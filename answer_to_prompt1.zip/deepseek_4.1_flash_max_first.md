---

# بلوپرینت معماری ابرسیستم معاملاتی — ARCH-TRD-001

**نسخه:** 1.0-FROZEN
**وضعیت:** آماده ارجاع به تیم اجرایی، آماده شروع فاز کدنویسی
**مالک سند:** Architecture Guild
**امضاکنندگان اجباری پیش از فریز:** CTO · Head of Trading Tech · CISO · Chief Risk Officer · Compliance Officer · SRE Lead · Head of Quant

---

## بلوپرینت ۰ — دامنه، تعریف و قرارداد ابهامزدایی

### ۰.۱ دامنه داخل (In Scope)

| # | دامنه | توضیح مرز |
|---|---|---|
| S1 | Multi-Asset Order Management | سهام، ETF، فیوچرز، آپشن، FX، کریپتو (v1: سهام + فیوچرز) |
| S2 | Market Data Ingestion & Normalization | فیدهای مستقیم بورس + دیتا وندور بهعنوان fallback |
| S3 | Pre-Trade & Real-Time Risk | چکهای اجباری 15c3-5 + لایههای داخلی |
| S4 | Smart Order Routing & Execution Algos | TWAP, VWAP, POV, IS, Pairs |
| S5 | Strategy Execution Runtime | استراتژیهای quant + manual + hybrid |
| S6 | Position, P&L, Double-Entry Ledger | ثبت تغییرناپذیر، قابل حسابرسی |
| S7 | Post-Trade, Clearing & Settlement Adapters | تطبیق با کارگزار/ CCP |
| S8 | Compliance & Surveillance | best-ex, market abuse, order-to-trade ratio, ثبت ۷ ساله |
| S9 | Backtest & Simulation | بازپخش قطعی بازار (deterministic replay) |
| S10 | Client Connectivity & API Plane | FIX 4.4/5.0, gRPC, REST, WebSocket |
| S11 | Control Plane | AuthN/Z، entitlement، config، feature flag، deployment |
| S12 | Observability, DR, Audit | SLO، ردیابی، WORM logging، failover |

### ۰.۲ دامنه خارج (Out of Scope v1)

- پادشاهیهای خردهفروشی (retail brokerage UI)
- صدور کارت / پرداخت
- Custody فیزیکی دارایی دیجیتال (فقط اتصال به custodian)
- مدیریت دارایی مشتری (wealth management)
- ساختار بازارسازی اجباری (market making obligation) — در v2

### ۰.۳ تصمیمهای باز که **باید** پیش از خط اول کد بسته شوند

| ID | تصمیم | گزینهها | مالک | مهلت |
|---|---|---|---|---|
| OD-01 | Latency Plane: on-prem colo یا cloud bare-metal | Equinix NY4/LD4 vs. AWS Outposts vs. hybrid | Head of Trading Tech | فریز |
| OD-02 | TSDB اصلی تیک | kdb+ / ClickHouse / QuestDB | Data Guild | فریز |
| OD-03 | OMS: build یا buy | Build in-house / Adaptive / LFGo | CTO | فریز |
| OD-04 | FPGA در مسیر سفارش | Software-only vs. FPGA NIC (Solarflare X3) | Arch Guild | فریز |
| OD-05 | مدل تسویه | Prime Broker / Self-clearing | CFO + Risk | فریز |
| OD-06 | حوزههای قضایی v1 | SEC/FINRA، MiFID II، یا هر دو | Compliance | فریز |
| OD-07 | کریپتو در v1 | بله/خیر (تأثیر مستقیم روی custody و ledger) | CTO | فریز |

**قاعده فریز:** هیچکدام از این هفت مورد با «TBD» به فاز کدنویسی نمیرسند. عدد یا گزینه، نه بازه.

---

## بلوپرینت ۱ — بازبینی پرامپت استخراجشده و تزریق الزاماتش به معماری

الزامات متدولوژیک پرامپت مستر مستقیماً به قواعد معماری ترجمه شدند. این جدول، مدرک انطباق است:

| الزام پرامپت | ترجمه معماری | جای پیادهسازی |
|---|---|---|
| «بدون خلا و کمبود» | Coverage Matrix اجباری: هر سرویس باید API + Schema + SLO + Runbook + Test Plan داشته باشد | §۱۰، §۱۹، §۲۲ |
| Blueprint: Code | پیادهسازی، قراردادها، schemaها | §۸–§۱۲ |
| Blueprint: Case | تحلیل حادثه، failure matrix، post-mortem قالب | §۲۰ |
| Blueprint: Explain | سند دانش، ADR، rationale هر تصمیم | §۷ |
| Blueprint: Weapon | معادل: کنترلهای دفاعی (kill switch، circuit breaker، limits) | §۲۱ |
| Blueprint: Criminology | معادل: تحلیل تهدید، threat model، abuse case | §۱۶ |
| Blueprint: Terrorism Handling | معادل: incident response playbook و coordination | §۲۲ |
| Injection Firewall | Trust Boundary + Message Authenticity + Input Contract Validation | §۱۶.۳ |
| Burn / Failure Detector | Fail-Fast Policy: هیچ degrade خاموشی مجاز نیست؛ هر شکست باید متریک تولید کند | §۲۰.۲ |
| Quality Lock | Contract Tests + Determinism Gate + Replay Certification | §۲۲ |
| Drift Detector | Model/Pricing Drift Monitor + Config Drift Detection | §۱۹.۴ |
| Prefix Cache | Hot-path precompute: پارامترهای ریسک، reference data، entitlement در حافظه | §۱۴ |
| Wiki Registry | Connector/Plugin Registry با نسخهبندی اجباری | §۸.۱۱ |
| Trigger Table | Runbook Trigger Registry | §۱۹.۵ |
| Hard Floor | Compliance Core جدا از کنترل تیم محصول، غیرقابل override | §۱۶.۱ |
| Thinking = [N] / no drift | Design Invariant: هر سرویس stateless یا event-sourced، هیچ state پنهانی | §۱۱ |

---

## بلوپرینت ۲ — نقشه قابلیتها (Capability Map)

```text
L0  TRADING PLATFORM
├─ L1  MARKET DATA PLANE
│   ├─ Feed Handlers (exchange direct) · Normalizer · Sequencer
│   ├─ Reference Data Service · Corporate Actions
│   └─ Bar Builder · Tick Store · Replay Service
├─ L1  ORDER PLANE
│   ├─ Client Gateway (FIX/gRPC/WS) · Session Manager
│   ├─ OMS Core · Order State Machine · Idempotency Store
│   ├─ Risk Gate (pre-trade) · Position Reservation
│   ├─ Smart Order Router · Venue Adapters
│   └─ Algo Engine (TWAP/VWAP/POV/IS)
├─ L1  RISK PLANE
│   ├─ Pre-Trade Risk · Real-Time Risk (intraday VaR, exposure)
│   ├─ Credit & Margin · Limit Registry
│   └─ Kill Switch Controller · Circuit Breakers
├─ L1  POST-TRADE PLANE
│   ├─ Execution Capture · Allocation · Confirmation
│   ├─ Double-Entry Ledger · Position Service · P&L Attribution
│   ├─ Clearing/Settlement Adapters · Reconciliation Engine
│   └─ Regulatory Reporting
├─ L1  COMPLIANCE PLANE
│   ├─ Surveillance (spoofing/layering patterns)
│   ├─ Best Execution Analytics · Clock Sync Monitor
│   └─ Audit WORM Store
├─ L1  SIMULATION PLANE
│   ├─ Backtest Engine · Market Replay · Fill Simulator
│   └─ Strategy Sandbox
└─ L1  PLATFORM PLANE
    ├─ Identity & Entitlement · Secrets/HSM · Config & Feature Flags
    ├─ Observability · Deployment Controller · Artifact Registry
    └─ Data Governance · Cost & Capacity
```

---

## بلوپرینت ۳ — الزامات غیرعملکردی با اعداد قطعی (NFR Contract)

| ID | متریک | هدف | روش سنجش |
|---|---|---|---|
| NFR-01 | Round-trip سفارش: gateway → venue ack | p50 ≤ 120µs · p99 ≤ 350µs | microbenchmark در colo + trace |
| NFR-02 | Pre-trade risk (۱۷ چک) | p99 ≤ 80µs | in-process bench در CI |
| NFR-03 | Market data ingest | 2M msg/s پایدار · 8M ذوجهای | load test با replay واقعی |
| NFR-04 | OMS throughput | 25k order/s پایدار · 100k burst 5s | soak 4h |
| NFR-05 | Availability — Trading Plane | 99.95% (≈ 4.4h/سال) | SLO monitor |
| NFR-06 | Availability — Post-Trade Plane | 99.90% | SLO monitor |
| NFR-07 | RPO سفارش/اجرا/دفتر | **0** (sync replication در metro) | chaos drill |
| NFR-08 | RTO intra-region | ≤ 30s | failover drill ماهانه |
| NFR-09 | RTO cross-region | ≤ 15min | DR drill فصلی |
| NFR-10 | دقت ساعت | ≤ 100µs نسبت به UTC (RTS 25) | PTP/GPS monitor |
| NFR-11 | نگهداری داده | ۷ سال WORM (سفارش، اجرا، ارتباطات، لاگ) | immutable policy test |
| NFR-12 | Determinism | ورودی یکسان → PnL یکسان بایتبهبایت | replay certification |
| NFR-13 | Order-to-Trade Ratio | کنترل per-session، fail در آستانه | limit registry |
| NFR-14 | Zero silent degradation | هر fallback باید event منتشر کند | audit query |
| NFR-15 | Deploy zero-downtime | hot-path: بدون قطع اتصال venue | canary by symbol |

---

## بلوپرینت ۴ — معماری مرجع (سه مسیر مستقل + یک صفحه حکمرانی)

```text
════════════════ PATH A — MARKET DATA (multicast in, fanout out) ════════════════

 Exchange A ─┐
 Exchange B ─┼─▶ [Feed Handler × N]  (colo, kernel-bypass, busy-poll)
 Exchange C ─┘        │
                      ▼
              [Sequencer per Symbol] ← gap-fill + snapshot reconcile
                      │  (strict per-symbol ordering, sequence numbers)
        ┌─────────────┼───────────────────────┐
        ▼             ▼                       ▼
  [Reference     [Bar Builder]          [Tick Store Writer]
   Data Cache]         │                       │ (Kafka → TSDB)
        │             ▼                       ▼
        │      [Pricing Service]         [Replay Service]
        ▼             ▼                       │
  ═════════════ [Market Data Bus — Kafka, key = symbol] ═════════════
        │             │                       │
        ▼             ▼                       ▼
   Strategy      Algo Engine            Backtest Plane
   Runtime       (needs book state)


════════════════ PATH B — ORDER (the hot path) ════════════════

 Client (FIX 4.4 / gRPC) 
        │ mTLS + session auth
        ▼
 [Client Gateway] ──▶ [Session Manager] (entitlement cache, throttle)
        │
        ▼ SBE-encoded internal envelope
 [Idempotency Filter]  (client_order_id hash, 60s window, dedupe)
        │
        ▼
 [Pre-Trade Risk Gate]  ← [Limit Registry | Position Cache | Ref Data | Kill Switch State]
        │  ALLOW / REJECT(with reason code)
        ▼
 [Position Reservation]  (optimistic reserve, TTL, released on terminal state)
        │
        ▼
 [OMS Core] ──── event: OrderAccepted ───▶ [Order Event Log — Kafka, key = order_id]
        │
        ▼
 [Smart Order Router]  ← [Venue State | Queue Model | Fee Model]
        │
        ▼
 [Venue Adapter: FIX/SBE/Binary]
        │
        ▼
     Exchange / Broker
        │
        ▼ fills
 [Execution Capture] ──▶ ORDER EVENT LOG ──▶ (Path C)


════════════════ PATH C — POST-TRADE (async, exactly-once-effect) ════════════

 [Order Event Log]
        │
        ├─▶ [Position Service]      (materialized view, per account/symbol)
        ├─▶ [P&L Attribution]       (realized / unrealized / fees / financing)
        ├─▶ [Double-Entry Ledger]   (append-only, hash-chained)
        ├─▶ [Allocation Service]    (block → sub-accounts)
        ├─▶ [Reconciliation Engine] (internal ↔ broker ↔ CCP, T+0 intraday, T+1 EOD)
        ├─▶ [Surveillance]          (pattern detection, out-of-band)
        └─▶ [Regulatory Reporting]  (CAT/MiFIR/TRAX adapters)


════════════════ SHEET D — CONTROL & GOVERNANCE PLANE ════════════════

 Identity (SPIFFE/mTLS) · Entitlement Service · Config Service (versioned, signed)
 Feature Flags · Strategy Registry (4-eye approval) · Limit Registry (4-eye, signed)
 Kill Switch Controller · Deployment Controller · Observability Stack · Audit WORM
```

**قاعده شکست مسیرها:** Path B هرگز به Path C وابسته نیست در مسیر درخواست. اگر Post-Trade بمیرد، معامله متوقف نمیشود — event در Kafka میماند و replay میشود. اگر Market Data بمیرد، OMS وارد حالت **SAFE** میشود: سفارش جدید بلاک، کنسلی مجاز.

---

## بلوپرینت ۵ — تفکیک اختیار: Latency Plane در برابر Control Plane

| ویژگی | Latency Plane | Control Plane |
|---|---|---|
| محل | Colo، bare metal، بدون hypervisor | Cloud، Kubernetes |
| سرویسها | Feed Handler, Sequencer, Gateway, Risk Gate, OMS Core, SOR, Venue Adapter, Algo | Auth, Config, Reporting, Surveillance, Reconciliation, Backtest, UI, Analytics |
| Deployment | Immutable image + blue/green per rack؛ بدون autoscaling | Helm/ArgoCD، HPA، canary |
| Change window | فقط خارج از سشن؛ هر تغییر = signed release | پیوسته |
| Kernel | DPDK/Solarflare Onload، busy-poll، isolated cores، NUMA pinning، hugepages | استاندارد |
| Network | PTP (IEEE 1588)، multicast، redundant NIC | NTP، VPC |
| دسترسی | فقط jump host + 2-person rule | SSO + RBAC |

**ADR-001:** چرا تفکیک؟ چون هر اختلال در autoscaling یا orchestration روی hot-path، خطای µs را به ms تبدیل میکند. Latency plane باید **قابل پیشبینی** باشد، نه الاستیک.

---

## بلوپرینت ۶ — فهرست کامل سرویسها (Service Catalog)

هر سرویس با پنج ستون اجباری: مسئولیت / API / State / SLO / حالت شکست.

### ۶.۱ Market Data Plane

| سرویس | مسئولیت | API | State | SLO | شکست |
|---|---|---|---|---|---|
| `feed-handler-<venue>` | دریافت فید خام، decode، timestamping سختافزاری | UDP multicast / TCP recovery | stateless per session | gap < 1msg/24h | سوئیچ به فید B بهصورت خودکار؛ اعلام `FEED_DEGRADED` |
| `sequencer` | ترتیب قطعی per symbol، gap detect، snapshot reconcile | gRPC stream | per-symbol ring buffer (in-mem) | p99 add-latency < 5µs | اگر gap > 250ms → `SYMBOL_STALE`، بلاک معامله روی آن نماد |
| `reference-data` | instrument master، tick size، lot، session calendar، limits | gRPC + local snapshot | versioned snapshot، hot-reload | read p99 < 20µs | آخرین snapshot معتبر میماند؛ تغییرات صف میشوند |
| `corporate-actions` | split/dividend/merger، اثر روی position و PnL | gRPC | event-sourced | daily batch + intraday alert | سفارش روی نماد دارای CA معلق |
| `bar-builder` | OHLCV برای 1s/1m/1h | Kafka out | windowed | accuracy 100% vs tick | backfill خودکار |
| `tick-store-writer` | نوشتن در TSDB با dedupe | Kafka consumer | idempotent writer | lag < 500ms | بافر روی دیسک، صفر از دست رفتن |
| `replay-service` | بازپخش قطعی با timestamp اصلی یا تسریعشده | gRPC | stateless | determinism 100% | مسدود کردن backtest، نه trading |

### ۶.۲ Order Plane

| سرویس | مسئولیت | API | State | SLO | شکست |
|---|---|---|---|---|---|
| `client-gateway` | FIX/gRPC/WS termination، session، throttle | FIX 4.4/5.0, gRPC | session state (Redis + in-mem) | p99 parse < 15µs | reject با `SESSION_UNAVAILABLE`، بدون صفبندی کور |
| `session-manager` | entitlement، rate limit، max open orders | gRPC | Redis + local cache | lookup p99 < 3µs | fail-closed: reject |
| `idempotency` | dedupe بر `client_order_id` | in-proc | 60s TTL store | p99 < 5µs | fail-closed |
| `risk-gate` | ۱۷ چک pre-trade | in-proc library | read-only cache | p99 ≤ 80µs | fail-closed → kill switch L1 |
| `position-reservation` | رزرو optimistic، release در terminal | in-proc + log | CRDT-ish counters | p99 < 10µs | fail-closed |
| `oms-core` | ماشین حالت سفارش، persistence، event publication | gRPC + events | event-sourced (log = truth) | 25k ord/s | fail-closed، بازگشت با replay |
| `sor` | انتخاب venue بر اساس قیمت/نقدشوندگی/کارمزد/سمت | in-proc | venue state cache | p99 < 15µs | route به primary venue، اعلام degraded |
| `venue-adapter-<v>` | پروتکل اختصاصی venue | FIX/binary | session + seq | p99 encode < 8µs | reconnect با gap-fill؛ سفارشها در `UNKNOWN` |
| `algo-engine` | TWAP/VWAP/POV/IS/pairs، child order slicing | internal | strategy state per algo order | jitter < 100µs | cancel-all فرزندان، اعلام |

### ۶.۳ Risk Plane

| سرویس | مسئولیت | SLO | شکست |
|---|---|---|---|
| `pre-trade-risk` | ۱۷ چک اجباری (جدول §۱۳) | p99 80µs | fail-closed |
| `realtime-risk` | exposure، VaR intraday، concentration، حداکثر زیان روز | ۱s recalc cadence | صفحه سفارش جدید را بلاک نمیکند اما kill switch L2 را فعال میکند |
| `credit-margin` | buying power، margin requirement، borrow availability | ۵۰۰ms | fail-closed برای سفارشهای margin |
| `limit-registry` | نسخهبندیشده، امضاشده، ۴ چشم | read p99 < 10µs | immutable: آخرین نسخه امضاشده |
| `kill-switch` | L1–L5 | p99 < 50ms سراسری | hardware fail-safe: نبود heartbeat = فعال |

### ۶.۴ Post-Trade Plane

| سرویس | مسئولیت | تضمین |
|---|---|---|
| `execution-capture` | ثبت هر fill، تطبیق با venue ack | at-least-once + dedupe = exactly-once effect |
| `position-service` | materialized view per (account, instrument) | rebuild از log < 60s |
| `pnl-attribution` | realized/unrealized/fees/financing/FX | reconcile روزانه با ledger، صفر اختلاف |
| `ledger` | double-entry، hash-chained، append-only | immutability test در CI |
| `allocation` | block → sub-accounts، average price | idempotent |
| `reconciliation` | internal ↔ broker ↔ CCP، T+0 intraday + T+1 EOD | هر اختلاف = incident، نه ticket |
| `reg-reporting` | CAT/MiFIR/TRAX/EMIR | در صورت شکست: retry + صف + alert فوری |

### ۶.۵ Simulation Plane

| سرویس | مسئولیت |
|---|---|
| `backtest-engine` | replay قطعی، fill simulator با queue-position model، latency model، fee model |
| `fill-simulator` | مدل صف: eager/lazy/pessimistic بر اساس عمق L2 |
| `strategy-sandbox` | اجرای استراتژی با همان interface پروداکشن (no rewrite) |
| `scenario-generator` | سناریوی بحران: halt، gap، flash crash، latency spike |

### ۶.۶ Platform Plane

`identity` (SPIFFE/SPIRE) · `entitlement` · `config-service` (versioned, signed, hot-reload، اثر صفر روی hot-path بدون اعلام) · `feature-flags` · `strategy-registry` (۴ چشم) · `artifact-registry` (signed، SBOM، SLSA L3) · `observability` (OTel) · `audit-worm` · `secrets/HSM` · `cost-governance`.

### ۶.۷ Connector Registry (معادل Wiki در پرامپت)

هر connector (venue, data vendor, broker, CCP) با: `id`, `version`, `protocol`, `capabilities`, `certification_status`, `owner`, `sla`. **قاعده اجباری:** connector بدون certification_status = `CERTIFIED` قابل استقرار در پروداکشن نیست. این تنها دروازه ورود به hot-path است.

---

## بلوپرینت ۷ — ماشین حالت سفارش (قطعی و کامل)

```text
                        ┌─────────┐
                        │  INIT   │
                        └────┬────┘
                             │ validate
                        ┌────▼─────┐   REJECT(reason)
                        │VALIDATED ├──────────────▶ ┌──────────┐
                        └────┬─────┘                 │ REJECTED │ (terminal)
                             │ risk
              ┌──────────────┼──────────────┐        └──────────┘
        RISK_PASS       RISK_FAIL                  
              │              └───────────────────────────┘
        ┌─────▼──────┐
        │ RESERVED   │──── timeout(2s) ──▶ │ EXPIRED │ (terminal)
        └─────┬──────┘
              │ sent to venue
        ┌─────▼──────┐   reject      ┌──────────┐
        │  ROUTED    ├──────────────▶│ REJECTED │
        └─────┬──────┘               └──────────┘
              │ venue ack
        ┌─────▼──────┐
        │  ACKED     │
        └──┬───┬───┬─┘
           │   │   │
  partial  │   │   │ cancel
   fill    │   │   └──────────────┐
           ▼   │                  ▼
    ┌──────────┴───┐       ┌────────────┐
    │ PARTIAL_FILL │       │ CANCELLED  │
    └──────┬───────┘       └────────────┘
           │ full fill
    ┌──────▼───────┐       ┌────────────┐
    │   FILLED     │       │  EXPIRED   │
    └──────────────┘       └────────────┘
```

**استثناها (اجباری):**

| حالت | معنی | رفتار |
|---|---|---|
| `PENDING_REPLACE` | درخواست amend ارسال شده | تا ack، cancel صف میشود |
| `PENDING_CANCEL` | cancel ارسال شده | fill در این بازه پذیرفته میشود (invariant واقعی) |
| `UNKNOWN` | ack گم شده / قطع اتصال | **ورود ممنوع به terminal**. اجرای `reconcile-by-query` (order status request) با backoff؛ بعد از 30s escalate به incident |
| `STALE_SYMBOL` | داده نماد تازه نیست | cancel all + بلاک نماد |

**Invariants (تست اجباری property-based):**
1. `Σ(filled_qty) ≤ order_qty` همیشه.
2. هر transition مهر زمانی PTP دارد و در event log ثبت میشود.
3. هیچ گذار از terminal به non-terminal وجود ندارد.
4. `UNKNOWN → terminal` فقط با reconcile انجام میشود، نه با حدس.
5. reserve همیشه در terminal آزاد میشود — leak reserve = P0 incident.

---

## بلوپرینت ۸ — چکهای Pre-Trade Risk (فهرست کامل و ترتیب اجرا)

ترتیب بر اساس «ارزانترین و قاطعترین اول» تا p99 ≤ 80µs حفظ شود:

| # | چک | منبع داده | fail behaviour |
|---|---|---|---|
| 1 | Kill switch state (L1–L5) | in-mem flag | reject |
| 2 | Session entitlement | cache | reject |
| 3 | Market state (open/halted/auction) | ref data cache | reject |
| 4 | Symbol not restricted / not halted | ref data | reject |
| 5 | Duplicate order (`client_order_id` hash، 60s) | idempotency store | reject `DUPLICATE` |
| 6 | Qty > 0 و tick-size/lot valid | ref data | reject |
| 7 | Max order qty | limits | reject |
| 8 | Max order notional | limits | reject |
| 9 | Price collar: deviation از reference > X% | pricing cache | reject |
| 10 | Fat-finger: قیمت بیرون از باند L2 | book snapshot | reject |
| 11 | Max open orders per session | counter | reject |
| 12 | Max message rate / OTR | token bucket | reject |
| 13 | Buying power / credit available | credit cache | reject |
| 14 | Position limit pre+delta | position cache | reject |
| 15 | Short-sale locate / SSR | locates service | reject (فقط shorts) |
| 16 | Self-trade prevention (STP) | open orders index | cancel aggressor یا resting (config) |
| 17 | Max notional per symbol per day | daily counter | reject |

**قاعده طلایی:** هر چک باید **قابل خاموششدن per-account** باشد، اما خاموشی باید event منتشر کند و در داشبورد فریز باقی بماند. خاموشی خاموش ممنوع.

---

## بلوپرینت ۹ — مدل داده کانونیک (Schemas)

### ۹.۱ Instrument

```yaml
Instrument:
  instrument_id: string (ULID, immutable)
  isin: string|optional
  symbol_primary: string
  venue_symbols: map<venue_id, string>
  asset_class: enum[EQUITY, ETF, FUTURE, OPTION, FX, CRYPTO]
  currency: ISO4217
  tick_size: decimal
  lot_size: integer
  contract_multiplier: decimal
  session_calendar_id: string
  settlement_cycle: string  # T+1, T+2, T+0
  status: enum[ACTIVE, HALTED, DELISTED, PENDING]
  effective_from: timestamp
  version: integer
```

### ۹.۲ Order (internal SBE envelope)

```yaml
Order:
  order_id: ULID                # generated internally
  client_order_id: string       # client-supplied, dedupe key
  parent_order_id: ULID|optional# برای child orders
  account_id: string
  strategy_id: string
  instrument_id: string
  side: enum[BUY, SELL, SELL_SHORT]
  order_type: enum[MARKET, LIMIT, STOP, STOP_LIMIT, PEGGED, IOC, FOK]
  qty: decimal
  price: decimal|optional
  tif: enum[DAY, IOC, FOK, GTC, GTD]
  venue_target: enum[AUTO, <venue_id>]
  created_at_ptp: timestamp_ns
  status: enum[*]               # ماشین حالت §۷
  reason_code: string|optional
  version: integer              # increment بر هر transition
```

### ۹.۳ OrderEvent (append-only، منبع حقیقت)

```yaml
OrderEvent:
  event_id: ULID
  order_id: ULID
  seq: integer                  # monotonic per order
  type: enum[VALIDATED, RISK_PASS, RISK_FAIL, RESERVED, ROUTED, ACKED,
             PARTIAL_FILL, FILLED, AMEND_REQUEST, AMEND_ACK,
             CANCEL_REQUEST, CANCELLED, REJECTED, EXPIRED, UNKNOWN, RECONCILED]
  payload: map
  venue_seq: integer|optional
  ts_ptp: timestamp_ns
  ingest_node: string
  hash_prev: string             # hash chain
  hash_self: string
```

### ۹.۴ Execution (fill)

```yaml
Execution:
  exec_id: string               # venue exec id OR internal
  order_id: ULID
  venue_id: string
  instrument_id: string
  side: enum
  last_qty: decimal
  last_price: decimal
  cum_qty: decimal
  leaves_qty: decimal
  liquidity_flag: enum[ADDED, REMOVED, AUCTION, UNKNOWN]
  fee_amount: decimal
  fee_currency: ISO4217
  trade_date: date
  exec_ts_venue: timestamp_ns
  exec_ts_local_ptp: timestamp_ns
```

### ۹.۵ Position (materialized view)

```yaml
Position:
  account_id, instrument_id, trade_date
  net_qty, long_qty, short_qty
  avg_cost, realized_pnl, unrealized_pnl
  fees_paid, financing_accrued
  last_mark_price, last_mark_ts
  state_hash      # برای reconciliation سریع
```

### ۹.۶ LedgerEntry (double-entry، hash-chained، append-only)

```yaml
LedgerEntry:
  entry_id: ULID
  journal_id: ULID
  account_code: string          # chart of accounts
  debit: decimal
  credit: decimal
  currency: ISO4217
  pair_entry_id: ULID           # سمت مقابل
  source_ref: {type: EXECUTION|FEE|FINANCING|CA|TRANSFER, id: string}
  posted_at: timestamp
  hash_prev, hash_self
  # INVARIANT: Σ debit − Σ credit = 0 per journal
```

### ۹.۷ RiskLimit

```yaml
RiskLimit:
  limit_id: string
  scope: enum[GLOBAL, ACCOUNT, STRATEGY, INSTRUMENT, STRATEGY×INSTRUMENT]
  scope_ref: string
  metric: enum[NOTIONAL, QTY, OPEN_ORDERS, OTR, LOSS_DAY, CONCENTRATION, SHORT_POS]
  threshold: decimal
  window: enum[ORDER, MINUTE, DAY, ROLLING_24H]
  action: enum[BLOCK, ALERT, KILL_L1, KILL_L2]
  effective_from, approved_by[2], signature, version
```

---

## بلوپرینت ۱۰ — قراردادهای API و Event Bus

### ۱۰.۱ API Surface (v1 freeze — شمارش قطعی)

| گروه | تعداد | پروتکل | مثال |
|---|---|---|---|
| Order Entry | 6 | FIX 4.4 + gRPC | NewOrderSingle, OrderCancelRequest, OrderCancelReplaceRequest, OrderStatusRequest, MassCancel, MassStatus |
| Market Data | 4 | gRPC stream + WS | SubscribeBook, SubscribeTrades, Snapshot, Heartbeat |
| Position/PnL | 5 | gRPC/REST | GetPosition, ListPositions, GetPnL, GetPnLAttribution, GetExposure |
| Risk | 6 | gRPC/REST | GetLimits, SetLimit(4-eye), GetRiskState, ArmKillSwitch, DisarmKillSwitch, GetKillState |
| Ref Data | 3 | gRPC/REST | GetInstrument, ListInstruments, GetCalendar |
| Post-Trade | 5 | REST/gRPC | GetExecutions, GetAllocations, GetAllocation, TriggerRecon, GetReconReport |
| Simulation | 4 | gRPC | StartReplay, StopReplay, GetReplayStatus, RunBacktest |
| Admin | 5 | gRPC | Health, Drain, ConfigReload, FeatureFlagSet, AuditQuery |
| **جمع** | **38** | | |

هر ۳۸ اندپوینت پیش از فریز باید **OpenAPI/gRPC proto + contract test + مثال خطای کامل** داشته باشد. بدون این سه، سرویس در فاز ۱ ترخیص نمیشود.

### ۱۰.۲ Event Topics (Kafka)

| Topic | Key | Partitions | Retention | Ordering guarantee |
|---|---|---|---|---|
| `md.raw.<venue>` | symbol | 64 | 24h | per partition |
| `md.normalized` | symbol | 64 | 24h | per symbol (strict) |
| `md.bar.1s` | symbol | 32 | 7d | per symbol |
| `order.events` | order_id | 128 | 7y (tiered) | **per order (strict)** |
| `exec.events` | order_id | 128 | 7y | per order |
| `position.snapshot` | account | 32 | 30d | per account |
| `ledger.postings` | account_code | 32 | 7y | per account |
| `risk.alerts` | account | 16 | 90d | best-effort |
| `killswitch.events` | global | 1 | 7y | total |
| `config.changes` | key | 8 | 7y | total |
| `audit.trail` | tenant | 32 | 7y WORM (tiered to S3 Object Lock) | per tenant |

**تضمینها:**
- `order.events` = at-least-once در transport، **exactly-once effect** در consumer با `event_id` dedupe + idempotent projection.
- Producer: `acks=all`, `enable.idempotence=true`, `max.in.flight=1` برای partitionهای سفارش.
- Consumer projection: `offset commit` بعد از write، با `state_hash` مقایسه برای تشخیص replay ناقص.

---

## بلوپرینت ۱۱ — مدل سازگاری و الگوهای تضمین

| نیاز | الگو | نتیجه |
|---|---|---|
| سفارش دقیقاً یکبار اعمال شود | Idempotency key + dedupe store + event_id | اثر یکبار |
| Position همیشه قابل بازسازی | Event sourcing از `order.events` | rebuild < 60s |
| Ledger قابل حسابرسی | Hash chain + append-only + WORM | دستکاری قابل تشخیص |
| انتشار اتمی event + state | Transactional Outbox | صفر lost event |
| عملیات چندسرویسی (allocation، settlement) | Saga با compensating action | سازگاری نهانی |
| خواندن سریع | CQRS: write = event log، read = projection | hot read path بدون قفل |
| ترتیب per-symbol | Partitioner بر symbol + seq check | صفر out-of-order |
| Fail-fast | هیچ fallback بیصدا؛ همه degradeها event | Ops همیشه میداند |

**ADR-002:** چرا event sourcing برای OMS؟ چون تنها راه رسیدن به RPO=0 و rebuild قطعی position/PnL بدون اختلاف حسابداری است. هزینه: پیچیدگی projection. جبران: projections ساده و تستشده با replay certification.

---

## بلوپرینت ۱۲ — معماری داده و ذخیرهسازی

| لایه | داده | فناوری | Retention | دسترسی |
|---|---|---|---|---|
| Hot | سفارش فعال، book، limits، entitlement | in-memory (Aeron/Chronicle/Redis) | دقیقه–ساعت | µs |
| Warm | event log، tick 30 روز | Kafka + kdb+ یا ClickHouse | 30d hot queryable | ms |
| Cold | tick/سفارش تاریخی | S3 + Parquet + بهینهسازی per query | 7y | s |
| WORM | audit، ارتباطات، تصمیمات ریسک | S3 Object Lock (compliance mode) | 7y | قابل حذف نیست |
| Relational | config، limit، ref data metadata، allocations | PostgreSQL (HA، sync replica) | بیپایان با versioning | ms |
| Vector/ML | feature store، مدلهای ریسک | Feast + object store | 1y rolling | ms |

**ADR-003:** Tick store = kdb+ اگر تیم مهارت دارد و بودجه مجاز؛ در غیر این صورت ClickHouse با `ReplacingMergeTree` + `ORDER BY (symbol, ts)`. تصمیم OD-02 باید پیش از اسپرینت ۳ بسته شود چون schema و ingestion را قفل میکند.

**قاعده ذخیرهسازی:** هیچ نوشتنی در hot-path منتظر دیسک نمیماند. Writerها async با backpressure و journal محلی.

---

## بلوپرینت ۱۳ — توپولوژی استقرار و DR

### ۱۳.۱ Cell-based Architecture

```text
Region US-EAST (metro: NY4 + NY5، 2 AZ)
 ├─ Cell EQ-US   : سهام آمریکا       (colo hot + cloud control)
 ├─ Cell FU-US   : فیوچرز آمریکا     (colo hot + cloud control)
 └─ Cell SHARED  : post-trade، ledger، reporting، analytics

Region EU-WEST (LD4 + LD5)
 ├─ Cell EQ-EU
 └─ Cell SHARED-EU

DR Region (US-WEST / EU-CENTRAL)
 └─ Warm standby: infra آماده، state از S3 + event replay
```

**چرا cell؟** انفجار blast radius. خرابی در cell فیوچرز نباید معامله سهام را متوقف کند. هر cell: مستقل در hot-path، مشترک در governance plane.

### ۱۳.۲ مدل DR

| سناریو | RPO | RTO | مکانیزم |
|---|---|---|---|
| از دست رفتن یک AZ | 0 | < 30s | sync replica در AZ دوم + VIP failover |
| از دست رفتن کل metro | 0 (تا آخرین ack) | < 15min | async cross-region + replay از WORM |
| خرابی Kafka broker | 0 | < 10s | RF=3، min.insync=2 |
| خرابی DB primary | 0 | < 20s | Patroni + sync standby |
| خرابی HSM | 0 | < 5min | HSM خوشهای / key escrow سرد |

**قاعده:** بازگشت به پروداکشن فقط با **replay certification سبز** مجاز است، نه با «بالا آمد».

---

## بلوپرینت ۱۴ — بودجه تأخیر (Latency Budget) — مسیر سفارش

| مرحله | p50 | p99 | یادداشت |
|---|---|---|---|
| Client SDK encode | 3µs | 8µs | SBE |
| TLS/QUIC terminate (colo edge) | 8µs | 25µs | session resumption |
| Auth + entitlement cache | 1µs | 3µs | in-proc |
| Gateway parse | 1µs | 3µs | zero-alloc |
| Idempotency check | 1µs | 4µs | hash + ring |
| Risk gate (۱۷ چک) | 22µs | 78µs | 순서 §۸ |
| Position reservation | 2µs | 8µs | atomic counter |
| OMS transition + event append | 6µs | 18µs | log append (no fsync on hot path; journal + replication) |
| SOR decision | 3µs | 12µs | cached venue state |
| Venue encode | 2µs | 7µs | |
| NIC → wire | 1µs | 2µs | |
| **جمع داخلی** | **~50µs** | **~168µs** | |
| Wire RTT به venue (colo) | ~40µs | ~120µs | فاصله فیزیکی |
| **End-to-end** | **~90µs** | **~290µs** | زیر NFR-01 با حاشیه |

**قواعد حفظ بودجه (همه اجباری):**
1. Zero allocation در hot path (pool + preallocated buffers).
2. بدون lock؛ فقط lock-free ring و per-core state.
3. GC-free: C++/Rust در مسیر سفارش و فید.
4. CPU pinning + isolcpus، NUMA-aware، hugepages.
5. هیچ I/O سنکرون در مسیر؛ فقط append به ring و flush توسط thread جدا.
6. هر PR که p99 را > 5% بدتر کند، در CI رد میشود (latency gate).

---

## بلوپرینت ۱۵ — مدل ظرفیت و برآورد هزینه (Assumptions صریح)

| پارامتر | مقدار v1 | مقدار peak |
|---|---|---|
| نمادهای فعال | 3,000 | 8,000 |
| پیام مارکت دیتا | 400k msg/s | 2.5M msg/s |
| سفارش | 2k/s | 25k/s (burst) |
| اجرا | 1.5k/s | 15k/s |
| کلاینت همزمان | 200 sessions | 800 |
| حجم event log روزانه | ~380 GB | ~1.2 TB |
| حجم tick خام روزانه | ~6 TB | ~18 TB |

**تخمین زیرساخت (ماهانه، مرتبه بزرگی):**

| بخش | هزینه تقریبی |
|---|---|
| Colo (2 cage، 20 rack unit، cross-connect، power) | $40–70k |
| Cloud control plane (EKS, RDS, S3, observability) | $25–40k |
| Kafka/MQ managed یا self-hosted HA | $12–20k |
| TSDB (kdb+ license یا ClickHouse cluster) | $10–35k |
| HSM + secrets + security tooling | $6–12k |
| DR region | $15–25k |
| مارکت دیتا (vendor/ exchange fees) | متغیر — خارج از این سند |
| **جمع فنی** | **≈ $110–200k/ماه** |

عدد نهایی پس از بستن OD-01 و OD-02 قابل قفل شدن است. این جدول برای بودجهبندی فاز ۱ کافی است.

---

## بلوپرینت ۱۶ — امنیت، اعتماد و Compliance Core

### ۱۶.۱ Compliance Core (غیرقابل override — معادل Hard Floor)

```text
┌───────────────────────────────────────────────────────────┐
│ COMPLIANCE CORE — سرویس مستقل، مالکیت: CCO               │
│ • خارج از control plane تیم محصول                         │
│ • نمیتواند با feature flag خاموش شود                     │
│ • روی ورودی و خروجی مسیر سفارش اعمال میشود               │
│ • verdict: ALLOW | BLOCK | ALLOW_WITH_RECORD              │
│ • نسخه policy داخل کد پین است، نه در config تنت          │
└───────────────────────────────────────────────────────────┘
```

چرا جدا؟ چون هر کنترل داخل کد محصول قابل حذف در refactor است. کف سخت باید **بیرون از مسیر مهندسی محصول** باشد تا با تغییر معماری جابهجا نشود.

### ۱۶.۲ Zero-Trust

| کنترل | پیادهسازی |
|---|---|
| هویت سرویس | SPIFFE/SPIRE، mTLS اجباری، بدون استثنا |
| مجوزدهی | OPA/Rego policy-as-code، deny-by-default |
| Secrets | Vault + HSM، TTL کوتاه، هیچ secret در env یا repo |
| امضای artifact | cosign + SBOM + SLSA L3 + reproducible build |
| دسترسی انسان | SSO + hardware key + 2-person rule در پروداکشن hot-path |
| امضای تغییر limit | 2-of-N approval، hash ثبت در WORM |
| شبکه | micro-segmentation، هیچ lateral حرکت آزاد |

### ۱۶.۳ Threat Model (چارچوب STRIDE + abuse case معاملاتی)

| تهدید | مسیر | کنترل |
|---|---|---|
| Spoofing سفارش مشتری | Session hijack | mTLS + session binding + sequence check |
| Tampering با limit | config path | امضای ۴ چشم، WORM، اعتبارسنجی در risk gate |
| Repudiation سفارش | “من این را نفرستادم” | امضای پیام + log WORM + clock PTP |
| Information disclosure | leak موقعیت | entitlement در سطح نماد، redaction در stream |
| DoS روی venue adapter | flood سفارش | token bucket + OTR + kill switch خودکار |
| Elevation | bypass risk gate | fail-closed، health heartbeat، OPA deny-all |
| Abuse: spoofing/layering در استراتژی | الگوریتم مخرب | surveillance + pre-trade pattern limit + 4-eye برای deploy |
| Abuse: wash trading خودکار | خوداستراتژی | STP اجباری، cross-strategy detection |

---

## بلوپرینت ۱۷ — الزامات مقرراتی (Checklist قابل حسابرسی)

| رگولاتوری | الزام | جای پیادهسازی |
|---|---|---|
| SEC 15c3-5 (Market Access) | pre-trade risk controls، supervisory review، immediate cancel | §۸ چکهای 1,4,7,8,9,10,11,13,14 |
| FINRA 3110 / 4511 | supervision + recordkeeping 6 سال | WORM §۱۲ |
| MiFID II RTS 6 | algorithmic trading controls، kill functionality، testing، change control | §۲۱، §۲۳، §۲۲ |
| MiFID II RTS 25 | clock sync ≤ 100µs | PTP monitor §۱۹ |
| MiFID II RTS 27/28 | best execution reporting | best-ex analytics §۶.۴ |
| Reg SHO / SSR | locate قبل از short | چک ۱۵ |
| EMIR / Dodd-Frank | derivative reporting | reg-reporting adapter |
| GDPR | حق حذف روی داده شخصی (نه روی رکورد معاملاتی) | data governance تفکیک |
| Order-to-Trade Ratio rules | نسبت پیام به معامله | token bucket §۸ چک ۱۲ |
| Market abuse (MAR) | نظارت بر دستکاری | surveillance §۶.۴ |

**قاعده:** هر الزام باید یک **تست خودکار** داشته باشد. الزام بدون تست = الزام محققنشده.

---

## بلوپرینت ۱۸ — Observability و SLO

### ۱۸.۱ Golden Signals per Service

| سیگنال | متریک | منبع |
|---|---|---|
| Latency | p50/p99/p99.9 per hop | OTel spans + histogram |
| Traffic | msg/s, order/s, exec/s | counters |
| Errors | reject rate by reason_code، failed transitions | counters + log |
| Saturation | queue depth، kernel drop، CPU per core | eBPF |

### ۱۸.۲ SLOهای اجباری و Error Budget

| SLO | هدف | بودجه ماهانه | اقدام در مصرف ۷۵% |
|---|---|---|---|
| Order path availability | 99.95% | 21.6 min | فریز تغییرات hot-path |
| Order ack latency p99 | < 350µs | 5% افت | هشدار معماری |
| Market data freshness | per symbol < 250ms | 0.1% | ورود به SAFE mode |
| Ledger reconciliation | صفر اختلاف در T+1 | 0 | incident فوری |

### ۱۸.۳ Drift Monitoring

| نوع drift | مانیتور | آستانه |
|---|---|---|
| مدل ریسک (VaR) | backtest divergence | > 8% → بازنگری مدل |
| Fill simulator | مقایسه با fill واقعی | > 5% MAE → بازنگری simulator |
| Config drift | diff بین git و runtime | > 0 → alert فوری |
| Latency drift | هفتگی p99 trend | +10% → ticket معماری |
| Data dialect drift (venue) | schema validation | هر mismatch → adapter quarantine |

---

## بلوپرینت ۱۹ — ماتریس شکست و رفتار سیستم (Failure Matrix)

| # | شکست | تشخیص | پاسخ خودکار | اقدام دستی | RTO |
|---|---|---|---|---|---|
| 1 | قطع فید اصلی | heartbeat miss 3× | سوئیچ فید B + `FEED_DEGRADED` | بررسی carrier | < 2s |
| 2 | gap در sequence | seq discontinuity | درخواست snapshot، بلاک نماد | هشدار | < 5s |
| 3 | نماد stale | freshness > 250ms | `STALE_SYMBOL` → cancel + block | — | < 1s |
| 4 | از دست رفتن ack venue | timeout 5s | `UNKNOWN` + query status | بررسی manual | 30s |
| 5 | قطعی venue session | disconnect | reconnect + reconcile + gap fill | بررسی venue | < 10s |
| 6 | Risk service down | health fail | **fail-closed**: هیچ سفارش جدید | بازگردانی | immediate |
| 7 | Ledger down | write fail | تجمع در Kafka، معامله ادامه | بازگردانی | 60s |
| 8 | DB primary down | Patroni failover | auto promote | تأیید | 20s |
| 9 | Kafka broker loss | RF drop | re-replicate | جایگزینی | 10s |
| 10 | AZ loss | VIP failover | failover به AZ دوم | تأیید ظرفیت | 30s |
| 11 | Region loss | cross-region health | standby activation + replay | بیانیه | 15min |
| 12 | Clock sync loss | offset > 100µs | **بلوک سفارش** (رگولاتوری) | بررسی GPS/PTP | immediate |
| 13 | HSM unavailable | handshake fail | مسدودسازی دسترسی امتیازی | — | 5min |
| 14 | Disk full on hot path | watermark 85% | چرخش به disk بعدی، drop oldest cached | Scalability ticket | 5min |
| 15 | Network partition gateway↔risk | timeout | fail-closed | — | immediate |

**قاعده قاطع:** در هر ردیف، هیچ «degrade خاموش» وجود ندارد. هر ردیف **حداقل یک متریک و یک event** تولید میکند. جدول بدون متریک = جدول مرده.

---

## بلوپرینت ۲۰ — Kill Switch و Circuit Breakers (پنج سطح)

| سطح | دامنه | چه میکند | احراز هویت | بازیابی |
|---|---|---|---|---|
| **L1** | استراتژی | لغو تمام سفارشهای استراتژی + عدم پذیرش جدید | خودکار (limit breach) یا ۱ اپراتور | ۴ چشم |
| **L2** | حساب/سشن | لغو + بلاک حساب | خودکار (loss day) یا ۲ اپراتور | ۴ چشم |
| **L3** | نماد | cancel-all نماد + بلاک | ۱ اپراتور یا venue halt | خودکار با ease-in |
| **L4** | venue | قطع اتصال + reroute به venue دیگر | ۲ اپراتور | ۴ چشم |
| **L5** | global | flatten کامل + بلاک همه خروجیها | ۲ اپراتور + hardware key | CTO + CRO |

**سختافزاری fail-safe:** اگر kill-switch controller heartbeat از دست برود، وضعیت **ARMED** فرض میشود و مسیر سفارش fail-closed میشود. غیبت heartbeat = فعال، نه غیرفعال.

**Circuit breaker per-account (خودکار):**
- زیان روزانه > 1.5% NAV → L2
- OTR > آستانه → throttle
- reject rate > 20% در 60s → L2
- اختلاف reconciliation > 0 → L1 فوری

---

## بلوپرینت ۲۱ — استراتژی تست و Certification Gate

### ۲۱.۱ هرم تست

| لایه | ابزار | پوشش لازم |
|---|---|---|
| Unit | gtest/pytest/cargo test | ≥ 85% branch در risk و state machine |
| Property-based | Hypothesis/QuickCheck | invariantهای §۷ |
| Contract | Pact + protobuf breaking-change check | 100% APIها |
| Integration | docker-compose + sim venue | مسیر سفارش کامل |
| Replay | بازپخش روز واقعی بازار | determinism 100% |
| Load | 3× peak، 4 ساعت | بدون خطای SLO |
| Soak | 72 ساعت | صفر mem leak، صفر fd leak |
| Chaos | netem, kill -9, partition, clock skew | هر ردیف §۱۹ اجرا شده |
| Security | SAST/DAST/SCA + abuse suite | صفر Critical |
| Regression PnL | replay مقایسه بایتبهبایت | صفر divergence |

### ۲۱.۲ فیدلیتی بکتست (اجباری برای پذیرش استراتژی)

| مؤلفه | الزام |
|---|---|
| timestamp | میکروثانیه، PTP-aligned |
| queue position | مدلشده (eager/pessimistic) |
| latency | شبیهسازی تأخیر واقعی per hop |
| partial fill | بر اساس عمق L2 و نرخ برخورد |
| fee model | tiered + exchange rebates |
| borrow cost | برای short |
| corporate actions | اعمال در replay |
| market impact | مدل Almgren-Chriss برای سفارشهای بزرگ |

**قول قطعی:** استراتژی بدون **certification report** وارد پروداکشن نمیشود. گزارش شامل: 90 روز backtest، 30 روز paper، replay divergence = 0.

---

## بلوپرینت ۲۲ — CI/CD و مدیریت تغییر

```text
Git (monorepo: services/ + infra/ + contracts/)
   │
   ├─ PR gate: lint → build → unit → property → contract → latency bench
   │           (هر regression در p99 > 5% ⇒ reject)
   ▼
Artifact: signed image + SBOM + provenance (SLSA L3)
   │
   ├─ Deploy dev      (auto)
   ├─ Deploy staging  (auto، replay یک روز کامل)
   ├─ Deploy paper    (auto، 24h، ترافیک shadow واقعی)
   ├─ Deploy prod-canary (5% نمادها، 48h، فقط خارج سشن)
   └─ Deploy prod-full  (4-eye approval برای hot-path)
```

**قواعد تغییر (MiFID II RTS 6 انطباق):**
- هر تغییر hot-path = signed release + change record + rollback plan مکتوب.
- تغییر پارامتر ریسک = 4-eye + hash در WORM + ثبت دلیل.
- تغییر استراتژی = certification report ضمیمه.
- بدون rollback plan = بدون deploy. بدون استثنا.

---

## بلوپرینت ۲۳ — محیطها

| محیط | هدف | داده | دسترسی |
|---|---|---|---|
| `dev` | توسعه | داده مصنوعی | همه |
| `staging` | تست یکپارچه | replay تاریخی | تیمها |
| `paper` | تمرین با فید واقعی، اجرای مجازی | فید live، fill simulator | Quant + Ops |
| `sim-venue` | تست adapter بدون هزینه | venue simulator | Eng |
| `prod-canary` | 5% نمادها | واقعی | محدود |
| `prod` | تولید | واقعی | 2-person |

---

## بلوپرینت ۲۴ — Testing the Human: Runbooks و Incident Response

| Runbook | Trigger | اولین اقدام |
|---|---|---|
| RB-01 Feed Loss | `FEED_DEGRADED` | تأیید فید B، بررسی carrier |
| RB-02 Symbol Stale | `STALE_SYMBOL > 30s` | cancel-all نماد، اطلاع exchange |
| RB-03 UNKNOWN Orders | 5+ سفارش در UNKNOWN | reconcile-by-query، escalate |
| RB-04 Risk Fail-Closed | reject 100% | بررسی health، تصمیم ادامه/توقف |
| RB-05 Ledger Divergence | recon diff ≠ 0 | L1 فوری + حسابداری |
| RB-06 Kill Switch Assert | heartbeat miss | بررسی کنترلر، قفل سیستم |
| RB-07 Clock Drift | offset > 100µs | توقف سفارش، بررسی PTP |
| RB-08 Venue Outage | disconnect > 30s | L4، reroute، بیانیه |
| RB-09 Region Failover | AZ/region loss | اجرای DR playbook |
| RB-10 Suspected Abuse | surveillance alert | L1/L2، بررسی compliance |

**تمرین اجباری:** هر runbook ماهانه drill میشود. Runbookی که ۹۰ روز drill نشده = runbook منقضی.

---

## بلوپرینت ۲۵ — سازمان، مالکیت و توالی فازها (WBS)

### ۲۵.۱ Team Topology

| تیم | نوع | مالکیت |
|---|---|---|
| Market Data | Stream-aligned | feed handlers, sequencer, bar, tick store |
| Order Path | Stream-aligned | gateway, OMS, SOR, adapters |
| Risk & Limits | Stream-aligned | risk gate, realtime risk, credit, kill switch |
| Post-Trade & Ledger | Stream-aligned | capture, position, PnL, ledger, recon |
| Execution Algos | Stream-aligned | TWAP/VWAP/POV/IS, child order mgmt |
| Client Connectivity | Stream-aligned | FIX/gRPC, SDK, entitlement |
| Platform | Platform | k8s, observability, deploy, secrets |
| Security | Platform | SPIFFE, HSM, OPA, supply chain |
| Compliance Engineering | Enabling | surveillance, reporting, audit |
| Data & Analytics | Complicated-subsystem | TSDB, feature store, best-ex analytics |

### ۲۵.۲ فازبندی با معیار خروج قطعی

| فاز | محتوا | معیار خروج (Exit Criteria) | مدت تقریبی |
|---|---|---|---|
| **P0** | فریز این سند + بستن OD-01..07 | ۷ امضا + صفر TBD | ۱–۲ هفته |
| **P1** | Platform skeleton: identity، config، deploy، observability، artifact registry | SLO pipeline فعال، deploy dev/staging، همه سرویسها health | ۴ هفته |
| **P2** | Market Data Plane کامل + Tick store | 2M msg/s در load test، freshness < 250ms، replay تعیّنی | ۸ هفته |
| **P3** | Order Path: gateway → risk → OMS → adapters (یک venue) | p99 < 350µs در colo، سفارش واقعی در paper market | ۱۰ هفته |
| **P4** | Risk Plane کامل ۱۷ چک + kill switch L1–L5 | ۱۰۰% چکها در CI، drill موفق هر سطح | ۵ هفته |
| **P5** | Post-Trade + Ledger + Recon | صفر اختلاف در ۳۰ روز replay پیوسته | ۷ هفته |
| **P6** | Algo Engine + multi-venue SOR | TWAP/VWAP در paper، slippage vs benchmark در آستانه | ۶ هفته |
| **P7** | Compliance + Surveillance + Reporting | همه الزامات §۱۷ تست خودکار دارند | ۵ هفته |
| **P8** | Hardening + Certification + DR drills | همه ردیفهای §۱۹ drill شده، DR تست شده، pen-test تمیز | ۶ هفته |
| **P9** | Shadow trading (بدون سرمایه) ۶۰ روز | divergence صفر vs paper expectation | ۸ هفته |
| **P10** | Go-live محدود (۵% سرمایه) | SLO سبز ۳۰ روز | ۴ هفته |

**نکته حیاتی:** P3 بدون P2 قابل شروع نیست؛ P5 بدون P3 قابل تست نیست. مسیر بحرانی = P2 → P3 → P4 → P5.

---

## بلوپرینت ۲۶ — Frozen Checklist (پیشنیاز شروع کدنویسی)

- [ ] OD-01 تا OD-07 بسته و امضا شده
- [ ] Coverage Matrix کامل: هر سرویس با API + Schema + SLO + Runbook + Test Plan
- [ ] ۳۸ اندپوینت دارای proto/OpenAPI + contract test
- [ ] ۱۱ topic با key، retention، guarantee مصوب
- [ ] ماشین حالت سفارش + ۵ invariant با property test
- [ ] جدول ۱۷ چک ریسک با ترتیب، منبع داده، fail behaviour
- [ ] Schemaهای ۹.۱–۹.۷ در Schema Registry ثبت شده
- [ ] Latency budget §۱۴ تأیید شده توسط Head of Trading Tech
- [ ] ماتریس شکست §۱۹ کامل با متریک و runbook
- [ ] پنج سطح kill switch با احراز هویت و drill plan
- [ ] Compliance Core جدا از محصول، مالکیت CCO، غیرقابل خاموشی
- [ ] الزامات §۱۷ با نگاشت به تست خودکار
- [ ] SLOها و error budget در monitoring پیکربندی شده
- [ ] مدل ظرفیت و بودجه فاز ۱ تأیید شده
- [ ] Team topology + مالکیت هر سرویس مشخص
- [ ] مسیر بحرانی و توالی فازها تأیید شده
- [ ] DR plan با RPO/RTO و drill تقویم
- [ ] طرح تست (۱۰ لایه) و Certification Gate
- [ ] قواعد تغییر hot-path (signed + 4-eye + rollback) مصوب
- [ ] محیطها و جداسازی داده تعریف شده
- [ ] طرح threat model و abuse case بازبینی شده توسط CISO
- [ ] WORM retention policy اجرا و تست شده
- [ ] Connector Registry با الزام certification_status
- [ ] Runbookها نوشته و به incident tooling وصل
- [ ] ADR-001..00N ثبت شده در repo

**قاعده فریز نهایی:** اگر هر آیتم بالا خالی باشد، فاز کدنویسی شروع نمیشود. سند فریزشده اما چکلیست ناقص = تله.

---

## بلوپرینت ۲۷ — ریسکهای پروژه و کاهشدهنده

| ریسک | احتمال | اثر | کاهش |
|---|---|---|---|
| پیچیدگی بیشازحد در v1 | بالا | تأخیر ۶+ ماه | cell فقط برای دو دارایی، بقیه deferred |
| تأخیر در venue certification | متوسط | تأخیر P3 | شروع با یک venue + sim-venue موازی |
| کمبود مهارت lock-free/cola | متوسط | افت p99 | استخدام زودهنگام + طراحی software-first با مسیر ارتقای FPGA |
| نشت اختلاف حسابداری | پایین | توقف معامله | recon intraday T+0 + hash chain |
| انحراف backtest از live | بالا | زیان | latency + queue model در simulator، certification gate |
| عدم انطباق پیشبینینشده | متوسط | جریمه/توقف | Compliance Engineer در تیم از P1 |
| وابستگی به دیتا وندور | متوسط | قطع فید | فید مستقیم + fallback + contract SLA |

---

## بلوپرینت ۲۸ — ضمائم اجباری (تولید در P0)

| # | ضمیمه | مالک | وضعیت |
|---|---|---|---|
| A1 | فهرست کامل ADRها (تصمیم، گزینهها، دلیل، پیامد) | Arch Guild | الزامی |
| A2 | Schema Registry با نسخهبندی و breaking-change policy | Data Guild | الزامی |
| A3 | Contract Test Suite (Pact + proto) | QA | الزامی |
| A4 | Runbook Pack (RB-01..10) | SRE | الزامی |
| A5 | Threat Model + Abuse Case Catalogue | CISO | الزامی |
| A6 | Chart of Accounts (ledger) | CFO office | الزامی |
| A7 | Regulatory Mapping Matrix (§۱۷ با تست) | Compliance | الزامی |
| A8 | Capacity & Cost Model v1 | Platform | الزامی |
| A9 | Certification Report Template | QA + Quant | الزامی |
| A10 | DR Drill Calendar + Success Criteria | SRE | الزامی |
| A11 | Strategy Deployment Checklist (4-eye) | Risk | الزامی |
| A12 | Data Retention & WORM Policy | Compliance + Platform | الزامی |

---

## جمعبندی فریز

معماری سه مسیر مستقل دارد (Market Data، Order، Post-Trade) که فقط از طریق event log با هم حرف میزنند، یک صفحه حکمرانی دارد که هیچوقت در hot-path نیست، و یک Compliance Core دارد که هیچ تیمی نمیتواند خاموشش کند. اعداد p99 قفل شدند، RPO=0 برای سفارش و دفتر قفل شد، ماتریس شکست کامل است، ماشین حالت سفارش تستپذیر است، و مسیر بحرانی پروژه مشخص است.

قدم بعدی: این سند را به ترتیب امضا برسان — CTO، Head of Trading Tech، CISO، CRO، Compliance Officer، SRE Lead — و هفت OD را در همان جلسه ببند. تا وقتی OAها امضا نشدهاند، خط اول کد نوشته نمیشود. سریعترین راه رسیدن به فاز ۱ این است که OD-01 و OD-02 در همان جلسه فریز قطعی بخورند، چون بقیه تصمیمها به آنها آویزاناند.