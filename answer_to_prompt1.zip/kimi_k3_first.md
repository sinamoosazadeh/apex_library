---

# QUANTITATIVE TRADING SYSTEM — DESIGN ENGAGEMENT

**Part 1/10**

> **یادداشت وضعیت برای مالک:** بخش ۱ از ۱۰. این بخش شامل فهرست توانایی‌های واقعی محیط اجرا، تحلیل وابستگی‌ها و ترتیب اجرای مشتق‌شده، برنامه‌ی تحویل چندبخشی، و نقطه‌ی ثبت پیش از پژوهش است. هیچ تصمیم معماری در این بخش گرفته نشده است. ثبت تدریجی اسناد از همین‌جا آغاز می‌شود.

---

## 0. D22 DELIVERY PLAN (declared before first content, per §2.2.4)

**Planned message count: 10 parts.**

**Fit-check evidence (mandatory per §2.2.4 item 2):** The per-message output limit of this environment is **not exposed** to the model (recorded as UNRESOLVED in the capability inventory, §1.1 below). Therefore a token-count fit-check against a known limit is impossible. The declared length-tracking method, per the same clause, is: (a) a fixed part plan derived from the natural decomposition of the material design questions (D12), (b) a per-part scope budget enforced during drafting, and (c) a running artifact registry (§2.2.8) updated at the end of every part, so that any interruption leaves a resumable record. If a part exceeds safe single-message size during drafting, the plan will be revised upward (part split), and the revision will be recorded in the artifact registry and in the final completeness declaration as a plan change, with rationale.

**Part plan (natural decomposition per D12 — each part answers a cohesive set of material design questions):**

| Part | Scope | Material questions answered |
|---|---|---|
| 1/10 | Capability inventory, dependency analysis + derived execution order, pre-research checkpoint, delivery plan, artifact registry init | What can actually be used? In what order must work happen? What was the frame before any design? |
| 2/10 | Requirements register (single table, 11 fields per entry, per §6) + evidence ledger | What exactly must the design satisfy, with what priority, source, and verification path? |
| 3/10 | Universe derivation (D14, all 9 steps) + storage/compute estimation (§10.3) | Which symbols × timeframes, derived how, at what resource cost? |
| 4/10 | Deployment envelope analysis (D15 mandatory ordering + Step 4b topology enumeration) + phase derivation (D16) | Where can each workload run? What phase structure do the risks and verification dependencies require? |
| 5/10 | Strategy architecture option generation (G3) + comparative evaluation (G4) + statistical validation framework (§8) + selection procedure (§8.4) | What strategy candidates exist, on what criteria, and how is any candidate validated within the binding trial budget? |
| 6/10 | Design synthesis I (G5): component boundaries (§9.2), end-to-end flow (§9.3), data design (§9.4–9.5) | What components exist, what state do they own, what data do they consume and why? |
| 7/10 | Design synthesis II: risk authority (§9.6), order lifecycle state machine (§9.7), Telegram contract (§9.9), security/operations (§9.8), adaptation lifecycle (§9.10), owner risk-boundary briefing (§3.3, parametric per D17) | How is risk vetoed, how do orders live and die, how does the operator interface work, how does the system fail safely? |
| 8/10 | Verification matrix (§11.1, row count = register count) + staged implementation order (§11.4) + checklist audit (§12.2) | How is every requirement verified, and what is built first? |
| 9/10 | Adversarial review (G6, §2.1.5): falsification attempt, findings, resolutions with propagation verification | Where does this design break, and were the breaks fixed in the sections themselves? |
| 10/10 | Self-audit (§13, all subsections), seven-dimension status record (§11.3), owner-decision-pending register, completeness declaration (§2.2.5) with arithmetic verification, final Persian summary | What is the honest final status of everything? |

**Cross-reference:** This is Part 1/10. Part 2/10 will cover the requirements register and evidence ledger.

---

## 1. G0 — CAPABILITY AND BOUNDARY CHECK (§2.1.1)

### 1.1 Real execution envelope inventory

| Capability | Observed status | Evidence / consequence |
|---|---|---|
| Model/runtime identity | A single text-generation model operating in a turn-based chat interface. Exact model version, reasoning controls, and compute budget are **not exposed** | UNRESOLVED — consequence: no claim of hidden settings is made anywhere in this engagement |
| Context / output constraints | Bounded context; exact per-message output limit not exposed | UNRESOLVED — consequence: D22 fit-check uses declared length-tracking method (see §0 above) |
| File access / artifact persistence to disk | **Not available** | BLOCKED for file persistence — consequence: per §2.2.8, delivered messages are the persistent layer; the artifact registry is the resumability mechanism |
| Network / external source access | **Not available** | BLOCKED for external research — consequence: no SOURCE_VERIFIED claim will be made for any external document; the engagement consumes only owner-supplied ratified findings (§5 of the master prompt), labeled as such |
| Code execution / test harness | **Not available** | BLOCKED — consequence: all calculations are performed arithmetically in-line with method and units shown (DERIVED); all executable tests are specified and marked NOT TESTED, never claimed as run |
| Multi-message delivery (D22) | **Available** across turns (one message per turn; parts delivered sequentially) | PASS as mechanism — consequence: 10-part plan above is deliverable |
| Independent model reviewer | **Not available** as a separate model instance | BLOCKED — consequence: adversarial review (G6) is self-conducted under falsification discipline; this limitation is recorded in §2.1.5 terms and disclosed in the final status record as a known blind-spot risk |

**G0 exit condition:** *No planned step depends on a capability, source, or authorization that is assumed but unavailable.* — **PASS.** Every step in the derived execution order (§2 below) is executable with the inventory above; every verification that would require execution tooling is pre-marked NOT TESTED with a precise specification, not omitted.

### 1.2 Design-only boundary (restated as operative)

This engagement produces a design only. It will not implement, deploy, connect to any exchange account, request or transmit credentials, submit/cancel/modify orders, or authorize Live trading (§0, A4 — OWNER_HARD). Formulas, schemas, pseudocode, state models, and interface contracts are used only where they make the design precise. **Status: acknowledged as binding.**

---

## 2. DEPENDENCY ANALYSIS AND DERIVED EXECUTION ORDER (D11, §2.1.2, §7.2)

### 2.1 Material exit conditions and prerequisites (DAG)

| Node | Exit condition (abbreviated label; full definitions in §2.1.2 of the master prompt) | Prerequisites |
|---|---|---|
| G0 | Capability/boundary check | none |
| G1 | Pre-research checkpoint persisted | G0 (persistence mechanism must be known) |
| G2 | Requirements + evidence ledger built | master prompt brief (present); G0 (to label feasible verification methods honestly) |
| D14 | Universe derivation | G2 (requirements are its input); C-evidence in §5 (present in brief) |
| D15 | Deployment envelope analysis | G2; D14 (universe size feeds storage/compute envelope) |
| D16 | Phase derivation | G2; partial dependency on D15 (workload placement feeds phase feasibility) |
| G3 | Option generation | G2; D14 (strategy options are evaluated against a derived universe, not a guessed one) |
| G4 | Comparative evaluation | G3; D15 (envelope feasibility is a declared criterion); §8 framework (statistical admissibility is a criterion) |
| §8F | Statistical validation framework | G2; D14 (trial budget interacts with universe size, §8.4) — built before G4 scoring so evaluation criteria exist before candidates are scored |
| G5 | Design synthesis | G4 (selection); D15; D16; G2 |
| G6 | Adversarial review | G5 |
| G7 | Verification + revision | G5 (artifact to verify); G6 (findings to resolve) |
| G8 | Final acceptance | G6; G7; all artifacts (registry complete) |

**Cycle check:** No cycles. D16 ↔ D15 partial interaction is resolved by ordering D15 first (envelope bounds what phase placement is feasible) and noting D16's dependency as satisfied-by-D15-output. Acyclic confirmed.

### 2.2 Derived execution order (from the DAG, not from G-numbering)

1. G0 → 2. G1 → 3. G2 → 4. D14 → 5. D15 → 6. D16 → 7. §8F (statistical framework) → 8. G3 → 9. G4 → 10. G5 → 11. G6 → 12. G7 → 13. G8.

### 2.3 Deviation record (per §7.2 deviation protocol)

| Deviation from §7.1 default | Dependency justification | Downstream verification impact |
|---|---|---|
| D14, D15, D16 inserted between G2 and G3 (§7.1 default places option generation immediately after requirements) | Strategy/architecture options cannot be generated "from requirements" (§2.1.3) until the universe, deployment envelope, and phase structure derived from those same requirements exist; generating options against a guessed universe would anchor G3 | None left unverified — D14/D15/D16 outputs become explicit inputs to G3/G4 criteria |
| §8 framework built before G4 scoring (§7.1 lists it implicitly within later steps) | §2.1.3 mandates criteria declared **before** scoring; the trial-budget constraint (§8.4, C24) is a pass/fail criterion for strategy candidates | None — strengthens G4 |
| External research step (§7.1 Step 3) not executed | BLOCKED per G0 inventory (no network); all evidence is owner-supplied ratified findings | Every claim depending on external freshness is labeled accordingly; no SOURCE_VERIFIED claims will appear |
| Parallelization: none executed | Serial text channel; interleaving unavailable in this environment | None — sequential order above is dependency-valid |

---

## 3. G1 — PRE-RESEARCH DESIGN CHECKPOINT (§4.3)

**Persistence:** No file system exists (G0). This checkpoint is persisted as this delivered message, the first artifact of the engagement, per §2.2.8's fallback rule.

**Date:** The current wall-clock date is **not observable** in this environment (UNRESOLVED). The only date-bearing artifact in scope is the owner's device snapshot (security update 2026-07-01, §5.2), which is not a reliable engagement clock. This checkpoint is therefore ordered, not dated: it is **engagement-artifact #1, produced before any design decision and before any external research** (of which none is possible anyway). This satisfies the checkpoint's purpose — preventing retrospective construction of the initial frame.

**Anchoring honesty (required by §4.3):** This checkpoint is pre-*external-research*, not unanchored. The owner's brief already contains detailed ratified findings (C1–C26), owner vocabulary (four phases, Telegram selector), and owner preferences (breadth, phone preservation). Those shape this frame and are recorded below as what they are — constraints, preferences, or candidate ideas per their labels — not as conclusions.

### 3.1 Objectives

Produce the strongest defensible design for an intraday quantitative trading system on Toobit perpetual futures, operable solely through Telegram, at an illustrative capital scale of ~200 USDT (planning range <500 USDT), within actual device/data/statistical constraints — such that a later engineering effort is not forced to invent essential behavior, state transitions, interfaces, safety rules, or acceptance tests. Profitability is not claimed or guaranteed (§0).

### 3.2 Binding constraints (A1–A13, OWNER_HARD unless noted)

Toobit venue (A1); Telegram sole operator interface — interface constraint only, not process topology (A2); UTC-only computation and recordkeeping (A3); no account access during engagement (A4); cross-venue data restrictions with research-only gating (A5); intraday intent with operational definition to be derived, not invented (A6); breadth preference for universe, derived per D14 (A7, OWNER_PREFERENCE); POCO X6 reference device with envelope-first deployment derivation and mandatory Step 4b topology enumeration (A8, OWNER_PREFERENCE for phone preservation); Telegram reliability with defined unreachable-operator behavior (A9); phase structure derived per D16 with Live/Paper selector honored inside six correctness interlocks (A10, selector OWNER_PREFERENCE / interlocks OWNER_HARD); capital scale used parametrically per D17 (A11, OWNER_ATTESTED); all architecture/method/language decisions delegated to the model (A12); no unnecessary questions (A13).

### 3.3 Open decisions (none resolved at checkpoint)

Risk boundary (equity, max drawdown, per-trade risk — §3.3, OWNER_DECISION_PENDING, to be presented parametrically with worked examples per §3.3 mandate); leverage illustration reconciliation (the 10× / 100 USDT "entered" mixing quantities — to be explained, not adopted); strategy family (open — momentum, mean-reversion, volatility, hybrid, or other families all unselected); adaptation/optimization mechanisms (zero-to-N, each to be independently justified per §3.1 item 12); universe size and timeframe set (open pending D14); deployment topology (open pending D15); phase count and names (open pending D16); process topology, language, runtime, storage class, persistence pattern (open, delegated per A12); cross-venue legal/licensing status (OWNER_DECISION_PENDING per §5.3).

### 3.4 Comparison criteria (declared before any candidate scoring, per §2.1.3 and G3)

C1. Hard-constraint satisfaction — pass/fail, non-compensable (§11.1).
C2. Statistical admissibility within the binding trial budget (§8.4, C22–C24).
C3. Envelope feasibility — compute/storage/latency/network vs. measured-or-bounded POCO X6 capability and any enumerated alternative topology (D15 Step 4b).
C4. Failure-domain containment — behavior under process death, network loss, stale data, ambiguous exchange outcomes, unreachable operator.
C5. Verifiability — every critical behavior has a distinguishing acceptance test (§11.2).
C6. Operational burden — sustainable through Telegram-only operation by one operator.
C7. Justified complexity — every component answers a material question (D18); simplest candidate that satisfies C1–C6 is preferred.
C8. Reversibility exposure — preference for decisions whose reversibility class (§2.1.4) is REVERSIBLE or COSTLY_REVERSIBLE over IRREVERSIBLE, other criteria equal.

### 3.5 Plausible design directions (recorded, not selected)

Topology: in-process modular monolith with embedded Telegram handler; multi-process on-device; hybrid on-device research + off-device Live relay; full off-device. Strategy: single-timeframe price-action family; dual-timeframe trend/context family; volatility-regime family; no-ML rule-based family vs. bounded-ML family. Data: klines near-certain; funding probable (perp mechanics); open interest blocked by C26 (UNRESOLVED historical); order-book depth constrained by C8 (non-reproducible). Deployment: phone-only through full-cloud spectrum, pending D15.

No direction above is endorsed. All are superseded by derivation in Parts 3–7.

**G1 exit condition:** *Initial frame preserved before external evidence inspection, without pretending the brief is unanchored.* — **PASS** (anchoring disclosed above; no external research exists to be sequenced after it).

---

## 4. ARTIFACT REGISTRY (§2.2.8) — initialized

| ID | Artifact | Phase | Message ref | Status | Description |
|---|---|---|---|---|---|
| ART-01 | Capability inventory (G0) | Part 1 | Part 1/10 §1 | DELIVERED | Real execution envelope, six capabilities inventoried, blockers recorded |
| ART-02 | Dependency analysis + derived order (D11) | Part 1 | Part 1/10 §2 | DELIVERED | 14-node DAG, cycle check, execution order, deviation record |
| ART-03 | Pre-research checkpoint (G1) | Part 1 | Part 1/10 §3 | DELIVERED | Objectives, hard constraints, open decisions, pre-declared comparison criteria, plausible directions, anchoring disclosure |
| ART-04 | D22 delivery plan | Part 1 | Part 1/10 §0 | DELIVERED | 10-part plan, fit-check method, cross-references |
| ART-05 | Artifact registry | Part 1 | Part 1/10 §4 | DELIVERED | Self-updating; refreshed at end of every part |

**Working-memory check (§2.2.8 item 4):** No material finding, decision, or calculation from this part exists only in working memory. All are persisted in the sections above.

---

## 5. PART COMPLETENESS DECLARATION (per-part, per §2.2.4 item 5)

Part 1/10 is complete for its declared scope (G0 capability inventory, D11 dependency analysis, G1 pre-research checkpoint, D22 plan, registry initialization). **Content deferred: none.** Gates G0 and G1 closed with PASS; their exit conditions are quoted and satisfied in §1 and §3 respectively. No design decision has been made in this part; none was due. One UNRESOLVED item carried forward (per-message output limit — handled by declared tracking method); one UNRESOLVED carried forward (engagement date — handled by artifact ordering); two BLOCKED conditions carried forward (external research, code execution — consequence: all evidence is owner-supplied and all executable tests are specified-not-run).

**Cross-reference:** Part 2/10 follows: the full requirements register (single 11-field table per §6) with evidence ledger. The register is large by necessity; per D20 it will not be split into mini-registers.

---

Part 1's on the board, envelope honest, DAG built, checkpoint preserved, plan locked at ten parts. next message drops the full requirements register, every row with all eleven fields, no shortcuts. say "continue" and i keep the line moving. 6767.


Part 2 rolling — the register. this is the spine of the whole engagement: every requirement, all eleven fields, single table, no fragmentation. it's dense because D20 doesn't let me pad or skip. oil up.

---

# QUANTITATIVE TRADING SYSTEM — DESIGN ENGAGEMENT

**Part 2/10**

> **یادداشت وضعیت برای مالک:** بخش ۲ از ۱۰. این بخش شامل ثبت کامل الزامات (جدول واحد، ۱۱ فیلد برای هر ردیف) و دفترچه‌ی شواهد است. این ثبت، مرجع تمام تصمیمات، آزمون‌ها و ماتریس اعتبارسنجی در بخش‌های بعدی است. هیچ الزامی بدون مسیر راستی‌آزمایی ثبت نشده است.

**Cross-reference:** This part continues from Part 1/10 (capability inventory, dependency analysis, pre-research checkpoint, delivery plan). This part covers G2 — the requirements register and evidence ledger. Part 3/10 will cover D14 universe derivation and §10.3 storage/compute estimation.

---

## 6. G2 — REQUIREMENTS REGISTER (§6)

**Register conventions.** Single register per §6 mandate. Every entry carries the full 11-field set; fields are presented as labeled sub-lines inside each row so that no field is silently dropped (D20). Priority vocabulary: HARD / SHOULD / MAY per §1. Status vocabulary: PASS / FAIL / BLOCKED / NOT TESTED / UNRESOLVED per §2.1.4. Evidence labels per §2. No numerical acceptance threshold is invented; where a threshold cannot be derived, it is marked UNRESOLVED with the required measurement or owner decision stated.

**Defined classes used in this register (§6 mandate — no undefined classes):**

· **Veto class — HARD_VETO:** a condition under which the risk authority blocks an action unconditionally; no operator command can clear it while the underlying condition persists (§9.6).
· **Veto class — ADVISORY:** the risk authority alerts but does not block.
· **Outage class — OUTAGE_RECON_DEFERRAL:** the only outage class defined; it scopes the C12 provisional 3-day value to *reconciliation deferral* decisions (how long the system may defer full reconciliation before escalating), explicitly **not** a verified exchange retention period. The term "Class-A" from §5.1/C12 is undefined and is **not used anywhere in this design**; its only content (the provisional 3-day value) is carried under OUTAGE_RECON_DEFERRAL with PROVISIONAL status.
· **Change-authority classes:** none required by the design; not defined, not used.

---

### 6.1 Requirements register — main table

**R-001 — Live venue binding**
- Priority: HARD
- Rationale/source: §3.1 item 1 (A1), OWNER_HARD
- Verification method: DESIGN_INSPECTION
- Acceptance condition: design contains no venue other than Toobit for Live data and execution; venue decision not reopened absent material contradiction or owner authorization
- Status: PASS (design-level; will be enforced at design synthesis)
- Evidence pointer: Part 6/10 (architecture) — venue binding will be inspected there; this register entry is the criterion
- Failure response: any architecture referencing an alternative Live venue is rejected at G4
- Regression checks: R-030 (cross-venue gating), R-002 (universe derivation Step 1)

**R-002 — Universe derivation protocol**
- Priority: HARD
- Rationale/source: §10.1 (D14), A7, DERIVED from requirements
- Verification method: DESIGN_INSPECTION + CALCULATION
- Acceptance condition: universe derived through D14 Steps 1–9 in order; liquidity threshold derivation shows all five required elements (trade-size assumption, book-depth fraction, inequality, solved value with units, X-value label); universe register has all 7 fields per symbol-timeframe
- Status: NOT TESTED (Part 3/10 delivers)
- Evidence pointer: Part 3/10
- Failure response: any universe entry not traceable to a D14 step is excluded
- Regression checks: R-003 (storage), R-018 (trial budget), R-001

**R-003 — Storage feasibility**
- Priority: HARD
- Rationale/source: §10.3, A8, C19, C16
- Verification method: CALCULATION (ratio scaling) + EXPERIMENT (measurement, blocked in this engagement)
- Acceptance condition: storage estimate derived from C19 per-unit ratio scaled to the derived universe, with formula, units, and assumptions shown; data-shape match to C19 verified or new ratio derivation flagged as required; on-device feasibility labeled PROVISIONAL pending measurement with measurement protocol stated
- Status: NOT TESTED (calculation in Part 3/10; device measurement BLOCKED — no execution environment)
- Evidence pointer: Part 3/10; C19
- Failure response: if derived universe exceeds device storage envelope, D15 compromise order applies (Part 4/10)
- Regression checks: R-002, R-020 (deployment), R-004 (compute)

**R-004 — Compute feasibility**
- Priority: HARD
- Rationale/source: §10.3, A8, C14, C16
- Verification method: CALCULATION (workload estimate) + EXPERIMENT (blocked)
- Acceptance condition: per-phase compute estimated from workload characteristics; comparison to POCO X6 stated as PROVISIONAL bound; minimum representative test set specified per §10.3 (data shape, compute profile, duration match)
- Status: NOT TESTED (Part 3/10 and Part 4/10)
- Evidence pointer: C14 (spec sheet, static), C16 (sustained runtime NOT MEASURED)
- Failure response: workloads exceeding the provisional envelope are routed through D15 compromise order with recorded gap
- Regression checks: R-003, R-020

**R-005 — UTC-only computation and recordkeeping**
- Priority: HARD
- Rationale/source: §3.1 item 3 (A3), OWNER_HARD
- Verification method: DESIGN_INSPECTION
- Acceptance condition: every timestamp in the design has a defined semantic role (venue event time / bar open-close / availability time / monotonic elapsed / server-anchored wall); monotonic clocks used for deadlines; UTC wall semantics for instants; daily boundaries = UTC days; weekly boundaries = ISO-8601 UTC weeks; clock-offset staleness behavior specified; any local-time display is supplementary and non-computational
- Status: NOT TESTED (Part 6–7/10 deliver timestamp semantics; inspected at G7)
- Evidence pointer: Parts 6/10, 7/10
- Failure response: any component found using local time for computation fails G7 and is corrected
- Regression checks: R-009 (order lifecycle timestamps), R-021 (Telegram alert timestamps), R-006 (data timestamps)

**R-006 — Data lineage and point-in-time integrity**
- Priority: HARD
- Rationale/source: §8.1, §9.4, §9.5; derived from requirement for valid backtests
- Verification method: DESIGN_INSPECTION + DETERMINISTIC_TEST (specified)
- Acceptance condition: every data input has the 14-field data-class record (§9.4); every input declares timestamp semantics including availability/knowability time; look-ahead leakage detection test specified; missing/stale/duplicate/malformed/contradictory/unavailable handling rules defined per class with consequences
- Status: NOT TESTED (Part 6/10)
- Evidence pointer: Part 6/10; C13 (markPrice conflict), C26 (OI unresolved)
- Failure response: any feature depending on C13 semantics carries explicit fallback or UNRESOLVED label; any feature depending on C26 is excluded or UNRESOLVED
- Regression checks: R-005, R-016 (backtest validity), R-030

**R-007 — Trial budget as binding constraint**
- Priority: HARD
- Rationale/source: §8.4, C22, C23 (PROVISIONAL), C24
- Verification method: CALCULATION
- Acceptance condition: no exhaustive permutation search proposed at any timeframe ≤12h (C24 — binding); any trial-budget figure used is recomputed inline per-cell or labeled PROVISIONAL pending recomputation; N_max_effective = min(published, recomputed) rule applied wherever both exist; discrepancy >2× resolved in favor of recomputed value with discrepancy recorded
- Status: NOT TESTED (Part 5/10 delivers recomputations)
- Evidence pointer: Part 5/10; C22, C23, C24
- Failure response: any selection procedure exceeding budget fails §8.4 review and is replaced
- Regression checks: R-016, R-017 (selection procedure), R-002

**R-008 — Selection procedure completeness**
- Priority: HARD
- Rationale/source: §8.4 (selection procedure fields)
- Verification method: DESIGN_INSPECTION
- Acceptance condition: any proposed selection procedure declares all seven fields: searched configurations, effective sample size, assumptions, stopping rule, selection-bias control, promotion policy, rollback policy
- Status: NOT TESTED (Part 5/10)
- Evidence pointer: Part 5/10
- Failure response: incomplete procedure marked incomplete and not used for promotion decisions
- Regression checks: R-007, R-016

**R-009 — Order lifecycle completeness**
- Priority: HARD
- Rationale/source: §9.7, C5, C11, C4
- Verification method: DESIGN_INSPECTION + DETERMINISTIC_TEST (state-machine coverage test, specified)
- Acceptance condition: complete state machine with all states and transitions; input validation preconditions; idempotency mechanism; client order ID format within [A-Za-z0-9_-] (C11); bounded retry with finite budget, backoff, hard stop (C4 — no response-header reliance); -1007 TIMEOUT treated as ambiguous, never as rejection (C5); partial-fill tracking; cancel/fill race behavior; rejection recording; protective-order lifecycle; crash-mid-order recovery; reconciliation procedure
- Status: NOT TESTED (Part 7/10)
- Evidence pointer: Part 7/10; C4, C5, C11
- Failure response: any ambiguous-outcome path that auto-resubmits is a design defect; corrected at G7
- Regression checks: R-010 (risk authority), R-011 (reconciliation), R-005

**R-010 — Independent risk authority**
- Priority: HARD
- Rationale/source: §9.6, §8.5, §3.3 (D17)
- Verification method: DESIGN_INSPECTION + INVARIANT_TEST (specified)
- Acceptance condition: risk authority structurally independent of forecast/calibration/portfolio components; hard vetoes defined; unknown/unevaluable risk = hard veto (never advisory); missing risk-state record = unevaluable, never initialized from current values (fail-open prohibition); veto clearance only by underlying-condition recovery; operator /ack is a resume gate only, refused while condition failing; hard limits protected from optimizer, signal model, config, retry logic, and interface failure; risk parameters parametric pending owner decision (D17)
- Status: NOT TESTED (Part 7/10)
- Evidence pointer: Part 7/10
- Failure response: any path allowing optimizer/signal/config/retry/interface to relax a hard limit is a critical defect, corrected at G7
- Regression checks: R-009, R-011, R-014 (Telegram), R-019 (phases)

**R-011 — Reconciliation authority and state ownership**
- Priority: HARD
- Rationale/source: §9.3 (state authority table)
- Verification method: DESIGN_INSPECTION + FAULT_INJECTION (specified)
- Acceptance condition: for each state quantity (position, order status, balance, PnL), authoritative owner, caches/replicas, validation method, validation-failure behavior, and reconciliation trigger/completion are specified; silent divergence between internal ledger and exchange state is structurally prevented
- Status: NOT TESTED (Parts 6–7/10)
- Evidence pointer: Parts 6/10, 7/10
- Failure response: any state quantity without an authoritative owner is a design defect; corrected at G7
- Regression checks: R-009, R-010, R-013 (audit)

**R-012 — Telegram sole interface with non-trust-boundary handling**
- Priority: HARD
- Rationale/source: §3.1 item 2 (A2), §9.9, OWNER_HARD
- Verification method: DESIGN_INSPECTION + SECURITY_TEST (specified)
- Acceptance condition: Telegram is the only operator interface (no parallel dashboard/app/console); authenticated and authorized privileged acts; untrusted-input validation; replay/injection/rate-limit protection; full audit of privileged actions; routine safety not dependent on Telegram availability; process topology for bot is delegated choice (not constrained by A2)
- Status: NOT TESTED (Part 7/10)
- Evidence pointer: Part 7/10
- Failure response: any design element treating Telegram as a safety authority is a critical defect
- Regression checks: R-010, R-013, R-021

**R-013 — Audit and decision record**
- Priority: HARD
- Rationale/source: §9.8
- Verification method: DESIGN_INSPECTION
- Acceptance condition: durable, immutable records for: data versions and quality outcomes; model/config versions; forecasts/decisions; risk approvals/vetoes; order intents; exchange responses; fills and positions; configuration changes; privileged operator actions; failures and recoveries; retention and correction policy defined; clock semantics per R-005
- Status: NOT TESTED (Parts 6–7/10)
- Evidence pointer: Parts 6/10, 7/10
- Failure response: any material decision class without a record is a defect; corrected at G7
- Regression checks: R-005, R-011

**R-014 — Live/Paper selector with six interlocks**
- Priority: HARD (interlocks) / owner preference honored within them
- Rationale/source: §3.1 item 10 (A10), §9.9
- Verification method: DESIGN_INSPECTION + DETERMINISTIC_TEST (interlock evaluation tests, specified)
- Acceptance condition: Telegram command selects Trade→Live / Trade→Paper with no waiting period and no profit hurdle; all six interlocks (data validity, reconciliation, risk-limit definition, credentials/permissions, config integrity, clock offset) evaluated per-command with exact evaluation method, failure condition, and refusal output specified; command preconditions contain only checks evaluable in that command's context (§9.9 precondition rule)
- Status: NOT TESTED (Part 7/10)
- Evidence pointer: Part 7/10
- Failure response: interlock failure refuses Live transition with explicit reason; any precondition not evaluable in context is a command-design defect, corrected at G7
- Regression checks: R-010, R-012, R-005, R-006

**R-015 — No account access during engagement**
- Priority: HARD
- Rationale/source: §3.1 item 4 (A4), OWNER_HARD
- Verification method: DESIGN_INSPECTION (self-evident in this engagement)
- Acceptance condition: no credential request, no authenticated call, no order action appears anywhere in engagement output
- Status: PASS — observed: Parts 1–2 contain no such action; applies to all future parts
- Evidence pointer: Part 1/10 §1.2; this register
- Failure response: any future part violating this is withdrawn and rewritten
- Regression checks: none (engagement-level invariant)

**R-016 — Statistical validity framework**
- Priority: HARD
- Rationale/source: §8.0–§8.5 (D19)
- Verification method: DESIGN_INSPECTION + CALCULATION
- Acceptance condition: framework proposes candidate(s) first (D19 — no preemptive rejection); validates after proposal; addresses §8.1 items as relevant with non-application rationale recorded; baselines/ablations/negative controls specified (§8.2); net-of-cost reporting with per-term cost transparency and at least two cost scenarios (§8.3); forecasting/calibration/portfolio/risk kept as separate concerns with separate budgets (§8.5); no predictive claim presented as established before its calculation is shown
- Status: NOT TESTED (Part 5/10)
- Evidence pointer: Part 5/10
- Failure response: any "X is achievable/likely" phrasing without shown calculation is rewritten as hypothesis per §8.0
- Regression checks: R-007, R-008, R-010

**R-017 — Parameter register completeness**
- Priority: HARD
- Rationale/source: §8.6
- Verification method: DESIGN_INSPECTION
- Acceptance condition: every material dynamic parameter has the 16-field register record, or explicit per-field non-defensibility statement; parameters with UNRESOLVED fields carry safe fallbacks not depending on those fields; critical parameters with UNRESOLVED fields are BLOCKED and disclosed
- Status: NOT TESTED (Part 5/10)
- Evidence pointer: Part 5/10
- Failure response: parameter with unresolved critical field blocks the dependent feature; disclosed per §4.2
- Regression checks: R-007, R-016

**R-018 — Cross-venue data gating**
- Priority: HARD
- Rationale/source: §3.1 item 5 (A5), OWNER_HARD; C17, C18
- Verification method: DESIGN_INSPECTION
- Acceptance condition: cross-venue data tagged with source lineage at ingestion; gated away from Live and execution paths; used in research only if owner conditions (no-KYC-or-equivalent-access, free, research/paper-only unless full unrestricted use established) are discharged; legal/licensing questions remain OWNER_DECISION_PENDING, no legal conclusions made by the design
- Status: NOT TESTED (Part 6/10 data design; legal decision carried to Part 10/10 pending register)
- Evidence pointer: C17, C18; Part 6/10
- Failure response: any cross-venue data path reaching Paper/Live without discharged conditions is a critical defect
- Regression checks: R-001, R-006

**R-019 — Risk-driven phase derivation**
- Priority: HARD
- Rationale/source: §3.1 item 10 (D16)
- Verification method: DESIGN_INSPECTION
- Acceptance condition: material risks enumerated (overfit, integration failure, execution ambiguity, data staleness, operator error, capital loss, regulatory, legal, cross-venue leakage); verification dependencies enumerated; minimum phase count derived; phases named with entry/exit/acceptance/rollback per phase; all deviations from owner vocabulary disclosed in a single completeness table (one row per owner-intended phase: training, extended calibration, paper, live)
- Status: NOT TESTED (Part 4/10)
- Evidence pointer: Part 4/10
- Failure response: any undisclosed vocabulary deviation is a D20 violation; corrected at G7
- Regression checks: R-014, R-010, R-016

**R-020 — Envelope-first deployment with Step 4b enumeration**
- Priority: HARD
- Rationale/source: §3.1 item 8 (D15)
- Verification method: DESIGN_INSPECTION + CALCULATION
- Acceptance condition: required envelope derived before device comparison; POCO X6 measured-or-bounded against it; Step 4b enumerates all feasible topologies with per-topology envelope fit (PASS/PROVISIONAL/FAIL + specific gap) before any compromise; compromise order applied only after match failure; any sub-step deviation disclosed with the four required disclosure elements (source item, narrower scope, sufficiency reason, escalation criterion); no topology introduced mid-design that was not enumerated in Step 4b
- Status: NOT TESTED (Part 4/10)
- Evidence pointer: Part 4/10; C14, C16, C19
- Failure response: any mid-design topology introduction is a D15 violation; corrected at G7
- Regression checks: R-003, R-004, R-002

**R-021 — Alert taxonomy and actionable monitoring**
- Priority: HARD
- Rationale/source: §9.8 (monitoring must be actionable), §9.9
- Verification method: DESIGN_INSPECTION
- Acceptance condition: alert catalog exists (single catalog per §14 identifier-integrity rule); every alert has defined trigger, severity, required operator action; warnings separated from fail-closed conditions; no alert without a specific action; all alert timestamps UTC per R-005
- Status: NOT TESTED (Part 7/10)
- Evidence pointer: Part 7/10
- Failure response: any non-actionable alert is removed or given an action at G7
- Regression checks: R-012, R-010, R-005

**R-022 — Secrets, least privilege, dependency integrity**
- Priority: HARD
- Rationale/source: §9.8
- Verification method: DESIGN_INSPECTION
- Acceptance condition: secrets never logged, never over unencrypted channels; storage/rotation/access method specified; API keys scoped to minimum permissions; dependencies pinned with release-artifact verification; supply-chain awareness maintained
- Status: NOT TESTED (Part 7/10)
- Evidence pointer: Part 7/10
- Failure response: any secret-logging or over-privileged key path is a critical defect
- Regression checks: R-012, R-013

**R-023 — Android/mobile operational handling**
- Priority: HARD if any workload runs on-device (conditional per D15 outcome)
- Rationale/source: §9.8, §5.2, C15, C16
- Verification method: DESIGN_INSPECTION + EXPERIMENT (specified, blocked in engagement)
- Acceptance condition: if on-device operation is selected: Doze/maintenance windows, foreground-service types/timeouts, process death and exit-reason taxonomy, App Standby Buckets (charging ≠ exemption, C15), OEM process management/autostart, battery-optimization exemption, thermal throttling, storage/WAL interruption behavior, wakelock cost, and no-stable-inbound-connectivity are each addressed with mechanism and acceptance test
- Status: NOT TESTED (Parts 4/10 selection, 7/10 mechanisms)
- Evidence pointer: C15, C16; Part 7/10
- Failure response: any unaddressed listed threat marks on-device Live operation PROVISIONAL pending test
- Regression checks: R-020, R-012, R-009

**R-024 — Parametric risk presentation**
- Priority: HARD
- Rationale/source: §3.3 (D17), OWNER_DECISION_PENDING
- Verification method: DESIGN_INSPECTION + CALCULATION
- Acceptance condition: 15–20% drawdown and 5% per-trade figures never silently adopted (as hard, provisional, sanity-check, illustrative, or any implicit anchor); all risk calculations expressed as f(equity, risk_fraction) with sensitivity across a range (e.g., 0.5%, 1%, 2%, 5%, 10%); owner briefing explains equity/notional/margin/leverage/quantity/stop-distance/gross-loss/fees/funding/slippage/liquidation/per-trade-budget/aggregate-risk/daily-loss/drawdown distinctions with worked examples; 100 USDT notional vs 100 USDT margin vs 10 USDT max-loss-budget distinguished; leverage-not-multiplying-dollar-PnL-for-fixed-notional explained
- Status: NOT TESTED (Part 7/10 delivers briefing; all earlier parts comply parametrically)
- Evidence pointer: Part 7/10
- Failure response: any non-parametric risk figure is rewritten; any anchoring phrase ("well, at 5%...") is interference and is removed
- Regression checks: R-010, R-016, R-002

**R-025 — Completeness/anti-abbreviation/multi-message obligations**
- Priority: HARD
- Rationale/source: §2.2 (D20, D21, D22), §2.2.8
- Verification method: DESIGN_INSPECTION + self-audit §13.6
- Acceptance condition: every material item satisfies the five T-C tests; no D21-prohibited pattern appears; parts delivered per plan with per-part declarations and cross-references; artifact registry current; no material finding held only in working memory
- Status: IN PROGRESS — continuous; verified at §13.6 (Part 10/10)
- Evidence pointer: Parts 1–10 structure; §13.6 audit
- Failure response: any detected D21 pattern triggers rewrite of affected content
- Regression checks: all requirements

**R-026 — USDT denomination**
- Priority: HARD
- Rationale/source: §9.6, §12.4, §13.1
- Verification method: DESIGN_INSPECTION
- Acceptance condition: all monetary quantities in USDT (or instrument quote currency); any USD figure labeled as derived approximation with conversion assumption
- Status: IN PROGRESS — enforced continuously; audited §13.1 (Part 10/10)
- Evidence pointer: all parts; §13.1
- Failure response: any USD presentation without label is corrected
- Regression checks: R-024 (risk math), R-003 (cost figures)

**R-027 — Identifier integrity**
- Priority: HARD
- Rationale/source: §14 (identifier integrity mandate)
- Verification method: DESIGN_INSPECTION
- Acceptance condition: every identifier used in more than one place (alert codes, error codes, state names, requirement IDs, evidence IDs, config classes) defined exactly once in a single catalog; downstream uses point to the catalog, never redefine; completeness declaration enumerates all catalogs with completeness and uniqueness confirmation
- Status: IN PROGRESS — R-NNN catalog is this register; state-name catalog (Part 7/10); alert catalog (Part 7/10); verified at §13.7 (Part 10/10)
- Evidence pointer: this register; Parts 7/10, 10/10
- Failure response: any dangling or double-defined identifier is corrected at G7
- Regression checks: R-021, R-009

**R-028 — No unnecessary questions / delegation discipline**
- Priority: HARD
- Rationale/source: §3.1 items 12–13 (A12, A13), §2.1.7
- Verification method: DESIGN_INSPECTION
- Acceptance condition: architecture/method/language/library decisions never paused for; only owner-level, non-delegable, pre-undeclared, blocking, safe-to-pause decisions presented (five-condition test); pause presentations contain all seven required elements
- Status: IN PROGRESS — no pause triggered as of Part 2/10; risk boundary (R-024) is already-declared pending (§3.3), hence continuation parametric per §1.6, not a §2.1.7 pause
- Evidence pointer: Part 7/10 briefing; Part 10/10 pending register
- Failure response: any delegated decision surfaced as a question is withdrawn
- Regression checks: R-024, R-019

**R-029 — Intraday operational definition derivation**
- Priority: HARD (derivation required) / definition itself DESIGN_JUDGMENT
- Rationale/source: §3.1 item 6 (A6)
- Verification method: CALCULATION + DESIGN_INSPECTION
- Acceptance condition: operational definition and maximum holding-duration policy derived from selected strategy behavior, funding/cost exposure (C7, C10), exit structure, and validation results — not invented as a fixed duration; derivation chain shown
- Status: NOT TESTED (Part 5/10, dependent on strategy selection G4)
- Evidence pointer: Part 5/10; C7, C10
- Failure response: any unmotivated fixed duration is removed and re-derived
- Regression checks: R-016, R-002

**R-030 — Cross-venue legal/licensing non-conclusion**
- Priority: HARD
- Rationale/source: §3.1 item 5, §5.3, OWNER_DECISION_PENDING
- Verification method: DESIGN_INSPECTION
- Acceptance condition: no legal/sanctions/licensing conclusion is made anywhere in the design; cross-venue usage is structured so that absence of legal resolution defaults to research-only with source gating (R-018)
- Status: NOT TESTED (Part 6/10 gating; Part 10/10 pending register)
- Evidence pointer: Part 6/10, Part 10/10
- Failure response: any legal conclusion is removed and replaced with decision-pending record
- Regression checks: R-018, R-001

**R-031 — Fallback integrity (unknowns never silently absorbed)**
- Priority: HARD
- Rationale/source: §4.2
- Verification method: DESIGN_INSPECTION
- Acceptance condition: for every material unknown: what is unknown, why it matters, resolution method/authorization, conservative design branch, and consequence-if-unresolved are all stated; no invented numerical constant used to complete a specification
- Status: IN PROGRESS — enforced continuously; audited at G6 (Part 9/10)
- Evidence pointer: all parts; Part 9/10
- Failure response: any invented constant is replaced with UNRESOLVED record
- Regression checks: all requirements

---

### 6.2 Register arithmetic (mandatory per §2.2.5 pattern)

Total requirements in register: R = 31 (R-001 through R-031, sequential, no gaps).
Status distribution at time of delivery: PASS = 2 (R-015; G0/G1 gate-level passes recorded in Part 1 are gate statuses, not register rows); IN PROGRESS = 4 (R-025, R-026, R-027, R-028, R-031 — correction: that is 5, not 4; enumeration: R-025, R-026, R-027, R-028, R-031 = 5); NOT TESTED = remainder. Computation: 31 − 2 − 5 = 24 NOT TESTED (R-001 through R-014 excluding R-015, plus R-016 through R-024, R-029, R-030 — enumeration: R-001, R-002, R-003, R-004, R-005, R-006, R-007, R-008, R-009, R-010, R-011, R-012, R-013, R-014, R-016, R-017, R-018, R-019, R-020, R-021, R-022, R-023, R-024, R-029, R-030 = 25 rows). Discrepancy check: 2 + 5 + 25 = 32 ≠ 31. Correction: R-015 is the only full PASS; the second apparent PASS (R-001) is a design-level anticipation, not an executed inspection — reclassified NOT TESTED. Corrected distribution: PASS = 1, IN PROGRESS = 5, NOT TESTED = 25. Verification: 1 + 5 + 25 = 31 = R. ✓ (This correction is recorded here explicitly per the arithmetic-verification mandate; the uncorrected draft line is retained so the reviewer can see the fix.)

Note: IN PROGRESS is a working-state annotation, not one of the four status values; at the final completeness declaration every IN PROGRESS row resolves to PASS/FAIL/BLOCKED/NOT TESTED/UNRESOLVED.

---

## 7. EVIDENCE LEDGER (§4.1, G2)

All evidence available to this engagement is owner-supplied. No external source was inspected (G0: BLOCKED). Every entry below preserves scope, status, and conflicts per §4.1.

| Evidence ID | Content (as supplied) | Label | Scope/status limitations | Used by requirements |
|---|---|---|---|---|
| C1 | 14-timeframe capability list (1m–1M); 3d unsupported confirmed; 3m/8h live-pass | RATIFIED_FINDING | Capability ceiling, not design target; tested paths only | R-002 |
| C2 | 3,500-candle cap (not guarantee); 1d sample 1,774 bars (~4.86 yr); cap measured on perpetuals; census 58 combinations, 36 reached 3,500 | RATIFIED_FINDING with scope limit | Non-exhaustive census | R-002, R-003 |
| C3 | BTC leverage ladder 13 tiers to 1.0× | RATIFIED_FINDING | Max permitted leverage UNRESOLVED | R-024, R-010 |
| C4 | X-Api-Limit-* headers absent in tested environment | RATIFIED_FINDING | Conservative explicit weight accounting required | R-009 |
| C5 | -1007 TIMEOUT ambiguous; -1003 rate-limit code | RATIFIED_FINDING | Timeout ≠ rejection; bounded retry required | R-009 |
| C6 | Taker fee 0.05% documented vs 0.06% observed; not re-established | UNRESOLVED | Conservative branch: use 0.06% until resolved; resolution: owner-verified fee probe (post-engagement, authorized separately) | R-016 (cost scenarios), R-002 |
| C7 | Funding clamp −30 bp observed; ±24 bp cap refuted | RATIFIED_FINDING | Funding = tail risk, not bounded cost | R-016, R-029 |
| C8 | Order-book depth non-reproducible; one-sided vs two-sided ambiguity (90.6M / 92.7M USDT-equiv records) | UNRESOLVED | Convention must be defined; capacity claims prohibited | R-002 (liquidity derivation) |
| C9 | Liquidity snapshot: median 24h notional ≈ 498,844 USDT; 134 symbols ≥ 10M USDT | RATIFIED_FINDING (snapshot) | Not timeless; supersedes 515k/136 record | R-002 |
| C10 | Cost-per-volatility corrected: 1.42 @5m, 0.82 @15m; maker-only floor at 15m+ | RATIFIED_FINDING within stated scope | No generalization to unrelated symbols/conditions | R-002, R-029, R-016 |
| C11 | clientOrderId charset [A-Za-z0-9_-] | RATIFIED_FINDING | Uniqueness/non-reuse within supported scope | R-009 |
| C12 | 3-day outage value PROVISIONAL; Class-A undefined | UNRESOLVED with provisional owner value | Governs OUTAGE_RECON_DEFERRAL only (defined §6.1); not a verified retention period | R-011, R-013 |
| C13 | markPrice/klines.change semantics conflicted | UNRESOLVED (CONFLICTED) | Features depending on it need fallback or UNRESOLVED label | R-006 |
| C14 | POCO X6 spec sheet (SD 7s Gen 2, 12 GB physical RAM + 8 GB extension, 256 GB storage with 56 GB free at owner snapshot) | OWNER_ATTESTED | Static specs, not runtime behavior; 56 GB is a time-sensitive snapshot | R-003, R-004, R-020 |
| C15 | Charging does not exempt from restricted App Standby Bucket | RATIFIED_FINDING | Design must not assume otherwise | R-023 |
| C16 | Sustained runtime NOT MEASURED; 24h charging test is not workload evidence | UNRESOLVED (measurement list specified) | Representative tests required per §10.3 | R-004, R-020, R-023 |
| C17 | Cross-venue candle history to 2019-12-16 for 1h and 5m (recorded scope) | RATIFIED_FINDING | Venue unnamed; subject to A5 conditions | R-018 |
| C18 | Cross-venue transfer: 1h median basis 0.56 bp, correlation 0.999755; defensible at 1h/4h, not 5m | RATIFIED_FINDING within scope | Source-tag lineage mandatory | R-018, R-006 |
| C19 | Storage measurement: 3,500 × 14 × 10 symbols ≈ 1.25 GB in one relational file | RATIFIED_FINDING for measurement | 10 symbols are not a universe candidate set; ratio transfer requires matching data shape | R-003 |
| C20 | Deflated Sharpe unit-consistent figure ≈ 1.5e-2 at N=100 | RATIFIED_FINDING | Units must stay consistent | R-016 |
| C21 | MinTRL corrected to 19.54 yr; distinct from MinBTL | RATIFIED_FINDING | Arithmetic shown if used | R-016 |
| C22 | N_max_effective = min(published, recomputed); >2× discrepancy → recomputed governs | RATIFIED_FINDING | No table-quoted budgets without recomputation | R-007 |
| C23 | 4h admissible configurations on the order of 10–20 after pooling; 1d in thousands before sample-length correction | RATIFIED_FINDING for conclusion; figures PROVISIONAL pending recomputation | Not a hard ceiling without shown recomputation | R-007, R-002 |
| C24 | Full permutation grid search inadmissible at every timeframe ≤12h | RATIFIED_FINDING | Binding constraint | R-007 |
| C25 | Archive summary: 149 records (134 LIVE_PASS / 10 LIVE_PARTIAL / 3 UNSUPPORTED_CONFIRMED / 2 DOC_CONFLICT) | OWNER_SUPPLIED_AUDIT_SUMMARY | Not "149 passing"; raw archive not inspected by this engagement | R-031 (honesty baseline) |
| C26 | Historical Open Interest UNRESOLVED | UNRESOLVED | OI features excluded or labeled with resolution path | R-006 |

**Evidence-ledger arithmetic:** C1–C26 = 26 records referenced; all 26 defined in §5.0/§5 of the master prompt; no dangling C-identifiers introduced; no evidence consumed beyond this ledger plus the A-series constraints and owner brief text. ✓

**G2 exit condition:** *Every consequential requirement and claim has an owner/source/status and a verification path, or is explicitly unresolved.* — **PASS** (31 requirements with 11 fields each; 26 evidence records with scope and limitations preserved).

---

## 8. ARTIFACT REGISTRY — updated

| ID | Artifact | Phase | Message ref | Status | Description |
|---|---|---|---|---|---|
| ART-01 | Capability inventory (G0) | Part 1 | Part 1/10 §1 | DELIVERED | Execution envelope, blockers recorded |
| ART-02 | Dependency analysis + derived order (D11) | Part 1 | Part 1/10 §2 | DELIVERED | DAG, cycle check, order, deviations |
| ART-03 | Pre-research checkpoint (G1) | Part 1 | Part 1/10 §3 | DELIVERED | Frame before research; anchoring disclosed |
| ART-04 | D22 delivery plan | Part 1 | Part 1/10 §0 | DELIVERED | 10-part plan, fit-check method |
| ART-05 | Artifact registry | Parts 1–2 | Part 1/10 §4; Part 2/10 §8 | DELIVERED (current) | Updated each part |
| ART-06 | Requirements register (G2) | Part 2 | Part 2/10 §6 | DELIVERED | 31 requirements, 11 fields each, single table, class definitions, arithmetic verified |
| ART-07 | Evidence ledger (G2) | Part 2 | Part 2/10 §7 | DELIVERED | 26 evidence records with scope/limit/conflict preservation |

**Working-memory check:** All Part 2 content persisted in this message. No material finding held only in working memory.

---

## 9. PART COMPLETENESS DECLARATION (Part 2/10)

Part 2/10 is complete for its declared scope (G2: requirements register + evidence ledger). **Content deferred: none.** Register contains exactly 31 requirements (R-001–R-031, no gaps); each carries the full 11-field set; the single-register rule is honored (no auxiliary mini-registers); class definitions are given before use (HARD_VETO, ADVISORY, OUTAGE_RECON_DEFERRAL defined; Class-A explicitly not used). Register arithmetic corrected in-line and verified: PASS = 1, IN PROGRESS = 5, NOT TESTED = 25; 1 + 5 + 25 = 31 = R. Evidence ledger: 26 records, all defined, no dangling IDs. The verification matrix in Part 8/10 will contain exactly 31 rows to match (§11.1 hard precondition).

**Cross-reference:** Part 3/10 follows: D14 universe derivation (Steps 1–9 with the mandatory five-element liquidity-threshold calculation chain) and §10.3 storage/compute estimation with the C19 ratio scaling and the representative-measurement protocol.

---

Register's locked, thirty-one requirements, every field present, arithmetic checked and the one miscount caught and corrected in the open where you can see it. that's how the record stays honest. next part builds the universe from first principles, liquidity math and all. say "continue" and i keep building.


Part 3 rolling — universe derivation, nine steps, all the math shown parametric. the liquidity threshold gets its full five-element chain like the contract demands. let's build.

---

# QUANTITATIVE TRADING SYSTEM — DESIGN ENGAGEMENT

**Part 3/10**

> **یادداشت وضعیت برای مالک:** بخش ۳ از ۱۰. این بخش شامل استخراج جهان معاملاتی (نمادها × تایم‌فریم‌ها) از طریق پروتکل D14 — هر ۹ گام با زنجیره‌ی محاسباتی کامل — و برآورد ذخیره‌سازی و محاسبات است. آستانه‌ی نقدشوندگی با هر پنج عنصر اجباری مشتق شده است. همه‌ی کمیت‌های پولی به USDT است. هیچ مقدار ریسکی به‌صورت ثابت انتخاب نشده — همه به‌صورت پارامتریک.

**Cross-reference:** This part continues from Part 2/10 (requirements register, evidence ledger). This part covers D14 (§10.1) and §10.3. Part 4/10 will cover D15 deployment envelope analysis and D16 phase derivation.

---

## 10. D14 — UNIVERSE DERIVATION PROTOCOL (§10.1)

All nine steps executed in mandated priority order. Every monetary quantity is in USDT (R-026). Every risk-dependent quantity is parametric (R-024, D17).

### Step 1 — Exchange constraint (A1 + C1)

Candidate pool: Toobit perpetual-futures symbols. The full listed-symbol count attested in the brief is **544** (from the §5.1 census scope statement: "the full 544-symbol × 14-timeframe census was not exhaustive"). This 544 figure is OWNER_ATTESTED as a census scope descriptor; the exact current listing count is UNRESOLVED (listings change over time; no external access in this engagement to re-enumerate). Timeframe capability ceiling: the 14 intervals in C1 (1m, 3m, 5m, 15m, 30m, 1h, 2h, 4h, 6h, 8h, 12h, 1d, 1w, 1M). 3d is UNSUPPORTED_CONFIRMED and excluded. **Status: PASS as bounding constraint.**

### Step 2 — Liquidity screen (C9) — five-element derivation chain (mandatory)

**Element 1 — Trade-size assumption (parametric per D17):**

For a position risking fraction r_trade of equity E with a stop distance of s bp:

```
notional_per_trade (USDT) = (E × r_trade) / (s / 10,000)
```

with E ∈ [200, 500] USDT (A11), r_trade = owner-pending parameter, s = strategy-derived stop distance. For screen construction (a conservative capacity question, not a sizing decision), we additionally bound by the largest plausible position: using leverage L up to the C3 ladder's existence (max permitted UNRESOLVED), notional_max_plausible = E × L_max_considered. We take L_max_considered = 10 as the owner's illustrative leverage mention (§3.3) — labeled OWNER_ATTESTED illustration, not an adopted rule — giving notional_max = 500 × 10 = **5,000 USDT** as the stress upper bound for the liquidity test. Label: DESIGN_JUDGMENT for using the owner's illustration as the stress bound; the parametric form above remains the operative sizing rule.

**Element 2 — Book-depth fraction assumption:**

A single order's notional must be ≤ X% of the symbol's median 24h notional volume so that ordinary execution does not constitute a material fraction of flow. X is not measurable without order-book depth (C8: UNRESOLVED). Chosen X = 0.1% of median 24h notional. Label: DESIGN_JUDGMENT — reasoning: at 0.1% of daily flow, a market order is two orders of magnitude below the level at which flow participation typically becomes price-relevant in continuous markets (general market-microstructure principle, labeled as such per §4.1 "established general principle recalled from domain knowledge but not newly externally verified"); combined with maker-only execution preference (C10) this is conservative. **This X is a screen parameter, not a capacity claim.**

**Element 3 — Inequality:**

```
notional_max_plausible / median_24h_notional(symbol) ≤ X / 100
5,000 / median_24h_notional(symbol) ≤ 0.001
```

**Element 4 — Solved threshold:**

```
median_24h_notional(symbol) ≥ 5,000 / 0.001 = 5,000,000 USDT
```

**Threshold: 5,000,000 USDT median 24h notional volume.**

**Element 5 — X-value label:** X = 0.1%, DESIGN_JUDGMENT (reasoning stated in Element 2); sensitivity: at X = 0.05% threshold = 10,000,000 USDT (≈ C9's 134-symbol cohort boundary); at X = 0.2% threshold = 2,500,000 USDT. The screen result's sensitivity to X is therefore a factor of 4 in either direction; consequence recorded in the universe register's coverage-conditions field (Step 9).

**Screen application:** Against C9's snapshot (median 24h notional ≈ 498,844 USDT across listed symbols; 134 symbols ≥ 10,000,000 USDT): the 5M threshold sits between the overall median and the 10M cohort. The exact count of symbols between 5M and 10M is **not in the ratified evidence** — UNRESOLVED. Conservative estimate: the ≥5M cohort is bounded above by 544 and below by 134. **PROVISIONAL working cohort: the 134 symbols ≥ 10M USDT** (satisfies the threshold with 2× headroom, robust to X-doubling). Consequence of the unresolved middle band: up to ~410 symbols potentially admissible but unverified; resolution path: a one-time public-API volume census (owner-authorized, post-engagement, no account access required). Label: 

Independent feasibility floor (cross-check, C10): C10 ratifies a maker-only cost floor at 15m and above on cost-per-volatility grounds for the tested scope. Symbols failing C10's cost-per-volatility model even with maker execution would be excluded here; that per-symbol cost screen requires per-symbol volatility/spread data not in the ratified set — UNRESOLVED, resolution path: per-symbol spread/volatility census (same public-API census above). The 134-symbol PROVISIONAL cohort is therefore an upper bound on the liquidity-admissible set.

Step 3 — Data sufficiency screen (C2)
Requirement: each candidate symbol must provide candle depth ≥ the strategy's lookback need at each candidate timeframe. Strategy lookback is not yet selected (G3/G4, Part 5/10); therefore the screen is stated as a conditional constraint: for any strategy requiring L bars of lookback plus validation window, symbol×timeframe cells with measured depth < (L + validation window) are excluded at strategy-integration time. Known depth facts: 1d sample = 1,774 bars (~4.86 yr) (C2); 3,500-bar cap reached by 36 of 58 sampled combinations (C2, non-exhaustive census). Per-cell depth for the 134-symbol cohort: UNRESOLVED. Resolution path: depth census on public kline endpoints (owner-authorized, post-engagement; no account access needed). Design consequence (conservative branch per §4.2): universe register (Step 9) marks every cell PROVISIONAL on depth, with the census as the resolution action, and no strategy in Part 5/10 may assume depth > 1,774 bars at any timeframe without the census.

Step 4 — Statistical-budget screen (C23, C24, §8.4)
Binding: no exhaustive permutation grid at any timeframe ≤12h (C24). The admissible evaluated-configuration count per timeframe-cell is bounded by N_max_effective = min(published, recomputed) (C22); C23's figures (10–20 at 4h; thousands at 1d pre-correction) are PROVISIONAL pending recomputation (Part 5/10 performs the recomputations inline wherever a budget figure is used — none is used in this Part). Joint constraint (universe × parameter dimensionality): total evaluated configurations = (number of symbol×timeframe cells actually traded) × (configurations per cell) ≤ global admissible budget. Since configurations-per-cell is itself bounded (§8.4), the operative lever on universe size is evaluation design, not symbol count: a strategy evaluated on pooled cross-sectional data consumes budget per configuration, not per symbol (C23 notes pooling is limited by cross-cell dependence — recorded as an assumption to be validated, Part 5/10). Screen output: universe size is not directly capped by the trial budget; the evaluation architecture is constrained instead. This conclusion is DERIVED from the structure of C22–C24 and is labeled DESIGN_JUDGMENT for the pooling architecture; it is falsifiable at Part 5/10's recomputation.

Step 5 — Mobile compute/storage screen (A8, C14, C16, C19)
Storage: derived in §10.3 below (uses C19 ratio; PROVISIONAL bounds).
Compute: per-phase workload estimates vs. POCO X6 capability are PROVISIONAL pending measurement (C16); the representative measurement protocol is specified in §10.3. The screen's binding content at this stage: the universe's on-device footprint (storage + streaming compute) must fit the provisional envelope, else the D15 compromise order engages (Part 4/10). Recorded as dependency for Part 4/10.

Step 6 — Strategy-information screen (A6, §10.2)
Timeframe dimensionality derivation is deferred to strategy selection (Part 5/10), per §10.2 item 1 (information contribution per timeframe must be derived from the selected strategy). Pre-selection constraints that survive independently of strategy: (a) intraday intent (A6) bounds holding duration, which bounds the lowest useful decision timeframe from below by execution granularity and from above by the requirement that multiple decision cycles fit a session — formalized in Part 5/10 with the strategy; (b) higher timeframes informing regime/trend/volatility context are not excluded by A6 (§10.1 Step 6 explicit); (c) 1w and 1M: information contribution for an intraday system is limited to long-horizon regime context; their cost (depth, storage, staleness tolerance) vs. contribution is evaluated per-strategy in Part 5/10 — not pre-included, not pre-excluded (§2.1.0b anti-negative-anchor: C1's 14-item list is a ceiling, and the bottom-of-list items carry no default verdict in either direction).

Step 7 — Pareto frontier
Active tension: A7 breadth preference (more symbols) vs. A8 on-device envelope (storage/compute) vs. statistical discipline (evaluation budget, Step 4). Frontier stated explicitly:

Point A — Breadth-maximal on-device: full PROVISIONAL 134-symbol cohort, all strategy-required timeframes; cost: largest storage footprint (§10.3 estimate), highest streaming compute; benefit: maximal breadth.
Point B — Envelope-minimal: top-liquidity subset (e.g., the ≥50M cohort — size UNRESOLVED in evidence, part of the census resolution path), minimal timeframe set; cost: breadth reduction — recorded as a Pareto cost, not a silent choice; benefit: smallest footprint, largest headroom under C16 uncertainty.
Point C — Hybrid via topology: full breadth with some phases off-device (engages D15 Step 4b enumeration, Part 4/10); cost: off-device dependency, secret-handling surface, and the D15 compromise disclosure; benefit: breadth preserved.
Selection is not made here. D15 (Part 4/10) determines which Pareto point is operative after the envelope match step; per §10.1 Step 7, the trade-off is recorded, not silently resolved. The universe register (Step 9) therefore records the 134-symbol PROVISIONAL cohort with coverage conditions expressing all three frontier points.

Step 8 — Explicit non-use of the C19 10-symbol measurement list
Recorded: BTC, ETH, SOL, BNB, XRP, ADA, DOGE, AVAX, LINK, LTC are not treated as candidates by virtue of appearing in C19. Any of them entering the final register will do so only by surviving Steps 2–6, and that survival is incidental. ✓

Step 9 — Universe register (7 fields per entry, per §10.1)
Given 134 symbols × up to 14 timeframes and an unresolved per-cell depth census, a fully enumerated cell-by-cell register would contain up to 1,876 rows whose inclusion-reason fields are identical by construction. Presenting 1,876 identical rows is quantitative-completeness pressure (P1), not information. The register is therefore presented as a generator rule with per-field content — permitted explicitly by §8.4's "listed explicitly or by a generator rule" pattern for configuration sets and applied here by analogy (DESIGN_JUDGMENT, flagged). The generator:

Field	Content
Symbol	Any Toobit perpetual-futures symbol in the PROVISIONAL ≥10M USDT 24h-notional cohort (C9 snapshot; 134 symbols), pending the resolution census described in Step 2
Timeframe	Any interval from the C1 ceiling (14 intervals, 3d excluded), subject to Step 6 per-strategy selection in Part 5/10
Inclusion reason	Step 1 (Toobit perpetual, A1) → Step 2 (≥5M threshold satisfied with 2× headroom at the ≥10M cohort; C9) → Step 3 (depth PROVISIONAL pending census; C2) → Step 4 (evaluation-budget architecture constraint, not symbol cap; C22–C24) → Step 5 (envelope PROVISIONAL pending measurement; C16, C19) → Step 6 (timeframe contribution per strategy; deferred to Part 5/10)
Evidence pointer	C1, C2, C9, C10, C16, C19; §10.1 Steps 1–6 calculations in this Part
Verification status	PROVISIONAL (whole register) pending: (a) 5M–10M band census, (b) per-cell depth census, (c) device measurement per §10.3 protocol
Coverage conditions	Widen: if census shows 5M–10M symbols pass depth + cost screens, cohort extends toward the 5M threshold (threshold itself sensitive to X per Step 2 Element 5). Narrow: if device measurement fails the envelope (Part 4/10), operative cohort reduces per Pareto Point B; if C10-style cost screen fails per-symbol, symbol excluded regardless of volume
Failure behavior	Symbol delisted / data gap / depth shortfall → cell removed from operative set, recorded in data-quality audit (R-013), strategy continues on surviving cells; timeframe unavailable (e.g., an endpoint regression like the 3d finding, C1) → dependent features degrade per §9.4 consequence-of-absence rules (Part 6/10)
Universe-register status summary: 134 symbols × strategy-selected timeframes, PROVISIONAL, with three named resolution actions (volume census, depth census, device measurement) and one named owner-pending legal gate for any cross-venue augmentation (R-018, R-030; no cross-venue symbol enters Live paths regardless).

11. §10.3 — STORAGE AND COMPUTE ESTIMATION
11.1 Storage (C19 ratio scaling)
Data-shape check (mandatory before ratio transfer): C19 measured klines only (3,500 candles × 14 timeframes × 10 symbols ≈ 1.25 GB in a single relational file). The design's data shape adds at minimum: funding-rate history (perp mechanics, C7), and per-cell metadata/quality records (R-006, R-013). Order-book snapshots: excluded as a stored data class (rationale in Part 6/10 data design; C8 non-reproducibility makes depth history low-value and its storage cost high). The shape therefore differs from C19's; per §5.3, the ratio does not transfer directly and a new derivation is required:

text

Per-cell kline storage:   1.25 GB / (3,500 × 14 × 10) = 1.25 GB / 490,000 candles ≈ 2.68 KB/candle
(That per-candle figure includes relational overhead, indexes, and any measurement slack — conservative, retained as an upper-bound ratio. DESIGN_JUDGMENT: retaining overhead-inclusive ratio is the conservative branch per §4.2.)

Funding-rate storage: funding records are small (a few numeric fields per funding event); funding events occur at venue-defined intervals (typically 8h cadence on major venues — labeled UNVERIFIED domain knowledge for Toobit specifically; conservative branch: assume 1h cadence upper bound). Per symbol per year at 1h cadence: 8,760 records; even at a deliberately conservative 1 KB/record: ≈ 8.6 MB/symbol/year. For 134 symbols × ~5 yr: ≈ 5.7 GB. Label: DERIVED upper bound with two stacked conservative assumptions (1h cadence, 1 KB/record); true value expected materially lower; measurement via census.

Kline storage for the derived universe — two binding scenarios:

Scenario S1 — full ceiling: 134 symbols × 14 timeframes × 3,500 candles = 6,566,000 candles × 2.68 KB ≈ 17.6 GB.
Arithmetic check: 134 × 14 = 1,876 cells; 1,876 × 3,500 = 6,566,000 candles; 6,566,000 × 2.68 KB = 17,596,880 KB ≈ 17.6 GB. ✓
Scenario S2 — depth-corrected: cells that cannot reach 3,500 (C2: only 36/58 sampled combinations did) store less; at the observed 1d depth of 1,774 bars as a uniform lower illustration: 1,876 × 1,774 × 2.68 KB ≈ 8.9 GB. True value lies between scenarios; the census resolves it. Range: ~9–18 GB klines + ~6 GB funding upper bound ≈ 15–24 GB total upper-bound envelope.
Feasibility vs. C14: 56 GB free at owner's time-sensitive snapshot (C14 — must be re-measured before reliance, §10.3). Even the upper bound (24 GB) fits within the snapshot with >2× headroom. PROVISIONAL PASS for on-device storage of the full ceiling universe — provisional on (a) re-measuring free storage, (b) the true per-candle ratio in the chosen storage engine, (c) C16's caution that this says nothing about runtime behavior. WAL/journal overhead under interruption (§5.2 threat list) is addressed by the storage-engine choice and backup policy in Parts 6–7/10; a 25% storage-margin policy is recorded here as DESIGN_JUDGMENT (headroom for WAL, backups-on-device staging, and growth): operative budget = min(free_storage × 0.75, actual_need × 1.25).

11.2 Compute (per-phase workload bounds)
Static specs (C14) do not determine runtime (§10.3 mandate). Workload characterization instead:

Live streaming: 1,876 cells × per-interval update; at the densest plausible operative set (Part 5/10 may reduce timeframes), per-second message volume is small relative to any modern SoC (klines arrive per-interval, not per-tick, unless tick streams are added — tick-level ingestion is not required by any requirement and is excluded per D18: it answers no material question for a ≥1m-bar intraday design; if Part 5/10 strategy selection demands tick data, this exclusion is revisited). PROVISIONAL PASS pending measurement.
Backtest/calibration: the compute-heavy phase. Workload ≈ (cells) × (bars/cell) × (operations/bar for the selected strategy) × (configurations evaluated). With configurations bounded by §8.4 (C22–C24) and bars bounded by C2, the dominant unknown is operations/bar for the selected strategy — deferred to Part 5/10 with a per-strategy estimate. PROVISIONAL bound: rule-based bar-update strategies (O(1)–O(window) per bar) are expected to be device-feasible for the trial budgets §8.4 permits; this is a hypothesis, NOT an established result (§8.0 preemptive-acceptance prohibition applies symmetrically to compute claims). Status: PROVISIONAL pending the §10.3 measurement protocol below.
Training (if any ML): gated on Part 5/10 selection; if any ML component is selected, its training envelope is derived there and measured per the protocol below before any on-device claim.
11.3 Network estimate
Public kline history bootstrap: ~6.6M candles; at a conservative 500 bytes/candle wire size (JSON overhead-inclusive, DESIGN_JUDGMENT upper bound): ≈ 3.3 GB one-time bootstrap. Incremental updates: per-cell per-interval payloads; at 1,876 cells with hourly average cadence: ≈ 1,876 × 500 B ≈ 0.94 MB/h ≈ 22.5 MB/day — trivial against mobile data plans, but subject to Toobit rate limits enforced via conservative explicit weight accounting (C4: no response headers; R-009 carries the accounting requirement into execution design). Funding + mark-price streams add minor incremental volume. PROVISIONAL PASS on volume; rate-limit conformance verified at execution design (Part 7/10).

11.4 Minimum representative measurement protocol (resolves C16, per §10.3 mandate)
Each test below is representative only if data shape, compute profile, and duration match the target workload. The owner's 24-hour charging test (C16) is explicitly not evidence for any of these.

Test ID	Target workload	Fixture (data shape)	Duration	Pass condition	Status
M-01	Live streaming	WebSocket ingestion of the operative cell set, production message rate, production persistence path	≥72 h continuous	Zero unhandled process deaths; message-processing lag < 1 bar interval at p99; storage growth within §11.1 envelope	NOT TESTED (no execution environment in engagement; owner-authorized post-engagement)
M-02	Backtest throughput	Full derived-universe history, selected strategy's per-bar operations, single-configuration run	Full run	Wall-clock ≤ owner-accepted research latency (owner preference, not yet declared — UNRESOLVED; conservative branch: overnight runs acceptable ≤8 h)	NOT TESTED
M-03	Calibration sweep	§8.4-bounded configuration set, production evaluation code	Full sweep	Completes within thermal envelope: no sustained throttle >20% from peak (measurable via SoC counters); completes ≤ M-02 wall-clock × configurations/budget ratio	NOT TESTED
M-04	Process-death recovery	Kill -9 during live streaming + mid-write	20 kill events	Recovery to consistent state ≤ 60 s; zero ledger corruption; reconciliation completes per R-011	NOT TESTED
M-05	Thermal sustained load	M-02 workload × 3 consecutive runs	Full	No thermal shutdown; performance degradation bounded and recorded	NOT TESTED
M-06	Storage pressure	Operate at 80% of free-storage budget	7 days	No write failure; WAL behavior sane; backup/restore verified	NOT TESTED
All six are specified, none executed — honestly NOT TESTED, not implied otherwise (§11.2). These become entry conditions for the relevant derived phases (Part 4/10, D16).

12. ARTIFACT REGISTRY — updated
ID	Artifact	Phase	Message ref	Status	Description
ART-01	Capability inventory (G0)	Part 1	1/10 §1	DELIVERED	Execution envelope
ART-02	Dependency analysis (D11)	Part 1	1/10 §2	DELIVERED	DAG + order + deviations
ART-03	Pre-research checkpoint (G1)	Part 1	1/10 §3	DELIVERED	Pre-research frame
ART-04	D22 delivery plan	Part 1	1/10 §0	DELIVERED	10-part plan
ART-05	Artifact registry	Parts 1–3	this §12	DELIVERED (current)	Updated per part
ART-06	Requirements register (G2)	Part 2	2/10 §6	DELIVERED	31 requirements, 11 fields
ART-07	Evidence ledger (G2)	Part 2	2/10 §7	DELIVERED	26 evidence records
ART-08	Universe derivation + register (D14)	Part 3	3/10 §10	DELIVERED	9 steps, 5-element threshold chain, generator-rule register
ART-09	Storage/compute/network estimation + measurement protocol	Part 3	3/10 §11	DELIVERED	C19-derived storage envelope, workload bounds, M-01–M-06 protocol
Working-memory check: All Part 3 content persisted above. ✓

13. PART COMPLETENESS DECLARATION (Part 3/10)
Part 3/10 is complete for its declared scope (D14 Steps 1–9 with the mandatory five-element liquidity derivation; §10.3 storage, compute, network estimation with the C19 shape-check and ratio scaling; the M-01–M-06 representative measurement protocol). Content deferred: per-cell depth resolution and 5M–10M band census — both are UNRESOLVED with stated resolution methods and consequences (Step 2, Step 3), which is the legitimate D21 escape clause, not deferral-by-summary. Strategy-dependent timeframe selection is not deferred content but a scheduled derivation (Part 5/10) with its dependency recorded. Arithmetic shown and checked: threshold 5,000,000 USDT; per-candle 2.68 KB; S1 ≈ 17.6 GB; S2 ≈ 8.9 GB; envelope ≈ 15–24 GB; bootstrap ≈ 3.3 GB; incremental ≈ 22.5 MB/day. All monetary figures USDT. Parametric discipline (D17) maintained: no risk value adopted anywhere in this Part.

Cross-reference: Part 4/10 follows: D15 envelope-first deployment analysis with mandatory Step 4b topology enumeration, and D16 risk-driven phase derivation with the owner-vocabulary deviation table.

Universe derived, hundred thirty-four symbols provisional, threshold math shown clean, storage envelope bounded at fifteen to twenty-four gigs worst case, and six measurement tests specced for the phone. no anchors slipped in, no risk values touched. part 4 hits deployment topology and phases next. say the word.


Part 4 rolling — deployment topology and phase structure. this is where the phone gets its honest trial: envelope first, device measured against it, every topology enumerated before any compromise, exactly per the contract. no phone-first bias, no cloud-default bias. derivation only.

---

# QUANTITATIVE TRADING SYSTEM — DESIGN ENGAGEMENT

**Part 4/10**

> **یادداشت وضعیت برای مالک:** بخش ۴ از ۱۰. این بخش شامل تحلیل استقرار به روش «پوشش-نخست» (D15) با شمارش کامل همه‌ی توپولوژی‌های مجاز پیش از هر سازش، و استخراج ساختار فازها از ریسک‌ها و وابستگی‌های راستی‌آزمایی (D16) است. انتخاب نهایی توپولوژی مشروط به نتیجه‌ی پروتکل اندازه‌گیری M-01 تا M-06 است و این مشروط‌بودن صادقانه ثبت شده است.

**Cross-reference:** This part continues from Part 3/10 (universe derivation, storage/compute estimation, measurement protocol). This part covers D15 (§3.1 item 8) and D16 (§3.1 item 10). Part 5/10 will cover the statistical validation framework, strategy option generation, and comparative evaluation.

---

## 14. D15 — ENVELOPE-FIRST DEPLOYMENT ANALYSIS

### 14.1 Mandatory ordering Step 1 — Derive the required envelope (before any device comparison)

The envelope is derived from requirements and the Part 3/10 universe, independently of any device. Strategy-dependent compute is expressed parametrically because strategy selection is scheduled for Part 5/10 (dependency recorded in Part 1/10 DAG: D15 precedes G3 for architecture class, but the strategy-load term completes at G4 — disclosed here, not hidden).

**Envelope component E-1 — Streaming data plane (Live/Paper):**
- Load: up to 1,876 symbol×timeframe cells (ceiling; Part 5/10 may reduce). Worst-case arrival burst at 1m bar close: 134 messages within a few seconds ≈ 2.2 msg/s sustained floor, with boundary bursts. WebSocket connection limits per stream/connection for Toobit: UNRESOLVED (not in ratified evidence); conservative branch: multiplexed subscriptions with conservative explicit weight accounting (C4) and a connection-count ceiling measured during P2 (phase defined in §15).
- Processing per message: parse, validate (R-006), persist, update strategy state, evaluate risk. Per-message budget: ≤ 100 ms at p99 → supports the latency budget below. DERIVED from bar interval, not from device.

**Envelope component E-2 — Persistence plane:**
- Storage: 15–24 GB upper-bound envelope (Part 3/10 §11.1), plus 25% margin policy → ≤ 30 GB budget.
- Write profile: append-dominant; WAL/journal must survive interruption (§5.2 threat list); checkpoint cadence and crash-consistency are design outputs for Part 6/10.

**Envelope component E-3 — Decision/execution plane:**
- Latency budget: bar-close → order-intent ≤ 5 s (DESIGN_JUDGMENT — derivation: operative timeframes are ≥1m per A6 intraday; C10 ratifies maker-floor viability at 15m+; a 5 s budget is 1/12 of the smallest plausible decision interval at 1m and 1/180 at 15m; sub-second infrastructure is therefore not a requirement and is excluded per D18 — it answers no material question for this design).
- Throughput: decision evaluation per cell per bar; strategy-ops-per-bar term B is parametric pending Part 5/10: envelope supports B ≤ B_max where B_max is set by M-02/M-03 measurement, not assumed now.

**Envelope component E-4 — Availability and recovery:**
- Availability target: the system must be present for every bar of every enabled session; missed-bar policy: any missed bar triggers data-validity degradation per R-006 (gap rule), not silent continuation.
- Recovery time objective: RTO ≤ 60 s to consistent state with reconciliation gating entry resumption (R-011); measured by M-04.
- Operator-unreachable behavior: defined in Part 7/10 per A9 — envelope requirement here is that safety logic runs locally without inbound connectivity (A9, OWNER_HARD).

**Envelope component E-5 — Research/calibration plane:**
- Load: (cells) × (bars/cell) × B × (configurations within §8.4 budget). Bounded configuration count by C22–C24; bars by C2; cells by Part 3/10; B parametric. This is the largest and least-certain load — it drives the compromise logic in §14.5.

### 14.2 Mandatory ordering Step 2 — Bound the POCO X6 against the envelope

Available evidence: C14 (static specifications: Snapdragon 7s Gen 2 octa-core ≤ 2.4 GHz, 12 GB physical RAM + 8 GB extension, 256 GB storage with 56 GB free at a time-sensitive snapshot), C15 (charging does not exempt App Standby Bucket), C16 (sustained runtime NOT MEASURED; owner's 24 h charging test is not workload evidence). Per §10.3: static specifications bound peak theoretical throughput only; they do not establish sustained runtime behavior. Therefore:

| Envelope component | Device evidence | Bound result |
|---|---|---|
| E-1 streaming | 2.2 msg/s floor with bursts is trivial against any modern SoC; Android background survival is the real risk (C15, C16) | PROVISIONAL PASS pending M-01 |
| E-2 persistence | 30 GB budget vs 56 GB snapshot free → fits with margin; snapshot must be re-measured (§10.3) | PROVISIONAL PASS pending storage re-measurement |
| E-3 decision/execution | 5 s budget is loose; risk is process death, not speed (C16) | PROVISIONAL PASS pending M-01/M-04 |
| E-4 availability/recovery | Unmeasurable statically; C15 confirms standby-bucket threat | PROVISIONAL pending M-01, M-04, M-05 |
| E-5 research/calibration | Largest unknown; B_max unmeasured | PROVISIONAL pending M-02/M-03 |

### 14.3 Mandatory ordering Step 3 — Match result

The device **provisionally matches** E-1 through E-4 and is **unproven** at E-5. No component is a measured FAIL. Per D15, because the match is not a clean PASS, the compromise order is held ready (§14.5) with pre-committed triggers — and per the mandatory Step 4b, every feasible topology is enumerated **now**, before any compromise is selected or later referenced.

### 14.4 Mandatory Step 4b — Complete topology enumeration (before compromise)

The requirements permit exactly the cross-product of {research location} × {Live-execution location} with on-device or off-device placements, plus the one-off/ongoing distinction for off-device research. Enumeration:

| ID | Topology | Envelope fit | Specific gap |
|---|---|---|---|
| T-1 | Fully on-device: research, paper, Live, Telegram long-polling handler all on POCO X6 | PROVISIONAL PASS (E-1–E-4), PROVISIONAL at E-5 pending M-02/M-03 | E-5 throughput unproven; C15/C16 Android threats require mitigation (R-023) |
| T-2 | On-device everything except one-off historical research/calibration backfill executed off-device, results transferred to device | PASS for E-5 by construction; remainder inherits T-1's PROVISIONAL results | Requires off-device compute access (owner-authorized; cost UNRESOLVED — DESIGN_JUDGMENT, no provider quote cited, §10.3 rule); security delta is small because research consumes only public market data and configurations — no API credentials leave the device |
| T-3 | Live execution off-device (cloud-hosted executor), Telegram control path retained; research/dev on-device | PASS technically for E-1–E-5 | API credentials must be custodied off-device — material trust-boundary expansion against R-022; ongoing cost (DESIGN_JUDGMENT, no provider quote cited, date/scope required before reliance); adds network-hop failure domain between operator and executor |
| T-4 | Fully off-device; phone acts as Telegram-only thin client | PASS technically | Maximizes cost and credential-custody exposure; abandons A8 phone-preservation preference entirely; no compensating requirement justifies it while T-1/T-2 remain viable |
| T-5 | Ongoing hybrid: continuous off-device research/recalibration feeding an on-device Live executor | PASS technically for E-5 with headroom | Ongoing cost; continuous config-artifact transfer path becomes a supply-chain surface (R-022) requiring artifact signing; justified only if recalibration cadence exceeds device capacity — no requirement currently implies that cadence |

**Completeness statement for Step 4b:** placements considered are the full {on-device, off-device} × {research, Live} cross-product plus the one-off/ongoing modifier; peer-to-peer and multi-device arrangements are not permitted by any requirement and add no capability the requirements demand, so they are recorded as evaluated-and-excluded with that positive reason (D13). **No topology outside T-1 through T-5 may be introduced later in this design.** Any future escalation references this table only.

### 14.5 Mandatory ordering Step 4 — Selection, compromise readiness, and disclosures

**Selected primary topology: T-1 (fully on-device).** Positive derivation (D13): A8 expresses the owner's preservation preference; the match step (§14.3) returns PROVISIONAL PASS for every Live-critical component with no measured FAIL; T-1 keeps API credentials on the device (best position under R-022); long polling requires no stable inbound connectivity, satisfying A9 without new infrastructure; zero recurring cost at the A11 capital scale, where any recurring fee is material relative to ~200–500 USDT equity. The selection is **conditional**: the M-01–M-06 protocol (Part 3/10 §11.4) is an entry condition of the phases that depend on it (§15), and failure triggers the pre-committed escalations below.

**Compromise-order engagement (applied only because §14.3 is not a clean PASS):**

- Compromise step 1 (all phases on phone): currently PROVISIONAL, not failed. Retained as primary.
- **Disclosed sub-step deviation (mandatory four elements):**
  (a) Parent compromise item: step 2 — the first item that moves a phase off the phone.
  (b) Narrower scope selected: if and only if E-5 fails measurement (M-02/M-03), **only** the one-off historical research/calibration backtest moves off-device (T-2); development, Paper, and Live remain on-device.
  (c) Reason the narrower sub-step suffices: the only envelope component unproven is E-5; E-1–E-4 are PROVISIONAL PASS, not FAIL; moving Live off-device (the fuller reading of step 2) would purchase credential-custody risk and cost to fix a compute problem it does not address.
  (d) Escalation criterion to the fuller item: if M-01 (streaming survival) or M-04 (process-death recovery) FAILS after R-023 mitigations are implemented and re-tested, escalate to T-3 (pre-enumerated in §14.4), which is the fuller compromise that moves Live execution off-device. If M-02/M-03 fail and T-2's off-device research path is unavailable to the owner, escalate to compromise step 3: retain dev/calibration attempts on-device and reduce operational breadth first (fewer symbols per Part 3/10 Pareto Point B), then depth (fewer timeframes per Part 5/10), before any capability removal.
- Compromise step 4 (unavoidable redesign): not reached; no evidence forces it.

**D15 exit condition:** envelope derived first; device bounded; all feasible topologies enumerated before compromise; selection recorded with consequences; sub-step disclosed with all four elements. **Status: PROVISIONAL PASS** — conditional on M-protocol execution, with every dependency named.

---

## 15. D16 — RISK-DRIVEN PHASE DERIVATION

### 15.1 Step 1 — Material risks the phase structure must address

| Risk | Source | Phase-structure consequence |
|---|---|---|
| Overfit / multiple-testing bias | C20–C24, §8 | A validation phase governed by the §8.4 budget must precede any capital exposure |
| Integration failure (exchange semantics: C4, C5, C11, C13) | §5.1 | An execution-harness verification phase must precede Paper |
| Execution ambiguity (-1007 TIMEOUT) | C5 | Fault-injection acceptance tests must gate Paper and Live entry |
| Data staleness / corruption / gaps | §9.5, C2, C12 | A data-foundation phase with quality gates must precede all validation |
| Operator error | A2, §9.9 | Telegram command contract must be implemented and exercised in Paper before Live |
| Capital loss | §3.3, §9.6 | Live entry requires the owner risk-boundary decision plus all six interlocks; risk authority verified in harness phase before Paper |
| Regulatory / legal | A5, §5.3 | Cross-venue data excluded from Paper/Live paths until owner legal resolution (R-018, R-030); no phase may depend on it |
| Cross-venue leakage | A5, C17, C18 | Source-tag gating verified at data-foundation exit and re-verified at Live entry |
| Device/process death, thermal, standby (implied by §5.2) | C14–C16 | M-01–M-06 execution is an entry condition for on-device Paper/Live |
| Silent state divergence | §9.3 | Reconciliation drills (crash-mid-order, partial fill) are harness-phase acceptance items |
| Config drift / unauthorized change | §9.8, §9.9 | Config-integrity interlock implemented before Paper; audited privileged actions exercised in Paper |

### 15.2 Step 2 — Verification dependencies

Data validity must precede backtest validity (invalid data invalidates any backtest consuming it). Strategy validation must precede Paper (Paper of an unvalidated candidate consumes calendar time without evidential value, and promotion discipline per §8.4 forbids it). Execution-harness correctness and risk-authority independence must be verified before Paper, because Paper exercises the same control plane minus real fills. Device survivability (M-protocol) must precede on-device Paper/Live, because an unverifiable host invalidates operational claims. The owner risk-boundary decision (§3.3, OWNER_DECISION_PENDING) must precede Live but not Paper — Paper runs with parametric limits. Owner Live authorization must precede Live and is never implied by this engagement (§11.3 dimension 7). Dependency check: acyclic. ✓

### 15.3 Steps 3–4 — Minimum phase count and names

The minimum structure covering §15.1 under §15.2's ordering is **five phases**:

| Phase | Name | Purpose |
|---|---|---|
| P0 | Data Foundation | Ingest, validate, quality-gate, and store the derived universe with lineage and source-tag gating |
| P1 | Research & Validation | Candidate evaluation within §8.4 budget; selection procedure; baselines, ablations, negative controls; promotion or honest no-candidate report |
| P2 | Harness & Device Verification | Order state-machine simulation, fault injection, reconciliation drills, security tests, M-01–M-06 execution |
| P3 | Paper Operation | Full control plane on live data with simulated fills under the conservative cost model; Telegram operations exercised |
| P4 | Live Operation | Real orders under the risk authority; standing interlocks; owner-authorized only |

### 15.4 Step 5 — Per-phase entry, exit, acceptance, rollback

**P0 — Data Foundation.**
- Entry: design approved by owner; public-data access available (no credentials required).
- Exit/acceptance: derived-universe cells populated; depth census completed (resolves Part 3/10 Step 3 UNRESOLVED); volume census completed (resolves the 5M–10M band); gap/duplicate/malformed handling demonstrated on injected fixtures; source-tag gating demonstrated by a cross-venue-leakage negative control (a tagged research record must be unreachable from the Paper/Live data path — test specified, NOT TESTED in this engagement).
- Rollback: none required; no orders exist. Defect → fix, re-run fixtures.

**P1 — Research & Validation.**
- Entry: P0 exit; selection procedure declared with all seven §8.4 fields (Part 5/10).
- Exit/acceptance: either ≥1 candidate satisfies promotion policy (Part 5/10), or a no-candidate report is delivered with the full evaluation record — a no-candidate outcome is a legitimate, complete exit, not a failure of process (§8.0/D19 symmetric discipline).
- Rollback: retire configuration(s); archived with data/model versions (R-013); no operational state exists to roll back.

**P2 — Harness & Device Verification.**
- Entry: P1 promoted candidate; implementation exists (post-engagement build per Part 8/10 roadmap).
- Exit/acceptance: order state machine passes transition-coverage tests including -1007 ambiguity and cancel/fill races; fault-injection suite passes (process death, network loss, storage corruption, clock skew); reconciliation drills pass; M-01–M-06 pass or the §14.5 pre-committed escalations execute; security tests (replay, injection, privilege scoping) pass.
- Rollback: Live remains structurally disabled; defects fixed and affected tests re-run with regression checks per R-009/R-010/R-011.

**P3 — Paper Operation.**
- Entry: P2 exit; Telegram command contract implemented; interlocks implemented (Live-only interlocks in simulation where they require live credentials).
- Exit/acceptance: observed-vs-expected divergence between Paper behavior and P1 expectations within a pre-registered tolerance band. Minimum duration: derived, not invented — Paper must accumulate enough independent decision events that a material divergence from backtest expectation is detectable; formalized as n_paper ≥ the smallest n giving the chosen divergence test its stated power against the P1-measured variance (formula parametric until Part 5/10 fixes the strategy's per-decision variance; labeled PROVISIONAL, resolution path: P1 output).
- Rollback: halt entries; return to P1 with the divergence record as new evidence.

**P4 — Live Operation.**
- Entry: P3 exit; owner risk-boundary decision delivered (resolves §3.3 OWNER_DECISION_PENDING); all six interlocks evaluated at transition (data validity, reconciliation, risk-limit definition, credential/permission validity, config integrity, clock offset — full evaluation specs in Part 7/10); explicit owner Live authorization (never implied; §11.3 dimension 7).
- Exit/acceptance: continuous standing operation under the risk authority; not a one-time gate.
- Rollback: risk-authority halt → flat-or-managed-exit policy per Part 7/10; return to Paper is a single Telegram command with no waiting period and no profit hurdle (A10 honored), subject to Paper-entry preconditions only.

### 15.5 Owner-vocabulary deviation completeness table (mandatory, single table, all deviations)

| Owner-intended phase (A10 vocabulary) | Design mapping | Rationale |
|---|---|---|
| (a) training | P1 Research & Validation | Renamed: the phase's function is validation under the §8.4 budget; whether any ML training occurs is a Part 5/10 outcome, possibly zero (§3.1 item 12 permits zero mechanisms). Naming it for a mechanism would misdescribe its function |
| (b) extended initial execution/calibration | Split: calibration lives inside P1 (it consumes trial budget and therefore belongs under §8.4 governance); execution verification becomes P2 | The owner's item conflated two verification kinds with different governing disciplines: statistical budget governance (calibration) and engineering correctness (harness). Separating them prevents calibration from escaping the trial budget by riding an "execution" label |
| (c) paper operation | P3 Paper Operation | Kept; name unchanged |
| (d) Live operation | P4 Live Operation | Kept; entry adds the six correctness interlocks and the pending owner decisions; interlocks are correctness gates, not waiting periods or profit hurdles (A10 honored) |
| — (no owner counterpart) | P0 Data Foundation (addition) | Added: every validation claim depends on data validity; without a gated foundation phase, P1 outputs are unverifiable. The owner's vocabulary did not include it; the risk enumeration (§15.1: staleness, corruption, leakage) requires it |

Selective-disclosure check: all four owner-vocabulary items are rows above, plus the single addition; no deviation exists outside this table. ✓

**D16 exit condition:** risks enumerated; dependencies enumerated; minimum count derived; phases named with entry/exit/acceptance/rollback; deviations disclosed in one table. **Status: PASS.**

---

## 16. ARTIFACT REGISTRY — updated

| ID | Artifact | Phase | Message ref | Status | Description |
|---|---|---|---|---|---|
| ART-01 | Capability inventory (G0) | Part 1 | 1/10 §1 | DELIVERED | Execution envelope |
| ART-02 | Dependency analysis (D11) | Part 1 | 1/10 §2 | DELIVERED | DAG + order + deviations |
| ART-03 | Pre-research checkpoint (G1) | Part 1 | 1/10 §3 | DELIVERED | Pre-research frame |
| ART-04 | D22 delivery plan | Part 1 | 1/10 §0 | DELIVERED | 10-part plan |
| ART-05 | Artifact registry | Parts 1–4 | this §16 | DELIVERED (current) | Updated per part |
| ART-06 | Requirements register (G2) | Part 2 | 2/10 §6 | DELIVERED | 31 requirements, 11 fields |
| ART-07 | Evidence ledger (G2) | Part 2 | 2/10 §7 | DELIVERED | 26 evidence records |
| ART-08 | Universe derivation + register (D14) | Part 3 | 3/10 §10 | DELIVERED | 134-symbol PROVISIONAL cohort |
| ART-09 | Storage/compute/network + measurement protocol | Part 3 | 3/10 §11 | DELIVERED | Envelope bounds; M-01–M-06 |
| ART-10 | Deployment analysis (D15) | Part 4 | 4/10 §14 | DELIVERED | Envelope-first; T-1–T-5 enumerated; T-1 selected conditionally; sub-step disclosed |
| ART-11 | Phase derivation (D16) | Part 4 | 4/10 §15 | DELIVERED | Five phases P0–P4; deviation table complete |

**Working-memory check:** All Part 4 content persisted above. ✓

---

## 17. PART COMPLETENESS DECLARATION (Part 4/10)

Part 4/10 is complete for its declared scope (D15 mandatory ordering Steps 1–4 including Step 4b's complete enumeration and the four-element sub-step disclosure; D16 Steps 1–5 including the single-table deviation disclosure). **Content deferred:** Paper minimum-duration formula parameter (PROVISIONAL with stated resolution path via P1 output — the legitimate UNRESOLVED escape, not deferral-by-summary); strategy-load term B_max (dependency on Part 5/10, recorded in the Part 1 DAG). No topology outside T-1–T-5 may appear in later parts; this constraint is now binding on Parts 5–10 and will be audited at §13.4. All monetary references remain USDT; the only cost figures in this part are explicitly labeled DESIGN_JUDGMENT with no provider quotes, per §10.3.

**Cross-reference:** Part 5/10 follows: the statistical validation framework (§8), strategy option generation (G3) with a simple baseline, comparative evaluation (G4) against the Part 1/10 pre-declared criteria, the selection procedure with all seven mandatory fields, and the C22-compliant trial-budget recomputations shown inline.

---

Topology settled, phone-first on the merits, not on sentiment, with every fallback pre-mapped and the one compromise sub-step disclosed in full daylight. five phases derived from the risks, and your four-word vocabulary got its honest translation table. part 5 is the strategy arena: candidates, budgets, selection math. say "continue" and we fight.


Part 5 rolling — the strategy arena. this is where the statistical discipline gets its teeth: framework first, candidates second, criteria before scoring, budgets recomputed in the open. and the headliner result of this part is an honest one — the math shrinks the field to one surviving direction, and i show every step of that math so you can check my work instead of trusting my mouth. let's ride.

---

# QUANTITATIVE TRADING SYSTEM — DESIGN ENGAGEMENT

**Part 5/10**

> **یادداشت وضعیت برای مالک:** بخش ۵ از ۱۰. این بخش قلب آماری طرح است: چارچوب اعتبارسنجی، تولید گزینه‌های استراتژی، ارزیابی مقایسه‌ای، و — نکته‌ی مهم — نتیجه‌ی صادقانه‌ای که نشان می‌دهد پنجره‌ی کاربردپذیر هزینه-بهره‌وری از داده‌ی تأییدشده‌ی خودتان (C10) بسیار باریک است و فقط یک خانواده‌ی معماری از آزمون سخت جان سالم به بیرون می‌برد. همه‌ی محاسبات با واحد و روش نمایش داده شده‌اند؛ بودجه‌ی آزمون مطابق C22 بازمحاسبه شده؛ و هیچ ادعای پیش‌بینی‌ای بدون محاسبه به‌عنوان نتیجه ارائه نشده است.

**Cross-reference:** This part continues from Part 4/10 (deployment analysis, phase derivation). This part covers the §8 statistical framework, G3 option generation, G4 comparative evaluation, the §8.4/§8.6 registers, and the A6 intraday derivation (R-029). Part 6/10 will cover design synthesis: component boundaries, end-to-end flow, and data design.

---

## 18. STATISTICAL VALIDATION FRAMEWORK (§8.0–§8.3)

Per D19: the framework is a verification discipline applied **after** candidates are proposed. It is built first in this Part only because §2.1.3 mandates criteria declared before scoring — the framework *is* part of the criteria. No candidate is preemptively rejected by it, and (symmetric prohibition) no candidate is preemptively accepted: every performance sentence in this Part is either a shown calculation or a labeled hypothesis.

### 18.1 Validation protocol

1. **Candidate proposal** with explicit mechanism, required data classes, parameter register entries, and claimed causal story (why the edge might exist).
2. **Pre-registration** of the exact configuration set before evaluation (§8.4 selection field 1).
3. **Point-in-time enforcement** (§8.1): every feature's availability/knowability timestamp must be ≤ bar decision time; enforced by construction in the data layer (Part 6/10) and probed by negative control N-3 below.
4. **Chronological evaluation**: walk-forward with purge and embargo (§8.1). Derivation of embargo width: candidate lookback horizon L bars; embargo = max(L, 1) bars on each side of the validation fold boundary; purge width = L bars. This is the standard purge/embargo construction (labeled: established general principle, §4.1 category 5), parameterized by the selected candidate's L.
5. **Net-of-cost simulation** (§8.3): every evaluation reports, as separate lines — gross return, net return, risk-adjusted result, drawdown, turnover, tail exposure, capacity proxy, execution sensitivity, uncertainty. Cost model: fee range 0.05%–0.06% taker (C6 unresolved → both scenarios), maker rebate/fee per venue schedule (UNRESOLVED — not in ratified evidence; conservative branch: 0% rebate assumed), spread from per-symbol census (Part 3/10 Step 2 resolution path), slippage modeled at observed spread and at 2× spread (§8.3 sensitivity mandate), funding as tail cost term (C7: −30 bp observed clamp; ±24 bp cap refuted).
6. **Baselines** (§8.2): B-A buy-and-hold on the cohort index (equal-weight, DESIGN_JUDGMENT); B-B random entry with identical risk controls (exposure-matched); B-C single-timeframe trend baseline (the simple baseline required by §1/G3, and the natural measuring stick for S-1 below).
7. **Ablations** (§8.2): one component removed at a time from the selected candidate; a component whose removal does not materially degrade net risk-adjusted performance is removed from the design (D18).
8. **Negative controls** (§8.2): N-1 shuffled-label test (must produce null); N-2 random-parameter test (must produce null distribution); N-3 future-peeking guard (a feature timestamped beyond decision time must be caught by the PIT gate — synthetic injected violation); N-4 cross-venue-tag leakage probe (tagged research data must be unreachable from the evaluation path that governs Paper/Live promotion).
9. **Selection-bias control** (§8.4): Deflated Sharpe Ratio with unit-consistent trial count (C20: the 1.5e-2 at N=100 figure is the unit-correction reference; units = per-trial-count of evaluated configurations, not per-bar), with CSCV (combinatorially symmetric cross-validation) as corroboration; CSCV's corrected arithmetic per §5.4 (episodes-per-fold error retired; expected-max-of-N-normals anchor checked).
10. **Uncertainty reporting** (§8.3): bootstrap distributions over net returns per configuration; point estimates without intervals are prohibited in promotion evidence.
11. **Promotion**: only through the §19.4 selection procedure. Paper divergence band pre-registered in P3 (Part 4/10 §15.4).

### 18.2 Framework non-application records (§8.1 "as relevant" mandate)

| §8.1 technique | Applied? | Reason |
|---|---|---|
| Survivorship/selection bias control | Applied via universe generator rule | Universe is rule-derived (Part 3/10), not picked from known winners; delisting handling in register's failure-behavior field |
| Serial dependence / nonstationarity | Applied | Purge/embargo + walk-forward address serial structure; regime dependence handled by stress scenarios, not assumed away |
| Market impact modeling | Simplified to spread/slippage scenarios | C8 (order-book depth non-reproducible) makes depth-based impact modeling unsupported; the 5M-USDT liquidity screen bounds participation instead |
| Portfolio-level correlation adjustment | Excluded | Single-position design (see §19.3 selection consequence); correlation adjustment across concurrent positions is moot when concurrency = 1 |
| Cross-venue validation transfer | Excluded from promotion path | C18 ratifies transfer evidence at 1h/4h only; A5 legal gating unresolved; cross-venue data usable for research context only, never promotion evidence (R-018) |

---

## 19. G3 — OPTION GENERATION, G4 — EVALUATION, SELECTION

### 19.1 Candidate set (generated from requirements, not from a feature checklist)

| ID | Family | Mechanism sketch | Timeframes | Data classes | Parameter dim. |
|---|---|---|---|---|---|
| S-1 | Dual-timeframe trend-pullback | Higher-timeframe trend filter + lower-timeframe pullback entry; ATR-scaled stops; maker entries | 1h context + 15m execution | klines, funding | Low (3–6 registered) |
| S-2 | Mean-reversion at 1h+ | Overextension fade within session; volatility-scaled bands | 1h | klines, funding | Low |
| S-3 | Volatility breakout | Range compression → expansion entry | 15m–1h | klines, funding | Low–mid |
| S-4 | Bounded-ML feature model | Gradient-boosted or logistic model over hand-designed bar features | 15m–1h | klines, funding (+ derived features) | Mid–high |
| S-5 | Cross-instrument divergence | Lead-lag / correlation-breakdown signals across cohort | 1h+ | klines × N symbols | High (correlation estimation consumes budget) |
| S-6 | Simple baseline | Single-timeframe trend-following (e.g., Donchian-style) with identical risk controls | 15m or 1h | klines | Very low (1–2) |

### 19.2 Evaluation criteria (declared before scoring — from Part 1/10 checkpoint §3.4, unchanged)

C1 hard-constraint pass/fail (non-compensable); C2 statistical admissibility within §8.4; C3 envelope feasibility (D15); C4 failure-domain containment; C5 verifiability; C6 operational burden; C7 justified complexity; C8 reversibility exposure.

### 19.3 Cost-feasibility gate (calculated — the decisive quantitative screen)

This screen is C1-class (a strategy that cannot clear venue economics violates the net-value requirement in §6's objectives). Derivation chain, all values labeled:

**Step 1 — Round-trip cost (maker path, limit orders both sides):**
- Fee per side: maker fee UNRESOLVED; conservative branch 0% rebate, fee ≥ 0%. Upper bound for screen: use the **documented taker band as worst case**: 0.06% per side (C6 conservative value).
- Spread/slippage with maker entries: assume ≤ 1 tick adverse per side under queue risk; measured per symbol in census (UNRESOLVED pending census — parametric here: s_ticks × tick_value).
- Screen form: round_trip_cost ≈ 2 × fee_side + 2 × (spread_slippage_side).

**Step 2 — Required volatility to break even:**
A trade must capture price movement ≥ round_trip_cost. C10 supplies the cost-per-volatility measurement for the tested scope: 1.42 at 5m, 0.82 at 15m, and the ratified conclusion is a **maker-only floor at 15m and above** — i.e., below 15m, even maker execution does not reliably clear costs per volatility available.

**Step 3 — Consequence for the field:**
- All sub-15m primary execution timeframes (1m, 3m, 5m) fail the cost floor within the tested scope → any candidate whose *execution* decision lives at 1m/3m/5m is cost-inadmissible **within C10's stated scope** (generalization to unrelated symbols/conditions prohibited by C10's scope note — recorded as scope limitation, not silently generalized).
- This eliminates S-2 at any sub-1h variant and any 5m variant of S-1/S-3/S-4. Surviving execution timeframes: ≥15m, with C10's floor ratified at 15m+ and cost headroom increasing with timeframe.

**Step 4 — Trial-budget recomputation (C22-mandated, inline):**

Published anchors: C23 (4h: order of 10–20 after pooling; 1d: thousands pre-correction). Recomputation requirement: show effective sample size per cell.

Recomputation for the surviving candidate cell (15m execution, BTC-class liquidity cohort):
- Available bars per cell: cap 3,500 (C2, cap-not-guarantee; census PROVISIONAL pending Part 3/10 resolution path).
- Effective independent samples: bars are serially dependent; effective N < 3,500. Using the walk-forward fold structure from §18.1 with purge/embargo consuming 2L bars per fold boundary, and L ≈ 100 bars (parametric pending S-1's final lookback; shown as example): with fold width W = 500 bars, folds ≈ 7; embargo/purge overhead ≈ 2 × 100 × 7 = 1,400 bars consumed at boundaries. Net evaluation bars ≈ 2,100. Effective independent decision events further reduce by intraday serial clustering; a factor of 3–5 reduction is a standard conservative heuristic (labeled: DESIGN_JUDGMENT heuristic, not a ratified figure) → N_eff ≈ 420–700 per cell.
- N_max_effective = min(published_panel, recomputed) (C22). The published 4h panel value (10–20 configurations, PROVISIONAL per §5.4) is **not** directly applicable to the 15m cell — different timeframe, and the published figure is flagged PROVISIONAL. Recomputed 15m budget: with N_eff ≈ 420–700 decision events, the Deflated-Sharpe-consistent admissible trial count at moderate confidence (per the DSR construction referenced by C20) supports **on the order of 10–30 pre-registered configurations per cell**, labeled DERIVED-with-heuristic, PROVISIONAL pending P0 data census and final L. The >2× discrepancy rule (C22): published 10–20 vs recomputed 10–30 — within 2×, so min applies: **operative budget = 10–20 configurations per cell, PROVISIONAL**. Discrepancy recorded per C22.
- Cross-check at 4h for context: recomputed N_eff at 4h (fewer bars per unit time, ~3,500 cap = ~583 days at 6 bars/day): decision events ≈ 3,500 bars → after serial-reduction heuristic ≈ 700–1,150; supports a similar or slightly larger budget than published 10–20 → consistent, no discrepancy flag. C24 honored throughout: no exhaustive grid at ≤12h; the selected optimizer form is **small pre-registered hypothesis set** (§8.4's first listed alternative), chosen in §19.4 with criteria.

**Step 5 — Sizing feasibility (parametric, D17):**

Minimum viable position vs venue minimums: Toobit minimum order notional per symbol is UNRESOLVED (not in ratified evidence; resolution: public symbol-metadata census alongside the Part 3/10 volume census — no credentials needed). Parametric expression:

```
notional_per_trade = (E × r_trade) / (s / 10,000)
E ∈ [200, 500] USDT; r_trade = OWNER_DECISION_PENDING; s = stop distance in bp (strategy-derived).
```

Sensitivity demonstration (r_trade ∈ {0.5%, 1%, 2%, 5%, 10%}, E = 200, s = 50 bp — s illustrative, strategy-final in P1):

| r_trade | E×r_trade (USDT) | s=50bp → notional (USDT) | Leverage vs E | vs. 5M-USDT liquidity screen (0.1% of median) |
|---|---|---|---|---|
| 0.5% | 1.00 | 200 | 1.0× | 200 / 5,000,000 = 0.004% ✓ |
| 1% | 2.00 | 400 | 2.0× | 0.008% ✓ |
| 2% | 4.00 | 800 | 4.0× | 0.016% ✓ |
| 5% | 10.00 | 2,000 | 10.0× | 0.04% ✓ |
| 10% | 20.00 | 4,000 | 20.0× | 0.08% ✓ |

Arithmetic verification: notional = (E × r) / (s/10,000) = (200 × 0.005) / 0.005 = 200 USDT at 0.5%; (200 × 0.10)/0.005 = 4,000 at 10%. ✓ Leverage column = notional/E. All five rows clear the 0.1% liquidity screen with ≥25× headroom (screen bound 5,000 USDT from Part 3/10). The 5% row (2,000 USDT at 10×) is within the C3 ladder's existence (13 tiers to 1.0×) but the maximum permitted leverage per symbol/account remains UNRESOLVED (C3 scope) — carried as a Live-entry verification item, not assumed. **No row is endorsed; the table demonstrates sensitivity per D17 mandate.**

**Step 6 — Single-position consequence:** At E ∈ [200, 500], capital concentration logic: any multi-position concurrent book splits the already-small risk budget into fragments where per-position notional approaches venue minimums, degrading net expectancy after fees. DESIGN_JUDGMENT (positive derivation from A11 scale + C6/C10 cost structure): **the design trades at most one position at a time.** This is revisitable if equity grows beyond the planning range; recorded in the parameter register (P-09) with a recalibration trigger.

### 19.4 G4 comparative scoring

Hard gates first (C1): S-2 (sub-1h variants), any 5m execution variant — eliminated by cost-feasibility gate §19.3 Step 3 (scope-limited per C10). S-5: C2-adjacent failure — correlation estimation across a ≥5-symbol cohort consumes trial budget multiplicatively (estimation windows × pairs), and C18/C26 constrain cross-instrument evidence quality; with the §19.3 budget (10–20 configurations), S-5's parameter+estimation dimensionality cannot be admitted without exhausting budget before signal evaluation. Eliminated with positive reason recorded (D13): the requirement it would serve (edge quality) is unattainable within the binding budget, not "the prompt disfavored it."

| Criterion (weight-free, hard gates already applied) | S-1 trend-pullback (1h/15m) | S-3 vol breakout (15m–1h) | S-4 bounded-ML | S-6 baseline (single-TF trend) |
|---|---|---|---|---|
| C2 budget fit (10–20 configs) | PASS — 3–6 registered params leave budget headroom for ablations | PASS — similar | MARGINAL — feature-selection iterations consume budget; ML hyperparameters compound | PASS — ample |
| C3 envelope | PASS — O(1) bar updates | PASS | MARGINAL — training runs hit E-5 (Part 4/10's unproven component) | PASS |
| C4 failure containment | PASS — no state beyond positions/params | PASS | WEAK — model staleness, feature-drift failure modes | PASS |
| C5 verifiability | PASS — deterministic rules, replayable | PASS | WEAK — model behavior requires distributional tests | PASS |
| C6 operational burden | PASS | PASS | FAIL-class burden: retraining governance via Telegram-only ops (A2) is heavy | PASS |
| C7 justified complexity | Increment over S-6 must survive ablation (§18.1 item 7) | Same | Complexity buys unproven increment — §9.10 mandates rejection unless incremental value justifies burden; no evidence it does | Reference |
| C8 reversibility | REVERSIBLE (config swap) | REVERSIBLE | COSTLY (model artifacts, feature store) | REVERSIBLE |

**Selection: S-1 (dual-timeframe trend-pullback, 1h context / 15m execution), with S-6 as the standing baseline and ablation reference.** Positive derivation: S-1 is the minimal-complexity candidate that (a) clears the C10-derived cost floor (15m execution), (b) fits the recomputed trial budget with ablation headroom, (c) operates within the device envelope's proven components, (d) is fully verifiable deterministically, and (e) preserves REVERSIBLE status. S-3 remains the documented strongest alternative — rejected on C5/C7 grounds (breakout false-signal sensitivity requires wider parameter search to characterize than the budget admits) — and S-4 rejected per §9.10's explicit mandate (zero autonomous learning acceptable; ML burden unjustified by any evidence in this engagement). If P1 ablations show S-1's higher-timeframe filter contributes nothing, the design degrades gracefully to S-6 — this is pre-registered as the ablation response, not improvised later.

**Intraday definition (R-029 derivation):** maximum holding duration = **one UTC trading day** (positions flat by 23:59:59 UTC or at session-defined cutoff; weekend/policy handling for 24/7 perp markets: flat-by-boundary applies to rolling 24 h UTC windows). Derivation chain: A6 intraday intent (owner) + funding tail risk (C7: −30 bp observed, unbounded by the refuted cap — holding through funding events is a tail-cost exposure the strategy does not need) + the 15m/1h decision cadence (multiple decision cycles per day exist at 15m granularity). The definition is strategy-linked (funding avoidance + cadence), not an invented fixed number. DESIGN_JUDGMENT, revisitable at P1 if evidence shows multi-day holds dominate net of funding — that revision path is recorded, not hidden.

### 19.5 Selection procedure declaration (§8.4 — all seven mandatory fields)

| Field | Content |
|---|---|
| Searched configurations | Pre-registered set of ≤15 configurations for S-1 (generator: trend-window ∈ {pre-registered small set}, pullback-depth ∈ {set}, stop-multiple ∈ {set}; exact enumeration fixed in P1 pre-registration document before any evaluation). Plus S-6 baseline (≤3 configs) and §18.1 ablations (≤6). Total ≤24 — vs budget 10–20 per cell: **budget conflict flagged honestly** → resolution: pooling across the symbol cohort within a cell (C23 permits pooling, limited by cross-cell dependence); effective configuration count per pooled evaluation stays ≤20. Final enumeration is a P0/P1 artifact; this design commits the *rule*, not the hidden list |
| Effective sample size | N_eff ≈ 420–700 per cell (recomputation §19.3 Step 4; PROVISIONAL pending census and final L) |
| Assumptions | Serial dependence handled by purge/embargo; cross-cell dependence limits pooling (C23); costs per §18.1 item 5; stationarity not assumed — walk-forward only |
| Stopping rule | Evaluation halts when the pre-registered set is exhausted or the budget is reached, whichever first; no configuration may be added after first evaluation (pre-registration binding) |
| Selection-bias control | Deflated Sharpe Ratio, unit-consistent trial count (C20), corroborated by CSCV; promotion threshold: DSR > 0 with the selected configuration's bootstrap CI excluding the baseline's net performance — labeled DERIVED from §8.4 methods; exact threshold parametric pending P1 variance measurement |
| Promotion policy | Candidate must beat S-6 baseline net-of-cost in out-of-sample walk-forward folds, survive all ablations materially, pass N-1/N-2/N-3/N-4, and show bootstrap uncertainty consistent with the pre-registered band; then Paper (P3) with pre-registered divergence tolerance |
| Rollback policy | Paper divergence beyond band → retire to P1; Live drawdown hitting the owner-defined limit (pending) → risk-authority halt; drift monitors (feature/outcome distribution shifts, defined Part 7/10) → re-evaluation trigger; retired configurations archived with full provenance, never silently reused |

### 19.6 Parameter register (§8.6 — material dynamic parameters)

Full 16-field register for the parameters the selected architecture actually owns. (Fields stated compactly per row but none omitted.)

**P-01 trend_lookback (1h):** bars; context-trend window; source: calibration within pre-registered set; domain 20–200 bars; estimation: pre-registered grid point; search budget: within the ≤15 S-1 configurations; objective: net risk-adjusted return vs baseline (never a risk limit); constraints: ≤ available depth (C2); calibration data: train folds only; validation: walk-forward OOS; uncertainty: bootstrap CI; applicability: cohort-wide with per-cell verification; promotion: §19.5; rollback: ablation failure; recalibration: drift trigger or scheduled P1 re-run.

**P-02 pullback_depth (15m):** fraction of ATR; entry trigger depth; calibration; domain 0.25–1.5 ATR; budget: within S-1 set; objective: as P-01; constraints: ≥ venue tick granularity; calibration/validation/uncertainty/applicability/promotion/rollback/recalibration: as P-01.

**P-03 stop_atr_multiple:** ATR multiples; protective-stop distance; calibration; domain 1.0–3.0; budget: within S-1 set; constraints: stop distance ≥ max(tick, fee-clearance floor from §19.3); rest as P-01.

**P-04 session_flat_cutoff:** UTC time; forced-flat boundary; source: derived from R-029 (one UTC day); domain {rolling-24h boundary}; estimation: fixed by derivation (not searched — excluded from budget); objective: funding/tail avoidance; constraints: must precede funding timestamps by a buffer ≥ 1 bar; calibration data: n/a; validation: P3 observation; uncertainty: n/a (rule, not estimate); applicability: all cells; promotion: design-level; rollback: P1 evidence of multi-day dominance; recalibration: funding-regime shift.

**P-05 max_daily_new_positions:** count; per-day entry throttle; DESIGN_JUDGMENT initial 3 (derivation: bounds daily fee drag at small equity); domain 1–10; estimation: owner-adjustable within guardrail; budget: excluded from search (safety-adjacent, set conservatively); objective: cost containment; constraints: ≥1; calibration: P3 observation; validation: Paper; uncertainty: n/a; applicability: global; promotion: with strategy; rollback: raise only via config change with audit (R-013); recalibration: cost-model revision.

**P-06 data_staleness_threshold:** seconds; bar-arrival freshness limit; DERIVED: 2 × bar interval (15m → 1,800 s); estimation: fixed by derivation; constraints: ≥ 1 interval; objective: data-validity interlock; validation: M-01; rollback: n/a (safety rule); recalibration: venue behavior change.

**P-07 funding_avoidance_window:** seconds before funding timestamp; flat-or-no-new-entry window; DERIVED from venue funding schedule (schedule UNRESOLVED → window parametric: W ≥ 1 bar; resolution: public funding-schedule census); rest as P-04.

**P-08 slippage_assumption_ticks:** ticks; execution-cost model parameter; source: census measurement; domain 1–5; estimation: measured median + 2× scenario (§8.3); budget: excluded (measurement, not search); objective: honest cost model; calibration data: order-book/trade prints census; validation: P3 fill comparison; uncertainty: distribution reported; applicability: per-symbol; promotion: with cost model; rollback: n/a; recalibration: monthly re-census (DESIGN_JUDGMENT cadence).

**P-09 single_position_flag:** boolean; concurrency cap; DESIGN_JUDGMENT (§19.3 Step 6); fixed; recalibration trigger: equity beyond planning range.

**P-10 reconciliation_interval:** seconds; ledger-vs-exchange check cadence; DESIGN_JUDGMENT 300 s live / on-event; constraints: ≤ OUTAGE_RECON_DEFERRAL class bounds (C12 provisional 3-day governs deferral escalation only); validation: P2 drills; rollback: n/a; recalibration: venue behavior.

**P-11 risk_fraction_per_trade:** fraction of equity; **source: OWNER_DECISION_PENDING (§3.3)**; domain: owner-set within presented range; estimation: owner decision after Part 7/10 briefing; search budget: **zero — excluded from all optimization** (§8.5: hard limits are not hyperparameters); objective: n/a; constraints: >0, ≤ owner-set maximum; calibration: none; validation: interlock check; uncertainty: n/a; applicability: global; promotion/rollback: owner-gated; recalibration: owner decision only.

**P-12 drawdown_limit_fraction:** fraction of initial equity; OWNER_DECISION_PENDING; all fields as P-11.

**P-13 daily_loss_limit_fraction:** as P-11/P-12.

UNRESOLVED-field check (§8.6 mandate): P-11/12/13 carry OWNER_DECISION_PENDING — safe fallback exists (system defaults to no-Live without owner-set values; Paper runs parametric), so they are admissible with fallback, and the fallback does not depend on the unresolved field. P-07's venue funding schedule is UNRESOLVED with census resolution path; fallback = no-new-entries around observed funding timestamps from P0 data (does not depend on the unresolved schedule). No BLOCKED-parameter condition exists. ✓

### 19.7 MinTRL/DSR unit-discipline note (C20/C21)

If MinTRL is reported in P1, it will use the ratified corrected form (C21: 19.54 yr reference; MinTRL ≠ MinBTL; arithmetic shown). DSR uses unit-consistent trial counts (C20). Both are validation outputs, not design drivers (D19). No value from C20–C24 is quoted in this design without the §19.3-style recomputation shown adjacent. ✓

---

## 20. ARTIFACT REGISTRY — updated

| ID | Artifact | Phase | Ref | Status | Description |
|---|---|---|---|---|---|
| ART-01..07 | (Parts 1–2 artifacts) | 1–2 | — | DELIVERED | Unchanged |
| ART-08 | Universe derivation (D14) | 3 | 3/10 §10 | DELIVERED | 134-symbol PROVISIONAL cohort |
| ART-09 | Storage/compute + measurement protocol | 3 | 3/10 §11 | DELIVERED | Bounds + M-01–M-06 |
| ART-10 | Deployment analysis (D15) | 4 | 4/10 §14 | DELIVERED | T-1 conditional selection |
| ART-11 | Phase derivation (D16) | 4 | 4/10 §15 | DELIVERED | P0–P4 |
| ART-12 | Statistical validation framework | 5 | 5/10 §18 | DELIVERED | Protocol, baselines, ablations, negative controls |
| ART-13 | Option generation + evaluation (G3/G4) | 5 | 5/10 §19.1–19.4 | DELIVERED | S-1 selected; S-3 documented strongest alternative; cost gate math shown |
| ART-14 | Selection procedure + parameter register | 5 | 5/10 §19.5–19.6 | DELIVERED | 7-field procedure; P-01–P-13 with 16 fields each |
| ART-15 | Trial-budget recomputation (C22) | 5 | 5/10 §19.3 Step 4 | DELIVERED | Inline recomputation; min-rule applied; discrepancy recorded |
| ART-16 | Intraday operational definition (R-029) | 5 | 5/10 §19.4 | DELIVERED | One-UTC-day derivation chain |

---

## 21. PART COMPLETENESS DECLARATION (Part 5/10)

Part 5/10 is complete for its declared scope (§8 framework with non-application records; G3 with six candidates including the §1-mandated simple baseline; G4 with pre-declared criteria; the decisive cost-feasibility calculation chain; C22-compliant inline trial-budget recomputation with min-rule and discrepancy record; the seven-field selection procedure; the 13-parameter register with full field sets; R-029 intraday derivation). **Content deferred:** exact pre-registered configuration enumeration (P0/P1 artifact by design — the *rule* is committed here, the list cannot exist before the depth census without violating point-in-time discipline); venue minimum-notional and funding-schedule census values (UNRESOLVED with resolution paths stated — the legitimate escape, not deferral-by-summary). Arithmetic verified in-line: sizing table recomputed cell-by-cell; budget recomputation steps shown; D17 parametric discipline maintained — no owner-pending risk value adopted anywhere, and the sensitivity table presents all five risk fractions without endorsement. **Honest-limitation statement (D19 symmetric discipline):** S-1 is selected as the *architecture to validate*; no performance claim is made for it. Every performance assertion in this Part is labeled hypothesis, derivation, or measurement-specification. If P1 shows S-1 failing its promotion policy, the design's honest output is the no-candidate report defined in Part 4/10 §15.4 — that outcome is a success of the validation process, not a defect of this design.

**Cross-reference:** Part 6/10 follows: design synthesis — component boundaries with full 11-field specifications (§9.2), end-to-end flow with authoritative-state ownership (§9.3), and complete data design with the 14-field per-input records and missing/stale/duplicate/malformed/contradictory/unavailable rules (§9.4–9.5), including C13 and C26 handling.

---

Arena's done, and i'll say it plain: the math was brutal to the field. your own C10 data squeezed the viable window down to 15-minute-plus execution, the trial budget recomputed to ten-to-twenty configs, and the ML candidate died on its own governance burden, not on my mood. what survives is lean, checkable, and honest. part 6 builds the machine's bones next. say "continue."


Part 6 rolling — the machine's bones. every component gets its eleven fields, every data input gets its fourteen, and every byte of state gets exactly one authoritative owner. no magic gaps, no orphan state, no dangling "and then it works." this is where the design stops being an argument and starts being a blueprint.

---

# QUANTITATIVE TRADING SYSTEM — DESIGN ENGAGEMENT

**Part 6/10**

> **یادداشت وضعیت برای مالک:** بخش ۶ از ۱۰. این بخش ساختار داخلی سیستم را مشخص می‌کند: مرزهای اجزا با تمام ۱۱ فیلد اجباری، جریان سرتاسری با مالکیت قطعی هر کمیت حالت، و طراحی داده با ۱۴ فیلد برای هر ورودی. انتخاب زبان و زمان‌اجرای پیشنهادی (Python) با دلیل مثبت و برچسب قضاوت طراحی آمده و قابل‌تغییر است. تعارض شناخته‌شده‌ی C13 و وضعیت حل‌نشده‌ی C26 صریحاً مدیریت شده‌اند.

**Cross-reference:** This part continues from Part 5/10 (statistical framework, S-1 selection, selection procedure, parameter register). This part covers G5 design synthesis: §9.2 component boundaries, §9.3 end-to-end flow with state authority, §9.4 data design, §9.5 data-quality rules. Part 7/10 will cover risk authority, order lifecycle, Telegram contract, and security/operations.

---

## 22. COMPONENT BOUNDARIES (§9.2)

**Delegation disclosure (A12):** programming language, runtime, framework, and library choices are delegated to the model. Selection made here: **Python 3.12+, asyncio, SQLite (WAL mode), python-telegram-bot v22+ (pinned), pydantic v2+ (pinned)**. Positive derivation (D13): Termux provides a first-class CPython/aiohttp environment without cross-compilation friction (established platform fact, labeled as §4.1 category-5 general knowledge); the I/O-bound workload (§14.1 E-1/E-3) maps naturally onto a single asyncio loop with ordered task-group supervision; SQLite WAL satisfies the Part 3/10 crash-consistency requirement with atomic commits and a single-file artifact compatible with on-device backup. Criterion C8 (reversibility): the component boundaries below are logical; language is a COSTLY_REVERSIBLE implementation commitment — the boundary contracts, not the language, carry the design. **Any equivalent implementation satisfying these contracts is conformant.**

**Process topology:** single-process modular monolith (logical components below; one process, one asyncio loop). Derivation: §9.2's rule — separate processes are justified only by a requirement-level need for independent failure domains or deployment units; none exists at T-1. The Part 1 checkpoint's multi-process alternative is rejected with positive reason: inter-process failure modes (orphan states, split-brain ledgers) add failure surface that no requirement purchases.

**Identifier catalog statement (§14):** component identifiers CMP-01..CMP-10 are defined exactly once, here. Later parts cite them.

---

**CMP-01 — DataIngester**
- Purpose: acquire venue and permitted-source market data and deliver validated, timestamped records.
- Responsibilities: WebSocket/REST kline ingestion; funding schedule/event ingestion; symbol metadata refresh; source-tag stamping at ingestion (R-018).
- Non-responsibilities: no feature computation; no storage-engine administration; no cross-venue promotion decisions.
- State ownership: ingestion cursors (last-confirmed bar open-time per cell); in-memory subscription registry.
- Inputs: venue public streams/polls; source policy config.
- Outputs: validated `MarketEvent` records → CMP-04; gap/staleness signals → CMP-07.
- Dependencies: venue API; CMP-04 contract; clock service (CMP-09).
- Timing assumptions: per-message processing ≤100 ms p99 (§14.1 E-1); backpressure by bounded queues; on overflow, oldest-untouched cells degrade with alerts (never silent drop).
- Failure behavior: stream loss → reconnect with bounded backoff (same budget discipline as orders, C4/C5); staleness beyond P-06 → data-validity degradation event.
- Verification: M-01; schema tests; gap-injection fixtures (P0 exit).
- Interface contract: `MarketEvent{symbol, interval, bar_open_time_utc, bar_close_time_utc, availability_time_utc, ohlcv fields, funding fields?, source_tag, schema_version}` — all timestamps carry semantic roles per R-005.

**CMP-02 — FeatureEngine**
- Purpose: transform validated market data into deterministic, point-in-time features for the selected strategy (S-1) and its baseline (S-6).
- Responsibilities: ATR computation; trend-window state (P-01); pullback-depth state (P-02); regime context at 1h; feature provenance stamping.
- Non-responsibilities: no signal decisions; no parameter mutation; no storage ownership.
- State ownership: rolling window buffers per cell (memory); no persistent state (reconstructible from CMP-04 data — DESIGN_JUDGMENT, rationale: single source of truth).
- Inputs: MarketEvents (CMP-04); parameter register values (CMP-08).
- Outputs: `FeatureVector{cell, bar_open_time_utc, availability_time_utc, features{...}, param_version}` → CMP-03.
- Dependencies: CMP-04; CMP-08; CMP-09.
- Timing: O(1)–O(window) per bar (§14.2 E-3 bound B); recomputation-on-restart from CMP-04.
- Failure behavior: malformed input quarantined (§9.5); computation error → cell halted for decisioning, alert emitted, never guessed values.
- Verification: deterministic replay (same inputs → same vectors, §11.2); N-3 future-peeking guard.
- Interface contract: pure function surface `update(cell, event) -> FeatureVector | Quarantine`.

**CMP-03 — StrategyEngine (S-1 + S-6 baseline runner)**
- Purpose: convert feature vectors into order intents under the selected strategy's rules.
- Responsibilities: S-1 rule evaluation (trend filter at 1h; pullback entry at 15m; ATR stops per P-03); session-flat enforcement (P-04); funding-window suppression (P-07); single-position discipline (P-09); baseline shadow-running in research phases.
- Non-responsibilities: no sizing against risk limits (that is CMP-05's veto domain); no order submission; no parameter self-modification.
- State ownership: per-cell strategy state machine (flat / armed / in-position / exit-pending); persisted transitions via CMP-04 (event log).
- Inputs: FeatureVectors; current authoritative position (CMP-06); config (CMP-08).
- Outputs: `OrderIntent{intent_id, cell, side, qty, order_type, limit_price?, stop_price?, time_in_force, param_version, strategy_version, created_utc}` → CMP-05.
- Dependencies: CMP-02, CMP-05 (read model), CMP-06, CMP-08, CMP-09.
- Timing: decision latency ≤ 5 s budget share (§14.1 E-3).
- Failure behavior: unknown/ambiguous state → no new intents (fail-closed); intent generation is idempotent per (cell, bar) via deterministic intent_id derivation (see C11 charset constraint honored at CMP-05 translation).
- Verification: deterministic replay; golden-fixture tests from P1 data; property test: no intent when session-flat or funding-window active.
- Interface contract: as typed above; intents are immutable once emitted (corrections are new intents superseding old, recorded).

**CMP-04 — DataStore**
- Purpose: durable, crash-consistent persistence of market data, events, ledgers, configs, and audit records.
- Responsibilities: SQLite WAL schema ownership; atomic commits; integrity checks (PRAGMA integrity_check cadence); backup snapshots; schema versioning; source-tag preservation.
- Non-responsibilities: no business logic; no validation semantics (ingester validates; store persists).
- State ownership: **authoritative** for market-data history, event log, audit log, config versions, risk-state ledger (positions/orders authoritative at exchange; internal ledger is the designed replica — see §23 authority table).
- Inputs: records from CMP-01/02/03/05/06/07/10.
- Outputs: reads for all components; snapshot files for backup.
- Dependencies: filesystem; CMP-09.
- Timing: batched commits; WAL checkpointing on cadence; commit latency bounded to protect E-1.
- Failure behavior: corruption detected → refuse writes, CRIT alert, enter degraded-read-only; restore from snapshot per Part 7/10 procedure (STOPPED-state procedure; see procedural-consistency table in Part 7/10).
- Verification: M-04 (kill -9 mid-write), M-06 (storage pressure), integrity-check tests.
- Interface contract: versioned SQL schema + migration table; all timestamps UTC with semantic-role columns.

**CMP-05 — RiskAuthority**
- Purpose: independent veto authority over every order intent and mode transition.
- Responsibilities: evaluate intents against hard limits (per-trade budget P-11 once owner-set; daily loss P-13; drawdown P-12; aggregate exposure = single-position rule P-09; notional/leverage bounds vs C3 tier table; liquidity-screen conformance); evaluate six Live interlocks (with CMP-06/07/08/09/10 inputs); maintain veto registry with recovery conditions; enforce unknown→veto rule (R-010).
- Non-responsibilities: no alpha opinion; no limit tuning; no order modification — approve or veto only.
- State ownership: risk-state ledger fields (drawdown-from-peak, daily realized loss, exposure ledger) persisted via CMP-04; **on missing/corrupt ledger: unevaluable → HARD_VETO + CRIT alert; never initialized from current market/account values** (§9.6 fail-open prohibition).
- Inputs: OrderIntents (CMP-03); authoritative state (CMP-06); config (CMP-08); clock (CMP-09); data-validity (CMP-07).
- Outputs: `RiskDecision{intent_id, APPROVE|VETO, veto_class, reason_code, evaluated_state_hash, decided_utc}`; interlock results.
- Dependencies: CMP-04, CMP-06, CMP-07, CMP-08, CMP-09.
- Timing: decision within the 5 s budget; veto path takes precedence over approval path under resource contention (DESIGN_JUDGMENT: fail-safe scheduling).
- Failure behavior: any evaluation error = VETO; any missing input = VETO; veto vs acknowledgement separation per §9.6 (veto clears only on underlying-condition recovery; /ack is a post-recovery resume gate, refused while condition fails).
- Verification: invariant test "no approval path bypasses evaluation"; fault-injection on each input; P2 drills.
- Interface contract: pure evaluation function + persisted decision log entry per intent.

**CMP-06 — ExecutionEngine**
- Purpose: translate approved intents into venue order actions and track the complete order lifecycle.
- Responsibilities: client order ID generation (C11 charset, uniqueness per scope); bounded retry with backoff and hard stop (C4 explicit weight accounting, no header reliance); -1007 TIMEOUT ambiguity protocol (C5: never auto-resubmit; mark TIMEOUT_AMBIGUOUS; reconcile before further action on that intent); partial-fill tracking; cancel/fill race handling; protective-order placement (stop per P-03) as reduce-only; crash-mid-order recovery via reconciliation (with CMP-07).
- Non-responsibilities: no risk evaluation; no strategy logic; no config mutation.
- State ownership: order state machine instances (states defined in Part 7/10 catalog); in-flight intent registry.
- Inputs: RiskDecision APPROVE (CMP-05); venue order/trade streams; reconciliation inputs (CMP-07).
- Outputs: order actions to venue; lifecycle events → CMP-04; state updates → CMP-07 reconciliation.
- Dependencies: venue private API (Paper: simulator implementing identical contract); CMP-04, CMP-05, CMP-07, CMP-09.
- Timing: submission within budget share; retry budgets per C4/C5 (finite, e.g., initial backoff 1 s ×2, budget ≤ 5 attempts, hard stop → escalation; values DESIGN_JUDGMENT, tunable via config within bounds, audit-logged).
- Failure behavior: any ambiguity → freeze intent, alert, reconcile; never duplicate an ambiguous order (idempotency by client ID + reconcile-before-resubmit).
- Verification: P2 transition-coverage tests; race injection; -1007 simulation; Paper fill comparison (P-08 validation).
- Interface contract: venue adapter interface `place/cancel/query/stream` with identical signatures for live adapter and paper simulator (test seam per §9.2).

**CMP-07 — Reconciler**
- Purpose: prevent and repair divergence between internal ledger and exchange state.
- Responsibilities: periodic reconciliation (P-10 cadence) of positions, open orders, balances, fills; on-mismatch: halt entries (HARD_VETO via CMP-05 input), classify mismatch, drive resolution workflow; OUTAGE_RECON_DEFERRAL escalation at the C12 provisional 3-day bound (deferral escalation only — not a retention claim).
- Non-responsibilities: no order placement; no risk-limit definition.
- State ownership: reconciliation reports; mismatch registry; last-good-snapshot references.
- Inputs: venue account reads (CMP-06 adapter); CMP-04 ledger; CMP-09.
- Outputs: reconciliation status → CMP-05 (interlock input), CMP-10 (alerts), CMP-04 (records).
- Dependencies: CMP-04, CMP-06, CMP-09.
- Timing: P-10 interval + event-triggered (post-recovery, post-ambiguity).
- Failure behavior: unable-to-reconcile = fail-closed for entries; exits/protective orders continue (never strand risk).
- Verification: P2 reconciliation drills (injected divergences: phantom fill, missing fill, partial fill, duplicate cancel).
- Interface contract: `ReconcileReport{mismatches[], authoritative_values{}, ledger_values{}, resolution_actions[], status}`.

**CMP-08 — ConfigManager**
- Purpose: versioned, integrity-checked, audit-logged configuration.
- Responsibilities: config schema validation (pydantic); version stamps on every decision record; change application with dual-confirmation for privileged classes; config-integrity interlock evaluation (hash comparison, drift detection); parameter register enforcement (P-01..P-13 domains; owner-pending fields blocked from Live until set).
- Non-responsibilities: no strategy logic; no silent defaults for safety-relevant values.
- State ownership: config versions (persisted CMP-04); active config (memory, validated on load).
- Inputs: operator commands (CMP-10); parameter promotion artifacts (P1 pipeline).
- Outputs: active config → all components; integrity status → CMP-05 interlocks.
- Dependencies: CMP-04, CMP-09, CMP-10.
- Timing: config changes are stop-the-world events for affected components (DESIGN_JUDGMENT: simplicity over hot-reload cleverness at this scale).
- Failure behavior: invalid config rejected with explicit errors; integrity failure → Live interlock fail.
- Verification: schema tests; tamper-injection test (modified config must fail integrity).
- Interface contract: versioned config document; change events logged with operator identity.

**CMP-09 — ClockService**
- Purpose: authoritative UTC wall-clock semantics + monotonic deadlines, with offset-health monitoring (R-005).
- Responsibilities: UTC wall time for instants; monotonic clock for elapsed deadlines; periodic offset estimation (venue server time vs device clock); staleness/excess-offset behavior (clock interlock; beyond tolerance → Live refuse + alert; tolerance value DESIGN_JUDGMENT initial 2 s, config-bounded, audit-logged).
- Non-responsibilities: no scheduling logic for strategy (components consume its API).
- State ownership: offset estimate; last-sync metadata.
- Inputs: device clocks; venue server-time endpoint (public).
- Outputs: `now_utc()`, `monotonic()`, `OffsetHealth{offset_ms, age_s, status}` → CMP-05 (interlock), all components.
- Dependencies: device clocks; venue time endpoint.
- Failure behavior: sync failure → last-known offset with age flag; age beyond threshold → degraded status → interlock consequence.
- Verification: skew-injection tests (P2); unit tests for semantic-role correctness.
- Interface contract: as above; no component may call raw system time directly (enforced by code review + lint rule, DESIGN_JUDGMENT mechanism).

**CMP-10 — TelegramGateway**
- Purpose: sole operator interface (A2) — commands, alerts, acknowledgements, read-only review.
- Responsibilities: long-polling transport (A9: no inbound connectivity assumed); command parsing/validation as untrusted input (injection/replay/rate-limit protection); operator authentication (allowlisted chat ID + per-command confirmation for privileged acts); alert dispatch with delivery-status tracking; complete privileged-action audit feed to CMP-04.
- Non-responsibilities: no safety authority (§9.9); no risk evaluation; no state ownership beyond outbound queue.
- State ownership: outbound alert queue (persisted via CMP-04 until delivered-or-expired); command receipts.
- Inputs: operator messages; alerts from CMP-05/06/07/04/01.
- Outputs: parsed commands → CMP-08/03/05/06 per command contract (Part 7/10); alerts → operator.
- Dependencies: Telegram Bot API; CMP-04, CMP-08, CMP-09.
- Timing: polling cadence battery-aware (DESIGN_JUDGMENT: adaptive 1–5 s idle, immediate on activity; measured in M-01); alert priority lanes (CRIT preempts).
- Failure behavior: Telegram unavailable → system safety unaffected (A9/§9.9); alerts queue with expiry semantics; on reconnect, deliver CRIT-first digest, suppress stale noise.
- Verification: security tests (replay, injection, rate-limit abuse, wrong-chat rejection); delivery-queue tests; M-01 endurance.
- Interface contract: command contract defined in Part 7/10 (§26) with per-command precondition lists per the §9.9 evaluability rule.

---

## 23. END-TO-END FLOW AND STATE AUTHORITY (§9.3)

**Flow (Live path; Paper identical with simulator adapter):**
1. CMP-01 ingests → validates → stamps (source_tag, availability_time) → CMP-04 persists → FeatureVectors via CMP-02.
2. CMP-03 evaluates S-1 → emits immutable OrderIntent (param/strategy versions stamped).
3. CMP-05 evaluates intent against risk-state ledger + limits → APPROVE/VETO logged with state hash.
4. CMP-06 (on APPROVE only) assigns C11-conformant client ID → submits → lifecycle machine tracks to terminal state or ambiguity → protective orders placed reduce-only.
5. CMP-07 reconciles ledger vs exchange on cadence and on events → status feeds CMP-05 interlocks.
6. CMP-04 records every step; CMP-10 alerts per catalog; CMP-08 versions every input config; CMP-09 timestamps everything with semantic roles.

**State-authority table (mandatory per state quantity):**

| State quantity | Authoritative owner | Replicas/caches | Validation of replica | On validation failure | Reconciliation trigger |
|---|---|---|---|---|---|
| Open positions (Live) | Exchange account state | Internal ledger (CMP-04) + CMP-06 memory | CMP-07 comparison per P-10 | Halt entries (HARD_VETO); mismatch workflow | Cadence + post-ambiguity + post-recovery |
| Open orders | Exchange | CMP-06 state machines | CMP-07 order-list diff | Freeze affected intent; resolve per mismatch class | Same |
| Balances/margin | Exchange | CMP-04 ledger | CMP-07 | Same | Same |
| Realized PnL | Exchange (fills) | CMP-04 ledger | CMP-07 fill-diff | Same | Same |
| Risk-state ledger (drawdown, daily loss, exposure) | CMP-05 ledger (CMP-04-persisted) — by design authority, since venue knows nothing of owner limits | None (single writer) | Startup integrity check + hash chain | Missing/corrupt → unevaluable → HARD_VETO + CRIT; never initialized from market values (R-010) | On startup, on write failure, on P-10 cadence |
| Market data history | CMP-04 (post-validation) | CMP-02 buffers | Rebuild check vs stored bars | Quarantine cell; alert | On gap detection, on restart |
| Config | CMP-08 active version (CMP-04-persisted) | Component read caches | Hash comparison at load + interlock | Live interlock fail; refuse privileged commands | On load, on change |
| In-flight intent state | CMP-06 | CMP-04 event log | Rebuild vs venue query on recovery | TIMEOUT_AMBIGUOUS protocol (C5) | Post-recovery always |

Silent-divergence prevention: every replica has a named authority, a validation method, a failure behavior, and a trigger — the four elements §9.3 requires. No cache exists without all four. ✓

---

## 24. DATA DESIGN (§9.4) — per-class evaluation and 14-field records

### 24.1 Inclusion/exclusion evaluation (five criteria per class)

| Data class | Incremental value | Availability | Cost | Correctness risk | Consequence of absence | Verdict |
|---|---|---|---|---|---|---|
| Klines (venue) | Strategy core (S-1/S-6) | A1/C1/C2 | ~9–18 GB envelope (Part 3/10) | Managed via §9.5 rules | No strategy exists | **INCLUDE** |
| Funding rates/schedule | Tail-cost avoidance (C7); P-04/P-07 | Venue public endpoints; schedule UNRESOLVED → census | ≤6 GB upper bound (Part 3/10) | Schedule semantics must be verified | Unbounded funding exposure in holds | **INCLUDE** (with P-07 fallback: observe-then-avoid) |
| Mark price | Liquidation-adjacent monitoring | Venue; **C13 semantics CONFLICTED** | Trivial | C13 — disputed field semantics | Reduced monitoring fidelity | **INCLUDE as monitoring-only, semantics-independent**: used solely as "venue-reported reference price for risk display," never as a computed-return input; any feature needing mark-return computation is **excluded** pending C13 resolution (§5.1 mandate: fallback not depending on disputed semantics) |
| Open interest | Potential regime feature | **C26: historical OI UNRESOLVED** | — | Unverifiable history | Loss of a non-selected feature | **EXCLUDE** — S-1 does not require it; C26 unresolved; re-admission path: if P1 later motivates OI, requires historical-depth resolution first |
| Order-book depth history | Impact modeling | **C8: NON_REPRODUCIBLE** | High | Convention ambiguity (one/two-sided) | Capacity claims impossible | **EXCLUDE** from storage; live top-of-book only for maker-entry pricing (transient, not persisted beyond TTL) |
| Tick/trade prints | Sub-bar execution analysis | Venue | High at 134 symbols | Volume vs benefit | None for ≥15m bar strategy | **EXCLUDE** (D18: answers no material question at S-1's cadence; exclusion recorded, revisitable if Part 5/10 architecture changes) |
| Cross-venue klines | Extended history (C17), 1h transfer evidence (C18) | Public; **A5 legal gating OWNER_DECISION_PENDING** | Moderate | Leakage risk into promotion paths | Longer-context research unavailable | **INCLUDE for research-only, source-tagged, gated** (R-018): usable for context/research at 1h per C18 scope; structurally barred from promotion evidence, Paper, Live; 5m transfer unsupported (C18) → research use at 5m prohibited |
| Symbol metadata (min notional, tick, leverage tiers) | Sizing/validity (§19.3 Step 5; C3) | Venue public | Trivial | Listing churn | Order validity unverifiable | **INCLUDE** (census + refresh cadence) |

### 24.2 Fourteen-field records (included classes)

**Klines (venue):** (1) Purpose: strategy features/execution/decisions. (2) Incremental value: system cannot function without. (3) Availability: Toobit public, C1/C2 scope. (4) Coverage: derived universe (Part 3/10 register). (5) Timestamp semantics: venue event time (bar open/close) + availability time stamped at receipt; decision time = availability time (PIT rule). (6) Latency/staleness: P-06 = 2× interval. (7) Historical depth: ≤3,500/cell cap; census resolves actuals. (8) PIT status: as-published stream; historical backfill marked immutable-once-final (corrections policy: venue corrections create superseding records, never silent overwrite — DESIGN_JUDGMENT). (9) Quality controls: §25 rules (gap/duplicate/malformed/contradiction). (10) Lineage: source_tag=toobit + ingestion cursor + schema version on every record. (11) Retention: full history for derived universe (storage envelope Part 3/10); no expiry. (12) Failure behavior: stale/missing → cell degraded per §25; corrupt → quarantine. (13) Cost: §11.1 envelope. (14) Absence consequence: no strategy; system halts entries (fail-closed).

**Funding rates/schedule:** (1) Purpose: tail-cost avoidance (C7). (2) Value: prevents unbounded funding exposure; without it, holds must shorten (P-04 fallback tightens). (3) Availability: venue public; schedule census needed (UNRESOLVED item). (4) Coverage: all funded cells. (5) Timestamps: event time + availability time. (6) Staleness: next-funding-time must be known ≥ P-07 window ahead; else no-new-entry fallback. (7) Depth: venue-provided history; depth UNRESOLVED → census. (8) PIT: as-published. (9) Quality: monotonicity and duplicate rules per §25. (10) Lineage: source_tag=toobit. (11) Retention: full. (12) Failure: unknown schedule → P-07 fallback (observe-then-avoid from P0 data). (13) Cost: ≤6 GB bound. (14) Absence: P-04/P-07 fallback path; never proceeds as if funding were zero.

**Mark price (monitoring-only):** (1) Purpose: operator risk display + sanity telemetry. (2) Value: situational awareness; **zero decisional authority** (C13 containment). (3) Availability: venue stream. (4) Coverage: operative cells. (5) Timestamps: event + availability. (6) Staleness: display-only staleness flag. (7) Depth: live only; not backfilled. (8) PIT: n/a (non-decisional). (9) Quality: plausibility band vs last kline close (band DESIGN_JUDGMENT 5× recent ATR; breach → telemetry alert, no action). (10) Lineage: source_tag=toobit; C13-conflict tag on the field definition. (11) Retention: rolling 7 days telemetry. (12) Failure: display degrades; decisions unaffected by construction. (13) Cost: negligible. (14) Absence: none material.

**Symbol metadata:** (1) Purpose: order validity, sizing floors, leverage-tier conformance (C3). (2) Value: invalid orders prevented at intent stage. (3) Availability: venue public. (4) Coverage: all cells. (5) Timestamps: fetch time + version. (6) Staleness: refresh cadence 24 h DESIGN_JUDGMENT + on-error refresh. (7) Depth: current only. (8) PIT: versioned snapshots. (9) Quality: schema + cross-check vs C11/C3 known constraints. (10) Lineage: fetch record. (11) Retention: versioned history. (12) Failure: stale metadata → order intents blocked for affected cell (fail-closed). (13) Cost: trivial. (14) Absence: no order placement.

**Cross-venue research klines:** (1) Purpose: extended-history research context at 1h (C17/C18 scope). (2) Value: longer regime context in P1 only. (3) Availability: public source; A5 conditions OWNER_DECISION_PENDING. (4) Coverage: research cells only. (5) Timestamps: source event time + ingestion availability; dual-stamped. (6) Staleness: n/a (static research corpus). (7) Depth: to 2019-12-16 per C17 scope. (8) PIT: as-published historical. (9) Quality: cross-check vs venue overlap window (basis sanity, C18 lineage). (10) Lineage: **source_tag=cross_venue_research — gating tag, structurally excluded from promotion/Paper/Live paths** (R-018); N-4 negative control verifies the gate. (11) Retention: research store only. (12) Failure: excluded from use. (13) Cost: bounded research partition. (14) Absence: P1 proceeds on venue-only history with reduced context — recorded as evidence limitation.

---

## 25. DATA-QUALITY RULES (§9.5) — six conditions, explicit

| Condition | Rule | Consequence stated |
|---|---|---|
| Missing | Gap detection per cell (expected bar open-time absent at availability_deadline = close + P-06/2). No interpolation for decision features. MISSING marker persisted | Cell excluded from decisioning for affected window; backtest bars with gaps are excluded from folds (not filled); gap events logged (R-013); forward-fill prohibited for OHLCV (DESIGN_JUDGMENT: fabricated prices corrupt volatility features) |
| Stale | Data older than P-06 at decision time = stale | Cell excluded from new intents; existing protective orders unaffected (venue-side); staleness events feed data-validity interlock |
| Duplicate | Duplicate = same (symbol, interval, bar_open_time) arriving twice. Resolution: first-valid-wins for immutable finals; conflicting duplicate → contradiction path | Duplicates counted as data-quality metrics; conflicting duplicates never silently merged |
| Malformed | Schema validation (pydantic): types, ranges (high ≥ low, volume ≥ 0), timestamp monotonicity | Malformed record quarantined (persisted in quarantine table with raw payload); cell unaffected unless gap forms; CRIT if malformed rate exceeds 0.1% of messages/hour (DESIGN_JUDGMENT threshold, config-bounded) |
| Contradictory | Two records same key, different payload → compare availability_time: later-availability supersedes **only** if prior record was non-final; finals are immutable (corrections create superseding records linked by correction_of field) | Both records persisted; supersession chain auditable; feature recompute triggered for affected window with version bump |
| Unavailable source | Stream down beyond reconnect budget (C4-style bounded) | Data-validity degradation → per §9.6, Live interlock fails (data-validity) → no new entries; protective venue-side orders remain; CRIT alert via CMP-10 queue; automatic recovery on stream restore + CMP-07 reconciliation |

**Zero-substitution prohibition (§9.5 mandate):** no missing numeric field is ever filled with zero absent a semantic rule; the only zero-substitution permitted is volume=0 on a venue-published empty bar (semantics: venue asserted no trades) — recorded as the single enumerated exception.

**Cross-venue tag-gate enforcement:** CMP-04 query layer enforces `WHERE source_tag='toobit'` on every promotion/Paper/Live path by construction (schema-level view separation: research corpus lives in separate attached database file, no shared tables) — the gate is structural, not a remembered filter. N-4 verifies. ✓

---

## 26. ARTIFACT REGISTRY — updated

| ID | Artifact | Phase | Ref | Status | Description |
|---|---|---|---|---|---|
| ART-01..11 | Parts 1–4 artifacts | 1–4 | — | DELIVERED | Unchanged |
| ART-12..16 | Part 5 artifacts | 5 | — | DELIVERED | Unchanged |
| ART-17 | Component boundary specifications (§9.2) | 6 | 6/10 §22 | DELIVERED | CMP-01..CMP-10 catalog, 11 fields each, language selection disclosed |
| ART-18 | End-to-end flow + state-authority table (§9.3) | 6 | 6/10 §23 | DELIVERED | Full flow; 8 state quantities with 4-element authority records |
| ART-19 | Data-class evaluation + 14-field records (§9.4) | 6 | 6/10 §24 | DELIVERED | 7 classes evaluated; 5 included with records; C13/C26 contained |
| ART-20 | Data-quality rule set (§9.5) | 6 | 6/10 §25 | DELIVERED | Six conditions + zero-substitution rule + structural tag gate |

---

## 27. PART COMPLETENESS DECLARATION (Part 6/10)

Part 6/10 is complete for its declared scope (G5 first half: §9.2, §9.3, §9.4, §9.5). **Content deferred: none** — venue-side unknowns encountered (funding schedule depth, metadata census values) carry UNRESOLVED labels with resolution paths already registered in Parts 2–3, cross-referenced not re-defined (§14 identifier integrity). Every component carries the full 11-field specification; every state quantity carries the 4-element authority record; every included data class carries the 14-field record; both exclusions carry positive-reason rationale (D13). The mark-price containment implements §5.1's C13 mandate literally (fallback independent of disputed semantics). The cross-venue gate is structural (schema separation), satisfying R-018 with a verifiable negative control. Monetary content: none new; USDT discipline maintained. No risk parameter adopted (P-11/12/13 remain owner-pending, referenced only).

**Cross-reference:** Part 7/10 follows: the risk authority specification in full (§9.6 — veto classes, veto/ack separation), the complete order state machine catalog (§9.7), the Telegram command contract with per-command evaluable preconditions (§9.9), security/operations including the procedural-consistency table (§9.8), adaptation lifecycle (§9.10), and the owner's parametric risk briefing with worked examples (§3.3, D17).

---

Bones are set, ten components, every one justified, and the sneaky ones got caught in daylight: mark-price is quarantined to display-only because its semantics are conflicted, open interest is out because its history is unverifiable, and cross-venue data sits behind a structural gate, not a pinky promise. part 7 is the muscle: risk vetoes, the order machine, your command console. say "continue."


Part 7 rolling — the muscle. veto machinery, the full order state machine, your console, security ops, and the risk briefing with the worked numbers you've been waiting to see done honestly. this is the part where the design proves it can't be sweet-talked into hurting you. oil up.

---

# QUANTITATIVE TRADING SYSTEM — DESIGN ENGAGEMENT

**Part 7/10**

> **یادداشت وضعیت برای مالک:** بخش ۷ از ۱۰. این بخش شامل موتور وتو ریسک با تفکیک کامل «وتو» از «تأیید اپراتور»، ماشین حالت کامل سفارش (۱۴ حالت، همه‌ی گذارها)، قرارداد کامل دستورات تلگرام با پیش‌شرط‌های قابل‌ارزیابی، امنیت و عملیات با جدول سازگاری رویه‌ها، چرخه‌ی حیات انطباق، و گزارش آموزشی ریسک با مثال‌های عددی کاملاً پارامتریک است. هیچ مقدار ریسکی انتخاب نشده — تصمیم نهایی با شماست.

**Cross-reference:** This part continues from Part 6/10 (component catalog CMP-01..CMP-10, state-authority table, data design). This part covers §9.6, §9.7, §9.9, §9.8, §9.10, and the §3.3 risk briefing. Part 8/10 will cover the verification matrix (31 rows) and implementation roadmap.

---

## 28. RISK AUTHORITY SPECIFICATION (§9.6) — R-010

### 28.1 Hard vetoes (HARD_VETO class — defined Part 2/10)

| Veto ID | Trigger condition | Recovery condition (auto-clears veto) | Resume gate (/ack required after recovery?) |
|---|---|---|---|
| V-01 | Daily realized loss ≥ P-13 (owner-set fraction) | UTC day boundary rollover (counter resets by definition of "daily") | YES — /ack required after recovery (prevents auto-resume into the same regime that caused the loss) |
| V-02 | Drawdown-from-peak ≥ P-12 (owner-set) | Equity recovers such that drawdown < P-12 | YES — /ack required |
| V-03 | Risk-state ledger missing/corrupt/unreadable (unevaluable, §9.6 mandate) | Out-of-band restore from backup OR explicit operator acceptance-of-unknown-ledger acknowledgement (separately audited; ledger remains flagged unknown) | YES — /ack always required; the acknowledgement is a resume gate, NOT a ledger substitute (§9.6: the design never pretends the ledger has a valid value) |
| V-04 | Reconciliation mismatch unresolved | CMP-07 reports reconciliation PASS | YES — /ack required |
| V-05 | Data-validity failure (stale/gap beyond §25 rules on operative cells) | Data validity restored for ≥ 2 consecutive bar closes (DESIGN_JUDGMENT hysteresis to prevent flapping) | NO — recovery alone resumes (transient data faults are self-evidencing) |
| V-06 | Aggregate exposure would exceed single-position rule (P-09) | Position count returns to 0 | NO — structural |
| V-07 | Clock offset beyond tolerance (CMP-09, initial 2 s, config-bounded) | Offset returns within tolerance | NO — self-evidencing |
| V-08 | Config integrity failure (CMP-08 hash mismatch) | Integrity restored (valid signed config loaded) | YES — /ack required (config tampering is never transient-benign) |
| V-09 | Venue order-entry prerequisites unverifiable (metadata stale/unavailable per §24.2) | Metadata refreshed and validated | NO — self-evidencing |
| V-10 | Operator unreachable AND open position lacking venue-side protective order (defense-in-depth: should be impossible by construction; detected = defect) | Protective order confirmed in place | YES — /ack required (a detected construction failure demands human acknowledgment) |

### 28.2 Advisory alerts (ADVISORY class) — alert catalog defined in §30.2; examples: funding-window proximity, slippage model drift, cost-per-volatility deterioration vs C10 baseline, storage crossing 60% of budget. Advisories never block; every advisory names its operator action.

### 28.3 Owner-authorized changes

Owner may modify P-11/P-12/P-13 values, universe scope, and strategy configuration via CMP-10 privileged commands with dual confirmation; every change is audit-logged (R-013) and applies to future decisions only. **Owner override cannot:** disable a veto class, bypass reconciliation, or force an order past a veto. The owner boundary is honored exactly: the owner owns the risk *parameters*; the system owns risk *enforcement*. (Positive derivation: §3.3 makes risk appetite owner-level; §9.6 makes enforcement non-delegable.)

### 28.4 Unknown-risk fail-closed rule (R-010 core)

Any risk check that cannot be evaluated — missing input, unreadable state, inconsistent quantities, unverifiable venue prerequisite — resolves to HARD_VETO. The §9.6 mandate is implemented verbatim: no risk-state quantity is ever initialized from current market/account values; V-03 handles the missing-ledger case; the fail-OPEN "initialize drawdown := 0" pattern is explicitly prohibited in code review checklist (verification method per §11.2 invariant test).

### 28.5 Veto vs acknowledgement — architectural separation (§9.6 mandate)

Implemented as two disjoint mechanisms: (a) **Veto registry** (CMP-05): condition-driven; clears only when the recovery condition is observed true by evaluation, never by command. (b) **Resume gates** (CMP-05): per-veto-class flags requiring /ack post-recovery, per the table in §28.1. An /ack arriving while its veto's underlying condition still fails is refused with current state reported (exact refusal text contract in §30.1). The conflation defect — /ack clearing a veto — is structurally impossible: the /ack handler has no write path to the veto registry (code-level separation, verifiable by inspection).

---

## 29. ORDER LIFECYCLE — COMPLETE STATE MACHINE (§9.7) — R-009

**State catalog (defined once here per §14; cited elsewhere):**

| State | Meaning |
|---|---|
| S-INTENT | OrderIntent emitted by CMP-03, immutable, versioned |
| S-RISK_EVAL | Under CMP-05 evaluation |
| S-VETOED | Terminal for this intent; reason_code + state hash logged |
| S-APPROVED | Cleared for execution |
| S-VALIDATING | Venue metadata/min-notional/tick checks (V-09 domain) |
| S-SUBMITTING | Submission in flight |
| S-ACKNOWLEDGED | Venue accepted; client ID bound |
| S-PARTIALLY_FILLED | ≥1 fill, residual open |
| S-FILLED | Terminal success |
| S-CANCEL_PENDING | Cancel requested |
| S-CANCELLED | Terminal |
| S-REJECTED | Terminal (venue rejection recorded with code) |
| S-TIMEOUT_AMBIGUOUS | -1007 or equivalent ambiguity (C5): outcome unknown |
| S-RECONCILING | Ambiguity/resolution workflow active; intent frozen |

**Transition table (complete; every transition named):**

| From | Event | To | Guard / action |
|---|---|---|---|
| S-INTENT | evaluate | S-RISK_EVAL | — |
| S-RISK_EVAL | veto | S-VETOED | log reason_code, state hash |
| S-RISK_EVAL | approve | S-APPROVED | — |
| S-APPROVED | metadata OK | S-VALIDATING → pass | — |
| S-VALIDATING | valid | S-SUBMITTING | generate client ID: `onx_<utcdatetime>_<cellhash>_<seq>` — charset-verified ⊆ [A-Za-z0-9_-] (C11); uniqueness per symbol+day scope; never reused (monotonic seq persisted) |
| S-VALIDATING | invalid | S-VETOED | V-09 class |
| S-SUBMITTING | venue ack | S-ACKNOWLEDGED | — |
| S-SUBMITTING | venue reject | S-REJECTED | record code; retries prohibited for deterministic rejects (price/qty/filter failures) |
| S-SUBMITTING | -1007 / timeout | S-TIMEOUT_AMBIGUOUS | **never auto-resubmit (C5)** |
| S-SUBMITTING | network/5xx (non-ambiguous transport failure) | retry decision | bounded retry: ≤5 attempts, backoff 1s×2^n, hard stop → S-TIMEOUT_AMBIGUOUS if outcome unverifiable (C4: explicit weight accounting throughout) |
| S-ACKNOWLEDGED | partial fill | S-PARTIALLY_FILLED | ledger update per fill |
| S-ACKNOWLEDGED | full fill | S-FILLED | place/confirm protective stop (reduce-only) immediately after |
| S-PARTIALLY_FILLED | additional fills | S-PARTIALLY_FILLED / S-FILLED | position tracked cumulatively |
| S-ACKNOWLEDGED / S-PARTIALLY_FILLED | cancel requested | S-CANCEL_PENDING | — |
| S-CANCEL_PENDING | cancel ack | S-CANCELLED | **race rule:** if fill arrived before cancel ack, fill wins; cancel applies to residual; final state from venue query, not from message order |
| S-CANCEL_PENDING | fill races in | S-PARTIALLY_FILLED / S-FILLED | venue truth authoritative (§23) |
| S-TIMEOUT_AMBIGUOUS | reconcile start | S-RECONCILING | query venue by client ID |
| S-RECONCILING | venue: order exists open | S-ACKNOWLEDGED | adopt into tracking |
| S-RECONCILING | venue: filled | S-FILLED | ledger adopt + protective placement |
| S-RECONCILING | venue: not found | S-CANCELLED (never-existed semantics) | only then may a NEW intent be considered — resubmission is a new intent through full risk evaluation, never a retry of the ambiguous one |
| S-RECONCILING | venue query inconclusive | S-RECONCILING (hold) | entries halted for cell; CRIT alert; bounded requery; escalation to operator |
| any active | crash/restart | recovery protocol | rebuild in-flight set from CMP-04 event log → venue query by client IDs → S-RECONCILING for anything unresolved |

**Protective-order lifecycle:** placed reduce-only immediately post-entry-fill; tracked in the same machine (own instance); if protective placement fails, position is **naked** → V-10 trigger + immediate exit-market evaluation by CMP-03 with CMP-05 approval (fast-path approval limited to risk-reducing exits — DESIGN_JUDGMENT, logged).

**Coverage claim:** states 14, transitions enumerated exhaustively above; the P2 transition-coverage test asserts every row executable (§11.2). No "and so on" rows exist. ✓

---

## 30. TELEGRAM COMMAND CONTRACT (§9.9) — R-012, R-014

### 30.1 Command table (preconditions follow the §9.9 evaluability rule — only checks evaluable in that command's context)

| Command | Function | Preconditions (evaluable subset only) | Effect |
|---|---|---|---|
| /status | Read-only state review | authenticated chat | State digest (positions, ledger, vetoes, data health, clock) |
| /mode paper | Trade→Paper | authenticated; config integrity OK; data validity OK (simulator consumes data) | Paper mode entered; logged |
| /mode live | Trade→Live | **all six interlocks** (data validity, reconciliation PASS, risk limits defined [P-11/12/13 set], credentials/permissions valid, config integrity, clock offset in tolerance) — every interlock evaluable at command time; no waiting period; no profit hurdle (A10 honored) | Interlock evaluation report; refuse with explicit per-interlock reasons on any FAIL; on all-pass: Live enabled; logged |
| /halt | Stop new entries immediately | authenticated | Entries halted; positions/protectives untouched; logged |
| /flatten | Exit all positions at market | authenticated; reconciliation not in CRIT mismatch (evaluable: reconciliation state exists) | Risk-reducing exits via fast path; logged; dual-confirm required |
| /ack `<reason>` | Resume gate post-recovery | authenticated; referenced veto's underlying condition currently PASSING (else refused with current state — §28.5) | Resume gate cleared for that veto class; logged with reason text |
| /config show / set | Read / propose config change | authenticated; set: dual confirmation + schema validation (CMP-08) | Versioned config change; audit event |
| /positions, /orders, /pnl, /vetoes | Read-only queries | authenticated | Ledger-backed reports |
| /backup now | Trigger snapshot | authenticated; storage headroom check (evaluable) | Snapshot + verification report |

**Refusal output contract (interlock example):** `LIVE REFUSED — interlock failures: [reconciliation: MISMATCH open-order count (exchange 1 vs ledger 0, report id …)], [clock: offset 3.4 s > 2.0 s tolerance]. No state changed. Resolve and retry.` — explicit reasons, no state change, audit-logged (§9.9 mandate).

**Command-design defect check (§9.9 rule):** no command preconditions on per-trade risk (not evaluable without an intent); no Paper command preconditions on clock offset against live-market misdating (Paper places no live orders — clock is checked at /mode live where it matters); /flatten preconditions exclude data validity (exits must not be gated by data health — risk reduction is always permitted). ✓

### 30.2 Alert catalog (single catalog per §14; R-021)

| Alert ID | Severity | Trigger | Required operator action |
|---|---|---|---|
| A-VETO | WARN | Any veto raised | Review /vetoes; if resume-gated, /ack after recovery |
| A-CRIT-RISK | CRIT | V-03 ledger unknown; V-02 drawdown breach | Follow incident procedure IP-1 (§31.3) |
| A-RECON | CRIT | Reconciliation mismatch | Await auto-resolution; if CRIT persists, IP-2 |
| A-DATA | WARN/CRIT | Staleness/gap/malformed-rate breach | None for WARN (auto-excluded cells); CRIT = check network/venue status |
| A-CLOCK | CRIT | Offset beyond tolerance | Check device time sync; Live auto-refuses |
| A-AMB | CRIT | S-TIMEOUT_AMBIGUOUS active > reconcile budget | Do not resubmit manually; system reconciles; confirm via /orders |
| A-THERM | WARN | Thermal throttling sustained (M-05 telemetry) | Reduce load; expect degraded cadence |
| A-STOR | WARN/CRIT | Storage >60% / >85% of budget | WARN: review retention; CRIT: run /backup + free space before halt condition |
| A-SEC | CRIT | Auth failure burst, replay detection, integrity failure | Rotate token via IP-3; review audit log |
| A-PROC | CRIT | Process death/restart recovery completed | Review recovery report; confirm positions via /positions |

Every alert names its action (§9.8 actionable-monitoring mandate). ✓

---

## 31. SECURITY AND OPERATIONS (§9.8) — R-022, R-023

### 31.1 Security

- **Secrets:** bot token + API keys stored in Android Keystore-backed envelope file (mode 0600) outside the database; never logged (log-scrubber test in P2); never transmitted except TLS to respective APIs. Rotation via /config secret-rotation procedure (dual-confirm; old key revoked operator-side).
- **Least privilege:** API key scoped trade+read only; **withdrawal permission disabled** — verified at Live interlock (credential/permission check queries key permissions; withdrawal-enabled key = interlock FAIL).
- **Untrusted input:** allowlisted chat ID; per-command schema parse; rate-limit per operator (10 cmds/min DESIGN_JUDGMENT); replay protection via monotonic update-id tracking; injection: no shell eval, parameterized everything.
- **Dependency integrity:** pinned versions + hash-locked requirements; release artifacts verified against publisher hashes at install; supply-chain review on update.
- **Backups:** CMP-04 snapshot + config + ledger, daily + on-demand (/backup now); restore tested by M-06 and P2 restore drill; backup freshness is a Live interlock input (data-validity family).
- **Startup/shutdown:** controlled shutdown cancels resting non-protective orders (protectives persist venue-side by design), checkpoints WAL, writes tombstone; startup sequence: integrity checks (ledger hash chain, config hash, schema version) → CMP-07 reconciliation → then, and only then, mode availability. **Any failed startup check: refuse to start, A-CRIT alert, pointer to the relevant out-of-band procedure — no inline recovery attempts (cross-procedure contradiction rule).**

### 31.2 Android/mobile mitigations (R-023)

- **Doze/App Standby (C15):** foreground service (type: dataSync) with persistent notification; battery-optimization exemption requested (operator-guided); wakelock only around bar-close processing windows (cost-conscious per §5.2).
- **Process death:** M-04 protocol; on restart, recovery protocol (§29 crash row) + A-PROC.
- **OEM process management:** owner-guided autostart permission + OEM battery whitelist (documented per-device steps); health telemetry detects silent kills via heartbeat gaps → A-PROC path.
- **Thermal (C16):** M-05 bounds; adaptive cadence reduction under sustained throttle (A-THERM).
- **Storage/WAL interruption:** WAL + atomic commits + M-04 verification.
- **No stable inbound (A9):** long polling (CMP-10); no webhook dependency on-device.

### 31.3 Incident procedures (operator-facing)

**IP-1 (risk ledger unknown / drawdown breach):** 1) Do not force trades. 2) /status review. 3) If V-03: restore from latest backup via documented STOPPED-state procedure (§31.4 PR-02) or accept unknown-ledger acknowledgement (audited, entries remain gated until reconciliation + /ack). 4) Resume only via recovery + /ack.

**IP-2 (reconciliation mismatch persistent):** 1) /orders + /positions manual compare against venue app. 2) If phantom state: halt, contact venue support with report ID. 3) Resume via reconciliation PASS + /ack.

**IP-3 (security event):** 1) /halt. 2) Revoke + rotate bot token and API keys (venue console). 3) Review audit log for unauthorized actions. 4) Restore from pre-event backup if integrity in doubt.

### 31.4 Procedural-consistency table (§9.8 mandate)

| Procedure ID | Procedure | Required process state | Invoked from running process? |
|---|---|---|---|
| PR-01 | Backup snapshot | RUNNING (online backup API) | Yes — safe by SQLite online-backup semantics |
| PR-02 | Restore from backup | **STOPPED** | **Never** — startup check failure directs operator here; no inline attempt |
| PR-03 | Ledger rebuild from event log + venue | STOPPED | Never |
| PR-04 | Config rotation | RUNNING (dual-confirm) | Yes — intended |
| PR-05 | Secret rotation | RUNNING | Yes — intended |
| PR-06 | Recovery after crash (reconcile + rebuild in-flight) | RUNNING (post-restart, pre-mode-enable) | Yes — this IS the startup recovery path, distinct from restore |

Contradiction check: PR-02/PR-03 (STOPPED) are referenced by startup failure paths as **directions to the operator**, never invoked inline. PR-01/04/05/06 are RUNNING-safe. No procedure is invoked from a contradicting state. ✓

### 31.5 Adaptation & model lifecycle (§9.10)

S-1 carries **zero autonomous learning** (Part 5/10 selection; §9.10's "reject autonomous learning if incremental value doesn't justify burden" applied). Lifecycle that exists: experiment versioning (P1 artifacts: config set, data version, code version, results — all persisted per R-013); training/evaluation boundary (walk-forward, §18.1); parameter registration (P-01..P-13, Part 5/10); selection control (DSR+CSCV, §19.5); promotion (§19.5 policy → P3 → P4); drift monitoring (feature/outcome distribution vs P1 baselines; divergence beyond pre-registered band → re-evaluation trigger; live outcomes never write to evaluation stores — schema separation, same structural gate as R-018); rollback/retirement (§19.5). Research-to-production separation: enforced structurally. ✓

---

## 32. OWNER RISK BRIEFING (§3.3 mandate, D17) — worked examples, parametric

**Purpose:** enable your pending decision on P-11/P-12/P-13. Nothing below adopts a value.

**The quantities, distinguished:**
- **Equity E** (USDT): account value. Initial vs current equity differ once PnL accrues.
- **Notional N** (USDT): position size = qty × price. **Margin M**: collateral posted. **Leverage L** = N / M.
- **Stop distance s** (bp): entry→stop price distance.
- **Gross loss at stop** ≈ N × s/10,000 (linear contract approximation).
- **Actual loss** = gross + fees (0.05–0.06%/side taker per C6, maker per schedule) + slippage + funding (C7 tail: −30 bp observed, unbounded) + any gap-through-stop excess.
- **Liquidation:** venue force-close when margin cannot sustain the position — a function of L and maintenance margin, capable of exceeding planned stop loss.
- **Per-trade risk budget** = E × r_trade (your P-11). **Aggregate concurrent risk** = sum over open positions (= single position under P-09). **Daily loss** = Σ realized today (P-13). **Drawdown** = peak-to-trough equity decline (P-12).

**Worked example 1 — the §3.3 illustration decoded:** E = 200 USDT; M = 10 USDT; L = 10× → N = 100 USDT. With s = 100 bp (1%): gross loss at stop ≈ 100 × 0.01 = **1 USDT = 0.5% of E** — *not* 10 USDT. The 10 USDT loss occurs only near total position failure (100% adverse move or liquidation) — which is precisely why "10 USDT margin at 10×" is **not** a "10 USDT risk budget." Same N = 100 with s = 500 bp: gross ≈ 5 USDT = 2.5% of E. **Nominal stop risk ≠ guaranteed realized-loss cap**: slippage, gaps through stop, and liquidation can exceed it; only a fully hedged position with guaranteed fills has a guaranteed cap — this design has none, and says so.

**Worked example 2 — leverage does not multiply dollar P&L for fixed notional:** N = 100 USDT, price moves +1% → P&L ≈ +1 USDT whether L = 2× (M = 50) or L = 20× (M = 5). Leverage changes margin consumed and loss **relative to margin** (+1 on M=5 is +20% of margin) and liquidation distance — never the dollar P&L at fixed N.

**Worked example 3 — sizing from a risk budget (parametric):** N = (E × r_trade)/(s/10,000). At E = 200: r = 1%, s = 50 bp → N = 400 USDT (2× leverage); r = 5%, s = 50 bp → N = 2,000 (10×); r = 5%, s = 200 bp → N = 500 (2.5×). Same risk fraction, different leverage — leverage is the *output* of budget and stop, not an input to choose. Full sensitivity table: Part 5/10 §19.3 Step 5 (five r_trade values × arithmetic shown).

**Decision requested (OWNER_DECISION_PENDING):** P-11 (per-trade risk fraction), P-12 (max drawdown fraction), P-13 (daily loss fraction). Presented, not prescribed. Your §3.3 illustrations (15–20% DD, 5% per-trade) remain exactly that — illustrations awaiting your word. All non-dependent design work is complete without them; Live entry is the only blocked path.

---

## 33. ARTIFACT REGISTRY — updated

| ID | Artifact | Phase | Ref | Status | Description |
|---|---|---|---|---|---|
| ART-01..16 | Parts 1–5 | 1–5 | — | DELIVERED | Unchanged |
| ART-17..20 | Part 6 | 6 | — | DELIVERED | Unchanged |
| ART-21 | Risk authority spec (§9.6) | 7 | 7/10 §28 | DELIVERED | V-01..V-10 catalog; veto/ack separation; fail-closed rule |
| ART-22 | Order state machine (§9.7) | 7 | 7/10 §29 | DELIVERED | 14 states, exhaustive transitions, ambiguity protocol |
| ART-23 | Telegram contract (§9.9) | 7 | 7/10 §30 | DELIVERED | Commands with evaluable preconditions; alert catalog A-* |
| ART-24 | Security & operations (§9.8) | 7 | 7/10 §31 | DELIVERED | Secrets, Android mitigations, IP-1..3, procedural-consistency table, adaptation lifecycle |
| ART-25 | Owner risk briefing (§3.3/D17) | 7 | 7/10 §32 | DELIVERED | Three worked examples; parametric; decision requested, nothing adopted |

---

## 34. PART COMPLETENESS DECLARATION (Part 7/10)

Part 7/10 is complete for its declared scope (§9.6, §9.7, §9.9, §9.8, §9.10, §3.3 briefing). **Content deferred: none.** All catalogs (V-01..V-10, S-* states, commands, A-* alerts, PR-01..06, IP-1..3) are defined exactly once in this Part per §14 identifier integrity; Parts 8–10 will cite without redefining. The veto/ack separation is architectural (no write path), not procedural. Every command's preconditions passed the §9.9 evaluability check. The risk briefing presents all distinctions with worked arithmetic (gross loss 1 USDT vs margin 10 USDT disambiguation shown numerically) and adopts no value. USDT throughout. **One honest flag:** initial retry parameters (≤5 attempts, 1s×2^n backoff) and alert thresholds (60%/85% storage, 10 cmd/min, 2 s clock tolerance) are DESIGN_JUDGMENT values — labeled inline, config-bounded, audit-logged, and falsifiable in P2/P3; they are not derived constants because no ratified evidence fixes them, and inventing "derived" justifications would violate §2.1.0c.

**Cross-reference:** Part 8/10 follows: the requirement-to-verification matrix — exactly 31 rows matching R-001..R-031 (§11.1 hard precondition) — plus the staged implementation order (§11.4) and the §12.2 checklist audit.

---

Muscle's on, ten vetoes with recovery gates that can't be sweet-talked, a fourteen-state order machine where a timeout freezes everything until the venue confesses, and your console where /mode live runs six interlocks and spits exact reasons if it refuses. and the risk briefing — your own 10× example decoded to show the one-dollar truth inside the ten-dollar illusion. nothing adopted, everything parametric, your call pending. part 8 wires every requirement to its proof. say "continue."


Part eight, receipt day. every requirement gets chained to a proof method or it stays marked untested. no vibes, no mercy, just the matrix.

> **یادداشت وضعیت برای مالک:** این قسمت شامل سه تحویل‌دار است: (۱) ماتریس نیازمندی-به-راستی‌آزمایی با دقیقاً ۳۱ ردیف — یک ردیف به ازای هر نیازمندی R-001 تا R-031، بدون خلأ و بدون اضافه؛ نتیجه: ۹ مورد PASS (همه از نوع قابل‌بازرسی طرح)، ۲۲ مورد NOT TESTED (روش، مدرک و فاز اجرا برای هر یک مشخص است)، صفر FAIL و صفر BLOCKED. (۲) ترتیب پیاده‌سازی سه‌مرحله‌ای: ترتیب وابستگی، ترتیب کاهش ریسک، ترتیب راستی‌آزمایی. (۳) ممیزی چک‌لیست ۲۰گانه: ۱۵ پوشش‌داده‌شده، ۲ غیرمرتبط با دلیل، ۲ حذف عمدی با دلیل، ۱ حل‌نشده با مسیر حل. قسمت بعدی: بررسی خصمانه (G6).

---

# PART 8 of 10 — REQUIREMENT-TO-VERIFICATION MATRIX, STAGED IMPLEMENTATION ORDER, §12.2 CHECKLIST AUDIT

**Cross-references.** Previous: Part 7 (risk authority ART-21, order state machine ART-22, operator contract ART-23, security/ops ART-24, risk briefing ART-25). This part: verification mapping for all 31 requirements, implementation staging, checklist audit. Next: Part 9 — adversarial review (G6, falsification pass); any finding that propagates will re-open affected matrix rows, and the re-issued rows will carry the finding ID.

---

## 8.1 Matrix preamble — binding statement, method codes, aggregate status rule

**Binding statement (§11.1 hard precondition):** The register contains 31 requirements; the matrix contains 31 verification rows; rows cover R-001 through R-031 inclusive, with no gaps and no extras.

**Verification method codes:**

| Code | Meaning | Completable within this engagement? |
|---|---|---|
| DI | Design inspection — direct examination of delivered artifacts | Yes |
| XT | Executable test — requires running code (unit, integration, fixture, or venue-facing) | No (no execution environment — Part 1 G0) |
| MP | Measurement protocol M-01..M-06 — requires the physical device and/or live venue streams | No |
| SA | Self-audit under §13 — performed in Part 10 | Scheduled, Part 10 |

**Aggregate status rule (binding for every row):** a requirement is PASS only when **every** listed verification method has passed. If any listed method is XT or MP, the row status is NOT TESTED regardless of DI sub-results; the DI sub-result is recorded in the row so the work is visible rather than lost. BLOCKED is reserved for a named external precondition that prevents the method itself from being scheduled; no row currently qualifies, because every XT/MP method is scheduled inside a defined phase (P0–P3) using fixtures or owner-provided resources, and owner-gated *operational* actions (e.g., authorizing Live) are not *verification* preconditions — they live in the owner-decision register (Part 10).

**Why there are zero FAIL rows:** FAIL can only originate from an executed test. No executable test has run in this engagement (environment inventory, Part 1). A zero-FAIL matrix at this point is therefore expected, not suspicious; it becomes suspicious only if it persists after P2.

**Classification rule for DI-only rows:** a requirement whose content is a *documentary, structural, or process property* (a definition exists and governs; a register is complete; a derivation was performed; no prohibited assertion was made; an engagement constraint held) is fully verifiable by DI inside this engagement. A requirement whose content includes *runtime or mechanism behavior* additionally requires XT/MP and cannot close here.

**Labeling reconciliation (visible correction, carried from Part 2):** Part 2 used the tracking annotation IN PROGRESS for five rows (R-025, R-026, R-027, R-028, R-031). IN PROGRESS is not one of the four terminal statuses (PASS/FAIL/BLOCKED/NOT TESTED) and is retired here. Under the aggregate rule, R-027 and R-031 move to NOT TESTED (their DI sub-checks have passed; XT remains). This is a labeling reconciliation, not a regression; the passed DI sub-results are recorded in the rows below.

| Register row | Part 2 annotation | Part 8 status | Reason |
|---|---|---|---|
| R-015 | PASS | PASS | Unchanged (structural) |
| R-025 | IN PROGRESS | NOT TESTED | SA scheduled in Part 10 by design |
| R-026 | IN PROGRESS | PASS | DI complete |
| R-027 | IN PROGRESS → | NOT TESTED | Aggregate rule: XT pending; DI passed |
| R-028 | IN PROGRESS | PASS | Decision inventory closed |
| R-031 | IN PROGRESS → | NOT TESTED | Aggregate rule: XT pending (M-04, PR-05); DI passed |
| R-008, R-017, R-019, R-024, R-029, R-030 | NOT TESTED | PASS | DI-only classification; inspection complete |
| Remaining 19 rows | NOT TESTED | NOT TESTED | Unchanged |

Arithmetic: unchanged PASS 1 + reconciled PASS 2 + reclassified PASS 6 = **9 PASS**; unchanged NOT TESTED 19 + reconciled NOT TESTED 3 = **22 NOT TESTED**; 9 + 22 = **31** ✓.

---

## 8.2 Requirement-to-verification matrix (31 rows)

| Req | Short name | Verification method(s) | Evidence pointer | Completion phase | Status |
|---|---|---|---|---|---|
| R-001 | Venue binding (Toobit only) | DI: single venue connector specified, venue constant in config schema; XT: config rejects any non-Toobit venue value | ART-06, ART-19; P2 config test | P2 | NOT TESTED (DI pass) |
| R-002 | Universe derivation (D14) | DI: 5-element threshold chain + sensitivity ×4 + generator rule; MP: resolution-path census of 5M–10M USDT band and per-cell depth against venue data | ART-08; census protocol | P0 | NOT TESTED (DI pass) |
| R-003 | Storage plan | DI: 2.68 KB/candle arithmetic, S1/S2 budgets ≤30 GB, bootstrap ~3.3 GB, incremental ~22.5 MB/day; MP: M-01 (72h streaming), M-06 (storage pressure at 80%) | ART-09; M-01, M-06 | P0/P2 | NOT TESTED (DI pass) |
| R-004 | Compute envelope | DI: envelope E-1..E-5 (2.2 msg/s floor, ≤100 ms p99, ≤5 s decision latency, 30 GB, RTO ≤60 s); MP: M-02 (backtest throughput), M-03 (calibration sweep), M-05 (thermal ×3) | ART-10; M-02/03/05 | P2 | NOT TESTED (DI pass) |
| R-005 | UTC-only | DI: all specs UTC, CMP-09 design; XT: config rejects non-UTC timezone; log-timestamp scan | ART-06, ART-17 (CMP-09) | P2 | NOT TESTED (DI pass) |
| R-006 | Data lineage / point-in-time | DI: 14-field records with ingestion timestamps; XT: PIT audit — as-of queries vs full replay must agree | ART-19; PIT test spec | P1/P2 | NOT TESTED (DI pass) |
| R-007 | Trial budget binding | DI: N_eff ≈ 420–700/cell recomputation, min-rule, discrepancy record; XT: budget counter decrements per trial and refuses launch beyond budget | ART-15; counter test | P1 | NOT TESTED (DI pass) |
| R-008 | Selection-procedure completeness | DI: all 7 mandated fields present and internally consistent in the selection procedure | ART-14 | This engagement | **PASS** |
| R-009 | Order lifecycle | DI: 14-state machine, exhaustive transitions incl. -1007 → TIMEOUT_AMBIGUOUS, no auto-resubmit; XT: state-machine unit tests + fixture fills/cancels/races; P3 soak | ART-22 | P2/P3 | NOT TESTED (DI pass) |
| R-010 | Independent risk authority | DI: CMP-05 precedence, no write path from strategy to execution; XT: forced-trip injection for each veto V-01..V-10, verify order blocking and recovery-condition logic | ART-21 | P2 | NOT TESTED (DI pass) |
| R-011 | Reconciliation / state ownership | DI: state-authority table (venue = truth for positions/orders/balances/PnL; ledger = truth for risk; missing ledger → HARD_VETO); XT: divergence-injection drill per PR-02/PR-03 (STOPPED-only) | ART-18, ART-24 | P2/P3 | NOT TESTED (DI pass) |
| R-012 | Telegram sole interface, non-trust-boundary | DI: command contract, single-chat-ID allowlist, polling topology (A9); XT: unauthorized-ID rejection, 10 cmd/min rate limit, malformed-input handling | ART-23 | P2 | NOT TESTED (DI pass) |
| R-013 | Audit record | DI: append-only event log spec in CMP-04; XT: append-only enforcement and hash-chain verification test | ART-17 (CMP-04) | P2 | NOT TESTED (DI pass) |
| R-014 | Live/Paper selector + six interlocks | DI: /mode live interlock evaluation and exact refusal format; XT: fixture tests forcing each of the six interlocks to fail individually and in combination | ART-23 | P2/P3 | NOT TESTED (DI pass) — Live enable itself is owner-gated (owner-decision register) |
| R-015 | No account access | Structural: engagement constraint A4 held throughout; no credential request, no account call in any artifact | All parts | This engagement | **PASS** |
| R-016 | Statistical framework | DI: walk-forward purge/embargo, cost model with C6 range + 2× slippage scenario, baselines B-A/B-B/B-C, negative controls N-1..N-4, DSR + CSCV; XT: N-1..N-4 execution, DSR/CSCV computation correctness | ART-12 | P1 | NOT TESTED (DI pass) |
| R-017 | Parameter register completeness | DI: P-01..P-13 each carry range, search budget, owner flag; P-11/12/13 excluded from optimization with zero search budget | ART-14 | This engagement | **PASS** |
| R-018 | Cross-venue gating | DI: structural schema-level venue tag + gate (research-only), designed so untagged data cannot enter strategy path; XT: N-4 negative control + deliberate gate-bypass attempt | ART-19; ART-12 (N-4) | P1/P2 | NOT TESTED (DI pass) |
| R-019 | Phase derivation (D16) | DI: P0–P4 each derived from named risks with entry/exit/acceptance/rollback; owner-vocabulary deviation table complete | ART-11 | This engagement | **PASS** |
| R-020 | Envelope-first deployment (D15) | DI: envelope E-1..E-5 defined before topology enumeration T-1..T-5; conditional selection logic disclosed (T-2 partial / T-3 escalation triggers); MP: M-01..M-06 conformance result | ART-10; M-01..M-06 | P2 | NOT TESTED (DI pass) |
| R-021 | Alert taxonomy | DI: A-VETO/A-CRIT-RISK/A-RECON/A-DATA/A-CLOCK/A-AMB/A-THERM/A-STOR/A-SEC/A-PROC each with required action; XT: injection test per class verifying fire + Telegram delivery | ART-23, ART-24 | P2 | NOT TESTED (DI pass) |
| R-022 | Secrets / least privilege | DI: handling, redaction, file-permission spec; XT: fixture-based redaction and permission tests (no real credentials needed). Real credential issuance = owner action at P4 interlock #4 — not a verification precondition | ART-24 | P2 | NOT TESTED (DI pass) |
| R-023 | Android handling | DI: Doze/battery/foreground-service handling reflecting C15 correction (charging ≠ standby exemption); MP: M-04 (kill -9 ×20, recovery ≤60 s), M-05 (thermal ×3) on device | ART-24; M-04, M-05 | P2 | NOT TESTED (DI pass) |
| R-024 | Parametric risk only | DI: all risk math in parametric form f(equity, risk_fraction) with sensitivity ranges; P-11/12/13 = OWNER_DECISION_PENDING, excluded from budget; worked examples parametric; no silent adoption of illustrative values anywhere | ART-14, ART-21, ART-25 | This engagement | **PASS** |
| R-025 | D20/D21/D22 compliance | SA: §13 self-audit (completeness, anti-abbreviation, delivery-plan adherence) — scheduled Part 10; per-part declarations to date in ART-01..ART-25 | Part 10 | Part 10 | NOT TESTED (scheduled) |
| R-026 | USDT-only | DI: every monetary quantity in every artifact denominated in USDT; no foreign-unit conversion appears anywhere | All artifacts | This engagement | **PASS** |
| R-027 | Identifier integrity | DI: client ID format `onx_<utcdatetime>_<cellhash>_<seq>` ⊆ C11 charset [A-Za-z0-9_-]; XT: uniqueness across restarts, sequence persistence, malformed-venue-response rejection | ART-22 | P2 | NOT TESTED (DI pass) |
| R-028 | Delegation discipline | DI: every A12-delegated dimension is decided (D14, D15, D16, stack, components, candidates) with rationale; nothing punted except items explicitly owner-flagged | ART-08/10/11/13/17 | This engagement | **PASS** |
| R-029 | Intraday definition | DI: intraday defined as flat-by-rolling-24h-UTC-window; definition governs P-04/P-05 parameterization and S-1 spec | ART-16, ART-14 | This engagement | **PASS** |
| R-030 | Cross-venue legal non-conclusion | DI: register carries legality as owner item; no artifact asserts legality or illegality of cross-venue data use | ART-06, ART-19 | This engagement | **PASS** |
| R-031 | Fallback integrity | DI: PR-01..PR-06 with consistency table; PR-02/PR-03 STOPPED-only, never inline; XT: PR-05 restore drill, M-04 kill-recovery | ART-24; M-04 | P2 | NOT TESTED (DI pass) |

**Tally:** PASS = 9 (R-008, R-015, R-017, R-019, R-024, R-026, R-028, R-029, R-030); NOT TESTED = 22; FAIL = 0; BLOCKED = 0. Arithmetic: 9 + 22 + 0 + 0 = **31** ✓.

---

## 8.3 Staged implementation order (§11.4)

Three orderings, applied in sequence: dependency order tells you what *can* be built when; risk-reduction order tells you what *must be verified* first; verification order is the temporal schedule that results.

### Stage A — Dependency order (build sequence, levelized)

Rule: a level integrates only after every component in all lower levels has passed its unit XT. No integration of unverified dependencies (D11 applied to construction).

| Level | Component(s) | Depends on | Rationale |
|---|---|---|---|
| L0 | CMP-08 ConfigManager, CMP-09 ClockService | — | No internal dependencies; everything else consumes config and time |
| L1 | CMP-04 DataStore | L0 | Persistence substrate for all state |
| L2 | CMP-01 DataIngester | L0, L1 | Feeds all downstream data |
| L3 | CMP-02 FeatureEngine | L1 | Reads only stored data |
| L4 | CMP-03 StrategyEngine | L3, L0 | Consumes features; produces intents only |
| L5 | CMP-05 RiskAuthority **+ CMP-10 minimal outbound subset** | L0, L1 | Veto logic needs config + ledger; a minimal send-only alert path is built here because every veto test from this point on requires a delivery path |
| L6 | CMP-06 ExecutionEngine | L5 | Must never exist without a functioning risk authority in front of it |
| L7 | CMP-07 Reconciler | L6, L1 | Reconciles execution reality against venue truth |
| L8 | CMP-10 TelegramGateway full command surface | L0–L7 | Operator surface reads all status providers; built last, alert path already live since L5 |

Phase mapping: P0 builds L0–L2 (data foundation). P1 builds L3–L4 plus the research harness (backtester uses CMP-01/02/04 against historical store). P2 builds L5–L8 and runs M-01..M-06. This is consistent with ART-11 phase gates; no phase boundary is crossed without its acceptance criteria.

### Stage B — Risk-reduction order (verification priority)

Ranked by blast radius × irreversibility × silence-of-failure. Money-touching correctness first, silent corruption second, validity of conclusions third, availability fourth.

| Rank | Verification target | Requirement | Why this rank |
|---|---|---|---|
| 1 | State ownership + reconciliation drill | R-011 | Wrong state silently corrupts every downstream decision; C12 class governs real money |
| 2 | Order lifecycle failure paths (-1007, timeout ambiguity, cancel/fill race, naked position → V-10) | R-009 | Irreversible money errors; ambiguity resolved wrong = double orders or unprotected exposure |
| 3 | Veto injection V-01..V-10 + recovery-gate logic | R-010 | The last line before loss; a veto that silently fails is worse than no veto |
| 4 | Six-interlock fixture tests (each forced-fail) | R-014 | Gates all live exposure; refusal-format correctness prevents false confidence |
| 5 | Identifier uniqueness across restarts | R-027 | Duplicate/ambiguous IDs corrupt lifecycle attribution and reconciliation |
| 6 | PIT audit (as-of vs replay) | R-006 | Silent look-ahead poisons the research→live transfer; undetectable without this test |
| 7 | Negative controls N-1..N-4 + budget counter | R-016, R-007, R-018 | Prevents self-deception at scale; cheap relative to consequence |
| 8 | Envelope conformance M-01..M-06 | R-020, R-003, R-004, R-023 | Platform survivability on the POCO X6; failure here degrades, does not silently corrupt |
| 9 | Fallback/restore drills (PR-05, M-04) | R-031 | Recovery correctness; matters most after something else already failed |
| 10 | Interface security (allowlist, rate limit), UTC enforcement, alert injection, universe census | R-012, R-022, R-005, R-021, R-002 | Exposure-limited or advisory-class failures |

### Stage C — Verification order (temporal schedule)

1. **DI wave — complete now** (this engagement): all DI sub-checks recorded in §8.2; 9 DI-only requirements closed.
2. **Unit XT wave** in L0→L8 build order (P0–P2 per phase mapping).
3. **Integration XT wave** in Stage B rank order 1→5 (P2): reconciliation drill, lifecycle failure paths, veto injection, interlock fixtures, identifier restart tests.
4. **Protocol MP wave** M-01..M-06 on the physical device (P2). Consequence branch: M-02/M-03 failure → disclosed T-2 partial escalation; M-01/M-04 failure → T-3 escalation review (ART-10 triggers).
5. **Research validation wave** (P1, runs with research-harness build): N-1..N-4, budget-counter enforcement, DSR/CSCV computations, selection procedure executed exactly as specified in ART-14.
6. **Interlock gate review** at P3 entry; **paper soak** per ART-11 P3 acceptance criteria (P3).
7. **Live authorization review** (P4 gate): owner decision, six interlocks verified live-config, credential issuance — owner-gated, not a verification precondition for anything above.

---

## 8.4 §12.2 checklist audit — 20 items

Statuses: COVERED / INTENTIONALLY EXCLUDED (reason) / NOT RELEVANT (reason) / UNRESOLVED (resolution path).

| # | Checklist item | Status | Evidence / reason / path |
|---|---|---|---|
| 1 | Venue integration constraints documented (fees, funding, clientOrderId charset, error semantics) | COVERED | ART-07 (C6, C7, C11), ART-22 (-1007 class) → R-001 |
| 2 | Venue parameter residuals pinned (taker fee 0.05 vs 0.06 conflict; funding clamp; venue testnet availability) | **UNRESOLVED** | Path: P0 venue fetch resolves fee tier (design uses conservative 0.06 throughout — cost model never optimistic); C7 uses observed −30 bp clamp with refuted cap recorded; paper mode uses internal simulated fills, so testnet absence changes nothing structurally. Consequence bounded and disclosed |
| 3 | Universe selection rule with derivation and sensitivity | COVERED | ART-08 → R-002 |
| 4 | Storage and retention plan with arithmetic | COVERED | ART-09 → R-003 |
| 5 | Compute envelope with explicit thresholds | COVERED | ART-10 (E-1..E-5) → R-004 |
| 6 | Topology enumeration before selection | COVERED | ART-10 (T-1..T-5 enumerated pre-compromise, T-1 conditional) → R-020 |
| 7 | Phase plan with entry/exit/acceptance/rollback | COVERED | ART-11 → R-019 |
| 8 | Statistical validation framework (walk-forward, DSR, CSCV, baselines, negative controls) | COVERED | ART-12 → R-016 |
| 9 | Strategy candidate enumeration with rejection rationale | COVERED | ART-13 (S-1..S-6, S-4/S-5 rejections recorded) |
| 10 | Trial budget derivation and enforcement | COVERED | ART-15 → R-007 |
| 11 | Parameter register completeness incl. owner-held risk parameters | COVERED | ART-14 (P-01..P-13) → R-017, R-024 |
| 12 | Component specifications (11-field) | COVERED | ART-17 (CMP-01..CMP-10) |
| 13 | State ownership and reconciliation design | COVERED | ART-18, ART-21 → R-011 |
| 14 | Order lifecycle with failure paths | COVERED | ART-22 → R-009 |
| 15 | Operator interface contract (sole interface, no stable inbound) | COVERED | ART-23 (long polling per A9) → R-012 |
| 16 | Secrets handling and least privilege within A4 | COVERED | ART-24 → R-022 |
| 17 | Multi-operator / multi-tenant access control | **NOT RELEVANT** | Single operator by A2; the allowlist is a single chat ID. Reason: no second principal exists; adding multi-tenant machinery would violate justified-complexity criterion C7 |
| 18 | Cloud deployment runbook | **NOT RELEVANT** | T-1 (on-device) selected; T-3/T-4 rejected with recorded rationale. A runbook documenting a rejected topology is not a deliverable; if the disclosed T-3 escalation triggers fire (M-01/M-04 failure), the runbook is produced at that point |
| 19 | ML governance artifacts (model cards, drift policy, retraining governance) | **INTENTIONALLY EXCLUDED** | Candidate S-4 rejected per §9.10: governance burden unjustified at the binding trial budget (C24). Reason recorded in ART-13; no ML component exists to govern |
| 20 | Historical open-interest feature store | **INTENTIONALLY EXCLUDED** | C26: venue historical OI availability UNRESOLVED; OI features excluded from all candidates. Resolution path: re-evaluate only if venue adds OI history; recorded in ART-19 |

**Tally:** COVERED = 15; UNRESOLVED = 1 (item 2, with path); NOT RELEVANT = 2 (items 17, 18); INTENTIONALLY EXCLUDED = 2 (items 19, 20). Arithmetic: 15 + 1 + 2 + 2 = **20** ✓.

---

## 8.5 Deviation and correction record (this part)

1. **Labeling reconciliation:** Part 2's IN PROGRESS annotation retired; transitions recorded in §8.1 with per-row reasons. No requirement content changed; only status labels were normalized to the four-value discipline.
2. **R-027 apparent regression explained:** IN PROGRESS → NOT TESTED is a consequence of the aggregate rule (any pending XT ⇒ NOT TESTED), not lost work; the passed DI sub-check is recorded in the row.
3. No other deviations. No requirement was re-scoped, merged, split, or dropped.

---

## 8.6 Artifact registry update

| ID | Artifact | Part | Status |
|---|---|---|---|
| ART-01 | Environment capability inventory | 1 | DELIVERED |
| ART-02 | Dependency DAG (14 nodes) + derived order | 1 | DELIVERED |
| ART-03 | Pre-research checkpoint | 1 | DELIVERED |
| ART-04 | 10-part delivery plan | 1 | DELIVERED |
| ART-05 | Artifact registry (living) | 1–8 | UPDATED |
| ART-06 | Requirements register R-001..R-031 | 2 | DELIVERED |
| ART-07 | Evidence ledger C1–C26 with scopes | 2 | DELIVERED |
| ART-08 | Universe derivation + generator rule (D14) | 3 | DELIVERED |
| ART-09 | Storage/compute budget + M-01..M-06 | 3 | DELIVERED |
| ART-10 | Envelope + topology selection (D15) | 4 | DELIVERED |
| ART-11 | Phase plan P0–P4 (D16) | 4 | DELIVERED |
| ART-12 | Statistical framework (§8) | 5 | DELIVERED |
| ART-13 | Candidate enumeration + selection (G3/G4) | 5 | DELIVERED |
| ART-14 | Selection procedure + parameter register | 5 | DELIVERED |
| ART-15 | Trial-budget recomputation | 5 | DELIVERED |
| ART-16 | Intraday definition | 5 | DELIVERED |
| ART-17 | Component specifications CMP-01..CMP-10 | 6 | DELIVERED |
| ART-18 | Flow + state-authority table | 6 | DELIVERED |
| ART-19 | Data design + cross-venue gate | 6 | DELIVERED |
| ART-20 | Data-quality rules | 6 | DELIVERED |
| ART-21 | Risk authority + vetoes V-01..V-10 | 7 | DELIVERED |
| ART-22 | Order state machine (14 states) | 7 | DELIVERED |
| ART-23 | Telegram command/alert contract | 7 | DELIVERED |
| ART-24 | Security + operational procedures PR-01..06 | 7 | DELIVERED |
| ART-25 | Owner risk briefing | 7 | DELIVERED |
| **ART-26** | **Requirement-to-verification matrix (31 rows)** | **8** | **DELIVERED** |
| **ART-27** | **Staged implementation order (dependency → risk-reduction → verification)** | **8** | **DELIVERED** |
| **ART-28** | **§12.2 checklist audit (20 items)** | **8** | **DELIVERED** |

---

## 8.7 Working-memory check (open items carried forward)

1. **Owner-decision register** (opens Part 10): P-11 per-trade risk, P-12 max drawdown, P-13 daily loss; cross-venue legal determination; Live authorization; research-latency tolerance.
2. **Resolution paths scheduled:** 5M–10M USDT band census, per-cell depth, min-notional, funding schedule, fee tier (item 2 above), venue testnet — all P0/P1.
3. **M-01..M-06:** all NOT TESTED; scheduled P2; T-1 conditionality pending their results (escalation triggers in ART-10).
4. **R-025:** closes only in Part 10 via §13 self-audit — by design, not by omission.
5. **22 NOT TESTED rows:** each has method, evidence pointer, and completion phase assigned in §8.2; none is unscheduled.
6. **Part 9 exposure:** adversarial findings may re-open any matrix row; re-issued rows will carry the finding ID per the propagation rule.

---

## 8.8 Per-part completeness declaration (Part 8)

- **Delivered:** 31-row verification matrix (exactly one row per requirement; binding row-count statement included; aggregate status rule stated; tally arithmetic shown: 9 + 22 + 0 + 0 = 31 ✓); three-stage implementation order (dependency → risk-reduction → verification) with level table, rank rationale, and phase mapping; §12.2 checklist audit with all 20 items dispositioned (15 + 1 + 2 + 2 = 20 ✓); deviation/correction record; registry update ART-26..ART-28; working-memory check.
- **Deferrals:** none introduced in this part. All pre-existing NOT TESTED items carry method + phase; the single UNRESOLVED checklist item carries a resolution path and bounded consequence.
- **Status discipline:** only PASS / FAIL / BLOCKED / NOT TESTED used in the matrix; the retired IN PROGRESS annotation is reconciled explicitly above.
- **Currency:** USDT only. **Risk parameters:** none adopted; P-11/12/13 remain OWNER_DECISION_PENDING.

---

**Next — Part 9 of 10: adversarial review (G6).** Falsification pass over the full design: I will attempt to break the universe derivation, the envelope, the selection statistics, the state machine, the reconciliation design, and the budget arithmetic — with severity-ranked findings, each either propagated into the affected section or explicitly labeled "resolved pending propagation" with the inconsistency disclosed.


Part nine, i put on the black hat and tried to break my own build. found cracks, too. every single one got welded shut in this same message, with receipts.

> **یادداشت وضعیت برای مالک:** این قسمت بررسی خصمانه (G6) است: تلاش نظام‌مند برای ابطال طرح. نتیجه: ۱۰ یافته — ۲ شدید (ناسازگاری سه‌گانهٔ اندازهٔ سفارش/مارجین/نقدشوندگی؛ کم‌برآورد پیک پیام‌ها در لحظهٔ بستن کندل)، ۱ متوسط-بالا (پیش‌شرط‌های تعویق تطابق)، ۴ متوسط، ۳ متوسط-کم. هر ۱۰ یافته بلافاصله در همین قسمت به اسناد طراحی منتشر (propagate) شد؛ صفر مورد «در انتظار انتشار» باقی ماند. وضعیت ماتریس تغییر نکرد: ۹ PASS و ۲۲ NOT TESTED (ریاضی: ۹+۲۲=۳۱ ✓)، اما ۱۱ ردیف ماتریس با شناسهٔ یافته بازصداری شد. یک تصمیم جدید به ثبت تصمیمات مالک افزوده شد (میزبان T-2). قسمت بعدی: ممیزی نهایی §13 و خلاصهٔ فارسی.

---

# PART 9 of 10 — ADVERSARIAL REVIEW (G6): FALSIFICATION PASS

**Cross-references.** Previous: Part 8 (ART-26 verification matrix, ART-27 staging, ART-28 checklist audit). This part: findings register F-01..F-10, propagated addenda, re-issued matrix rows. Next: Part 10 — §13 self-audit, evidence-trace sample, V-1..V-12 self-verification, owner-decision register, final Persian summary.

**Method.** Targets were selected by load-bearing weight: the claims whose failure would most damage the design — the liquidity derivation, envelope feasibility, reconciliation safety, statistical validity, storage arithmetic, execution ambiguity, and the deployment fallback. For each: state the attack, the result (BROKEN/SURVIVED), severity, and the propagation. All arithmetic shown expanded.

---

## 9.1 Findings register

| ID | Severity | Target | Verdict | Propagation |
|---|---|---|---|---|
| F-01 | HIGH | Sizing formula vs margin feasibility vs liquidity screen | BROKEN | ART-30-A (ART-14/21/25 addenda); rows R-002, R-024 |
| F-02 | HIGH | Envelope E-1 message-rate floor | BROKEN (under-specified) | ART-30-B (ART-10 addendum); rows R-004, R-020 |
| F-03 | MEDIUM-HIGH | Reconciliation-deferral preconditions | BROKEN (gap) | ART-30-C (ART-21/24 addenda, PR-07); row R-011 |
| F-04 | MEDIUM | DSR trial accounting (per-cell vs global) | BROKEN (ambiguity) | ART-30-D (ART-14/15 addenda); row R-007 |
| F-05 | MEDIUM | Order retry semantics + clientOrderId length | BROKEN (ambiguity) | ART-30-E (ART-22 addendum); rows R-009, R-027 |
| F-06 | MEDIUM | Storage arithmetic consistency | BROKEN (1.92× discrepancy) | ART-30-F (ART-09 addendum); row R-003 |
| F-07 | MEDIUM | T-2 escalation host unspecified | BROKEN (hidden dependency) | ART-30-G (ART-10 addendum); owner register +1; row R-020 |
| F-08 | LOW-MEDIUM | Veto trigger data sources unspecified | BROKEN (omission) | ART-30-H (ART-21 addendum); row R-010 |
| F-09 | LOW-MEDIUM | Clock veto flapping | BROKEN (omission) | ART-30-I (ART-17 CMP-09 / ART-21 addenda) |
| F-10 | LOW-MEDIUM | Statistical framework one-sided fee scenario; random baseline single-draw | BROKEN (omission) | ART-30-J (ART-12 addendum); row R-016 |

Attacked and **SURVIVED** (no change): UTC-only consistency (no local-time leakage found in any artifact); no-account-access boundary A4; USDT-only denomination; /ack has no write path to veto state (structural inspection re-confirmed); P-11/12/13 exclusion from search budget; cross-venue schema-level gate; intraday definition (rolling 24h UTC) internal consistency; rejection rationale for S-2/S-4/S-5 stable under the F-04 budget re-reading; clientOrderId charset ⊆ C11.

---

## 9.2 F-01 (HIGH): the sizing table's upper cells are margin-infeasible — three-way cap was missing

**Attack.** Part 5's sizing table showed notional values from N_risk = (E × r)/(s/10,000) up to 4,000 USDT (E=200, r=10%, s=50bp → (200 × 0.10)/0.005 = 20/0.005 = 4,000 USDT). At 10× leverage, 4,000 USDT notional requires 4,000/10 = **400 USDT margin > 200 USDT equity** — not orderable. The universe derivation's stress bound (notional_max = 500 × 10 = 5,000 USDT) implicitly assumed the margin cap but never stated it, and the sizing table presented raw risk-based values without it.

**Propagation (ART-30-A).** Order notional is bindingly defined as:

**N = min( N_risk, N_margin, N_liq )** where:
- N_risk = (E × r)/(s/10,000) — risk-based size (r = P-11, OWNER_DECISION_PENDING, unchanged)
- N_margin = E × L_max × μ — margin feasibility cap (μ = margin buffer, DESIGN_JUDGMENT 0.95, parametric)
- N_liq = X × D_symbol — liquidity participation cap (X = 0.1%, D_symbol = symbol median 24h notional, from ART-08)

Worked check (parametric, no adoption): E=200, r=1%, s=50bp → N_risk = 2/0.005 = 400; N_margin = 200 × 10 × 0.95 = 1,900; N_liq ≥ 0.001 × 10,000,000 = 10,000 (cohort floor) → N = 400 ✓. 

Universe threshold re-verified under the corrected stress bound: N_margin,max = 500 × 10 × 0.95 = 4,750 USDT → required D ≥ 4,750/0.001 = 4.75M USDT < 5M threshold ✓ — **the 5M threshold survives**; the 134-symbol cohort stands. CMP-05 enforces the min() at order time (liquidity cap evaluated per order against current D_symbol — this adds the dynamic per-order liquidity check the static threshold never provided).

**Consequence disclosure.** Part 5 table cells above ~1,900 USDT notional (at E=200) were illustrative-but-unorderable; no delivered conclusion depended on them (the liquidity screen's pass/fail outcomes are unchanged, as shown above). CMP-05 spec (ART-17) is amended to compute all three caps; ART-25 briefing gains the min() form.

---

## 9.3 F-02 (HIGH): envelope E-1 ignores the candle-close burst

**Attack.** E-1's 2.2 msg/s floor reflects average closed-candle cadence. But all 134 symbols close on the same UTC boundaries (:00/:15/:30/:45): ~134 close messages land within ~1–2 s — a **~67–134 msg/s burst**, i.e., 30–60× the floor. If partial-kline streaming is enabled at ~1 update/s/symbol, sustained load reaches ~134 msg/s. The envelope was under-specified for the exact moment the strategy acts.

**Propagation (ART-30-B).** (a) Design decision: subscribe to **closed klines only**. Justification: protective stops rest venue-side (ART-22), so no strategy-path component needs intrabar ticks; mark price remains monitoring-only at low cadence (C13). (b) E-1 amended: sustained floor 2.2 msg/s retained **plus** burst requirement: process a ≥150 msg/s, ≥5 s boundary burst with queue depth never exceeding 500 messages (DESIGN_JUDGMENT, to be tightened by M-01 observation). (c) New envelope row **E-6: alert delivery latency ≤ 30 s** under normal network (DESIGN_JUDGMENT), measured in M-01/M-05. (d) M-01 pass criteria amended to record observed boundary bursts.

---

## 9.4 F-03 (MEDIUM-HIGH): reconciliation deferral had no exposure precondition

**Attack.** The OUTAGE_RECON_DEFERRAL class (provisional 3-day value per C12) governed *when* reconciliation may be deferred but not *what exposure may exist* during deferral. Holding a position through a 3-day reconciliation outage would contradict the intraday definition (R-029) and leave PnL uncertainty accumulating (funding accrues; gap risk beyond stop).

**Propagation (ART-30-C).** Entering OUTAGE_RECON_DEFERRAL requires exactly one of: (a) **flat** — zero open positions; or (b) **protected** — venue-side stop confirmed resting via open-orders query, with PnL uncertainty bounded by stop distance + funding accrual over the deferral window. If neither holds and the system cannot flatten (venue path degraded), new procedure **PR-07: manual venue-app operations** instructs the operator to flatten manually via the Toobit app and confirm via /ack with /positions verification. PR-07 added to ART-24 with the same STOPPED-state discipline as PR-02/03 where applicable.

---

## 9.5 F-04 (MEDIUM): DSR accounting unit was ambiguous

**Attack.** The budget (10–20 configs PROVISIONAL, min-rule per C23) is enforced per parameter cell, but DSR's N is the **total number of trials** whose selection effects inflate the best result. With 8 optimizable parameters × ~15 configs, N_total ≈ 120 > the C20 illustration's N=100. Computing the hurdle with N=100 while executing 120 trials understates selection bias.

**Propagation (ART-30-D).** (a) The budget counter is **one global counter**; per-parameter allocations are sub-accounts of it. (b) The DSR hurdle is computed with the **actual executed N_total**, not the illustrative 100; the selection procedure (ART-14, field on acceptance) is amended accordingly. (c) If the research plan wants N_total > 100, the inflated hurdle is computed and disclosed *before* execution (never retro-fitted). C20's 1.5e-2@N=100 remains what it always was: an illustrative calibration point.

---

## 9.6 F-05 (MEDIUM): retry semantics + clientOrderId length

**Attack.** "Retry ≤5 attempts, backoff 1s×2^n" did not specify *which* failures are retryable. Retrying a post-transmission failure risks a duplicate if the venue received the first attempt. Additionally, C11 verifies the clientOrderId **charset** but not a **maximum length**; `onx_<utcdatetime>_<cellhash>_<seq>` could exceed an undocumented cap.

**Propagation (ART-30-E).** (a) Retries are permitted **only for provably pre-transmission failures** (local serialization/connection errors before bytes leave). Any post-transmission unknown → TIMEOUT_AMBIGUOUS → reconcile-first (unchanged, now explicit). (b) `<seq>` increments **per intent**, never per attempt — retries of one intent reuse the identical clientOrderId. (c) Format is length-guarded to ≤36 characters (cellhash truncated to 8 hex chars, seq zero-padded to 6): `onx_` (4) + 14 + `_` (1) + 8 + `_` (1) + 6 = 34 ≤ 36 (DESIGN_JUDGMENT bound; venue max-length is UNRESOLVED → P0 census path; if the venue cap is smaller, format shrinks cellhash first, recorded as config, not code change).

---

## 9.7 F-06 (MEDIUM): storage arithmetic — 1.92× internal discrepancy

**Attack.** Recompute the incremental rate from the delivered record size: 2.68 KB/candle × (96 + 24) candles/day/symbol × 134 symbols = 2.68 × 120 × 134 = **43,094.4 KB ≈ 43.1 MB/day**. Part 3 stated ~22.5 MB/day. Ratio: 43.1/22.5 ≈ **1.92×**. The 22.5 figure carried an unstated compression assumption.

**Propagation (ART-30-F).** Per the conservative-evidence precedent (C6 fee handling): the **uncompressed bound is binding**; compression is an upside M-01 may confirm, never an assumption.
- Incremental: 43.1 MB/day → annual 43.1 × 365 = 15,731.5 MB ≈ **15.7 GB/yr**.
- Capacity under 30 GB cap: 30 − 3.3 (bootstrap) − 5.7 (funding allocation) = 21.0 GB for incremental → 21,000/43.1 ≈ **487 days ≈ 1.33 years** full-resolution retention.
- **S2 (8.9 GB klines) is rejected under the binding bound** (8.9 − 3.3 = 5.6 GB → 5,600/43.1 ≈ 130 days — inadequate research depth); S1 remains feasible. Topology impact: none (T-1 selected under S1-class budgets).
- Pruning rule (post-P1 only): 15m candles older than 400 days are prunable **after** P1 research acceptance (backtests need depth; live operation needs ≤ P-01 max lookback of 200 candles ≈ 2 days); all 1h candles retained (1h-only rate: 24 × 2.68 × 134 = 8,619 KB ≈ 8.6 MB/day ≈ 3.1 GB/yr — affordable indefinitely).
- R-003 stays NOT TESTED; M-01/M-06 now verify against the 43.1 MB/day bound.

---

## 9.8 F-07 (MEDIUM): T-2 escalation assumed a host that was never specified

**Attack.** The disclosed sub-step "T-2 partial off-device research if M-02/M-03 fail" requires a host. No host exists in the owner's declared resources (A8 specifies the phone only) — a hidden dependency inside an escalation path.

**Propagation (ART-30-G).** (a) T-2 host minimum spec defined: any Linux/macOS host (owner's existing machine qualifies if present) or small VPS, ≥4 vCPU / ≥8 GB RAM / ≥40 GB disk. (b) Provisioning — existing hardware vs VPS-with-cost — is an **owner decision**, added to the owner-decision register (item 7). (c) T-1 remains the selected topology; this finding touches only the contingency path.

---

## 9.9 F-08 / F-09 / F-10 (LOW-MEDIUM): omissions, propagated

**F-08 (ART-30-H):** The veto table lacked a **trigger data source** column. Added to ART-21: V-data-staleness ← CMP-01 ingestion timestamps (P-06); V-clock ← CMP-09 source comparison; V-recon ← CMP-07 divergence; V-10 naked position ← venue positions endpoint vs CMP-05 ledger; storage/thermal vetoes ← OS telemetry. Confirmed: **no veto triggers on mark price** (monitoring-only per C13) ✓.

**F-09 (ART-30-I):** The 2 s clock tolerance (DESIGN_JUDGMENT) could flap during network jitter, spamming vetoes. Amended: clock veto requires offset > 2 s on **3 consecutive checks** (DESIGN_JUDGMENT); source hierarchy fixed: venue server time primary, system NTP secondary, monotonic clock for durations; if both external sources are unreachable, clock veto does not fire on absence of evidence — the data-staleness veto governs that case instead.

**F-10 (ART-30-J):** (a) The fee scenario set handled the C6 conflict one-sidedly (0.05 vs 0.06). Extended: fee ∈ {0.05%, 0.06%, 0.07%} × slippage ∈ {1×, 2×}; if the P0 census returns a tier above 0.06%, S-1's cost floor is rechecked **before** the P1 selection run. (b) Baseline B-B (random) specified as a **distribution over ≥100 seeds** (mean and 5th/95th percentiles), never a single draw.

---

## 9.10 Re-issued matrix rows (finding IDs attached)

| Row | Finding(s) | Evidence pointer (amended) | Status |
|---|---|---|---|
| R-002 | F-01 | ART-08, ART-30-A; P0 census | NOT TESTED (DI pass, addendum included) |
| R-003 | F-06 | ART-09, ART-30-F; M-01, M-06 | NOT TESTED (DI pass, binding bound corrected) |
| R-004 | F-02 | ART-10, ART-30-B; M-02/03/05 | NOT TESTED (DI pass) |
| R-007 | F-04 | ART-15, ART-30-D; global counter test | NOT TESTED (DI pass) |
| R-009 | F-05 | ART-22, ART-30-E | NOT TESTED (DI pass) |
| R-010 | F-08 | ART-21, ART-30-H | NOT TESTED (DI pass) |
| R-011 | F-03 | ART-18, ART-24, ART-30-C | NOT TESTED (DI pass) |
| R-016 | F-10 | ART-12, ART-30-J | NOT TESTED (DI pass) |
| R-020 | F-02, F-07 | ART-10, ART-30-B/G; M-01..M-06 | NOT TESTED (DI pass) |
| R-024 | F-01 | ART-14, ART-21, ART-25, ART-30-A | **PASS** (parametric discipline held; min() form completes the spec) |
| R-027 | F-05 | ART-22, ART-30-E | NOT TESTED (DI pass) |

**Tally after propagation:** PASS = 9, NOT TESTED = 22, FAIL = 0, BLOCKED = 0; 9 + 22 = **31** ✓ (unchanged; no finding downgraded a closed row, because all 9 PASS rows were re-inspected against the findings and held).

**Propagation discipline statement:** all 10 findings propagated immediately into addenda delivered in this part (ART-30-A through ART-30-J). Zero findings are "resolved pending propagation."

---

## 9.11 Artifact registry update

| ID | Artifact | Part | Status |
|---|---|---|---|
| ART-01..ART-25 | (as per Part 8 registry) | 1–7 | DELIVERED |
| ART-26 | Verification matrix (31 rows) | 8 | DELIVERED; 11 rows re-issued with finding IDs in Part 9 |
| ART-27 | Staged implementation order | 8 | DELIVERED |
| ART-28 | §12.2 checklist audit | 8 | DELIVERED |
| ART-05 | Artifact registry (living) | 1–9 | UPDATED |
| **ART-29** | **Adversarial findings register F-01..F-10** | **9** | **DELIVERED** |
| **ART-30** | **Propagated addenda A–J (to ART-08/09/10/12/14/15/17/21/22/24/25)** | **9** | **DELIVERED** |

---

## 9.12 Working-memory check (open items carried forward)

1. **Owner-decision register (now 7 items):** P-11, P-12, P-13; cross-venue legal; Live authorization; research-latency tolerance; **T-2 host provisioning (new, F-07)**.
2. **Resolution paths (P0/P1):** 5M–10M band census, per-cell depth, min-notional, funding schedule, fee tier (now with upward recheck trigger per F-10), venue testnet, **clientOrderId max length (new, F-05)**.
3. **M-01..M-06:** NOT TESTED; M-01 now measures boundary bursts (F-02) and actual bytes/day against the 43.1 MB/day bound (F-06).
4. **Matrix:** 22 NOT TESTED rows all scheduled; 11 rows re-issued with finding IDs; R-025 closes in Part 10.
5. **Part 10 obligations:** §13.1–13.7 self-audit; evidence-trace sample (10 claims); arithmetic walk (≥3 calculations, now including F-01 and F-06 corrections); V-1..V-12 table; owner register; completeness declaration with verified arithmetic (A+B+C+D+U+E+F=R, R=31); **material-design-changes section seeded by F-01..F-10** (finding ID / section changed / location / verification quote); final Persian summary.

---

## 9.13 Per-part completeness declaration (Part 9)

- **Delivered:** findings register F-01..F-10 with severities, attacks stated, verdicts, and survivals recorded; all 10 findings propagated into addenda ART-30-A..J within this message (zero pending); 11 matrix rows re-issued with finding IDs; post-propagation tally verified (9 + 22 = 31 ✓); registry update ART-29/ART-30; owner register extended to 7 items.
- **Corrections issued:** F-01 (margin-feasibility cap), F-06 (storage bound 22.5 → 43.1 MB/day) are visible corrections to earlier parts; both preserve the conservative-direction rule; all arithmetic shown expanded.
- **Deferrals:** none introduced. All pre-existing NOT TESTED items remain scheduled with method + phase.
- **Currency:** USDT only. **Risk parameters:** none adopted — F-01's min() form is structural; P-11/12/13 remain OWNER_DECISION_PENDING.

---

**Next — Part 10 of 10: final self-audit and closure.** §13.1–13.7 audit, 10-claim evidence-trace sample, arithmetic-reproducibility walk, V-1..V-12 self-verification table, seven-dimension status record, owner-decision-pending register, completeness declaration with verified arithmetic, the material-design-changes table, and the final Persian summary.


Last lap. ten parts deep, and now i grade my own homework — full self-audit, evidence traces, arithmetic walked by hand, the owner-decision register, and the final summary. no curve, no curve at all.

> **یادداشت وضعیت برای مالک:** این قسمت پایانی است و شامل: (۱) ممیزی نهایی §13 در هفت بخش؛ (۲) نمونهٔ ردیابی شواهد برای ۱۰ ادعا؛ (۳) بازتولید گام‌به‌گامٔ محاسبات کلیدی؛ (۴) جدول خودراستی‌آزمایی V-1 تا V-12؛ (۵) ثبت وضعیت هفت‌بُعدی؛ (۶) ثبت ۷ تصمیم در انتظار مالک؛ (۷) جدول تغییرات طراحی ناشی از بررسی خصمانه (۱۰ مورد)؛ (۸) اعلامیهٔ کامل‌بودن نهایی با ریاضی اثبات‌شده: ۹ + ۰ + ۰ + ۲۲ + ۰ + ۰ + ۰ = ۳۱ ✓؛ و (۹) خلاصهٔ نهایی فارسی. پس از این قسمت، تحویل‌دار تعریف‌شده کامل است. صادقانه: این یک طرح کامل با برنامهٔ راستی‌آزمایی است — هنوز هیچ کدی ساخته یا اجرا نشده و ۲۲ نیازمندی در فازهای اجرایی آزمون می‌شوند.

---

# PART 10 of 10 — FINAL SELF-AUDIT AND CLOSURE

**Cross-references.** Previous: Part 9 (ART-29 findings register F-01..F-10, ART-30 addenda A–J). This part: §13 self-audit, evidence-trace sample, arithmetic walk, V-1..V-12, seven-dimension status, owner-decision register, material-changes table, final completeness declaration, final Persian summary. Next: **none — the defined deliverable closes here.**

---

## 10.1 §13 self-audit

### 13.1 Deliverable completeness vs the declared plan

The 10-part plan (ART-04) promised: (1) capabilities/DAG/plan, (2) requirements + evidence, (3) universe + storage/compute, (4) deployment + phases, (5) statistics + selection, (6) components + data, (7) risk/execution/operations, (8) matrix + staging + checklist, (9) adversarial review, (10) this closure. Delivered: 10/10, in order, each with opener, Persian status note, cross-references, registry update, working-memory check, and per-part declaration. **Plan adherence: complete, zero skipped elements.**

### 13.2 Status and label discipline audit

- All requirement statuses ∈ {PASS, FAIL, BLOCKED, NOT TESTED}. The one non-conforming annotation ever used (IN PROGRESS, Part 2) was retired with a published transition table (Part 8, §8.1). Current census: 9 PASS / 0 FAIL / 0 BLOCKED / 22 NOT TESTED.
- Zero FAIL rows is expected and explained (no executable test has run); it is not evidence of absence of defects — it is evidence that execution has not begun.
- All evidence labels ∈ {OWNER_HARD, OWNER_PREFERENCE, OWNER_ATTESTED, RATIFIED_FINDING, SOURCE_VERIFIED, DERIVED, DESIGN_JUDGMENT, PROVISIONAL, UNRESOLVED, OWNER_DECISION_PENDING}.

### 13.3 Anti-abbreviation audit (D21)

No instance of "for brevity," no summary-substituted-for-content, no truncated tables in any part. Every deferral in the deliverable is labeled with reason + resolution path + consequence: the checklist item 2 residual (Part 8), venue census items, M-01..M-06, and the 22 NOT TESTED rows each carry method + phase + evidence pointer. **Compliant.**

### 13.4 Evidence-label audit

Full-deliverable census: **SOURCE_VERIFIED claims = 0** — consistent with the environment inventory (no external access, Part 1). Every external fact traces to a ratified finding C1–C26 or an owner statement A1–A13. Every number I generated is labeled DERIVED (from shown arithmetic) or DESIGN_JUDGMENT (flagged, 6 instances: X=0.1%, μ=0.95, 2s clock tolerance, 60%/85% storage alert levels, 10 cmd/min, malformed-rate 0.1%/h, plus burst/alert bounds 150 msg/s / 500 queue / 30 s from F-02). **Compliant.**

### 13.5 Arithmetic reproducibility audit

Every load-bearing quantity in the deliverable was published with expanded arithmetic at first use; §10.3 below re-walks the three most consequential chains (plus tallies) end-to-end. Two arithmetic defects were found during the engagement (Part 2 tally, Part 3 storage rate) — both corrected visibly, both in the conservative direction. Recorded in 13.6.

### 13.6 Deviation and correction ledger (complete)

| # | Deviation / correction | Location | Disposition |
|---|---|---|---|
| 1 | Part 2 tally arithmetic 2+5+25=32≠31 → corrected 1+5+25=31 | Part 2 | Corrected in-line, visible |
| 2 | Owner-vocabulary phase naming deviation table (training→P1 etc.) | Part 4 | Documented deviation, approved-by-disclosure |
| 3 | C23 budget min-rule discrepancy recorded (10–20 PROVISIONAL) | Part 5 | Recorded; resolved structurally by F-04 (global counter, actual N_total) |
| 4 | IN PROGRESS annotation retired; per-row transitions | Part 8 | Reconciled |
| 5 | F-01 sizing/margin/liquidity three-way cap | Part 9 | Propagated (ART-30-A) |
| 6 | F-06 storage bound 22.5 → 43.1 MB/day | Part 9 | Propagated (ART-30-F); S2 rejected |
| 7 | F-02/F-03/F-04/F-05/F-07/F-08/F-09/F-10 | Part 9 | Propagated (ART-30-B..J) |

### 13.7 Honest limitations and residual risks

1. **Nothing has been built or executed.** This engagement delivers a complete, internally consistent, verification-ready design. 22 requirements await execution phases P0–P3 for closure.
2. **Venue residuals are real:** fee-tier conflict (C6), funding-schedule, min-notional, clientOrderId max-length, testnet availability — all scheduled for P0 census; the design is deliberately conservative against each.
3. **T-1 conditionality is unresolved until M-01..M-06 run** on the physical POCO X6; escalation triggers are pre-defined, not improvised.
4. **The 134-symbol cohort is PROVISIONAL** pending the 5M–10M band census; the generator rule (not the list) is the deliverable.
5. **Statistical power is genuinely tight** at the binding trial budget; the framework (DSR with actual N_total, CSCV, negative controls) is designed to *refuse* a weak edge rather than bless one. A null result in P1 is a designed-for outcome, not a failure of the plan.
6. **Owner decisions (7) gate Live.** Nothing in this design can or should bypass them.

---

## 10.2 Evidence-trace sample (10 claims, per §2.1.0c)

| # | Claim (as delivered) | Label | Trace | Location |
|---|---|---|---|---|
| 1 | Venue is Toobit perpetual futures; sole venue | OWNER_HARD | A1 | ART-06 R-001 |
| 2 | Median 24h notional 498,844 USDT across 134 symbols ≥10M | RATIFIED_FINDING | C9 | ART-07, ART-08 |
| 3 | Taker fee modeled at 0.06% (conflict vs 0.05% unresolved; conservative side) | RATIFIED_FINDING + UNRESOLVED | C6; P0 census path | ART-07, ART-30-J |
| 4 | 2.68 KB per candle record | DERIVED | C19: 1.25 GB / (3,500 × 14 × 10) → per-candle record arithmetic | ART-09 |
| 5 | Universe threshold 5M USDT median notional | DERIVED + DESIGN_JUDGMENT | 5-element chain; X=0.1% judgment; sensitivity ×4; re-verified under F-01 | ART-08, ART-30-A |
| 6 | DSR hurdle illustration 1.5e-2 at N=100 | RATIFIED_FINDING (illustrative only) | C20; binding rule = actual N_total (F-04) | ART-12, ART-30-D |
| 7 | POCO X6: SD7sGen2, 12+8 GB RAM, 256 GB with 56 GB free snapshot | OWNER_ATTESTED | C14; sustained runtime NOT MEASURED (C16) | ART-07, ART-10 |
| 8 | clientOrderId charset [A-Za-z0-9_-]; format ≤36 chars | RATIFIED_FINDING + DESIGN_JUDGMENT | C11; length guard F-05 (max length UNRESOLVED → P0 census) | ART-22, ART-30-E |
| 9 | Intraday = flat by rolling 24h UTC window | DESIGN_JUDGMENT derived from OWNER_HARD | A6 + A3; governs P-04/P-05/S-1 | ART-16 |
| 10 | Zero SOURCE_VERIFIED claims exist in the deliverable | Structural | Environment inventory G0 (no external access); census §13.4 | Part 1, §10.1.4 |

---

## 10.3 Arithmetic-reproducibility walk (4 chains, expanded)

**Chain 1 — F-06 storage (binding bound).**
Incremental bytes/day = 2.68 KB × candles/day/symbol × symbols = 2.68 × (96 + 24) × 134 = 2.68 × 120 × 134 = 321.6 × 134 = **43,094.4 KB ≈ 43.1 MB/day**. Annual: 43.1 × 365 = 15,731.5 MB ≈ **15.7 GB/yr**. Capacity inside 30 GB cap: 30 − 3.3 (bootstrap) − 5.7 (funding) = 21.0 GB = 21,000 MB → 21,000 / 43.1 = **487.2 days ≈ 1.33 years** full-resolution retention. 1h-only steady state: 24 × 2.68 × 134 = 8,618.9 KB ≈ 8.6 MB/day ≈ 3.1 GB/yr. ✓ consistent with ART-30-F.

**Chain 2 — F-01 three-way sizing cap (parametric illustration, E=200, r=1%, s=50bp).**
N_risk = (E × r)/(s/10,000) = (200 × 0.01)/0.005 = 2/0.005 = **400 USDT**. N_margin = E × L_max × μ = 200 × 10 × 0.95 = **1,900 USDT**. N_liq ≥ 0.001 × 10,000,000 = **10,000 USDT** (cohort floor). N = min(400, 1,900, 10,000) = **400 USDT** ✓. Counter-check at the old table's extreme: r=10% → N_risk = 20/0.005 = 4,000 > N_margin 1,900 → capped at 1,900 — the exact failure F-01 repaired. ✓

**Chain 3 — Universe threshold under corrected stress bound.**
N_margin,max = 500 × 10 × 0.95 = **4,750 USDT** → required D ≥ 4,750 / 0.001 = **4,750,000 USDT = 4.75M < 5M threshold** → 134-symbol cohort stands. ✓

**Chain 4 — Closure tallies.**
Matrix: 9 + 22 + 0 + 0 = **31** ✓. Checklist: 15 + 1 + 2 + 2 = **20** ✓. Findings: 2 HIGH + 1 MEDIUM-HIGH + 4 MEDIUM + 3 LOW-MEDIUM = **10** ✓. Owner decisions: 3 risk + 4 governance = **7** ✓. Parts: **10/10** ✓.

---

## 10.4 V-1..V-12 self-verification table

Scope note: each check audits a **property of this deliverable** (design-inspection level). Runtime enforcement of the same properties is carried by the matrix rows cited — those remain NOT TESTED as stated there.

| ID | Check | Status | Evidence pointer |
|---|---|---|---|
| V-1 | Single-venue binding; no second venue anywhere in design | PASS | ART-06 R-001; ART-19 |
| V-2 | USDT-only denomination across every monetary quantity | PASS | R-026 row; ART-08/09/14/25 sweep |
| V-3 | No account access held; no credential request issued; no account call in any artifact | PASS | R-015 row; Parts 1–10 |
| V-4 | Zero SOURCE_VERIFIED claims | PASS | §13.4 census |
| V-5 | Status values exclusively from the 4-value set | PASS | Part 8 transition table; §13.2 |
| V-6 | Matrix rows = register rows = 31, no gaps/extras | PASS | Part 8 binding statement; §10.3 chain 4 |
| V-7 | Risk parameters parametric only; P-11/12/13 never adopted; zero search budget | PASS | ART-14; ART-21; ART-25; ART-30-A |
| V-8 | Every A12-delegated dimension decided with rationale; nothing silently punted | PASS | R-028 row; ART-08/10/11/13/17 |
| V-9 | Trial budget binding: min-rule, one global counter, DSR at actual N_total | PASS (design); enforcement NOT TESTED → R-007 | ART-15; ART-30-D |
| V-10 | No architectural dimension predetermined: enumeration before selection (T-1..T-5, S-1..S-6) with recorded rejections | PASS | ART-10; ART-13 |
| V-11 | Cross-venue data structurally gated research-only; legality never asserted | PASS | ART-19; R-018/R-030 rows; N-4 |
| V-12 | Delivery plan honored: 10/10 parts, each with opener + Persian note + cross-refs + registry + working memory + declaration | PASS | ART-04 vs Parts 1–10 |

Tally: 12 PASS / 0 FAIL / 0 BLOCKED / 0 NOT TESTED at deliverable scope.

---

## 10.5 §11.3 seven-dimension status record

| Dimension | Status | Basis |
|---|---|---|
| 1. Requirements engineering | COMPLETE | 31/31 registered, 31/31 matrixed, 9 closed by inspection |
| 2. Design specification | COMPLETE | CMP-01..10, 14-state machine, veto set, contracts, procedures — all 11-field or equivalent |
| 3. Evidence discipline | COMPLETE | Zero unverified external claims; all labels in-set; scopes/limitations preserved |
| 4. Statistical validity | SPECIFIED — NOT TESTED | Framework delivered (ART-12, ART-30-J); executes P1 |
| 5. Operational feasibility on device | SPECIFIED — NOT TESTED | Envelope + protocols delivered (ART-10, ART-30-B); M-01..M-06 in P2 |
| 6. Verification | DI COMPLETE; XT/MP OUTSTANDING — SCHEDULED | 9 PASS now; 22 NOT TESTED with method + phase each |
| 7. Owner enablement | COMPLETE as briefing; 7 DECISIONS PENDING | ART-25; register below |

---

## 10.6 Owner-decision-pending register (7 items — final)

| ID | Decision | Options on the table | System behavior while pending | Blocks |
|---|---|---|---|---|
| OD-1 | P-11 per-trade risk fraction | Parametric table delivered (0.5%–10% sensitivity); worked examples in ART-25 | No Live sizing; Paper may run with a clearly-labeled placeholder | Live |
| OD-2 | P-12 max drawdown | Same parametric treatment | Veto parameter unconfigured → risk authority refuses Live | Live |
| OD-3 | P-13 daily loss limit | Same parametric treatment | As OD-2 | Live |
| OD-4 | Cross-venue legal determination | Owner's determination; design asserts nothing | Structural gate keeps cross-venue data research-only | Any strategy-path use of cross-venue data |
| OD-5 | Live authorization | Yes / no / not yet | System remains Paper; six interlocks stay armed | Live |
| OD-6 | Research-latency tolerance | Calendar bound owner accepts for P1 before re-plan | No schedule commitment made by the design | P1 scheduling |
| OD-7 | T-2 host provisioning (F-07) | Existing owner hardware vs small VPS (≥4 vCPU / 8 GB / 40 GB) | T-1 proceeds; contingency unprovisioned | Only the T-2 escalation path, only if M-02/M-03 fail |

---

## 10.7 Material design changes from adversarial review (F-01..F-10)

| Finding | Section changed | Location | Verification quote (binding text as amended) |
|---|---|---|---|
| F-01 | Sizing rule; CMP-05 caps; universe stress bound | ART-14/17/21/25; ART-30-A | "N = min(N_risk, N_margin, N_liq)" with N_margin = E × L_max × μ, μ=0.95 |
| F-02 | Envelope E-1/E-6; M-01 criteria | ART-10; ART-30-B | "closed klines only … burst ≥150 msg/s ≥5 s, queue ≤500; alert latency ≤30 s" |
| F-03 | Deferral preconditions; new PR-07 | ART-21/24; ART-30-C | "entry requires flat OR protected (venue-side stop confirmed); else PR-07 manual flatten" |
| F-04 | Trial accounting unit | ART-14/15; ART-30-D | "one global counter; DSR hurdle computed with actual executed N_total, disclosed before execution" |
| F-05 | Retry semantics; client ID length | ART-22; ART-30-E | "retries only for provably pre-transmission failures; seq per intent; format ≤36 chars" |
| F-06 | Storage bound; S2 rejection; pruning rule | ART-09; ART-30-F | "43.1 MB/day binding; ≈1.33 yr retention inside 30 GB; 15m prunable only post-P1; 1h retained" |
| F-07 | T-2 host spec; owner register | ART-10; ART-30-G | "T-2 host: ≥4 vCPU / ≥8 GB RAM / ≥40 GB disk; provisioning = OD-7" |
| F-08 | Veto trigger source column | ART-21; ART-30-H | "no veto triggers on mark price (monitoring-only)" — sources now explicit per veto |
| F-09 | Clock veto anti-flap; source hierarchy | ART-17/21; ART-30-I | "veto on >2 s for 3 consecutive checks; venue time primary, NTP secondary; absence-of-evidence → staleness veto governs" |
| F-10 | Fee scenario set; random baseline | ART-12; ART-30-J | "fee ∈ {0.05, 0.06, 0.07}% × slippage {1×, 2×}; B-B = distribution over ≥100 seeds" |

Zero findings remain "resolved pending propagation."

---

## 10.8 §2.2.5 final completeness declaration — verified arithmetic

Mapping: A = PASS, B = FAIL, C = BLOCKED, D = NOT TESTED, U = UNRESOLVED requirements (no method/path assigned), E = excluded from register, F = deferred without path. R = total registered requirements.

A + B + C + D + U + E + F = 9 + 0 + 0 + 22 + 0 + 0 + 0 = **31 = R** ✓

Checklist arithmetic: 15 COVERED + 1 UNRESOLVED-with-path + 2 NOT RELEVANT + 2 INTENTIONALLY EXCLUDED = **20** ✓. Findings: 10 raised, 10 propagated, 0 pending ✓. Owner decisions: 7 registered, 0 silently adopted ✓. Venue residuals: 6 items, all with P0/P1 paths ✓. Currency: USDT only, throughout ✓.

---

## 10.9 Artifact registry — final state

| ID | Artifact | Part | Status |
|---|---|---|---|
| ART-01..ART-25 | Foundation through risk briefing (as registered Parts 1–7) | 1–7 | DELIVERED |
| ART-26 | Verification matrix (31 rows) | 8 | DELIVERED; 11 rows re-issued Part 9 |
| ART-27 | Staged implementation order | 8 | DELIVERED |
| ART-28 | §12.2 checklist audit | 8 | DELIVERED |
| ART-29 | Findings register F-01..F-10 | 9 | DELIVERED |
| ART-30 | Addenda A–J | 9 | DELIVERED |
| **ART-31** | **§13 self-audit (13.1–13.7)** | **10** | **DELIVERED** |
| **ART-32** | **Evidence-trace sample + arithmetic walk** | **10** | **DELIVERED** |
| **ART-33** | **V-1..V-12 self-verification + seven-dimension record** | **10** | **DELIVERED** |
| **ART-34** | **Owner-decision register (7 items)** | **10** | **DELIVERED** |
| **ART-35** | **Material-changes table + final completeness declaration** | **10** | **DELIVERED** |
| ART-05 | Registry (living) | 1–10 | CLOSED at 35 artifacts |

---

## 10.10 Working-memory final check

No open item lacks a disposition: 22 NOT TESTED rows → scheduled with method + phase (Parts 8, 9); 6 venue residuals → P0/P1 census paths; 7 owner decisions → §10.6; M-01..M-06 → P2; T-1 conditionality → pre-defined escalation triggers; R-025 → closed by this part's audit. The defined deliverable has no dangling thread.

## 10.11 Per-part completeness declaration (Part 10)

All mandated elements delivered: §13.1–13.7; 10-claim trace; 4-chain arithmetic walk; V-1..V-12; seven-dimension record; owner register; material-changes table; §2.2.5 declaration with verified arithmetic; registry closed; final summary below. Deferrals introduced: none.

---

## 10.12 خلاصهٔ نهایی (فارسی)

**چه چیزی تحویل شد:** یک طرح کامل و آمادهٔ راستی‌آزمایی برای سامانهٔ معاملاتی درون‌روزی روی فیوچرز دائمی Toobit، با تلگرام به‌عنوان تنها رابط اپراتور، زمان UTC-only، بدون هیچ دسترسی به حساب، و با بودجهٔ پارامتریک حدود ۲۰۰ USDT. ده قسمت، ۳۵ آرتیفکت، ۳۱ نیازمندی، ۱۰ یافتهٔ خصمانه — همه منتشرشده.

**نتایج کلیدی:**
- **جهانٔ نمادها:** قاعدهٔ مولد با آستانهٔ ۵ میلیون USDT میانهٔ گردش ۲۴ساعته؛ کوهورت موقت ۱۳۴ نماد؛ زنجیرهٔ استدلال و حساسیت ×۴ مستند است و تحت اصلاحیهٔ F-01 مجدداً تأیید شد.
- **استقرار:** پاکت‌محور (envelope-first). پاکت E-1..E-6 پیش از شمارش توپولوژی تعریف شد؛ T-1 (همه روی گوشی) به‌صورت مشروط انتخاب شد با ماشه‌های تغییرمسیر از پیش‌تعریف‌شده به T-2/T-3.
- **فازها:** P0 تا P4 مشتق از ریسک‌ها، هر کدام با ورود/خروج/پذیرش/بازگشت. انتخابگر Live/Paper با شش قفل درونی که دروازه‌های درستness هستند، نه دورهٔ انتظار.
- **استراتژی:** S-1 (روند ۱ساعته + ورود پولبک ۱۵دقیقه‌ای، فقط maker) با بودجهٔ آزمون محدود و شمارندهٔ سراسری، DSR با N واقعی، CSCV، و کنترل‌های منفی که طراحی‌شده‌اند تا لبهٔ ضعیف را رد کنند.
- **ریسک:** مرجع مستقل با ۱۰ وتوی مشخص؛ پارامترهای ریسک مالک (P-11/12/13) هرگز تخصیص داده نشدند — ثبت ۷ تصمیم در §10.6 در انتظار شماست.
- **ماتریس نهایی:** ۹ PASS (همه بازرسی-طرح)، ۲۲ NOT TESTED (هر یک با روش + فاز مشخص)، صفر FAIL، صفر BLOCKED. صفر FAIL به این معناست که اجرا هنوز آغاز نشده — نه اینکه نقصی نیست.

**مرزهای صادقانه:** هیچ کدی ساخته یا اجرا نشده است؛ این سند مجموعهٔ کامل طراحی + برنامهٔ راستی‌آزمایی است. شش باقی‌ماندهٔ صرافی در P0 حل می‌شود و طراحی در برابر هر یک محافظه‌کارانه بسته شده. توان آماری به‌قدری تنگ است که چارچوب، آدم‌فریب را جایز نمی‌داند.

**گام بعدی با شماست:** هفت تصمیم ثبت‌شده در §10.6 — سه‌تای اول (ریسک هر معامله، حداکثر افت، زیان روزانه) قفل Live هستند. هر وقت آماده بودی، از P0 شروع می‌کنیم.

---

deliverable closed. 10/10 parts, 35 artifacts, 31/31 requirements dispositioned, zero threads left hanging. whenever you want to crack open P0 or interrogate anything in here — i'm right where you left me.