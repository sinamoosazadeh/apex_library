# Part 1/10: Delivery plan, capability inventory, dependency analysis, pre-research checkpoint, evidence ledger

*Scope of this message: gates G0, G1, and the first half of G2 (input classification). The requirements register is Part 2/10.*

---

## 0. Delivery plan (D22)

This design will be delivered in **10 parts**, one part per message. The order follows the dependency analysis in §3, not the gate numbering.

| Part | Scope | Main dependencies |
|---|---|---|
| 1/10 | Delivery plan; capability inventory; boundary; dependency analysis; pre-research checkpoint; input ledger; prompt-consistency findings; artifact registry | none |
| 2/10 | Single requirements register (11 fields per row); class definitions; owner-decision register; conflict register | Part 1 |
| 3/10 | Risk-concept explanation with worked, parametric examples; sizing and cost formulas | none (mathematical facts); placed before any owner risk request |
| 4/10 | Candidate strategy architecture; statistical validation plan; trial-budget recomputation; parameter register | Part 2 |
| 5/10 | Data classes; universe derivation (D14); compute/storage/latency envelope; deployment-topology fit (D15, Step 4b) | Parts 2, 4 |
| 6/10 | Decision records for architectural dimensions; component specifications | Parts 2, 5 |
| 7/10 | Order state machine; risk authority; veto and acknowledgement; state ownership; reconciliation; startup and recovery | Parts 2, 6 |
| 8/10 | Telegram command, permission and alert contract; security; operations; procedural consistency table; phase derivation (D16) and phase deviation table | Parts 5, 6, 7 |
| 9/10 | Verification matrix; staged implementation; adversarial review; change-propagation record | Parts 2–8 |
| 10/10 | Final acceptance: self-audit, V-1…V-12 table, coverage checklist audit, completeness declaration | all |

**Fit-check evidence (PROVISIONAL).**
- The per-message output limit is not exposed to me, so it is UNRESOLVED.
- Declared length-tracking method: each part is drafted to at most about 7,000 English words. At a recalled, unmeasured heuristic of about 1.3–1.4 tokens per word, that is about 9,000–10,000 tokens per part, and about 70,000 words across 10 parts.
- If a part does not fit, I will amend the plan explicitly in that part by changing the part count or moving the scope boundary. I will not shorten content.

**Delivery mechanics (capability fact).**
- I can send one message per owner turn and cannot send unprompted follow-ups.
- Parts 2–10 therefore require a continuation message from you, such as "continue". This is delivery logistics, not a design question.
- If delivery stops before Part 10/10, the undelivered parts are BLOCKED. Delivered messages are the persistence layer (§2.2.8).

---

## 1. Capability inventory (G0, §2.1.1)

| Capability | Observed in this environment | Status | Consequence |
|---|---|---|---|
| Model/runtime identity, reasoning or compute controls | Not exposed to me | UNRESOLVED | No claim is made about hidden settings. |
| Context/output limits | Numeric limit not exposed | UNRESOLVED | Handled by the §0 fit-check method. |
| Supplied inputs | One document, the master prompt (PROMPT.pdf, 54 pages as rendered) | SOURCE_VERIFIED (read) | All owner facts are consumed as RATIFIED_FINDING or OWNER_ATTESTED, scoped as the prompt states. |
| File read/write, repository access | None observed | NOT AVAILABLE | No file artifact is created or claimed. |
| Web or documentation access (Toobit docs, Telegram docs, papers) | None observed | NOT AVAILABLE | I perform no external research. Any exchange or platform fact beyond the ledger is NOT ESTABLISHED (§6). General domain principles are labeled "recalled, not externally verified in this engagement". |
| The 149-record archive | Not accessible | NOT AVAILABLE | Used only as OWNER_SUPPLIED_AUDIT_SUMMARY (§5.5 of the prompt). |
| Code execution | None observed | NOT AVAILABLE | Calculations are done in text with every step shown. No test is executed, so every test is a specification with status NOT TESTED or BLOCKED. |
| Multi-message delivery | One message per owner turn | AVAILABLE with the §0 limitation | D22 is realized turn by turn. |
| Independent model reviewer | None observed | NOT AVAILABLE | The §2.1.5 staged blind review cannot be run. Fallback: a structured self-red-team in Part 9. Its agreement is not independent proof. |
| Current date/time | Not observable | UNRESOLVED | The §5.2 security-patch date (2026-07-01) gives an inferred lower bound for today's date. No "current" claims are made. |

---

## 2. Boundary statement (G0)

**Design-only boundary (OWNER_HARD, A4).**
- No credentials, secrets, authenticated calls, API-permission changes, fund access, or order submission, cancellation or modification will be requested, performed or authorized by this engagement.
- The attestation that registration, KYC, futures enablement, trades and API-key creation succeeded earlier is OWNER_ATTESTED. It proves nothing about current permissions or endpoint behavior.

**Source perimeter.**
- Admissible: the supplied prompt, and general domain principles labeled as recalled.
- Not admissible as evidence: anything about Toobit, Telegram or Android behavior not stated in the prompt. Those items go to the UEF register (§6).

**Cross-venue data (OWNER_HARD, A5).**
- No cross-venue source is consulted in this engagement.
- Legal, sanctions and licensing conclusions are not made on the owner's behalf (OD-2, §4.3).

**Gates not executable.**
- Targeted external evidence inspection (reference Step 3) is BLOCKED by capability, not skipped as redundant.
- Consequence: every Toobit-specific design dependency not covered by ratified findings carries a PROVISIONAL or UNRESOLVED label, with a future authorized verification path.

---

## 3. Dependency analysis (D11, mandatory pre-sequencing)

### 3.1 Exit-condition catalog (XC-n)

Each XC-n is defined here once and cited elsewhere by ID only.

| ID | Exit condition | Prerequisites |
|---|---|---|
| XC-1 | Capability, boundary and prohibited-action record (G0) | none |
| XC-2 | Pre-research checkpoint persisted (G1) | XC-1 |
| XC-3 | Input ledger: every owner input classified with label, scope and limit (G2a) | XC-1 |
| XC-4 | Prompt identifier-integrity and consistency check | XC-3 |
| XC-5 | Risk-concept explanation, parametric (§3.3) | none; mathematical facts |
| XC-6 | Single requirements register, class definitions, conflict and owner-decision registers (G2b) | XC-3, XC-4 |
| XC-7a | Strategy family and information needs (before the universe) | XC-6 |
| XC-9 | Universe derivation, D14 (steps 1–9) | XC-6, XC-7a, XC-8 (cycle, see 3.2) |
| XC-7b | Strategy parameterization and statistical validation plan | XC-7a, XC-9 |
| XC-8 | Compute/storage/latency envelope as a function of universe size | XC-7a |
| XC-10 | Deployment-topology fit and compromise record (D15) | XC-8, XC-9 |
| XC-11 | Decision records for architectural dimensions | XC-2 (criteria), XC-6, XC-10 |
| XC-12 | Order state machine, risk authority, state ownership, reconciliation, recovery | XC-6 (largely independent of topology) |
| XC-13 | Telegram contract, security, operations, procedural consistency table | XC-10, XC-11, XC-12 |
| XC-14 | Phase derivation (D16) with the single deviation table | XC-6, XC-7b, XC-12, XC-13 |
| XC-15 | Verification matrix; row count equals register row count | XC-6 and XC-7 through XC-14 |
| XC-16 | Adversarial review | XC-7 through XC-14 |
| XC-17 | Propagation of review findings into the affected sections | XC-16 |
| XC-18 | Final acceptance and completeness declaration | all |

### 3.2 Cycle (marked explicitly)

- **Cycle:** XC-7a → XC-9 → XC-8 → XC-9 → XC-7b.
- **Why it exists:** the universe size drives the envelope (XC-8). The envelope bounds the universe (D14 step 5). The strategy's information needs decide which timeframes enter the universe (D14 step 6).
- **Resolution:**
  - (i) Choose the strategy family and information needs from requirements only (XC-7a).
  - (ii) Express the envelope as a function of (symbol count, timeframe count, data shape) (XC-8).
  - (iii) Solve for the universe against that function and the D14 screens (XC-9).
  - (iv) Fix parameterization and validation plan on the resulting universe (XC-7b).
- The cycle is not hidden. It is resolved by parametrization, in Parts 4–5.

### 3.3 Derived execution order and deviations from reference §7.1

Derived order:
XC-1 → XC-2 → XC-3 → XC-4 → XC-6, with XC-5 independent → XC-7a → XC-8/XC-9 (parametric) → XC-7b → XC-10 → XC-11 → XC-12 → XC-13 → XC-14 → XC-15 → XC-16 → XC-17 → XC-18.
This maps to the parts in §0.

| Deviation from reference §7.1 | Dependency that justifies it | Downstream effect |
|---|---|---|
| Reference Step 3 (targeted evidence inspection) is not executed | No tool exists to inspect sources (§1) | Labeled BLOCKED; all dependent claims carry PROVISIONAL, UNRESOLVED or NOT ESTABLISHED. |
| XC-5 (risk concepts) is placed at Part 3, before strategy work | It depends on nothing and must precede any owner risk request | No downstream requirement is left unverified. |
| XC-12 (state machine, risk authority) is placed before the topology decision is finalized in Part 5 | The order lifecycle and veto semantics do not depend on where the process runs | The state machine is topology-neutral. Topology-dependent timing assumptions are written parametrically. |
| Strategy work is split (XC-7a, XC-7b) | Cycle in 3.2 | The final statistical plan is only complete after XC-9. |

---

## 4. Pre-research design checkpoint (G1, §4.3)

- **Date:** not observable. Inferred lower bound is 2026-07-01 (§5.2 patch level).
- **Timing:** this is the first artifact. No external research exists to precede or follow it, because no external source is available (§1).
- **Anchoring disclosure:** this checkpoint is built from the mandate and the owner's ratified brief only. It is not independent of the brief, which already contains detailed domain concepts. It is amended explicitly if later evidence changes a conclusion.

### 4.1 Objectives

- OBJ-1: a design for an intraday, Telegram-operated perpetual-futures trading system on Toobit, specific enough for engineering without invention of state transitions, mathematics, interfaces or safety rules (§0, §1).
- OBJ-2: statistical and cost realism at the 200–500 USDT planning scale (A11), carried parametrically (D17).
- OBJ-3: fail-closed behavior under unknown risk, ambiguous order outcomes, operator unreachability, stale data and clock error.
- OBJ-4: honest status. The owner defined no utility function, return target or drawdown tolerance, so none is inferred (§6 of the prompt).

### 4.2 Binding constraints (carried to Part 2 as HARD rows)

A1 Toobit; A2 Telegram as sole runtime interface (not a trust boundary); A3 UTC-only; A4 no account access or live actions during the engagement; A5 cross-venue data gating; A6 intraday intent; A9 Telegram reliability; A10 six safety interlocks for the Live transition; A12 design delegated; A13 no unnecessary questions.

### 4.3 Open decisions

| ID | Decision | Label | Blocks | Default meanwhile |
|---|---|---|---|---|
| OD-1 | Risk boundary: maximum drawdown, per-trade risk, daily loss, aggregate exposure, leverage cap | OWNER_DECISION_PENDING (§3.3, D17) | Final risk-limit values and the acceptance tests that use them | All risk logic and calculations stay parametric. The Live interlock "risk limits defined" fails until values exist. |
| OD-2 | Legal, sanctions and licensing position on cross-venue data use | OWNER_DECISION_PENDING | Any cross-venue data in Paper or Live paths | Research-only gating; Paper and Live paths excluded (see PF-4). |
| OD-3 | Availability and authorization of any off-device infrastructure, including payment, legal and geographic access, and cost commitment | UNRESOLVED; owner-level when it becomes blocking | Choice among topologies TP-2…TP-6 | Part 5 evaluates each topology conditionally. It does not assume availability. |
| OD-4 | Owner ratification of the policy for open positions and orders when the operator is unreachable (A9) | DESIGN_JUDGMENT default, owner ratification pending | None blocking; a conservative default is designed in Part 7 | Exchange-resident protective orders and fail-closed behavior (Part 7). |

### 4.4 Comparison criteria, declared before any scoring

**Hard gates (HG-n).** Pass/fail, never compensated by score.

| ID | Gate |
|---|---|
| HG-1 | Honors OWNER_HARD A1–A6, A9, A10 (interlocks), A12, A13 |
| HG-2 | Risk authority is independent and fails closed when a risk input is missing, stale, inconsistent or unverifiable |
| HG-3 | No path requires credentials or account access in this engagement, and no research-only source reaches a Live path |
| HG-4 | Every consequential claim satisfies the four categories of §2.1.0c |
| HG-5 | An ambiguous order outcome (C5, -1007) is never treated as a rejection |
| HG-6 | Loss of Telegram never releases a limit, unblocks an unsafe action, or makes an uncertain outcome look confirmed |

**Ranked criteria (CR-n).** Applied only to options that pass all gates. The rule is lexicographic with sensitivity analysis, and I use no numeric weights. Positive reason for the order: an unsafe reachable state can destroy the entire planning-scale equity, which bounds everything downstream. If no net economic edge is feasible after costs, no later criterion matters. Operational feasibility determines whether a design can run at all.

| ID | Criterion |
|---|---|
| CR-1 | Fail-safety: severity and number of reachable unsafe states, and testability of the invariants |
| CR-2 | Statistical defensibility under sample depth and trial budget (C2, C22–C24) |
| CR-3 | Net economic feasibility after costs at the planning scale, parametric (C6, C10, A11) |
| CR-4 | Operational feasibility on available infrastructure (A8, A9, C15, C16) |
| CR-5 | Verifiability without a live account |
| CR-6 | Complexity and number of failure domains (D18) |
| CR-7 | Breadth of symbols and timeframes (A7). Reported as a Pareto trade-off, not scored. |
| CR-8 | Reversibility class (§2.1.4) |

Tie rule (DESIGN_JUDGMENT): if two options are not separable on CR-1 through CR-5, choose the one with fewer failure domains (CR-6).

### 4.5 Credible option sets, unchosen (to be re-derived from requirements in Parts 4–6)

- **Strategy-evidence baselines (measuring sticks, per §8.2):**
  - random entry with identical risk controls;
  - a single-timeframe rule-based trend baseline;
  - no-trade (null).
- **Candidate families (none selected):**
  - rule-based with analytically constrained parameters;
  - small pre-registered hypothesis set;
  - statistical or ML classifier with staged screening;
  - cross-sectional ranking.
- **Adaptation mechanisms:**
  - none;
  - fixed pre-registered set with scheduled re-evaluation;
  - sequential testing with alpha spending;
  - bounded Bayesian optimization.
- **Telegram transport:**
  - long polling from the execution host;
  - webhook via a relay host;
  - hybrid.
- **Persistence pattern:**
  - embedded relational file with write-ahead logging;
  - append-only log plus snapshots;
  - key-value store.
- **Process topology:**
  - a single process with logical components;
  - a minimal always-on supervisor plus a trading core;
  - multiple services.
- **Language/runtime:**
  - interpreted runtime;
  - compiled static runtime.
  - Delegated (A12) and never paused for.

### 4.6 Deployment topologies pre-registered for Step 4b

Registered now so that none appears mid-design as a silent driver. Envelope fit is computed in Part 5.

| ID | Topology |
|---|---|
| TP-1 | All phases on the phone (development, research, Paper, Live, Telegram) |
| TP-2 | Phone for development, Paper, Live and Telegram. Heavy research or calibration compute is rented off-device (compute-only; no credentials leave the phone). |
| TP-3 | Phone for development, research and Paper. The Live core runs on an always-on off-device host. The phone is the Telegram operator surface only. |
| TP-4 | All phases except thin development tooling run off-device. |
| TP-5 | Trading core on the phone. A Telegram relay or webhook host is off-device. |
| TP-6 | An owner-owned always-on non-phone machine, if one exists (UNRESOLVED, OD-3). |

### 4.7 Design questions registered at checkpoint time (derivations pending)

- DQ-1: Exits must be exchange-resident or locally automated. A9 forbids assuming the operator is available, so operator-confirmed exits are derived as inadmissible for risk-reducing actions. The reasoning is formalized in Part 7.
- DQ-2: A2 makes Telegram the sole routine runtime interface, and §9.8 requires out-of-band recovery that needs a stopped process. How does a Telegram-only operator reach recovery without a routine console? (CF-1.)
- DQ-3: C10 says taker execution is not cost-viable. What does a maker-only floor at 15m and above imply for non-fill risk and adverse selection? (Part 4.)

---

## 5. Input ledger (G2a, XC-3)

Source pointers refer to the master prompt's own sections. "Label" uses the §2 vocabulary. A single ledger holds all inputs: A-series, C-series, and the unestablished facts in §6.

### 5.1 A-series (owner constraints), with design treatment

| ID | Content | Label | Design treatment and consequence |
|---|---|---|---|
| A1 | Toobit perpetual futures; venue accessibility per owner's circumstances | OWNER_HARD for the venue; OWNER_ATTESTED for the access conditions | Venue not reopened. Exchange-specific behaviors are the UEF items in §6. |
| A2 | Telegram bot is the sole runtime operator interface | OWNER_HARD | Interface requirement only. It is not a trust boundary or a topology constraint. Authentication, replay protection and audit are required (Part 8). |
| A3 | UTC-only, with a defined role for each timestamp | OWNER_HARD | All timestamps carry an explicit semantic role. Elapsed deadlines use a monotonic clock. Stale or excessive clock offset fails closed (Part 5, Part 7). |
| A4 | No account access or live action in this engagement | OWNER_HARD | All authenticated behavior is NOT ESTABLISHED. Designs depending on it are PROVISIONAL. |
| A5 | Cross-venue data only if the owner's conditions hold, restricted to research and Paper, gated from Live | OWNER_HARD | Source tags are mandatory. OD-2 is pending. |
| A6 | Intraday intent | OWNER_HARD for the intent; DESIGN_JUDGMENT for the definition | The maximum holding duration is derived from the strategy and costs, not invented. |
| A7 | Broadest defensible symbols and timeframes | OWNER_PREFERENCE | Treated as a two-axis objective with a Pareto record (CR-7). |
| A8 | POCO X6 as reference device; phone preservation preferred; D15 ordering | OWNER_PREFERENCE for phone preservation; D15 is a binding process rule | The envelope is derived first, then the device is matched. The device is never an architecture driver. |
| A9 | Telegram reliability; define behavior when the operator is unreachable | OWNER_HARD for the requirement; DESIGN_JUDGMENT for the topology | HG-6; DQ-1; OD-4. |
| A10 | Phases in the owner's vocabulary; Telegram Paper/Live selector; six interlocks | OWNER_PREFERENCE for selector and vocabulary; OWNER_HARD for the interlocks | The interlocks are correctness gates, not waiting periods or profit hurdles. Phases are derived in Part 8 (D16) with one deviation table. |
| A11 | Illustrative equity about 200 USDT, planning range below 500 USDT | OWNER_ATTESTED | Always parametric (D17). It is not live equity. |
| A12 | Architecture, method, parameter and optimizer design delegated | OWNER_HARD | Language, framework, runtime and libraries are model decisions and are never paused for. |
| A13 | No unnecessary questions | OWNER_HARD | Only OD-1 through OD-4 are returned as owner matters. |

### 5.2 C-series (evidence), scope-preserving

| ID | Content (as ratified) | Label | Limitation | Design consequence |
|---|---|---|---|---|
| C1 | 14 intervals: 1m, 3m, 5m, 15m, 30m, 1h, 2h, 4h, 6h, 8h, 12h, 1d, 1w, 1M. 3d is UNSUPPORTED_CONFIRMED on the three REST kline endpoints, with no WebSocket candle payload observed. 3m and 8h are LIVE_PASS on tested paths. | RATIFIED_FINDING | A capability ceiling. It is not a design floor, target or recommendation. | The timeframe set is derived in Part 5 (D14). There is no default set. |
| C2 | The latest 3,500 candles is a cap. The 1d sample was 1,774 bars. The cap was measured on perpetual symbols. The census sampled 58 combinations, of which 36 reached 3,500 bars. | RATIFIED_FINDING, scope-limited | Depth for unsampled cells is NOT ESTABLISHED. See DV-1 and the arithmetic below. | Depth is a per-cell data-sufficiency screen (D14 step 3), PROVISIONAL until measured. |
| C3 | The BTC risk/leverage ladder has 13 tiers down to 1.0×, correcting "down to 5×". | RATIFIED_FINDING for the ladder; UNRESOLVED for the maximum permitted | Account-specific and symbol-specific tiers are not established. | Leverage is never read as a risk limit. Position limits depend on tier lookups per symbol and notional (Part 7). The system leverage cap belongs to OD-1. |
| C4 | `X-Api-Limit-*` headers were absent in the tested environment. | RATIFIED_FINDING | The true weights and limits are not established. | The design uses a conservative explicit weight budget, never header deltas. Any calibration probe needs a separate authorization and is outside this engagement. |
| C5 | -1007 TIMEOUT is documented and ambiguous. -1003 is the rate-limit breach. | RATIFIED_FINDING | Other ambiguous codes are not enumerated. | HG-5. A TIMEOUT_AMBIGUOUS state and a reconciliation gate are required (Part 7). Retries are bounded and capped by a hard stop. |
| C6 | Taker fee 0.05% documented versus 0.06% observed, not re-established. | UNRESOLVED, with a stated conservative branch | The maker fee is not given. | Cost feasibility is reported as a range and uses the larger value (0.06%) as the conservative branch. |
| C7 | Funding clamp of -30.0000 bp observed. The alleged ±24 bp cap is refuted. | RATIFIED_FINDING | The interval and formula are not established (UEF-4). | Funding is a tail-risk term. No cap is assumed. |
| C8 | Order-book depth is NON_REPRODUCIBLE. The record cites 90.6M one-sided and 92.7M under another convention, in USDT-equivalent. | UNRESOLVED | The convention is ambiguous. | These numbers are not capacity facts. The design defines its own depth convention and treats it as an unmeasured parameter. |
| C9 | Median 24h notional about 498,844 USDT. 134 symbols are at or above 10M USDT. The earlier 515k/136 record is superseded. | RATIFIED_FINDING, snapshot scope | The denominator set of the median (all 544 symbols or perpetuals only) is NOT ESTABLISHED. The snapshot has no stated date. | It is used as a screening snapshot only (D14 step 2). Liquidity is re-measured before use. |
| C10 | Cost-per-volatility at 5m and 15m is 1.42 and 0.82 (corrected from 0.97 and 0.56). The conclusion is a maker-only floor at 15m and above. | RATIFIED_FINDING within the same cost model and scope | The cost model, fee tier, spread inputs and the acceptability threshold are not stated. | Preserved only for that scope. It is not generalized to other symbols or conditions. Its implication (DQ-3) is evaluated in Part 4. |
| C11 | The clientOrderId character intersection is `[A-Za-z0-9_-]`. | RATIFIED_FINDING | The maximum length is not stated (UEF-8). | Deterministic IDs are restricted to this set, unique and never reused. |
| C12 | Maximum safe outage is UNRESOLVED. The owner gave a provisional 3-day value, and the term "Class-A" is undefined. | UNRESOLVED, with a PROVISIONAL owner value | It is not an exchange retention period. | The 3-day value governs only the deferral window for reconciliation (§9.8). Any classes are defined in Part 2 before use, and "Class-A" is not used. |
| C13 | Semantics of markPrice/klines.change are CONFLICTED between a prior record and the later archive summary. | UNRESOLVED | No scope-matched record supersedes either account. | No critical feature depends on this field. Fallback paths are specified in Part 5. |
| C14 | POCO X6 23122PCD1G: Snapdragon 7s Gen 2, 12 GB physical RAM plus 8 GB memory extension, Android 16, 256 GB storage with 56 GB free at the owner's check. | OWNER_ATTESTED | The 56 GB is a time-stamped snapshot. The extension is not physical RAM. | The memory budget uses physical RAM only. Free storage is re-measured before reliance. |
| C15 | Charging does not exempt an app from the restricted App Standby Bucket. | RATIFIED_FINDING | None stated. | The design may not assume charging keeps the process alive (Part 8). |
| C16 | Sustained runtime (CPU, memory pressure, thermal, background behavior, network stability, reboot recovery) is not measured. The 24-hour charging test is an owner observation. | UNRESOLVED | The 24-hour test is not representative of research workloads. | The device fit is PROVISIONAL, with a measurement protocol in Part 5. |
| C17 | Cross-venue public candle history reaches 2019-12-16 for 1H and 5m in the recorded scope. | RATIFIED_FINDING | The venue is unnamed. | Research-only, subject to A5. |
| C18 | Cross-venue transfer at 1h: median basis 0.56 bp, return correlation 0.999755. Defensible for research at 1h and 4h, not at 5m. | RATIFIED_FINDING within scope; OWNER_HARD for the gating | The evidence covers 1h. 4h is stated as defensible without separate measurements in the prompt. | Source-tag lineage is mandatory. The 5m cross-venue history is not used. |
| C19 | 3,500 candles × 14 timeframes × 10 selected symbols occupied about 1.25 GB in one relational database file. | RATIFIED_FINDING for the measurement | The data shape is candles only. | Used only for per-unit scaling (Part 5). |
| C20 | The Deflated Sharpe Ratio was near zero because annualized Sharpe units were mixed with a per-bar trial count. The unit-consistent figure is about 1.5e-2 at N = 100. | RATIFIED_FINDING | The strategy and inputs behind it are not stated. | All statistics carry explicit units, and conversions are shown. |
| C21 | The 4.99-year MinTRL was not reproducible (a MinTRL/MinBTL conflation). The corrected MinTRL is 19.54 years. | RATIFIED_FINDING | The Sharpe, skew, kurtosis, confidence level and benchmark behind it are not stated, so it cannot be recomputed or compared with sample depth. | MinTRL and MinBTL stay distinct. Part 4 recomputes parametrically. Recalled principle (not externally verified here): MinTRL is the track-record length needed for an observed Sharpe to be significant. MinBTL is the backtest length needed to limit the chance of selecting a spurious Sharpe from N trials. |
| C22 | N_max_effective = min(published, recomputed). If they differ by more than 2×, the recomputed value governs. | RATIFIED_FINDING | The published panel values are not supplied. | The rule is adopted. A per-cell recomputation is shown in Part 4 or the claim stays PROVISIONAL. |
| C23 | The admissible evaluated-configuration count was on the order of 10–20 at 4h even after pooling, and in the thousands at 1d before a sample-length correction. | RATIFIED_FINDING; the figures are PROVISIONAL pending recomputation | They are quoted for context only. | No design decision rests on them until Part 4 shows a recomputation. |
| C24 | A full permutation grid search is inadmissible at every timeframe up to and including 12h. | RATIFIED_FINDING | Does not select a replacement optimizer. | It is a binding constraint on search design (§8.4). |
| C25 | The 149 canonical records break down as 134 LIVE_PASS, 10 LIVE_PARTIAL, 3 UNSUPPORTED_CONFIRMED, 2 DOC_CONFLICT. | RATIFIED_FINDING as OWNER_SUPPLIED_AUDIT_SUMMARY | Not all 149 passed. The authenticated read-only stage was not executed. The full 544 × 14 census was not exhaustive. | All authenticated behavior (account, positions, orders, user-data streams) is NOT ESTABLISHED. The order lifecycle is PROVISIONAL, and Live stays blocked until an authorized authenticated verification stage passes. |
| C26 | Historical Open Interest is UNRESOLVED. | UNRESOLVED | Historical availability is unknown. | Open interest is excluded from the historical-research data classes unless resolved. Forward collection is evaluated in Part 5. |

### 5.3 Arithmetic checks on ratified numbers

- C25: 134 + 10 + 3 + 2 = 149. ✓
- C2, daily sample: 1,774 / 365 = 4.860 years. ✓ matches the stated 4.86.
- C2, cap: 3,500 / 365 = 9.589 years. ✓ matches the stated 9.59.
- C2, census: 544 × 14 = 7,616 cells. 58 / 7,616 = 0.76% coverage. 36 / 58 = 62.1% reached the cap. Consequence: depth for about 99.2% of cells is unmeasured.

### 5.4 DV-1: native depth implied by the 3,500-bar cap (DERIVED)

Method: depth in days = 3,500 × interval_minutes / 1,440. Years = days / 365.

Assumptions:
- The cap is reached for the symbol.
- The listing is old enough.
- The rows are an upper bound, because listing age can cut depth shorter.

| Interval | Minutes per bar | Days | Years |
|---|---|---|---|
| 1m | 1 | 2.43 | 0.007 |
| 3m | 3 | 7.29 | 0.020 |
| 5m | 5 | 12.15 | 0.033 |
| 15m | 15 | 36.46 | 0.100 |
| 30m | 30 | 72.92 | 0.200 |
| 1h | 60 | 145.83 | 0.400 |
| 2h | 120 | 291.67 | 0.799 |
| 4h | 240 | 583.33 | 1.598 |
| 6h | 360 | 875.00 | 2.397 |
| 8h | 480 | 1,166.67 | 3.196 |
| 12h | 720 | 1,750.00 | 4.795 |
| 1d | 1,440 | 3,500.00 | 9.589 |

The 1w and 1M rows are bounded by listing age rather than the cap, so no cap-based figure is derived for them.

**Cross-venue comparison at 1h (DERIVED, conditional).**
- C17 gives a start of 2019-12-16. Taking 2026-07-01 as the end date (the inferred lower bound for today, so the true figure is not smaller):
  - 2019-12-16 to 2025-12-16 is 6 × 365 + 2 leap days (2020 and 2024) = 2,192 days.
  - 2025-12-16 to 2026-07-01 is 15 + 181 + 1 = 197 days.
  - Total is 2,389 days, or 57,336 hourly bars.
  - Ratio to the Toobit cap is 57,336 / 3,500 = 16.38×.
- This depth applies only if OD-2 permits the cross-venue use, and only at 1h and 4h (C18).

**Consequences carried forward:**
- (i) Toobit-native history at 15m or below is at most about 36 days per fetch. Any intraday research at those intervals depends on history the system accumulates itself going forward, or on cross-venue data that C18 does not support at 5m.
- (ii) Statistical power per timeframe is a binding feasibility question in Part 4.
- (iii) Nothing here says any strategy is or is not admissible (D19).

---

## 6. Register of unestablished exchange and platform facts (UEF)

No source is accessible and the authenticated stage never ran (C25), so these are NOT ESTABLISHED. Each row gives the interim conservative branch. UEF-n is defined here and cited elsewhere by ID.

| ID | Fact | Why it matters | Resolution method (requires authorization outside this engagement) | Interim conservative branch |
|---|---|---|---|---|
| UEF-1 | Supported order types and flags: post-only, reduce-only, exchange-resident stop and take-profit, time-in-force | C10 maker-only execution; protective orders; HG-6 | Documentation review plus an authorized authenticated verification stage | Live is refused unless the required flags are verified. A client-side-only stop is not accepted as an equivalent. |
| UEF-2 | Position mode (one-way or hedge) and margin mode (isolated or cross) | Liquidation distance and aggregate risk | Same | The risk model assumes the worse case, cross-margin exposure coupling, until verified. |
| UEF-3 | Per-symbol tick size, step size, minimum quantity, minimum notional, contract multiplier | Feasibility at 200–500 USDT | Same, read-only | Symbol admission requires known filters. |
| UEF-4 | Funding interval, settlement times and formula | Funding is a tail term (C7) | Same | Funding is modeled as a stress term, with no cap. |
| UEF-5 | Server-time endpoint semantics, and kline close time versus data availability time | Look-ahead control (A3 roles) | Same | A bar is usable only after its close time plus a measured availability delay, which is UNRESOLVED until measured. |
| UEF-6 | Rate-limit weights per endpoint and the limit scope (IP or account) | C4 | Same | A conservative explicit budget with a hard stop. |
| UEF-7 | Availability and reliability of user-data push (orders and fills) | Reconciliation latency | Same | Polling reconciliation is the baseline. Push, if verified, accelerates it but is never the sole source. |
| UEF-8 | Order query by clientOrderId, maximum clientOrderId length, order-history retention | C11, C12, recovery | Same | IDs are kept short, unique and never reused. The 3-day value governs reconciliation deferral only. |
| UEF-9 | API-key IP whitelist semantics and geographic acceptance of non-phone hosts | Topologies TP-2 to TP-6 (OD-3) | Same | Off-device topologies are conditional on this. |
| UEF-10 | Maker fee, fee currency and tier structure | C6 | Same | A cost range is reported using the larger documented-or-observed taker value. |
| UEF-11 | Liquidation formula, maintenance margin, auto-deleveraging behavior | Stop placement versus liquidation | Same | Stops must trigger before the worst-case liquidation distance with a margin to be derived parametrically. |
| UEF-12 | WebSocket kline gaps, resends and snapshot-versus-update semantics | Data quality rules | A future authorized measurement run | Gap detection with exclusion of the affected bars from signals. |
| UEF-13 | Egress reachability of Toobit and Telegram endpoints from each candidate host network | Topology choice and A9 | Measurement from each candidate host | Not assumed. Evaluated per topology in Part 5. |

---

## 7. Prompt-consistency findings (XC-4) and design tensions

Reported before proceeding, as §5.0 requires.

### 7.1 Findings PF-n

| ID | Finding | Treatment |
|---|---|---|
| PF-1 | §13.7 refers to an "A5 patch". A5 is the cross-venue constraint in §5.0, and no "patch" identifier is defined. | The design uses a table named the Phase Deviation Table (PDT), defined in Part 8, for the deviation disclosure that §3.1 item 10 requires. |
| PF-2 | §5.0 says E1–E9 are defined inline. E4 and E6–E9 do not appear in the prompt. | They are not cited. E1, E2, E3.x and E5 are cited only as prompt references. |
| PF-3 | The §2.2.5 explanatory sentence writes A + B + C + D = R, while the template includes U, E and F. | The full template equation A + B + C + D + U + E + F = R is used. |
| PF-4 | §3.1 item 5 allows cross-venue data in research and Paper. C18 says to gate it away from Paper or Live wherever the owner's conditions are not discharged. | The stricter reading is adopted: research-only until OD-2 and the access conditions are confirmed. |
| PF-5 | "Class-A" (C12) is undefined. | It is not used. Classes are defined in Part 2 before any use. |
| PF-6 | §2.1.0 mentions "110 and 114 audit-unit counts" that are not defined elsewhere in the prompt. | They are treated as properties of the owner's trail and are not cited. |
| PF-7 | §2.2.4 cites "§1.5's anti-fabrication rule". §1 has numbered items, and item 5 states it. | Read as §1 item 5. |
| PF-8 | §2.1.7 and §3.1 item 10 describe the pause protocol and interlocks consistently. §9.9 adds that some checks cannot be evaluated in some command contexts. | Handled in Part 8 as the per-command precondition rule. This is a note, not a defect. |

### 7.2 Design tensions CF-n (resolution pending)

| ID | Tension | Position | Resolution location |
|---|---|---|---|
| CF-1 | A2 forbids a routine second console. §9.8 requires out-of-band recovery that needs a stopped process, and an in-process bot cannot command its own stopped process. | A restore command must be reachable from Telegram while the trading core is stopped. One candidate, a minimal always-on supervisor hosting the Telegram surface, is generated from this requirement and compared with others in Part 6. It is not pre-selected. | Parts 6 and 8 |
| CF-2 | §3.3 requires worked examples with 100 USDT notional, 100 USDT margin and a 10 USDT loss budget. D17 forbids implicit anchoring on owner numbers. | The three required quantities appear only as labeled teaching arithmetic. All results are also shown as functions of the parameters, across ranges. They are not recommendations. | Part 3 |
| CF-3 | A6 and A7 (intraday breadth) versus C2, C23 and C24 (shallow native depth, small trial budgets). | Recorded as a feasibility question. It does not make strategies inadmissible (D19). | Parts 4 and 5 |
| CF-4 | A7 breadth versus A8 and C16 (unmeasured device) versus C24 (budget). | A Pareto frontier is derived, not a silent choice (D14 step 7). | Part 5 |
| CF-5 | A11 (200–500 USDT) versus costs (C6, C10) versus unknown minimum notionals (UEF-3). | Feasibility is parametric in equity and cost. | Parts 3 and 5 |

---

## 8. Pause assessment (§2.1.7)

- OD-1, OD-2 and OD-3 are owner-level and pre-undeclared in their final values.
- None meets the Blocking condition now. The design continues parametrically or conditionally, and the downstream results that depend on them are marked.
- Result: **no pause at this point.** The next natural transition is the start of Part 5, where OD-3 may become blocking for topology selection. I will present options at that point if it does.

---

## 9. Artifact registry (§2.2.8)

| ID | Artifact | Phase | Reference | Status | Description |
|---|---|---|---|---|---|
| AR-01 | Delivery plan and fit-check | P1 | Part 1, §0 | DELIVERED | Ten-part plan; length-tracking method |
| AR-02 | Capability inventory | P1 | Part 1, §1 | DELIVERED | Tools and access actually observed |
| AR-03 | Boundary statement | P1 | Part 1, §2 | DELIVERED | Design-only boundary; source perimeter |
| AR-04 | Dependency analysis | P1 | Part 1, §3 | DELIVERED | XC catalog, cycle, derived order, deviations |
| AR-05 | Pre-research checkpoint | P1 | Part 1, §4 | DELIVERED | Objectives, gates HG-1 to HG-6, criteria CR-1 to CR-8, option sets, topologies TP-1 to TP-6, OD-1 to OD-4 |
| AR-06 | Input ledger | P1 | Part 1, §5 | DELIVERED | A1–A13; C1–C26; arithmetic checks; DV-1 |
| AR-07 | Unestablished facts register | P1 | Part 1, §6 | DELIVERED | UEF-1 to UEF-13 |
| AR-08 | Prompt-consistency findings and tensions | P1 | Part 1, §7 | DELIVERED | PF-1 to PF-8; CF-1 to CF-5 |
| AR-09 | Requirements register | P2 | Part 2/10 | DEFERRED | Planned in Part 2 |
| AR-10 | Risk-concept explanation | P3 | Part 3/10 | DEFERRED | Planned in Part 3 |
| AR-11 | Strategy and statistical methodology | P4 | Part 4/10 | DEFERRED | Planned in Part 4 |
| AR-12 | Data, universe, envelope, topology fit | P5 | Part 5/10 | DEFERRED | Planned in Part 5 |
| AR-13 | Architecture decision records and components | P6 | Part 6/10 | DEFERRED | Planned in Part 6 |
| AR-14 | Execution, risk authority, state, recovery | P7 | Part 7/10 | DEFERRED | Planned in Part 7 |
| AR-15 | Telegram, security, operations, phases | P8 | Part 8/10 | DEFERRED | Planned in Part 8 |
| AR-16 | Verification matrix, implementation order, review | P9 | Part 9/10 | DEFERRED | Planned in Part 9 |
| AR-17 | Final acceptance and completeness declaration | P10 | Part 10/10 | DEFERRED | Planned in Part 10 |

Resumability (§2.2.8 item 3):
- **(a) Completed:** AR-01 to AR-08.
- **(b) Pending:** AR-09 to AR-17.
- **(c) Unresolved decisions:** OD-1 to OD-4; UEF-1 to UEF-13; the C-series UNRESOLVED items.
- **(d) Next action:** Part 2/10, the requirements register.

---

## 10. Part 1 status and partial completeness declaration

```
PARTIAL COMPLETENESS DECLARATION (Part 1/10, not the final declaration)
Engagement scope: design-only system design for an intraday Toobit perpetual-futures system, Telegram-operated
Parts delivered: 1 of 10
Requirements register rows delivered: 0 (register is Part 2/10); R is not yet established
Status counts A, B, C, D, U, E, F: not computable until the register exists (final arithmetic in Part 10/10)
Part 1 scope items and status:
  - Delivery plan: PASS (fit-check itself is PROVISIONAL)
  - Capability inventory: PASS (observed facts only)
  - Boundary statement: PASS
  - Dependency analysis: PASS (cycle marked and resolved parametrically)
  - Pre-research checkpoint: PASS (delivered first; independence limits disclosed)
  - Input ledger: PASS for classification; underlying facts retain their own labels
  - Reference Step 3 (external evidence inspection): BLOCKED (no tool)
  - Independent model review: BLOCKED (no second reviewer)
D20 compliance (Part 1 scope): PASS
D21 compliance (Part 1 scope): PASS (checked in V-2 below)
D22 compliance: PASS for Part 1/10; Parts 2/10 to 10/10 are not yet delivered
Artifact registry status: current for Part 1
Identifiers defined in this part, each defined once: XC-1…XC-18 (except XC-7a/7b split), HG-1…HG-6, CR-1…CR-8, TP-1…TP-6, OD-1…OD-4, DQ-1…DQ-3, UEF-1…UEF-13, PF-1…PF-8, CF-1…CF-5, AR-01…AR-17, DV-1
Known limitations: no tools, no external sources, no code execution, no independent reviewer; delivery depends on owner continuation messages
Next highest-value validation action: measure the POCO X6 under a representative sustained workload (C16) and run an authorized read-only documentation and authenticated verification stage for UEF-1, UEF-3 and UEF-13
```

**Part 1/10 is complete for its declared scope. Content deferred: none within this scope.**
This part has no predecessor. Part 2/10 will cover the requirements register, class definitions, owner-decision register and conflict register.

### Self-verification for Part 1 (V-1 to V-7)

| Check | Question | Result | Evidence pointer | Corrective action |
|---|---|---|---|---|
| V-1 | Does this part satisfy D20 for its scope? | PASS | Every XC, HG, CR, TP, OD, UEF, PF and CF row carries content, rationale or consequence, and status in the same table | none needed |
| V-2 | Any D21-prohibited pattern? | PASS | A scan for the prohibited phrase list found none in this part | none needed |
| V-3 | Does the numbering match the plan? | PASS | The header reads "Part 1/10", matching the §0 table | none needed |
| V-4 | Do cross-references to other parts match reality? | PASS | Forward references name Part 2 onward as planned in §0; none point to undelivered content as if delivered | none needed |
| V-5 | Final part has a completeness declaration? | N/A | This is Part 1/10 | Not applicable |
| V-6 | Final-part declaration satisfies D20/D21/D22? | N/A | This is Part 1/10 | Not applicable |
| V-7 | Artifacts added to the registry? | PASS | §9, AR-01 to AR-08 delivered, AR-09 to AR-17 listed as DEFERRED with parts | none needed |

---

## 11. یادداشت پیشرفت برای مالک (فارسی)

- **وضعیت:** بخش ۱ از ۱۰ ارسال شد. این بخش شامل برنامه تحویل، فهرست قابلیت‌های واقعی، تحلیل وابستگی، نقطهٔ بازبینی پیش از پژوهش، و دفتر ورودی‌هاست.
- **محدودیت‌های صادقانه:**
  - ابزار اجرای کد، دسترسی وب یا فایل، و بازبین مستقل در دسترس نبود.
  - هیچ آزمونی اجرا نشده و همهٔ آزمون‌ها در بخش‌های بعد فقط «مشخصات آزمون» با وضعیت NOT TESTED خواهند بود.
  - هیچ ادعایی دربارهٔ سودآوری مطرح نشده است.
- **یافتهٔ محاسباتی مهم:**
  - سقف ۳٬۵۰۰ کندل یعنی در تایم‌فریم ۱۵ دقیقه حداکثر حدود ۳۶٫۵ روز تاریخچهٔ بومی Toobit.
  - در ۱ ساعت حدود ۱۴۵٫۸ روز، و در ۴ ساعت حدود ۱٫۶ سال.
  - این موضوع قدرت آماری را محدود می‌کند، اما هیچ استراتژی را از پیش رد نمی‌کند.
- **تصمیم‌های در انتظار (فقط موارد غیرقابل واگذاری):**
  - OD-1: مرز ریسک (افت سرمایه، ریسک هر معامله و غیره). همچنان معلق است و محاسبات به‌صورت پارامتریک خواهند بود.
  - OD-2: موضع حقوقی دربارهٔ استفاده از دادهٔ سایر صرافی‌ها.
  - OD-3: دسترسی و اجازهٔ استفاده از زیرساخت خارج از گوشی (پرداخت، قانونی و جغرافیایی).
  - OD-4: تأیید سیاست رفتار در صورت قطع دسترسی اپراتور (پیش‌فرض محافظه‌کارانه طراحی می‌شود).


# Part 2/10: Requirements Register, Class Definitions, Owner-Decision Register, Conflict Register

**Continuity.** Part 1/10 delivered gates G0 and G1 and the input-classification half of G2. It defined catalogs A, C, UEF, PF, CF, HG, CR, DQ, TP, XC, DV-1 and AR. This Part defines the catalogs listed in §2.8. Part 3/10 follows with risk concepts and parametric sizing arithmetic. No Part-1 identifier is redefined here.

## 2.0 Fidelity notes (read first)

Three items could not be reproduced verbatim because the engagement's carried summary kept their structure but not their exact wording. Each is disclosed rather than guessed.

1. **Register field set.** The register uses 11 fields, defined in §2.2.2. Nine are named in the carried summary: ID, Priority, Rationale/source, Verification method, Acceptance condition, Status, Evidence pointer, Failure response, Regression checks. I added two, "Requirement" (the statement itself) and "Evidence label" (the permitted label set). If §6 of the master prompt names the 11 differently, that is a defect. It will be corrected through a recorded change in the Part 9 propagation record.
2. **V-1…V-12 wording.** The numbering is retained but not each check's wording. Part 2's self-checks therefore use local identifiers PC-1…PC-8 (§2.9). The mapping of V-1…V-12 to evidence is performed in Part 10 against the prompt text.
3. **§2.1.0c four-category test.** I did not restate the four categories. Requirement RQ-BND-03 operationalizes the test as "permitted evidence label plus a traceable basis". This is DESIGN_JUDGMENT and is audited in Part 10.

All "PASS" statuses in this Part are author self-inspection (VM-1). They are not independent verification. No independent reviewer exists in this engagement (BLOCKED, per Part 1).

## 2.1 Class definitions

These definitions precede every use of a class label. The label "Class-A" is undefined in the prompt (PF-5) and is not used anywhere.

### 2.1.1 Priority classes (PRI)

| ID | Definition | Waiver rule |
|---|---|---|
| PRI-0 | Violation voids the design. Applies to OWNER_HARD items, hard gates and fail-safety rules. | None. A violation is repaired, never waived. |
| PRI-1 | Required for a complete design. | Waived only by CA-1 (owner), or by CA-2 with a recorded decision that gives a positive reason and a reversibility class. |
| PRI-2 | Required unless a recorded alternative satisfies the same acceptance condition. | CA-2 with a recorded alternative and its acceptance evidence. |

### 2.1.2 Severity classes (SEV)

Severity classifies a defect or failed requirement.

| ID | Definition |
|---|---|
| SEV-1 | Violates a hard gate or an OWNER_HARD item, or could permit unbounded or unrecoverable loss, or could make an uncertain outcome appear confirmed. |
| SEV-2 | Violates a PRI-1 requirement, or weakens a safety margin while still failing closed. |
| SEV-3 | Degrades verifiability or operability with no safety effect. |
| SEV-4 | Editorial: wording, formatting, cross-reference. |

### 2.1.3 Change-authority classes (CA)

Change authority states who may change an item.

| ID | Definition | Applies to |
|---|---|---|
| CA-1 | Owner only. Requires explicit owner decision. | OWNER_HARD items, OWNER_PREFERENCE items, OD-1…OD-4, any loosening of a risk limit. |
| CA-2 | Design authority. Requires a recorded decision (rationale, rejected alternatives with positive reasons, reversibility class) and propagation to every affected section. | DESIGN_JUDGMENT and DERIVED items; delegated choices under A12. |
| CA-3 | Implementation authority. A change record is required. It must not alter an interface, a state transition, a safety rule or an acceptance condition. | Choices internal to one component specification. |

A change that touches both a CA-1 and a CA-2 item takes the more restrictive authority.

### 2.1.4 Outage classes (OCL)

Outage classes are defined by what is unavailable, not by duration. Duration thresholds are named symbolically (τ_op, τ_venue, τ_feed, τ_proc, τ_clk). Values or derivations for them appear in Part 4 (parameter register) or Part 7. Until then, no duration is asserted. C12's maximum safe outage is UNRESOLVED.

| ID | Definition |
|---|---|
| OCL-1 | Operator-channel outage: Telegram or its network path is unreachable from the trading process, or the operator is unreachable for any reason. |
| OCL-2 | Venue-interface outage: the venue's REST or streaming endpoints are unreachable, erroring, rate-limited, or returning ambiguous outcomes. |
| OCL-3 | Data-feed outage: market data is stale or gapped, whether or not the order interface works. |
| OCL-4 | Process or host outage: the trading process, the supervisor, or the host stops (crash, OS kill, power loss, restart). |
| OCL-5 | Clock outage: no usable time source, or the clock offset is unknown or excessive. |

Outages may co-occur. For a compound outage, the most restrictive response among the member classes applies (DESIGN_JUDGMENT, CA-2, REVERSIBLE).

### 2.1.5 Risk classes (RKC)

Each veto class specified in Part 7 will carry one primary RKC.

| ID | Definition |
|---|---|
| RKC-1 | Financial-limit risk: a quantity bounded by an owner limit (per-trade, aggregate concurrent, daily, drawdown, leverage). |
| RKC-2 | Execution-uncertainty risk: order or position state is not known with certainty. |
| RKC-3 | Data-validity risk: market or reference data is wrong, stale, gapped or mis-sourced. |
| RKC-4 | Availability risk: a component or channel is unavailable (maps to OCL-1…OCL-5). |
| RKC-5 | Model or statistical risk: strategy edge or estimates are unsupported, overfit or misestimated. |
| RKC-6 | Security, legal or compliance risk: credential exposure, unauthorized command, or use of a prohibited data source. |

### 2.1.6 Verification-method classes (VM)

| ID | Definition | Executable in this engagement? |
|---|---|---|
| VM-1 | Document inspection: a checklist applied to delivered text. | Yes |
| VM-2 | Analytical check: arithmetic or derivation reproduced by hand. | Yes |
| VM-3 | Design walk-through: scenarios and state transitions traced on the specification. | Yes |
| VM-4 | Replay or simulation on recorded or synthetic data (post-implementation, no account). | No: no code execution |
| VM-5 | Fault injection in a test harness or Paper mode (post-implementation, no account). | No |
| VM-6 | Authenticated venue observation. It requires credentials and is a pre-Live gate. | No: blocked by A4 (OWNER_HARD) |

### 2.1.7 Register conventions

- **Status values** are PASS, FAIL, BLOCKED, NOT TESTED and UNRESOLVED. Most rows read NOT TESTED because the design is not yet written or walked through.
- **Domain codes** in IDs:

| Code | Domain |
|---|---|
| BND | boundary |
| OWN | owner constraints |
| RSK | risk |
| EXE | execution |
| TEL | Telegram and operator |
| DAT | data |
| STA | statistics |
| DEP | deployment |
| PHS | phases |
| OPS | operations |
| SEC | security |
| VER | verification and process |
| DOC | documentation form |

- **Evidence pointers** name a Part and section. "Planned: Part N" means the evidence does not yet exist.
- **Regression checks** state what to re-run when the design changes.

## 2.2 Requirements register (single table)

### 2.2.1 Method

Requirements were derived positively from three sources: (a) OWNER_HARD, OWNER_PREFERENCE and OWNER_ATTESTED inputs (A1–A13); (b) hard gates HG-1…HG-6 and ranked criteria CR-1…CR-8; (c) the prompt rules carried in the engagement summary. Every row traces to at least one of these. No requirement was added because it "seems prudent". Where I added a design-level rule, its label is DESIGN_JUDGMENT.

### 2.2.2 Field definitions

1. **ID**
2. **Requirement**: the statement.
3. **Priority**: PRI-0, PRI-1 or PRI-2.
4. **Rationale/source**
5. **Evidence label**
6. **Verification method**: VM-n.
7. **Acceptance condition**: a pass/fail test.
8. **Status**
9. **Evidence pointer**
10. **Failure response**: what is done if verification fails (design response for design requirements, runtime response for runtime requirements).
11. **Regression checks**

### 2.2.3 The register

| ID | Requirement | Priority | Rationale/source | Evidence label | Verification method | Acceptance condition | Status | Evidence pointer | Failure response | Regression checks |
|---|---|---|---|---|---|---|---|---|---|---|
| RQ-BND-01 | No implementation, deployment, account connection, credential request, authentication, order action or Live authorization occurs in this engagement. Post-engagement steps appear only as labeled future procedure. | PRI-0 | A4; HG-3 | OWNER_HARD | VM-1 | Zero requests for secrets or authenticated actions and zero Live authorizations in every delivered Part. Each future step is labeled "post-engagement". | PASS | Part 1 boundary statement; Part 2 inspected | Withdraw the text in the next message; log it in the Part 9 propagation record; SEV-1 | Re-inspect every Part; re-inspect after any edit to the Part 8 command catalog |
| RQ-BND-02 | No profitability guarantee. No statement that a strategy is achievable or will perform before calculation. Every strategy and its figures carry NOT TESTED or PROVISIONAL until computed. | PRI-0 | A4; D19; §8.0 | OWNER_HARD | VM-1 | No sentence asserts expected profit or achievability. Every strategy carries a status label. | PASS | Parts 1–2 inspected (no strategy presented yet) | Replace with conditional wording; SEV-1 | Re-inspect Parts 3, 4, 9, 10 |
| RQ-BND-03 | Every claim carries one permitted evidence label and a basis the reader can trace (source, derivation or labeled judgment). This operationalizes the §2.1.0c test (HG-4). | PRI-0 | HG-4; §2.1.0c | DESIGN_JUDGMENT (operationalization) | VM-1, VM-2 | A sampled-claim audit finds no unlabeled claim. The full audit is in Part 10. | NOT TESTED | Planned: Part 10 coverage audit | Relabel as PROVISIONAL or UNRESOLVED, or delete; SEV-2 | Re-sample at each Part |
| RQ-BND-04 | No fabricated sources, tests or results. Recalled domain principles are labeled "recalled, not externally verified in this engagement". The 149-record archive is cited only as OWNER_SUPPLIED_AUDIT_SUMMARY. | PRI-0 | Standing instruction; Part 1 capability inventory | OWNER_HARD | VM-1 | Every external-fact claim has an A/C/UEF pointer or a "recalled" label. No invented citation. | NOT TESTED | Planned: Part 10 | Delete or relabel; SEV-1 | Re-inspect at each Part |
| RQ-OWN-01 | Toobit futures/perpetuals is the venue. The decision is not reopened. | PRI-0 | A1 | OWNER_HARD | VM-1 | No Part proposes, compares or evaluates an alternative live venue. | PASS | Parts 1–2 inspected | Remove the alternative; SEV-1 | Re-inspect Parts 5, 6 |
| RQ-OWN-02 | The Telegram bot is the sole routine runtime operator interface. No dashboard, app, second bot or routine console is specified. This is an interface constraint only, not a trust-boundary or topology constraint. | PRI-0 | A2; CF-1; DQ-2 | OWNER_HARD | VM-1, VM-3 | Every routine operator function is a command in the Part 8 catalog. Any non-Telegram access exists only as a non-routine recovery procedure in the procedural consistency table. | NOT TESTED | Planned: Parts 6, 8 | Remove the surface or reclassify it as recovery with a positive reason; SEV-1 | Re-run when any command or recovery procedure is added |
| RQ-OWN-03 | UTC everywhere. Each timestamp has a defined semantic role. Elapsed deadlines use monotonic clocks. Behavior is specified for stale, unknown and excessive clock offset. Days are UTC days and weeks are ISO-8601 UTC weeks. | PRI-0 | A3 | OWNER_HARD | VM-1, VM-3 | A timestamp-role catalog exists. No elapsed deadline uses wall-clock time. A behavior table covers fresh, stale, unknown and excessive offset. Day and week boundaries are stated. | NOT TESTED | Planned: Parts 6, 7 | Add the missing role or behavior; SEV-1 | Re-run when any component adds a timestamp or deadline |
| RQ-OWN-04 | Cross-venue data is used only under the A5 conditions and is research-only until OD-2 resolves (PF-4). Every dataset and derived artifact carries a source-tag lineage. A check refuses any research-only-tagged input on a Live path. No legal conclusion is drawn. | PRI-0 | A5; PF-4; HG-3 | OWNER_HARD | VM-3, VM-5 | Lineage tag is mandatory on every data artifact in the Part 5/6 specifications. The Live path rejects any research-only tag and logs the rejection. No sentence asserts legality. | NOT TESTED | Planned: Parts 5, 6, 7 | Add a tag or gate; SEV-1 | Re-run when any data source or data class is added |
| RQ-OWN-05 | "Intraday" and its maximum holding duration are derived from stated requirements, not invented. | PRI-0 | A6 | OWNER_HARD | VM-2 | A derivation yields a definition and a bound expressed as a function of named inputs. No unsourced constant appears. | NOT TESTED | Planned: Part 4 | Replace the constant with a derivation or label it PROVISIONAL; SEV-2 | Re-run when the strategy family or timeframe set changes |
| RQ-OWN-06 | Breadth of symbols and timeframes is reported as a Pareto frontier on two defined axes. Dominated points are excluded and no scalar score is used. | PRI-1 | A7; D14; CR-7 | OWNER_PREFERENCE | VM-2 | Axes are defined. The frontier is derived by stated dominance. Every excluded point names its dominator. | NOT TESTED | Planned: Part 5 | Re-derive; SEV-2 | Re-run when envelope inputs change |
| RQ-OWN-07 | The reference device (Xiaomi POCO X6, 23122PCD1G, Termux) is treated as a feasibility constraint, not an architecture driver. Nine workloads are assessed separately: development, training, backtest, calibration, paper, live, Telegram runtime, storage, recovery. Measured and unmeasured values are marked. | PRI-1 | A8; D15; C14–C16 | OWNER_PREFERENCE | VM-2, VM-3 | Nine separate findings exist. Each cites C14–C16 or labels the quantity unmeasured. | NOT TESTED | Planned: Part 5 | Add the missing finding; SEV-2 | Re-run when any workload definition changes |
| RQ-OWN-08 | Owner questions appear only in the owner-decision register. Each entry justifies non-delegability. No pause occurs for architecture, methods, features, parameters, optimizer, language, framework, runtime or libraries. | PRI-0 | A12; A13 | OWNER_HARD | VM-1 | The register (§2.3) is the sole source of owner questions. Each entry has a non-delegability reason. | NOT TESTED | Part 2 §2.3; planned: Part 10 | Delete the question or move it to the register with a reason; SEV-2 | Re-inspect each Part's closing note |
| RQ-OWN-09 | Illustrative equity (about 200 USDT, planning range below 500 USDT) appears only as labeled parametric sample points. It is never presented as live equity or as proof of feasibility. | PRI-1 | A11 | OWNER_ATTESTED | VM-1, VM-2 | Each use is inside a function or range table and is labeled. | NOT TESTED | Planned: Parts 3, 4, 5 | Convert to a parametric form; SEV-2 | Re-inspect each Part containing equity examples |
| RQ-RSK-01 | An independent risk authority exists. Its veto cannot be cleared by strategy logic, optimizer or any Telegram command except through the defined recovery condition. On any inability to evaluate, it vetoes. | PRI-0 | HG-2; §9.6 | OWNER_HARD (D-level hard gate) | VM-3, VM-5 | The component specification states inputs, state ownership, failure domain and veto classes. A walk-through of each failure of the authority's own inputs ends in veto. | NOT TESTED | Planned: Parts 6, 7 | Redesign the path; SEV-1 | Re-run when any component gains write access to risk state |
| RQ-RSK-02 | Unknown, stale or unevaluable risk is a hard veto. | PRI-0 | §9.6; HG-2 | OWNER_HARD | VM-3 | Every risk input has a freshness bound (symbolic) and an "unknown" state. A table maps each (input, state) to a veto. | NOT TESTED | Planned: Part 7 | Add the row; SEV-1 | Re-run when a risk input is added |
| RQ-RSK-03 | A missing or corrupt risk-state record is never initialized from market or account values. The response is hard veto, Live refusal, CRIT alert, and an out-of-band restore or a separately audited operator acknowledgement. | PRI-0 | §9.6 | OWNER_HARD | VM-3, VM-5 | The startup branch has all four responses. No inline initialization path exists. Deletion and corruption cases are walked through. | NOT TESTED | Planned: Part 7 | Remove the initialization path; SEV-1 | Re-run when the state schema changes |
| RQ-RSK-04 | Veto clearance and /ack are different operations. Each veto class states its recovery condition and whether a resume gate applies. /ack during a failing condition is refused. /ack never clears a veto. | PRI-0 | §9.6 | OWNER_HARD | VM-3 | Every veto class has recovery condition, resume-gate flag and refusal text for /ack-while-failing. | NOT TESTED | Planned: Parts 7, 8 | Add the missing field; SEV-1 | Re-run when a veto class is added |
| RQ-RSK-05 | Risk limit values (max drawdown, per-trade risk, daily loss, aggregate exposure, leverage cap) come only from the owner (OD-1). No illustrative owner figure is adopted as a hard, provisional, sanity-check or illustrative value. Every risk calculation is a function over a range. The "risk limits defined" interlock evaluates false until OD-1 supplies values. | PRI-0 | D17; §3.3; OD-1 | OWNER_DECISION_PENDING | VM-1, VM-2 | No illustrative owner figure appears as an anchor in any Part. Each calculation is shown across a range. | UNRESOLVED | OD-1 (§2.3); planned: Part 3 | Convert the anchor into a parameter; SEV-1 | Re-inspect Parts 3, 4, 5 |
| RQ-RSK-06 | Part 3 explains fifteen quantities: equity, notional, margin, leverage, quantity/contract multiplier, stop distance, gross loss, fees, funding, spread/slippage, liquidation, per-trade budget, aggregate concurrent risk, daily loss, peak-to-trough drawdown. Each has a reproducible worked example. The 100/100/10 USDT teaching arithmetic is labeled and shown as functions. The text states that leverage alone does not multiply P&L at fixed notional and that nominal stop risk is not a realized-loss cap. | PRI-1 | D17; §3.3; CF-2 | DERIVED | VM-2 | Fifteen examples exist and each is reproducible by hand. The two statements appear verbatim in substance. | NOT TESTED | Planned: Part 3 | Add the missing example; SEV-2 | Re-compute every example after any formula change |
| RQ-RSK-07 | Sizing and stop placement account for fees, funding stress, spread/slippage and gap terms. The stop must trigger before worst-case liquidation (UEF-11). Sizing refuses when the minimum tradable quantity exceeds the per-trade budget (UEF-3, CF-5). | PRI-0 | §3.3; UEF-3; UEF-11 | DERIVED | VM-2, VM-3 | The formula contains each term. A refusal branch exists. Worst-case liquidation is expressed parametrically. | NOT TESTED | Planned: Part 3 | Add the missing term or branch; SEV-1 | Re-run when the cost model or leverage ladder assumption changes |
| RQ-RSK-08 | No optimizer or adaptation may relax a hard risk limit. A design with zero adaptation is acceptable if justified. | PRI-0 | §8.5; §9.10 | OWNER_HARD | VM-3 | The parameter register marks every hard limit non-adaptable. Any adaptive element lists its permitted range and its write path, and the write path cannot reach hard limits. | NOT TESTED | Planned: Parts 4, 6 | Remove the write path; SEV-1 | Re-run when any adaptive parameter is added |
| RQ-EXE-01 | A complete order state machine covers INTENT, SUBMITTED, ACKNOWLEDGED, PARTIALLY_FILLED, FILLED, CANCEL_PENDING, CANCELLED, REJECTED, TIMEOUT_AMBIGUOUS and RECONCILING. Transitions are not invented ad hoc. | PRI-0 | §9.7 | OWNER_HARD | VM-3, VM-5 | A transition table has trigger, guard, action and next state. Every (state, event) pair is a defined transition or an explicit "impossible, logged" entry. No state lacks an exit. | NOT TESTED | Planned: Part 7 | Add the missing transition; SEV-1 | Re-run when an event type is added |
| RQ-EXE-02 | An ambiguous order outcome is never treated as a rejection. TIMEOUT_AMBIGUOUS leads to RECONCILING before any resubmission. | PRI-0 | HG-5 | OWNER_HARD | VM-3, VM-5 | No transition from TIMEOUT_AMBIGUOUS reaches REJECTED or INTENT without passing RECONCILING. | NOT TESTED | Planned: Part 7 | Remove the transition; SEV-1 | Re-run when retry or timeout logic changes |
| RQ-EXE-03 | Idempotency and retry are specified. clientOrderId uses charset [A-Za-z0-9_-] (C11), is no longer than the venue limit (UEF-8; unknown, so the shortest unique form is used), is never reused, and derives from a persisted intent identifier. Retries are bounded by count and window with a hard stop that vetoes new orders. Cancel/fill races and protective orders have defined rules. | PRI-1 | §9.7; C11; UEF-8 | DERIVED | VM-3, VM-5 | The ID format, uniqueness argument, retry bound, hard stop, race table and protective-order rule are all present. | NOT TESTED | Planned: Part 7 | Add the missing element; SEV-2 | Re-run when the ID format or retry policy changes |
| RQ-EXE-04 | Risk-reducing exits are exchange-resident or locally automated. They are never operator-confirmed. If exchange-resident stops cannot be verified (UEF-1), Live is refused. | PRI-0 | DQ-1; A9; UEF-1 | DERIVED | VM-3, VM-6 | The exit path of every position state names its resident location and requires no Telegram interaction. A pre-Live gate checks UEF-1. | NOT TESTED | Planned: Part 7 | Redesign the exit path; SEV-1 | Re-run when the order-type assumptions change |
| RQ-EXE-05 | Entry cost models may assume a maker-only floor within C10's scope. Protective and risk-reducing exits may cross the spread, and their costs use the taker branch. | PRI-1 | C10; DQ-3; RX-1; CR-1 before CR-3 | DESIGN_JUDGMENT | VM-2, VM-3 | The cost model has separate entry and exit fee assumptions. No exit rule depends on a maker fill. | NOT TESTED | Planned: Parts 3, 7 | Separate the assumptions; SEV-2 | Re-run when the fee assumptions change |
| RQ-EXE-06 | Reconciliation compares local order/position state to venue state, with polling as the baseline (UEF-7). Mismatch classification and response are specified. Reconciliation deferral is bounded by the C12 provisional 3-day value, and that value is used for nothing else. | PRI-1 | §9.7; UEF-7; C12 | PROVISIONAL (C12 value) | VM-3, VM-5 | A mismatch table has a response per class. The 3-day value appears only in the deferral rule. | NOT TESTED | Planned: Part 7 | Remove other uses of the value; SEV-2 | Re-run when C12 is resolved |
| RQ-TEL-01 | Telegram loss never releases a limit, unblocks an unsafe action, or makes an uncertain outcome look confirmed. | PRI-0 | HG-6; A9 | OWNER_HARD | VM-3, VM-5 | Every command's effect is evaluated under OCL-1. No limit state, veto state or order-outcome display depends on message delivery. | NOT TESTED | Planned: Parts 7, 8 | Redesign the dependency; SEV-1 | Re-run when a command or alert is added |
| RQ-TEL-02 | The operator-unreachable policy states what happens to open positions and pending orders under OCL-1 as a function of τ_op. Default: exchange-resident protective orders plus fail-closed behavior. Ratification is requested via OD-4. | PRI-0 | A9; OD-4 | DESIGN_JUDGMENT (default); OWNER_DECISION_PENDING (ratification) | VM-3 | A table maps (position state, pending-order state, τ_op band) to an action. Every action is non-increasing in exposure. | NOT TESTED | OD-4 (§2.3); planned: Part 7 | Revise the table; SEV-1 | Re-run if OD-4 returns a different policy |
| RQ-TEL-03 | The Paper/Live selector is gated by exactly six interlocks: data validity, reconciliation, risk-limit definition, credential/permission validity, config integrity, clock offset. Each has an evaluation method, failure condition and refusal output. The selector has no waiting period and no profit hurdle. | PRI-0 | A10 | OWNER_HARD (interlocks); OWNER_PREFERENCE (no waiting/hurdle) | VM-3, VM-5 | Six rows exist. The precondition set equals the six. No time-since-start or return-based condition appears. | NOT TESTED | Planned: Part 8 | Remove the extra condition or add the missing row; SEV-1 | Re-run when any command gains a Live-affecting effect |
| RQ-TEL-04 | A command's preconditions are the intersection of the checks it must enforce and the checks its context can evaluate. A general resume command does not check per-trade risk. A paper command does not check clock. | PRI-1 | PF-8; §9.6 | DERIVED | VM-3 | Each command row lists "must enforce", "context can evaluate" and the resulting intersection. | NOT TESTED | Planned: Part 8 | Correct the row; SEV-2 | Re-run when a command's context changes |
| RQ-DAT-01 | Data-class decisions use the five criteria of §9.4. Source-tag lineage is carried per class. | PRI-1 | §9.4; D-series | DERIVED | VM-3 | Every data class has five criterion outcomes and a lineage tag. | NOT TESTED | Planned: Part 5 | Add the missing outcome; SEV-2 | Re-run when a data class is added |
| RQ-DAT-02 | The universe is derived by steps 1–9 with a Pareto frontier. The 10-symbol storage measurement list is not a candidate universe. The liquidity threshold is a five-element calculation chain, shown parametrically. | PRI-1 | D14; §10.1; C9; C19 | DERIVED | VM-2 | Nine steps are shown. The five chain elements are shown as a function. No Part treats the 10-symbol list as a universe. | NOT TESTED | Planned: Part 5 | Re-derive; SEV-2 | Re-run when C9 or the symbol census changes |
| RQ-DAT-03 | A bar is usable only after close plus a measured delay (UEF-5). Gaps are detected and excluded (UEF-12). The 3,500-bar cap and its depth consequences (DV-1) are handled by forward accumulation at the intervals where native depth is short. No critical feature depends on markPrice/klines.change semantics (C13). | PRI-1 | UEF-5; UEF-12; C2; C13; DV-1 | DERIVED | VM-3, VM-4 | The data-validity rules cover close-plus-delay, gap handling and cap handling. No feature definition uses the conflicted field. | NOT TESTED | Planned: Parts 4, 5 | Remove the dependency; SEV-2 | Re-run when a feature is added |
| RQ-DAT-04 | A symbol is admitted only with known filters: tick, lot, minimum notional, precision (UEF-3). Otherwise Live is refused for that symbol. | PRI-0 | UEF-3; CF-5 | DERIVED | VM-3, VM-6 | The admission rule lists required filters and the refusal output. A pre-Live gate checks them. | NOT TESTED | Planned: Parts 5, 7 | Add the filter requirement; SEV-1 | Re-run when the filter list changes |
| RQ-DAT-05 | Use of cross-venue data in Paper requires OD-2. Until then it is research-only. | PRI-0 | A5; PF-4; OD-2 | OWNER_DECISION_PENDING | VM-1, VM-3 | No Paper-path component consumes cross-venue-tagged data while OD-2 is open. | UNRESOLVED | OD-2 (§2.3); planned: Part 5 | Disable the consumer; SEV-1 | Re-run when OD-2 is answered |
| RQ-DAT-06 | Cost models use the taker 0.06% conservative branch and a stated range that also covers 0.05% (C6). The maker fee is a range (UEF-10). Funding is an uncapped stress term (UEF-4, C7). | PRI-1 | C6; C7; UEF-4; UEF-10 | PROVISIONAL | VM-2 | Each cost term appears as a parameter with its range. No term is hard-coded. | NOT TESTED | Planned: Part 3 | Parameterize; SEV-2 | Re-run when any fee, funding or tier fact is resolved |
| RQ-STA-01 | At least one candidate strategy is proposed and labeled NOT TESTED until calculated. No statement says it "is achievable" before calculation. Statistical rigor validates strategies; it does not preemptively reject them. | PRI-0 | D19; §8.0 | OWNER_HARD | VM-1 | At least one strategy with an explicit NOT TESTED label. No achievability sentence. | NOT TESTED | Planned: Part 4 | Relabel; SEV-1 | Re-inspect Parts 4, 9, 10 |
| RQ-STA-02 | Any trial-budget figure has a per-cell, unit-consistent recomputation (§5.4, §8.4) or a PROVISIONAL label. The anchors in C23 justify no decision. | PRI-1 | C23; §8.4 | DERIVED | VM-2 | Each figure has a recomputation with units, or a PROVISIONAL label. | NOT TESTED | Planned: Part 4 | Recompute or relabel; SEV-2 | Re-run when the timeframe set or sample depth changes |
| RQ-STA-03 | No exhaustive permutation grid at ≤12h. The selection procedure declares searched configurations, effective sample size, assumptions, stopping rule, selection-bias control, promotion policy and rollback policy. | PRI-1 | C24; §8.4 | OWNER_HARD (C24) | VM-2, VM-3 | The seven declarations are present. The chosen search design is one of the allowed alternatives. | NOT TESTED | Planned: Part 4 | Add the missing declaration; SEV-2 | Re-run when the parameter space changes |
| RQ-STA-04 | N_max_effective = min(published, recomputed), and the recomputed value governs when they differ by more than 2× (C22). MinTRL (C21) stays distinct from MinBTL. The DSR value (C20) is used only with its stated N. | PRI-1 | C20; C21; C22 | RATIFIED_FINDING; recalled definitions labeled | VM-2 | Formulas are stated with units. The two quantities are named distinctly. | NOT TESTED | Planned: Part 4 | Correct the formulas; SEV-2 | Re-run when published inputs become available |
| RQ-STA-05 | Net economic feasibility after costs is shown parametrically, with no assurance of positive net return. | PRI-1 | CR-3; CF-5 | DERIVED | VM-2 | Costs and breakeven appear as functions over ranges. No result is presented as expected. | NOT TESTED | Planned: Parts 3, 4 | Convert to functions; SEV-2 | Re-run when cost parameters change |
| RQ-DEP-01 | The envelope is derived before the device match. All topologies are enumerated in Step 4b before any compromise. Any compromise sub-step has a four-part disclosure: compromise-order item, narrower scope, why it suffices, escalation criterion. | PRI-1 | D15; A8 | OWNER_PREFERENCE (phone); DERIVED | VM-3 | The envelope appears before the match. TP-1…TP-6 are all assessed. Each compromise has four parts. | NOT TESTED | Planned: Part 5 | Add the missing part; SEV-2 | Re-run when a topology is added or the envelope changes |
| RQ-DEP-02 | Component specifications stay topology-neutral where possible. Topology-conditional properties are flagged with their dependency (UEF-9, UEF-13). | PRI-2 | D15; CR-6 | DESIGN_JUDGMENT | VM-3 | Each component spec lists "topology-conditional properties" or states none. | NOT TESTED | Planned: Part 6 | Flag the property; SEV-3 | Re-run when a component is added |
| RQ-DEP-03 | Use of off-device infrastructure depends on OD-3. Its availability is not assumed. | PRI-1 | A8; OD-3 | UNRESOLVED | VM-1 | Each topology that needs off-device resources is labeled conditional. | UNRESOLVED | OD-3 (§2.3); planned: Part 5 | Relabel; SEV-2 | Re-run when OD-3 is answered |
| RQ-DEP-04 | No sustained background runtime on the phone is assumed (C15, C16). Live on the phone is permitted only on measured evidence. Before measurement, any such claim is PROVISIONAL. | PRI-1 | C15; C16 | PROVISIONAL | VM-6 (device measurement is outside this engagement) | A measurement protocol is specified. No Part asserts a phone-runtime duration. | BLOCKED | C16 (Part 1 ledger); planned: Part 5 | Relabel PROVISIONAL; SEV-2 | Re-run when a device measurement is supplied |
| RQ-PHS-01 | The minimum phase set is derived from risks and verification dependencies. A single Phase Deviation Table has one row per owner-intended phase (training, extended calibration, paper, live), stating the design's phase name or merged/split/removed, with rationale. | PRI-1 | D16; PF-1 | DERIVED | VM-2, VM-3 | Four rows exist. The derivation precedes the table. No selective disclosure. | NOT TESTED | Planned: Part 8 | Add the missing row; SEV-2 | Re-run when a risk or verification dependency changes |
| RQ-OPS-01 | A startup check that needs out-of-band recovery causes refuse-to-start, a CRIT alert naming the check, and a pointer to the procedure. Recovery is never attempted inline. | PRI-0 | §9.8 | OWNER_HARD | VM-3, VM-5 | Every such check has the three outputs. No startup path performs recovery. | NOT TESTED | Planned: Part 7 | Remove the inline path; SEV-1 | Re-run when a startup check is added |
| RQ-OPS-02 | The operations section ends with a procedural consistency table listing each recovery procedure and its required process state (RUNNING, STOPPED or either). | PRI-1 | §9.8 | OWNER_HARD | VM-1, VM-3 | The table exists, is last in the section, and has no procedure absent from the text. | NOT TESTED | Planned: Part 8 | Add the row; SEV-2 | Re-run when a procedure is added |
| RQ-OPS-03 | A conservative request-rate budget with a hard stop is defined (UEF-6). C4 and C5 are respected: the -1007 code is ambiguous and -1003 is the rate-limit breach. | PRI-1 | UEF-6; C4; C5 | PROVISIONAL | VM-3, VM-5 | A budget symbol, a hard stop and an error-code mapping exist. -1007 is treated as an ambiguous outcome (HG-5). | NOT TESTED | Planned: Parts 6, 7 | Correct the mapping; SEV-2 | Re-run when weights become known |
| RQ-OPS-04 | The maximum safe outage is parameterized (C12 is UNRESOLVED). The provisional 3-day value governs reconciliation deferral only. | PRI-1 | C12 | UNRESOLVED | VM-1 | No outage threshold other than symbolic τ values appears. The 3-day value appears only in the deferral rule. | UNRESOLVED | C12 (Part 1 ledger); planned: Part 7 | Replace with symbols; SEV-2 | Re-run when C12 is resolved |
| RQ-SEC-01 | Credentials never appear in design artifacts or messages. Future storage and permission minimization (no withdrawal permission) is specified. The credential/permission-validity interlock has an evaluation method that needs no secret disclosure. | PRI-1 | A4; UEF-9; HG-3 | DESIGN_JUDGMENT | VM-3 | The specification has a credential-handling rule and a permission-check method. | NOT TESTED | Planned: Part 8 | Add the rule; SEV-2 | Re-run when a credential-using component is added |
| RQ-SEC-02 | Telegram commands are authenticated to an allow-listed operator identity. Replay and duplicate commands are rejected. Dangerous commands require a confirmation step. | PRI-1 | A2; HG-6 | DESIGN_JUDGMENT | VM-3, VM-5 | The command contract has identity, replay and confirmation rules. | NOT TESTED | Planned: Part 8 | Add the rule; SEV-2 | Re-run when a command is added |
| RQ-VER-01 | Verification does not require a live account (CR-5). Items that need authenticated observation (UEF-1, UEF-2, UEF-3, UEF-6, UEF-7, UEF-8, UEF-11) are listed as pre-Live gated checks. Live is refused until they pass. | PRI-1 | CR-5; RX-3; A4 | DERIVED | VM-1, VM-3 | The gated-check list names each UEF item, its check and its refusal output. | NOT TESTED | Planned: Parts 7, 9 | Add the missing check; SEV-2 | Re-run when the UEF register changes |
| RQ-VER-02 | The verification matrix has exactly as many rows as the requirements register. Both counts are stated. As of Part 2, the register has 65 rows. | PRI-1 | Standing rule | DERIVED | VM-2 | Counts match at Part 9 and Part 10 delivery. | NOT TESTED | Planned: Parts 9, 10 | Add the missing rows; SEV-2 | Re-count whenever a row is added or removed |
| RQ-VER-03 | Staged independent blind review is performed. It is BLOCKED in this engagement (no reviewer). The fallback is a structured self-red-team, explicitly not independent proof. | PRI-1 | Reference process; §2.1.5 | UNRESOLVED (blocked) | VM-1 | The fallback is labeled non-independent. Findings that change the design are propagated. | BLOCKED | Part 1 capability inventory; planned: Part 9 | Keep the label; SEV-2 | Re-run when a reviewer becomes available |
| RQ-VER-04 | Implementation order is derived from dependencies and risk reduction. A repository blueprint is proposed only if justified. | PRI-2 | D11; CR-6 | DERIVED | VM-3 | An ordering derivation exists. Any blueprint has a justification. | NOT TESTED | Planned: Part 9 | Derive or drop the blueprint; SEV-3 | Re-run when components change |
| RQ-VER-05 | Each identifier appears in exactly one catalog where it is fully defined. Later uses point to the catalog. The final declaration enumerates every catalog and confirms completeness and no duplicates. | PRI-1 | Standing rule | DERIVED | VM-1 | The catalog list is complete and has no duplicate definitions. | NOT TESTED | Part 2 §2.8; planned: Part 10 | Merge the duplicate; SEV-2 | Re-check each Part |
| RQ-VER-06 | Every rejected alternative has a positive reason. Every decision carries a reversibility class: REVERSIBLE, COSTLY_REVERSIBLE or IRREVERSIBLE. | PRI-1 | Standing rule | DERIVED | VM-1 | No decision record lacks either. | NOT TESTED | Planned: Parts 6–9 | Add the reason or class; SEV-2 | Re-check each decision added |
| RQ-VER-07 | Design choices follow the ranked criteria CR-1…CR-8 lexicographically. Ties are broken by fewer failure domains (CR-6). No numeric weighting is used. | PRI-1 | CR-1…CR-8 | OWNER_HARD (rank order) | VM-1, VM-3 | Each decision record cites the criterion that decided it. No weights appear. | NOT TESTED | Planned: Part 6 | Re-decide; SEV-2 | Re-check on each decision |
| RQ-VER-08 | Reference Step 3 (targeted external evidence inspection) is performed or, if blocked, every dependent claim carries PROVISIONAL, UNRESOLVED or NOT ESTABLISHED. | PRI-1 | Reference process; Part 1 capability inventory | UNRESOLVED (blocked) | VM-1 | Each dependent claim carries one of the three labels. | BLOCKED | Part 1 capability inventory; UEF register | Relabel; SEV-2 | Re-run when external access exists |
| RQ-DOC-01 | Every Part begins with "Part K/10" and carries a completeness declaration, cross-references to the previous and next Parts, an updated artifact registry, and checks. | PRI-1 | Delivery plan | DERIVED | VM-1 | Header and four elements present in every Part. | NOT TESTED | Parts 1–2; planned: Part 10 | Add the element; SEV-3 | Re-inspect each Part |
| RQ-DOC-02 | The principal specification is professional English Markdown. Owner-facing progress notes and the final summary are Persian. D21-prohibited phrases are absent. No content reduction occurs: no compression, summarization, abbreviation, omission, referral, deferral or truncation of required content. | PRI-1 | Standing instruction; D21 | OWNER_HARD | VM-1 | Language split respected. Prohibited phrases absent. Every deferred item is on the delivery plan and carries a delivery Part. | NOT TESTED | Parts 1–2; planned: Part 10 | Restore the content; SEV-2 | Re-inspect each Part |
| RQ-DOC-03 | All money is in USDT, never USD. Any USD figure is a derived approximation with its conversion assumption. | PRI-1 | Standing instruction | OWNER_HARD | VM-1 | No unlabeled USD figure. | NOT TESTED | Parts 1–2; planned: Part 10 | Convert or label; SEV-3 | Re-inspect each Part |
| RQ-DOC-04 | Part 10/10 contains the full completeness declaration with arithmetic A+B+C+D+U+E+F=R (PF-3), V-1…V-12 as a table with evidence pointers, the §12.2 coverage-checklist audit, the seven-dimension status (§11.3), the catalog-completeness confirmation, and the "material design changes from adversarial review" section. | PRI-1 | Delivery plan; PF-3 | DERIVED | VM-1, VM-2 | All six elements present, with the arithmetic reproduced. | NOT TESTED | Planned: Part 10 | Add the element; SEV-2 | Re-run at Part 10 |

### 2.2.4 Register arithmetic (reproducible)

| Count | Value | Check |
|---|---|---|
| Rows by domain | BND 4 + OWN 9 + RSK 8 + EXE 6 + TEL 4 + DAT 6 + STA 5 + DEP 4 + PHS 1 + OPS 4 + SEC 2 + VER 8 + DOC 4 | 4+9=13; +8=21; +6=27; +4=31; +6=37; +5=42; +4=46; +1=47; +4=51; +2=53; +8=61; +4=65 |
| Rows by priority | PRI-0: 27; PRI-1: 36; PRI-2: 2 | 27+36+2 = 65 |
| Rows by status | PASS 3; NOT TESTED 55; UNRESOLVED 4; BLOCKED 3; FAIL 0 | 3+55+4+3+0 = 65 |

Rows by status:
- PASS: RQ-BND-01, RQ-BND-02, RQ-OWN-01.
- UNRESOLVED: RQ-RSK-05, RQ-DAT-05, RQ-DEP-03, RQ-OPS-04.
- BLOCKED: RQ-DEP-04, RQ-VER-03, RQ-VER-08.
- PRI-2: RQ-DEP-02, RQ-VER-04.

## 2.3 Owner-decision register

This is the single catalog that fully defines OD-1…OD-4. Part 1 referenced them in its pause assessment as forward references.

**Why only four.** Under A12 and A13, everything delegable stays with the design: architecture, methods, features, parameters, optimizer, language, framework, runtime, libraries. A question enters this register only if it concerns (a) the owner's own risk tolerance, (b) a legal or personal position the design cannot determine, (c) resources or access only the owner controls, or (d) a safety-relevant default that affects the owner's exposure while unreachable.

| ID | Decision needed | Why non-delegable | Evidence label | Reversibility | Default until answered | What it blocks | Earliest blocking point | Answer format |
|---|---|---|---|---|---|---|---|---|
| OD-1 | Risk boundary: maximum peak-to-trough drawdown, per-trade risk budget, daily loss limit, aggregate concurrent risk limit, leverage cap, plus the equity basis each is measured against. | The owner's capital and loss tolerance. The owner's earlier illustrative figures are inputs, not decisions, and are not adopted. | OWNER_DECISION_PENDING | REVERSIBLE (tightening takes effect immediately; loosening is a CA-1 action) | The "risk limits defined" interlock fails, so Live is refused. The design produces results as functions across ranges. Paper-mode limits are supplied by the owner through the same mechanism and are labeled paper-only. The design supplies none. | The Live selector. Any claim that a sizing result is "the answer". | Part 3 (parametric only, so not blocking). Part 8 (interlock text). | Five values, each as a fraction of equity or an amount in USDT, plus the equity basis. |
| OD-2 | The owner's legal, sanctions and licensing position on using cross-venue data for research and Paper. | A5 forbids the design from drawing legal conclusions. Only the owner can attest the facts. | OWNER_DECISION_PENDING | COSTLY_REVERSIBLE (derived artifacts must be re-derived if retracted) | Stricter reading (PF-4): cross-venue data is research-only. No Paper consumer. | Paper-path use of cross-venue data. Any depth claim at 1h/4h that rests on cross-venue history (DV-1 consequence). | Part 5. | One statement: A5 conditions hold, or they do not, or unknown. |
| OD-3 | Availability and authorization of off-device infrastructure (payment, legal, geographic and cost constraints). | Money, identity and location are the owner's. | UNRESOLVED | COSTLY_REVERSIBLE | TP-1 is the only topology assumed available. TP-2…TP-6 are conditional. | May become blocking at the start of Part 5 if TP-1 cannot cover the derived envelope. If so, options are presented per §2.1.7 with consequences. | Start of Part 5 (conditional). | Per topology: available, unavailable, or unknown; plus a monthly cost ceiling in USDT. |
| OD-4 | Ratification of the operator-unreachable policy. | It determines the owner's exposure while unreachable. | OWNER_DECISION_PENDING (ratification); DESIGN_JUDGMENT (default) | REVERSIBLE | Default stays in force: exchange-resident protective orders plus fail-closed behavior (RQ-TEL-02). | Nothing. It is not blocking. | None (ratification requested at Part 8). | Accept default, or name an alternative from those enumerated in Part 7. |

## 2.4 Conflict register

Rows CF-1…CF-5 are defined in Part 1. They appear here only with their Part 2 disposition. Rows RX-1…RX-6 are defined here. Resolution follows the lexicographic order CR-1…CR-8, so a conflict is resolved in favor of the earlier criterion.

| ID | Conflicting items | Nature | Resolution rule | Disposition | Where resolved | Reversibility | Status |
|---|---|---|---|---|---|---|---|
| CF-1 (Part 1) | A2 vs stopped-process recovery (DQ-2) | Telegram-only operator vs recovery when no process runs | Open design question. Candidate: minimal always-on supervisor. Not pre-selected. | Carried by RQ-OWN-02 and RQ-OPS-02 | Parts 6, 8 | To be assigned in the decision record | UNRESOLVED |
| CF-2 (Part 1) | Teaching arithmetic vs D17 | Fixed examples vs parametric rule | Examples allowed only as labeled teaching arithmetic and as functions | RQ-RSK-06 | Part 3 | REVERSIBLE | Disposition set |
| CF-3 (Part 1) | Intraday breadth vs shallow depth vs trial budget | Native depth at ≤15m is short | Pareto reporting; forward accumulation; per-cell budget | RQ-OWN-06, RQ-DAT-02, RQ-STA-02, RQ-STA-03 | Parts 4, 5 | REVERSIBLE | Disposition set |
| CF-4 (Part 1) | Breadth vs device vs budget | Device and cost limit breadth | Envelope first, then device match; Step 4b | RQ-DEP-01, RQ-OWN-07 | Part 5 | REVERSIBLE | Disposition set |
| CF-5 (Part 1) | Small capital vs costs vs unknown minimum notionals | A fixed fee per trade may dominate small budgets | Parametric breakeven; admission rule; sizing refusal | RQ-DAT-04, RQ-RSK-07, RQ-STA-05 | Parts 3, 5 | REVERSIBLE | Disposition set |
| RX-1 | C10 maker-only floor vs protective exits (DQ-3) | A maker-only exit may not fill when protection is needed | CR-1 (fail-safety) over CR-3 (cost). Entries may use maker-only within C10 scope. Exits may cross the spread and are costed at the taker branch. | RQ-EXE-05 | Parts 3, 7 | REVERSIBLE | Disposition set |
| RX-2 | DQ-1 (exchange-resident exits) vs UEF-1 (order types unverified) | The requirement presumes a capability not yet established | Live is refused until UEF-1 is verified. Alternatives are analyzed in Part 7 with positive reasons. Locally automated exits alone leave an unprotected window during OCL-4. | RQ-EXE-04, RQ-VER-01 | Part 7 | REVERSIBLE | UNRESOLVED (until UEF-1 is verified) |
| RX-3 | A4 (no authenticated calls) vs CR-5 (verifiability) | The facts needed for Live readiness need credentials | Pre-Live gated checks (VM-6). This engagement verifies none. Live is not authorized by this design. | RQ-VER-01 | Parts 7, 9 | REVERSIBLE | Disposition set |
| RX-4 | A10 (no waiting period or profit hurdle) vs CR-2 (statistical defensibility) | The selector could switch to Live for a strategy that is NOT TESTED | The selector remains gated by the six interlocks only. Strategy evidence status is disclosed in the selector's response as labels, not as a gate. The owner may add a gate later (CA-1). | RQ-TEL-03 | Part 8 | REVERSIBLE | Disposition set |
| RX-5 | A8 (phone preservation) vs A9/HG-6 (reliable operation under Telegram loss) | The phone may be killed by the OS, so the Live core is exposed to OCL-4 | Per-workload evaluation. Live on the phone only if measured (C15, C16). Otherwise fall through the compromise order. | RQ-DEP-04, RQ-DEP-01 | Part 5 | REVERSIBLE | UNRESOLVED (measurement BLOCKED) |
| RX-6 | A5 (cross-venue conditions) vs A7 (breadth) and DV-1 (shallow native depth) | Cross-venue history deepens 1h/4h research but is gated by OD-2 | Research-only until OD-2. Forward accumulation covers ≤15m. | RQ-OWN-04, RQ-DAT-05 | Part 5 | COSTLY_REVERSIBLE | UNRESOLVED (OD-2) |

## 2.5 Reasoning notes for decisions made in this Part

| Decision | Alternatives rejected, with positive reasons | Reversibility | Deciding criterion |
|---|---|---|---|
| Local check identifiers PC-1…PC-8 instead of V-n | Labeling the checks V-1…V-7 without their wording could mislabel evidence. The local set is accurate now, and Part 10 maps it to V-1…V-12. | REVERSIBLE | CR-1 (never present a check as passed under the wrong definition) |
| Register uses statuses "NOT TESTED" for design rows | Marking them PASS would assert verification that has not occurred. The rows become PASS only after VM-3 or later methods run. | REVERSIBLE | CR-2 |
| Only four owner decisions | Adding questions about architecture or parameters would breach A12/A13 and would not change safety. | REVERSIBLE | CR-4 |
| Outage classes defined by affected capability, not duration | Duration-based classes would require asserting thresholds that C12 leaves UNRESOLVED. | REVERSIBLE | CR-1 |

## 2.6 Cross-references

| Pointer | Meaning |
|---|---|
| Part 3 | Resolves CF-2 and CF-5 numerically; the RQ-RSK-06 and RQ-RSK-07 acceptance conditions are tested there. |
| Part 4 | Carries RQ-OWN-05, RQ-STA-01…RQ-STA-05, RQ-RSK-08. |
| Part 5 | Carries RQ-OWN-06, RQ-OWN-07, RQ-DAT-01…RQ-DAT-05, RQ-DEP-01…RQ-DEP-04. OD-2 and OD-3 may be blocking there. |
| Parts 6–7 | Carry RQ-RSK-01…RQ-RSK-04, RQ-EXE-01…RQ-EXE-06, RQ-OPS-01, RQ-OPS-03, RQ-OPS-04. |
| Part 8 | Carries RQ-TEL-01…RQ-TEL-04, RQ-PHS-01, RQ-OPS-02, RQ-SEC-01, RQ-SEC-02; requests OD-4 ratification. |
| Parts 9–10 | Carry RQ-VER-01…RQ-VER-08, RQ-DOC-01…RQ-DOC-04. |

## 2.7 Artifact registry (updated)

| Artifact | Content | Part | Status |
|---|---|---|---|
| AR-01…AR-08 | Delivery plan; capability inventory; boundary; dependency analysis; checkpoint; input ledger; UEF register; PF/CF findings | 1 | DELIVERED |
| AR-09 | Requirements register, class definitions, OD register, conflict register | 2 | DELIVERED (this Part) |
| AR-10 | Risk concepts, parametric sizing | 3 | DEFERRED |
| AR-11 | Strategy architecture, statistical plan, trial budget, parameter register | 4 | DEFERRED |
| AR-12 | Data classes, universe, envelope, topology fit | 5 | DEFERRED |
| AR-13 | Decision records and component specifications | 6 | DEFERRED |
| AR-14 | Execution, risk authority, state, recovery | 7 | DEFERRED |
| AR-15 | Telegram, security, operations, phases | 8 | DEFERRED |
| AR-16 | Verification matrix, implementation order, adversarial review, propagation record | 9 | DEFERRED |
| AR-17 | Final acceptance | 10 | DEFERRED |

## 2.8 Part 2 completeness declaration

**Catalogs fully defined in Part 2** (each ID appears in one defining table):

| Catalog | IDs | Count |
|---|---|---|
| Requirements register | RQ-BND-01…RQ-DOC-04 | 65 |
| Priority classes | PRI-0…PRI-2 | 3 |
| Severity classes | SEV-1…SEV-4 | 4 |
| Change-authority classes | CA-1…CA-3 | 3 |
| Outage classes | OCL-1…OCL-5 | 5 |
| Risk classes | RKC-1…RKC-6 | 6 |
| Verification-method classes | VM-1…VM-6 | 6 |
| Owner-decision register | OD-1…OD-4 | 4 |
| New conflicts | RX-1…RX-6 | 6 |
| Part-2 checks | PC-1…PC-8 | 8 |

**Catalogs defined in Part 1 and only referenced here:** A1–A13, C1–C26, UEF-1…UEF-13, PF-1…PF-8, CF-1…CF-5, HG-1…HG-6, CR-1…CR-8, DQ-1…DQ-3, TP-1…TP-6, XC-1…XC-18, DV-1, AR-01…AR-08. The Part 1 definitions are not repeated here.

**Dangling-identifier audit.** Every identifier family used in Part 2 resolves to a catalog above or in Part 1. Part numbers ("Part 7") and prompt section marks ("§9.6") are pointers, not identifiers. Symbolic names τ_op, τ_venue, τ_feed, τ_proc, τ_clk are parameters, not IDs. They are to be listed in the Part 4 parameter register and are not used as values in Part 2.

**Duplicate-definition audit.** No ID defined in Part 2 was defined in Part 1. OD-1…OD-4 were forward references there and are defined here.

**Cumulative status.**
- Delivered: Parts 1 and 2 of 10.
- Deferred: Parts 3–10, with their delivery Parts named in §2.7.
- The full A+B+C+D+U+E+F=R arithmetic is produced in Part 10, because the category definitions are not restated in this Part.

## 2.9 Part 2 checks

| ID | Check | Evidence | Status |
|---|---|---|---|
| PC-1 | Header "Part 2/10" present; continuity to Part 1 and Part 3 stated | Header; §2.6; this Part's closing section | PASS |
| PC-2 | Register is one table, 11 fields, every row complete | §2.2.3; field list in §2.2.2; 65 rows counted in §2.2.4 | PASS (self-inspection) |
| PC-3 | Class definitions precede first use; "Class-A" absent | §2.1 precedes §2.2; no undefined class label used | PASS |
| PC-4 | No dangling identifiers | §2.8 audit | PASS |
| PC-5 | No illustrative owner risk figure adopted as an anchor | RQ-RSK-05 and OD-1 describe them without numeric values | PASS |
| PC-6 | Counts reproducible | §2.2.4 | PASS |
| PC-7 | No credential request or order action | Inspection of this Part | PASS |
| PC-8 | Conflicts registered and CF pointers valid | §2.4 | PASS |

All PASS entries are author self-inspection, not independent verification.

## 2.10 Next step

**Part 3/10** will deliver the risk-concept explanation with parametric worked examples for the 15 quantities, the 100/100/10 USDT teaching arithmetic shown as labeled functions, and the sizing and cost formulas. No owner input is needed before Part 3. OD-3 may become blocking at the start of Part 5, in which case the options will be presented then.

---

**یادداشت پیشرفت (فارسی)**

بخش ۲ از ۱۰ ارسال شد. محتوای آن: ثبت‌نامهٔ نیازمندی‌ها (۶۵ ردیف در یک جدول واحد با ۱۱ ستون)، تعریف کلاس‌های اولویت، شدت، اختیار تغییر، قطعی و ریسک، ثبت تصمیم‌های مالک (OD-1 تا OD-4) و ثبت تعارض‌ها.

**وضعیت:**
- ۳ ردیف PASS (بازرسی خودِ نویسنده، نه بررسی مستقل).
- ۵۵ ردیف NOT TESTED.
- ۴ ردیف UNRESOLVED.
- ۳ ردیف BLOCKED.
- هیچ ردیف FAIL نیست.

**تصمیم‌های در انتظار مالک:**
- OD-1: مقادیر مرز ریسک. تا تعیین آن‌ها، شرط «تعریف حدود ریسک» برای Live رد می‌شود. اعداد نمونهٔ قبلی شما به‌عنوان مبنا استفاده نشده‌اند.
- OD-2: موضع حقوقی دربارهٔ داده‌های بین‌صرافی. تا آن زمان فقط برای پژوهش است.
- OD-3: دسترسی به زیرساخت خارج از دستگاه. ممکن است در ابتدای بخش ۵ مانع‌ساز شود؛ در آن صورت گزینه‌ها ارائه می‌شود.
- OD-4: تأیید سیاست «اپراتور در دسترس نیست». پیش‌فرض برقرار است و مانع‌ساز نیست.

**نکتهٔ شفافیت:** سه مورد (فهرست دقیق ۱۱ فیلد بند ۶، متن دقیق V-1 تا V-12، و دسته‌های آزمون §2.1.0c) را عیناً بازتولید نکردم. جزئیات در بخش ۲٫۰ آمده و در بخش ۱۰ بازبینی می‌شود.


# Part 3/10: Risk Concepts, Parametric Worked Examples, Sizing and Cost Formulas

**Continuity.** Part 2/10 delivered the 65-row requirements register, the class definitions, OD-1…OD-4 and RX-1…RX-6. This Part tests the acceptance conditions of RQ-RSK-06 and RQ-RSK-07 and gives the numerical disposition of CF-2 and CF-5, and of the cost side of RX-1. Part 4/10 follows with the strategy architecture, the statistical plan and the parameter register. No earlier identifier is redefined here.

## 3.0 Scope and fidelity notes (read first)

1. **Nothing in this Part is a recommendation or a limit.** The risk limits (drawdown, per-trade risk, daily loss, aggregate exposure, leverage cap) belong to OD-1 (OWNER_DECISION_PENDING). They appear here only as symbols (B, A_cap, D_day, DD_max, L_cap) and as grids chosen to show the shape of a function. The grid values are not defaults.
2. **A coincidence in teaching constants.** The teaching budget of 10 USDT (§3.6) divided by the sample equity of 200 USDT is 5%. This is arithmetic between two teaching constants. It does not adopt the owner's earlier illustrative per-trade figure, which remains an input and not a decision. §3.6 shows the ratio as a function of equity.
3. **Every numeric input below is hypothetical.** The instrument, price, multiplier and filters are chosen so that arithmetic is checkable by hand. They are not Toobit quotes or contract specifications. Contract multiplier, filters, liquidation formula, funding interval and maker fee are all unestablished (UEF-3, UEF-11, UEF-4, UEF-10).
4. **Labels.** Formulas are DERIVED from the stated model assumptions. Hypothetical inputs are DESIGN_JUDGMENT, chosen for checkability. Results are DERIVED from them. Where a fee value comes from C6, it is the PROVISIONAL conservative branch.
5. **Arithmetic provenance.** All arithmetic was done by hand, because no code execution exists in this engagement (Part 1 capability inventory). Rounded displays are marked. A reader can reproduce each result from the stated inputs. The arithmetic checks are VM-2 self-inspection, not independent verification.

## 3.1 Model assumptions (catalog MA)

| ID | Assumption | Basis | Evidence label | If false |
|---|---|---|---|---|
| MA-1 | The contract is linear and USDT-margined. P&L in USDT is s·q·ΔP with s = +1 long, −1 short. Inverse contracts are out of scope. | Not established in the carried inputs. Money is always USDT (RQ-DOC-03). | PROVISIONAL | Pre-Live check on contract type. Formulas FM-1…FM-19 are re-derived. |
| MA-2 | Quantity q (base units) = n·m, with n an integer number of contracts and m the contract multiplier. Orders are integer multiples of a lot increment λ (base units), with minimum quantity q_min, minimum notional N_min, and prices on a tick grid. | UEF-3 | UNRESOLVED (values unknown, so symbols) | A symbol with unknown filters is not admitted (RQ-DAT-04). |
| MA-3 | Fees are charged on traded notional at the fill price. The entry rate is f_in and the exit rate is f_out. The conservative taker branch is 0.0006 (C6). The 0.05% branch is also covered. The maker rate is a parameter range. | C6; UEF-10 | PROVISIONAL | Re-run FM-4, FM-8. |
| MA-4 | Funding settles at discrete timestamps spaced Δ_f apart, with payment s·φ·q·Mk (Mk = mark price at settlement). Stress takes the adverse sign and an uncapped magnitude φ_stress ≥ 0. | UEF-4; C7 | PROVISIONAL | Re-run FM-5, FM-6. |
| MA-5 | For a per-position liquidation estimate, margin is treated as isolated: M = N/L backs the position. Cross-margin coupling (UEF-2) is handled by the aggregate rule FM-13. | UEF-2 | DESIGN_JUDGMENT | If cross buffers are smaller than assumed, FM-13 and FM-15 are re-derived. |
| MA-6 | A generic liquidation model uses a maintenance margin rate mmr. The trigger excludes fees and funding. A safety factor κ ≥ 1 multiplies the stop-side loss distance. The venue formula is not assumed. | UEF-11 | PROVISIONAL | Live is refused until the venue formula is observed (RQ-VER-01). |
| MA-7 | A protective stop converts to a market-like exit near the trigger price P_s. The fill is P_x = P_s − s·σ_x. A gap term g ≥ 0 beyond σ_x may occur. No assumption is made that the stop fills at its trigger. | UEF-1 | DESIGN_JUDGMENT | Not applicable. This is the conservative direction. |
| MA-8 | The unit is USDT. No USDT/USD parity is assumed. Prices are in USDT per base unit. | RQ-DOC-03 | OWNER_HARD (money rule) | Not applicable. |

## 3.2 Notation

These are notation, not catalog identifiers. Part 4 lists the adjustable ones in the parameter register, with ranges and adaptation status.

| Symbol | Meaning | Unit |
|---|---|---|
| E | Equity on a stated basis: E_w = wallet balance, E_mtm = wallet balance + unrealized P&L at mark | USDT |
| s | Side: +1 long, −1 short | none |
| P_ref | Reference price at decision (mid) | USDT/base unit |
| P_e, P_s, P_x | Actual entry fill, stop trigger price, stop exit fill | USDT/base unit |
| σ_e, σ_x | Adverse entry slippage (half-spread plus impact) and adverse stop-exit slippage allowance (includes a gap allowance) | USDT/base unit |
| g | Realized extra adverse exit move beyond σ_x | USDT/base unit |
| d_ref | Stop distance from the reference: s·(P_ref − P_s) > 0 | USDT/base unit |
| m, n, q | Contract multiplier (base units per contract), integer contracts, quantity: q = n·m | base units |
| λ, q_min, N_min | Lot increment, minimum quantity, minimum notional | base units, base units, USDT |
| N, M, L | Notional, initial margin, leverage setting | USDT, USDT, none |
| L_eff | Notional divided by equity | none |
| f_in, f_out | Fee rates, entry and exit | fraction of notional |
| φ, φ_stress, Δ_f, T_h, k_max | Funding rate per interval, stress magnitude, funding interval, holding time, maximum settlements | fraction, fraction, time, time, count |
| B, r | Per-trade budget and budget fraction: B = r·E_basis | USDT, fraction |
| u | Worst-case modeled loss per base unit (FM-8) | USDT/base unit |
| ℓ | Worst-case modeled loss of a position: q·u | USDT |
| mmr, κ | Maintenance margin rate; stop-before-liquidation safety factor | fraction, none |
| A_cap, D_day, DD_max, L_cap | OD-1 limits: aggregate concurrent risk, daily loss, peak-to-trough drawdown, leverage cap. Values are not set here. | USDT, USDT, fraction, none |

## 3.3 Formula catalog (FM)

All are DERIVED from MA-1…MA-8 unless a note says otherwise.

| ID | Formula | Notes |
|---|---|---|
| FM-1 | N = q·P = n·m·P | P is the entry fill or current mark. N changes with price. |
| FM-2 | M = N/L; L_eff = N/E | Isolated-equivalent margin (MA-5). L is a setting; L_eff is an outcome. |
| FM-3 | G = s·q·(P − P_e) | Price P&L before fees and funding. |
| FM-4 | Fee = f_in·q·P_e + f_out·q·P_x | Entry and exit rates stay separate (RX-1; RQ-EXE-05). |
| FM-5 | Funding cost = Σ_k s·φ_k·q·Mk_k (cost positive); stress bound per unit: c_f = k_max·φ_stress·Mk_ref | The adverse sign is assumed. φ_stress is uncapped (C7 refutes the ±24 bp cap). |
| FM-6 | k_max = floor(T_h/Δ_f) + 1 | The number of settlement instants inside a hold is floor(T_h/Δ_f) or one more, depending on alignment. The upper value is used. |
| FM-7 | P_e = P_ref + s·σ_e; P_x = P_s − s·σ_x; d_ref = s·(P_ref − P_s) | P_s is on the tick grid before sizing. The sizing uses the stop actually placed. |
| FM-8 | u = d_ref + σ_e + σ_x + f_in·P_e + f_out·P_x + c_f | From s(P_e − P_x) = d_ref + σ_e + σ_x. Every term is nonnegative. |
| FM-9 | q = λ·floor(B / (u·λ)) | Round down. This guarantees ℓ = q·u ≤ B under the model. |
| FM-10 | Admission = conjunction of the negations of RF-1…RF-10 (§3.8) | A symbol that fails any member gets that refusal, not an adjusted trade. |
| FM-11 | B = r·E_basis. The basis (E_w or E_mtm) and r are OD-1 values. | Until OD-1 is answered the interlock "risk limits defined" fails. |
| FM-12 | B_min = max(q_min, N_min/P_e)·u; E_min(r) = B_min/r | The smallest budget and equity at which one lot is admissible (CF-5). |
| FM-13 | A_head = A_cap − Σ_i ℓ_rem,i; D_head = D_day − [max(0, E_open − E_mtm) + Σ_i ℓ_rem,i]; H_dd = Peak·DD_max − (Peak − E_mtm) − Σ_i ℓ_rem,i; B_eff = min(B, A_head, D_head, H_dd). The remaining worst-case loss of an open position is ℓ_rem,i = q_i·[s(P_mk − P_x) + f_out·P_x + c_f,rem]. | E_open is equity at 00:00 UTC (A3). Position losses are summed, which assumes the stops coincide. |
| FM-14 | Long: P_liq = P_e·(1 − 1/L)/(1 − mmr). Short: P_liq = P_e·(1 + 1/L)/(1 + mmr). Distance D_liq = |P_e − P_liq| = P_e·(1/L − mmr)/(1 − s·mmr). | From equating the loss to M − mmr·q·P_liq. The model is generic (MA-6). |
| FM-15 | Stop precedes liquidation: D_liq ≥ κ·(d_ref + σ_x), which gives L ≤ 1/(mmr + κ·x·(1 − s·mmr)) with x = (d_ref + σ_x)/P_e. | The leverage ceiling follows from the stop and the cost allowance. |
| FM-16 | Break-even hit rate for a stop-or-target trade: p* = u/(u + w), with win unit w(T) = T − σ_e − f_in·P_e − f_out·P_t − σ_t − c_f, where P_t = P_ref + s·T is the target price and σ_t the target-exit slippage. | A necessary condition on the hit rate, not an expectation. No claim is made that p* is attainable (RQ-BND-02). |
| FM-17 | Fee share ψ = (f_in·P_e + f_out·P_x)/u | The fraction of worst-case loss that is fees. |
| FM-18 | DD_t = (Peak_t − E_t)/Peak_t, Peak_t = max E over the measurement window; E basis from OD-1 | Peak-to-trough drawdown. |
| FM-19 | Realized loss under a gap: ℓ_real = q·(u + g) | The nominal stop loss (q·d_ref) and the budget B are not caps on ℓ_real. |

## 3.4 Hypothetical scenario (catalog HS)

| ID | Inputs (all DESIGN_JUDGMENT, hypothetical) |
|---|---|
| HS-1 | E_w = 200 USDT (sample point, A11; never live equity). Long (s = +1). Quote bid/ask 49,995/50,005, so P_ref = 50,000 (mid) and the taker entry fills at P_e = 50,005 (σ_e = 5). m = 0.001, λ = 0.001 (1 contract), q_min = 0.001, N_min = 5 USDT. d_ref = 500, so P_s = 49,500. σ_x = 25. f_in = f_out = 0.0006. φ_stress = 0.0010, k_max = 1, Mk_ref = 50,000. mmr = 0.005, κ = 2. L = 5. r = 1%, so B = 2 USDT. |

**Core result (used throughout).** From FM-7: P_x = 49,500 − 25 = 49,475. From FM-8:

- s(P_e − P_x) = 50,005 − 49,475 = 530 (= 500 + 5 + 25 ✓)
- f_in·P_e = 0.0006 × 50,005 = 30.003
- f_out·P_x = 0.0006 × 49,475 = 29.685
- c_f = 0.0010 × 50,000 × 1 = 50
- **u = 530 + 30.003 + 29.685 + 50 = 639.688 USDT per base unit**

From FM-9: B/u = 2/639.688 = 0.0031264 base units, so floor(3.1264) = 3 contracts, **q = 0.003** and **ℓ = 0.003 × 639.688 = 1.919064 USDT ≤ 2 ✓**.

## 3.5 The fifteen quantities (catalog WE, WE-1…WE-15)

Each row defines the quantity and the distinction it exists to teach. Each worked example uses HS-1.

| ID | Quantity | Definition and what it is not | Worked example | Result |
|---|---|---|---|---|
| WE-1 | Equity | The account value on a stated basis. E_w excludes unrealized P&L. E_mtm includes it. The basis is part of OD-1. Equity is not notional, margin or buffer. | Start E_w = 200. The entry fee paid is 0.003 × 30.003 = 0.090009, so E_w = 199.909991. At mark 49,800: G = 0.003 × (49,800 − 50,005) = −0.615, so E_mtm = 199.909991 − 0.615 = 199.294991. | Three equity values coexist: 200; 199.909991; 199.294991. |
| WE-2 | Notional | N = q·P: the exposure's market value. It moves with price and is not the amount at risk. | At fill: 0.003 × 50,005 = 150.015. At mark 49,800: 0.003 × 49,800 = 149.4. | 150.015 then 149.4 USDT. |
| WE-3 | Margin | The collateral locked to hold N: M = N/L. Margin is not loss and not the loss cap in the general case. | L = 5: 150.015/5 = 30.003. L = 10: 15.0015. L = 20: 7.50075. | Margin falls as L rises. The stop loss in WE-7 does not change. |
| WE-4 | Leverage | L is a setting that fixes how much margin N needs. L_eff = N/E is the exposure relative to equity. They differ. | L = 5 while L_eff = 150.015/200 = 0.750075. Doubling L to 10 leaves N, q and loss unchanged. | A configured L = 5 can coexist with L_eff < 1. **Leverage alone does not multiply P&L for a fixed notional.** |
| WE-5 | Quantity and contract multiplier | q = n·m, and q must be a multiple of λ and at least q_min. m changes what one contract means. | m = 0.001: 3 contracts = 0.003. If instead m = 0.01 with 1-contract lot, then q_min = 0.01 and B_min = 0.01 × 639.688 = 6.39688 > B = 2, so the trade is refused (RF-2). | Granularity can force refusal at a given budget. |
| WE-6 | Stop distance | d_ref = s(P_ref − P_s): the price move to the stop. It is set by market structure (Part 4), not by the budget. The budget then fixes q. | d_ref = 500, which is 500/50,000 = 1.00% of P_ref. If the bar's standard deviation were 250, the stop would be 2.0 σ_bar. | The stop is on the tick grid before sizing (FM-7). |
| WE-7 | Gross loss | The price-only loss at realized fills, before fees and funding. It is not the nominal stop loss, because slippage is in the fills. | Nominal q·d_ref = 0.003 × 500 = 1.5. Realized G = 0.003 × (49,475 − 50,005) = −1.59. | −1.5 nominal; −1.59 gross realized. |
| WE-8 | Fees | Charged on both legs at their own rates (FM-4). They are paid whether the trade wins or loses. | Entry 0.003 × 30.003 = 0.090009. Exit 0.003 × 29.685 = 0.089055. Total 0.179064. | 0.179064 USDT. Fee share ψ = 59.688/639.688 = 9.33%. |
| WE-9 | Funding | A periodic transfer between sides, paid or received. Stress takes the adverse sign without a cap. | q·Mk = 0.003 × 50,000 = 150 USDT. See table 3.5.1. | Stress cost 0.15 USDT at φ_stress = 10 bp and k_max = 1. |
| WE-10 | Spread and slippage | σ_e = half-spread + impact (here 5 + 0 = 5). σ_x is a stop-exit allowance that includes the half-spread and adverse motion (here 25 = 5 + 20, a hypothetical split). Slippage is a cost inside the fills. It is not a fee. | (σ_e + σ_x)·q = 30 × 0.003 = 0.09. In basis points of P_ref: σ_e = 1 bp, σ_x = 5 bp. | 0.09 USDT. It is part of the 1.59 gross loss: 1.5 + 0.09 = 1.59 ✓. |
| WE-11 | Liquidation | The forced close when margin cannot support the loss. It is a venue process, not a stop. Stops must trigger first (FM-15). | Table 3.5.2. | At L = 5, 10, 20 a κ = 2 stop precedes liquidation. At L = 40 it does not. |
| WE-12 | Per-trade budget | B = r·E: the most the system intends to lose on one trade under the model. A budget is a sizing input. It is not a guarantee. | Table 3.5.3. HS-1: ℓ = 1.919064 against B = 2. The unused part is 0.080936 (4.05% of B), caused by lot rounding. | Rounding down keeps ℓ ≤ B. |
| WE-13 | Aggregate concurrent risk | The sum of worst-case losses of all open positions if their stops fire together. See below. | Below. | Sum is used. Independence is not established. |
| WE-14 | Daily loss | The net equity change since 00:00 UTC (A3): max(0, E_open − E_mtm). Gains offset losses. | Below. | Net, not gross. |
| WE-15 | Peak-to-trough drawdown | DD = (Peak − E)/Peak (FM-18) over a stated window and basis. It differs from daily loss because the peak moves. | Below. | The basis changes the answer. |

### 3.5.1 Funding stress (WE-9), q·Mk = 150 USDT

| φ_stress (bp per settlement) | Cost, k_max = 1 (USDT) | Cost, k_max = 3 (USDT) | Share of B = 2 at k_max = 1 |
|---|---|---|---|
| 0 | 0 | 0 | 0% |
| 5 | 0.075 | 0.225 | 3.75% |
| 10 | 0.15 | 0.45 | 7.5% |
| 20 | 0.30 | 0.90 | 15% |
| 30 | 0.45 | 1.35 | 22.5% |

The 30 bp row matches the magnitude observed in C7. It is not a ceiling, because the ±24 bp cap is refuted. k_max by FM-6, for a hypothetical Δ_f = 8 h (UEF-4 unknown): T_h = 6 h gives floor(0.75) + 1 = 1, and T_h = 20 h gives floor(2.5) + 1 = 3.

### 3.5.2 Liquidation (WE-11), long, P_e = 50,005, mmr = 0.005, X = d_ref + σ_x = 525, κ = 2

| L | P_liq = P_e·(1 − 1/L)/0.995 | D_liq = P_e − P_liq | D_liq/X | Stop first (needs ≥ κ = 2)? |
|---|---|---|---|---|
| 5 | 40,205.03 | 9,799.97 | 18.67 | Yes |
| 10 | 45,230.65 | 4,774.35 | 9.09 | Yes |
| 20 | 47,743.47 | 2,261.53 | 4.31 | Yes |
| 40 | 48,999.87 | 1,005.13 | 1.91 | **No** |

Check against FM-15: x = 525/50,005 = 0.010499, and mmr + κ·x·(1 − mmr) = 0.005 + 2 × 0.010499 × 0.995 = 0.025893, so L_max = 38.62. L = 20 satisfies L ≤ 38.62 and L = 40 does not, as the table shows. A short check: P_e = 49,995, L = 10, P_liq = 49,995 × 1.1/1.005 = 54,720.90, D_liq = 4,725.90. Check by the closed form: 49,995 × 0.095/1.005 = 4,725.90 ✓. The long and short distances differ because of the (1 ∓ mmr) denominators.

### 3.5.3 Per-trade budget grid (WE-12): B = r·E in USDT

The r values are a span chosen to show the function's shape. They are not defaults and no value is recommended.

| E (USDT) | r = 0.25% | r = 0.5% | r = 1% | r = 2% | r = 3% |
|---|---|---|---|---|---|
| 100 | 0.25 | 0.50 | 1.00 | 2.00 | 3.00 |
| 200 | 0.50 | 1.00 | 2.00 | 4.00 | 6.00 |
| 300 | 0.75 | 1.50 | 3.00 | 6.00 | 9.00 |
| 500 | 1.25 | 2.50 | 5.00 | 10.00 | 15.00 |

### 3.5.4 Aggregate concurrent risk (WE-13)

Sample A_cap = 4 USDT (arbitrary, to show the mechanism). Open position 1 has ℓ = 1.919064 and position 2 has ℓ = 1.50. A candidate 3 sized like position 1 would add 1.919064. The sum is 5.338128 > 4, so A_head = 4 − (1.919064 + 1.5) = 0.580936. The smallest admissible position is one lot: 0.001 × 639.688 = 0.639688 > 0.580936. So the candidate is refused (RF-7 with RF-2). If the combination rule were root-sum-square, the figure would be √(3.682806 + 2.25 + 3.682806) = √9.615612 = 3.1009 < 4, and the candidate would be admitted. Independence of stops is not established, so the sum is used (§3.9). This is deliberate: simultaneous stops are the case a limit exists for.

### 3.5.5 Daily loss (WE-14)

Each stopped trade costs ℓ = 1.919064. The admission rule is the sample-D case of D_head ≥ ℓ_new with no open positions. The number of consecutive stopped trades admitted is floor(D_day/ℓ).

| D_day sample (USDT) | D_day/ℓ | Trades admitted | After the last admitted stop |
|---|---|---|---|
| 4 | 2.0843 | 2 | 3.838128 lost; headroom 0.161872 |
| 6 | 3.1264 | 3 | 5.757192 lost; headroom 0.242808 |
| 8 | 4.1687 | 4 | 7.676256 lost; headroom 0.323744 |
| 10 | 5.2108 | 5 | 9.59532 lost; headroom 0.40468 |

For D_day = 6: a fourth admission would need 5.757192 + 1.919064 = 7.676256 > 6, so it is refused (RF-8).

**Net versus gross-loss counting.** The sequence is stop, stop, then a win of net +2.50, at D_day = 4. Net basis: max(0, 3.838128 − 2.5) = 1.338128, and 1.338128 + 1.919064 = 3.257192 ≤ 4, so the next trade is admitted. Gross-loss-only counting: 3.838128 + 1.919064 = 5.757192 > 4, so it is refused. The net basis is used because the equity effect on the owner is net (§3.9).

### 3.5.6 Peak-to-trough drawdown (WE-15)

Realized equity path (hypothetical): 200 → +4.0 = 204.0 → +3.0 = 207.0 (peak) → −2.5 = 204.5 → −3.0 = 201.5 → −1.5 = 200.0 (trough) → +2.0 = 202.0.

- DD_max-observed = (207 − 200)/207 = 7/207 = **3.3816%** (absolute 7.0 USDT).
- The same path measured against the initial 200: 7/200 = 3.5%. The basis matters, so the basis is part of OD-1.
- Mark-to-market excursion: if the final trade was open at −2.0 before closing at +2.0, then E_mtm reached 198.0 and DD = 9/207 = **4.3478%**. A realized-only measurement understates the drawdown actually experienced.
- Drawdown headroom H_dd with Peak = 207, E = 202, Σℓ_rem = 0, for sample DD_max values: 4% gives 207 × 0.04 − 5 = 3.28; 6% gives 12.42 − 5 = 7.42; 8% gives 16.56 − 5 = 11.56 USDT.

## 3.6 Teaching arithmetic (WE-16)

**Label (CF-2).** These constants are teaching arithmetic only: notional 100 USDT, margin 100 USDT, maximum-loss budget 10 USDT. Each is shown as a function over a range. None is a recommended size or limit.

**(a) Fixed notional N = 100: leverage changes margin, not loss.**

| L | M = 100/L (USDT) | Loss at 1% adverse (USDT) | Loss at 10% adverse (USDT) |
|---|---|---|---|
| 1 | 100 | 1.00 | 10.00 |
| 2 | 50 | 1.00 | 10.00 |
| 5 | 20 | 1.00 | 10.00 |
| 10 | 10 | 1.00 | 10.00 |
| 20 | 5 | 1.00 | 10.00 |

**(b) Fixed margin M = 100: here notional rises with L, so loss rises.** The multiplier is notional. Leverage is the mechanism that permits more notional from the same margin.

| L | N = L·100 (USDT) | Loss at 1% adverse | Loss at 2% adverse |
|---|---|---|---|
| 1 | 100 | 1 | 2 |
| 2 | 200 | 2 | 4 |
| 5 | 500 | 5 | 10 |
| 10 | 1,000 | 10 | 20 |

**(c) Fixed budget B = 10: notional is a function of the stop distance.** The gross-only function is N_max = B/d_rel. The cost-inclusive function is N_max = B·P_e/u. For HS-1, u/P_e = 639.688/50,005 = 0.0127929.

| Stop distance d_rel | Gross-only N_max (USDT) | Margin needed at L = 1 | L needed if margin allocated = 100 |
|---|---|---|---|
| 0.5% | 2,000 | 2,000 | 20 |
| 1% | 1,000 | 1,000 | 10 |
| 2% | 500 | 500 | 5 |
| 5% | 200 | 200 | 2 |
| 10% | 100 | 100 | 1 |

The case (notional 100, margin 100, budget 10) is internally consistent only at d_rel = 10% and L = 1. In every other case the three numbers describe different things. **Cost effect:** at a 1% stop with HS-1 costs, the cost-inclusive N_max = 10 × 50,005/639.688 = 781.71 USDT, against 1,000 gross-only. Costs reduce the admitted notional by 1 − 781.71/1,000 = 21.83%.

**(d) The ratio B/E as a function of equity:** B = 10 gives 10.00% at E = 100, 6.67% at E = 150, 5.00% at E = 200, 3.33% at E = 300, 2.00% at E = 500 (see §3.0 item 2).

## 3.7 Further worked functions (WE-17…WE-20)

### WE-17: minimum feasible equity (CF-5)

FM-12 with u = 639.688 and q_min as shown. N_min = 5 USDT is not binding, since 5/50,005 = 0.0001 < q_min. B_min = q_min·u. E_min = B_min/r (USDT).

| q_min | B_min (USDT) | E_min at r = 0.25% | r = 0.5% | r = 1% | r = 2% | r = 3% |
|---|---|---|---|---|---|---|
| 0.001 | 0.639688 | 255.88 | 127.94 | 63.97 | 31.98 | 21.32 |
| 0.01 | 6.39688 | 2,558.75 | 1,279.38 | 639.69 | 319.84 | 213.23 |

Reading: with 200 USDT equity and q_min = 0.01, a 3% budget fraction is infeasible (213.23 > 200) and the system refuses (RF-2). With q_min = 0.001 the same equity admits r ≥ 0.32%, since 0.639688/200 = 0.3198%. The venue filters (UEF-3) therefore decide admissibility, so a symbol is admitted only with known filters (RQ-DAT-04).

### WE-18: break-even hit rate (RQ-STA-05)

Stop at d_ref = 500 and the same costs. The target exit uses the taker rate (conservative) with σ_t = 0. Gross-only: p*_g = d_ref/(d_ref + T). Cost-inclusive: p* = u/(u + w), where w(T) = T − 5 − 30.003 − f_out·P_t − 50 and P_t = 50,000 + T.

| T (target distance) | Gross-only p*_g | f_out·P_t | w(T) | Cost-inclusive p* |
|---|---|---|---|---|
| 500 | 0.5000 | 30.300 | 384.697 | 0.6245 |
| 1,000 | 0.3333 | 30.600 | 884.397 | 0.4197 |
| 1,500 | 0.2500 | 30.900 | 1,384.097 | 0.3161 |
| 2,000 | 0.2000 | 31.200 | 1,883.797 | 0.2535 |

Arithmetic example, T = 1,000: w = 1,000 − 5 − 30.003 − 30.6 − 50 = 884.397; p* = 639.688/(639.688 + 884.397) = 639.688/1,524.085 = 0.4197. Costs raise the required hit rate by 8.6 to 12.5 percentage points over the gross-only figures (0.6245 − 0.5000 = 0.1245; 0.2535 − 0.2000 = 0.0535 at T = 2,000). This is a necessary condition on a two-outcome model. It says nothing about whether any strategy attains it (NOT TESTED).

### WE-19: nominal stop risk is not a realized-loss cap (FM-19)

q = 0.003, B = 2, E = 200. Nominal stop loss: 0.003 × 500 = 1.5. Model worst case: 1.919064. Realized loss under a gap g beyond the σ_x allowance:

| g (USDT/unit) | ℓ_real = 0.003 × (639.688 + g) | Ratio to B = 2 | Percent of E = 200 |
|---|---|---|---|
| 0 | 1.919064 | 0.9595 | 0.9595% |
| 100 | 2.219064 | 1.1095 | 1.1095% |
| 500 | 3.419064 | 1.7095 | 1.7095% |
| 1,000 | 4.919064 | 2.4595 | 2.4595% |
| 5,000 | 16.919064 | 8.4595 | 8.4595% |

The allowance σ_x is a model parameter with a floor that no optimizer may lower (RQ-RSK-08). It does not bound g. The protections against g are: the stop-before-liquidation ceiling (FM-15), the daily, drawdown and aggregate limits that count realized losses after the fact, and the Part 7 rules for exchange-resident exits (RQ-EXE-04). A larger g never reduces a limit. It triggers the limits sooner.

### WE-20: fee-branch comparison (RQ-EXE-05, RQ-DAT-06)

B = 2, stop at d_ref = 500 (P_s = 49,500, P_x = 49,475). The maker parameter range is not a fact (UEF-10), so its values are illustrative. A non-fill probability is not modeled here (Part 4).

| Branch | σ_e | f_in, f_out | u (USDT/unit) | B/u | n | ℓ = 0.003·u |
|---|---|---|---|---|---|---|
| a. Taker entry, 0.06% both legs | 5 | 0.0006, 0.0006 | 639.688 | 0.0031264 | 3 | 1.919064 |
| b. Taker entry, 0.05% both legs | 5 | 0.0005, 0.0005 | 629.74 | 0.0031759 | 3 | 1.88922 |
| c. Maker entry, f_in = 0, taker exit | 0 | 0, 0.0006 | 604.685 | 0.0033075 | 3 | 1.814055 |
| d. Maker entry, f_in = 0.0002, taker exit | 0 | 0.0002, 0.0006 | 614.685 | 0.0032537 | 3 | 1.844055 |

Arithmetic: (b) 530 + 0.0005 × 50,005 (= 25.0025) + 0.0005 × 49,475 (= 24.7375) + 50 = 629.74. (c) 500 + 25 + 0 + 29.685 + 50 = 604.685, and the closed form 604.685 + 50,000·f_m gives 614.685 at f_m = 0.0002. All four branches size to 3 contracts, so lot quantization hides a 5.7% spread in u (639.688/604.685 = 1.0579) at this budget. The cost differences matter at larger budgets or finer lots, and in break-even terms (WE-18).

## 3.8 Sizing procedure and refusal catalog (RF)

### 3.8.1 Procedure (executed by the sizing function, whose home component is specified in Part 6)

1. Validate inputs. Any unknown, stale or unevaluable input gives RF-1.
2. Compute B (FM-11) from OD-1 values. Compute the headrooms and B_eff (FM-13). The budget is capped by headroom. It is never raised.
3. Select the stop price on the tick grid, then compute d_ref, σ values and u (FM-7, FM-8).
4. Compute q (FM-9). If q < q_min, refuse RF-2. If q·P_e < N_min, refuse RF-3.
5. Choose L. L must satisfy N/L ≤ available margin (with reserve), L ≤ L_cap, L ≤ the venue maximum for the notional tier (C3: maximum UNRESOLVED), and L ≤ the FM-15 ceiling. If no L satisfies all, refuse RF-4, RF-5 or RF-6, whichever applies first.
6. Recompute ℓ = q·u and confirm ℓ ≤ B_eff. Output the sized order with all inputs recorded.

Reducing the budget to headroom is allowed because it can only lower exposure. Raising a quantity to meet a minimum lot is not allowed (§3.9).

### 3.8.2 Refusal catalog

Part 7 binds each code to a veto or refusal class. Part 8 binds each to its text. This Part defines code name, condition and fields.

| ID | Code | Condition | Output fields |
|---|---|---|---|
| RF-1 | UNKNOWN_INPUT | Any needed input is unknown or stale: tick, lot, q_min, N_min, m, fee rate, price, equity basis, mmr, risk limits (OD-1 not set). | Input name; age or "unknown" |
| RF-2 | BELOW_MIN_QTY | q after rounding is below q_min. | B_eff, u, q_raw, q_min |
| RF-3 | BELOW_MIN_NOTIONAL | q·P_e < N_min. | q, P_e, N_min |
| RF-4 | MARGIN_INSUFFICIENT | M exceeds available margin after reserve. | M, available margin |
| RF-5 | LEVERAGE_CAP | Required L = N/margin allocation exceeds L_cap. | L_required, L_cap |
| RF-6 | LIQ_ORDER_FAIL | No L satisfies FM-15 within the other bounds. | L_max (FM-15), κ, mmr |
| RF-7 | AGGREGATE_EXCEEDED | A_head is below the smallest admissible ℓ. | A_head, ℓ_min |
| RF-8 | DAILY_EXCEEDED | D_head is below the smallest admissible ℓ. | D_head, ℓ_min |
| RF-9 | DRAWDOWN_HEADROOM | H_dd is below the smallest admissible ℓ. | H_dd, ℓ_min |
| RF-10 | STOP_NOT_PLACEABLE | The stop is on the wrong side, off the tick grid, or an exchange-resident stop is unverified (UEF-1). | Reason; UEF-1 status |

## 3.9 Decisions made in this Part

| Decision | Alternatives rejected, with positive reasons | Reversibility | Deciding criterion |
|---|---|---|---|
| Size from worst-case loss per unit u, not from d_ref alone | Sizing from d_ref only omits costs that, in HS-1, are 20.4% of u ((639.688 − 500)/639.688 = 21.8% when σ_e, σ_x are included): the budget would be breached by construction | REVERSIBLE | CR-1 |
| Round quantity down; refuse below the minimum lot | Rounding up to meet q_min raises ℓ above B (WE-5: 6.39688 against B = 2), so it breaks the budget by design | REVERSIBLE | CR-1 |
| Reduce the budget to headroom instead of refusing outright | Refusing whenever the full budget does not fit blocks admissible smaller trades. A smaller trade cannot raise exposure. | REVERSIBLE | CR-4 (after CR-1 is met) |
| Aggregate by summing worst-case losses | Root-sum-square assumes independent stops. That is not established, and in a market shock correlation is the feared case. In WE-13 the choice flips admission. | REVERSIBLE | CR-1 |
| Daily loss on net equity change | Gross-loss counting blocks trading after a recovered loss (§3.5.5) although the owner's equity effect is net. A peak-based measure is drawdown, which is limited separately. | REVERSIBLE | CR-4 |
| Generic liquidation model with κ and mmr | Assuming the venue formula would present an unverified fact as known (UEF-11). A fixed leverage ceiling would not respond to stop distance. | REVERSIBLE | CR-1 |
| Funding stress with the adverse sign and no cap | Assuming a cap is refuted by C7. Assuming the favorable sign would understate cost. | REVERSIBLE | CR-1 |
| Separate entry and exit fee rates | A single blended rate would hide that protective exits cross the spread (RX-1) | REVERSIBLE | CR-1, CR-3 |
| Leverage chosen as an output of margin, cap and FM-15, not as an input | Treating leverage as a strategy parameter invites an optimizer to relax a limit (RQ-RSK-08) | REVERSIBLE | CR-1 |

## 3.10 Requirement acceptance tests (VM-2, author self-inspection)

| Requirement | Acceptance condition | Result | Evidence |
|---|---|---|---|
| RQ-RSK-06 | Fifteen reproducible examples; teaching arithmetic labeled and shown as functions; the two statements present | **PASS** (self-inspection) | WE-1…WE-15 (§3.5); WE-16 (§3.6); statements in WE-4 and WE-19 |
| RQ-RSK-07 | Formula contains each term; a refusal branch exists; worst-case liquidation is parametric | **PASS** (self-inspection) | FM-8, FM-10, FM-14, FM-15; RF-1…RF-10 |
| RQ-RSK-05 | No illustrative owner figure as an anchor; each calculation across a range | Unchanged: UNRESOLVED (OD-1). Part 3 contains no anchor. | §3.0; §3.5.3; §3.5.5 |
| RQ-EXE-05 | Entry and exit fee assumptions separate | Partial: the cost model satisfies it (FM-4, WE-20). "No exit rule depends on a maker fill" is verified in Part 7. Remains NOT TESTED. | §3.7 |
| RQ-DAT-06 | Each cost term a parameter with its range | Partial: the parameters are named. Their ranges and adaptation status come in Part 4. Remains NOT TESTED. | §3.2 |
| RQ-STA-05 | Costs and break-even as functions; no expected result | Partial: break-even given (WE-18). Remains NOT TESTED until Part 4. | §3.7 |

**Status delta.** RQ-RSK-06 and RQ-RSK-07 move from NOT TESTED to PASS (self-inspection). Register arithmetic: PASS 3 + 2 = 5; NOT TESTED 55 − 2 = 53; UNRESOLVED 4; BLOCKED 3; FAIL 0; total 5 + 53 + 4 + 3 + 0 = 65. The row count is unchanged at 65. The register edit is applied in the Part 9 matrix.

**Conflict dispositions updated.**

| ID | Disposition |
|---|---|
| CF-2 | Resolved: the teaching arithmetic is labeled and shown as functions (§3.6). Status: RESOLVED (design level). |
| CF-5 | Quantified: E_min(r) shows that minimum lots and fees can make small equity infeasible, and the refusal branch exists (§3.7 WE-17, RF-2). The admission rule over actual filters is completed in Part 5. Status: DISPOSITION SET, awaiting UEF-3. |
| RX-1 | Cost side resolved: entries may be modeled as maker, exits at the taker rate (WE-20). The exit-path rule is verified in Part 7. Status: PARTIALLY RESOLVED. |

## 3.11 Artifact registry (updated)

| Artifact | Content | Part | Status |
|---|---|---|---|
| AR-01…AR-08 | Part 1 artifacts | 1 | DELIVERED |
| AR-09 | Requirements register, classes, OD register, conflict register | 2 | DELIVERED |
| AR-10 | Risk concepts, parametric sizing, MA/FM/HS/WE/RF catalogs | 3 | DELIVERED (this Part) |
| AR-11 | Strategy architecture, statistical plan, trial budget, parameter register | 4 | DEFERRED |
| AR-12 | Data classes, universe, envelope, topology fit | 5 | DEFERRED |
| AR-13 | Decision records and component specifications | 6 | DEFERRED |
| AR-14 | Execution, risk authority, state, recovery | 7 | DEFERRED |
| AR-15 | Telegram, security, operations, phases | 8 | DEFERRED |
| AR-16 | Verification matrix, implementation order, review, propagation record | 9 | DEFERRED |
| AR-17 | Final acceptance | 10 | DEFERRED |

## 3.12 Part 3 completeness declaration

**Catalogs fully defined in Part 3** (each ID appears in one defining table):

| Catalog | IDs | Count |
|---|---|---|
| Model assumptions | MA-1…MA-8 | 8 |
| Formulas | FM-1…FM-19 | 19 |
| Hypothetical scenario | HS-1 | 1 |
| Worked examples | WE-1…WE-20 | 20 |
| Refusal codes | RF-1…RF-10 | 10 |
| Part-3 checks | PC-9…PC-16 | 8 |

**Catalogs referenced only** (defined in Parts 1 and 2): A, C, UEF, PF, CF, RX, HG, CR, DQ, TP, XC, DV-1, OD, RQ, PRI, SEV, CA, OCL, RKC, VM, AR, PC-1…PC-8.

**Dangling-identifier audit.** Identifiers used and where they resolve: MA, FM, HS, WE and RF in §3.1–3.8; RQ, OD, CF, RX, UEF, C, A, CR, VM in Parts 1–2. Symbols in §3.2 are notation. Part references are pointers.

**Duplicate-definition audit.** No ID defined here was defined earlier. The RF catalog is the sole definition of the refusal codes, and Parts 7 and 8 will point to it.

**Cumulative status.** Delivered: Parts 1, 2, 3 of 10. Deferred: Parts 4–10, each with its delivery Part in §3.11. The full A+B+C+D+U+E+F=R arithmetic is produced in Part 10.

## 3.13 Part 3 checks

| ID | Check | Evidence | Status |
|---|---|---|---|
| PC-9 | "Part 3/10" header; continuity to Parts 2 and 4 stated | Header; §3.11; closing section | PASS |
| PC-10 | All fifteen quantities have worked examples | WE-1…WE-15 | PASS (self-inspection) |
| PC-11 | Teaching arithmetic labeled and shown as functions | §3.6 | PASS |
| PC-12 | No owner illustrative risk figure used as an anchor or default | §3.0 items 1–2; grids labeled as shape-only | PASS |
| PC-13 | Hand arithmetic spot-recomputed: u, ℓ, fee sum, liquidation distances (two formulas), L_max, E_min, p*, equity path | §3.4; §3.5.2; §3.7 | PASS (VM-2, author) |
| PC-14 | All money in USDT; no unlabeled USD | Inspection | PASS |
| PC-15 | No credential request, account access or order action | Inspection | PASS |
| PC-16 | No strategy claimed achievable; break-even stated as a necessary condition only | WE-18 | PASS |

All PASS entries are author self-inspection, not independent verification.

## 3.14 Next step

**Part 4/10** delivers the candidate strategy architecture (labeled NOT TESTED), the derivation of "intraday" and its holding bound (RQ-OWN-05), the statistical validation plan and trial-budget recomputation (RQ-STA-02…RQ-STA-04), the search-design declarations, and the parameter register (including τ_op, τ_venue, τ_feed, τ_proc, τ_clk and the adaptation status of every parameter named in §3.2). No owner input is needed before Part 4. OD-3 may become blocking at the start of Part 5.

---

**یادداشت پیشرفت (فارسی)**

بخش ۳ از ۱۰ ارسال شد. محتوا:
- فرض‌های مدل (MA-1 تا MA-8) و ۱۹ فرمول (FM-1 تا FM-19) برای اندازهٔ پوزیشن، هزینه‌ها، ضریب تأمین سرمایه و تسویه اجباری.
- ۱۵ مفهوم الزامی (سرمایه، ارزش اسمی، مارجین، اهرم، ضریب قرارداد، فاصلهٔ حد ضرر، زیان ناخالص، کارمزد، فاندینگ، اسپرد/لغزش، لیکوئید شدن، بودجهٔ هر معامله، ریسک هم‌زمان کل، زیان روزانه، افت از قله به دره) هر یک با مثال عددی قابل بازتولید.
- حساب آموزشی ۱۰۰/۱۰۰/۱۰ تتری به‌صورت تابع روی بازه، با برچسب «آموزشی».
- فهرست ۱۰ کد رد سفارش (RF-1 تا RF-10).

**نکتهٔ مهم برای شفافیت:** در حساب آموزشی، بودجهٔ ۱۰ تتر تقسیم بر سرمایهٔ نمونهٔ ۲۰۰ تتر برابر ۵٪ می‌شود. این فقط تصادف عددی دو ثابت آموزشی است و عدد شما به‌عنوان مبنا یا پیش‌فرض پذیرفته نشده است. همهٔ حدود ریسک هنوز در انتظار تصمیم شما (OD-1) هستند.

**نتایج کلیدی:**
- اهرم به‌تنهایی برای اندازهٔ ثابت پوزیشن زیان را چند برابر نمی‌کند؛ مقدار پوزیشن (notional) است که اثر دارد.
- حد ضرر اسمی سقف تضمین‌شدهٔ زیان نیست (در جدول WE-19 با شکاف قیمتی نشان داده شده است).
- با حداقل لات‌های نامعلوم و سرمایهٔ کوچک، ممکن است معامله اصلاً مجاز نباشد (WE-17).

**وضعیت:** دو ردیف نیازمندی (RQ-RSK-06 و RQ-RSK-07) با بازرسی خودِ نویسنده PASS شدند (نه بررسی مستقل). تعداد ردیف‌ها همچنان ۶۵ است.

**تصمیم‌های در انتظار:** OD-1 تا OD-4 بدون تغییر. OD-3 ممکن است در ابتدای بخش ۵ مانع‌ساز شود.


# Part 4/10: Candidate Strategy Architecture, Statistical Validation Plan, Trial Budget, Parameter Register

**Continuity.** Part 3/10 delivered the sizing and cost formulas FM-1…FM-19, the 20 worked examples and the refusal catalog RF-1…RF-10. Part 4 derives "intraday" (RQ-OWN-05), proposes candidate strategies (all NOT TESTED), and sets out the statistical plan (RQ-STA-01…RQ-STA-05). It also recomputes the trial budget per cell, decides the adaptation policy (RQ-RSK-08) and delivers the parameter register. Part 5/10 follows with data classes, the universe, the envelope and topology fit. No earlier identifier is redefined here.

## 4.0 Scope and fidelity notes (read first)

1. **Every strategy statement is NOT TESTED.** No performance figure appears. Cost inputs come from the hypothetical scenario HS-1 (Part 3) and are not venue facts. Nothing here says a strategy is achievable.
2. **Statistical formulas are recalled, not externally verified in this engagement** (Part 1: no external access). They assume independent, approximately Gaussian returns, so the floors below are optimistic when returns are fat-tailed or autocorrelated. §4.4 adds a stress multiplier ν for this.
3. **Hand arithmetic.** Normal quantiles come from standard tables at 3–4 decimals. Results are rounded as shown. The expected maximum of N trials uses the two-quantile Euler-constant approximation, which differs from exact expected maxima by a few percent at small N (recalled).
4. **C20, C21 and C23 are not reproduced.** Their inputs are unstated in the carried summary. C20 (DSR about 1.5e-2 at N = 100) is cited only with its N. C21 (MinTRL 19.54 years) is kept distinct from MinBTL (SF-3 versus SF-4). C23's anchors justify no decision (§4.5.7).
5. **Pre-registration set values are PROVISIONAL.** Sets such as {3 h, 6 h, 12 h} give the search a computable count structure. They are not tuned to any data.
6. **Owner-proposed adaptation concepts** are not enumerated in the carried summary. §4.8 therefore gives the rules by which any such concept is evaluated (A12: candidates only).

## 4.1 Derivation of "intraday" and its holding bound (RQ-OWN-05)

Catalog **IV** (derivation steps). Label: DERIVED from A6, A3, HG-2, DQ-1 and UEF-4, except where marked.

| ID | Step | Statement | Basis |
|---|---|---|---|
| IV-1 | Inputs | A6 requires intraday intent. A3 fixes UTC days. Daily loss is measured per UTC day (RQ-RSK-05, FM-13). Exposure while the operator is unreachable should be bounded (DQ-1, A9). The funding interval Δ_f is unknown (UEF-4). | A3, A6, DQ-1 |
| IV-2 | Definition | A position is **intraday** if and only if its entry and exit fall in the same UTC calendar day. | A6 + A3 |
| IV-3 | Flat deadline | t_flat(D) = 24:00 UTC of day D minus τ_exit. The exit sequence begins at t_flat. τ_exit is symbolic. It must be at least the bounded retry window (Part 7) plus one reconciliation cycle, so that a risk-reducing exit can complete before the boundary (PR-21). | HG-5, §9.7 |
| IV-4 | Maximum holding duration | For entry time t_e on day D: T_max(t_e) = t_flat(D) − t_e. The universe-wide bound is T_max ≤ 24 h − τ_exit. A strategy time-stop T_s may be shorter, never longer. | IV-2, IV-3 |
| IV-5 | Admitted trading intervals | A bar interval b can drive entries only if one full bar fits before the deadline: b + δ_bar + τ_exit ≤ 24 h, where δ_bar is the measured post-close usability delay (UEF-5, PR-20). Hence 1d, 1w and 1M cannot drive intraday entries, because b = 24 h violates the inequality. Intervals ≤ 12 h pass whenever δ_bar + τ_exit ≤ 12 h. Closed 1d/1w/1M bars may serve as context features (FT-5). | IV-4 |
| IV-6 | Entry cutoff | A new entry is allowed only if T_max(t_e) ≥ b + δ_bar. The strategy then has at least one subsequent decision point before the deadline. | IV-5 |

**Consequences (DERIVED).**

- **Daily accounting.** If every position is flat at 00:00 UTC, E_open in FM-13 equals realized equity. A non-flat state at 00:00 UTC is a failure case, handled in Part 7.
- **Funding count.** The settlement count obeys k_max ≤ ceil(24 h/Δ_f), by FM-6 with T_h < 24 h.

| Δ_f (hypothetical, UEF-4 unknown) | 1 h | 4 h | 8 h |
|---|---|---|---|
| k_max upper bound | 24 | 6 | 3 |

- **Funding scale against the stop.** At the adverse stress magnitude of 30 bp per settlement (C7) and k_max = 3, the funding stress is 90 bp. For HS-1 (stop distance 100 bp) that is 90% of the stop distance. Funding is a sizing stress, not an expectation. This is why the holding bound is derived and not left open.
- **Exposure while unreachable (OCL-1).** The bound IV-4 caps how long a locally automated strategy intends to hold. If the process is also down (OCL-4), only exchange-resident stops protect the position. That is Part 7 territory (RX-2).

## 4.2 Information needs and features (XC-7a)

**Candles only.** The first-candidate information set is OHLCV candles from Toobit (C19 data shape). The positive reasons are the smallest data envelope, the best-measured source, and no dependence on unreproducible or conflicted fields: order-book depth is NON_REPRODUCIBLE (C8), markPrice/klines.change is CONFLICTED (C13), historical open interest is UNRESOLVED (C26), and user-data push is unverified (UEF-7).

Catalog **FT** (features):

| ID | Feature | Definition (closed bars only, BC-1) |
|---|---|---|
| FT-1 | Bar log return | r_t = ln(C_t/C_{t−1}) |
| FT-2 | Bar volatility | σ_bar,t = sample standard deviation of r over the trailing w_σ bars (PR-18) |
| FT-3 | UTC-day anchor | A_t = Σ(tp_i·v_i)/Σ v_i over bars i of the current UTC day up to t, with tp = (H+L+C)/3. This is a candle-based VWAP approximation, not tick VWAP. |
| FT-4 | Friction ratio | ρ_t = cost_rt/(σ_bar,t·C_t), where cost_rt is the round-trip friction in price units, from FM-8 terms excluding the stop distance and funding |
| FT-5 | Closed-bar context | Previous UTC day's closed range and close from the 1d bar. Available at day start, so no look-ahead. |

**Excluded inputs:** order-book features, open interest, any use of the markPrice/klines.change field, and cross-venue data on any Live or Paper path (OD-2 open, RQ-OWN-04).

**Hand-off to Part 5 (envelope parameters).** Part 5 receives these inputs:

- Admitted candidate intervals: 15m, 30m, 1h, 2h, 4h and 6h (SC-1 and SC-2 only). 1d is context. Raw-interval storage at 1m, 3m and 5m is not needed by SC-1 or SC-2. Execution-quality measurement may still want it (decided in Part 5).
- Bars per year P(b) = 365·24 h/b: 15m 35,040; 30m 17,520; 1h 8,760; 2h 4,380; 4h 2,190; 6h 1,460; 1d 365.
- Retention horizon per cell = the evidence-time function in §4.5.5.
- Symbol count n and the correlation ρ̄ remain parameters (PR-28).

## 4.3 Candidate strategies (RQ-STA-01) and backtest conventions

### 4.3.1 Candidates

Catalog **SC**. Evidence status of both candidates: **NOT TESTED**. Neither is claimed to be profitable or achievable. Either may fail, and the plan in §4.4–4.7 is how that is found out.

| Item | SC-1 Volatility-scaled momentum | SC-2 Reversion to the UTC-day anchor |
|---|---|---|
| Hypothesis (H0 is zero net mean) | The sign of the trailing return over horizon H, normalized by volatility, predicts the sign of the next holding-period return after costs. | A deviation from the UTC-day anchor beyond θ bar-volatilities reverts toward the anchor within the day, after costs. |
| Decision time | Each closed bar of interval b, at t_close + δ_bar (UEF-5). | Same. |
| Signal | z = ln(C_t/C_{t−ℓ})/(σ_bar·√ℓ) with ℓ = H/b (integer ≥ 2). Long if z > 0, short if z < 0. | z_a = ln(C_t/A_t)/σ_bar. Long if z_a ≤ −θ, short if z_a ≥ θ. Not before n_anchor_min bars of the day exist (PR-19). |
| Admission gate | Friction ratio gate: enter only if ρ_t ≤ 1/c_g. | Same. |
| Entry order | Passive limit at the near side of the book at decision time, cancelled at the end of the next bar. No chase and no re-quote. | Same. |
| Stop | Exchange-resident. d_ref = k_s·σ_bar·P_ref, rounded outward to the tick grid (FM-7). | Same. |
| Other exits | A sign flip at a bar close (flatten only). The flat deadline t_flat (IV-3). | Target = anchor value at entry, a profit-taking resting limit. Its non-fill is harmless because the stop and the deadline remain. The flat deadline. |
| Sizing and leverage | Strategy emits side, stop price and reference price only. Quantity, leverage and refusals come from the sizing function (FM-9, §3.8). The strategy never writes risk state. | Same. |
| Applicable intervals | b where ℓ = H/b is an integer ≥ 2 for at least one H: 15m, 30m, 1h, 2h, 4h, 6h. | b ≤ 4 h (at least 6 bars per UTC day, so the anchor is meaningful): 15m, 30m, 1h, 2h, 4h. |
| Evidence label | DESIGN_JUDGMENT (choice); NOT TESTED (performance) | DESIGN_JUDGMENT (choice); NOT TESTED (performance) |

**Why these two (positive reasons).** Both use only candles and fit the smallest measured data shape. They are single-instrument, which avoids cross-symbol margin coupling (UEF-2) and multiplied per-leg fees against small capital (CF-5). Their exits satisfy the intraday bound. They have opposite regime exposure, so evidence on both informs later diversification questions. Criterion: CR-6, then CR-5.

**Alternatives not selected as first candidates, each with its unmet prerequisite.** None is declared impossible (§8.0: rigor does not preemptively reject). Reversibility: REVERSIBLE.

- **Cross-sectional ranking.** It needs synchronized multi-symbol data and many legs. Each leg adds fees and minimum-notional demands against equity that is small (CF-5, UEF-3).
- **Microstructure or order-book strategies.** The book is NON_REPRODUCIBLE (C8) and push streams are unverified (UEF-7).
- **Funding-carry.** The funding formula is unknown (UEF-4) and the holding exceeds the intraday bound.
- **Cross-venue strategies.** A5 forbids research-only data on Live paths, and cross-venue transfer is defensible only at 1h/4h (C18).

### 4.3.2 Backtest conventions

Catalog **BC**. Label: DESIGN_JUDGMENT, each chosen to bias against the strategy where information is missing (CR-1, then CR-2).

| ID | Convention |
|---|---|
| BC-1 | A feature at bar t uses bars ≤ t only. A decision is taken at t_close + δ_bar. Bars flagged as gaps (UEF-12) are excluded and the decision is skipped. |
| BC-2 | If a stop and any other exit lie inside one bar, the stop is assumed first. |
| BC-3 | Passive entry fills only if the next bar trades through the limit by at least one tick (low ≤ p − tick for buys, high ≥ p + tick for sells), at price p. A touch earns no fill. Unfilled orders expire after one bar. Both fill and non-fill are recorded. |
| BC-4 | Stop exits fill at P_s − s·σ_x. If a bar opens beyond P_s, the fill is the open minus s·σ_x. Fee f_out per PR-11. |
| BC-5 | Funding is reported as a function of a backtest funding sensitivity φ_bt (PR-34), including φ_bt = 0 as a labeled bound, never as a silent zero. Realized funding history is used only if its availability is established (UEF-4). |
| BC-6 | Results are expressed in R-multiples (net P&L per trade divided by the sized budget B). Sharpe is computed on the bar-by-bar R series and annualized with P(b) periods per year. This makes results independent of OD-1 values. Lot-rounding and minimum-lot effects are analyzed separately through the admission analysis (WE-17 pattern). |
| BC-7 | Every dataset and result carries its source tag (Toobit-native or cross-venue). Results from cross-venue-tagged data can inform screening only and never promote beyond research (RQ-OWN-04). |

**DQ-3 disposition (maker-only floor, non-fill and adverse selection).** BC-3 and BC-4 are the conservative treatment. Expected net per signal equals p_fill × E[net | fill], and adverse selection means E[net | fill] can be below E[net | signal]. Paper mode must therefore record p_fill and net-per-fill separately from net-per-signal. Status: DISPOSITION SET; the quantity is measurable only in Paper (VM-5).

## 4.4 Statistical framework

**Unit convention (unit-consistent, DV-1 aligned).** Y is in years, Y = days/365. Annualized Sharpe uses P(b) = 365·24 h/b periods per year. With T = P·Y observations, the per-period standard error is 1/√T, so the annualized standard error is √P/√(PY) = 1/√Y, independent of b.

Catalog **SF** (DERIVED under the stated assumptions; recalled forms, not externally verified):

| ID | Formula | Meaning and assumptions |
|---|---|---|
| SF-1 | SR*(N, Y) = ν·M(N)/√Y, with M(N) = (1−γ_E)·Φ⁻¹(1−1/N) + γ_E·Φ⁻¹(1−1/(N·e)), γ_E = 0.57722, N ≥ 2 | Annualized net Sharpe that the best of N noise configurations is expected to reach by chance. Assumes independent trials, zero true Sharpe, and standard error ν/√Y. An in-sample Sharpe at or below SR* is no evidence. |
| SF-2 | ν = √(1 − γ₃·SR + ((γ₄−1)/4)·SR²) | Non-normality stress multiplier (recalled; γ₃ skewness, γ₄ kurtosis). At SR = 1, γ₃ = 0: ν = 1.2247 for γ₄ = 3 and ν = 1.8028 for γ₄ = 10. Tables below use ν = 1 (the optimistic bound). |
| SF-3 | Y_BTL(N, s) = (ν·M(N)/s)² | Minimum backtest-length analog (MinBTL-type): years of development data needed so that N trials' noise floor falls to s. |
| SF-4 | Y_TRL(s; α, β, K) = (ν·(z_{1−α/K} + z_{1−β})/s)² | Minimum track-record analog (MinTRL-type, simplified): years to confirm true Sharpe s with one-sided size α/K and power 1−β. It omits the skew and kurtosis terms of the full formula. It is a different quantity from SF-3 and from C21. |
| SF-5 | s_det = ν·(z_{1−α/K} + z_{1−β})/√Y_h | Smallest true annualized Sharpe detectable on a holdout of Y_h years. |
| SF-6 | N_eff,sym = n/(1+(n−1)·ρ̄) | Effective independent bets across n symbols with mean pairwise correlation ρ̄. Reported only. It never enlarges a budget (§4.5.2). |
| SF-7 | α*(t) = 2·[1 − Φ(z_{1−α/2}/√t)], information fraction t = Y_obs/Y_plan | Cumulative alpha spent at look t (Lan–DeMets O'Brien–Fleming-type, recalled). α*(1) = α. |
| SF-8 | Stationary block bootstrap with block length ℓ_blk (PR-27) for confidence intervals on net Sharpe | Block length at least the typical holding duration in bars. |

**Reference quantiles and M(N)** (hand lookups, ±1 in the last digit):

| N | Φ⁻¹(1−1/N) | Φ⁻¹(1−1/(Ne)) | M(N) |
|---|---|---|---|
| 6 | 0.9674 | 1.5439 | 1.3002 |
| 10 | 1.2816 | 1.7893 | 1.5746 |
| 12 | 1.3830 | 1.8712 | 1.6648 |
| 18 | 1.5933 | 2.0448 | 1.8539 |
| 20 | 1.6449 | 2.0881 | 1.9007 |
| 100 | 2.3263 | 2.6801 | 2.5305 |
| 1,000 | 3.0902 | 3.376 | 3.2552 |

Working values for α, β: z_{0.95} = 1.6449 and z_{0.80} = 0.8416, so (z_α + z_β) = 2.4865 and its square is 6.1827 (both PROVISIONAL conventions, PR-22 and PR-23).

**Effective bets across symbols (SF-6), computed by hand:**

| n \ ρ̄ | 0.3 | 0.5 | 0.7 | 0.9 |
|---|---|---|---|---|
| 5 | 2.273 | 1.667 | 1.316 | 1.087 |
| 20 | 2.985 | 1.905 | 1.399 | 1.105 |
| 134 | 3.276 | 1.985 | 1.424 | 1.110 |

The n = 134 row uses the C9 snapshot count as a sample point only. It is not a universe (RQ-DAT-02). Even at ρ̄ = 0.5, the benefit is under 2× independent bets, and it assumes an equal edge across symbols. The budget therefore ignores it.

**Alpha spending (SF-7), α = 0.05:**

| t | 0.25 | 0.5 | 0.75 | 1.0 |
|---|---|---|---|---|
| α*(t), cumulative | 9e-5 | 0.0056 | 0.024 | 0.050 |

## 4.5 Trial budget, recomputed per cell (RQ-STA-02)

### 4.5.1 Planned configurations per cell (the pre-registered family)

A **cell** is (candidate, interval). Pre-registered sets (PROVISIONAL values; structure DERIVED):

- Horizon H ∈ {3 h, 6 h, 12 h}, usable only if ℓ = H/b is an integer ≥ 2.
- Stop multiple k_s ∈ {1.0, 1.5, 2.0}.
- Gate multiple c_g ∈ {2, 3}.
- For SC-2, θ ∈ {1.5, 2.0, 2.5} replaces H.

| Interval | Usable H (count) | SC-1 N_cell = count × 3 × 2 | SC-2 N_cell = 3 × 3 × 2 |
|---|---|---|---|
| 15m | 3 | 18 | 18 |
| 30m | 3 | 18 | 18 |
| 1h | 3 (ℓ = 3, 6, 12) | 18 | 18 |
| 2h | 2 (6 h, 12 h) | 12 | 18 |
| 4h | 1 (12 h) | 6 | 18 |
| 6h | 1 (12 h) | 6 | n/a (b > 4 h) |
| 8h, 12h | 0 | n/a | n/a |

**Family size:** SC-1 = 18+18+18+12+6+6 = 78. SC-2 = 18×5 = 90. Total = 168 configurations. Selection is within a cell. Choosing which cells to promote is a second selection layer, controlled by the Bonferroni division by K in SF-4 and SF-5 (§4.6, SD-5).

### 4.5.2 Noise floor by N and depth (SF-1, ν = 1, native cap depth from DV-1, no holdout)

| Interval (Y years, √Y) | N = 6 | N = 10 | N = 18 | N = 100 | N = 1,000 |
|---|---|---|---|---|---|
| 15m (0.0999, 0.3161) | 4.11 | 4.98 | 5.87 | 8.01 | 10.30 |
| 30m (0.1998, 0.4470) | 2.91 | 3.52 | 4.15 | 5.66 | 7.28 |
| 1h (0.3995, 0.6321) | 2.06 | 2.49 | 2.93 | 4.00 | 5.15 |
| 2h (0.7991, 0.8939) | 1.45 | 1.76 | 2.07 | 2.83 | 3.64 |
| 4h (1.598, 1.264) | 1.03 | 1.25 | 1.47 | 2.00 | 2.57 |
| 6h (2.397, 1.548) | 0.84 | 1.02 | 1.20 | 1.63 | 2.10 |
| 8h (3.196, 1.788) | 0.73 | 0.88 | 1.04 | 1.42 | 1.82 |
| 12h (4.795, 2.190) | 0.59 | 0.72 | 0.85 | 1.16 | 1.49 |
| 1d reference (9.589, 3.097) | 0.42 | 0.51 | 0.60 | 0.82 | 1.05 |
| 1d at 1,774 bars (4.860, 2.205) | 0.59 | 0.71 | 0.84 | 1.15 | 1.48 |

Entries are annualized Sharpe. At N = 6, the 1m, 3m and 5m depths give floors of 15.93, 9.20 and 7.13. Examples of the arithmetic: 4h, N = 10: 1.5746/1.2642 = 1.2455. 1d at cap, N = 1,000: 3.2552/3.0966 = 1.0512.

### 4.5.3 Per-cell floor at the planned N_cell (full depth, and development-only with holdout fraction h = 0.3)

Development-only multiplies the floor by 1/√(1−h) = 1/√0.7 = 1.1952.

| Cell | N_cell | Floor, full native depth | Floor, development part only |
|---|---|---|---|
| SC-1 15m | 18 | 5.87 | 7.01 |
| SC-1 30m | 18 | 4.15 | 4.96 |
| SC-1 1h | 18 | 2.93 | 3.51 |
| SC-1 2h | 12 | 1.86 | 2.23 |
| SC-1 4h | 6 | 1.03 | 1.23 |
| SC-1 6h | 6 | 0.84 | 1.00 |
| SC-2 15m | 18 | 5.87 | 7.01 |
| SC-2 30m | 18 | 4.15 | 4.96 |
| SC-2 1h | 18 | 2.93 | 3.51 |
| SC-2 2h | 18 | 2.07 | 2.48 |
| SC-2 4h | 18 | 1.47 | 1.75 |

**Reading (D19-consistent).** A cell whose floor exceeds any economically relevant Sharpe is **NOT ASSESSABLE at native depth** (ES-1). It is not rejected and not declared unprofitable. It needs forward accumulation (§4.5.5). The selection rule uses SR*(N_cell, Y_dev) as the screen. No fixed Sharpe cutoff is borrowed from the C23 anchors.

### 4.5.4 Holdout detectability (SF-5, α = 0.05, K = 1, β = 0.2, h = 0.3, ν = 1)

| Interval | Y_h = 0.3·Y (years) | s_det (annualized Sharpe) |
|---|---|---|
| 1h | 0.1199 | 7.18 |
| 2h | 0.2397 | 5.08 |
| 4h | 0.4795 | 3.59 |
| 6h | 0.7192 | 2.93 |
| 12h | 1.4384 | 2.07 |
| 1d reference | 2.8767 | 1.47 |

**Consequence (CF-3, numeric).** On native Toobit depth, a holdout at 1h–6h can confirm only very large true Sharpe ratios. A holdout therefore cannot be the only confirmation. Evidence has to come from forward accumulation and Paper-mode sequential testing (SD-4).

**Multiple cells.** If K = 3 cells reach the holdout, α/K = 0.0167 and z = 2.128. Then (z + 0.8416) = 2.9696, which is 1.194× the K = 1 value. At s = 1.5, Y_TRL rises from 2.748 to 3.919 years ((2.9696/1.5)² = 3.9193).

### 4.5.5 Evidence time (development screen plus confirmation, α = 0.05, β = 0.2, K = 1, ν = 1)

Y_total = Y_BTL(N, s) + Y_TRL(s). Years of forward-accumulated data are the same units as DV-1 depth.

| N | s = 1.0 | s = 1.5 | s = 2.0 |
|---|---|---|---|
| 6: Y_BTL / Y_TRL / sum | 1.691 / 6.183 / 7.873 | 0.751 / 2.748 / 3.499 | 0.423 / 1.546 / 1.968 |
| 12: Y_BTL / Y_TRL / sum | 2.772 / 6.183 / 8.954 | 1.232 / 2.748 / 3.980 | 0.693 / 1.546 / 2.239 |
| 18: Y_BTL / Y_TRL / sum | 3.437 / 6.183 / 9.620 | 1.527 / 2.748 / 4.275 | 0.859 / 1.546 / 2.405 |

For s = 0.5 and N = 18 the sum would be 13.748 + 24.731 = 38.479 years. Arithmetic example: (1.8539/1.5)² = 1.5275, and 2.4865²/1.5² = 6.1827/2.25 = 2.7479.

**This is a time-to-evidence function, not a Live hurdle.** It determines when a cell's evidence label can change (§4.7). It is not a waiting period for the selector (A10, RX-4).

**C21 consistency check, not a reconstruction.** Under these α and β, SF-4 yields 19.54 years at s = 2.4865/√19.54 = 0.5625. C21's inputs are unstated, so this value is arithmetic only and nothing is concluded from it.

### 4.5.6 Cross-venue history (conditional on OD-2, 1h and 4h only, C18)

Y = 2,389/365 = 6.545 years (57,336 hourly bars or 14,334 4h bars), √Y = 2.558. Floors at ν = 1: N = 6: 0.51; N = 18: 0.72; N = 100: 0.99. Holdout (h = 0.3, Y_h = 1.964, √ = 1.401) gives s_det = 1.77. Use is restricted to **screening**. Costs, fills and funding are Toobit-specific, so promotion to Paper requires Toobit-native evidence (BC-7). Status: CONDITIONAL (OD-2).

### 4.5.7 Reconciliation of C23 and C22

- **Published anchors (PROVISIONAL, inputs unstated).** "10–20 at 4h" and "thousands at 1d."
- **Recomputation at native cap depth.** At 4h, floors of 1.25 (N = 10) and 1.50 (N = 20) mean the anchors correspond to a target annualized Sharpe of about 1.25–1.50. At 1d, floors of 1.05 (N = 1,000) and 1.25 (N = 10,000) correspond to about 1.05–1.25. The ratio of N_max for a different target Sharpe is not bounded by 2×. For example, at 4h with target 1.0, the N = 6 floor of 1.03 already exceeds the target, so N_max is under 6.
- **Rule (C22).** N_max_effective(cell, s) = min(published, recomputed). Where the published inputs are unstated, only the recomputed function drives any decision, and no decision depends on a published anchor. That is the effective meaning of "recomputed governs."
- **The cell's planned N must satisfy N_cell ≤ N_max(cell, s_min).** The pre-registration check is: SR*(N_cell, Y_dev) ≤ s_min. Otherwise the cell is ES-1.

### 4.5.8 Net feasibility after costs (RQ-STA-05, parametric)

Round-trip friction at a stop-out (price-fee-slippage, excluding funding and stop distance), from the HS-1 inputs (σ_e = 1 bp, σ_x = 5 bp of P_ref):

| Branch (Part 3 WE-20) | Fees (bp) | Slippage (bp) | cost_rt (bp) |
|---|---|---|---|
| c. Maker entry, f_in = 0, taker exit 0.06% | 6 | 5 | 11 |
| d. Maker entry 0.02%, taker exit 0.06% | 8 | 5 | 13 |
| b. Taker both legs 0.05% | 10 | 6 | 16 |
| a. Taker both legs 0.06% | 12 | 6 | 18 |

**Friction ratio ρ = cost_rt/σ_bar across bar volatility (hypothetical σ_bar values):**

| σ_bar (bp) | c (11) | d (13) | b (16) | a (18) |
|---|---|---|---|---|
| 10 | 1.10 | 1.30 | 1.60 | 1.80 |
| 20 | 0.55 | 0.65 | 0.80 | 0.90 |
| 40 | 0.275 | 0.325 | 0.400 | 0.450 |
| 80 | 0.1375 | 0.1625 | 0.200 | 0.225 |

The gate ρ ≤ 1/c_g opens at σ_bar ≥ c_g·cost_rt: for c_g = 2 and 3, branch c opens at 22 and 33 bp, branch d at 26 and 39 bp, branch b at 32 and 48 bp, and branch a at 36 and 54 bp. With Part 3 WE-18, this shows costs and break-even as functions. It gives no expected result.

## 4.6 Search-design declaration (RQ-STA-03)

The chosen design combines three of the allowed alternatives: a **pre-registered small set**, **staged screening with a holdout**, and **sequential testing with alpha spending**. No exhaustive grid is used, and the largest cell has 18 configurations at ≤ 12 h.

Catalog **SD** (the seven required declarations):

| ID | Declaration | Content |
|---|---|---|
| SD-1 | Searched configurations | The 168-configuration family of §4.5.1, counted per cell. No other parameter is searched. Every other parameter is design-fixed (§4.9). Each configuration is evaluated once on the development segment. |
| SD-2 | Effective sample size | Time-based: Y_dev = (1−h)·Y_cell years and Y_h = h·Y_cell years, plus the realized trade count. N_eff,sym (SF-6) is reported but never used to enlarge a budget. |
| SD-3 | Assumptions | Floors use SF-1 with independent trials and Gaussian returns. N counts every configuration (conservative, since correlated configurations reduce the true count). The stress ν ≥ 1 and the block bootstrap (SF-8) are reported with every result. Backtest conventions BC-1…BC-7 apply. |
| SD-4 | Stopping rule | Development: evaluate all N_cell once, with no interim peeking and no early stop on a favorable interim. Holdout: one-shot per cell, never re-run. Paper: sequential looks at t = Y_obs/Y_plan with the SF-7 boundary, where Y_plan = Y_TRL(s_min). Stop for success when the statistic crosses the boundary. Stop for futility when the upper (1−β) confidence bound on net Sharpe is below s_min. Otherwise stop at t = 1 with the label set by §4.7. |
| SD-5 | Selection-bias control | Pre-registration of hypotheses, sets, metric, α, h, s_min and K, recorded as a content hash before data access (config integrity interlock, Part 8). The SF-1 floor is applied to the development Sharpe. The embargo between segments is E_b = ceil((H_max + T_max)/b) bars. A holdout is used with Bonferroni across the K cells promoted. A placebo is run: N_pl random-entry replicates matched to signal frequency and holding distribution. A candidate's holdout net Sharpe must also exceed the (1−α) placebo quantile. |
| SD-6 | Promotion policy | Research → Paper requires the development screen (SR_dev ≥ max(s_min, SR*(N_cell, Y_dev))) and holdout success on Toobit-native data. Paper → PAPER-CONFIRMED requires the sequential boundary. The Paper/Live selector is separate and has no evidence hurdle (A10, RX-4). It discloses the ES label. |
| SD-7 | Rollback policy | A frozen configuration version is the only unit of deployment. If a sequential futility or harm rule trips, or an interlock fails, the strategy self-halts (a non-increasing-exposure action). Re-enabling it needs an operator command. A prior frozen version is restored only by a config change that passes the integrity interlock. Rollback never changes a hard limit (RQ-RSK-08). |

## 4.7 Strategy evidence-status labels (ES)

Catalog **ES**. These labels are what a status display shows (RX-4). They are descriptive of evidence, not gates.

| ID | Label | Meaning |
|---|---|---|
| ES-0 | NOT TESTED | No calculation has been run. |
| ES-1 | NOT ASSESSABLE | Depth is insufficient: SR*(N_cell, Y_dev) exceeds any economically relevant s_min. This is not evidence against. |
| ES-2 | NO EVIDENCE YET | Assessed, with insufficient evidence for or against. |
| ES-3 | EVIDENCE AGAINST | The upper (1−β) bound on net Sharpe is below s_min, with enough depth to say so. |
| ES-4 | PROMOTED TO PAPER | Development screen and holdout passed (SD-6). |
| ES-5 | PAPER-CONFIRMED | The sequential boundary was crossed in Paper. |

Both SC-1 and SC-2 start at ES-0.

## 4.8 Adaptation policy (RQ-RSK-08, §9.10, §8.5)

**Decision: zero online adaptation of strategy parameters and of risk parameters in the baseline design.** Changes happen only by offline, versioned, pre-registered recalibration (AD-2).

Catalog **AD**:

| ID | Rule |
|---|---|
| AD-1 | No online adaptation of strategy parameters. Deterministic data-driven quantities (for example the rolling σ_bar) are features, not adaptation, because their rule is fixed. |
| AD-2 | Offline recalibration produces a new frozen configuration version. The new trials add to the cumulative count N_cum, which feeds SF-1 on any reused data. The budget does not reset. |
| AD-3 | No adaptive element, optimizer or strategy component has a write path to an AC-0 parameter or to risk state. The write-path absence is specified in Part 6 and checked in Part 9. |
| AD-4 | Protective model parameters (σ_x, φ_stress, fee branch, κ) may be recalibrated offline, but never below their floors (§4.9). |
| AD-5 | An owner-proposed adaptation concept is evaluated against AD-1…AD-4 plus trial accounting. It is a candidate only (A12). |

**Positive reasons for zero online adaptation.** First, the trial budget cannot support repeated refitting: each refit adds trials and raises the floor (§4.5.2). Second, any online write path is a path that could relax a hard limit (RQ-RSK-08; CR-1). Third, a frozen version makes Paper evidence attributable to one configuration (CR-2, CR-5). Reversibility: REVERSIBLE. Adaptation can be added later by CA-2 with a recorded decision and AD-1…AD-4 compliance.

## 4.9 Parameter register

### 4.9.1 Adaptation classes

Catalog **AC**:

| ID | Class | Rule |
|---|---|---|
| AC-0 | OWNER_LIMIT | Set only by the owner (CA-1). No other write path. Unknown → RF-1. |
| AC-1 | DESIGN_FIXED | Fixed by design decision. Change by CA-2 record. |
| AC-2 | CALIBRATED_OFFLINE | Re-estimated offline and applied only as a versioned config under the integrity interlock. Floors apply (AD-4). |
| AC-3 | SEARCHED | Member of a pre-registered set (SD-1). Fixed per promoted config version. |
| AC-4 | RUNTIME_STATE | Computed per decision or cycle. Not a parameter. No optimizer write path. |
| AC-5 | VENUE_FACT | Read from the venue. Unknown → refusal (RQ-DAT-04). |

### 4.9.2 Register

Catalog **PR**. Labels: OWNER_DECISION_PENDING, PROVISIONAL, DESIGN_JUDGMENT, DERIVED or UNRESOLVED as shown. "Authority" is the change authority (CA).

| ID | Symbol | Meaning (unit) | Domain or derivation | Label | AC | Authority |
|---|---|---|---|---|---|---|
| PR-1 | A_cap | Aggregate concurrent-risk limit (USDT) | ≥ 0; set by OD-1 | OWNER_DECISION_PENDING | AC-0 | CA-1 |
| PR-2 | D_day | Daily loss limit (USDT) | ≥ 0; set by OD-1 | OWNER_DECISION_PENDING | AC-0 | CA-1 |
| PR-3 | DD_max | Peak-to-trough drawdown limit (fraction) | (0,1); set by OD-1 | OWNER_DECISION_PENDING | AC-0 | CA-1 |
| PR-4 | L_cap | Leverage cap (none) | ≥ 1; set by OD-1; also bounded by venue tier (C3, UNRESOLVED) | OWNER_DECISION_PENDING | AC-0 | CA-1 |
| PR-5 | r, basis | Per-trade budget fraction and equity basis (E_w or E_mtm) | r ∈ (0,1); set by OD-1 | OWNER_DECISION_PENDING | AC-0 | CA-1 |
| PR-6 | κ | Stop-before-liquidation factor (none) | ≥ 1. Raising allowed by CA-2. Lowering below the recorded design value is a loosening, so CA-1. | PROVISIONAL | AC-1 | CA-2 / CA-1 |
| PR-7 | σ_x | Stop-exit slippage allowance incl. gap allowance (fraction of P) | ≥ σ_x,floor (half-spread plus a measured adverse-exit quantile, measured in Paper) | PROVISIONAL | AC-2 | CA-2 |
| PR-8 | σ_e | Entry slippage (fraction of P) | Taker: ≥ observed half-spread. Maker backtest: 0 under BC-3 only. | PROVISIONAL | AC-2 | CA-2 |
| PR-9 | φ_stress | Funding stress magnitude per settlement (fraction) | ≥ 30 bp (the largest adverse magnitude observed in C7), no cap (C7 refutes ±24 bp) | PROVISIONAL | AC-2 | CA-2 |
| PR-10 | mmr | Maintenance margin rate used by the generic liquidation model (fraction) | ≥ venue value once known (UEF-11). Unknown → RF-1. | UNRESOLVED | AC-5 | CA-3 |
| PR-11 | f_in, f_out | Fee rates, entry and exit (fraction) | Model value ≥ the conservative branch 0.0006 unless a verified schedule is lower (C6, UEF-10); maker value is a stated range | PROVISIONAL | AC-2 | CA-2 |
| PR-12 | μ_res | Margin reserve (fraction of available margin) used in §3.8.1 step 5 | [0,1); the design value is set at implementation and may only be raised | DESIGN_JUDGMENT | AC-1 | CA-2 |
| PR-13 | m, λ, q_min, N_min, tick, Δ_f | Contract multiplier, lot increment, minimum quantity, minimum notional, tick size, funding interval | Read from the venue per symbol | UNRESOLVED (UEF-3, UEF-4) | AC-5 | CA-3 |
| PR-14 | H | SC-1 lookback horizon (hours) | {3, 6, 12}, with H/b an integer ≥ 2 | PROVISIONAL | AC-3 | CA-2 |
| PR-15 | k_s | Stop multiple (σ_bar units) | {1.0, 1.5, 2.0} | PROVISIONAL | AC-3 | CA-2 |
| PR-16 | c_g | Friction-gate multiple (none) | {2, 3} | PROVISIONAL | AC-3 | CA-2 |
| PR-17 | θ | SC-2 deviation threshold (σ_bar units) | {1.5, 2.0, 2.5} | PROVISIONAL | AC-3 | CA-2 |
| PR-18 | w_σ | Volatility window (bars) | max(20, 24 h/b) | PROVISIONAL | AC-1 | CA-2 |
| PR-19 | n_anchor_min | Minimum bars of the UTC day before SC-2 may trade | 3 | PROVISIONAL | AC-1 | CA-2 |
| PR-20 | δ_bar | Post-close usability delay (seconds) | Measured (UEF-5); until measured, entries are refused | UNRESOLVED | AC-2 | CA-3 |
| PR-21 | τ_exit | Exit-sequence time reserve before UTC midnight (seconds) | ≥ W_retry + one reconciliation cycle (Part 7) | DERIVED | AC-1 | CA-2 |
| PR-22 | α | Overall test size | (0, 0.5); working value 0.05 (conventional, recalled) | PROVISIONAL | AC-1 | CA-2 |
| PR-23 | β | Type-II error | (0, 0.5); working value 0.2 | PROVISIONAL | AC-1 | CA-2 |
| PR-24 | h | Holdout fraction | (0, 0.5); working value 0.3 | PROVISIONAL | AC-1 | CA-2 |
| PR-25 | s_min | Minimum relevant net annualized Sharpe | > 0; pre-registered per cell before analysis; no default | UNRESOLVED | AC-1 | CA-2 |
| PR-26 | ν | Non-normality stress multiplier | ≥ 1; tables at 1; sensitivity 1.22 and 1.80 (SF-2) | PROVISIONAL | AC-1 | CA-2 |
| PR-27 | ℓ_blk, E_b | Bootstrap block length (bars); embargo (bars) | ℓ_blk ≥ holding duration in bars; E_b = ceil((H_max + T_max)/b) | DERIVED | AC-1 | CA-3 |
| PR-28 | ρ̄ | Mean pairwise symbol correlation | Measured; unknown until computed | UNRESOLVED | AC-4 | none |
| PR-29 | τ_feed (with ε, z) | Data-staleness bound with open exposure (seconds) | τ_feed ≤ b·(ε·k_s/z)² (§4.9.3) | DERIVED | AC-1 | CA-2 |
| PR-30 | τ_venue (with b₀, n_max) | Venue-outage declaration after bounded retries (seconds) | τ_venue = W_retry = b₀·(2ⁿ − 1) (§4.9.3) | DERIVED | AC-1 | CA-2 |
| PR-31 | τ_proc (with h_p, m_miss) | Process-outage declaration time after last heartbeat (seconds) | τ_proc = m_miss·h_p (§4.9.3) | DERIVED | AC-1 | CA-2 |
| PR-32 | τ_clk (with ε_c, ω) | Clock-offset tolerance (seconds) | θ_max = ε_c·δ_bar with ε_c < 1, and θ_max < ω/2 if the venue enforces a timestamp window ω (unknown) | DERIVED | AC-1 | CA-2 |
| PR-33 | τ_op (τ_op,1 < τ_op,2) | Operator-silence thresholds: new-entry halt, then flatten trigger (seconds) | Ordering constraint only. Values as a function in Part 7. Independent of the C12 3-day value. | UNRESOLVED | AC-1 | CA-2, ratified via OD-4 |
| PR-34 | φ_bt | Backtest funding sensitivity per settlement (fraction) | Range including 0 as a labeled bound | PROVISIONAL | AC-1 | CA-3 |
| PR-35 | K | Number of cells promoted to the holdout | Integer, 1 ≤ K ≤ number of assessable cells; fixed at pre-registration | DERIVED | AC-1 | CA-2 |

### 4.9.3 Derivations for the τ parameters

**τ_feed.** During a blind period τ, the adverse price move is about z·σ_bar·√(τ/b). Require it to be at most ε times the stop distance d_ref = k_s·σ_bar. Then τ ≤ b·(ε·k_s/z)². Working values ε = 0.1 and z = 2 (PROVISIONAL).

| b | k_s = 1.0 | k_s = 1.5 | k_s = 2.0 |
|---|---|---|---|
| 900 s (15m) | 2.25 s | 5.06 s | 9.00 s |
| 3,600 s (1h) | 9.00 s | 20.25 s | 36.00 s |
| 14,400 s (4h) | 36.00 s | 81.00 s | 144.00 s |

Example: 14,400 × (0.1 × 1.5/2)² = 14,400 × 0.005625 = 81 s. The effective bound is the minimum over open positions and the entry check. If a derived value lies below the measured normal feed jitter, the system would trip falsely. In that case, reliance moves to exchange-resident exits and the value is re-set from Paper measurements (PROVISIONAL until then).

**Rejected alternative: a fixed fraction of the bar.** A fixed 500 bp of the bar gives 500 bp × 14,400 s = 0.05 × 14,400 = 720 s at 4h. That is 720/81 = 8.9× looser than the derived value at k_s = 1.5, and it ignores the stop distance. Reason for rejection: it is blind to the quantity the staleness exposes (CR-1). The same rule gives 180 s at 1h and 45 s at 15m.

**τ_venue.** Outage is declared only after bounded retries are exhausted. With base delay b₀ and doubling for n_max attempts, W_retry = b₀·(2ⁿ − 1). Ambiguous outcomes go to RECONCILING at once (HG-5) and do not wait for this timer.

| b₀ \ n_max | 3 | 4 | 5 | 6 |
|---|---|---|---|---|
| 0.25 s | 1.75 | 3.75 | 7.75 | 15.75 |
| 0.5 s | 3.5 | 7.5 | 15.5 | 31.5 |
| 1.0 s | 7 | 15 | 31 | 63 |

Values in seconds, shape only. Part 7 sets the retry bound.

**τ_proc.** A heartbeat every h_p seconds, with the process declared down after m_miss consecutive misses, gives τ_proc = m_miss·h_p.

| h_p \ m_miss | 2 | 3 | 5 |
|---|---|---|---|
| 1 s | 2 | 3 | 5 |
| 5 s | 10 | 15 | 25 |
| 15 s | 30 | 45 | 75 |

**τ_clk.** If the offset exceeded δ_bar, a bar that has not closed on the venue could be treated as closed (violating UEF-5). So θ_max < δ_bar is necessary, and the margin factor ε_c < 1 gives θ_max = ε_c·δ_bar. The formal behavior for fresh, stale, unknown and excessive offset is given in the timestamp catalog in Part 7 (RQ-OWN-03). Monotonic clocks govern all elapsed deadlines.

**τ_op.** Only constraints are set here, because the response table belongs to Part 7: 0 < τ_op,1 < τ_op,2, and every action at either threshold is non-increasing in exposure (RQ-TEL-02).

### 4.9.4 Symbol disposition (every symbol of §3.2)

| Class | Symbols | Register pointer |
|---|---|---|
| Owner limits (AC-0) | A_cap, D_day, DD_max, L_cap, r (B is the derived output B = r·E_basis) | PR-1…PR-5 |
| Model parameters | κ, σ_x, σ_e, φ_stress, mmr, f_in, f_out | PR-6…PR-11 |
| Venue facts (AC-5) | m, λ, q_min, N_min, Δ_f | PR-13 |
| Runtime state and outputs (AC-4, not parameters) | E, s, P_ref, P_e, P_s, P_x, g, d_ref, n, q, N, M, L, L_eff, φ, T_h, k_max, u, ℓ | Computed by the procedure in §3.8.1 and FM-1…FM-19. No optimizer write path. L is an output of §3.8.1 step 5. |

Count: 6 + 7 + 5 + 19 = 37 symbols, matching §3.2.

## 4.10 Decisions made in this Part

| Decision | Alternatives rejected, with positive reasons | Reversibility | Deciding criterion |
|---|---|---|---|
| Intraday = same UTC day, flat deadline t_flat | A fixed duration cap such as 8 h is an unsourced constant. Holding without a day limit breaks daily-accounting alignment (A3) and makes exposure unbounded while unreachable. A cut at the funding time needs Δ_f, which is unknown (UEF-4). | COSTLY_REVERSIBLE (it shapes the daily-loss accounting) | CR-1 |
| 1d/1w/1M as context only | A 1d bar needs b = 24 h, so one bar cannot fit before the deadline (IV-5) | REVERSIBLE | CR-1 |
| Candles-only first candidates | Book- or OI-based inputs rest on NON_REPRODUCIBLE (C8), UNRESOLVED (C26) or unverified (UEF-7) sources | REVERSIBLE | CR-5 |
| Two candidates with opposite regime exposure | A single candidate gives no comparative evidence. More candidates multiply trials against a short depth. | REVERSIBLE | CR-2, CR-6 |
| Pre-registered small set with a holdout and sequential Paper testing | A full grid is excluded by C24. Bounded Bayesian optimization hides the trial count behind a surrogate model. Analytic constraint alone cannot fix the stop multiple and gate. | REVERSIBLE | CR-2 |
| Pessimistic backtest conventions (BC-2, BC-3) | Optimistic fills overstate performance and would inflate the apparent evidence at the same N | REVERSIBLE | CR-1, CR-2 |
| Results in R-multiples | Results in USDT would depend on equity and OD-1 values that are not set | REVERSIBLE | CR-5 |
| Floors computed with ν = 1 shown as the optimistic bound, ν stress reported | Hiding fat-tail inflation would understate the floor (SF-2: up to 1.80× at SR = 1) | REVERSIBLE | CR-2 |
| Zero online adaptation | A refit adds trials and raises the floor. A write path could reach risk state (§4.8). | REVERSIBLE | CR-1 |
| τ_feed derived from the stop distance | A fixed fraction of the bar is up to 8.9× looser and ignores d_ref (§4.9.3) | REVERSIBLE | CR-1 |
| N counted per configuration, not reduced by correlation | Estimating N_eff for correlated configurations needs data this engagement lacks. Counting all configurations errs toward higher floors. | REVERSIBLE | CR-2 |

## 4.11 Requirement acceptance and conflict dispositions

| Requirement | Acceptance condition | Result | Evidence |
|---|---|---|---|
| RQ-OWN-05 | Derivation gives a definition and a bound as a function of named inputs; no unsourced constant | **PASS** (self-inspection, VM-2) | §4.1 IV-1…IV-6; τ_exit symbolic |
| RQ-STA-01 | At least one strategy labeled NOT TESTED; no achievability sentence | **PASS** (VM-1) | SC-1, SC-2 (§4.3.1); ES-0 |
| RQ-STA-02 | Each trial-budget figure has a unit-consistent recomputation or a PROVISIONAL label | **PASS** (VM-2) | §4.5.1–4.5.7; unit convention in §4.4 |
| RQ-STA-03 | Seven declarations present; one allowed design | **PASS** (VM-2, VM-3) | SD-1…SD-7 |
| RQ-STA-04 | Formulas with units; MinBTL and MinTRL distinct; DSR used only with its N | **PASS** (VM-2) | SF-1…SF-8; §4.0 item 4; §4.5.5 |
| RQ-STA-05 | Costs and break-even as functions; no expected result | **PASS** (VM-2) | §4.5.8 with Part 3 WE-18, WE-20 |
| RQ-DAT-06 | Each cost term a parameter with its range | **PASS** (VM-2) | PR-7…PR-11, PR-34 |
| RQ-RSK-08 | Hard limits marked non-adaptable; write path cannot reach them | Partial: the register marks AC-0, and AD-3 states the rule. The component-level write-path check is Part 6. Remains NOT TESTED. | §4.8, §4.9 |
| RQ-DAT-03 | Close-plus-delay, gap handling, cap handling, no C13 dependence | Partial: BC-1 and FT definitions satisfy the feature side. Data-validity rules complete in Part 5. Remains NOT TESTED. | §4.2, §4.3.2 |

**Status delta.** Seven rows move from NOT TESTED to PASS: RQ-OWN-05, RQ-STA-01, RQ-STA-02, RQ-STA-03, RQ-STA-04, RQ-STA-05, RQ-DAT-06. Register arithmetic: PASS 5 + 7 = 12; NOT TESTED 53 − 7 = 46; UNRESOLVED 4; BLOCKED 3; FAIL 0; total 12 + 46 + 4 + 3 + 0 = 65. The row count remains 65. The register edit is applied in the Part 9 matrix.

**Conflict dispositions updated.**

| ID | Disposition |
|---|---|
| CF-3 | Numerically dispositioned. Native depth at ≤ 1h cannot support holdout-only confirmation (§4.5.4). The plan combines per-cell budgets (§4.5.3), forward accumulation (§4.5.5) and cross-venue screening, which is conditional on OD-2 (§4.5.6). Status: DISPOSITION SET. Breadth selection is completed in Part 5. |
| DQ-3 | Disposition set (§4.3.2). Verified through Paper measurement of p_fill and net-per-fill. |
| RX-1 | Strategy side confirmed: entries may be passive, the stop-out is costed at the taker rate (§4.5.8), and no stop or deadline exit depends on a maker fill. The SC-2 target is a profit-taking maker order only. The exit-path verification is Part 7. |
| RX-4 | Strategy evidence status is displayed through the ES labels (§4.7). |

**Amendment note for Part 3 (no change to any result).** §3.8.1 step 5 referred to a margin "reserve" without a symbol. It is now PR-12.

## 4.12 Artifact registry (updated)

| Artifact | Content | Part | Status |
|---|---|---|---|
| AR-01…AR-08 | Part 1 artifacts | 1 | DELIVERED |
| AR-09 | Requirements register, classes, OD and conflict registers | 2 | DELIVERED |
| AR-10 | Risk concepts, parametric sizing | 3 | DELIVERED |
| AR-11 | Intraday derivation, candidates, statistical plan, trial budget, search design, adaptation, parameter register | 4 | DELIVERED (this Part) |
| AR-12 | Data classes, universe, envelope, topology fit | 5 | DEFERRED |
| AR-13 | Decision records and component specifications | 6 | DEFERRED |
| AR-14 | Execution, risk authority, state, recovery | 7 | DEFERRED |
| AR-15 | Telegram, security, operations, phases | 8 | DEFERRED |
| AR-16 | Verification matrix, implementation order, review, propagation record | 9 | DEFERRED |
| AR-17 | Final acceptance | 10 | DEFERRED |

## 4.13 Part 4 completeness declaration

**Catalogs fully defined in Part 4** (each ID appears in one defining table):

| Catalog | IDs | Count |
|---|---|---|
| Intraday derivation | IV-1…IV-6 | 6 |
| Features | FT-1…FT-5 | 5 |
| Strategy candidates | SC-1, SC-2 | 2 |
| Backtest conventions | BC-1…BC-7 | 7 |
| Statistical formulas | SF-1…SF-8 | 8 |
| Search declarations | SD-1…SD-7 | 7 |
| Evidence-status labels | ES-0…ES-5 | 6 |
| Adaptation rules | AD-1…AD-5 | 5 |
| Adaptation classes | AC-0…AC-5 | 6 |
| Parameter register | PR-1…PR-35 | 35 |
| Part-4 checks | PC-17…PC-24 | 8 |

**Catalogs referenced only:** A, C, UEF, PF, CF, RX, HG, CR, DQ, TP, XC, DV-1, OD, RQ, PRI, SEV, CA, OCL, RKC, VM, AR, PC-1…PC-16, MA, FM, HS, WE, RF.

**Dangling-identifier audit.** Every identifier used resolves to a Part 4 catalog or an earlier Part. Symbols (σ_bar, ν, N_cell, and so on) are notation. The τ symbols are defined in PR-29…PR-33. Part numbers are pointers.

**Duplicate-definition audit.** No ID defined here was defined earlier. The ES labels are defined only here, and Part 8 will point to them.

**Cumulative status.** Delivered: Parts 1–4 of 10. Deferred: Parts 5–10, each with its delivery Part in §4.12. The full A+B+C+D+U+E+F=R arithmetic is produced in Part 10.

## 4.14 Part 4 checks

| ID | Check | Evidence | Status |
|---|---|---|---|
| PC-17 | "Part 4/10" header; continuity to Parts 3 and 5 stated | Header; §4.12; §4.15 | PASS |
| PC-18 | Every strategy statement NOT TESTED; no achievability or profit claim | §4.0 item 1; §4.3.1; ES-0 | PASS |
| PC-19 | Hand arithmetic spot-recomputed: M(N) at six N, floor table cells, holdout s_det at six rows, Y_BTL/Y_TRL sums, SF-6 grid, alpha-spending values, τ_feed grid, 500 bp × 14,400 s = 720 s | §4.4–4.5, §4.9.3 | PASS (VM-2, author) |
| PC-20 | No owner illustrative risk figure used as anchor or default; PR-1…PR-5 carry OD-1 only | §4.9.2 | PASS |
| PC-21 | C23, C20 and C21 not used as anchors; unit-consistent recomputation provided | §4.0 item 4; §4.5.7 | PASS |
| PC-22 | Every §3.2 symbol is dispositioned (37 of 37) | §4.9.4 | PASS |
| PC-23 | All money in USDT; no unlabeled USD | Inspection | PASS |
| PC-24 | No credential request, account access or order action | Inspection | PASS |

All PASS entries are author self-inspection, not independent verification.

## 4.15 Next step

**Part 5/10** delivers the data classes (five criteria of §9.4), the universe derivation (steps 1–9 with a Pareto frontier and the five-element liquidity chain), the envelope as a function of (symbols, intervals, data shape), the nine device workload assessments, and the topology fit with Step 4b. **OD-3 may become blocking at the start of Part 5.** I will test first whether TP-1 (all on phone) covers the derived envelope. If it cannot, I will present the options per §2.1.7 with their consequences and then continue. No owner input is needed to start Part 5.

---

**یادداشت پیشرفت (فارسی)**

بخش ۴ از ۱۰ ارسال شد. محتوا:
- **تعریف «درون‌روزی»:** معامله‌ای که ورود و خروجش در یک روز UTC باشد. سقف نگهداری از مهلت «تخت‌شدن» پیش از نیمه‌شب UTC به‌دست می‌آید. تایم‌فریم‌های ۱ روزه و بزرگ‌تر فقط زمینه‌اند، چون یک کندل روزانه در این مهلت جا نمی‌شود.
- **دو استراتژی نامزد (هر دو NOT TESTED):** SC-1 (مومنتوم نرمال‌شده با نوسان) و SC-2 (بازگشت به میانگین روزانهٔ UTC). هیچ ادعای سودآوری یا «دست‌یافتنی بودن» نشده است.
- **بودجهٔ آزمایش به‌ازای هر سلول:** خانوادهٔ پیش‌ثبت‌شده شامل ۱۶۸ پیکربندی (۷۸ برای SC-1 و ۹۰ برای SC-2)، بدون جست‌وجوی جدولی کامل. کف نویز (Noise floor) برای هر سلول محاسبه شد.
- **یافتهٔ کلیدی:** با عمق بومی Toobit در تایم‌فریم‌های ۱ ساعت و کوچک‌تر، تأیید آماری فقط با holdout امکان‌پذیر نیست. شواهد باید از انباشت داده‌های آینده و آزمون ترتیبی در حالت Paper بیاید. این به‌معنای رد استراتژی نیست؛ برچسب آن «غیرقابل ارزیابی با عمق فعلی» است.
- **سیاست انطباق:** صفر انطباق آنلاین؛ فقط بازکالیبراسیون آفلاین، نسخه‌دار و پیش‌ثبت‌شده. هیچ بهینه‌سازی نمی‌تواند حد ریسک را شل کند.
- **ثبت پارامترها:** ۳۵ ردیف با کلاس انطباق و مرجع اختیار تغییر، شامل مشتق‌گیری پارامترهای τ.

**وضعیت:** هفت ردیف نیازمندی به PASS رفتند (بازرسی خودِ نویسنده، نه بررسی مستقل). جمع کل: PASS ۱۲، NOT TESTED ۴۶، UNRESOLVED ۴، BLOCKED ۳، FAIL صفر (جمع ۶۵).

**تصمیم‌های در انتظار شما:** OD-1 تا OD-4 بدون تغییر. OD-3 (زیرساخت خارج از دستگاه) ممکن است در ابتدای بخش ۵ مانع‌ساز شود؛ در آن صورت گزینه‌ها همان‌جا ارائه می‌شود.


# Part 5/10: Data Classes, Universe, Envelope, Device Match, Topology Fit (AR-12)

**Navigation.**
- **Previous: Part 4/10 (AR-11).** It delivered the intraday derivation, features FT, strategies SC, conventions BC, statistics SF/SD/ES/AD/AC, and parameters PR-1…PR-35. Part 5 consumes its hand-off: intervals 15m–6h with 1d as context, P(b), N_cell, and the parameters n and ρ̄.
- **Next: Part 6/10 (AR-13).** Architectural decision records and component specifications (§9.2 fields). Part 6 must stay host-neutral because of D5-9 below.

**Engagement boundary (A4).** Nothing here is measured on the device or on the venue. Every number is either a ratified C-series value, a spec-sheet value, or arithmetic derived in this Part. Evidence marks used below:
- **[M]** ratified measurement (C-series)
- **[S]** spec sheet (C14), not measured under load
- **[D]** derived in this Part
- **[U]** unmeasured

## 0. Fidelity notes

1. The five criteria of §9.4, the step numbering of the universe derivation, and the option format of §2.1.7 are not held verbatim in session memory. This Part uses operational readings (DK-1…DK-5, US-1…US-9, the options table in §6.4), labeled DESIGN_JUDGMENT. They are audited against the prompt in Part 10, the same disclosure class as Part 2 §2.0.
2. Register rows are cited by ID. Their acceptance texts live in Part 2. §9 pairs each Part 5 test with its row, and any mismatch found when the Part 9 matrix re-reads the rows becomes a FAIL there.
3. All money is in USDT. The 134-symbol count from C9 is used only as a scale marker. It is not a derived liquidity threshold.

## 1. Data classes (RQ-DAT-01, RQ-DAT-02)

### 1.1 Decision criteria (DK)

| ID | Criterion | Test |
|---|---|---|
| DK-1 | Consumer | A named design decision (feature, gate, size, interlock, measurement) reads the class. |
| DK-2 | Provenance | Source, access path, legal status and source tag are known and assignable (A5, HG-3). |
| DK-3 | Semantics | Field semantics are SOURCE_VERIFIED or ratified, not CONFLICTED or UNRESOLVED, so validity rules can be written. |
| DK-4 | Cost | Storage, request and compute cost fit the envelope EV (§4) parametrically. |
| DK-5 | Failure response | Missing, stale or invalid input has a fail-safe response (refuse or veto), never a silent default. |

**Rule.**
- ADMIT if all five pass on every declared path.
- RESTRICT if DK-2 or DK-4 passes on only a subset of paths. The class is then barred from the others.
- EXCLUDE if DK-1 or DK-3 fails.

### 1.2 Source tags (ST)

| ID | Tag | Meaning |
|---|---|---|
| ST-1 | TB-HIST | Toobit REST historical klines |
| ST-2 | TB-FWD | Toobit data recorded forward by this system |
| ST-3 | TB-META | Toobit public venue facts (filters, funding, ticker, time) |
| ST-4 | TB-ACC | Authenticated account/order state (not observable in this engagement) |
| ST-5 | XV-RO | Cross-venue data, research-only |
| ST-6 | SYS-DER | Derived artifact; carries the union of its inputs' tags |

### 1.3 Class catalog (DC)

Result column order is DK-1…DK-5. R = research, P = paper, L = live.

| ID | Class | Tag | Consumer | DK | Paths | Decision |
|---|---|---|---|---|---|---|
| DC-1 | Historical closed klines, 15m/30m/1h/2h/4h/6h | ST-1 | FT-1…FT-3, BC, SD | ✓✓✓✓✓ | R, P (warm-up), L (warm-up) | ADMIT |
| DC-2 | Closed 1d klines | ST-1/ST-2 | FT-5 (context only) | ✓✓✓✓✓ | R, P, L | ADMIT |
| DC-3 | Forward-recorded klines, same intervals | ST-2 | Live/Paper features, depth extension past the 3,500 cap | ✓✓✓✓✓ | R, P, L | ADMIT |
| DC-4 | Per-symbol facts: contract type, status, tick, lot m/λ, q_min, N_min (PR-13) | ST-3 | FM-7…FM-10, US-3, US-6 | ✓✓✓✓✓ | R, P, L | ADMIT; unknown → RF-1 |
| DC-5 | Funding schedule and observations (UEF-4) | ST-3 | FM-5, FM-6, BC-5 | ✓✓✓✓✓ (as stress term only; C7) | R, P, L | ADMIT |
| DC-6 | 24h public ticker volume snapshots | ST-3 | LQ-1…LQ-5 | ✓✓✓✓✓ | R, P, L (universe only) | ADMIT; never a signal |
| DC-7 | Server-time and offset observations | ST-3 | VR-1, VR-11, clock interlock | ✓✓✓✓✓ | R, P, L | ADMIT |
| DC-8 | Authenticated account, order, position, fill state | ST-4 | Reconciliation, risk authority | ✓ ✓ ✓ ✓ ✓ by design; no engagement observation (A4) | P (simulated), L | ADMIT as designed, UNOBSERVED; never enters research stores |
| DC-9 | Cross-venue klines at 1h/4h (C17, C18) | ST-5 | Screening in SD only | ✓ ✗(OD-2) ✓ ✓ ✓ | R only | RESTRICT |
| DC-10 | Intervals outside the Part 4 hand-off: 1m, 3m, 5m, 8h, 12h, 1d-as-driver, 1w, 1M | n/a | none | ✗ … | n/a | EXCLUDE; revisit if a new candidate names a consumer |
| DC-11 | Order-book depth (C8 NON_REPRODUCIBLE) | n/a | none in FT | ✗ ✓ ✗ ✓ ✓ | n/a | EXCLUDE |
| DC-12 | Historical open interest (C26 UNRESOLVED) | n/a | none | ✗ ✓ ✗ ✓ ✓ | n/a | EXCLUDE |
| DC-13 | markPrice and klines.change fields (C13 CONFLICTED) | n/a | none | ✗ ✓ ✗ ✓ ✓ | n/a | EXCLUDE; dropped at ingest |
| DC-14 | System records: decisions, config versions, Paper and Live outcomes | ST-6 | ES labels, p_fill, audit | ✓✓✓✓✓ | R, P, L | ADMIT |

**Raw 1m/3m/5m (DC-10).** The native caps are 2.43, 7.29 and 12.15 days [M, DV-1], so they cannot support any cell's evidence. SC-1 and SC-2 do not read them. Execution-quality measurement could use them, but Paper records p_fill and net-per-fill from the admitted intervals (DQ-3 disposition), so DK-1 fails. Revisit trigger: a candidate whose consumer needs sub-15m data.

### 1.4 Lineage gate

| Path | Allowed tags in a datum's lineage |
|---|---|
| RESEARCH | ST-1, ST-2, ST-3, ST-5, ST-6 (lineage within these) |
| PAPER | ST-1, ST-2, ST-3, ST-4 (simulated), ST-6 with no ST-5 in lineage. After OD-2 resolves favorably, ST-5 may be admitted to Paper screening only (A5). |
| LIVE | ST-1, ST-2, ST-3, ST-4, ST-6 with no ST-5 in lineage. Never relaxed by OD-2. |

**Gate rules.**
- (a) Every record is tagged at ingest. Untagged data is not loadable.
- (b) A derived artifact carries the union of its inputs' tags (ST-6 plus members).
- (c) The gate is evaluated at three points: dataset load, config-version load, and order-intent construction.
- (d) A violation on a Paper or Live path produces a lineage refusal and a CRIT alert. It is never downgraded to a warning. The refusal receives an identifier in the Part 8 refusal catalog.
- (e) Lineage modes for configs derived with ST-5:
  - **Mode A (default):** any ST-5 influence on selection makes the config research-only.
  - **Mode B:** ST-5 may only eliminate candidates, and the deployed config's evidence is ST-1/ST-2 only. Mode B needs an owner decision recorded under OD-2, because "derived parameters" is a legal reading the design cannot make.

The consequence of Mode A is that cross-venue screening informs research but cannot shorten the path to Live. The evidence plan therefore rests on native depth plus forward accumulation (DC-3).

## 2. Data-validity rules (RQ-DAT-03, completed here)

**State vocabulary.** Each (symbol, interval) is VALID, STALE, GAP, QUARANTINED or UNKNOWN. Only VALID is usable. UNKNOWN is never promoted to VALID (CR-1, §9.6).

| ID | Rule | Failure state and response |
|---|---|---|
| VR-1 | **Close-plus-delay.** A bar (open t_o, interval b) is usable at corrected server time t̂ iff t̂ ≥ t_o + b + δ_bar(b). δ_bar(b) is a pre-registered quantile (AC-2) of the observed (first-seen time − (t_o+b)) over the MQ-7 window. t̂ comes from monotonic elapsed time anchored to the last accepted server-time observation (A3). | While δ_bar is unmeasured (PR-20): UNKNOWN, so entries are refused. |
| VR-2 | **Grid.** t_o ≡ 0 (mod b) on the UTC epoch grid. The 1d bar opens at 00:00 UTC. Every admitted b divides 24 h. | Misaligned: QUARANTINED, because the venue grid differs from the assumption. |
| VR-3 | **Gap.** A missing bar is first treated as late and re-queried within a bounded backfill window. If still absent it becomes GAP and is excluded (BC-1). A feature is VALID only if its σ window of w_σ + 1 consecutive valid closes (PR-18) and every other named input bar are VALID. | GAP clears only when the window is rebuilt (table below). Entries are refused meanwhile. Open positions rely on resident stops. |
| VR-4 | **3,500-cap.** A history response of exactly 3,500 bars is treated as possibly truncated. Coverage starts at the earliest returned bar, with no extrapolation. A count below 3,500 with a requested start earlier than the first bar means complete back to listing. Cells whose coverage is below the required depth are labeled ES-1 NOT ASSESSABLE. | Never described as complete history. Depth beyond the cap comes only from DC-3. |
| VR-5 | **Immutability.** A closed bar re-read with any OHLCV difference is kept in both versions and marked REVISED. Dependent features are invalid. | QUARANTINED until two consecutive identical reads and a rebuilt window. |
| VR-6 | **Structure.** low ≤ min(open, close) ≤ max(open, close) ≤ high, prices > 0, volumes ≥ 0, no duplicate t_o. | Violation: QUARANTINED. |
| VR-7 | **No deletion of real extremes.** Only VR-6 structural failures exclude a bar. Winsorizing or dropping large moves is prohibited because gap risk is the quantity WE-19 sizes against. | n/a |
| VR-8 | **Polling baseline.** Closed bars are confirmed by REST after VR-1. Streams are an optimization only, and any stream gap (UEF-12) is ignored for validity (UEF-7 polling baseline). | n/a |
| VR-9 | **Staleness.** If the age of the latest VALID bar exceeds τ_feed (PR-29), the state is STALE. | RKC-3 veto path (bound in Parts 7–8). New entries are refused. |
| VR-10 | **No C13 dependence.** No feature, gate or interlock reads markPrice or klines.change. Those fields are dropped at ingest (DC-13). | n/a |
| VR-11 | **Clock.** If the clock offset is unknown, stale, or |θ| > θ_max (PR-32), no bar is VALID. | Entries refused. Resident protective orders are unaffected. |
| VR-12 | **Venue-fact freshness.** DC-4 and DC-5 are re-fetched at each UTC day start and after any rejection that implies a filter mismatch. A fact older than one UTC day, or absent, is UNKNOWN (DESIGN_JUDGMENT). | UNKNOWN produces RF-1. |
| VR-13 | **Cross-venue.** DC-9 is compared with native bars only at 1h/4h (C18). Basis monitoring never feeds Paper or Live. | n/a |

**Gap-recovery cost of VR-3.** The earliest VALID entry decision after one excluded bar is (w_σ + 1)·b after the gap bar closes. This is the price of strict contiguity: CR-1 over CR-7 [D].

| b | 15m | 30m | 1h | 2h | 4h | 6h |
|---|---|---|---|---|---|---|
| w_σ | 96 | 48 | 24 | 20 | 20 | 20 |
| (w_σ+1)·b | 24.25 h | 24.5 h | 25 h | 42 h | 84 h | 126 h |

If Paper shows gap frequency costing too much valid time, tolerance is added through a new frozen config version (REVERSIBLE).

## 3. Universe derivation (D14, §10.1; RQ-OWN-06)

### 3.1 Steps (US)

The 10-symbol storage measurement list is not a candidate and appears in no step.

| ID | Step | Operation | Output |
|---|---|---|---|
| US-1 | Enumerate | All symbols the venue lists (the census shows 544 [M, DV-1]). | Candidate set S₀ |
| US-2 | Structural eligibility | Keep linear USDT-margined perpetuals (MA-1, PROVISIONAL) in tradable status. | S₁ |
| US-3 | Known filters (UEF-3) | Keep symbols with DC-4 complete and fresh (VR-12). Every other symbol is refused with RF-1. | S₂ |
| US-4 | Liquidity | Apply the five-element chain LQ-1…LQ-5. | S₃ |
| US-5 | Data adequacy | Require VR-2/VR-6-clean history on at least one admitted interval, and a tick resolution that supports BC-3: tick/(σ_bar·P_ref) ≤ ε_tick (AC-2, calibrated offline). | S₄ |
| US-6 | Sizing feasibility | Apply the admission predicate (§3.3) over the actual filters. | S₅ |
| US-7 | Statistical independence | Symbols are admitted by structural rules only, never by backtest or Paper performance. Parameters are pooled across symbols. | N_cell does not multiply by n |
| US-8 | Envelope | Evaluate EV(n, I, shape) (§4). | Feasible n by T |
| US-9 | Pareto frontier | Over the axes (symbols n, timeframes T) (§3.4). | Frontier and dominator table |

**US-7 rationale.** Selecting symbols by performance would multiply the trial count by n and invalidate SF-1. The effective-bets figure SF-6 N_eff,sym = n/(1+(n−1)ρ̄) is reported only and never enlarges a budget.

### 3.2 Liquidity threshold: five-element chain (LQ)

| ID | Element | Definition |
|---|---|---|
| LQ-1 | N_max | Maximum order notional ≈ r·E·P_e/u from FM-1, FM-9, FM-11. Parametric in OD-1 (r, basis), so the threshold is parametric until OD-1 resolves. |
| LQ-2 | π | Participation cap: order notional ≤ π × bar quote volume. AC-2, pre-registered, no value asserted. |
| LQ-3 | κ_q | Low-quantile-to-mean ratio of per-bar quote volume at b_min. Measured offline from DC-1 [U]. |
| LQ-4 | σ_v | Stress-day volume ratio, ≤ 1. Measured offline [U]. |
| LQ-5 | b_min | Finest admitted interval (binding, because per-bar volume is smallest there). |

**Threshold.** V_thr = N_max · (24 h / b_min) / (π · κ_q · σ_v), in USDT of 24h notional.

**Properties.**
- V_thr is linear in N_max.
- It is proportional to 24 h/b_min: 96 at 15m, 48 at 30m, 24 at 1h, 12 at 2h, 6 at 4h, 4 at 6h.
- It is non-increasing in π, κ_q and σ_v.

**Arithmetic check (teaching constants, not design values).** N_max = 100 USDT, π = 0.01, κ_q = 0.3, σ_v = 0.5, b_min = 1 h gives V_thr = 100 × 24 / 0.0015 = 1,600,000 USDT/day. This is above the C9 median of 498,844 USDT [M], which shows the chain can exclude the median symbol. It does not pick the threshold.

**Symbol-count function.** n(V_thr) is a non-increasing step function. Known points: 134 symbols at a 10,000,000 USDT snapshot [M]. Other points are [U] until DC-6 is read at implementation time.

### 3.3 Admission predicate (UEF-3, CF-5)

A symbol s is admitted iff all of the following hold:
1. DC-4(s) is complete and fresh (VR-12).
2. V_24h(s) ≥ V_thr.
3. q_req(s) = λ·⌈max(q_min, N_min/P_e)/λ⌉ and E_min(s) = q_req·u(s)/r satisfy E_v ≥ E_min(s). E_v is the equity basis at version freeze (OD-1 basis). This generalizes WE-17.
4. US-5 holds.

Two layers apply.
- **Structural** (this predicate) is fixed per universe version.
- **Runtime** per-order refusals RF-2, RF-3, RF-4 and RF-5 still apply at every intent, because equity changes.

**Current state.** No filter is verified (UEF-3), so the admitted set is empty today. The design delivers the function. The list is produced when it runs on DC-4 and DC-6 snapshots.

**Versioning.**
- Universe membership is frozen per config version.
- Removal for safety (filters unknown, delisting, status change, VR-12 failure) is applied immediately and needs no approval.
- Additions require a new version.
- This asymmetry is fail-safe by construction.

### 3.4 Pareto frontier on (symbols n, timeframes T)

**Timeframe axis.** T counts admitted driving intervals in the nested coarse-to-fine order {6h}, +4h, +2h, +1h, +30m, +15m. Rationale: lower b needs more trials, a higher friction ratio (C10), and more wakes per day.

**Joint constraints on n for a given T.**
- (i) n ≤ n_elig = |S₅|.
- (ii) Request burst: at 00:00 UTC all T+1 intervals (including 1d) close at once, so n·(T+1) ≤ Q = ⌊Ω·s_b/w_r⌋. Ω is the request-weight budget (C4, UEF-6 [U]), s_b the spread window, w_r the weight per request.
- (iii) Storage: n·β_c·Σ_b D(b) ≤ S_max.
- (iv) Compute: n·Σ N_cell·D(b)·c_bt within the pass-time budget.
- Separate bound on T: wake reliability (MQ-1) limits how fine b_min can be on a given host.

**Frontier points.** n*(T) = min over (i)–(iv). It is non-increasing in T. PP-k = (n*(k), k) for k = 1…6.

| ID | Point | Frontier test |
|---|---|---|
| PP-1…PP-6 | PP-k = (n*(k), k), T = k | PP-k is on the frontier iff n*(k) > n*(k+1) or k = 6. Otherwise it is dominated by PP-(k+1). |

**Excluded points and their dominators.**
- Any (n, T) with n < n*(T) is dominated by PP-T.
- Any (n, T) with n > n*(T) is infeasible, and the violated constraint among (i)–(iv) is named.
- T beyond 6, or 1d/1w/1M as drivers, is infeasible by IV (b + δ_bar + τ_exit ≤ 24 h).
- 1m/3m/5m are excluded by DK-1 (DC-10).

**Worked mechanics (teaching constants, not estimates).** n_elig = 100, Q = 420. Then ⌊420/(T+1)⌋ = 210, 140, 105, 84, 70, 60 for T = 1…6, and n*(T) = 100, 100, 100, 84, 70, 60.
- PP-1 (100,1) is dominated by PP-3 (100,3).
- PP-2 (100,2) is dominated by PP-3 (100,3).
- PP-3, PP-4, PP-5 and PP-6 are on the frontier.

**Selection.** Breadth is CR-7: Pareto, not scored. The design does not collapse the frontier to a point. Cells activate one at a time in the nested order. Each activation needs:
- data adequacy (VR-4, ES-1 not applicable);
- a pre-registered budget (PR-25);
- the SD promotion path.

Deployed breadth is therefore an output of evidence.

**Burden of the timeframe axis (reported, [D], approximate normal quantiles, recalled tables, ±0.005).** The holdout threshold inflation (z_{1−α/K}+z_{1−β})/(z_{1−α}+z_{1−β}) is about 1.13 at K = 2, 1.19 at K = 3 (matches Part 4), 1.30 at K = 6, and 1.39 at K = 11 (the 11 strategy × interval cells of the 168-configuration family).

### 3.5 OD-2 handling (RX-6, A5, PF-4)

- DC-9 is research-only (ST-5). It has no Paper consumer until OD-2 resolves.
- Cross-venue-dependent depth or evidence-time claims at 1h/4h are blocked.
- The evidence plan does not depend on DC-9. It uses native depth plus forward accumulation.
- Upon a favorable OD-2, the gate widens only to Paper screening (§1.4). It never widens to Live. The change is COSTLY_REVERSIBLE.

**Forward accumulation need (parametric, [D]).** The wait beyond native depth is (required years − native depth). Values below use s = 1.5, which is a teaching value for the function. It is neither a target nor an expectation, and s_min is PR-25 UNRESOLVED. It uses the Part 4 sums (N = 18: 4.275 y; N = 6: 3.499 y).

| Cell | Native depth (y) | Required (y) | Wait (y) |
|---|---|---|---|
| 15m, N=18 | 0.100 | 4.275 | 4.175 |
| 30m, N=18 | 0.200 | 4.275 | 4.075 |
| 1h, N=18 | 0.400 | 4.275 | 3.875 |
| 2h, N=18 (SC-2) | 0.799 | 4.275 | 3.476 |
| 4h, N=18 (SC-2) | 1.598 | 4.275 | 2.677 |
| 4h, N=6 (SC-1) | 1.598 | 3.499 | 1.901 |
| 6h, N=6 (SC-1) | 2.397 | 3.499 | 1.102 |

Calendar time cannot be bought. This quantifies why DC-3 is ADMIT and why Paper is long-running.

## 4. Envelope as a function of (symbols, intervals, data shape)

Derived before any device is considered, from the Part 4 hand-off.

### 4.1 Parameters (EP)

| ID | Parameter | Value or status |
|---|---|---|
| EP-1 | n (admitted symbols) | Parametric; output of §3 |
| EP-2 | I (driving intervals) and T = |I|; 1d is added as context | 15m–6h per Part 4 |
| EP-3 | β_c, bytes per stored candle | Design layout 72 B (§4.2); C19-implied upper envelope 2,551 B |
| EP-4 | t_acc, forward accumulation years | Parametric |
| EP-5 | Ω, w_r, s_b, Q = ⌊Ω·s_b/w_r⌋ | [U] (C4 headers absent; UEF-6) |
| EP-6 | S_max, storage budget | Owner/host dependent |
| EP-7 | c_bt, seconds per bar-step | [U] (MQ-4) |
| EP-8 | B_boot, N_surv (bootstrap resamples, surviving configs) | AC-3 SEARCHED |

### 4.2 Data shape

**Design record (DESIGN_JUDGMENT).** Fixed 72 B: open_time 8; O, H, L, C 32; base volume 8; quote volume 8; ingest_time 8; trade count 4; source tag 1; flags 1; padding 2. The ingest time exists because it is the only source of δ_bar. The source tag exists because lineage is mandatory.

**C19-implied density.** 1.25 GB over 3,500 × 14 × 10 = 490,000 candles is about 2,551 B per candle (decimal GB; format and unit convention unstated [U]). This is 35.4× the design layout, so it is treated as the conservative upper envelope.

### 4.3 Formulas (EV) with numeric anchors

| ID | Formula | Anchors |
|---|---|---|
| EV-1 | **Storage.** S(t_acc) = n·β_c·Σ_{b∈I∪{1d}}[D₀(b) + P(b)·t_acc], with D₀ ≤ 3,500 | Per symbol at the cap (T = 6 plus 1d): 7 × 3,500 = 24,500 candles. Per year of forward data: 35,040+17,520+8,760+4,380+2,190+1,460+365 = 69,715 bars. Design layout: 1.764 MB at the cap, +5.019 MB/year. C19 density: 62.50 MB at the cap, +177.84 MB/year. |
| EV-2 | **Request volume.** R_d = n·Σ_b 86,400/b = 191·n per day (96+48+24+12+6+4+1) | n = 134: 25,594/day, 0.296 req/s average |
| EV-3 | **Burst.** All T+1 intervals close together at 00:00 UTC: B = n·(T+1) requests, which must satisfy B·w_r ≤ Ω·s_b | n = 134, T = 6: 938 requests |
| EV-4 | **Working set.** Live core windows: (w_σ+1) closes per driving cell = 97+49+25+21+21+21 = 234, plus 2 for 1d, so 236 closes per symbol. Journal: J(yr) = 365·n·f_o·ρ_rec·β_rec, with f_o orders per symbol-day [U] | 236 × 72 = 16,992 B per symbol; n = 134: 2.28 MB |
| EV-5 | **Backtest.** Bar-steps per symbol = Σ N_cell·D(b) = 168 × 3,500 = 588,000 at the cap (SC-1 78 × 3,500 = 273,000; SC-2 90 × 3,500 = 315,000). Time = n × 588,000 × c_bt | n = 134: 78,792,000 bar-steps. Illustration only: c_bt = 1 µs gives 78.8 s; 100 µs gives 7,879 s = 2.19 h. These two values are not measurements. |
| EV-6 | **Bootstrap/placebo.** T_boot = B_boot·N_surv·n·D·c_bt | Applied only to configs surviving screening |
| EV-7 | **Availability demand.** Decision wakes per day W_d = 86,400/b_min at fixed UTC instants (the 15m grid contains every coarser grid). A missed wake is a missed decision, so entries are refused. Missing the t_flat(D) window (A6) carries a stop-protected position past its intended exit. | W_d = 96, 48, 24, 12, 6, 4 for b_min = 15m, 30m, 1h, 2h, 4h, 6h |

**Totals at n = 134, scale marker only.**

| Basis | Cap only | + 1 year forward | Share of 56 GB free [S, snapshot] |
|---|---|---|---|
| Design layout | 236.4 MB | 909.0 MB | 1.62% |
| C19 density | 8.375 GB | 32.21 GB | 57.5% |

Cross-venue research (DC-9, 1h and 4h only): 57,336 + 14,334 = 71,670 candles per symbol, which is 5.160 MB at the design layout or 182.8 MB at C19 density. It is conditional on OD-2.

**Envelope reading.** Capacity demand is small under the design layout and conditional under the C19 density. Availability demand (EV-7) is independent of n and rises as b_min falls.

## 5. Device-workload assessments (D15, A8, C14–C16)

Reference device: POCO X6, 23122PCD1G, Termux. It is a feasibility constraint only. Each workload is assessed separately.

### 5.1 Nine assessments (DW)

| ID | Workload | Demand | Evidence on phone | TP-1 verdict |
|---|---|---|---|---|
| DW-1 | Development | Editing and unit tests; language is delegated (A12). Constraint on Part 6: the runtime must install in Termux. | [S] 12 GB physical RAM (C14, the 8 GB extension is not physical); toolchain availability [U] | COVERED, PROVISIONAL |
| DW-2 | Training (parameter screening, not model fitting) | EV-5 and EV-6: 79 s–2.19 h per full pass at n = 134 across the c_bt illustration | Sustained CPU and thermal behavior [U] (C16); MQ-4 | COVERED, PROVISIONAL |
| DW-3 | Backtest | EV-5, with BC-1…BC-7 per-trade logic; streaming one symbol at a time bounds memory at 1.764 MB per symbol | [U] c_bt | COVERED, PROVISIONAL |
| DW-4 | Calibration | σ_x, σ_e, κ_q, σ_v, δ_bar estimation: small data, negligible compute | n/a | COVERED, PROVISIONAL |
| DW-5 | Paper | EV-2 and EV-3 polling, EV-4 working set, the same decision path as Live without orders; long-running (years, §3.5). Gaps cost evidence, not safety. | Process survival [U] (C15, C16) | COVERED, degraded by gaps |
| DW-6 | Live | Same as Paper plus EV-7 wakes, resident protective orders, forced flat at t_flat(D) | Restricted standby bucket not exempted by charging (C15); sustained runtime unmeasured (C16) | NOT ESTABLISHED |
| DW-7 | Telegram runtime | Outbound-only long polling (A9: no stable inbound assumed); commands tolerant of latency; safety independent (A2, HG-6) | Wake and standby behavior [U] (MQ-3) | NOT ESTABLISHED |
| DW-8 | Storage | EV-1 | [S] 56 GB free (snapshot) | COVERED at the design layout; conditional at C19 density |
| DW-9 | Recovery | Restore risk state, rebuild windows (EV-4), reconcile orders by clientOrderId (UEF-8). Stopped-process recovery needs physical access to the device, which is non-routine, so it does not violate A2. | Termux process-restart behavior [U] | COVERED, PROVISIONAL |

### 5.2 Measurement requests (MQ)

Each request is owner-run, unauthenticated, and outside this engagement (A4). None has been executed.

| ID | Quantity | Feeds | Acceptance relation | Status |
|---|---|---|---|---|
| MQ-1 | Termux process survival and wake accuracy over ≥ 72 h, screen off, in charging and battery states (C15, C16) | EV-7, DW-5, DW-6, T_wake | Longest down interval vs τ_proc (PR-31) and τ_op,1 (PR-33, UNRESOLVED); wake miss count vs W_d | [U] |
| MQ-2 | Outbound reachability and request-weight behavior to public Toobit endpoints (UEF-6, UEF-13) | EP-5, UEF-13 | Reachability from every candidate host | [U] |
| MQ-3 | Telegram long-poll round-trip under standby | DW-7 | Latency distribution vs command design (Part 8) | [U] |
| MQ-4 | c_bt on a reference kernel | EV-5, EV-6 | Pass time at n | [U] |
| MQ-5 | Storage write throughput and free space with the 72 B layout | EV-1 | S ≤ S_max | [U] |
| MQ-6 | Clock offset distribution | PR-32, VR-11 | θ_max = ε_c·δ_bar, ε_c < 1 | [U] |
| MQ-7 | δ_bar per interval | VR-1, PR-20 | Entries enabled only after measurement | [U] |

## 6. Step 4b: topology fit (D15)

### 6.1 Enumeration before any compromise

| TP | Capacity (EV-1…EV-6) | Availability (EV-7, DW-6, DW-7) | Extra requirement | Dominance note |
|---|---|---|---|---|
| TP-1 all on phone | Covered, provisional | Not established | none (0 USDT/month) | Test below |
| TP-2 compute off-device | Not needed (capacity covered) | Unchanged | Cost, credential-free | No benefit for Live; costlier than TP-1 on capacity |
| TP-3 Live core off-device | Covered | Host-dependent | UEF-9 (IP whitelist, geography), UEF-13, cost | Removes the unmeasured phone dependency for the only availability-critical workload |
| TP-4 all except thin dev tooling off-device | Covered | Host-dependent | As TP-3, plus a research host | More failure domains than TP-3 (CR-6) |
| TP-5 core on phone, relay off-device | Covered | Unchanged | Relay as an extra trust boundary | Dominated by TP-1: long polling is outbound, so no inbound relay is needed |
| TP-6 owner-owned always-on non-phone machine | Covered | Host-dependent | Availability UNRESOLVED | Cost 0 if it exists |

### 6.2 TP-1 test

TP-1 is tested first against the derived envelope.
- **Capacity (EV-1…EV-6):** covered. At the design layout n = 134 uses 909.0 MB over one forward year (1.62% of the snapshot).
- **Availability (EV-7 for DW-6, DW-7):** NOT ESTABLISHED. C15 shows charging does not exempt the app, and C16 shows sustained runtime unmeasured.

**Result: TP-1 cannot be shown to cover the derived envelope for Live and Telegram runtime. OD-3 therefore becomes BLOCKING.**

**What is and is not blocked.**
- Blocked: selection of the Live core host, and any claim that Live-on-phone is acceptable.
- Not blocked: the rest of the design. It continues host-neutral (D5-9).

### 6.3 Why the design stays fail-safe without a host answer

- Entries stop when the process stops (VR-1, VR-9, VR-11).
- Positions are held by exchange-resident stops. Live is refused until UEF-1 verifies them (RX-2).
- The time-based forced flat (A6) needs the running core. If the process is down at t_flat(D), the position is carried stop-protected past its intended exit. Part 7's τ_op response table defines the response, and OD-4 requests ratification of the policy in Part 8.

### 6.4 Options for OD-3 (§2.1.7 reading)

Answer format: per topology available / unavailable / unknown, plus a monthly cost ceiling in USDT. This is the only question returned by this Part.

| Option | Owner confirms | Consequence for the design | Consequence for the owner | Reversibility |
|---|---|---|---|---|
| TP-1 only | No off-device host | Research and Paper run on phone. Live is authorizable only if MQ-1…MQ-3 pass; otherwise CS-5 applies (§6.5). | 0 USDT/month; battery, Android settings and charger discipline are owner-side effort | REVERSIBLE |
| TP-3 | An always-on host exists; payment, legal and geography are workable; UEF-9 whitelist is available | Live core and Telegram bot run on the host. The phone keeps development, research and Paper. The unmeasured phone dependency is removed. | Monthly cost within the ceiling; remote shell access for non-routine recovery (A2 allows non-routine) | COSTLY_REVERSIBLE |
| TP-6 | An owner-owned always-on non-phone machine exists | Same design effect as TP-3 | No rental cost; the machine's power and network are the owner's responsibility | COSTLY_REVERSIBLE |
| TP-4 | As TP-3, plus a research host | More failure domains (CR-6), no capacity benefit | Higher cost | COSTLY_REVERSIBLE |
| TP-2 | Rented compute | No benefit under the derived envelope | Cost without a requirement | REVERSIBLE |
| TP-5 | A relay host | Adds a trust boundary that long polling makes unnecessary | Cost and exposure | REVERSIBLE |

### 6.5 Compromise sub-steps (CS), four-part disclosure

The order follows A8. TP-1…TP-6 were enumerated first (§6.1).

| ID | (a) Compromise-order item | (b) Narrower scope | (c) Why it suffices | (d) Escalation criterion |
|---|---|---|---|---|
| CS-1 | All phases on phone | None; this is TP-1. Conditional on MQ-1…MQ-3. | Capacity covered (§4); Live availability only if measurements pass | Any MQ acceptance fails, or OD-3 returns "unavailable" for TP-1 |
| CS-2 | All but Live on phone | The Live core and Telegram runtime move off-device (TP-3 or TP-6). Phone keeps dev, research and Paper. | The only unmeasured workload leaves the phone. Capacity was never binding. | UEF-9 or UEF-13 fails for the host, or OD-3 answers "unavailable" for TP-3, TP-4 and TP-6 |
| CS-3 | Keep dev/train/calibrate on phone; reduce breadth | Not invoked. Breadth reduction does not address an availability gap. | n/a | Invoked only if EV-1…EV-6 later fail on measurement (MQ-4, MQ-5) |
| CS-4 | Reduce depth | Not invoked, same reason as CS-3 | n/a | Same as CS-3 |
| CS-5 | Reduce a capability | Live is withheld: the system runs research and Paper only, and the selector's Live interlocks stay unsatisfied. The design remains valid. | Removes the only unestablished workload from scope | If neither CS-1 nor CS-2 can be satisfied |
| CS-6 | Stated redesign | Not invoked | n/a | Only if CS-5 is rejected by the owner |

## 7. Decisions

| ID | Decision | Rejected alternative with positive reason | Reversibility | Deciding criterion |
|---|---|---|---|---|
| D5-1 | Classes decided by DK-1…DK-5; 14 classes (§1.3). | Admit every available field: it would give maximal flexibility but consumes C13, C8 and C26 data whose semantics are not established. | REVERSIBLE | CR-1, CR-5 |
| D5-2 | Tag-union lineage gate at load, config load and order intent; Mode A default. | Gate only at order intent: it is cheaper but misses config lineage, which is where cross-venue influence would enter. | REVERSIBLE (OD-2 changes are COSTLY_REVERSIBLE) | CR-1 (HG-3) |
| D5-3 | Closed-bar polling baseline with VR-1 gating. | Stream-driven bars: lower latency but gaps (UEF-12) and unmeasured weights make validity harder to prove. | REVERSIBLE | CR-1, CR-5 |
| D5-4 | 72 B fixed record. | Storing as C19 measured (2,551 B/candle): format already working, but 35.4× larger and 57.5% of free space at one forward year. | REVERSIBLE | CR-4, CR-6 |
| D5-5 | No performance-based symbol selection; pooled parameters. | Per-symbol tuning: may fit each symbol better but multiplies N by n and raises the SF-1 floor. | COSTLY_REVERSIBLE | CR-2 |
| D5-6 | Universe as a versioned function; removals immediate, additions versioned. | Static list: simpler, but a delisted or filter-unknown symbol would stay admitted until the next release. | REVERSIBLE | CR-1 |
| D5-7 | Pareto frontier over (n, T); nested coarse-to-fine activation; no scalar score. | Weighted breadth score: gives a single answer but hides the trade-off the owner asked to see (A7, CR-7). | REVERSIBLE | CR-7, CR-2 |
| D5-8 | Capacity and availability evaluated separately; TP-1 capacity covered, Live not established; OD-3 BLOCKING for host selection. | Declare TP-1 sufficient from capacity alone: would hide the C15/C16 gap. | COSTLY_REVERSIBLE | CR-1, CR-4 |
| D5-9 | Host-neutral core (H_live may be phone or off-device) with invariants: resident protection before a position is counted protected, no inbound listener, risk state local to the core, Telegram loss never releases a limit. | Design Live for the phone only: simpler, but it would force a redesign if MQ-1 fails. | COSTLY_REVERSIBLE | CR-6, CR-8 |

## 8. Dispositions

| Item | Disposition after Part 5 |
|---|---|
| CF-3 | Breadth part completed. Parameters are pooled and symbols admitted structurally, so N_cell does not multiply by n (US-7). Forward accumulation and conditional cross-venue are quantified in §3.5. |
| CF-4 | The breadth-versus-feasibility trade-off is handled by the Pareto structure (§3.4) with joint constraints (i)–(iv). No scalar compromise is made. |
| CF-5 | The admission rule over actual filters is delivered (§3.3). It awaits UEF-3 and OD-1 for numeric output. |
| RX-5 | Per-workload evaluation done (§5). Live-on-phone remains UNRESOLVED because MQ-1…MQ-3 are unmeasured. |
| RX-6 | Research-only gate and forward accumulation are delivered. UNRESOLVED until OD-2. |
| RQ-DAT-05 | UNRESOLVED. Depends on OD-2 and on δ_bar (MQ-7, PR-20). |
| RQ-DEP-03 | UNRESOLVED. Depends on OD-3 and MQ-1…MQ-3. |
| RQ-DEP-04 | BLOCKED. Measurement is outside the engagement (A4, capability). Protocol is MQ-1…MQ-7. |
| OD-2 | Still OWNER_DECISION_PENDING. Default stands: research-only, no Paper consumer. |
| OD-3 | Now BLOCKING for Live-host selection; options in §6.4. |

**Resolved pending propagation (§2.1.5).**
1. SD-3 promotion text in Part 4: configs with ST-5 selection influence are research-only under Mode A. Applied in the Part 9 change record.
2. Strict-contiguity cost for VR-3 versus the BC-1 gap statement: consistent, recorded in Part 9.

## 9. Part checks PC-25…PC-32 (author self-inspection; not independent proof)

| PC | Check | Method | Result |
|---|---|---|---|
| PC-25 | Every data input named in Parts 3–4 maps to exactly one DC, and each DC carries its DK record. | VM-3 walk-through of FT inputs, PR-13 facts, funding, time, exclusions | PASS |
| PC-26 | Lineage gate: an ST-5 input on Paper or Live is refused at all three evaluation points. | VM-3 with three cases: dataset, config, intent | PASS |
| PC-27 | VR consistency and test vector: 1h bar opening 05:00 UTC missing → next VALID entry decision at 07:00 UTC + δ_bar the next UTC day (25 h after the gap bar's 06:00 close). Table (w_σ+1)·b recomputed. | VM-2 arithmetic | PASS |
| PC-28 | Universe: the 10-symbol list absent; every step has input and output; dominators named for every excluded point. | VM-3, VM-2 (worked example 100/84/70/60) | PASS |
| PC-29 | LQ dimensional check: V_thr in USDT/day; monotonic properties; teaching example 1,600,000. | VM-2 | PASS |
| PC-30 | Envelope arithmetic recomputed: 69,715; 24,500; 62,499,500 B; 177,842,965 B; 588,000; 78,792,000; 25,594; 938; 234 closes; 16,992 B; 909.0 MB; 32.21 GB. | VM-2 | PASS |
| PC-31 | Nine workloads assessed separately with [M]/[S]/[D]/[U] marks; TP-1…TP-6 enumerated before CS; four-part disclosure present. | VM-3 | PASS |
| PC-32 | Identifier integrity (catalogs below), no USD, no OD-1 anchors, no "Class-A" label. | VM-3 | PASS |

**Register pairing (status after Part 5; row texts re-read in Part 9).**
- **PASS (self-inspection):** RQ-OWN-06, RQ-OWN-07, RQ-DAT-01, RQ-DAT-02, RQ-DAT-03, RQ-DAT-04, RQ-DEP-01, RQ-DEP-02.
- **Remain NOT TESTED:** RQ-OWN-04 (Part 5 portion contributed; completes in Parts 8–9), RQ-EXE-05, RQ-RSK-08.
- **Unchanged:** RQ-DAT-05, RQ-DEP-03 (UNRESOLVED); RQ-DEP-04 (BLOCKED).

| Status | Count |
|---|---|
| PASS | 20 (12 + 8) |
| NOT TESTED | 38 (46 − 8) |
| UNRESOLVED | 4 |
| BLOCKED | 3 |
| FAIL | 0 |
| **Total** | **65** |

Part 5 portions of CF-3, CF-4, CF-5, RX-5 and RX-6 are recorded in §8.

## 10. Completeness declaration

**Catalogs defined in this Part (each fully defined here only).**

| Catalog | Range | Count |
|---|---|---|
| DK | DK-1…DK-5 | 5 |
| ST | ST-1…ST-6 | 6 |
| DC | DC-1…DC-14 | 14 |
| VR | VR-1…VR-13 | 13 |
| US | US-1…US-9 | 9 |
| LQ | LQ-1…LQ-5 | 5 |
| PP | PP-1…PP-6 | 6 |
| EP | EP-1…EP-8 | 8 |
| EV | EV-1…EV-7 | 7 |
| DW | DW-1…DW-9 | 9 |
| MQ | MQ-1…MQ-7 | 7 |
| CS | CS-1…CS-6 | 6 |
| D5 | D5-1…D5-9 | 9 |
| PC | PC-25…PC-32 | 8 |

**Referenced-only catalogs.** A, C, UEF, PF, CF, HG, CR, DQ, TP, XC, DV-1, AR (Part 1); RQ, PRI, SEV, CA, OCL, RKC, VM, OD, RX (Part 2); MA, FM, HS, WE, RF (Part 3); IV, FT, SC, BC, SF, SD, ES, AD, AC, PR (Part 4).

**Dangling-identifier audit.** No identifier is used without a defining catalog. Forward references are by description only: the lineage refusal identifier (Part 8) and the τ_op response table (Part 7).

**Duplicate-definition audit.** No identifier defined here appears in an earlier catalog. PC-25…PC-32 continue from PC-24.

**Artifact registry.**

| AR | Content | Status |
|---|---|---|
| AR-01…AR-11 | Parts 1–4 | DELIVERED |
| AR-12 | Data, universe, envelope, device match, topology (this Part) | DELIVERED |
| AR-13 | Decisions and components (Part 6) | DEFERRED |
| AR-14 | Execution, risk, state, recovery (Part 7) | DEFERRED |
| AR-15 | Telegram, security, operations, phases (Part 8) | DEFERRED |
| AR-16 | Verification, implementation, review (Part 9) | DEFERRED |
| AR-17 | Final acceptance (Part 10) | DEFERRED |

**یادداشت پیشرفت (فارسی)**

بخش ۵ از ۱۰ ارائه شد: کلاس‌های داده با پنج معیار و برچسب منبع، قواعد اعتبار داده، استخراج جهان نمادها با مرز پارتو و زنجیرهٔ پنج‌عنصری نقدشوندگی (پارامتری)، پوشش مصرف (envelope)، ارزیابی جداگانهٔ ۹ بار کاری دستگاه و آزمون TP-1.

**نتیجهٔ مهم:** ظرفیت (ذخیره‌سازی، محاسبه، RAM) روی گوشی با قالب فشردهٔ ۷۲ بایتی پوشش داده می‌شود، اما در دسترس‌بودنِ پایدار برای Live و Telegram اثبات‌نشده است (C15، C16). بنابراین **OD-3 مسدودکننده** شد؛ فقط برای انتخاب میزبان Live، نه برای ادامهٔ طراحی. گزینه‌ها در بخش ۶٫۴ آمده است. لطفاً برای هر توپولوژی «در دسترس / در دسترس نیست / نامعلوم» و سقف هزینهٔ ماهانه به USDT را اعلام کنید. OD-1 و OD-2 همچنان در انتظار تصمیم شماست.


Part 6/10: Architectural Decision Records and Component Specifications (AR-13)
Navigation.

Previous: Part 5/10 (AR-12). It delivered data classes DC, validity rules VR, the universe derivation, the envelope EV, the device workloads DW, and the topology fit with OD-3 blocking. Part 6 consumes DC/VR/EV/DW and the host-neutral invariant D5-9.
Next: Part 7/10 (AR-14). Order state machine, risk authority, veto and ack, state ownership, timestamp-role catalog, reconciliation, startup and recovery, the τ_op response table, and the retry bound. Part 7 formalizes the state domains named here.
Engagement boundary (A4). This Part is a design. No code, connection or account action exists. Every statement is DESIGN_JUDGMENT unless it cites a ratified item. Facts about Termux, Android or SQLite are "recalled, not externally verified in this engagement" and are listed as assumptions AS-1…AS-5 with checks in Part 9.

0. Fidelity notes and carry-over
The exact §9.2 field list is not held verbatim. This Part uses ten operational fields (CPF-1…CPF-10, §3), labeled DESIGN_JUDGMENT and audited against the prompt in Part 10.
OD-3 is unanswered. The owner's last message was only a continuation. OD-3 therefore remains BLOCKING for Live-host selection only. Nothing below depends on its answer, because every component is host-neutral (D5-9, HA-1…HA-5). OD-1 and OD-2 also remain OWNER_DECISION_PENDING. No pause is triggered, since the design continues.
Part 5 arithmetic was recomputed as a carry-over check (PC-40). No correction was needed.
Component names in §3 are descriptive roles. They do not fix a framework or library name beyond D6-5, which is delegated (A12).
1. Architectural principles (AP)
Each principle is derived from a hard gate or a ranked criterion. It is not a style preference.

ID	Principle	Derived from
AP-1	Risk-reducing actions never require a permit and are never blocked by a veto. Risk-increasing actions require a fresh, single-use permit from the risk authority.	HG-2, CR-1, DQ-1
AP-2	Unknown, stale or unevaluable state is treated as the most restrictive value. It is never promoted to a safe value.	§9.6, HG-5, VR state vocabulary
AP-3	Every state item has exactly one writing component. Others read it or ask by interface.	CR-1, RQ-RSK-08
AP-4	No component listens for inbound connections from outside the host, and none opens a network path except through the gateway (venue) or the Telegram client.	A9, HG-3
AP-5	Venue signing capability exists only in the Live core process, and only after its mode and interlocks are satisfied.	A4, HG-3
AP-6	The mode (PAPER or LIVE) is fixed at process start. A change is a stop and a start.	CR-1, A10 interlocks
AP-7	Telegram is a command and alert channel, never a trust root and never a safety dependency. Silence is never consent.	A2, A9, HG-6
AP-8	Host specifics are confined to the host adapter. No other component names a phone or a server.	D5-9, CR-8
2. Process boundaries and capabilities
2.1 Process boundaries (PB)
ID	Process	Contains	Credentials	Network	Restarted by
PB-1	CORE (one instance, mode PAPER or LIVE)	CP-1…CP-7, CP-9, CP-10, CP-11 (PAPER only), CP-14, CP-16 (signer, LIVE only)	Venue key, LIVE only	Outbound to the venue	PB-3
PB-2	RISK	CP-8, CP-1, CP-14	None	None (local IPC only)	PB-3
PB-3	CONTROL	CP-12, CP-13, CP-14, CP-16 (Telegram token)	Telegram token	Outbound to Telegram only	The host mechanism (HA-1); non-routine
PB-4	RESEARCH (offline, invoked in a development shell)	CP-15, CP-1, CP-5 (writer), CP-14	None	Outbound, public venue data only	The developer
Notes.

PB-4 is a development activity, not a runtime operator surface, so A2 is respected. It can affect runtime only by writing an immutable release bundle. That bundle activates only through an authenticated Telegram command that quotes the bundle hash and a summary rendered by the core from the bundle (never from the sender).
At most one PB-1 instance runs at a time (single-instance lock in CP-13).
Per-mode files avoid mixing: risk_<mode>.db, orders_<mode>.db and sim.db (PAPER only). Paper risk limits are separate from Live limits (OD-1 supplies both).
PB-2 is a separate process because a fault in ingest, strategy or execution code must not corrupt or bypass risk state (HG-2).
2.2 Capability matrix (KP)
ID	Capability
KP-1	Public venue network
KP-2	Signed venue network
KP-3	Write risk database
KP-4	Write orders database
KP-5	Telegram network
KP-6	Process control
KP-7	Write market databases
Process	KP-1	KP-2	KP-3	KP-4	KP-5	KP-6	KP-7
PB-1 LIVE	✓	✓	✗ (IPC only)	✓	✗	✗	✓ (forward)
PB-1 PAPER	✓	✗	✗	✓ (sim)	✗	✗	✓ (forward)
PB-2	✗	✗	✓	✗	✗	✗	✗
PB-3	✗	✗	✗	✗	✓	✓	✗
PB-4	✓	✗	✗	✗	✗	✗	✓ (historical)
Enforcement: OS file permissions (each database file is opened for writing only by its owner process, HA-3), absence of code in a process (RB rules, §6.3), and absence of secrets in a process (AP-5).

3. Component specifications
3.1 Field list (CPF)
ID	Field
CPF-1	Purpose
CPF-2	Inputs
CPF-3	Outputs
CPF-4	State owned (domain; Part 7 formalizes state items)
CPF-5	Interfaces (IF, §4)
CPF-6	Invariants
CPF-7	Failure modes and response (OCL class)
CPF-8	Dependencies
CPF-9	Host constraints (HA, §5)
CPF-10	Requirement and evidence trace
3.2 Components, Table A (CPF-1…CPF-4)
CP	Name (process)	CPF-1 Purpose	CPF-2 Inputs	CPF-3 Outputs	CPF-4 State owned
CP-1	Clock Service (library in PB-1, 2, 3, 4)	Corrected UTC and elapsed time with an explicit offset state (A3)	Server-time samples (DC-7) via IF-2; local wall and elapsed clocks	t̂; offset state KNOWN, STALE, UNKNOWN, EXCESSIVE; offset age	Offset estimate; last sample with boot identifier
CP-2	Venue Gateway (PB-1; PB-4 public face only)	Sole network path to the venue; global request budget; response classification	Requests via IF-2, IF-3	Classified responses; budget state	Budget and backoff timers (memory)
CP-3	Market Data Validity Engine (PB-1)	Fetch closed bars; apply VR-1…VR-13; record forward data (DC-3)	Public responses; CP-1; universe from CP-5	Bar windows with state (IF-4); δ_bar observations	Per-(symbol, interval) validity state (rebuilt from CP-4 at start)
CP-4	Data Store (writers PB-1 forward, PB-4 historical)	Persist DC-1…DC-7 in the 72 B layout with a source tag	CP-3; CP-15	Windows; depth reports	market_fwd.db, market_hist.db
CP-5	Config and Lineage Registry (writer PB-4; readers PB-1, PB-3)	Immutable content-addressed release bundles: parameters (AC-2/AC-3), universe version, cost branch, activated cells, formula-library version, lineage manifest	Research output; activation command (IF-14)	Verified bundle or refusal	releases/ directory
CP-6	Strategy Engine (PB-1)	Compute FT-1…FT-5; evaluate SC-1/SC-2	IF-4; bundle	IF-5 Signal or Abstain	None (pure given inputs)
CP-7	Sizing and Admission (PB-1)	FM-7…FM-13 sizing; RF refusals; runtime layer of the admission predicate	Signal; venue facts (IF-6); headroom (IF-7)	Sized request (IF-8) or an RF refusal	None
CP-8	Risk Authority (PB-2)	Independent veto and permit authority; sole owner of the risk-state record	IF-7, IF-8, IF-9, IF-12, IF-14 (limits and ack)	Headroom; permits; vetoes; alerts	risk_<mode>.db: risk-state record, committed-risk ledger, veto set
CP-9	Execution Manager (PB-1)	Order lifecycle (Part 7); clientOrderId; protective orders; forced flat; reduce-only path	Consumed permits (IF-9); IF-3	Order events; IF-12 reports	orders_<mode>.db: order journal
CP-10	Reconciler (PB-1)	Compare venue state (ST-4) with the journal; resolve ambiguity	IF-3 queries	IF-11, IF-12 reports; divergences	recon_<mode>.db: results and cursors
CP-11	Paper Venue Simulator (PB-1, PAPER only)	Implement IF-3 semantics with BC conventions; no network	Orders via IF-3; bars via CP-4	Simulated ST-4 events; p_fill and net-per-fill records	sim.db (tagged simulated)
CP-12	Telegram Surface (PB-3)	Outbound long polling; allow-list authentication; command parsing and relay; alert rendering	Updates; outbox cursors	IF-14 commands; operator messages	Update offset and command log (in sup.db)
CP-13	Supervisor (PB-3)	Start, stop and restart PB-1 and PB-2; single-instance lock; heartbeats; outbox drain	IF-13; process table	Control actions; heartbeats; alerts	sup.db: restart counters, mode record, outbox cursors
CP-14	Audit Journal (library per process)	Append-only hash-chained record of decisions, commands and state changes	IF-15	Verifiable chain; chain-break alert	audit_<process>.log (owner process writes)
CP-15	Research Engine (PB-4)	BC backtests, SF statistics, the SD procedure, calibration, release-bundle creation, ST-1 backfill	Market databases; public data	Reports carrying source tags; bundles	market_hist.db, releases/, results
CP-16	Credential Provider (venue reader in PB-1, token reader in PB-3)	Hold secrets and expose only a signing or send capability	Secret storage (at-rest form decided in Part 8)	Capability handle	None
3.3 Components, Table B (CPF-5…CPF-10)
CP	CPF-5 IF	CPF-6 Invariants	CPF-7 Failure and response	CPF-8 Depends on	CPF-9 HA	CPF-10 Trace
CP-1	1, 2	Deadlines use the elapsed clock, never wall time. Dual-clock check: if the elapsed-clock change and the corrected-wall change over an interval differ by more than a tolerance (suspension or clock step), the state becomes UNKNOWN until re-sampled. |θ| > θ_max gives EXCESSIVE. Age beyond A_θ = (θ_max − θ̂_ub)/ρ̂_d gives STALE (drift ρ̂_d estimated offline, AC-2, bound in Part 7).	OCL-5: bars invalid (VR-11); day rollover blocked, which is a veto (Part 7); resident orders unaffected	CP-2 (public)	HA-5	A3, VR-11, PR-32, AS-4
CP-2	2, 3	One scheduler, so no component opens its own socket. Once bytes may have left, any failure is AMBIGUOUS, never REJECTED. Conservative budget (UEF-6) with a hard stop at -1003 and backoff τ_venue (PR-30). The signed face exists only in LIVE. No inbound listener.	OCL-2: classified failure; entries refused; outcomes stay unknown	CP-1, CP-16	HA-4	C4, C5, UEF-6, UEF-13, HG-5
CP-3	2, 4	Only VALID is served. UNKNOWN is never promoted. Untagged records are rejected. C13 fields are dropped at ingest.	OCL-3: STALE, GAP or QUARANTINED; entries refused	CP-1, 2, 4, 5	HA-2	VR-1…VR-13, DC, EV-7
CP-4	none (library)	The source tag is required at write. One writer per file; all other opens are read-only. ingest_time is first-seen time.	OCL-4: integrity check at start; corrupt rows quarantined and refetched from the venue	HA-3	HA-3	D5-4, EV-1, AS-1
CP-5	14	Bundles are immutable and hash-verified at load. The lineage union is recomputed at load (gate point 2). A bundle contains no AC-0 value and no write path to risk state (AD).	Hash or lineage failure: refuse to load, CRIT alert; the previous bundle stays only if it verifies	CP-14	HA-3	D5-2, AD, config-integrity interlock (Part 8)
CP-6	4, 5	Emits only side, stop and reference price. No sizing and no order calls. Abstains on any non-VALID input. Deterministic for equal inputs (replay).	Exception: Abstain plus CRIT counter	CP-3, CP-5	none	SC-1, SC-2, FT
CP-7	5, 6, 7, 8	q comes from FM-9, rounded down. Refusals come from the RF set. Never requests more than B_eff. Headroom must be fresh.	IF-7 failure or staleness: refuse (RF-1, headroom unknown); Part 8 binds text	CP-6, CP-4, CP-8	none	FM-7…FM-13, RF-1…RF-10, CF-5
CP-8	7, 8, 9, 12, 14	Permits are single-use with a TTL on the elapsed clock. Committed risk is released only on confirmed closure or reconciled resolution (HG-5). Unknown, stale or unevaluable state is a hard veto. A veto never blocks risk reduction. A missing or corrupt record means refuse to start. No write path accepts market or account values as initial state (§5).	PB-2 down: no permits, which fails closed; PB-3 restarts it. An audit-write failure on a risk-increasing event means no permit.	CP-1, CP-14, formula library	HA-3	HG-2, §9.6, FM-13, RQ-RSK-08
CP-9	3, 9, 10, 11, 12	No risk-increasing submit without a consumed permit. Position counts as protected only after the resident stop is acknowledged. Reduce-only is never gated. clientOrderId is unique, never reused, charset per C11, length per UEF-8. Bounded retry with a hard stop (Part 7).	AMBIGUOUS leads to TIMEOUT_AMBIGUOUS and then RECONCILING; the permit's committed risk stays	CP-2, 8, 10, 14	HA-1	HG-5, RX-1, RX-2, UEF-1, UEF-8
CP-10	3, 11, 12	Polling baseline (UEF-7). Query by clientOrderId. Never infers rejection from absence until the history-retention bound is known (UEF-8); until then the result is UNKNOWN. The C12 3-day value governs deferral only.	Venue unreachable: divergence UNKNOWN; risk held	CP-2, 9	HA-4	C12, UEF-7, UEF-8
CP-11	3 (provider)	Cannot be constructed in LIVE. No network and no credentials. All outputs tagged simulated. Fill rules follow BC-3/BC-4 using bars only (no depth, C8).	none (pure)	CP-4	none	A10, BC, DQ-3
CP-12	14, 16	Outbound only. Allow-listed identities. Duplicate or stale update ids rejected via the persisted offset. A command's effect is never inferred from silence. Secrets are never rendered.	OCL-1: queue and retry; no state changes by the loss	CP-13, CP-16	HA-4	A2, A9, HG-6
CP-13	13, 16	Holds no venue credential and no trading logic. Children are detached (AS-3). Restarts are bounded by R_max in window W_r (AC-2, pre-registered, UNRESOLVED), after which it stops restarting and sends CRIT. If a startup check needs out-of-band recovery, it refuses to start, alerts naming the check and the procedure, and never recovers inline (§9.8). Liveness uses h_p and τ_proc = m_miss·h_p (PR-31).	PB-3 down: children continue; no routine operator channel; non-routine recovery (Part 7 table)	CP-1, 12	HA-1, HA-2	DQ-2, §9.8, PR-31
CP-14	15	Append-only. Each record carries a sequence number and the previous hash. No secrets.	Chain break: CRIT alert, record flagged	HA-3	HA-3	CR-5, §9.6
CP-15	2 (public)	Holds KP-1 and KP-7 (historical) only. Every result carries source tags (Mode A default). Writes only into releases/ and its own stores. Never opens risk or orders files.	Offline: failure is a failed run	CP-4, CP-5	HA-3	SD, SF, BC, HG-3
CP-16	none (capability handle)	The raw secret never leaves the provider. Loaded only after mode and interlock checks. Never logged.	Missing or invalid: credential interlock fails (Part 8)	none	HA-3	A4, HG-3

4. Interface contracts (IF)
Common rules:

Every request carries a deadline on the elapsed clock.
Any timeout or error toward CP-8 is a DENY for risk-increasing requests and has no effect on risk-reducing ones (AP-1).
Every interface is defined by its message fields and failure semantics. Wire formats are an implementation choice (CA-3) if those semantics are preserved.
ID	From → To	Request	Reply	Failure semantics
IF-1	any → CP-1 (library)	now()	t̂, offset state, offset age	UNKNOWN or EXCESSIVE is returned, never a guess
IF-2	CP-3, CP-15, CP-1 → CP-2	public request(endpoint, params, deadline)	class ∈ {OK, RATE_LIMITED, UNREACHABLE, MALFORMED, TIMEOUT}; payload; RTT	Public failures are retriable and idempotent
IF-3	CP-9, CP-10 → CP-2 (LIVE) or CP-11 (PAPER)	signed request(op, params, clientOrderId, deadline)	class ∈ {ACCEPTED, REJECTED_DEFINITE, AMBIGUOUS, RATE_LIMITED, AUTH_FAIL, CLOCK_FAIL, UNREACHABLE_BEFORE_SEND}	UNREACHABLE_BEFORE_SEND only when provably not sent; every other failure after possible send is AMBIGUOUS (HG-5)
IF-4	CP-3 → CP-6	valid_window(symbol, b, n, t̂)	state ∈ {VALID, STALE, GAP, QUARANTINED, UNKNOWN}; bars; source tags	Non-VALID means Abstain
IF-5	CP-6 → CP-7	(response)	Signal{symbol, cell, side, P_ref, P_stop, bar id, config version, lineage tags, ES label} or Abstain{reason}	Reason codes are recorded in CP-14
IF-6	CP-4 → CP-7	venue_facts(symbol)	DC-4 record with fetch time	Older than one UTC day or absent: UNKNOWN, giving RF-1 (VR-12)
IF-7	CP-7 → CP-8	headroom(symbol, side)	{B_eff, A_head, D_head, H_dd, veto state, record age} or VETO{class}	Timeout is a refusal
IF-8	CP-7 → CP-8	permit_request{signal ref, q, P_e, P_x, d_ref, u components, margin}	PERMIT{id, TTL, approved risk} or DENY{refusal id}	CP-8 recomputes FM-8/FM-9 itself with the shared formula library (D6-9)
IF-9	CP-9 → CP-8	consume(permit id)	CONSUMED{committed risk} or REFUSED	Atomic and single-use; expired or consumed means REFUSED
IF-10	CP-9 internal	reduce_only(position, reason)	none: no permit and no veto check	CP-8 is told afterward via IF-12
IF-11	CP-10 → CP-9	divergence report	Resolution instruction	Only CP-9 mutates order state
IF-12	CP-9, CP-10 → CP-8	observation{sequence, kind ∈ fill, equity, position, order state; source tag; time roles}	ack(sequence)	Unacked observations are resent; CP-8 deduplicates by sequence
IF-13	CP-13 ↔ PB-1, PB-2	start, stop, status, heartbeat	Process state	Missing heartbeats lead to the restart policy
IF-14	CP-12 → CP-13 → CP-5, 8, 9	command{id, nonce, issue time, type, args}	Result or refusal with identifier	Stale, duplicate or unauthorized: refusal; commands list in Part 8
IF-15	any → CP-14	record{role timestamps, component, kind, payload hash}	none (durable append)	Failure on a risk-increasing path means no permit
IF-16	PB-1, PB-2 → CP-13	alert{severity, class, code, text} written to the producer's own outbox file	Cursor advance by CP-13	Durable. If CP-13 is absent, the alert waits and is not lost.
5. Risk-state write paths (RQ-RSK-08, Part 6 portion)
The risk-state record is written only by CP-8 through the paths below. No path accepts market or account values as initial state.

ID	Path	Trigger and source	Guard
WP-1	Owner limits (PR-1…PR-5)	Owner command via IF-14	Confirmation exchange; validation against OD-1 form; tightening applies at once, loosening per the Part 8 rule
WP-2	Observation accrual	IF-12 (fills, realized PnL)	Sequence deduplication; source tag ST-4 or simulated
WP-3	Day and ISO-week rollover	CP-8's own evaluator at UTC boundaries	Only if the clock is KNOWN; otherwise veto
WP-4	Veto set and clear	CP-8's evaluators	Set on any failing condition; clear only by the class's own recovery condition (Part 7). /ack never clears.
WP-5	Permit ledger	IF-8, IF-9 and closure events	Single-use; committed risk released only on confirmed closure or reconciled resolution
WP-6	Restore or audited acknowledgement	Out-of-band procedure with PB-2 STOPPED	Restore from a backup artifact or an owner-supplied initial record with an audited acknowledgement
Equity.

The risk basis (OD-1 basis) plus accrued realized results (WP-2) form the record's equity.
Observed account equity from the reconciler is cross-checked against it. A divergence beyond a tolerance is a veto (tolerance is parametric; Part 7 binds the class).
The observation never overwrites the record.
Initialization rule.

If the record is missing or corrupt at start, PB-2 refuses to start.
It sends a CRIT alert naming the check and pointing to the WP-6 procedure.
Live is refused meanwhile, per §9.6 and §9.8.
6. Host adapter, technology and repository
6.1 Host adapter functions (HA)
ID	Function	Phone binding (examples, recalled, not verified)	Off-device binding
HA-1	Launch detached processes; report exit; boot hook	Termux services or boot add-on; owner-side setup	Service manager of the host
HA-2	Keep-alive and wake discipline; report host power and standby state	Wake lock; battery-optimization exemption (C15: charging is not an exemption)	Not required beyond the service manager
HA-3	Private storage root (owner-only permissions); free-space probe; fsync	App-private directory	Dedicated directory with owner-only permissions
HA-4	Outbound reachability probe to the venue and Telegram (UEF-13)	Mobile or Wi-Fi network	Host network
HA-5	Clock source, boot identifier (the elapsed clock may reset at reboot)	Android clock, boot id	Host clock, boot id
Reboot rule. A deadline stored across a restart is invalid. Persisted deadlines are re-derived from corrected wall time and a stored boot id (Part 7 timestamp roles).

6.2 Technology decisions
These are delegated (A12) and recorded in §8 as D6-5 to D6-9.

Runtime: Python 3, standard library first, minimal third-party dependency.
Persistence: SQLite in WAL mode, with full synchronization for risk and order files. One file per ownership domain.
IPC: Unix domain sockets in the private directory, request-reply.
Formulas: one shared pure-function library used by research, strategy, sizing and risk (D6-9).
6.3 Repository blueprint (justified)
Justification.

AP-3 and AP-5 are enforced by capability boundaries.
Absence of code is a stronger guard than convention.
A static import-graph test (Part 9) can verify import rules mechanically.
The blueprint is therefore a verification instrument. Otherwise it would not be proposed.
ID	Package	Contains	May import	Must not import
RB-1	schema	Record layouts, enums, tags, states, refusal ids	none	all
RB-2	formulas	FM, FT, VR pure parts	RB-1	all other
RB-3	clock	CP-1	RB-1	all other
RB-4	audit	CP-14	RB-1	all other
RB-5	venue_pub	CP-2 public face	RB-1, 3, 4	RB-6, 7
RB-6	venue_sig	CP-2 signed face, venue part of CP-16	RB-1, 3, 4	RB-7, 12, 13
RB-7	venue_sim	CP-11	RB-1, 2, 3, 4, 8	RB-6
RB-8	data	CP-3, CP-4, CP-5 reader	RB-1, 2, 3, 4, 5	RB-6, 10
RB-9	strategy	CP-6, CP-7	RB-1, 2, 3, 4, 8	RB-6, 10, 11, 12
RB-10	risk	CP-8	RB-1, 2, 3, 4	RB-5, 6, 7, 8, 9, 11, 12, 13
RB-11	exec	CP-9, CP-10	RB-1, 2, 3, 4, 5, 6, 7	RB-12, 13
RB-12	control	CP-12, CP-13, token part of CP-16	RB-1, 3, 4	RB-6, 9, 10, 11, 13
RB-13	research	CP-15, CP-5 writer	RB-1, 2, 3, 4, 5, 8	RB-6, 10, 11, 12
6.4 Assumptions requiring verification (AS)
ID	Assumption	Check (Part 9 or pre-Live)
AS-1	Python 3 and SQLite (WAL, full sync) are available in Termux and crash-consistent on the device storage	Install probe; kill and power-loss injection (VM-5)
AS-2	Unix domain sockets work between separate Termux processes in the private directory	Probe (VM-4)
AS-3	A detached child survives termination of its parent	Probe (VM-5)
AS-4	The elapsed clock used for deadlines may exclude suspended time on Linux-based hosts (recalled domain fact), so the dual-clock check (CP-1) is required	Measure across screen-off sleep (joins MQ-1, MQ-6)
AS-5	Other apps on the device cannot read the private directory	Permission audit (VM-3)
7. DQ-2 / CF-1 resolution and outage walk
7.1 Selected candidate and test
Selection. A minimal always-on supervisor (PB-3) hosts the Telegram surface. It holds no venue credential and no trading logic.

Case	Situation	Result
1	Core stopped, supervisor running	The operator can restart it by command, subject to startup checks and command preconditions (Part 8)
2	Core stopped and a startup check needs out-of-band recovery	Refuse to start, CRIT naming the check, pointer to the procedure; no inline recovery
3	Supervisor stopped	No Telegram. Children continue. Recovery is a non-routine procedure on a STOPPED supervisor (Part 7 table). Routine safety is unaffected.
4	Telegram network down, supervisor running	Autonomous restart policy continues; alerts wait in outboxes; no limit is released
5	Host or phone down	Only resident protective orders remain (if UEF-1 holds). The τ_op response table (Part 7) defines the response for the forced-flat deadline.
7.2 Outage walk (OCL classes at architecture level)
Class	Behavior in the Part 6 design
OCL-1 operator channel	CP-12 queues; no component treats silence as consent or release; the position policy is in Part 7 (τ_op) and OD-4
OCL-2 venue interface	Gateway returns UNREACHABLE or AMBIGUOUS; entries refused; committed risk held; reduce-only attempts bounded (Part 7)
OCL-3 data feed	VR-9 STALE; entries refused; resident stops unaffected
OCL-4 process or host	Supervisor restart policy; PB-2 down means no permits; PB-1 down means no entries; both down leaves only resident orders
OCL-5 clock	CP-1 UNKNOWN or EXCESSIVE; bars invalid; rollover blocked; resident orders unaffected
Compound	The most restrictive response of the members applies
8. Decision records
All evidence labels are DESIGN_JUDGMENT, traced to the cited criteria.

ID	Decision	Rejected alternative, with its positive reason	Reversibility	Deciding criterion
D6-1	Three runtime processes plus offline research (PB-1…PB-4)	Single process: fewest moving parts, no IPC, lowest memory (CR-6 favors it), but one fault in ingest or strategy would also take down risk and Telegram, violating HG-2 and DQ-2. One process per component: maximal isolation, but more IPC failure modes and phone resource cost than the isolation buys	COSTLY_REVERSIBLE	CR-1, then CR-6
D6-2	Risk authority in its own process, with single-use permit consumption; risk reduction exempt (AP-1)	In-process veto library: no IPC failure mode and faster, but a core fault shares memory with the veto and could bypass it	COSTLY_REVERSIBLE	CR-1 (HG-2)
D6-3	Supervisor hosts Telegram (resolves DQ-2)	Telegram inside the core: one fewer process, but a core stop would remove the recovery channel. Webhook or relay host: convenient push delivery, but it needs an inbound path (A9) and an extra trust boundary (TP-5 dominated)	COSTLY_REVERSIBLE	CR-1, CR-6
D6-4	Mode fixed at process start; one core instance; Paper has no signed face and no credential	Runtime flag flip: instant switching and no restart, but one flag error from a real order and credentials resident during Paper	REVERSIBLE	CR-1 (A10 interlocks)
D6-5	Python 3, stdlib first	Rust or Go: faster and statically checked, but a toolchain and cross-compilation burden on the reference device (DW-1, AS-1 unverified) and slower iteration. The runtime may change per component under CA-3 if the interface is preserved	COSTLY_REVERSIBLE	CR-4, CR-5
D6-6	SQLite per ownership domain; hash-chained audit log	Flat files with custom flush logic: no database dependency, but crash-consistency code would be hand-written. Embedded key-value store: simple for single records, but weaker ad-hoc inspection for audit	REVERSIBLE	CR-1, CR-5
D6-7	Unix domain sockets	Loopback TCP: portable across hosts, but other local apps can connect (AP-4). Database-mediated queue: needs no sockets, but polling latency and weaker request-reply semantics for permit consume	REVERSIBLE	CR-1
D6-8	One outbound gateway with a global budget; hard stop on rate-limit breach	Per-component clients: simpler per component, but the budget cannot be enforced globally and UEF-6 is unknown	REVERSIBLE	CR-1
D6-9	Single shared formula library, with test vectors from HS-1 (WE)	Independent re-implementation inside the risk authority: protects against a common-mode formula bug, but two implementations drift and cause spurious refusals. Independence is of state, process and authority. The common-mode risk is disclosed and mitigated by vectors	REVERSIBLE	CR-2, CR-6
D6-10	Host adapter HA-1…HA-5	Phone-specific core: simpler today, but a failed MQ-1 would force a redesign	COSTLY_REVERSIBLE	CR-8
D6-11	Per-producer durable alert outboxes, drained by the supervisor	Direct send from the core: simpler, but a Telegram outage would block the core path and put a second network client in PB-1	REVERSIBLE	CR-1 (HG-6)
D6-12	Bounded automatic restart by the supervisor; no entries resume after an unclean exit until reconciliation (Part 7)	No automatic restart (operator only): safest against crash loops, but it makes availability depend on the operator channel, which A9 forbids assuming	REVERSIBLE	CR-1, CR-4
D6-13	Per-mode risk and order files	Shared files with a mode column: one schema, but a Paper bug could write Live risk state	REVERSIBLE	CR-1
D6-14	Repository blueprint (RB-1…RB-13) with an import-graph test	No blueprint (flat package): lower overhead, but capability boundaries could erode silently	REVERSIBLE	CR-5
9. Dispositions and propagation
Item	Disposition after Part 6
DQ-2 / CF-1	Resolved at design level: supervisor hosting Telegram, tested in §7.1. Commands and preconditions complete in Part 8.
RX-2	Unchanged, UNRESOLVED; resolved in Part 7
RX-5	Unchanged (OD-3, MQ-1…MQ-3)
OD-3	Still BLOCKING for host selection only
Register status	No row changes status in Part 6. Component specifications supply evidence for later acceptance checks. Statuses move only when an acceptance condition is fully evaluated (Part 9). RQ-RSK-08 receives its Part 6 write-path portion here and remains NOT TESTED.
Resolved pending propagation (§2.1.5).

Part 7: the state-ownership table must match the files in CP-4…CP-14. The τ_op table must take supervisor liveness as an OCL-1/OCL-4 input. The clock-offset age bound A_θ and the reconciliation-divergence tolerance must be bound there.
Part 8: the command set must include mode start and stop, bundle activation with hash confirmation, and owner-limit entry through WP-1. The lineage refusal needs an identifier.
Part 9: the import-graph test and the AS-1…AS-5 checks join the verification matrix.
10. Part checks PC-33…PC-40 (author self-inspection; not independent proof)
PC	Check	Method	Result
PC-33	All 16 components carry CPF-1…CPF-10, each state domain has one owner, and no component has an empty field	VM-3 over Tables A and B	PASS
PC-34	Capability matrix: PB-4 lacks KP-2, KP-3, KP-5 and KP-6. PAPER core lacks KP-2. PB-2 has only KP-3.	VM-3	PASS
PC-35	Interface closure: IF-1…IF-16 each have a provider and a consumer, and each CP input maps to an IF or a library call	VM-3 matrix	PASS
PC-36	Write-path enumeration: WP-1…WP-6 cover every record mutation. None accepts market or account values as initial state.	VM-3	PASS
PC-37	Outage walk covers all five OCL classes plus compound	VM-3	PASS
PC-38	DQ-2 walk: five cases, each with a defined outcome	VM-3	PASS
PC-39	Import rules (RB) trace to AP-3, AP-5, HG-3. Each prohibition has a stated reason.	VM-3	PASS
PC-40	Identifier integrity (§11); no USD; no OD-1 anchors; no "Class-A" label; Part 5 arithmetic recomputed (69,715; 24,500; 1.764 MB; 5.019 MB; 62.5 MB; 177.84 MB; 191; 25,594; 236; 16,992; 588,000; 78,792,000; 1,600,000; inflations 1.13/1.19/1.30/1.39; waits 4.175…1.102)	VM-2, VM-3	PASS
Register status after Part 6, unchanged: PASS 20, NOT TESTED 38, UNRESOLVED 4, BLOCKED 3, FAIL 0, total 65. The next check identifier is PC-41.

11. Completeness declaration
Catalogs defined in this Part (each fully defined here only).

Catalog	Range	Count
AP	AP-1…AP-8	8
PB	PB-1…PB-4	4
KP	KP-1…KP-7	7
CPF	CPF-1…CPF-10	10
CP	CP-1…CP-16	16
IF	IF-1…IF-16	16
WP	WP-1…WP-6	6
HA	HA-1…HA-5	5
RB	RB-1…RB-13	13
AS	AS-1…AS-5	5
D6	D6-1…D6-14	14
PC	PC-33…PC-40	8
Referenced-only catalogs. Part 1: A, C, UEF, CF, HG, CR, DQ, TP, AR. Part 2: RQ, OCL, OD, RX, VM, CA. Part 3: FM, HS, WE, RF. Part 4: FT, SC, BC, SD, AD, AC, PR. Part 5: DC, ST, VR, DW, MQ, EV, D5.

Dangling-identifier audit. No identifier is used without a defining catalog. Forward references are by description only: the state items and the τ_op table (Part 7), the command and refusal identifiers (Part 8), and the at-rest secret form (Part 8). The symbols A_θ, R_max, W_r and ρ̂_d are local derived quantities bound in Parts 7–8, not catalog identifiers.

Duplicate-definition audit. No identifier defined here appears in an earlier catalog. PC-33…PC-40 continue from PC-32.

Artifact registry.

AR	Content	Status
AR-01…AR-12	Parts 1–5	DELIVERED
AR-13	Architectural decisions and components (this Part)	DELIVERED
AR-14	Execution, risk, state, recovery (Part 7)	DEFERRED
AR-15	Telegram, security, operations, phases (Part 8)	DEFERRED
AR-16	Verification, implementation, review (Part 9)	DEFERRED
AR-17	Final acceptance (Part 10)	DEFERRED
یادداشت پیشرفت (فارسی)

بخش ۶ از ۱۰ ارائه شد: اصول معماری، چهار فرایند (هسته، مرجع ریسک، کنترل/تلگرام، پژوهش آفلاین)، ماتریس قابلیت‌ها، مشخصات ۱۶ جزء با ده فیلد، قراردادهای واسط، مسیرهای نوشتن وضعیت ریسک، آداپتور میزبان، طرح مخزن کد با آزمون گراف import، و ۱۴ رکورد تصمیم با گزینه‌های ردشده.

نتایج کلیدی:

مسئلهٔ DQ-2 حل شد: یک ناظر (supervisor) حداقلی تلگرام را میزبانی می‌کند. این ناظر اعتبارنامهٔ صرافی و منطق معاملاتی ندارد.
مرجع ریسک فرایند جداست و بدون مجوز یک‌بارمصرف او هیچ سفارش ریسک‌افزا ارسال نمی‌شود. سفارش‌های کاهندهٔ ریسک هرگز مسدود نمی‌شوند.
ساعت: مکانیزم بررسی دوگانهٔ ساعت (برای خواب دستگاه) طراحی شد. فرض مربوط به آن در AS-4 ثبت شد و هنوز اندازه‌گیری نشده است.
وضعیت ردیف‌ها: هیچ ردیفی در این بخش تغییر نکرد (۲۰ PASS، ۳۸ NOT TESTED، ۴ UNRESOLVED، ۳ BLOCKED).
OD-1 و OD-2 همچنان در انتظار تصمیم شماست و OD-3 فقط برای انتخاب میزبان Live مسدودکننده است. طراحی مستقل از پاسخ شما ادامه دارد. هیچ عملیات احراز هویت‌شده‌ای انجام نشده است (A4). برای ادامه، «ادامه» بفرستید تا بخش ۷ (ماشین حالت سفارش، مرجع ریسک، veto/ack، مالکیت وضعیت، تطبیق، بازیابی و جدول τ_op) ارائه شود.


# Part 7/10: Order Lifecycle, Risk Authority, State Ownership, Reconciliation, Recovery, Operator-Unreachable Response (AR-14)

**Navigation.**
- **Previous: Part 6/10 (AR-13).** It delivered components CP-1…CP-16, interfaces IF-1…IF-16, write paths WP-1…WP-6, host adapter HA, and decisions D6-1…D6-14. Part 7 formalizes the behavior behind them.
- **Next: Part 8/10 (AR-15).** It binds the Telegram command set and preconditions, the six selector interlocks, refusal texts and identifiers, security, operations, the procedural consistency table over RP-1…RP-10 (§9), phases (PDT), and the OD-4 ratification request.

**Engagement boundary (A4).** Nothing is executed or observed on the venue. Every behavior is DESIGN_JUDGMENT unless it cites a ratified C-item. Numeric examples are labeled teaching constants or HS-1 hypotheticals and are not design values.

## 0. Fidelity notes and carry-over

1. The §9.7 state list is used exactly as ten states. Event, transition and race catalogs (EN, TX, FR) are operational readings, audited in Part 10.
2. **Owner decisions.**
   - OD-3 remains BLOCKING for Live-host selection only. Nothing below names a host (D5-9).
   - OD-1 and OD-2 remain OWNER_DECISION_PENDING. No pause is triggered, because the design continues without them.
   - Every limit in this Part is a parameter.
3. **Part 6 propagation items closed here:**
   - state ownership matches the Part 6 files (§6);
   - the τ_op table takes supervisor liveness as an input (§8);
   - the clock age bound A_θ (§1.2) and the equity-comparison rule (§7) are bound.
4. **Residual risk disclosed (RR-1).** A resting passive entry order outlives a dead core, because no credential-less process can cancel it. A fill in that window leaves a position without a resident stop. Mitigation and gate: §4.4. It joins the OD-4 ratification scope in Part 8.

## 1. Timestamp-role catalog

### 1.1 Roles (TR)

Each stored timestamp names its role. Roles are never interchangeable.

| ID | Role | Clock source | Used for | Forbidden use |
|---|---|---|---|---|
| TR-1 | VENUE_EVENT | Venue-stamped fill/order time | Day attribution (§1.3), audit | Deadlines, ordering of local actions |
| TR-2 | BAR_OPEN t_o | UTC epoch grid (VR-2) | Bar identity | Freshness |
| TR-3 | BAR_CLOSE t_o+b | Grid arithmetic | VR-1 usability | n/a |
| TR-4 | FIRST_SEEN | Corrected UTC at ingest | δ_bar measurement (AC-2) | Deadlines |
| TR-5 | DECISION | Corrected UTC plus bar id | Signal lineage | n/a |
| TR-6 | INTENT_CREATED | Corrected UTC, elapsed, boot id | Order journal | n/a |
| TR-7 | SEND_STAMP | Elapsed at dispatch, corrected UTC | RTT, ambiguity windows | n/a |
| TR-8 | DEADLINE | Elapsed plus boot id only | Order, retry, cancel and permit deadlines | Wall-clock comparison |
| TR-9 | PERMIT_EXPIRY | Elapsed plus boot id | Permit TTL | n/a |
| TR-10 | OFFSET_SAMPLE | Local elapsed at receipt plus server time (DC-7) | CP-1 estimate | n/a |
| TR-11 | COMMAND_ISSUE | Telegram message time (untrusted) | Staleness refusal only | Ordering (update id orders) |
| TR-12 | AUDIT_TIME | Corrected UTC plus offset-state label | CP-14 | n/a |
| TR-13 | HEARTBEAT | Sender elapsed plus boot id; receiver uses its own arrival elapsed | Liveness, d_op | Cross-process comparison of sender elapsed values |
| TR-14 | BOUNDARY | UTC day and ISO-8601 week instants from corrected UTC | Rollover (WP-3) | Evaluated only if the offset is KNOWN |
| TR-15 | FLAT_DEADLINE t_flat(D) | 24:00 UTC − τ_exit (IV) | Forced flat | Late-side evaluation |

**Reboot rule.** A deadline persisted across a restart is invalid. The boot id changes, so the deadline is re-derived from corrected UTC or the intent is re-decided.

### 1.2 Offset-state behavior (OB)

States come from CP-1 (A3). The staleness age bound is derived below.
- Worst-case offset at use = θ̂_ub + ρ̂_d·age. The state is STALE when this exceeds θ_max.
- A_θ = (θ_max − θ̂_ub)/ρ̂_d.
- Teaching example: θ_max = 0.5 s, θ̂_ub = 0.1 s, ρ̂_d = 5·10⁻⁵ gives A_θ = 0.4/0.00005 = 8,000 s = 2.22 h. These are not design values.
- The sampling interval is at most A_θ/m_θ, with m_θ ≥ 2.
- θ_max = ε_c·δ_bar with ε_c < 1 (PR-32).

| OB | State | Bars | New entries | Rollover (WP-3) | Forced flat (TR-15) | Audit label |
|---|---|---|---|---|---|---|
| OB-1 | KNOWN | VALID per VR | Allowed | Allowed | Trigger when t̂ + θ̂_ub ≥ t_flat (early side) | KNOWN |
| OB-2 | STALE | None VALID | Vetoed (VC-8) | Blocked | Trigger when t̂ + θ̂_ub + ρ̂_d·age ≥ t_flat | STALE |
| OB-3 | UNKNOWN | None VALID | Vetoed | Blocked | Elapsed-clock fallback is not trusted (dual-clock failure). If UNKNOWN persists ≥ τ_cu, close-all (XP-6). | UNKNOWN |
| OB-4 | EXCESSIVE (\|θ\| > θ_max) | None VALID | Vetoed | Blocked | Trigger at t̂ + max(\|θ̂\|, θ_max) ≥ t_flat | EXCESSIVE |

τ_cu is pre-registered (AC-2). It is at least 2 sampling intervals and at most τ_exit, so a close-all can complete inside the exit window. Resident orders are never affected by clock state.

### 1.3 Day attribution of venue events

Rollover uses corrected UTC. An event within ±θ̂_ub of a UTC-day or ISO-week boundary is ambiguous, and the conservative rule applies:
- a loss counts against both periods;
- a gain counts in neither.

This preserves net daily accounting (FM-13) and never loosens a limit.

## 2. Order state machine (RQ-EXE-01…RQ-EXE-04 evidence)

### 2.1 States, events (OS, EN)

**States (OS).** OS-1 INTENT, OS-2 SUBMITTED, OS-3 ACKNOWLEDGED, OS-4 PARTIALLY_FILLED, OS-5 FILLED (terminal), OS-6 CANCEL_PENDING, OS-7 CANCELLED (terminal), OS-8 REJECTED (terminal), OS-9 TIMEOUT_AMBIGUOUS, OS-10 RECONCILING. Each order stores: cid, role (E entry, S stop, X exit, F forced-flat), side, quantity q, reduce-only flag, cumulative filled quantity c, permit id (entries), deadlines (TR-8), and an append-only event list.

**Events (EN).**

| ID | Event |
|---|---|
| EN-1 | Intent created (entry needs a consumed permit; S, X, F need none) |
| EN-2 | Dispatch: cid and journal row durable, then the gateway sends |
| EN-3 | Gateway proves not sent (UNREACHABLE_BEFORE_SEND) |
| EN-4 | Venue explicit rejection with a code in the definite-reject set (DRS) |
| EN-5 | Venue ack |
| EN-6 | Fill report, c < q |
| EN-7 | Fill report, c = q |
| EN-8 | Cancel requested (deadline, risk directive, operator) |
| EN-9 | Cancel confirmed by the venue |
| EN-10 | Cancel refused with "unknown order" or "already filled" |
| EN-11 | Ambiguous result (timeout, malformed, unlisted code, unknown class after possible send) |
| EN-12 | Reconciliation result: open, with c |
| EN-13 | Reconciliation result: filled |
| EN-14 | Reconciliation result: cancelled, with c |
| EN-15 | Reconciliation result: confirmed absent (NF conditions) |
| EN-16 | Reconciliation inconclusive |
| EN-17 | d_ack elapsed with no ack |
| EN-18 | Entry window lapsed before dispatch |

**DRS.** The definite-reject set is a closed list of venue codes catalogued as non-ambiguous. An unlisted code is EN-11. C5 puts -1007 outside DRS (ambiguous). A rate-limit code (-1003) is in DRS but also triggers the gateway hard stop (CP-2). The list is populated at implementation from documentation, never inferred.

**NF conditions** (all required for EN-15):
1. A query by clientOrderId returned a definite NOT_FOUND after a settle delay.
2. The same cycle's open-orders and position queries show no exposure consistent with the order.
3. The venue history-retention bound is VERIFIED (UEF-8) and the order age is inside it.

Until UEF-8 is verified, EN-15 never fires. The order stays RECONCILING with its risk held (HG-5).

### 2.2 Transition table (TX)

Any (state, event) pair not listed is ILLEGAL. An illegal pair causes no state change, a CRIT audit record, and VC-5.

| TX | From | Event | Guard | To | Actions |
|---|---|---|---|---|---|
| TX-1 | INTENT | EN-2 | cid durable; entries have a consumed permit; X/F/S flagged reduce-only | SUBMITTED | Record TR-7; start d_ack |
| TX-2 | INTENT | EN-3 | Provably not sent | REJECTED (NOT_SENT) | Release permit's committed risk |
| TX-3 | INTENT | EN-18 | Entry window lapsed | REJECTED (EXPIRED_UNSENT) | Release committed risk |
| TX-4 | SUBMITTED | EN-4 | Code in DRS | REJECTED | Release committed risk; classify |
| TX-5 | SUBMITTED | EN-5 | n/a | ACKNOWLEDGED | n/a |
| TX-6 | SUBMITTED | EN-6 / EN-7 | Fill before ack | PARTIALLY_FILLED / FILLED | Apply fill (§2.3) |
| TX-7 | SUBMITTED | EN-11 or EN-17 | n/a | TIMEOUT_AMBIGUOUS | Hold committed risk |
| TX-8 | ACKNOWLEDGED | EN-6 / EN-7 | n/a | PARTIALLY_FILLED / FILLED | Apply fill |
| TX-9 | ACKNOWLEDGED | EN-8 | n/a | CANCEL_PENDING | Dispatch cancel; start d_c |
| TX-10 | PARTIALLY_FILLED | EN-6 | c grows monotonically | PARTIALLY_FILLED | Apply fill |
| TX-11 | PARTIALLY_FILLED | EN-7 | n/a | FILLED | Apply fill |
| TX-12 | PARTIALLY_FILLED | EN-8 | n/a | CANCEL_PENDING | Dispatch cancel |
| TX-13 | CANCEL_PENDING | EN-9 | n/a | CANCELLED (c ≥ 0) | Release the unfilled share only now |
| TX-14 | CANCEL_PENDING | EN-6 | n/a | CANCEL_PENDING | Apply fill |
| TX-15 | CANCEL_PENDING | EN-7 | Fill wins | FILLED | Apply fill; cancel moot |
| TX-16 | CANCEL_PENDING | EN-10, EN-11 or d_c elapsed | n/a | RECONCILING | Query; position state unknown until resolved |
| TX-17 | TIMEOUT_AMBIGUOUS | automatic | Query dispatched | RECONCILING | Start reconciliation (RC) |
| TX-18 | RECONCILING | EN-12 | n/a | ACKNOWLEDGED, or PARTIALLY_FILLED if c > 0 | If a cancel was pending, re-issue under RT-3 |
| TX-19 | RECONCILING | EN-13 | n/a | FILLED | Apply fill |
| TX-20 | RECONCILING | EN-14 | n/a | CANCELLED | Apply fills; release the unfilled share |
| TX-21 | RECONCILING | EN-15 | NF conditions hold | REJECTED (RESOLVED_ABSENT) | Release committed risk |
| TX-22 | RECONCILING | EN-16 | n/a | RECONCILING | Back off; retry under RT-6; VC-6 once aged beyond T_amb |

**Terminal states.** FILLED, CANCELLED and REJECTED never transition. A fill report on a terminal order is ILLEGAL and recorded as DG-5. The exposure is still applied to the position record, protection is evaluated at once, and VC-5 is raised.

**Cancel before ack.** A cancel request while SUBMITTED sets a flag. On ACK the order moves to CANCEL_PENDING (TX-5 followed by TX-9). If the result is ambiguous, TX-7 applies.

### 2.3 Fill accounting and races (FR)

- Cumulative filled quantity c is monotone. A report with a smaller c than recorded is ILLEGAL.
- A fill is applied once, keyed by the venue trade id if present (UEF-8), otherwise by (cid, c).
- Applying a fill:
  - (1) update the position;
  - (2) send the observation to CP-8 (IF-12);
  - (3) evaluate protection (§3).
- Order of effects is journal, then risk observation, then protection action.
- **A fill always wins over a cancel.** Cancel is a request. Only confirmation or reconciliation proves non-execution.

| FR | Race | Resolution |
|---|---|---|
| FR-1 | Cancel requested, fill arrives first | TX-15 or TX-14; position grows; stop sized to c; cancel moot or confirmed later |
| FR-2 | Cancel confirmed, a later fill report names the order | ILLEGAL (terminal); DG-5; exposure applied; VC-5 |
| FR-3 | Partial fill, then cancel confirmed | CANCELLED with c > 0; stop covers c; committed risk drops to c's share |
| FR-4 | Submit ambiguous, fill discovered by reconciliation | TX-17 then TX-19; protection starts at discovery (not at the fill's venue time) |
| FR-5 | Stop triggers while a manual or forced exit is in flight | Both are reduce-only; the venue's reduce-only semantics prevent reversal (UV-2). Neither is cancelled until the position is confirmed flat. |
| FR-6 | Fill report and ack arrive out of order | TX-6 accepts a fill in SUBMITTED. A late ack on a FILLED order is ignored and journaled. |

### 2.4 Idempotency and clientOrderId (CID)

- **Format.** `<mode 1><role 1><gen 3><seq 9><chk 2>`, 16 characters from [A-Za-z0-9_-] (C11).
  - mode: L or P.
  - role: E, S, X or F.
  - gen and seq: base-36.
  - chk: two characters of a hash of the preceding 14.
- **Capacity.** 36⁹ = 101,559,956,668,416 sequence values per generation. The 3-character generation gives 36³ = 46,656 values, which is 127.7 years of daily generations.
- **Write-ahead.** seq is incremented and committed (full sync) before dispatch. A cid is never reused, including when the order was never sent.
- **Counter loss or journal restore.** Procedure RP-7 sets gen to the larger of (days since 2024-01-01 UTC, from a KNOWN clock) and 1 + the highest gen visible in any artifact or venue query. Format validity at the venue (maximum length, uniqueness semantics) is UEF-8 and UV-6, verified before Live.
- **No blind resend.** An order is dispatched exactly once per cid. After EN-11 the only action is a query by cid.

## 3. Protective orders and the position-protection machine

### 3.1 Protection states (PS)

Per position:

| ID | State | Meaning |
|---|---|---|
| PS-1 | FLAT | Position zero |
| PS-2 | EXPOSED | Position nonzero, no acknowledged resident stop covering it |
| PS-3 | PROTECTING | Stop submitted, awaiting ack |
| PS-4 | PROTECTED | Acknowledged reduce-only stops cover the full quantity at P_s or beyond |
| PS-5 | UNDER_PROTECTED | Position grew; acknowledged cover is less than position |
| PS-6 | CLOSING | An X or F order is in flight |
| PS-7 | PROTECTION_FAILED | Retry bound exhausted for a stop |

**Rules.**
- The first fill report moves FLAT to EXPOSED, and a stop S is dispatched at once.
- **Delta stops.** On later fills a new reduce-only stop is placed for the delta only (PS-5 until acked). This needs only place and cancel semantics. Amend semantics are not required (UV-4 reduced).
- A position counts as protected only in PS-4. The committed-risk ledger treats every other state as fully exposed.
- Stop price P_s comes from the signal, preserving the sizing assumption (FM-7, FM-8).
- Stop order failure follows RT-4. After the bound is exhausted (PS-7) the emergency exit XP-5 starts and VC-12 is raised.
- Stops and targets are cancelled only after the position is confirmed flat (FR-5).
- **Maximum unprotected window** W_prot = W_retry(RT-4). Worst-case total exposure before the emergency path starts is W_prot plus the reconciliation cycle T_rc.
- PS-3, PS-5 and PS-7 survive restart in the journal. At startup, SK-10 re-evaluates every position.

### 3.2 Exit paths (XP) (RQ-EXE-05 and RX-1 exit-path check)

All exit orders are reduce-only (UV-2) and never need a permit or a veto check (AP-1). The cost branch is the taker side (RX-1: entries may be maker, exits may cross).

| XP | Exit path | Trigger | Order | Failure response |
|---|---|---|---|---|
| XP-1 | Resident stop | Price reaches P_s | Venue-resident stop, reduce-only | Gap: realized loss q(u+g) (FM-19) |
| XP-2 | Strategy target (SC-2) | Venue fills a resting profit order | Maker, reduce-only | If unfilled by t_flat: XP-4 |
| XP-3 | Strategy exit (SC-1) | Time-based exit per Part 4 | Taker, reduce-only | RT-5 |
| XP-4 | Forced flat | TR-15 reached | Taker, reduce-only; stops stay until flat (FR-5) | RT-5; then XP-5 |
| XP-5 | Emergency exit | PS-7, or an XP-3/XP-4 retry bound exhausted | Taker, reduce-only; repeated under RT-5 at bounded rate | HARD_STOP: CRIT; entries vetoed (VC-12); polling reconciliation continues |
| XP-6 | Close-all | Directive from CP-8 or CP-9 backstop (§8), or OB-3 beyond τ_cu | As XP-4, all positions; pending entries cancelled | As XP-5 |
| XP-7 | Operator flatten | Telegram command (Part 8) | As XP-4 | As XP-5 |

**Forced-flat arithmetic.** An entry decision at t_e has T_max(t_e) = t_flat − t_e (IV-2). The start of XP-4 leaves τ_exit ≥ W_retry + T_rc before 24:00 UTC (PR-21), so one full retry sequence plus a reconciliation check fits.

## 4. Retry bounds, rate behavior and entry protection

### 4.1 Retry classes (RT)

Parameters: b₀ (base delay), d_a (per-attempt deadline), N_r (maximum attempts).
- Waits between attempts: b₀, 2b₀, …, 2^{N_r−2}·b₀. Their sum is b₀(2^{N_r−1} − 1).
- W_retry = N_r·d_a + b₀(2^{N_r−1} − 1).
- Teaching example: b₀ = 1 s, d_a = 5 s, N_r = 5 gives waits 1+2+4+8 = 15 s = 1·(2⁴ − 1), attempts 25 s, W_retry = 40 s. These are not design values.
- PR-30: after n consecutive failures at backoff base b₀ the venue is declared unreachable at τ_venue = b₀(2ⁿ − 1).

| RT | Operation | Bound | After the bound |
|---|---|---|---|
| RT-1 | Public requests (idempotent) | N_r attempts, backoff as above | Mark OCL-3 or OCL-2; entries refused |
| RT-2 | Entry submit | **Zero retries.** A duplicate fill would double the exposure and UEF-8 duplicate semantics are unknown. | TX-7 and reconciliation. A resolved-absent order leads to a new intent needing a new permit. |
| RT-3 | Cancel | N_r attempts with a query between attempts | RECONCILING; the order is treated as possibly live |
| RT-4 | Protective stop | Query by cid and open orders before every attempt; N_r attempts | PS-7, XP-5, VC-12 |
| RT-5 | Reduce-only exit | Same pre-attempt query; N_r attempts per round; rounds repeat at the bounded rate | HARD_STOP state; CRIT; continues reconciliation |
| RT-6 | Reconciliation query | Backoff capped at T_rc | VC-6 after T_amb |

**Hard stop.** After rate-limit code -1003, or after N_r consecutive gateway failures, the gateway sends only reduce-only and query traffic until the budget recovers (UEF-6). Entries are refused (OCL-2 response).

### 4.2 Permit-gated entry path

1. Strategy signal → sizing (FM-9) → permit request (IF-8).
2. CP-8 re-evaluates PT-1…PT-11 (§5.3) and issues a single-use permit with a TTL.
3. CP-9 consumes the permit (IF-9, atomic), then dispatches (TX-1).
4. Committed risk is recorded at consumption.

### 4.3 Cancel at deadline

An entry order is cancelled at the end of the next bar (Part 4). The cancel is issued on the elapsed-clock deadline TR-8, with the bar-grid end as the reference. The unfilled share's risk is released only on CANCELLED (TX-13).

### 4.4 Unattended resting entry (RR-1) and its gate

If the core dies with an entry resting, it can fill unprotected. Live entries are therefore admissible only if UV-5 verifies at least one venue-side mitigation:
- (a) a protective stop attached to the entry or triggered on its fill;
- (b) venue-enforced order expiry no later than the entry deadline.

If neither is verified, Live entries are refused by VC-14. The alternative of accepting RR-1 is an owner decision recorded under OD-4 (Part 8). The design does not accept it by default.

## 5. Risk authority (RQ-RSK-08 completion, §9.6)

### 5.1 Risk-state record (RS)

Owned by CP-8 (file `risk_<mode>.db`). Fields:

| RS | Field |
|---|---|
| RS-1 | Mode, record version, hash, monotone write sequence |
| RS-2 | Owner limits and their version (PR-1…PR-5), with the equity basis |
| RS-3 | Accrued realized net result by UTC day and ISO week (§1.3 attribution) |
| RS-4 | Equity-basis running value and peak value (drawdown reference) |
| RS-5 | Committed-risk ledger: one row per permit or position with state |
| RS-6 | Veto set: instances with class, id, state (§5.4), epoch |
| RS-7 | Last acknowledged observation sequence from each producer |
| RS-8 | Last clean reconciliation time |
| RS-9 | Active release bundle id |
| RS-10 | Operator-supplied initial record marker (WP-6) |

**Integrity.** The record is hash-checked on every read. The write sequence is cross-checked against the last committed sequence in the risk audit log. A mismatch counts as corrupt.

**Missing or corrupt record (§9.6, §9.8).**
- PB-2 refuses to start.
- The supervisor raises CRIT naming the check (SK-3) and the procedure RP-1.
- Live is refused.
- Nothing is initialized from market or account values.
- Recovery happens only through RP-1, with the out-of-band restore or an audited operator acknowledgement.
- First-ever initialization also uses RP-1 (an owner-supplied record).

### 5.2 Headroom, committed risk and aggregate

- Headroom comes from FM-13: B_eff = min(B, A_head, D_head, H_dd).
- Committed risk per entry is q·u at permit consumption (HS-1 example: 0.003 × 639.688 = 1.919064 USDT ≤ B = 2).
- Risk converts to position risk only through confirmed fills and PS-4.
- It is released only on confirmed closure (FILLED exit or flat), CANCELLED for the unfilled share, REJECTED, or reconciled resolution (TX-2, TX-3, TX-21).
- Aggregate is the sum over rows (Part 3 decision).
- **Example (HS-1, hypothetical).** The entry fills 0.002 of 0.003 and the cancel is then confirmed:
  - committed risk is 0.002 × 639.688 = 1.279376 USDT;
  - the stop quantity is 0.002;
  - 0.001 × 639.688 = 0.639688 USDT is released only after CANCELLED.

### 5.3 Permit conditions (PT)

A risk-increasing permit is issued only if all hold. Any unknown value fails the condition (AP-2).

| PT | Condition |
|---|---|
| PT-1 | Veto set contains no active or pending-ack instance (§5.4) |
| PT-2 | Record valid and written within τ_rec |
| PT-3 | Offset state KNOWN (OB-1) |
| PT-4 | Last clean reconciliation is not older than 2·T_rc |
| PT-5 | Sizing recomputed by CP-8 from the shared formula library equals the request (D6-9), and risk ≤ B_eff |
| PT-6 | Bar ids in the request are VALID, and the newest bar is no older than τ_feed |
| PT-7 | Bundle id equals RS-9, and lineage is clean for the mode (§1.4 of Part 5) |
| PT-8 | Venue facts fresh (VR-12); symbol in the frozen universe |
| PT-9 | UV items for the entry type verified (LIVE) |
| PT-10 | Audit append for the permit succeeded |
| PT-11 | Entry window open: T_max ≥ b + δ_bar (IV-5) |

**TTL.** TTL_p ≤ τ_feed, because the data behind the permit goes stale at τ_feed. It is measured on the elapsed clock with boot id. An expired or unknown-boot permit is REFUSED at consumption.

### 5.4 Veto classes (VC), veto and /ack lifecycle

A veto blocks risk-increasing actions only. It never blocks a cancel, stop, exit or flatten (AP-1).

**Instance lifecycle.**
- ACTIVE: a failing condition exists.
- RECOVERED_PENDING_ACK: the recovery condition holds and the class has a resume gate.
- CLEARED.

**Clearing rules.**
- A veto clears only through its own recovery condition. Without a resume gate it goes ACTIVE → CLEARED.
- With a resume gate it goes ACTIVE → RECOVERED_PENDING_ACK → CLEARED. The second step happens only on an /ack that quotes the instance id.
- /ack while the recovery condition fails is refused with an identified refusal (Part 8).
- /ack on a class with no gate has no effect on the veto and is refused.
- If the condition fails again while pending, the instance returns to ACTIVE.
- /ack does not clear VC-1 (the process is not running). RP-1 does.

| VC | Class | Trigger | Recovery condition | Resume gate (/ack) |
|---|---|---|---|---|
| VC-1 | RISK_RECORD_INVALID | Missing, corrupt or stale-sequence record | RP-1 completed, then PB-2 starts and passes SK-3 | Yes, quoting RP-1's audit id |
| VC-2 | LIMITS_UNDEFINED | Any OD-1 value unset, invalid or unconfirmed | All PR-1…PR-5 valid via WP-1 for the mode | No |
| VC-3 | DAILY_LOSS_REACHED | D_head ≤ 0 | Next UTC day rolled over with KNOWN offset, or limits changed via WP-1 so D_head > 0 | Yes |
| VC-4 | DRAWDOWN_REACHED | H_dd ≤ 0 | Owner changes limit or basis via WP-1 so H_dd > 0. The system never self-clears. | Yes |
| VC-5 | RECON_DIVERGENCE | Any DG-class item unresolved, illegal transition, foreign order, or flat-equity mismatch | A reconciliation cycle with zero unresolved items and the ledger matching venue exposure | Yes |
| VC-6 | AMBIGUOUS_ORDER_AGED | An order has stayed in TIMEOUT_AMBIGUOUS or RECONCILING longer than T_amb | All such orders resolved (TX-18…TX-21) | No |
| VC-7 | DATA_UNVALIDATED | The attested window is not VALID or is older than τ_feed (RKC-3) | A VALID window rebuilt (VR-3) | No |
| VC-8 | CLOCK_UNSAFE | Offset not KNOWN (OB-2…OB-4) | m_s consecutive samples give KNOWN with \|θ\| ≤ θ_max | No |
| VC-9 | CREDENTIAL_INVALID | Authentication or permission check fails, or the permission set differs from the registered set | A passing check (Part 8 defines the check) | Yes |
| VC-10 | CONFIG_INTEGRITY | Bundle hash or lineage failure | A verified bundle is active | No |
| VC-11 | AUDIT_FAILURE | Audit append failure or chain break | RP-6 completed and the chain verified | Yes |
| VC-12 | PROTECTION_FAILURE | PS-7 on any position, or HARD_STOP | All positions in PS-4 or PS-1 | Yes |
| VC-13 | OPERATOR_HALT | Operator halt command | Operator resume command (it is itself the gate) | n/a |
| VC-14 | VENUE_CAPABILITY_UNVERIFIED | A required UV item is unverified or its verification is stale (LIVE) | Verification record complete in the audit chain | No |
| VC-15 | OPERATOR_CHANNEL_LOST | d_op ≥ τ_op,1 (§8) | Channel healthy for m_c consecutive polls | Yes (proves the operator is reachable) |

**Selector interlocks (Part 8 binds).** The mapping is:
- data validity → VC-7;
- reconciliation → VC-5, VC-6;
- risk-limit definition → VC-1, VC-2;
- credential/permission → VC-9;
- config integrity → VC-10;
- clock offset → VC-8.

Commands check only the classes their context can evaluate.

**Venue capability items (UV).**

| UV | Verification item (pre-Live, VM-6; blocked in this engagement) |
|---|---|
| UV-1 | Venue-resident stop order type usable for stops |
| UV-2 | Reduce-only flag semantics: no position reversal |
| UV-3 | Post-only semantics: rejection instead of taking |
| UV-4 | Place and cancel semantics for stops (amend not required) |
| UV-5 | RR-1 mitigation (§4.4 (a) or (b)) |
| UV-6 | clientOrderId length, charset and uniqueness behavior; query by cid (UEF-8) |
| UV-7 | Position mode and margin mode (UEF-2) |

**RX-2 disposition.** DQ-1 and UEF-1 are reconciled by gating. Live is refused (VC-14) until UV-1…UV-7 are verified. The exit design is complete and stands independent of the unknowns.

## 6. State ownership (SO)

Each state item has one writer (AP-3). Readers get data through IF-12 or read-only opens.

| SO | Item | File | Writer | Readers | Recovery |
|---|---|---|---|---|---|
| SO-1 | Risk-state record, ledger, veto set | `risk_<mode>.db` | PB-2 (CP-8) | none directly (IPC) | RP-1 |
| SO-2 | Order journal, cid counter | `orders_<mode>.db` | PB-1 (CP-9) | PB-1 | RP-2, RP-7 |
| SO-3 | Reconciliation results and cursors | `recon_<mode>.db` | PB-1 (CP-10) | PB-1 | Rebuilt by a reconciliation cycle |
| SO-4 | Simulator state | `sim.db` | PB-1 (CP-11, PAPER) | PB-1 | Discard and restart Paper segment |
| SO-5 | Forward market data | `market_fwd.db` | PB-1 (CP-4) | PB-1, PB-4 read-only | RP-5 |
| SO-6 | Historical market data | `market_hist.db` | PB-4 | PB-1 read-only | RP-5 |
| SO-7 | Release bundles | `releases/` | PB-4 | PB-1, PB-3 read-only | RP-4 |
| SO-8 | Supervisor state, mode record, command log, outbox cursors, clean-shutdown flag | `sup.db` | PB-3 | PB-3 | RP-3 |
| SO-9 | Audit chains | `audit_<process>.log` (core, risk, control, research) | Each owner process | Verifiers | RP-6 |
| SO-10 | Alert outboxes | One file per producer | Producer | PB-3 (drain) | Preserved across restart |

**Cross-store consistency.**
- The risk ledger is derived from observations. The order journal is the durable source.
- When PB-2 restarts, it requests replay from the last acknowledged sequence (RS-7).
- If PB-1 is down, the journal is unchanged and nothing is lost.
- If the journal's next sequence is lower than the risk record's last sequence, the pair is inconsistent: VC-5 and no start (SK-4).

## 7. Reconciliation (RC, DG)

### 7.1 Algorithm (RC)

**Triggers.** Startup; after any EN-11; after a gateway reconnect; periodic every T_rc; before each rollover; before any resume gate.

| RC | Step |
|---|---|
| RC-1 | Snapshot venue state via IF-3 queries: open orders, positions, recent fills by cid and by time window |
| RC-2 | Compare against the journal and the position record along orders, positions, fills |
| RC-3 | Classify each difference (DG table) |
| RC-4 | Apply resolution through CP-9 only (IF-11). CP-10 never mutates order state. |
| RC-5 | For every venue exposure, ensure protection (PS) |
| RC-6 | Report observations to CP-8 (IF-12) |
| RC-7 | Record the cycle result: clean only if zero unresolved items |
| RC-8 | If the venue is unreachable, mark UNKNOWN and keep risk held |

### 7.2 Divergence classes (DG)

Venue is authoritative for exposure. The journal is authoritative for our intent.

| DG | Divergence | Response | Veto |
|---|---|---|---|
| DG-1 | Journal says open, venue shows filled or partially filled | EN-13 or EN-12 for the order; protect | None if resolved in-cycle |
| DG-2 | Journal says open, venue shows none | EN-15 only if NF conditions hold; otherwise RECONCILING | VC-6 after T_amb |
| DG-3 | Venue order with our cid format unknown to the journal | Adopt into the journal as RECONCILING (anomaly record); cancel it under RT-3 if it is an entry; protect any fill | VC-5 |
| DG-4 | Venue order without our cid format (foreign) | Never touched by the system. CRIT. It may affect margin. | VC-5 until the owner resolves |
| DG-5 | Position or fill the journal does not explain | Ledger commits risk at the larger of journal and venue exposure. Protect or exit. | VC-5 |
| DG-6 | Wallet balance differs from the record beyond the tolerance, compared only when flat | See §7.3 | VC-5 |
| DG-7 | Venue unreachable | RC-8; reduce-only attempts bounded (RT-5) | VC-6 once aged |

**Absence is never rejection.** Only EN-3 (proven unsent) and EN-15 (NF conditions) release committed risk without a venue result. Otherwise the order stays RECONCILING (HG-5).

### 7.3 Equity comparison and deferral

- **Flat-only equity check.** Equity is compared only when there are no open positions or orders, using wallet balance. While positions exist, quantities are compared (DG-5). This avoids mark-price fields (C13).
- **Tolerance.** ε_E = c_E·(f_max·Σ|fill notional| + φ_stress·Σ N·k since the last baseline) + ε_round, with c_E ≥ 1. The funding and fee terms use conservative bounds (PR-9, PR-11). ε_round is the venue rounding bound. All are pre-registered (AC-2).
- **Deferral.** The C12 provisional 3-day value governs reconciliation deferral only. T_def = 3 days (PROVISIONAL). If venue state remains unobtainable for T_def, unresolved items become UNRESOLVABLE. They keep their risk held, and no entries resume until RP-9 records an owner-audited acknowledgement. T_def is not used for any other response (independent of τ_op).

## 8. Operator-unreachable response (A9, HG-6; OD-4 default)

### 8.1 Definitions

- Channel health: the supervisor's last successful Telegram poll, carried in each heartbeat (TR-13).
- d_op = elapsed time at the observer since the last healthy-channel report. If heartbeats stop, the last report ages, so d_op grows. A dead supervisor and a dead network look the same.
- Observers: CP-8 (primary) and a backstop in CP-9 (BK). The backstop only reduces risk.
- **Silence is never consent.** No lapse of time releases a limit or clears a veto.
- Thresholds: τ_op,1 < τ_op,2 (PR-33 UNRESOLVED). Constraints:
  - τ_op,1 ≥ m_1·h_c (poll interval multiple, to avoid flapping);
  - τ_op,2 ≥ τ_op,1 + G, with G at least one T_rc;
  - the outage distribution from MQ-3 informs both.
- These thresholds are independent of the C12 3-day value.

### 8.2 Response table (TO)

CORE, RISK and SUP (supervisor) are process states. TG is the Telegram network. The rows partition all 16 combinations of (CORE, RISK, SUP, TG) up/down:
- CORE up and RISK up: 4 combinations, covered by TO-1…TO-3 by d_op;
- CORE up and RISK down: 4 combinations, TO-4;
- CORE down with SUP up and TG up: 2 combinations (RISK any), TO-5;
- CORE down with SUP up and TG down: 2 combinations, TO-6;
- CORE down with SUP down: 4 combinations (RISK and TG any), TO-7.

| TO | Condition | Entries | Open positions | Pending entries | Alerts and recovery |
|---|---|---|---|---|---|
| TO-1 | CORE up, RISK up, d_op < τ_op,1 | Normal | Strategy and resident stops | Normal deadline cancel | Alerts queued in outboxes if TG is down |
| TO-2 | CORE up, RISK up, τ_op,1 ≤ d_op < τ_op,2 | Blocked (VC-15) | Autonomous: stops, targets, forced flat | Cancelled at deadline, none new | CRIT queued. /ack needed after the channel recovers. |
| TO-3 | CORE up, RISK up, d_op ≥ τ_op,2 | Blocked | Close-all (XP-6) at the earlier of this moment and t_flat | Cancelled | Stay flat until /ack |
| TO-4 | CORE up, RISK down | No permits possible | Autonomous. The backstop issues XP-6 when d_op ≥ τ_op,2 or RISK and SUP heartbeats are both missing for ≥ τ_op,2. | Deadline cancel | If SUP is up it restarts RISK, bounded by R_max in W_r. SK-3 failure means refuse to start (§9.8). |
| TO-5 | CORE down, SUP up, TG up | None | Resident stops only | Entry orders may rest unattended (RR-1, §4.4) | Operator command may start the core (preconditions in Part 8). The supervisor also restarts, bounded. |
| TO-6 | CORE down, SUP up, TG down | None | Resident stops only | As TO-5 | Bounded automatic restart; alerts queued |
| TO-7 | CORE down, SUP down (host or phone down included) | None | Resident stops only | As TO-5 | Non-routine recovery (RP table). After a reboot the boot id changes and deadlines are invalid (§1.1). |

**Compound outages.** The most restrictive row applies (OCL compound rule).

**Positions at the day boundary.** If the core is down at t_flat, the position remains stop-protected beyond its intended exit. On core recovery, SK-10 closes any overdue position first (XP-4) before any other action. This is the cost of an unreachable core, disclosed for OD-4.

## 9. Startup and recovery (SK, RP)

### 9.1 Startup checks (SK)

Order is fixed. A failed check never triggers inline recovery (§9.8).

| SK | Check | On failure |
|---|---|---|
| SK-1 | Single-instance lock | Refuse |
| SK-2 | Storage integrity: database integrity checks, audit chain verification | **Refuse to start.** CRIT names the check. Pointer to RP-2, RP-5 or RP-6 by file. |
| SK-3 | Risk record valid (PB-2) | Refuse to start. CRIT. Pointer to RP-1. |
| SK-4 | Order journal valid, cid counter present, journal and risk sequences consistent | Refuse. Pointer to RP-2 or RP-7. |
| SK-5 | Offset state KNOWN | Wait and re-sample, bounded. This is not a recovery. VC-8 stays active. |
| SK-6 | Bundle verification and lineage (gate point 2) | Refuse to activate. VC-10. RP-4 if the store is damaged. |
| SK-7 | Credential and permission check (LIVE) | VC-9. Entries refused. Reduce-only still operates. |
| SK-8 | Venue facts and UV records current | VC-14 and RF-1 |
| SK-9 | Reconciliation cycle | VC-5 or VC-6 until clean |
| SK-10 | Protection check: every venue position is PS-4, or a stop is placed, or the position is closed; overdue positions closed first | PS-7 path, VC-12 |
| SK-11 | Data windows rebuilt to VALID | VC-7 |
| SK-12 | Unclean-exit rule | See below |

**Unclean exit (SK-12).** An unclean exit is when `sup.db` shows the clean-shutdown flag absent. Entries resume only after SK-9 gives a clean cycle. If any DG item arose, VC-5's resume gate applies (/ack). Process restart never skips a check.

### 9.2 Recovery procedures (RP)

Required process state is defined here. Part 8 lists these in the procedural consistency table.

| RP | Procedure | Required process state |
|---|---|---|
| RP-1 | Restore the risk-state record from a backup artifact, or write an owner-supplied initial record with an audited acknowledgement | PB-1 STOPPED and PB-2 STOPPED |
| RP-2 | Rebuild or restore the order journal; core then starts in a mode that only reconciles and protects | PB-1 STOPPED |
| RP-3 | Restore supervisor state | PB-3 STOPPED (children either) |
| RP-4 | Replace a damaged release store | PB-1 STOPPED |
| RP-5 | Repair market databases | Forward: PB-1 STOPPED. Historical: either. |
| RP-6 | Resolve an audit-chain break by opening a marked new segment | Owner process STOPPED |
| RP-7 | Advance the cid generation | PB-1 STOPPED |
| RP-8 | Rotate or revoke credentials | Venue key: PB-1 STOPPED. Telegram token: PB-3 STOPPED. |
| RP-9 | Owner-audited acknowledgement of UNRESOLVABLE items (§7.3) | PB-2 STOPPED |
| RP-10 | Emergency flatten by the owner outside the system. It is non-routine, so A2 holds. The reconciler then treats the changes as DG items. | Either |

## 10. Decisions

| ID | Decision | Rejected alternative with positive reason | Reversibility | Deciding criterion |
|---|---|---|---|---|
| D7-1 | Ten-state machine with a closed definite-reject set; any unlisted outcome is ambiguous | Treat timeouts as rejection: lowest latency and simplest, but it can duplicate or hide exposure (HG-5) | COSTLY_REVERSIBLE | CR-1 |
| D7-2 | No retry of entry submits (RT-2) | Retry with the same cid: recovers lost submits quickly, but duplicate semantics are unverified (UEF-8) and a double fill doubles the exposure | REVERSIBLE | CR-1 |
| D7-3 | Absence is never rejection; EN-15 needs three NF conditions | Release risk after a fixed wait: frees capacity sooner, but retention bounds are unknown | COSTLY_REVERSIBLE | CR-1 |
| D7-4 | Delta stops instead of amending stops | Amend the single stop: one order per position, but needs amend semantics (UV-4) and has an unprotected gap during modification | REVERSIBLE | CR-1, CR-5 |
| D7-5 | Venue authoritative for exposure; ledger commits the larger of journal and venue | Trust the journal: simpler, but it hides orphan exposure | COSTLY_REVERSIBLE | CR-1 |
| D7-6 | Veto and /ack separated, with a per-class recovery condition and resume gate | One acknowledge-to-clear command: simpler for the operator, but it can clear a failing condition (§9.6) | COSTLY_REVERSIBLE | CR-1 |
| D7-7 | Veto blocks only risk-increasing actions; reduction is exempt | Block everything under veto: simple rule, but it can trap a position under a veto (DQ-1) | COSTLY_REVERSIBLE | CR-1 |
| D7-8 | Fixed permit conditions PT-1…PT-11 and TTL ≤ τ_feed | Long-lived permits: fewer round trips, but they outlive their data | REVERSIBLE | CR-1 |
| D7-9 | Missing or corrupt risk record: refuse to start, recover by RP-1; first initialization also uses RP-1 | Initialize from account equity: a fast start, but it launders an unknown state into a known one (§9.6) | COSTLY_REVERSIBLE | CR-1 |
| D7-10 | τ_op response: entries blocked at τ_op,1; close-all at τ_op,2 (bounded by t_flat); default for OD-4 | Hold positions until t_flat regardless: avoids taker cost, but it leaves exposure with no operator for the whole outage. Close-all at first outage: safest but flaps on short outages | REVERSIBLE | CR-1, CR-3 |
| D7-11 | Backstop in the core for close-all (reduction only) | Risk authority only: one decision point, but a risk-process fault would leave exposure | REVERSIBLE | CR-1 |
| D7-12 | Offset-state table with an early-side forced-flat trigger | Wall-clock trigger only: simpler, but wrong when the offset is uncertain | REVERSIBLE | CR-1 |
| D7-13 | Equity compared only when flat | Compare against mark-based equity: continuous check, but it depends on C13 fields | REVERSIBLE | CR-1, CR-5 |
| D7-14 | Entries admissible on Live only with UV-5 verified; RR-1 acceptance is the owner's decision | Accept RR-1 silently: fewer prerequisites, but it creates unprotected exposure | COSTLY_REVERSIBLE | CR-1 |
| D7-15 | 16-character cid with a write-ahead counter and a generation | Time-based cid: no counter, but clock errors can repeat it | REVERSIBLE | CR-1 |

## 11. Dispositions

| Item | Disposition after Part 7 |
|---|---|
| RX-1 | Exit-path verification complete at design level (XP-1…XP-7) |
| RX-2 | Resolved by gating (VC-14, UV-1…UV-7). Verification stays pre-Live (VM-6, blocked by A4). |
| RQ-EXE-05 | PASS (self-inspection): exit-path check §3.2 |
| RQ-RSK-08 | PASS (self-inspection): write paths WP-1…WP-6 (Part 6) and SO-1…SO-10, §5.1 |
| PR-33 | Still UNRESOLVED as a number. The ordering, constraints and measurement are defined (§8.1). |
| OD-1, OD-2 | Still OWNER_DECISION_PENDING |
| OD-3 | Still BLOCKING for Live-host selection only |
| OD-4 | Default: §8 and D7-10. Scope extended by RR-1. Ratification requested in Part 8. |

**Resolved pending propagation (§2.1.5).**
- **Part 8:** the refusal identifiers for VC-1…VC-15, the lineage refusal and each command precondition; the procedural consistency table over RP-1…RP-10; the OD-4 text.
- **Part 9:** the transition table and the TO table become replay and fault-injection cases.

## 12. Part checks PC-41…PC-48 (author self-inspection; not independent proof)

| PC | Check | Method | Result |
|---|---|---|---|
| PC-41 | State machine: ten states; every listed event has a defined (state, event) outcome or is ILLEGAL; terminal states closed; fill-wins-over-cancel; test vector HS-1: 0.003 entry, 0.002 filled, cancel confirmed → stop 0.002, committed 1.279376 USDT, release 0.639688 USDT | VM-3, VM-2 | PASS |
| PC-42 | cid: 16 characters from C11; 36⁹ = 101,559,956,668,416; 36³ = 46,656 = 127.7 years of generations; no reuse by write-ahead | VM-2 | PASS |
| PC-43 | Retry arithmetic: b₀ = 1, d_a = 5, N_r = 5 → waits 15 s, attempts 25 s, W_retry = 40 s; closed form b₀(2ⁿ − 1) = 15 at n = 4 | VM-2 | PASS |
| PC-44 | Veto table: 15 classes, each with a recovery condition and a gate decision; /ack walk-through for three cases (condition failing, no gate, VC-1) | VM-3 | PASS |
| PC-45 | τ_op table: all 16 (CORE, RISK, SUP, TG) combinations map to one row; supervisor liveness is an input | VM-3 | PASS |
| PC-46 | Reconciliation: DG-1…DG-7 each with response; absence never rejection; NF conditions; no C13 dependence | VM-3 | PASS |
| PC-47 | Timestamp roles TR-1…TR-15 each with clock and forbidden use; A_θ = 0.4/0.00005 = 8,000 s = 2.22 h; offset-state table complete | VM-2, VM-3 | PASS |
| PC-48 | Identifier integrity (§14); no USD; no OD-1 anchors; no "Class-A" label; Part 6 propagation items closed | VM-3 | PASS |

**Register status after Part 7.**

| Status | Count |
|---|---|
| PASS | 22 (20 + RQ-EXE-05, RQ-RSK-08) |
| NOT TESTED | 36 |
| UNRESOLVED | 4 (RQ-RSK-05, RQ-DAT-05, RQ-DEP-03, RQ-OPS-04) |
| BLOCKED | 3 (RQ-DEP-04, RQ-VER-03, RQ-VER-08) |
| FAIL | 0 |
| **Total** | **65** |

Row texts are re-read in Part 9, and any mismatch becomes a FAIL there. The next check identifier is PC-49.

## 13. Evidence labels

All behavior above is DESIGN_JUDGMENT with its traced criterion. Ratified inputs used: C5, C11, C12, C13 (excluded), UEF-1/6/8 (conditions). Unmeasured: δ_bar, θ_max, h_c, τ_op values, T_rc, T_amb, N_r, b₀, d_a, DRS content, UV items.

## 14. Completeness declaration

**Catalogs defined in this Part (each fully defined here only).**

| Catalog | Range | Count |
|---|---|---|
| TR | TR-1…TR-15 | 15 |
| OB | OB-1…OB-4 | 4 |
| OS | OS-1…OS-10 | 10 |
| EN | EN-1…EN-18 | 18 |
| TX | TX-1…TX-22 | 22 |
| FR | FR-1…FR-6 | 6 |
| PS | PS-1…PS-7 | 7 |
| XP | XP-1…XP-7 | 7 |
| RT | RT-1…RT-6 | 6 |
| RS | RS-1…RS-10 | 10 |
| PT | PT-1…PT-11 | 11 |
| VC | VC-1…VC-15 | 15 |
| UV | UV-1…UV-7 | 7 |
| SO | SO-1…SO-10 | 10 |
| RC | RC-1…RC-8 | 8 |
| DG | DG-1…DG-7 | 7 |
| TO | TO-1…TO-7 | 7 |
| SK | SK-1…SK-12 | 12 |
| RP | RP-1…RP-10 | 10 |
| RR | RR-1 | 1 |
| D7 | D7-1…D7-15 | 15 |
| PC | PC-41…PC-48 | 8 |

**Referenced-only catalogs.** Part 1: A, C, UEF, HG, CR, DQ, AR. Part 2: RQ, OCL, OD, RX, VM. Part 3: FM, HS, RF. Part 4: IV, BC, AC, PR. Part 5: VR, DC, MQ. Part 6: AP, PB, CP, IF, WP, HA.

**Dangling-identifier audit.** No identifier is used without a defining catalog. Forward references are by description only: refusal identifiers and command preconditions (Part 8), and the procedural consistency table (Part 8). The symbols A_θ, W_retry, τ_cu, T_rc, T_amb, T_def, ε_E, m_s, m_c, m_1, N_r, b₀, d_a, G, DRS and NF are local derived quantities or named sets defined in this Part, not catalog identifiers. The names BK (core backstop) and HARD_STOP are local labels defined in §8.1 and §3.2.

**Duplicate-definition audit.** No identifier defined here appears in an earlier catalog. PC-41…PC-48 continue from PC-40.

**Artifact registry.**

| AR | Content | Status |
|---|---|---|
| AR-01…AR-13 | Parts 1–6 | DELIVERED |
| AR-14 | Execution, risk, state, recovery (this Part) | DELIVERED |
| AR-15 | Telegram, security, operations, phases (Part 8) | DEFERRED |
| AR-16 | Verification, implementation, review (Part 9) | DEFERRED |
| AR-17 | Final acceptance (Part 10) | DEFERRED |

**یادداشت پیشرفت (فارسی)**

بخش ۷ از ۱۰ ارائه شد: کاتالوگ نقش‌های زمانی، ماشین حالت سفارش (۱۰ حالت و ۲۲ گذار)، شرایط رقابت لغو/پر شدن، قالب clientOrderId، ماشین محافظت از موقعیت و مسیرهای خروج، کران تلاش مجدد، مرجع ریسک (رکورد وضعیت، مجوز یک‌بارمصرف، ۱۵ کلاس veto با شرط بازیابی و دروازهٔ ازسرگیری، و تفکیک veto از /ack)، مالکیت وضعیت، تطبیق، بازیابی و راه‌اندازی، و جدول پاسخ به قطع دسترسی اپراتور (τ_op).

**نکات کلیدی:**
- **ریسک باقی‌مانده (RR-1):** سفارش ورود منتظرِ پر شدن ممکن است هنگام مرگ هسته پر شود و بدون stop بماند. Live فقط وقتی مجاز است که صرافی یکی از دو راه‌حل (stop الصاقی یا انقضای سمت صرافی) را تأیید کند. در غیر این صورت پذیرش این ریسک تصمیم خود شماست و در بخش ۸ درخواست می‌شود.
- **پاسخ پیش‌فرض به قطع اپراتور (OD-4):** پس از τ_op,1 ورودی جدید مسدود می‌شود و پس از τ_op,2 همهٔ موقعیت‌ها بسته می‌شوند. مقادیر عددی هنوز تعیین‌نشده است (PR-33) و به اندازه‌گیری MQ-3 وابسته است.
- **وضعیت ردیف‌ها:** RQ-EXE-05 و RQ-RSK-08 به PASS رفتند (خودبازرسی): ۲۲ PASS، ۳۶ NOT TESTED، ۴ UNRESOLVED، ۳ BLOCKED، ۰ FAIL.

OD-1 و OD-2 همچنان در انتظار تصمیم شماست و OD-3 فقط برای انتخاب میزبان Live مسدودکننده است. هیچ عملیات احراز هویت‌شده‌ای انجام نشده است (A4). برای ادامه، «ادامه» بفرستید تا بخش ۸ (فرمان‌ها و دسترسی‌های تلگرام، شش interlock، امنیت، عملیات، جدول سازگاری رویه‌ها، فازها و PDT، و درخواست تأیید OD-4) ارائه شود.


# Part 8/10: Security, Telegram Contract, Interlocks, Operations, Phases (AR-15)

**Navigation.**
- **Previous: Part 7/10 (AR-14).** It delivered the order state machine, the 15 veto classes VC, the risk authority, the τ_op table TO, startup checks SK and recovery procedures RP. Part 8 binds refusals, commands, interlocks, security, operations and phases to those catalogs.
- **Next: Part 9/10 (AR-16).** Verification matrix (65 rows), staged implementation, structured self-red-team (the independent review is BLOCKED, RQ-VER-03) and the change-propagation record.

**Engagement boundary (A4).** Nothing here was executed. No credential, token, permission or venue behavior was observed. Statements about Telegram limits and Android behavior are "recalled, not externally verified in this engagement". All design content is DESIGN_JUDGMENT unless it cites a ratified item.

## 0. Fidelity notes, carry-over, amendments

1. The §9.8 and §10 field lists, and the exact PDT column set, are not held verbatim. The operational columns below are audited against the prompt in Part 10 (the Part 2 §2.0 disclosure class).
2. **Owner decisions.**
   - OD-1 and OD-2 remain OWNER_DECISION_PENDING.
   - OD-3 remains BLOCKING for Live-host selection only. Nothing below names a host.
   - **OD-4 ratification is requested in §6.** It is not blocking, and the default stands until the owner answers.
   - No pause is triggered.
3. **Adversarial self-review of Parts 6–7 found four defects (AM).** Each is corrected here. The corrections apply from Part 8 onward and are logged in the Part 9 change record.

| AM | Defect found | Correction | Affects |
|---|---|---|---|
| AM-1 | AP-5 said signing exists only after all interlocks pass. A restarted Live core with positions must still place protective and reduce-only orders (SK-10), and the credential check (IL-4) is itself an authenticated query. | The credential provider (CP-16) exposes **three capability tiers**, QUERY, REDUCE and FULL (§1, SE-3). FULL (risk-increasing orders) is released only by the selector confirmation. | Part 6 AP-5, CP-16 |
| AM-2 | RX-2 made Live refuse entries under VC-14 until UV-1…UV-7 are verified. Verification needs orders, and the orders are refused under VC-14. The recovery condition was circular. | A **VERIFY permit type** (§5.3) is issued only for scripted tickets VP-1…VP-7. It waives PT-9 solely for the UV item under test. | Part 7 PT-9, VC-14 |
| AM-3 | RP-1, RP-2, RP-4, RP-7, RP-9 require a child STOPPED, but the supervisor restarts children (D6-12), which would race the procedure. | A **desired-state record** in `sup.db`: RUNNING_PAPER, RUNNING_LIVE or STOPPED. The supervisor restarts only toward a RUNNING desired state. A startup refusal that needs out-of-band recovery sets STOPPED automatically (§9.8), and CM-11 sets it on request. | Part 6 CP-13, Part 7 §9 |
| AM-4 | CP-13 allowed one PB-1 instance at a time, but Live and Paper then cannot overlap, so Paper evidence stops accruing during Live. | Disclosed and kept (§5, PDT). The alternative of two concurrent cores is recorded as D8-12 with its trigger. | Part 5 §3.5, Part 7 |

## 1. Security design

### 1.1 Threats (TH) and controls (SE)

| TH | Threat | Asset |
|---|---|---|
| TH-1 | Impersonation or takeover of the operator's Telegram identity | Command authority |
| TH-2 | Replay of an old command, or processing a backlog after an outage | Command integrity |
| TH-3 | Command injection from a group, a forwarded message, or a lookalike name | Command authority |
| TH-4 | Secret leakage through logs, alerts, audit, crash output or process arguments | Venue key, bot token |
| TH-5 | Another app or user on the host reading data or connecting to local sockets | All local state |
| TH-6 | Dependency or supply-chain compromise | Core code |
| TH-7 | Malicious or corrupted release bundle | Parameters, universe, lineage |
| TH-8 | Misuse of a compromised core process or key | Account funds |
| TH-9 | Server-time or clock manipulation | Validity, deadlines |
| TH-10 | Audit tampering | Evidence |

| SE | Control | Counters |
|---|---|---|
| SE-1 | Allow-list of numeric Telegram user ids and one private chat id, held in `sup.db`. It is changed only by an out-of-band procedure (RP-3 or RP-8), never by a Telegram command. Usernames, groups, channels and forwarded messages are never accepted. | TH-1, TH-3 |
| SE-2 | **Challenge-response confirmation** (CH-6) for every command that increases risk, releases a gate, changes limits or has a taker cost. The code is 6 characters from a 32-symbol alphabet: 32⁶ = 1,073,741,824 values. With 3 attempts per challenge the guess probability is 3/1,073,741,824 = 2.8·10⁻⁹. A challenge expires after τ_conf on the **elapsed** clock. It is bound to one command, one sender and one argument hash. It proves freshness and intent, not identity. | TH-1, TH-2 |
| SE-3 | **Credential tiers (AM-1).** QUERY: authenticated read of permissions, orders and positions, loaded after the mode check. REDUCE: reduce-only orders and cancels, released after IL-4 passes. FULL: entries, released only by the selector confirmation (CM-5). The Telegram token is held only by PB-3, and the venue key only by PB-1 (LIVE). | TH-4, TH-8 |
| SE-4 | **Key scope requirements** (owner-side, a precondition for IL-4): trade and read permission only; no withdrawal or transfer permission; IP whitelist where the venue offers it (UEF-9); one key for Live only (Paper holds none, D6-4). IL-4 compares the observed permission set with the registered set. | TH-8 |
| SE-5 | Redaction at source: secrets exist only inside CP-16. Records, alerts and audit carry a secret-free fingerprint (a truncated hash of the public identifier). Secrets are never placed in process arguments or environment variables of other processes. The bot never echoes user text that matches a secret pattern, and never requests a secret. | TH-4 |
| SE-6 | Owner-only file permissions for the private storage root. Unix sockets live inside it (D6-7). Permission audit AS-5. No listening TCP socket (AP-4). | TH-5 |
| SE-7 | Standard library first, a short pinned dependency list with recorded hashes, no dynamic code loading, and release bundles that are **data only**, never code. | TH-6, TH-7 |
| SE-8 | Bundle activation quotes the bundle hash. The summary shown to the operator is rendered by the core from the verified bundle, never from the sender's text. | TH-7 |
| SE-9 | Time offset comes only from venue server time (DC-7), with a sanity bound |θ| ≤ θ_max. The dual-clock check (CP-1) detects suspension and steps. | TH-9 |
| SE-10 | Hash-chained audit with an **external anchor**: the chain head hash is included in the daily digest (AE-8) sent to Telegram. A later rewrite of history can be detected against the delivered digest. | TH-10 |
| SE-11 | Commands can never read, set or rotate credentials. Rotation is RP-8. | TH-1, TH-4 |
| SE-12 | Every command, refusal and state change is audited (CP-14). Failure of the audit append blocks risk-increasing actions (PT-10). | TH-1, TH-10 |

### 1.2 Secrets at rest (resolves the Part 6 forward reference)

- **Decision.** The venue key and the bot token are stored in owner-only files in the private root. Host storage encryption is relied on and **not verified here** (recalled: Android file-based encryption).
- **Rejected alternative.** A passphrase-encrypted store entered at each start. It is stronger against device theft, but every reboot or crash restart would then need the operator. That contradicts A9 and D6-12, which require recovery without a stable operator channel.
- **Residual risk RR-2.** A compromised device exposes both secrets. Mitigations: SE-4 key scope, IP whitelist, RP-8 rotation, and owner-side revocation on loss.
- **Operator account compromise (RR-3).** An attacker controlling the owner's Telegram account is the operator. SE-2 stops accidents and replay, not this. The owner-side mitigation is Telegram two-step verification (an owner action, no credential is requested). The design mitigation is that every command is audited and echoed to the channel.

## 2. Telegram contract

### 2.1 Runtime rules

- Outbound long polling only (A9). Parameters: poll timeout t_lp, backoff after failure b_tg (AC-2, MQ-3 informs them).
- **Channel health** is the age of the last poll that returned, even if empty. That age is d_op for CP-8 (Part 7 §8.1).
- The update offset is advanced only after the command's result is durable in `sup.db`. After a crash, a command whose result is recorded is answered again but **not re-executed**. A command whose execution outcome is unknown is reported PENDING_UNKNOWN. Risk-increasing and limit-changing commands are never re-executed from a backlog without a fresh challenge.
- Message length is kept below 4,000 characters, and the outbox sends at most one message per second per chat (recalled limits, unverified). INFO items may be coalesced. WARN and CRIT items are never dropped or coalesced across classes.
- Every status message carries an as-of time and the offset label (KNOWN, STALE, UNKNOWN or EXCESSIVE). A field that cannot be evaluated is printed as UNKNOWN, never as a last known value without its age.
- Silence is never consent (HG-6). No timeout turns an unanswered challenge into execution.

### 2.2 Command classes (CL) and handling steps (CH)

| CL | Class | Challenge | Staleness refusal (RJ-18, only if offset KNOWN) |
|---|---|---|---|
| CL-1 | Read-only | No | No |
| CL-2 | Risk-reducing, no cost | No | No (executed at any age) |
| CL-3 | Risk-reducing with consequences (taker cost or process stop) | Yes | Yes, to avoid challenging an obsolete message |
| CL-4 | Risk-increasing, gate-releasing or configuration | Yes | Yes |

| CH | Step |
|---|---|
| CH-1 | Receive the update. Reject if the chat id or user id is not in the allow-list (RJ-17). |
| CH-2 | Deduplicate by update id against the persisted offset (RJ-19 for a repeat). |
| CH-3 | Parse. Unknown command or arguments give RJ-28. |
| CH-4 | Classify (CL). Apply the staleness refusal where it applies. |
| CH-5 | Evaluate the command's **precondition set P** (§2.4). Any check that cannot be evaluated is a refusal (RJ-27, AP-2). |
| CH-6 | If the class needs a challenge, send the challenge with a core-rendered summary. Wait for CM-5 within τ_conf (elapsed clock). |
| CH-7 | At CM-5, re-evaluate P (not only at the first step). Execute only if it still holds. |
| CH-8 | Record the result in the command log and the audit chain, then advance the offset. |
| CH-9 | Reply with the result, or with the refusal output (§2.5). |

### 2.3 Commands (CM)

| CM | Command | CL | Effect |
|---|---|---|---|
| CM-1 | `/status` | CL-1 | Mode, process states, offset label, positions with protection state PS, pending orders, active vetoes with ids, channel age d_op, last clean reconciliation |
| CM-2 | `/risk` | CL-1 | Limits version, B_eff and its components, daily and weekly results, committed-risk rows |
| CM-3 | `/paper` | CL-4 | Select PAPER: start PB-2 and PB-1 in PAPER. If a LIVE core is running, it is accepted only when that core is flat (RJ-23 otherwise). |
| CM-4 | `/live` | CL-4 | Start the LIVE core **gated** (initial VC-13 instance, reason START_GATE). Evaluate IL-1…IL-6 repeatedly and report. When all six pass in one evaluation round, send the challenge (CM-5). |
| CM-5 | `/confirm <code>` | n/a | Second step for CL-3 and CL-4 commands. For CM-4 it re-evaluates all six interlocks, then clears START_GATE and releases the FULL tier. |
| CM-6 | `/halt` | CL-2 | Set VC-13. Blocks entries only. Pending entries are left to their deadline unless CM-9 is also sent. |
| CM-7 | `/resume` | CL-4 | Clear VC-13 (its own gate). It does not clear, bypass or evaluate any other veto. |
| CM-8 | `/ack <instance id>` | CL-4 | Resume gate for a class with a gate, only while the instance is RECOVERED_PENDING_ACK (Part 7 §5.4) |
| CM-9 | `/cancel_entries` | CL-2 | Cancel all pending entry orders (reduction only) |
| CM-10 | `/flatten` | CL-3 | XP-7 operator flatten |
| CM-11 | `/stop` | CL-3 | Graceful stop of the core: cancel pending entries, report open positions and their protection state, then stop. Sets the desired state STOPPED (AM-3). |
| CM-12 | `/limits <PR id> <value>` | CL-4 | Owner limit entry through WP-1 |
| CM-13 | `/activate <bundle hash>` | CL-4 | Activate a release bundle |
| CM-14 | `/recon` | CL-2 | Trigger a reconciliation cycle |

### 2.4 Precondition sets

**Rule.** P = M ∩ E. M is the set of checks the command must enforce for correctness. E is the set of checks its evaluating context can evaluate at that instant. A check in M but not in E is not silently dropped. It is **deferred** to a named continuous enforcement point, and the command's reply says so.

| CM | M (must enforce) | E (context can evaluate) | P = M ∩ E | Deferred to |
|---|---|---|---|---|
| CM-1, 2 | none | all | none (UNKNOWN fields shown) | n/a |
| CM-3 | IL-1, IL-3, IL-5, IL-6; live exposure flat | The core is not yet running. The supervisor can read the bundle and ask PB-2. A clock check needs m_s consecutive samples, so a single command-time sample cannot evaluate IL-6. A data window needs the running core. | **IL-3, IL-5, flat** | IL-1 → VC-7 and IL-6 → VC-8, both of which refuse every entry (PT-3, PT-6) once Paper runs. IL-2 and IL-4 are not in M (no venue state and no credential in PAPER). |
| CM-4 / CM-5 | IL-1…IL-6 | The gated LIVE core runs all six | **IL-1…IL-6** | none (VC-14, VC-11, VC-12, VC-13, VC-15 keep blocking entries through PT-1, see D8-3) |
| CM-6, 9, 14 | none | n/a | none | n/a |
| CM-7 | VC-13 instance exists | Veto set is known to PB-2 | **VC-13 active** | Per-trade risk (PT-5) and every other veto stay enforced at each permit. A general resume cannot evaluate per-trade risk and does not try. |
| CM-8 | Instance in RECOVERED_PENDING_ACK, class has a gate, recovery condition currently true | PB-2 holds the instance and evaluates its condition | **All three** | n/a |
| CM-10, 11 | none (risk reduction) | n/a | none. CM-11 additionally requires the sender to see positions listed in the challenge summary. | n/a |
| CM-12 | Value valid for its PR form; for a basis change (PR-5), flat | PB-2 validates; position state known from PB-2 | **Validity; flat for basis** | Loosening takes effect at once after CM-5. It is audited and echoed, and requires the operator to retype the new value in the confirmation. This is deliberate friction, not a waiting period. |
| CM-13 | IL-5 for the new bundle; lineage clean for the mode; flat (no position, no pending order); RS-9 updated atomically | Bundle read by the supervisor; flat state from PB-2 and PB-1 status | **IL-5, lineage, flat** | A PB-2 that is down makes flatness unevaluable, giving RJ-27. |

### 2.5 Interlocks (IL)

The selector has no waiting period and no profit hurdle (A10). Each interlock is a correctness check with a bounded freshness τ_il ≤ τ_feed. A result older than τ_il is UNKNOWN, and UNKNOWN fails.

| IL | Interlock | Evaluation method | Failure condition | Refusal |
|---|---|---|---|---|
| IL-1 | Data validity | For the activated cells ∩ the frozen universe, CP-3 reports VALID windows, newest bar age ≤ τ_feed, and δ_bar measured for the cell (PR-20). Cells that fail are **excluded** from the confirmation summary. Entries in them are refused individually by VC-7. | Zero VALID (symbol, cell) pairs remain | RJ-7 |
| IL-2 | Reconciliation | A cycle (RC-1…RC-7) completed within 2·T_rc with zero unresolved items. The ledger matches venue exposure. | VC-5 or VC-6 active, or the venue is unreachable (UNKNOWN) | RJ-5 or RJ-6 |
| IL-3 | Risk-limit definition | PB-2 reports a valid record (RS-1 hash and sequence) and every PR-1…PR-5 set, validated and confirmed **for this mode** (Paper and Live limits are separate) | VC-1 or VC-2 active, or any value unknown | RJ-1 or RJ-2 |
| IL-4 | Credential and permission (LIVE only) | QUERY-tier authenticated read of the permission set. It must equal the registered set (SE-4), and the IP whitelist state matches if the venue offers one. | Authentication fails, the permission set differs or is unknown, or the check is older than τ_il | RJ-9 |
| IL-5 | Config integrity | Bundle hash re-verified, lineage union recomputed for the mode (Part 5 gate point 2), formula-library version equals the bundle's, universe version present | Any mismatch or lineage violation | RJ-10 or RJ-16 |
| IL-6 | Clock offset | CP-1 offset state KNOWN with |θ| ≤ θ_max, m_s consecutive samples, age ≤ A_θ | Any other state (OB-2…OB-4) | RJ-8 |

The mapping from veto classes to interlocks is the one in Part 7 §5.4.

### 2.6 Refusal catalog (RJ) and refusal output

Common output fields: RJ id, class name, the failing check or instance id, observed value or UNKNOWN, as-of time with offset label, the recovery condition, whether /ack applies, and a procedure pointer (RP-n) when recovery is out-of-band. No secret ever appears.

| RJ | Name | Source |
|---|---|---|
| RJ-1 | RISK_RECORD_INVALID | VC-1; procedure RP-1 |
| RJ-2 | LIMITS_UNDEFINED | VC-2 |
| RJ-3 | DAILY_LOSS_REACHED | VC-3 |
| RJ-4 | DRAWDOWN_REACHED | VC-4 |
| RJ-5 | RECON_DIVERGENCE | VC-5 |
| RJ-6 | AMBIGUOUS_ORDER_AGED | VC-6 |
| RJ-7 | DATA_UNVALIDATED | VC-7 |
| RJ-8 | CLOCK_UNSAFE | VC-8; also CL-3/CL-4 staleness unevaluable |
| RJ-9 | CREDENTIAL_INVALID | VC-9 |
| RJ-10 | CONFIG_INTEGRITY | VC-10 |
| RJ-11 | AUDIT_FAILURE | VC-11; procedure RP-6 |
| RJ-12 | PROTECTION_FAILURE | VC-12 |
| RJ-13 | OPERATOR_HALT | VC-13 |
| RJ-14 | VENUE_CAPABILITY_UNVERIFIED | VC-14 |
| RJ-15 | OPERATOR_CHANNEL_LOST | VC-15 |
| RJ-16 | LINEAGE_VIOLATION | Part 5 §1.4 rule (d); CRIT |
| RJ-17 | UNAUTHORIZED_SENDER | CH-1 |
| RJ-18 | STALE_COMMAND | CH-4 |
| RJ-19 | DUPLICATE_COMMAND | CH-2 |
| RJ-20 | CONFIRMATION_FAILED_OR_EXPIRED | CH-6, CH-7 |
| RJ-21 | ACK_CONDITION_FAILING | CM-8 while the recovery condition fails |
| RJ-22 | ACK_NOT_APPLICABLE | CM-8 on a class without a gate, on VC-1, or on a non-pending instance |
| RJ-23 | NOT_FLAT | CM-3, CM-12 (basis), CM-13 |
| RJ-24 | WRONG_PROCESS_STATE | A command invalid in the current process state |
| RJ-25 | SELECTOR_INTERLOCK_FAILED | CM-5, listing each failing IL with its RJ |
| RJ-26 | STARTUP_CHECK_REFUSED | SK-n failure, with the procedure pointer |
| RJ-27 | PRECONDITION_UNEVALUABLE | CH-5 |
| RJ-28 | UNKNOWN_COMMAND_OR_ARGS | CH-3 |
| RJ-29 | ENTRY_WINDOW_CLOSED | PT-11 |

**Permit denials map to refusals.** PT-1 → the active veto's RJ; PT-2 → RJ-1; PT-3 → RJ-8; PT-4 → RJ-5; PT-5 → the RF id from Part 3; PT-6 → RJ-7; PT-7 → RJ-10 or RJ-16; PT-8 → RF-1; PT-9 → RJ-14; PT-10 → RJ-11; PT-11 → RJ-29.

### 2.7 Alerts (AL, AE)

| AL | Severity | Delivery |
|---|---|---|
| AL-1 | INFO | Durable outbox. May be coalesced. |
| AL-2 | WARN | Durable. Never dropped. |
| AL-3 | CRIT | Durable. Re-sent every T_rep while its source condition persists. Deduplicated by key, and re-sent after Telegram recovers. |

| AE | Event family | Severity |
|---|---|---|
| AE-1 | VC-1, VC-5, VC-6, VC-9, VC-10, VC-11, VC-12, VC-15 set | AL-3 |
| AE-2 | VC-2, VC-3, VC-4, VC-7, VC-8, VC-14 set | AL-2 |
| AE-3 | VC-13 set or cleared, mode change, command executed | AL-1 |
| AE-4 | Veto RECOVERED_PENDING_ACK (names the instance id and that /ack is needed) | AL-2 |
| AE-5 | Startup refusal (RJ-26, names the check and the RP pointer), illegal transition, foreign order (DG-4), lineage violation, close-all (XP-6), protection failure | AL-3 |
| AE-6 | Reconnect, restart, unclean-exit detected | AL-2 |
| AE-7 | Disk or resource threshold crossed (OP-3) | AL-2 or AL-3 |
| AE-8 | Daily digest at a fixed UTC instant: state, positions, results, offset label, audit chain head hash (SE-10) | AL-1 |

A missing digest is itself the owner's observable signal of a dead supervisor or channel. Alerts are generated by producers into their own outboxes (IF-16), so a Telegram outage never blocks a producer.

## 3. Operations (§9.8)

### 3.1 Routine operations (OP)

| OP | Operation | Trigger (UTC) | Behavior | Failure response |
|---|---|---|---|---|
| OP-1 | Day-start routine | 00:00 UTC plus settle | Refresh DC-4 and DC-5 (VR-12); day and ISO-week rollover (WP-3) only if the offset is KNOWN; risk-record backup; AE-8 digest | Rollover blocked and VC-8 stays active; stale facts give RF-1 |
| OP-2 | Backups | After every WP-1 and WP-3 commit, and every T_bk | Snapshot of the risk record to a second private location; the owner may export copies by file copy (out-of-band, never over Telegram); no secrets inside | Backup write failure: WARN; a missing backup makes RP-1 use the owner-supplied record path |
| OP-3 | Resource monitoring | Every T_hp | Free-space probe against S_max (HA-3); thresholds σ_d1 > σ_d2 (WARN, then CRIT); reachability probes (HA-4) | Below σ_d2: market writes pause, risk and order journals keep priority, CRIT |
| OP-4 | Heartbeats | Every h_p | Liveness per TR-13; τ_proc = m_miss·h_p (PR-31) | Restart policy of CP-13 (bounded R_max in W_r, then CRIT and stop restarting) |
| OP-5 | Releases | By CM-13 for bundles; stop, install, start for code | Bundle: only when flat (RJ-23 otherwise). Code release: CM-11, install while desired state is STOPPED, start (SK runs in full). The formula-library version must equal the bundle's. | Any SK failure follows §9.8 |
| OP-6 | Audit segment rotation | At the size limit | New segment with the previous head hash as its first record; no deletion before an archived copy verifies | Chain break: VC-11, RP-6 |
| OP-7 | Incident pointers | On any AL-3 | Each CRIT carries its procedure pointer (RP-n, or "no action: condition self-recovers") | n/a |
| OP-8 | Universe and bundle refresh | On demand (PB-4) | The US function (Part 5) runs on fresh DC-4 and DC-6 snapshots and produces a candidate bundle. Removals for safety are immediate (Part 5 D5-6). Additions require a new bundle and CM-13. | n/a |

**Startup rule (§9.8).** A startup check that needs out-of-band recovery means:
- the process refuses to start;
- a CRIT alert names the check and points to the procedure;
- the supervisor sets the desired state to STOPPED for that process (AM-3);
- no inline recovery is ever attempted.

### 3.2 Procedural consistency table

States: S = STOPPED, E = either. A procedure requires the listed state of each process while it runs. The desired state of the affected children must be STOPPED (set by the startup refusal, by CM-11, or by stopping PB-3), so the supervisor cannot restart them mid-procedure.

| RP | Trigger | PB-1 | PB-2 | PB-3 | Exit check before entries can resume |
|---|---|---|---|---|---|
| RP-1 | SK-3 refusal, or a runtime integrity failure in PB-2 | S | S | E | SK-3, SK-4, SK-9; then VC-1 gate (/ack quoting the RP-1 audit id). An owner-supplied initial record sets D_head = 0 and the peak at the declared value, and entries stay blocked until the next UTC rollover with a KNOWN offset. |
| RP-2 | SK-4 refusal (journal) | S | E | E | SK-4, SK-9; core starts in a reconcile-and-protect substate with entries vetoed until a clean cycle |
| RP-3 | SK-2 failure on `sup.db` | E | E | S | Supervisor adopts live children by heartbeat; if the desired-state record is lost it records STOPPED for future starts and leaves running children untouched, with CRIT |
| RP-4 | SK-6 refusal, or runtime bundle re-verification failure | S | E | E | SK-6 |
| RP-5 forward | SK-2 on `market_fwd.db` | S | E | E | SK-2, SK-11 |
| RP-5 historical | SK-2 on `market_hist.db` | E | E | E | Repair is an atomic replace (write temporary file, then rename). PB-1 reads this file only at warm-up. |
| RP-6 core chain | SK-2 chain failure, or VC-11 | S | E | E | Chain verifies from the marked new segment; VC-11 gate |
| RP-6 risk chain | As above | E | S | E | As above |
| RP-6 control chain | As above | E | E | S | As above |
| RP-7 | SK-4 (counter absent) or journal restore | S | E | E | New generation visible in the journal; SK-4 |
| RP-8 venue key | VC-9, suspected compromise, or rotation | S | E | E | SK-7, IL-4; selector confirmation is required again |
| RP-8 bot token | Suspected compromise or rotation | E | E | S | Channel health restored; allow-list re-verified (SE-1) |
| RP-9 | UNRESOLVABLE items after T_def | E | S | E | SK-3, SK-9; entries only after a clean cycle |
| RP-10 | Owner emergency flatten outside the system | E | E | E | The reconciler classifies the changes as DG items (VC-5 and its gate) |

**Consistency checks (PC-52):**
1. No procedure requires any process to be RUNNING. Every state in the table is S or E.
2. A trigger that arises while the required process is running has an explicit stopping step. For a runtime failure, PB-2 terminates itself and the core denies every permit (VC-1). Then CM-11 or a host stop sets the desired state STOPPED.
3. A startup refusal leaves the process already STOPPED, so no stopping step is needed.
4. No two procedures that can be triggered together require conflicting states. RP-1 and RP-9 both need PB-2 stopped. RP-8 for the key and the token needs different processes stopped.
5. RP-3 and the RP-8 token procedure stop the Telegram channel. That is expected and non-routine (A2). Core and risk continue, and the d_op rules of Part 7 §8 apply.
6. Positions that exist while a core is stopped are carried by resident stops (TO-5). The procedure begins with CM-10 if the supervisor is reachable. Otherwise RP-10 applies.
7. The C12 3-day value appears only in RP-9 (reconciliation deferral).

## 4. Venue verification tickets (VP)

These tickets are the VERIFY permits of AM-2. They are issued only in LIVE after all six interlocks pass and the selector is confirmed. A ticket is allowed only while flat, at most one at a time, at fixed quantity q_ticket = λ·⌈max(q_min, N_min/P_e)/λ⌉. Its risk q·u must satisfy B_eff, so OD-1 limits still bind. PT-9 is waived solely for the UV item under test. Each ticket's result is a signed audit record (VC-14 recovery condition). The tickets are **not executed in this engagement** (A4, VM-6 blocked).

| VP | UV | Scripted check | Pass criterion |
|---|---|---|---|
| VP-1 | UV-1 | Open a minimum position, place a resident stop at the planned distance, kill the core, restart | The stop remains resident and acknowledged after the kill |
| VP-2 | UV-2 | With a minimum position open, submit a reduce-only order larger than the position | No opposite position results |
| VP-3 | UV-3 | Submit a post-only order priced to cross | Rejected or expired with no fill |
| VP-4 | UV-4 | Place a stop, then cancel it | Both outcomes confirmed by query |
| VP-5 | UV-5 | Place an entry with the candidate mitigation (attached stop or venue expiry), then kill the core | Stop present after fill, or order gone by the deadline |
| VP-6 | UV-6 | Place with a 16-character cid; query by cid; resubmit the same cid; later query a terminal cid at recorded ages | Query works; duplicate semantics recorded; retention bound recorded (EN-15 stays disabled until it is) |
| VP-7 | UV-7 | Read position and margin mode | Equals the MA-5 assumption, or the assumption is amended |

**Ticket cost arithmetic (HS-1 hypotheticals, N_min = 5 USDT, f = 0.0006).** One round trip costs 2 × 0.0006 × 5 = 0.006 USDT per ticket, before any slippage. This is not a design value.

## 5. Phases (D16) and the Phase Deviation Table

### 5.1 Derivation from risks and verification dependencies

Two phases are distinct only if they differ in **capability profile** or in the **evidence that closes them**. The minimum set is the number of distinct (risk, verification means) groups.

| Risk (RKC) | What can verify it | Capability profile (KP) | Group |
|---|---|---|---|
| RKC-5 model-statistical | Historical and forward public data, offline compute | KP-1, KP-7 only; no orders | G1 |
| RKC-3 data validity (δ_bar, θ_max, κ_q, σ_v) | Forward public observation over time | KP-1, KP-7 only; no orders | G1 (same profile, no ordering dependency between the two workstreams) |
| RKC-2 execution logic and p_fill, net-per-fill | The complete decision path without money (simulator) | KP-1, KP-7, simulated KP-4 | G2 |
| Venue behavior (UEF-1…UEF-11, UV-1…UV-7) | Authenticated minimum-size orders only | KP-2 (FULL tier under VERIFY permits) | G3 |
| RKC-1 financial limits and operation | The system itself, with owner limits | KP-2, signed | G4 |

Four groups give four phases. G1 merges the owner's training and calibration because they share one capability profile and neither depends on the other's completion.

### 5.2 Phase catalog (PH)

| PH | Phase | Entry | Closure evidence | Constraints |
|---|---|---|---|---|
| PH-1 | RESEARCH_AND_OBSERVE (two concurrent workstreams: WS-A parameter screening and statistics; WS-B public-data calibration) | None | Per cell: SD-3 research → Paper conditions (ES-4). WS-B: measured δ_bar, θ_max, κ_q, σ_v (MQ-6, MQ-7). | No orders, no credentials (PB-4 and the forward recorder). Calibration yields frozen versions only (AD). |
| PH-2 | PAPER | At least one cell ES-4 (SD-3) and a verified bundle. Selection by CM-3 (IL-3, IL-5). | ES labels by the sequential boundary (SD-7). The labels are descriptive and are not a Paper-to-Live gate (RX-4). | PAPER core has no signed face. Evidence accrual pauses while the LIVE core is running (AM-4). |
| PH-3 | VENUE_VERIFICATION | Owner authorization, outside this engagement (A4); the six interlocks | VP-1…VP-7 records in the audit chain (VC-14 clears) | LIVE core with VERIFY permits only |
| PH-4 | LIVE | The six interlocks via CM-4 and CM-5. VC-14 clear is a standing entry condition (PT-9), not part of the selector. | None (operation) | No waiting period and no return hurdle (A10). Selecting Live does not require prior Paper time, and ES labels are displayed in the confirmation summary. |

PH-1 and PH-2 can overlap. PH-2 and PH-3 are order-free relative to each other. Both precede PH-4's entries, because VC-14 is a capability gate and not a performance gate.

### 5.3 Phase Deviation Table (PDT)

One row per owner-intended phase. The added phase is listed in the same table with no omission.

| PD | Owner-intended phase | Design disposition | Rationale |
|---|---|---|---|
| PD-1 | Training | **Merged** into PH-1 as WS-A | Training here is parameter screening within a pre-registered budget (SD-1), not model fitting. It shares its capability profile with calibration. |
| PD-2 | Extended calibration | **Merged and split.** Public-data calibration → PH-1 WS-B. Execution-parameter calibration (σ_e, σ_x, φ_stress) **cannot** be measured from Paper or public data, so it stays conservative (AC-1 fixed, PR-7/8/9) until live evidence and is then updated only through a new frozen version offline (AD-3). | A calibration phase after training and before Paper would measure only what public data can show. Execution slippage is observable only on the venue. |
| PD-3 | Paper | **Retained** as PH-2 | Closes RKC-2 evidence without money. No duration is imposed. |
| PD-4 | Live | **Retained** as PH-4 | Selector gated only by the six interlocks (A10) |
| PD-5 | (none; added by the design) | **Added** PH-3 VENUE_VERIFICATION | RX-2 makes Live refuse entries until UV items are verified, and no phase verified them. Without PH-3 Live would never become admissible. |

**Disclosure of cost (AM-4).** Because one PB-1 instance runs at a time, Paper evidence stops accruing while Live runs. Part 5 §3.5 shows the forward-accumulation waits are years, so this cost is large. Option B (concurrent PAPER and LIVE cores, separate market writers) is recorded as D8-12 with its trigger.

## 6. OD-4 ratification request (A9, HG-6)

**Question to the owner.** Ratify the operator-unreachable policy, or choose an alternative. This is the only question returned by this Part. It is **not blocking**: the default stands until answered.

| ON | Option | Consequence for the design | Consequence for the owner | Reversibility |
|---|---|---|---|---|
| ON-1 | **Default.** Entries blocked at τ_op,1; close-all at τ_op,2, or at t_flat if earlier; stay flat until /ack | No unattended exposure beyond τ_op,2. Needs the core alive to close, so a dead core leaves resident stops (TO-5). | Taker cost f_out·N per position on a long outage (0.0006 × N, HS-1 teaching constant, plus slippage) | REVERSIBLE |
| ON-2 | Entries blocked at τ_op,1; positions held with resident stops until t_flat; no close-all at τ_op,2 | Lower cost, but exposure remains for the whole outage | Larger loss tail if the outage coincides with a gap (FM-19) | REVERSIBLE |
| ON-3 | Close-all at τ_op,1 (single threshold) | Simplest. Flaps on short outages. | More taker cost, more churn | REVERSIBLE |
| ON-4 | **Default for RR-1.** Live entries admissible only with UV-5 verified | No entry can fill unprotected by a dead core | Live waits on VP-5 | REVERSIBLE |
| ON-5 | Accept RR-1 (resting entries may fill without a stop while the core is dead). Scope: at most one entry at B_eff per symbol. | Fewer prerequisites | Owner-recorded unprotected exposure | COSTLY_REVERSIBLE |

Answer format: "ON-n, ON-m", or "default stands". The numeric τ_op,1 and τ_op,2 are not requested from the owner. They come from MQ-3 and the Part 7 §8.1 constraints (PR-33).

## 7. Decisions

| ID | Decision | Rejected alternative with positive reason | Reversibility | Deciding criterion |
|---|---|---|---|---|
| D8-1 | Challenge-response for all risk-increasing, gate-releasing, limit and taker-cost commands; elapsed-clock expiry | Timestamp-only freshness: no second message, but wrong when the offset is unknown (A3) | REVERSIBLE | CR-1 |
| D8-2 | Staleness refusal only when the offset is KNOWN; the challenge supplies freshness otherwise | Mandatory staleness check: a single rule, but it would block risk-reducing commands when the clock is unknown | REVERSIBLE | CR-1 |
| D8-3 | Selector enforces exactly the six interlocks. VC-11, VC-12, VC-13, VC-14 and VC-15 keep blocking entries through PT-1. | Add them to the selector: a visible single gate, but it adds conditions the owner did not choose, and entries are already refused without it | REVERSIBLE | CR-1, A10 |
| D8-4 | LIVE starts gated (initial VC-13), evaluates interlocks, and releases only on CM-5 | Refuse to start the core until all six pass: simpler, but a restarted core with open positions must run to protect them | REVERSIBLE | CR-1 |
| D8-5 | Preconditions are M ∩ E, with deferral named | Check everything at every command: more conservative-looking, but it demands checks a context cannot evaluate, so commands would fail for the wrong reason | REVERSIBLE | CR-1, CR-5 |
| D8-6 | Credential tiers QUERY, REDUCE, FULL (AM-1) | Single signer enabled by selector: simpler, but a restarted core could not protect positions | COSTLY_REVERSIBLE | CR-1 |
| D8-7 | Key and token in owner-only files, no passphrase | Passphrase store: protects against device theft, but blocks unattended recovery (A9) | COSTLY_REVERSIBLE | CR-1, CR-4 |
| D8-8 | VERIFY permit type for VP tickets (AM-2) | Operator-attested UV flags: no new permit path, but they turn an unverified venue claim into a trusted one | COSTLY_REVERSIBLE | CR-1, CR-5 |
| D8-9 | Desired-state record in `sup.db` (AM-3) | A maintenance flag file written by procedures: needs no state, but breaks single-writer ownership (AP-3) | REVERSIBLE | CR-1 |
| D8-10 | Allow-list changes only out-of-band | Telegram command to add users: convenient, but a compromised account could add an attacker | REVERSIBLE | CR-1 |
| D8-11 | Four phases: merge training and calibration, add verification (PD table) | Keep the owner's four phases as stated: familiar, but the verification dependency would be missing and calibration would claim to measure execution it cannot | COSTLY_REVERSIBLE | CR-1, CR-5 |
| D8-12 | One PB-1 instance at a time; Paper pauses during Live | Concurrent PAPER and LIVE cores: preserves evidence accrual, but doubles phone load and needs a second market-data writer (SO-5). Trigger to adopt: forward accumulation (Part 5 §3.5) shows the pause dominates the schedule and MQ-1 passes with margin. | COSTLY_REVERSIBLE | CR-6, CR-4 |
| D8-13 | External anchor of the audit chain head in the daily digest | No anchor: simpler, but a rewritten chain would be undetectable | REVERSIBLE | CR-5 |

## 8. Dispositions

| Item | Disposition after Part 8 |
|---|---|
| DQ-2 / CF-1 | Closed. The supervisor hosts Telegram, and its commands, classes and preconditions are specified. |
| RQ-TEL-01…04, RQ-SEC-01, RQ-SEC-02, RQ-PHS-01, RQ-OPS-01…03 | PASS (self-inspection). Evidence: §2, §1, §5 and §3. Row texts are re-read in Part 9, and any mismatch becomes a FAIL there. |
| RQ-OPS-04 | Unchanged, UNRESOLVED |
| RQ-OWN-04 | Remains NOT TESTED. The Part 8 portion is delivered, and it completes in Part 9. |
| RX-2 | Resolved by gating (VC-14), with the circularity removed (AM-2). Verification itself stays blocked by A4. |
| RX-4 | Selector gated by the six interlocks only. ES labels appear in the summary and are not a gate. |
| PR-33 | Unchanged, UNRESOLVED as a number. |
| OD-1, OD-2 | OWNER_DECISION_PENDING |
| OD-3 | BLOCKING for Live-host selection only |
| OD-4 | Ratification requested (§6). Default stands. |

**Resolved pending propagation (§2.1.5).**
- **Part 9:** apply AM-1…AM-4 to Part 6 (AP-5, CP-16, CP-13) and Part 7 (PT-9). Turn the transition table, the TO table, the command preconditions and the VP tickets into replay and fault-injection cases.
- **Part 10:** audit the operational §9.8, §10 and PDT readings against the prompt.

## 9. Part checks PC-49…PC-56 (author self-inspection; not independent proof)

| PC | Check | Method | Result |
|---|---|---|---|
| PC-49 | Command matrix: 14 commands each with M, E and P = M ∩ E. Three walks: CM-3 (clock deferred to VC-8), CM-7 (general resume does not check per-trade risk), CM-8 (/ack refused while the condition fails). | VM-3 | PASS |
| PC-50 | Six interlocks each have a method, failure condition and refusal. All 15 veto classes map to an RJ (RJ-1…RJ-15). All 11 permit conditions map to a refusal. 29 refusals in total. | VM-3 | PASS |
| PC-51 | Every threat TH-1…TH-10 has at least one control. Confirmation arithmetic: 32⁶ = 1,073,741,824; 3/1,073,741,824 = 2.8·10⁻⁹. | VM-3, VM-2 | PASS |
| PC-52 | Procedural consistency table: all of RP-1…RP-10 listed; no procedure requires RUNNING; every runtime trigger has a stopping step; no restart race (AM-3); C12 value only in RP-9. | VM-3 | PASS |
| PC-53 | PDT has one row per owner-intended phase (four) plus the added phase. The minimum set is derived from five risk groups. The cost of merged and pausing phases is disclosed. | VM-3 | PASS |
| PC-54 | OD-4: five options with consequences and reversibility; non-blocking; τ_op numbers stay in PR-33; the ON-1 cost expression f_out·N matches FM-4. | VM-3 | PASS |
| PC-55 | Amendments AM-1…AM-4 are consistent with CP-16, CP-13, PT-9, D6-12 and Part 5 §3.5. VP ticket arithmetic: 2 × 0.0006 × 5 = 0.006 USDT. | VM-3, VM-2 | PASS |
| PC-56 | Identifier integrity (§10); no USD; no OD-1 anchors; no "Class-A" label; no credential requested; no prohibited phrase. | VM-3 | PASS |

**Register status after Part 8.**

| Status | Count |
|---|---|
| PASS | 32 (22 + 10) |
| NOT TESTED | 26 |
| UNRESOLVED | 4 (RQ-RSK-05, RQ-DAT-05, RQ-DEP-03, RQ-OPS-04) |
| BLOCKED | 3 (RQ-DEP-04, RQ-VER-03, RQ-VER-08) |
| FAIL | 0 |
| **Total** | **65** |

Check: 32 + 26 + 4 + 3 + 0 = 65. The next check identifier is PC-57.

## 10. Completeness declaration

**Catalogs defined in this Part (each fully defined here only).**

| Catalog | Range | Count |
|---|---|---|
| AM | AM-1…AM-4 | 4 |
| TH | TH-1…TH-10 | 10 |
| SE | SE-1…SE-12 | 12 |
| CL | CL-1…CL-4 | 4 |
| CH | CH-1…CH-9 | 9 |
| CM | CM-1…CM-14 | 14 |
| IL | IL-1…IL-6 | 6 |
| RJ | RJ-1…RJ-29 | 29 |
| AL | AL-1…AL-3 | 3 |
| AE | AE-1…AE-8 | 8 |
| OP | OP-1…OP-8 | 8 |
| VP | VP-1…VP-7 | 7 |
| PH | PH-1…PH-4 | 4 |
| PD | PD-1…PD-5 | 5 |
| ON | ON-1…ON-5 | 5 |
| D8 | D8-1…D8-13 | 13 |
| PC | PC-49…PC-56 | 8 |

**Referenced-only catalogs.**
- Part 1: A, C, UEF, HG, CR, DQ, AR.
- Part 2: RQ, RKC, OD, RX, VM.
- Part 3: FM, HS, RF.
- Part 4: SD, ES, AD, AC, PR.
- Part 5: DC, VR, MQ, D5.
- Part 6: AP, PB, CP, IF, WP, HA, D6.
- Part 7: TR, OB, PT, VC, UV, SO, RC, DG, TO, SK, RP, EN, TX, XP, RR.

**Dangling-identifier audit.** No identifier is used without a defining catalog. Forward references are by description only: the verification matrix and change record (Part 9) and the final acceptance mapping (Part 10). The symbols τ_conf, τ_il, T_rep, T_bk, T_hp, h_p, t_lp, b_tg, σ_d1, σ_d2, q_ticket and m_miss are local pre-registered parameters (AC-2) defined in this Part or in Part 4 (PR-31), not catalog identifiers. The names START_GATE, PENDING_UNKNOWN and VERIFY are local state labels defined in §2.3, §2.1 and §4.

**Duplicate-definition audit.** No identifier defined here appears in an earlier catalog. PC-49…PC-56 continue from PC-48. The names RJ (refusals) and RF (Part 3 sizing refusals) are distinct catalogs, and PD (phase deviation rows) is distinct from PR and PH.

**Artifact registry.**

| AR | Content | Status |
|---|---|---|
| AR-01…AR-14 | Parts 1–7 | DELIVERED |
| AR-15 | Security, Telegram contract, interlocks, operations, phases, OD-4 request (this Part) | DELIVERED |
| AR-16 | Verification, implementation, review (Part 9) | DEFERRED |
| AR-17 | Final acceptance (Part 10) | DEFERRED |

**یادداشت پیشرفت (فارسی)**

بخش ۸ از ۱۰ ارائه شد: طراحی امنیت (تهدیدها و کنترل‌ها)، قرارداد تلگرام (۱۴ فرمان، چهار کلاس فرمان، چالش-پاسخ)، شش interlock با روش ارزیابی و شرط شکست و متن رد، ۲۹ کد رد، هشدارها، عملیات، جدول سازگاری رویه‌های بازیابی، تیکت‌های راستی‌آزمایی صرافی، فازها و جدول انحراف فاز (PDT).

**نتایج کلیدی:**
- **چهار نقص در بخش‌های ۶ و ۷ پیدا و اصلاح شد (AM-1…AM-4):** سطح‌بندی دسترسی اعتبارنامه (QUERY/REDUCE/FULL)، حل دور باطل راستی‌آزمایی صرافی (مجوز نوع VERIFY)، ثبت «حالت مطلوب» برای جلوگیری از شرط رقابتی بین ناظر و رویه‌های بازیابی، و افشای هزینهٔ توقف شواهد Paper هنگام اجرای Live.
- **فازها:** چهار فاز مشتق شد. آموزش و کالیبراسیون ادغام شدند (PH-1)، Paper و Live حفظ شدند، و یک فاز اضافه (راستی‌آزمایی صرافی، PH-3) لازم بود. کالیبراسیون لغزش اجرا فقط با شواهد واقعی ممکن است و تا آن زمان محافظه‌کارانه می‌ماند.
- **انتخابگر Paper/Live** فقط با شش interlock محدود می‌شود. بدون زمان انتظار و بدون آستانهٔ بازده (A10).
- **وضعیت ردیف‌ها:** ۳۲ PASS، ۲۶ NOT TESTED، ۴ UNRESOLVED، ۳ BLOCKED، ۰ FAIL (مجموع ۶۵).

**درخواست از شما (غیرمسدودکننده): OD-4.** لطفاً سیاست پیش‌فرض قطع دسترسی اپراتور را تأیید کنید یا گزینهٔ دیگری از ON-1 تا ON-3 را برگزینید. دربارهٔ ریسک RR-1 (پر شدن سفارش ورود بدون stop هنگام مرگ هسته)، گزینهٔ ON-4 پیش‌فرض است و ON-5 پذیرش آن ریسک است. اگر پاسخ ندهید، پیش‌فرض اعمال می‌شود. OD-1 و OD-2 همچنان در انتظار تصمیم شماست و OD-3 فقط برای انتخاب میزبان Live مسدودکننده است. هیچ عملیات احراز هویت‌شده‌ای انجام نشده است (A4).


# Part 9/10: Verification Matrix, Staged Implementation, Self-Red-Team, Change Propagation (AR-16)

**Position.** This Part follows Part 8/10 (AR-15: security, Telegram contract, interlocks, operations, phases, OD-4). The next Part is Part 10/10 (AR-17: final acceptance). This engagement is design-only (A4). Nothing below was executed, and no account, credential or order action is involved. Every "case" is a specification of a future test.

---

## 1. Completeness declaration (Part 9)

**Catalogs defined in this Part (each defined here once, nowhere else):**

| Catalog | Range | Meaning |
|---|---|---|
| FD | FD-1…FD-5 | Fidelity disclosures of this Part |
| NL | NL-1…NL-9 | Numeric ledger (reproducible arithmetic) |
| VX | VX-1…VX-17 | Verification case groups (replay, fault injection, analytical, inspection, probes) |
| IS | IS-0…IS-10 | Implementation stages |
| SR | SR-1…SR-11 | Self-red-team findings |
| PA | PA-1…PA-6 | Amendments introduced by Part 9 |
| PG | PG-1…PG-12 | Change-propagation records |
| D9 | D9-1…D9-7 | Decisions of this Part |
| PC | PC-57…PC-64 | Part checks |

**Referenced-only catalogs:**
- Part 1: A, C, UEF, PF, CF, HG, CR, DQ, TP, XC, DV-1, AR.
- Part 2: RQ, PRI, SEV, CA, OCL, RKC, VM, OD, RX.
- Part 3: MA, FM, HS, WE, RF.
- Part 4: IV, FT, SC, BC, SF, SD, ES, AD, AC, PR.
- Part 5: DK, ST, DC, VR, US, LQ, PP, EP, EV, DW, MQ, CS, D5.
- Part 6: AP, PB, KP, CPF, CP, IF, WP, HA, RB, AS, D6.
- Part 7: TR, OB, OS, EN, TX, FR, PS, XP, RT, RS, PT, VC, UV, SO, RC, DG, TO, SK, RP, RR, D7.
- Part 8: AM, TH, SE, CL, CH, CM, IL, RJ, AL, AE, OP, VP, PH, PD, ON, D8.

**Dangling-identifier audit.** Every range cited below was checked against the catalog ranges recorded in the session memory (counts such as TX-1…22, VC-1…15, UV-1…7, VP-1…7, CM-1…14, RJ-1…29, RB-1…13, AS-1…5, IL-1…6, TO-1…7). No identifier is used outside its recorded range. Limit of this audit: it is made against recorded ranges, not against full Part 2–8 text (FD-1, FD-2).

**Duplicate-definition audit.** The prefixes FD, NL, VX, IS, SR, PA, PG and D9 do not occur in any earlier catalog list. PC-57…PC-64 continue PC-56 without overlap. No register row is redefined. Matrix rows reuse RQ identifiers by reference only.

---

## 2. Fidelity disclosures (FD)

| ID | Disclosure | Effect |
|---|---|---|
| FD-1 | The Part 2 acceptance-condition text of the 65 register rows is not available in this session. Only the condensed session memory is. The planned step "re-read each row text and convert mismatches to FAIL" therefore **could not be performed**. | No FAIL can be found by that step, and none is claimed. Statuses are carried from Parts 2–8 and flagged "re-read pending". The step is specified as VX-17(e) and can be run by anyone holding the Part 2 table. Disclosed again in Part 10. |
| FD-2 | The semantic roles of catalogs follow their names in the memory: OS order states, EN events, TX transitions, TO operator-unreachable table, VC vetoes, UV venue-capability items, VP verification tickets, CM commands, IL interlocks, RJ rejection reasons, RB repository rules, AS verification assumptions. Where per-row content of a catalog is not in memory, Part 9 defines generators keyed on the table, not content copied from it. | The cases stay correct if the tables are keyed as named. A different keying would require regenerating the cases. |
| FD-3 | Interlock numbering IL-1 data validity, IL-2 reconciliation, IL-3 risk-limit definition, IL-4 credential/permission validity, IL-5 config integrity, IL-6 clock offset is inferred from the six-interlock order and from CM-3 = {IL-3, IL-5, flat}. The correspondence OWN-n ↔ A-n (A4 mapped to BND) is inferred from where evidence was delivered. Both are DESIGN_JUDGMENT, used only to route cases, never as evidence for a PASS. | Wrong inference produces mis-routed cases, not false PASS. |
| FD-4 | All VX cases are specifications. None was executed. The code, device and venue do not exist in this engagement. | Rows whose acceptance needs an executed test stay NOT TESTED. |
| FD-5 | The self-red-team (§8) is by the same author who wrote Parts 1–8. It is not independent proof. RQ-VER-03 stays BLOCKED. | Shared blind spots are possible. §8 lists what it cannot detect. |

---

## 3. Numeric ledger (NL)

Each entry was recomputed in this Part.

| ID | Computation | Result |
|---|---|---|
| NL-1 | HS-1 hypothetical (teaching case, not a recommendation). P_x = 49,500 − 25 = 49,475. u = (50,005 − 49,475) + 0.0006 × (50,005 + 49,475) + 0.0010 × 50,000 = 530 + 59.688 + 50 = 639.688 USDT/unit. Risk budget B = 1% × 200 = 2 USDT. 2 / 639.688 = 0.0031264, floored on a 0.001 step gives q = 0.003. ℓ = 0.003 × 639.688 = 1.919064 ≤ 2. Partial-fill release for 0.001 = 0.639688 USDT. | Matches Part 3 and Part 7 values |
| NL-2 | TO partition: 2⁴ = 16 combinations of (CORE, RISK, SUP, TG) up/down. Single-component flips: 4 × 2³ = 32 undirected edges, 64 directed. | 16 / 32 / 64 |
| NL-3 | cid space: 36³ = 46,656 generations. 36⁶ = 2,176,782,336. 36⁹ = 2,176,782,336 × 46,656 = 101,559,956,668,416 sequence values per generation. Generation wrap time at k restarts/day = 46,656 / k days: k = 1 gives 127.74 y; k = 10 gives 12.77 y; k = 100 gives 466.56 d = 1.277 y (365.25-day year). | Basis for PA-6 |
| NL-4 | Challenge code: 32⁶ = 2³⁰ = 1,073,741,824. Three attempts: 3 / 1,073,741,824 = 2.794 × 10⁻⁹. Consistent with the recorded 2.8 × 10⁻⁹; "three attempts" is inferred from that figure. | Consistency check only |
| NL-5 | VP ticket fee ceiling at the Part 8 inputs: 2 × 0.0006 × 5 = 0.006 USDT per ticket. Seven tickets: 0.042 USDT. Scope: fees only. Spread, slippage and adverse move are excluded and carry no bound from this arithmetic (SR-10). | 0.006 / 0.042 USDT |
| NL-6 | Register: 4+9+8+6+4+6+5+4+1+4+2+8+4 = 65. Priority: 27+36+2 = 65. Status after Part 9: 33+25+4+3+0 = 65. | 65 |
| NL-7 | Storage: bars/symbol/year = 35,040+17,520+8,760+4,380+2,190+1,460+365 = 69,715 (intervals 15m, 30m, 1h, 2h, 4h, 6h, 1d). Cap candles/symbol = 3,500 × 7 = 24,500. C19: 3,500 × 14 × 10 = 490,000 candles; 490,000 × 2,551 B = 1,249,990,000 B ≈ 1.25 GB (decimal). | Reproduced |
| NL-8 | DV-1 native depth uses a 365-day year: 3,500 × 15 min = 36.458 d, so 0.0999 y ≈ 0.100; 3,500 h = 145.83 d, so 0.3995 y ≈ 0.400; 4h gives 583.33 d, so 1.598 y; 6h gives 875 d, so 2.397 y. Configurations: 78 + 90 = 168. | Reproduced |
| NL-9 | Elapsed-time example: 500 bp = 0.05; 0.05 × 14,400 s = 720 s. | 720 s |

---

## 4. Verification case catalog (VX)

Methods are the Part 2 VM classes. Counts are explicit. "Harness-computed" means the harness derives the count from the named table and asserts the stated partition equation. Fixed-count groups total **209** cases (22+80+15+7+6+16+4+6+4+14+5+11+4+10+5; VX-2 and VX-5 are excluded because they are harness-computed).

| ID | Group | VM | Generator rule and expected outcome | Count |
|---|---|---|---|---|
| VX-1 | Transition replay (positive) | VM-4 | One case per TX-1…TX-22: set source state, inject the event, assert next state, side effects and audit record. Replay each event twice to assert idempotence. | 22 |
| VX-2 | Transition replay (negative, partition) | VM-4 | For every (OS state, EN event) pair that no TX row covers (180 pairs minus pairs covered), assert no transition, an audit record, and escalation where the event concerns an uncertain order. The harness asserts covered + uncovered = 10 × 18 = 180. This guards against a vacuous suite. | Harness-computed |
| VX-3 | Operator-unreachable fault injection | VM-5 | All 16 (CORE, RISK, SUP, TG) combinations map to exactly one of TO-1…TO-7. Assertions: RISK down means no entry (HG-2); TG down alone leaves routine safety running (A2, A9); no combination releases a limit or makes an uncertain outcome look confirmed (HG-6). Plus all 64 directed single-flip edges, each asserting that no intermediate state is less restrictive than both endpoints. | 16 + 64 = 80 |
| VX-4 | Veto lifecycle | VM-4/5 | For each VC-1…VC-15, five assertions: (a) trigger; (b) persistence across restart; (c) entries refused while exits remain possible (except where VC-9 removes the credential); (d) clearing only by the veto's own recovery condition; (e) /ack refused while the condition fails and required, after recovery, only where the resume gate says so. | 15 cases, 75 assertions |
| VX-5 | Command precondition matrix | VM-4 | For each CM-1…CM-14 one pass case, plus one refusal case per precondition in P = M ∩ E, asserting the expected RJ code. The harness asserts every RJ-1…RJ-29 is produced by at least one case. An RJ code no case can reach is a specification defect. | Harness-computed (≥ 14 + 29) |
| VX-6 | Venue-capability tickets | VM-6 | Run VP-1…VP-7 only after authorization outside this engagement. Each ticket names exactly one UV item under test; each UV-1…UV-7 is covered by at least one ticket. Assert the VERIFY permit is consumed once (PA-1). Fee ceiling per NL-5. | 7 |
| VX-7 | Ambiguous-outcome injection (HG-5) | VM-5 | Six injections: timeout after send; -1007 reply; connection reset after send; duplicate response; late fill after cancel acknowledgement; partial fill followed by reject. Assert zero entry retries (RT-2), AMBIGUOUS state, resolution only by query under EN-15 conditions, never treated as rejection. | 6 |
| VX-8 | Risk-authority fault injection | VM-5 | (i) Risk-state record: absent, truncated, checksum mismatch, wrong schema version, stale, future-dated. Each gives hard veto, Live refusal, CRIT alert and no initialization from market or account values (6). (ii) Permit abuse: replay of a spent permit, expired permit, permit for another cid, permit after a veto, quantity above approved (5). (iii) VERIFY-permit constraints of PA-1 (5). | 16 |
| VX-9 | Clock (A3) | VM-5 | Four injections: forward step, backward step, unknown reference, suspend gap. Assert IL-6/VC-8 behavior and the PA-4 elapsed rule. | 4 |
| VX-10 | Telegram degradation | VM-5 | Six injections: duplicate updates; reordered updates; replayed /live confirmation after restart; expired challenge; wrong-code lockout; inbound dead through τ_op,1 and τ_op,2 under the ON-1 timeline. | 6 |
| VX-11 | Lineage and research-only leak | VM-4 | Four cases: config selected with ST-5 influence refused for Paper/Live by IL-5; config using only ST-1…ST-4 and ST-6 admitted; config with a missing lineage record treated as research-only; config whose lineage record is altered fails the hash check. | 4 |
| VX-12 | Import-graph and single-formula test | VM-1/4 | One executable check per RB-1…RB-13 (parse imports; assert forbidden edges absent, including any research-only data package reachable from a Live-path package). Plus one differential test: research and Live call the same formula-library function objects, with no second implementation of any FM formula found by AST scan. | 14 |
| VX-13 | Assumption probes AS-1…AS-5 | VM-4 (on device) | One probe each: Python/SQLite in Termux with full sync; Unix domain sockets; detached child survival; elapsed-clock behavior across forced suspend; permission isolation. Each has a pass criterion and a topology consequence on failure under A8. | 5 |
| VX-14 | Numeric core | VM-2/4 | NL-1 golden vector; one trigger per RF-1…RF-10 (10 cases); property tests: q floored, ℓ ≤ B_eff, B_eff = min(B, A_head, D_head, H_dd). | 11 |
| VX-15 | Statistics procedures | VM-2 | Four cases: N_max_effective = min(published, recomputed); label-shuffle leakage test yields no edge; cost-sensitivity monotonicity; DSR/MinTRL calculators reproduce hand-computed values (recalled formulas, labeled unverified). | 4 |
| VX-16 | Recovery walk-throughs | VM-3 | One tabletop per RP-1…RP-10 against the Part 8 consistency table. Assert that no procedure attempts out-of-band recovery inline, that startup refusal sets STOPPED, and that the CRIT alert names the failing check. | 10 |
| VX-17 | Document audits | VM-1 | (a) boundary scan: no credential request, order action, Live authorization or profit guarantee; (b) evidence-label audit under RQ-BND-03; (c) identifier audit (dangling, duplicate); (d) unit, UTC and phrase audit (USDT; UTC; prohibited phrases); (e) register-row re-read of acceptance text against evidence (**NOT PERFORMED, FD-1**). | 5 |

---

## 5. Verification matrix (65 rows)

**Counts:** register rows 65; matrix rows 65; each RQ identifier appears exactly once (PC-57). "P8" is the status carried from Part 8, "P9" the status after this Part. Cases are routed by group semantics (FD-3). "Re-read" means FD-1 applies.

| Row | P8 | P9 | Cases | Closure path |
|---|---|---|---|---|
| RQ-BND-01 | PASS | PASS | VX-17a | Re-read |
| RQ-BND-02 | PASS | PASS | VX-17a | Re-read |
| RQ-BND-03 | NOT TESTED | NOT TESTED | VX-17b | Label audit completes in Part 10 |
| RQ-BND-04 | NOT TESTED | NOT TESTED | VX-17a,d | Part 10 audit |
| RQ-OWN-01 | PASS | PASS | VX-17a | Re-read |
| RQ-OWN-02 | NOT TESTED | NOT TESTED | VX-3, VX-10, VX-12 | Executes at IS-7 |
| RQ-OWN-03 | NOT TESTED | NOT TESTED | VX-9, VX-17d, PA-4 | Executes at IS-0 and IS-7 |
| RQ-OWN-04 | NOT TESTED | **PASS** | VX-11, VX-12, PG-5 | Part 5 and Part 8 portions plus Part 9 lineage propagation (PG-5) and import-graph rule (PG-11) are delivered; re-read |
| RQ-OWN-05 | PASS | PASS | NL-8 | Re-read |
| RQ-OWN-06 | PASS | PASS | NL-7 | Re-read |
| RQ-OWN-07 | PASS | PASS | VX-13 | Design passes; probe results NOT TESTED; re-read |
| RQ-OWN-08 | NOT TESTED | NOT TESTED | VX-3, VX-10 | Executes at IS-7 |
| RQ-OWN-09 | NOT TESTED | NOT TESTED | VX-4, VX-5 | Executes at IS-7 |
| RQ-RSK-01 | NOT TESTED | NOT TESTED | VX-14, VX-4, VX-8 | Executes at IS-1, IS-5 |
| RQ-RSK-02 | NOT TESTED | NOT TESTED | VX-14, VX-4, VX-8 | Executes at IS-1, IS-5 |
| RQ-RSK-03 | NOT TESTED | NOT TESTED | VX-14, VX-4, VX-8 | Executes at IS-1, IS-5 |
| RQ-RSK-04 | NOT TESTED | NOT TESTED | VX-14, VX-4, VX-8 | Executes at IS-1, IS-5 |
| RQ-RSK-05 | UNRESOLVED | UNRESOLVED | none | Pending item recorded at status-setting; no Part 9 change |
| RQ-RSK-06 | PASS | PASS | VX-14 | Re-read |
| RQ-RSK-07 | PASS | PASS | VX-14 | Re-read |
| RQ-RSK-08 | PASS | PASS | VX-8 | Re-read |
| RQ-EXE-01 | NOT TESTED | NOT TESTED | VX-1, VX-2, VX-7 | Executes at IS-6 |
| RQ-EXE-02 | NOT TESTED | NOT TESTED | VX-1, VX-2, VX-7 | Executes at IS-6 |
| RQ-EXE-03 | NOT TESTED | NOT TESTED | VX-1, VX-2, VX-7 | Executes at IS-6 |
| RQ-EXE-04 | NOT TESTED | NOT TESTED | VX-1, VX-2, VX-7 | Executes at IS-6 |
| RQ-EXE-05 | PASS | PASS | VX-7 | Re-read |
| RQ-EXE-06 | NOT TESTED | NOT TESTED | VX-1, VX-2, VX-16 | Executes at IS-6 |
| RQ-TEL-01 | PASS | PASS | VX-5, VX-10 | Re-read; execution NOT TESTED |
| RQ-TEL-02 | PASS | PASS | VX-5, VX-10 | Re-read; execution NOT TESTED |
| RQ-TEL-03 | PASS | PASS | VX-5, VX-10 | Re-read; execution NOT TESTED |
| RQ-TEL-04 | PASS | PASS | VX-5, VX-10 | Re-read; execution NOT TESTED |
| RQ-DAT-01 | PASS | PASS | VX-11, VX-12 | Re-read |
| RQ-DAT-02 | PASS | PASS | VX-11, VX-12 | Re-read |
| RQ-DAT-03 | PASS | PASS | VX-11, VX-12 | Re-read |
| RQ-DAT-04 | PASS | PASS | VX-11, VX-12 | Re-read |
| RQ-DAT-05 | UNRESOLVED | UNRESOLVED | none | Pending item recorded at status-setting |
| RQ-DAT-06 | PASS | PASS | NL-7 | Re-read |
| RQ-STA-01 | PASS | PASS | VX-15 | Re-read |
| RQ-STA-02 | PASS | PASS | VX-15 | Re-read |
| RQ-STA-03 | PASS | PASS | VX-15 | Re-read |
| RQ-STA-04 | PASS | PASS | VX-15 | Re-read |
| RQ-STA-05 | PASS | PASS | VX-15 | Re-read |
| RQ-DEP-01 | PASS | PASS | VX-13 | Re-read |
| RQ-DEP-02 | PASS | PASS | VX-13 | Re-read |
| RQ-DEP-03 | UNRESOLVED | UNRESOLVED | VX-13 | Pending item recorded; the OD-3 answer blocks Live-host selection |
| RQ-DEP-04 | BLOCKED | BLOCKED | VX-13 | Blocked by capability as recorded |
| RQ-PHS-01 | PASS | PASS | VX-5, IS-8…IS-10 gates | Re-read |
| RQ-OPS-01 | PASS | PASS | VX-16 | Re-read |
| RQ-OPS-02 | PASS | PASS | VX-16, VX-3 | Re-read |
| RQ-OPS-03 | PASS | PASS | VX-16, VX-3 | Re-read |
| RQ-OPS-04 | UNRESOLVED | UNRESOLVED | VX-3 | Pending item recorded (τ_op value, C12) |
| RQ-SEC-01 | PASS | PASS | VX-8, VX-12 | Re-read |
| RQ-SEC-02 | PASS | PASS | VX-6, VX-8 | Re-read |
| RQ-VER-01 | NOT TESTED | NOT TESTED | VX-17c,e | Part 10 audit |
| RQ-VER-02 | NOT TESTED | NOT TESTED | VX-17c,e | Part 10 audit |
| RQ-VER-03 | BLOCKED | BLOCKED | none | Independent reviewer unavailable; §8 is a fallback and not independent |
| RQ-VER-04 | NOT TESTED | NOT TESTED | VX-17c,e | Part 10 audit |
| RQ-VER-05 | NOT TESTED | NOT TESTED | VX-17c,e | Part 10 audit |
| RQ-VER-06 | NOT TESTED | NOT TESTED | VX-17c,e | Part 10 audit |
| RQ-VER-07 | NOT TESTED | NOT TESTED | VX-17c,e | Part 10 audit |
| RQ-VER-08 | BLOCKED | BLOCKED | none | Reference Step 3 blocked; dependent claims carry PROVISIONAL, UNRESOLVED or NOT ESTABLISHED |
| RQ-DOC-01 | NOT TESTED | NOT TESTED | VX-17c,d | Part 10 |
| RQ-DOC-02 | NOT TESTED | NOT TESTED | VX-17c,d | Part 10 |
| RQ-DOC-03 | NOT TESTED | NOT TESTED | VX-17c,d | Part 10 |
| RQ-DOC-04 | NOT TESTED | NOT TESTED | VX-17c,d | Part 10 |

**Status arithmetic after Part 9:**

| Group | Rows | PASS | NOT TESTED | UNRESOLVED | BLOCKED | FAIL |
|---|---|---|---|---|---|---|
| BND | 4 | 2 | 2 | 0 | 0 | 0 |
| OWN | 9 | 5 | 4 | 0 | 0 | 0 |
| RSK | 8 | 3 | 4 | 1 | 0 | 0 |
| EXE | 6 | 1 | 5 | 0 | 0 | 0 |
| TEL | 4 | 4 | 0 | 0 | 0 | 0 |
| DAT | 6 | 5 | 0 | 1 | 0 | 0 |
| STA | 5 | 5 | 0 | 0 | 0 | 0 |
| DEP | 4 | 2 | 0 | 1 | 1 | 0 |
| PHS | 1 | 1 | 0 | 0 | 0 | 0 |
| OPS | 4 | 3 | 0 | 1 | 0 | 0 |
| SEC | 2 | 2 | 0 | 0 | 0 | 0 |
| VER | 8 | 0 | 6 | 0 | 2 | 0 |
| DOC | 4 | 0 | 4 | 0 | 0 | 0 |
| **Total** | **65** | **33** | **25** | **4** | **3** | **0** |

The only status change from Part 8 is RQ-OWN-04 (NOT TESTED to PASS, self-inspection). There is no FAIL because the FAIL-producing step (FD-1) was not performed. This is not evidence that no mismatch exists.

---

## 6. Staged implementation order (IS)

**Derivation.** Stages follow dependency edges (D11) and then risk reduction. Two risk-reduction rules apply.
- **Rule R1.** Fail-closed substrate precedes any order-capable code.
- **Rule R2.** The exit path (QUERY and REDUCE tiers, reconciliation, flatten) precedes the entry path.

A third rule comes from C2 and DV-1: history is capped at 3,500 bars, so forward archives cannot be back-filled. The data collector therefore starts as early as possible (IS-3), which shortens the evidence wait. At the recorded teaching value s = 1.5 the waits range from 4.175 y (15m) to 1.102 y (6h).

| Stage | Deliverable | Depends on | Exit gate (cases) | Owner decisions needed |
|---|---|---|---|---|
| IS-0 | Repository skeleton per RB-1…RB-13, import-graph test, identifier constants, UTC and elapsed-time utilities (PA-4), device probes | none | VX-12 (14), VX-13 (5), VX-17a–d | none |
| IS-1 | Shared formula library (FM, WE, RF), golden vectors | IS-0 | VX-14 (11) | none (all risk values are parameters) |
| IS-2 | State stores (SQLite WAL, full sync), audit log, checksummed risk-state record format, schema versioning | IS-0 | VX-8(i) record cases (6) | none |
| IS-3 | Public-data collector, VR validation, lineage tags; **start collection immediately** | IS-0, IS-2 | VX-11 (4), validation cases for VR-1…VR-13 | OD-2 for any ST-5 use (default research-only) |
| IS-4 | Research harness (BC, SF, DSR/MinTRL), configuration selection with lineage | IS-1, IS-3 | VX-15 (4); PA-5 exclusion counts reported | none |
| IS-5 | Risk authority process, permit protocol, veto engine VC-1…VC-15 | IS-1, IS-2 | VX-8 (16), VX-4 (15 cases, 75 assertions) | OD-1 (interlock IL-3 fails until set) |
| IS-6 | Execution core on a fault-injectable simulated venue: order state machine, reconciliation, recovery, REDUCE path first, entry path second | IS-1, IS-2, IS-5 | VX-1 (22), VX-2, VX-7 (6) | none |
| IS-7 | Supervisor, desired state, TO table, Telegram contract, commands and interlocks | IS-2, IS-5, IS-6 | VX-3 (80), VX-5, VX-9 (4), VX-10 (6), VX-16 (10) | ON-1…ON-5 (default stands) |
| IS-8 | Paper phase (PH-2), p_fill recording | IS-4, IS-7 | Interlocks IL-3, IL-5 pass; no Live path reachable | none |
| IS-9 | Venue verification (PH-3): VP-1…VP-7 tickets | IS-7, IS-8 | VX-6 (7); VC-14 clears | Authorization to authenticate is the owner's, outside this engagement; OD-3 for host |
| IS-10 | Live (PH-4) | IS-9 | All six interlocks; matrix rows PASS or accepted by the owner; ON-5 decision on RR-1 | OD-1, OD-3, ON-5 |

**Linear order for one implementer:** IS-0, IS-1, IS-2, IS-3, IS-5, IS-6, IS-7, IS-4, IS-8, IS-9, IS-10. IS-4 and IS-8 wait on elapsed evidence rather than engineering effort. IS-4 should therefore begin as soon as IS-3 produces a first validated dataset and run in parallel with IS-5…IS-7. IS-4 completes before IS-8 starts.

**Topological check (PC-60).** Positions: IS-0 = 1, IS-1 = 2, IS-2 = 3, IS-3 = 4, IS-5 = 5, IS-6 = 6, IS-7 = 7, IS-4 = 8, IS-8 = 9, IS-9 = 10, IS-10 = 11. Every edge in the table goes from a lower position to a higher one. IS-4's dependencies (IS-1, IS-3) sit at positions 2 and 4 < 8. IS-8's dependencies (IS-4 at 8, IS-7 at 7) < 9.

---

## 7. Structured self-red-team (SR)

**Method.** This is a fixed attack-lens checklist applied to Parts 6–8 and the AM-1…AM-4 corrections. The lenses are:
- L1 fail-open paths
- L2 ambiguity treated as rejection
- L3 Telegram loss
- L4 dual writers or state ownership
- L5 clock
- L6 lineage and leaks
- L7 arithmetic and statistics
- L8 capability circularity (the AM-2 pattern)
- L9 identifier and specification gaps

**Status.** FD-5 applies. This is the fallback for the BLOCKED independent review and not a substitute for it.

| ID | Lens | Attack | Finding | Disposition |
|---|---|---|---|---|
| SR-1 | L8, L1 | The VERIFY permit (AM-2) is a deliberate bypass of the VC-14 refusal. If it can be issued while a position is open or another veto is active, it becomes an entry path around the risk authority. | Constraints were not stated as conditions. | **Amend: PA-1.** |
| SR-2 | L1 | The AM-3 desired-state record lives in `sup.db`. If it is missing or corrupt, an implementation may default to the last known value or to RUNNING_LIVE. | Fail-closed default was not stated. | **Amend: PA-2.** |
| SR-3 | L1 | After a phone reboot with desired state RUNNING_LIVE, a restarted core could receive FULL tier before reconciliation (AM-1 gap). | Not stated. | **Amend: PA-3.** |
| SR-4 | L5 | A monotonic clock that excludes suspend stops while the phone sleeps. Deadlines (τ_op, A_θ, W_retry) would stretch in real time and the close-all deadline could fire late. AS-4 names the exclusion of suspend. | Real defect for safety deadlines. | **Amend: PA-4.** |
| SR-5 | L7 | Part 5 VR-3 requires strict contiguity; BC-1 backtest timing may read gaps differently. Two rules for one situation. | Inconsistency. | **Amend: PA-5.** |
| SR-6 | L6 | Mode A lineage (any ST-5 selection influence makes a config research-only) exists only as a data rule. If lineage is not inside the config hash, a config could be re-labeled. | Propagation gap. | **Propagate: PG-5**, case VX-11. |
| SR-7 | L9 | A replay suite that enumerates only specified pairs would pass vacuously. | Test-design risk. | **Addressed in VX-2** (partition equation) and **VX-5** (RJ coverage). |
| SR-8 | L2, L3 | Entry-submit timeouts, Telegram loss, and a late fill after cancel acknowledgement were each walked against HG-5 and HG-6. | No finding. | None. VX-3 and VX-7 retain these as regression cases. |
| SR-9 | L9 | FD-1: the row-text re-read could not be performed. | Verification limitation. | Disclosed (FD-1); step specified (VX-17e). |
| SR-10 | L7 | NL-5 bounds only fees, so a reader may take 0.042 USDT as a loss bound. | Scope risk. | Disclosed in NL-5. Tickets stay owner-confirmed at execution time. No design change. |
| SR-11 | L4, L9 | The cid generation counter (3 chars) wraps after 46,656 starts (NL-3). Wrap, or loss of the counter's store, can reuse a cid inside the venue retention window (UEF-8 unknown). | Rare, but silent reuse breaks absence-is-never-rejection. | **Amend: PA-6.** |

**What this review cannot detect:**
- Omissions the same author would repeat.
- Errors in Part 2–8 text not present in the memory.
- Any behavior that only code, the device or the venue would show.

---

## 8. Amendments introduced by Part 9 (PA)

Each is a tightening, so it can only remove permissive behavior. Label DESIGN_JUDGMENT, reversibility REVERSIBLE unless stated.

- **PA-1 (VERIFY permit constraints; amends PT-9 and VC-14 per AM-2).** The risk authority issues a VERIFY permit only if all hold:
  - the account is flat and no non-VERIFY order is pending;
  - no veto other than VC-14 is active;
  - the permit names one VP ticket and one UV item;
  - at most one VERIFY permit is outstanding;
  - quantity and notional do not exceed the ticket's scripted values;
  - the permit is single-use and expires by elapsed time (PA-4).
  
  A VERIFY permit can never authorize an order outside its ticket. Cases: VX-8(iii).
- **PA-2 (desired-state fail-closed; amends CP-13 per AM-3).** If the desired-state record in `sup.db` is missing, unreadable, checksum-failing or of unknown schema, the supervisor treats the desired state as STOPPED, raises a CRIT alert naming the record, and starts no child. It never infers RUNNING_PAPER or RUNNING_LIVE from the previous process list. Returning to a RUNNING state requires an explicit operator command (CM-3 or CM-4 path).
- **PA-3 (cold start tier rule; amends AP-5 and CP-16 per AM-1).** Every cold start of the Live core begins with QUERY and REDUCE only. FULL is activated only after startup reconciliation passes and the resume gate for any active veto is satisfied. A reboot with desired state RUNNING_LIVE therefore protects positions but cannot open new exposure until those conditions hold.
- **PA-4 (elapsed-time rule; amends AS-4, A_θ, W_retry, τ_op deadlines).**
  - Safety deadlines use the elapsed clock that counts suspended time (the boot-time class) where AS-4 shows it exists on the device.
  - Independently, after any wake or process restart the deadline is re-evaluated as elapsed = max(Δ elapsed clock, Δ UTC wall time) when IL-6 reports the offset acceptable.
  - When IL-6 does not hold, an unmeasurable gap counts as the deadline having elapsed and VC-8 applies.
  - Rejected: monotonic-only (stops during suspend), wall-only (offset or step errors).
  - NL-9 gives the unit example: 0.05 × 14,400 s = 720 s.
- **PA-5 (VR-3 versus BC-1).** VR-3 governs. BC-1 timing applies only to contiguous bar sequences. A trade whose interval from signal bar to last bar needed to evaluate its exit contains a missing bar is excluded and counted, and never interpolated. The excluded fraction per (configuration, symbol, interval) cell is a required output of every backtest report, and the gap-handling choice is a sensitivity dimension for the trial count.
- **PA-6 (cid generation guard; amends the cid format of Part 7).**
  - The generation counter never wraps silently. At generation 46,655 the core refuses to start, raises a CRIT alert naming the check, and requires the out-of-band procedure (never inline).
  - If the order store is lost, the next generation is 1 + the highest generation observed in cids returned by venue queries. If the venue cannot return historical cids (UEF-8 unverified), Live refuses and VC-5 applies.
  - Cases: VX-1 (duplicate-event replay) plus a restart case in VX-16.

---

## 9. Change-propagation record (PG)

| ID | Source | Target | Amended content now stated | Status |
|---|---|---|---|---|
| PG-1 | AM-1 | AP-5, CP-16 | Credentials in three tiers. QUERY: read-only account, position, open-order and order-status queries. REDUCE: QUERY plus cancel and reduce-only or close orders. FULL: REDUCE plus exposure-increasing entries. A restarted Live core holds QUERY and REDUCE; FULL is granted only through risk-authority permits (PA-3). If the venue cannot scope keys by tier, tiers are enforced inside the credential-holding component, and RR-2 (device compromise exposes the key) is unchanged. | Propagated |
| PG-2 | AM-2 | PT-9, VC-14, UV-1…7, VP-1…7 | VC-14 recovery uses the VERIFY permit type for scripted tickets; PT-9 is waived only for the UV item under test; PA-1 conditions apply. Circularity removed. | Propagated |
| PG-3 | AM-3 | CP-13 | The supervisor holds a desired-state record in `sup.db` (RUNNING_PAPER, RUNNING_LIVE, STOPPED). A startup refusal needing out-of-band recovery sets STOPPED automatically; CM-11 sets it on request; children are restarted only when the desired state is not STOPPED; PA-2 covers record loss. | Propagated |
| PG-4 | AM-4 | PB-1 scheduling (D8-12) | One PB-1 at a time. Paper evidence pauses during Live. Disclosed and kept. The D8-12 alternative (concurrent cores) is adopted only on its recorded trigger. | Disclosed, no change |
| PG-5 | Part 5 SD-3 / Mode A | SD-3, IL-5, CM-3, CM-4, CM-13, RB rules | The config lineage record lists every source tag that influenced selection (evaluation, trial counts, feature or hyperparameter choice). Any ST-5 member makes the config research-only. IL-5 (config integrity) includes the predicate lineage ∩ {ST-5} = ∅ for any mode other than research, and the lineage record is inside the config hash. A missing lineage record counts as research-only. CM-3, CM-4 and CM-13 inherit the check through IL-5. Case: VX-11. | Propagated |
| PG-6 | Part 5 VR-3 / BC-1 | VR-3, BC-1 | Resolved by PA-5. | Propagated |
| PG-7 | Part 7 TX table | Matrix rows EXE-01…06 | Generator VX-1 (positive) and VX-2 (negative, partition equation). | Joined |
| PG-8 | Part 7 TO table | Matrix rows OWN-02, OWN-08, OPS-02…04 | Generator VX-3 (16 combinations, 64 edges). | Joined |
| PG-9 | Part 8 command preconditions | Matrix rows OWN-09, TEL-01…04, PHS-01 | Generator VX-5 with RJ-coverage assertion. | Joined |
| PG-10 | Part 7 VP tickets and UV list | Matrix rows SEC-02, DEP-03, DEP-04 | Generator VX-6, executed only after authorization outside this engagement. | Joined |
| PG-11 | Part 6 import-graph rules | Matrix rows OWN-04, SEC-01, DAT-01…04 | VX-12: 13 rule checks plus one differential test. | Joined |
| PG-12 | Part 6 AS-1…AS-5 | Matrix rows OWN-07, OWN-03, DEP-01…04 | VX-13: five probes; failure consequences follow the A8 compromise order. | Joined |

All adversarial-review findings that change the design appear above: SR-1…SR-6 and SR-11 appear as PA-1…PA-6 or PG-5. None remain "resolved pending propagation". The AM-1…AM-4 text is now carried in the affected Part 6 and Part 7 elements (PG-1…PG-4).

---

## 10. Decisions (D9)

| ID | Decision | Rejected alternative and positive reason for rejection | Reversibility | Deciding criterion |
|---|---|---|---|---|
| D9-1 | Carry the Part 2–8 statuses without conversion and state FD-1 openly. | Assume row texts match: no evidence supports it, and a false PASS violates HG-4. Reconstruct row texts from memory: invented acceptance conditions would create requirements nobody ratified. | REVERSIBLE | CR-5, HG-4 |
| D9-2 | Generate verification cases from the Part 7 and Part 8 tables (VX-1…VX-5). | Hand-written scenarios: they cover what the author imagines; generation by table gives coverage by construction and exposes a table that changes. | REVERSIBLE | CR-5 |
| D9-3 | Dependency-ordered stages with R1 (fail-closed substrate first) and R2 (exit path first). Collector starts immediately. | Vertical slice to Live: gives early feedback but exposes entry code to funds before the substrate exists (CR-1 outranks speed). Strategy-first build: delays discovery of AS failures that change topology under A8. | REVERSIBLE | CR-1 |
| D9-4 | PA-4: elapsed = max(elapsed clock, wall time) when wall time is trusted; unmeasurable gap counts as elapsed. | Monotonic-only: stops during suspend, deadlines late. Wall-only: step errors and offset (A3). | REVERSIBLE | CR-1, A3 |
| D9-5 | PA-5: VR-3 governs BC-1; gap trades are excluded and counted. | Interpolation: it invents prices the venue never printed. Dropping the whole cell on one gap: discards usable evidence without a threshold that was ever ratified. | COSTLY_REVERSIBLE (changes stored backtest results) | CR-2 |
| D9-6 | Self-red-team with a fixed lens list (L1…L9). | Free-form review: not reproducible, and gaps cannot be seen. | REVERSIBLE | CR-5 |
| D9-7 | PA-2 and PA-3: fail-closed defaults for desired state and cold-start tiers. | Resume the last state: restores exposure after an unknown interval. Always start STOPPED even after a clean supervisor restart: leaves positions without a protector and conflicts with AM-1's reason for the REDUCE tier. | REVERSIBLE | CR-1, HG-6 |

---

## 11. Part checks (PC-57…PC-64)

| ID | Check | Result |
|---|---|---|
| PC-57 | Matrix has 65 rows, equal to the 65 register rows, each RQ id once; group sizes sum 4+9+8+6+4+6+5+4+1+4+2+8+4 = 65. | PASS (self-inspection) |
| PC-58 | Status counts 33+25+4+3+0 = 65; the only change from Part 8 is RQ-OWN-04. | PASS (self-inspection) |
| PC-59 | Every VX source range lies inside its recorded catalog range; fixed counts reproduce (22, 80, 15, 7, 6, 16, 4, 6, 4, 14, 5, 11, 4, 10, 5 = 209). | PASS (self-inspection) |
| PC-60 | IS order is a topological order of the dependency edges (positions listed in §6); each stage has an exit gate that cites VX groups. | PASS (self-inspection) |
| PC-61 | Every SR has a disposition; every "amend" disposition has a PA or PG entry (SR-1→PA-1, SR-2→PA-2, SR-3→PA-3, SR-4→PA-4, SR-5→PA-5, SR-6→PG-5, SR-11→PA-6). | PASS (self-inspection) |
| PC-62 | Propagation record covers AM-1…AM-4, SD-3/Mode A, VR-3/BC-1, TX, TO, CM preconditions, VP/UV, import graph and AS-1…AS-5 (PG-1…PG-12). | PASS (self-inspection) |
| PC-63 | NL-1…NL-9 recomputed in this Part, including 36⁹ = 101,559,956,668,416, 2³⁰ = 1,073,741,824, and 78+90 = 168. | PASS (self-inspection) |
| PC-64 | Boundary scan: no credentials requested, no order action, no Live authorization, no profitability claim, no use of the owner's illustrative risk figures (OD-1 pending), money in USDT, UTC only, no undefined class labels. | PASS (self-inspection) |

All of these are author self-inspection. FD-1 and FD-5 apply.

---

## 12. Artifact registry (updated)

| ID | Artifact | State |
|---|---|---|
| AR-01…AR-11 | Parts 1–4 and shared artifacts | DELIVERED (unchanged) |
| AR-12 | Part 5: data, universe, device | DELIVERED |
| AR-13 | Part 6: architecture | DELIVERED |
| AR-14 | Part 7: state machine, risk authority, recovery | DELIVERED |
| AR-15 | Part 8: security, Telegram, operations, phases | DELIVERED |
| **AR-16** | **Part 9: verification, implementation order, self-red-team, change propagation** | **DELIVERED (this Part)** |
| AR-17 | Part 10: final acceptance | DEFERRED, next |

---

## ۱۳. یادداشت پیشرفت (فارسی)

**بخش ۹ از ۱۰ تحویل شد.**

- **ماتریس تأیید:** ۶۵ ردیف، برابر با ۶۵ ردیف رجیستر. وضعیت: ۳۳ PASS، ۲۵ NOT TESTED، ۴ UNRESOLVED، ۳ BLOCKED و صفر FAIL. تنها تغییر نسبت به بخش ۸ مربوط به RQ-OWN-04 است.
- **محدودیت مهم (FD-1):** متن شرایط پذیرش ردیف‌های بخش ۲ در این نشست در دسترس نبود. بنابراین گام «بازخوانی هر ردیف و تبدیل ناسازگاری به FAIL» اجرا نشد و نتیجه‌ی آن ادعا نشده است. این گام در VX-17(e) مشخص شده است. اگر جدول بخش ۲ را از همین گفتگو دوباره بفرستید، می‌توانم آن را در بخش ۱۰ اجرا کنم. این کار الزامی نیست و روند طراحی را متوقف نمی‌کند.
- **ترتیب پیاده‌سازی:** مرحله‌های IS-0 تا IS-10. زیرساخت ایمن در برابر خرابی و مسیر خروج پیش از مسیر ورود ساخته می‌شود، و جمع‌آوری داده از همان ابتدا آغاز می‌شود چون تاریخچه با سقف ۳٬۵۰۰ کندل قابل بازسازی نیست.
- **بازبینی خودانتقادی (غیرمستقل):** یازده یافته. شش اصلاحیه‌ی سخت‌گیرانه (PA-1 تا PA-6) به طراحی اضافه شد: محدودیت مجوز VERIFY، پیش‌فرض بستن برای وضعیت مطلوب مفقود، سطح‌بندی اعتبارنامه در شروع سرد، ساعت سپری‌شده در حالت تعلیق گوشی، سازگاری VR-3 با BC-1 و محافظ چرخش شناسه‌ی سفارش.
- **گسترش تغییرات:** AM-1 تا AM-4 و موارد دیگر در ۱۲ ردیف PG ثبت شدند.
- **تصمیم‌های هنوز باز:** OD-1 (حدود ریسک)، OD-2 (موضع حقوقی داده‌ی بین‌صرافی) و OD-3 (زیرساخت خارج از دستگاه و بودجه ماهانه) بی‌پاسخ ماندند. OD-4 با گزینه‌ی پیش‌فرض ON-1 پابرجاست مگر اینکه گزینه‌ی دیگری انتخاب کنید.


