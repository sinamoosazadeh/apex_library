# Part 1 — Pre-research checkpoint and initial design

**یادداشت وضعیت:** متن ارسالی مبنای این کار است. طراحی زیر فقط پیشنهاد مهندسی است؛ هیچ حسابی بررسی نشده و هیچ معامله‌ای انجام نشده است. تحویل مستقل چند پیام پشت‌سرهم در این محیط در دسترس من نیست؛ بنابراین نمی‌توانم تعداد بخش‌های نهایی یا ارسال خودکار آن‌ها را تضمین کنم. این بخش، نتیجه نهایی یا تأیید آمادگی معامله نیست.

## 1. Pre-research design checkpoint

**Checkpoint date:** unavailable in the supplied interaction.  
**Basis:** the supplied 54-page parsed master prompt; no external research has been performed. The checkpoint is pre-external-research, not independent of the owner’s detailed brief.

### Objective

Produce an implementable, evidence-aware design for an intraday perpetual-futures trading system on Toobit, with Telegram as the sole runtime operator interface. The system must preserve safety independently of Telegram availability. Profitability and live readiness remain unproven.

### Binding boundaries

- **Venue:** Toobit for live futures execution.
- **Interface:** one Telegram bot for routine operator control, alerts, and review.
- **Time:** UTC for instants and records; monotonic clocks for elapsed deadlines.
- **Engagement:** design only; no credentials, authenticated access, or order operations.
- **Cross-venue sources:** restricted by the owner’s access, cost, use, and legal conditions.
- **Intraday:** required intent; holding duration must be derived and validated, not invented.
- **Risk:** owner limits remain pending; unknown risk inputs must not authorize entries.
- **Mode changes:** live mode requires the six specified correctness interlocks.
- **Device:** derive workload first; test the reference handset against that workload.

### Decision criteria, before comparing alternatives

1. Compliance with binding constraints and safe failure behavior.
2. Point-in-time correctness and reproducibility.
3. Realistic execution, cost, and small-account feasibility.
4. Statistical validity and resistance to selection bias.
5. Operational resilience and recoverability.
6. Compute, storage, network, and operator burden.
7. Maintainability and the ability to verify each consequential behavior.

Hard constraints are gates, not scores that can be outweighed by other benefits.

### Credible directions to investigate

These are candidates, not selections:

- A single-timeframe, rules-based intraday strategy with independently enforced risk.
- A multi-timeframe strategy using a slower context signal and a faster execution signal, if the additional information earns its data and validation cost.
- A predictive model with a separately governed portfolio and risk layer, if its incremental value justifies its training and operational burden.
- A modular single-process implementation or separately deployed components, depending on required fault isolation and measured workload.
- Phone-only, phone plus remote research, phone plus remote live execution, fully remote execution, and hybrid relay arrangements. Feasibility and permissible infrastructure are not established.

### Important open inputs

- Actual owner-approved risk limits and loss accounting.
- Current instrument specifications, fee tier, permissions, margin rules, and order semantics.
- Point-in-time symbol listings, actual history and liquidity for candidate instruments.
- Available experiment inputs and the independently recomputed trial budget.
- Sustained phone workload and operational reliability.
- Cross-venue legal, licensing, and access eligibility.
- A validated intraday maximum holding duration and strategy economics.

**Status:** the checkpoint is delivered in this message before any external research. It has not been written to a separate file.

## 2. Execution envelope and dependency analysis

### Observable capabilities

- **Available:** the supplied parsed text and ordinary reasoning and arithmetic over it.
- **Not exposed in this interaction:** browsing, file creation, code execution, external source inspection, exchange access, and an independent reviewer.
- **Unknown:** underlying model identity, compute settings, exact output limit, and whether a later interaction will expose tools.
- **Delivery limitation:** I cannot autonomously send a sequence of separate final messages. A full multi-message delivery therefore depends on further interaction or a different delivery environment. The requested fixed part count cannot be verified against an unknown message limit.
- **Actually inspected:** the supplied parsed master prompt, not the underlying PDF or the raw audit archive.
- **Actually tested:** no software, market data, device, exchange endpoint, or strategy.

### Exit-condition graph

```text
Capability/boundary inventory ─┬─> requirements + evidence ledger ─┬─> candidate generation
                               │                                   │         │
Pre-research checkpoint ───────┴─> permitted evidence review ──────┘         v
                                                                  comparative evaluation
                                                                          │
                                    ┌─────────────────────────────────────┤
                                    v                                     v
                            design synthesis                    resource-envelope derivation
                                    │                                     │
                                    └──────────────┬──────────────────────┘
                                                   v
                                      failure analysis + verification plan
                                                   │
                                      adversarial review and revisions
                                                   │
                                  acceptance audit + completeness declaration
```

**Dependency rationale:** alternatives require objectives and constraints; a deployment decision requires an estimated workload and a device comparison; acceptance requires a candidate design and evidence. Source inspection and requirements work can proceed independently after the checkpoint. A later observation may reopen an earlier decision; that is revision, not a logical cycle in the exit-condition graph.

**Derived next action:** construct the complete requirements register and evaluate strategy candidates. Independent operational work can proceed while risk policy, exchange semantics, and device measurements remain unresolved.

### Material prompt conflicts

1. **Delivery:** the prompt requires autonomous sequential messages and a predetermined count, but this interaction exposes neither a mechanism to send multiple final messages automatically nor a known message limit. **BLOCKED.** Continue through delivered conversation turns; do not claim all parts have been delivered.
2. **Paper-mode clock checks:** the prompt requires UTC computation and point-in-time data correctness, while also forbidding a clock-offset precondition on a paper-mode command. These can coexist by allowing selection of paper mode without a live-exchange clock interlock, while preventing paper decisions that require trustworthy timestamps when time quality is unknown. This is a **DESIGN_JUDGMENT**, not a claim that an untrustworthy clock produces valid paper results.
3. **Missing risk ledger:** the prompt says acknowledgement is a resume gate, not a ledger substitute. Consequently, acknowledgement alone cannot enable live entries while a required risk value is unknown. Recovery must restore or independently reconstruct sufficient trustworthy history; otherwise live entries remain vetoed.
4. **Trial-budget rule:** the prompt says both “take the minimum” and “if values differ by more than 2×, the recomputed value governs.” When the recomputed figure is larger, those rules conflict. **UNRESOLVED:** until clarified, the smaller value is the conservative research cap; this is not a claim that the inconsistency has been resolved.
5. **Identifier definitions:** the prompt’s identifier section states that some design identifiers are defined inline and that several are unused, while the audit also references labels whose definitions are not consistently catalogued. This is a prompt-traceability defect. This response avoids relying on those ambiguous labels.

## 3. Evidence ledger: inputs that materially affect early design

| Input | Status and scope | Consequence |
|---|---|---|
| Toobit is the selected live venue | **OWNER_HARD**, master prompt §3.1 | Do not substitute another execution venue. |
| 3,500 candles is a measured cap, not guaranteed depth | **RATIFIED_FINDING**, §5.1; limited census | Measure each candidate symbol and interval before claiming history sufficiency. |
| A timeout can leave order acceptance ambiguous | **RATIFIED_FINDING**, §5.1 | Reconcile before any replacement submission. |
| Taker fees of 0.05% and 0.06% conflict | **UNRESOLVED**, §5.1 | Analyze both; use 0.06% as the conservative stated branch until resolved. |
| A maker-only cost-per-volatility floor at 15 minutes and above | **RATIFIED_FINDING**, §5.1, within its original model scope | Evaluate maker assumptions and non-fill risk; do not generalize the finding to every instrument. |
| Historical open interest | **UNRESOLVED**, §5.5 | A candidate strategy cannot depend on it without an authorized source and quality verification. |
| Mark-price change-field meaning | **UNRESOLVED**, §5.1 | Do not derive a critical signal from the disputed field. |
| Phone sustained performance | **UNRESOLVED**, §5.2 | Device fit and continuous operation remain unverified. |
| Archive disposition | **OWNER-SUPPLIED SUMMARY**, §5.5 | 134 + 10 + 3 + 2 = 149 records; the summary does not establish 149 passes and the raw archive was not inspected. |

## 4. Initial strategy candidates and economic boundary

### Criteria

Compare candidates on information required, ability to trade intraday, execution sensitivity, reproducibility, research burden, and whether their incremental complexity can be tested. None is accepted until actual data and execution assumptions are tested.

### Candidate A: single-timeframe rules baseline

**PROVISIONAL hypothesis:** evaluate a directional signal derived only from completed candles, combined with a separately specified exit and independent risk veto. A decision may use a candle only after its close has been observed and validated.

- **Positive reason:** it directly tests whether a minimal price-based hypothesis can survive costs without requiring cross-instrument synchronization or model training.
- **Material limitation:** candles alone cannot establish maker fills, queue position, spread, intrabar order sequencing, or realistic slippage.
- **Status:** **NOT TESTED**. No lookback, entry threshold, stop distance, or holding duration is approved by this proposal.

### Candidate B: contextual multi-timeframe rules

**PROVISIONAL hypothesis:** a slower completed-bar context conditions a faster completed-bar entry.

- **Positive reason:** the extra context could distinguish market conditions that affect the faster signal.
- **Trade-off:** it adds synchronized data, slower information, parameters, and additional selection opportunities.
- **Acceptance condition:** retained only if a pre-registered comparison against Candidate A shows a defensible incremental contribution after realistic costs and selection control.
- **Status:** **NOT TESTED**.

### Candidate C: trained predictive model

**PROVISIONAL hypothesis:** a model estimates a future outcome and feeds a constrained position decision; it has no authority to relax risk controls.

- **Positive reason:** it can represent relationships not captured by a fixed rule.
- **Trade-off:** it requires training, more governance, calibration, leakage controls, and a larger effective research budget.
- **Acceptance condition:** measurable out-of-sample incremental value against the simpler candidates after costs and selection-bias controls.
- **Status:** **NOT TESTED**.

**Initial selection:** Candidate A is the first research baseline, not the production strategy. It offers the cleanest comparison point; choosing it for research does not establish that it is profitable or that Candidates B or C are inferior.

### Sizing and cost arithmetic

For a linear USDT-quoted position, define:

- \(E\): account equity, USDT.
- \(r\): owner-approved maximum nominal loss fraction per trade, dimensionless and **pending**.
- \(N\): position notional, USDT.
- \(d\): fractional adverse price movement to the assumed stop fill.
- \(c(N)\): estimated fees, spread, slippage, and funding attributable to the trade, USDT.

A conservative *planned* sizing condition is:

\[
N d + c(N) \le E r.
\]

This is not a guaranteed realized-loss cap: gaps, slippage, partial fills, exchange behavior, and liquidation can produce a larger loss.

For an illustrative **100 USDT notional**, excluding costs:

| Adverse price movement | Approximate gross loss |
|---:|---:|
| 0.5% | 0.5 USDT |
| 1% | 1 USDT |
| 2% | 2 USDT |

At fixed notional, leverage changes margin requirements; it does not by itself multiply the dollar price-change P&L. For example, if an instrument permitted 10× leverage and margin were approximated as notional divided by leverage, 100 USDT notional would require approximately 10 USDT initial margin before other requirements. Conversely, 100 USDT margin at 10× implies approximately 1,000 USDT notional. Actual margin, maintenance margin, liquidation, fees, and contract rules require venue-specific verification.

At the two unresolved taker-fee rates, a **100 USDT notional** entry costs 0.05–0.06 USDT in taker fees; an exit with the same notional and fee rate would bring the two-fee total to approximately 0.10–0.12 USDT. Exit notional may differ, and this excludes spread, slippage, and funding.

A 10 USDT loss budget is distinct from both notional and margin. Before costs, it permits \(N = 10/d\) USDT at an assumed stop distance \(d\); this is algebra, not a trade recommendation or an approved owner limit.

For sensitivity without adopting a risk setting, at equity \(E=200\) USDT the nominal risk budget is \(200r\) USDT:

| Pending \(r\) | Budget \(200r\), USDT |
|---:|---:|
| 0.5% | 1 |
| 1% | 2 |
| 2% | 4 |
| 10% | 20 |

The owner must eventually decide per-trade, concurrent, daily-loss, and drawdown limits. These examples do not select them.

## 5. Initial safety invariants

These are design requirements, not claims of implemented or tested behavior.

1. **Unknown risk state:** no new live entry when required equity, exposure, loss history, or approved limit is missing or inconsistent.
2. **Ambiguous submission:** record the intent and client identifier before submission. On timeout, classify the result as unresolved and reconcile exchange orders, fills, and positions before considering a replacement.
3. **Telegram outage:** loss of operator connectivity must not disable independent risk checks. Existing positions and protective orders require a venue-specific, tested policy; their behavior cannot be guaranteed until order semantics and process resilience are established.
4. **Missing data:** mark it missing; do not replace it with zero. A decision requiring the missing observation is vetoed.
5. **Cross-venue lineage:** research-only data must not enter paper or live decisions until the relevant owner conditions are established.
6. **Veto versus acknowledgement:** a veto clears only when its underlying condition is demonstrably corrected. Operator acknowledgement, where required, is a separate resume step and cannot repair missing evidence.
7. **Live transition:** refuse with a specific reason unless data validity, reconciliation, defined and evaluable risk limits, credentials and permissions, configuration integrity, and clock quality all pass.

## Artifact registry and partial completeness

| Artifact | Location | Status | Purpose |
|---|---|---|---|
| Pre-research checkpoint | §1 of this response | DELIVERED | Preserves the initial frame before external research. |
| Capability inventory and dependency graph | §2 | DELIVERED | Records actual limitations and derived work dependencies. |
| Initial evidence ledger | §3 | DELIVERED | Preserves important source limitations and conflicts. |
| Candidate strategy comparison and risk arithmetic | §4 | DELIVERED | Establishes research directions and distinguishes notional, margin, and loss budget. |
| Initial safety invariants | §5 | DELIVERED | Records constraints that later implementation design must satisfy. |
| Complete requirements register and matching verification matrix | Not yet delivered | BLOCKED as a completed artifact | Requires further design work; no implementation or test evidence is available. |
| Full architecture, order state machine, Telegram contracts, deployment evaluation, and final audit | Not yet delivered | BLOCKED as a completed artifact | Requires subsequent work and, for some acceptance claims, unavailable measurements or authorization. |

**Part completeness:** the checkpoint and initial analysis above are delivered for their stated scope. The full design and final completeness declaration have **not** been delivered. No strategy, implementation, paper operation, or live readiness has passed validation.


# Part 2 — Execution, risk, and recovery contracts

**یادداشت وضعیت:** این بخش طراحی بخش‌های حساس به خطای سفارش و ریسک را ادامه می‌دهد. هیچ‌کدام از رفتارهای زیر پیاده‌سازی یا آزمایش نشده‌اند. موارد وابسته به ویژگی‌های تأییدنشدهٔ Toobit همچنان مسدود هستند و نباید مبنای معاملهٔ واقعی قرار گیرند.

This part follows Part 1’s checkpoint, candidate comparison, and initial safety invariants. It specifies a proposed execution and recovery contract. It does **not** complete the requirements register, full architecture, deployment analysis, or final audit.

## 1. Design boundary and state authority

### Decision criteria

Execution must prevent duplicate exposure after ambiguous outcomes, preserve a traceable record of decisions, and block new risk when account state cannot be established. It must also tolerate the operator becoming unreachable.

### Alternatives

| Candidate | Advantage | Material weakness | Decision |
|---|---|---|---|
| Treat the internal ledger as authoritative and update it from acknowledgements | Straightforward local processing | A lost response or missed fill can make local state diverge from the venue | Reject as the sole authority. |
| Treat venue observations as authoritative for current external orders, fills, positions, and balances; maintain a durable local decision and observation ledger | Allows reconciliation after crashes and ambiguous responses | Requires complete, sufficiently fresh venue queries and careful handling of inconsistent snapshots | **PROVISIONAL selection.** Venue query capabilities and retention are unverified. |

The venue is authoritative for what it reports about its external state; this does **not** mean every venue response is automatically fresh, complete, internally consistent, or correct. The system owns its local record of intentions, approvals, requests, responses, observations, and operator actions.

| Quantity | Authority | Local handling | Failure response |
|---|---|---|---|
| Order acceptance and status | Venue, subject to verified query semantics | Persist observations with source and observation time | If unknown or contradictory, block related replacement and new exposure; reconcile. |
| Fills and actual position | Venue, subject to completeness checks | Maintain a derived local view and compare against venue observations | On mismatch, block new entries and preserve both records. |
| Balance and equity | Venue for exchange-reported values | Cache with timestamp and account/instrument scope | Stale, missing, or inconsistent values cannot authorize entries. |
| Intent, risk decision, and request history | Local durable ledger | Append auditable records before external side effects | If unreadable or incomplete, refuse new live entries and require recovery. |
| Owner-approved limits and historical risk state | Local protected records, supplemented by reconciled venue data | Verify integrity and provenance before evaluation | Unknown limits or history are a hard veto; do not reset history to zero. |

**Status:** **PROVISIONAL.** The exchange’s actual query coverage, ordering, pagination, retention, and snapshot consistency must be verified in a future separately authorized integration. Until then, complete reconciliation cannot be claimed.

## 2. Risk authority and order admission

The signal proposes an intent. A separate logical risk authority approves or vetoes it. Separation is an authority and test boundary; it does not by itself require a separate process.

### Intent contract

A proposed order intent contains at least:

- durable intent identifier and configuration version;
- instrument, direction, intended quantity, order type, and price constraints where applicable;
- decision time and data versions used;
- intended exit/protection policy;
- estimated fees, slippage, funding exposure, and loss at the assumed protective fill;
- expiration condition for the intent.

The risk authority evaluates the intent against owner-approved limits and current reconciled state. An approval is scoped to the exact intent and the state/configuration versions evaluated. If a material input changes before submission, approval expires and the intent must be evaluated again.

### Admission checks

A new live entry is vetoed if any required input is absent, stale, inconsistent, or unevaluable. Checks include:

1. Approved risk policy and intact risk history.
2. Current reconciled position, orders, balance, and applicable margin state.
3. Estimated per-intent loss and aggregate concurrent risk, including open orders that may fill.
4. Owner-approved daily-loss, drawdown, position-count, and exposure constraints.
5. Instrument constraints and sufficient margin under verified contract rules.
6. Valid data, configuration, credentials/permissions, and clock state.
7. No unresolved order outcome that could make the proposed exposure duplicative.

**Risk values:** **OWNER_DECISION_PENDING.** The design does not assume the illustrative percentages in the master prompt. The risk authority cannot be tuned or bypassed by a signal, optimizer, retry, Telegram failure, or acknowledgement.

### Protective-order uncertainty

A stop order is an instruction, not a guaranteed realized-loss ceiling. Whether Toobit supports the required order type, reduce-only behavior, trigger basis, atomic linkage, and recovery queries is **UNRESOLVED**.

**Safe branch:** do not enable a live strategy requiring a protective-order mechanism until that mechanism and its failure behavior have been verified. If protection is absent, rejected, ambiguous, or no longer covers the actual position, block new entries, alert the operator, and use only a separately verified risk-reducing procedure. Do not assume an attempted close succeeded.

## 3. Order lifecycle

### State catalog

These states describe the local lifecycle of one order intent. They are not a claim that Toobit uses the same names.

| State | Meaning | Permitted next states |
|---|---|---|
| **Intent recorded** | Intent and its unique local identifier are durably recorded; no request has been sent. | Risk approved; rejected locally. |
| **Risk approved** | The exact intent passed risk checks against recorded state and configuration versions. | Submission pending; rejected locally if approval expires. |
| **Submission pending** | A submission request is being issued or its outcome is not yet durably known. | Acknowledged; rejected by venue; outcome ambiguous. |
| **Acknowledged** | A venue observation establishes that an order exists, subject to later fills or cancellation. | Partially filled; filled; cancel pending; rejected by venue if venue semantics permit; reconciliation. |
| **Partially filled** | At least one fill is observed and the order is not known to be fully filled or cancelled. | Partially filled; filled; cancel pending; reconciliation. |
| **Cancel pending** | A cancellation was requested; final outcome is not established. | Cancelled; partially filled; filled; outcome ambiguous; reconciliation. |
| **Filled** | Venue evidence establishes completion under verified order semantics. | Reconciliation if later evidence contradicts the local record. |
| **Cancelled** | Venue evidence establishes cancellation of the remaining quantity; prior fills remain effective. | Reconciliation if later evidence contradicts the local record. |
| **Rejected by venue** | Venue evidence establishes rejection under verified semantics. | Reconciliation if contradictory evidence appears. |
| **Rejected locally** | No submission was authorized or the intent expired before submission. | A new intent requires a new evaluation. |
| **Outcome ambiguous** | Acceptance, cancellation, or completion cannot be established. | Reconciliation. |
| **Reconciliation** | Queries and observations are being compared to resolve state. | Any state supported by sufficient venue evidence; remain ambiguous if evidence is insufficient. |

### Transition rules

1. **Before submission:** persist the intent, approval, client identifier, and request fingerprint. If persistence fails, do not submit.
2. **Submission timeout:** a timeout, including the owner-ratified `-1007` condition, moves the order to **outcome ambiguous**. It does not establish rejection.
3. **Partial fill:** update actual exposure from observed fills. The unfilled remainder remains potentially live until the venue establishes otherwise.
4. **Cancel/fill race:** cancellation is not final until observed. A fill received while cancellation is pending must be incorporated before position and protection are evaluated.
5. **Crash:** on restart, any request whose outcome is not durably established is treated as ambiguous. Reconcile before replacement or new exposure.
6. **Contradiction:** retain both observations with timestamps and sources. Do not overwrite one silently; block affected entries until resolved.
7. **Terminal state:** “filled,” “cancelled,” and “rejected” are terminal only while consistent with subsequent authoritative evidence.

### Client identifiers and retries

The client identifier uses only the owner-ratified character intersection `[A-Za-z0-9_-]`. It must be generated from a durable, non-reused intent identity and mapped to the exact request fingerprint.

**UNRESOLVED:** the venue’s supported identifier length, uniqueness scope, reuse behavior, lookup behavior, and duplicate-request semantics have not been inspected. Until verified, an identifier cannot be treated as a venue-enforced idempotency guarantee.

A retry policy requires a finite attempt budget, backoff, a deadline, and explicit rate accounting. Their numeric values remain **UNRESOLVED** because endpoint weights, limits, latency, and failure behavior were not verified. No retry may convert an ambiguous submission into a fresh submission without reconciliation. A rate-limit response stops or delays work according to the verified policy; it does not grant permission to bypass risk checks.

## 4. Reconciliation and recovery

### Reconciliation procedure

1. Freeze affected new entries; retain the unresolved intent and all observed responses.
2. Obtain the venue’s available order, fill, position, and balance observations for the relevant scope.
3. Validate query completeness, pagination, freshness, and consistency using venue-specific rules once those rules are verified.
4. Compare observations with durable intents and local fill records. Record discrepancies rather than silently rewriting history.
5. Recompute exposure and protection requirements from the reconciled position.
6. Clear the reconciliation veto only when the defined completeness and consistency checks pass.
7. If the configured resume gate applies, require a separate authorized acknowledgement after recovery. An acknowledgement issued while the veto remains active is refused with the current reason.

**Blocker:** no authenticated query was performed in this engagement, and venue retention is unresolved. A successful future query is not sufficient by itself unless it establishes the relevant history is complete.

### Loss of Telegram connectivity

**DESIGN_JUDGMENT:** when Telegram is unreachable, prohibit operator-dependent new actions; continue independently enforced risk and reconciliation where the runtime and venue connection remain available. Existing positions and orders must not be represented as closed merely because alerts cannot be delivered.

The precise automated action for an already open position—retain verified protection, cancel an entry remainder, or submit a risk-reducing order—depends on verified venue semantics and a separately approved operating policy. Until that policy exists, live operation is **BLOCKED**.

### Corrupt or missing persistent state

- Refuse live startup and new entries.
- Preserve the damaged records for investigation; do not initialize risk history from current account values.
- Alert through Telegram if available, identifying the failed check.
- Stop the affected process before an out-of-band restore that requires exclusive access.
- Restore a verified backup or reconstruct the missing history from sufficient evidence.
- Reconcile restored state with the venue.
- Clear each veto only after its recovery condition passes; apply the separate acknowledgement gate where required.

An operator’s acknowledgement does not substitute for missing history. If the history cannot be restored or reconstructed sufficiently to evaluate a hard limit, live entries remain blocked.

### Procedure consistency

| Procedure | Required process state | Invocation rule |
|---|---|---|
| Detect integrity failure and refuse startup | Starting or running | May be performed by the process; it must not perform an exclusive offline restore inline. |
| Offline restore requiring exclusive access | Stopped | Performed outside the stopped process; restore method remains to be specified and tested. |
| Venue reconciliation after restore | Running in a restricted recovery state | New entries remain blocked while observations and restored records are compared. |
| Resume acknowledgement | Running, after relevant veto recovery | Refused while the underlying veto condition still fails. |

**Status:** **NOT TESTED.** The table defines non-contradictory intended process states; no restore drill or crash-recovery test was run.

## 5. Telegram mode and control contract

Telegram is the sole routine operator interface, not a risk authority. Privileged requests require authenticated and authorized operator identity, input validation, replay protection, and an auditable result. Specific Telegram transport and identity implementation remain **UNRESOLVED** pending a comparison of polling and feasible relay/webhook infrastructure.

| Operator action | Checks available and required at action time | Result on failure |
|---|---|---|
| Read status | Authorization for the requested information; available local state | Return known state and explicitly mark stale or unknown fields. |
| Select paper mode | Authorized request and valid configuration for paper operation | Refuse if configuration cannot be evaluated. This selection does not require the live-exchange clock interlock. Paper decisions still require sufficiently trustworthy timestamps and data. |
| Request live mode | Authorized request plus the six interlocks in the master prompt: data validity, reconciliation, risk-limit evaluation, credentials and permissions, configuration integrity, clock quality | Refuse live transition and report each failing or unevaluable interlock. |
| Pause new entries | Authorized request | Persist pause where possible; report if durable recording fails. Pausing does not assert that open orders or positions were cancelled or closed. |
| Resume entries | Authorized request; applicable active vetoes recovered; required acknowledgement complete; current aggregate state and mode readiness evaluable | Refuse with the active veto or missing recovery condition. A per-trade calculation is performed later, when a specific intent exists. |
| Acknowledge recovered incident | Authorized request; the incident’s underlying veto has already cleared | Refuse while the condition remains failing; do not change risk history or clear the veto. |
| Request risk-reducing close | Authorized request and a separately verified procedure capable of identifying the actual position and avoiding unintended exposure | If state or venue semantics are ambiguous, report that the action is unresolved; do not claim a close occurred. |

The command names, message schemas, authorization mechanism, and exact refusal text remain **UNRESOLVED**. Their absence blocks an implementation-ready Telegram interface; they are not represented as tested.

## 6. Verification specifications

No test below has been executed. Each is designed to distinguish a correct behavior from a specific faulty one.

| Test | Fixture and action | Required result | Blind spot |
|---|---|---|---|
| Ambiguous submission | Submission reaches a simulated venue; response is lost. Restart the process. | Intent remains ambiguous; no replacement is submitted before reconciliation establishes the outcome. | Does not prove real venue query retention or idempotency. |
| Cancel/fill race | A fill occurs after cancellation is requested and before cancellation is confirmed. | Fill changes position; cancelled remainder and actual exposure are recorded separately; protection is re-evaluated. | Depends on realistic venue event semantics. |
| Missing risk history | Remove or corrupt the persisted drawdown/loss record before startup. | Live entries and live transition are refused; no zero initialization; acknowledgement alone cannot clear the veto. | Does not prove backup completeness. |
| Recovery acknowledgement | Cause a veto, issue acknowledgement while failing, then recover the underlying condition. | First acknowledgement is refused; recovery clears the veto; if the resume gate applies, a subsequent acknowledgement is required. | Does not establish the correctness of every recovery predicate. |
| Telegram outage | Disconnect the operator channel while a position and pending order are present in a controlled simulation. | Risk logic remains active; position/order state is not marked resolved merely due to missing alerts. | Does not validate the venue’s protective-order behavior. |
| Stale clock | Present a clock offset or synchronization age beyond the later-established tolerance. | Live transition and live actions requiring trusted time are refused; paper-mode selection remains separately evaluable. | Tolerance cannot pass acceptance until derived and measured. |
| Offline restore | Fail an integrity check during startup. | Process refuses live start and does not invoke a stopped-process restore inline. | Does not prove restored data is complete or authentic. |

## 7. Adversarial review of this part

| Finding | Consequence | Containment and status |
|---|---|---|
| A client identifier may not provide venue-side idempotency. | Reusing or resubmitting an intent could create duplicate exposure. | Identifier is only a correlation key until venue semantics are verified; ambiguous outcomes require reconciliation. **BLOCKED pending source verification.** |
| A protective stop may fail, fill late, or not cover a partial fill. | Realized loss can exceed planned loss. | Protection is evaluated against actual reconciled exposure; missing or ambiguous protection vetoes entries. **NOT TESTED.** |
| Acknowledgement could be mistaken for risk-state recovery. | Unknown historical loss could be silently treated as zero. | The recovery procedure explicitly separates restored evidence, veto clearance, and acknowledgement. **Design inspection only; NOT TESTED.** |
| A local ledger and venue snapshot may disagree because of incomplete queries or timing. | Incorrect exposure or premature resumption. | Preserve discrepancies and block affected entries until completeness and consistency are established. **BLOCKED pending verified query semantics.** |
| A running process might attempt an offline restore requiring exclusive access. | Restore can corrupt state or produce inconsistent records. | The procedure table requires the process to stop before exclusive restore. **Design inspection only; NOT TESTED.** |

## Artifact registry update

| Artifact | Location | Status |
|---|---|---|
| Pre-research checkpoint, capability inventory, initial evidence and strategy candidates | Part 1 | DELIVERED |
| State authority, risk admission, order lifecycle, reconciliation, and recovery contracts | Part 2, §§1–4 | DELIVERED as a proposed design |
| Telegram action preconditions | Part 2, §5 | DELIVERED in partial form; detailed schemas and transport remain unresolved |
| Execution and recovery test specifications | Part 2, §6 | DELIVERED; all tests unexecuted |
| Adversarial review of execution and recovery | Part 2, §7 | DELIVERED; findings remain subject to the stated blockers |
| Complete requirements register and matching verification matrix | Not yet delivered | BLOCKED as a completed artifact |
| Universe, research protocol, device envelope, deployment comparison, and final completeness declaration | Not yet delivered | BLOCKED as completed artifacts |

**Part completeness:** the execution and recovery contracts above are delivered for their stated scope, with unresolved venue dependencies disclosed. The overall design remains incomplete and is not authorized or ready for live trading.


# Part 3 — Requirements register and research protocol

**یادداشت وضعیت:** این بخش الزامات طراحی و روش ارزیابی راهبرد را ثبت می‌کند. جدول آزمون‌های متناظر، انتخاب نهایی نمادها و ارزیابی دستگاه هنوز کامل نشده‌اند. هیچ بک‌تست یا آزمون نرم‌افزاری انجام نشده است.

Part 1 recorded the checkpoint and initial candidates. Part 2 specified proposed execution, risk, and recovery contracts. This part defines the project requirements and the research procedure needed to assess a candidate without treating a proposal as a validated strategy.

## 1. Requirements register

**Status interpretation:** A requirement’s status below describes its acceptance as a project deliverable, not whether the owner stated it. **BLOCKED** means required evidence or a decision is unavailable; **NOT TESTED** means the required verification has not been performed. The master prompt is the supplied parsed text, not an independently inspected PDF.

Every identifier in this table is defined here. The “regression” column names requirements to revisit when the row changes.

| ID | Priority | Requirement and rationale / source | Verification method | Acceptance condition | Status and observed evidence | Failure response | Regression |
|---|---|---|---|---|---|---|---|
| R-001 | HARD | Live execution venue is Toobit; owner selection, master prompt §3.1.1. | Design inspection and later venue integration test | All live order paths target the selected venue and verified account scope. | **NOT TESTED:** no integration exists or was inspected. | Block live operation. | R-007, R-008, R-012 |
| R-002 | HARD | Telegram is the sole routine operator interface; §3.1.2. | Design inspection and interface test | Mode, control, alerts, acknowledgements, monitoring, and authorized read-only review are available through one bot. | **NOT TESTED:** Part 2 specifies action preconditions, not complete commands or implementation. | Block operational acceptance. | R-009, R-010, R-014 |
| R-003 | HARD | UTC governs instants and records; monotonic time governs elapsed deadlines; §3.1.3. | Deterministic clock tests | Timestamps have defined roles; stale or excessive clock error triggers the applicable refusal. Numeric tolerances require derivation. | **BLOCKED:** tolerance and tests are unavailable. | Veto affected live actions and time-dependent decisions. | R-005, R-008, R-009 |
| R-004 | HARD | This engagement is design-only and does not access accounts, credentials, or orders; §3.1.4. | Inspection of engagement actions | No prohibited access or external trading action occurs. | **PASS for work reported so far:** no tools, account calls, credentials, or orders have been used in Parts 1–3. | Stop any proposed prohibited action. | R-001, R-012 |
| R-005 | HARD | Cross-venue data must satisfy owner access, free-use, licensing, and research/paper/live restrictions; §3.1.5. | Source check, lineage tests, owner/legal decision | Each source has a use classification; disallowed or unestablished sources cannot flow into restricted paths. | **BLOCKED:** source identity and legal/access conditions are not established. | Exclude the source from affected paths. | R-006, R-011, R-015 |
| R-006 | HARD | Strategy expresses intraday intent and derives a holding-duration policy from evidence; §3.1.6. | Research evaluation and design inspection | Candidate holding and exit rules are explicit and supported by applicable data, costs, and validation. | **BLOCKED:** no strategy results or holding-duration evidence. | Do not promote the candidate. | R-011, R-013, R-015 |
| R-007 | HARD | Hard risk limits are owner-approved, independently enforced, and not adjustable by forecasts or optimization; §§3.3, 8.5, 9.6. | Owner decision and invariant tests | Required limits and risk state are defined, evaluable, intact, and enforced on each applicable intent. | **BLOCKED:** limits and risk history are not established; Part 2 states the proposed veto behavior. | Refuse live transition and new entries. | R-008, R-009, R-013, R-014 |
| R-008 | HARD | Orders, partial fills, cancellations, ambiguous outcomes, and reconciliation must be traceable; §§5.1, 9.7. | Contract, fault-injection, and authorized integration tests | No replacement is submitted solely because of timeout; external state and local records reconcile under verified venue semantics. | **BLOCKED:** Part 2 proposes a lifecycle; actual venue semantics, implementation, and tests are unavailable. | Block affected new exposure and reconcile. | R-001, R-007, R-009, R-014 |
| R-009 | HARD | Live mode requires data, reconciliation, risk, credentials/permissions, configuration, and clock interlocks; §3.1.10. | Deterministic interlock and authorized permission tests | Each interlock passes independently; any failed or unknown check yields a specific refusal. | **BLOCKED:** no implementation, approved risk policy, or authorized account checks. | Refuse live mode. | R-002, R-003, R-007, R-008, R-010 |
| R-010 | HARD | Operator-channel loss must not release safety controls or falsely resolve positions; §§3.1.9, 9.9. | Network fault injection and recovery drill | Risk enforcement persists independently of Telegram; pending outcomes remain unresolved until evidence establishes them. | **NOT TESTED:** proposed behavior appears in Part 2. | Pause new entries; preserve unresolved state and attempt only verified recovery procedures. | R-002, R-008, R-009, R-014 |
| R-011 | HARD | Research is point-in-time, reproducible, selection-aware, and net of realistic costs; §§8.1–8.4. | Data audit, replay, historical evaluation, and statistical checks | Frozen data and experiment records permit reproduction; leakage, trial accounting, costs, and uncertainty are evaluated. | **BLOCKED:** data, trial-budget inputs, and execution-cost observations are unavailable. | Do not claim strategy validation or promote it. | R-005, R-006, R-013, R-015 |
| R-012 | SHOULD | Derive workload before choosing deployment; compare feasible topology and phase fit against the reference handset; §3.1.8. | Workload calculation and representative device experiments | Peak resource, latency, availability, and recovery requirements are compared with measured device behavior; compromises are disclosed. | **BLOCKED:** workload and sustained device measurements are unavailable. | Do not claim a deployment topology is fit for live operation. | R-001, R-010, R-014, R-015 |
| R-013 | HARD | Small-account feasibility must account for quantity, notional, margin, fees, funding, slippage, and contract constraints; §§3.1.11, 3.3. | Calculation and venue specification checks | Each proposed order satisfies verified instrument constraints and owner-approved risk limits after realistic costs. | **BLOCKED:** instrument specifications, current fees, and approved risk limits are unavailable. | Reject unevaluable intents and withhold feasibility claims. | R-006, R-007, R-011, R-015 |
| R-014 | HARD | Persistent state, secrets, recovery, audit, and privileged actions require integrity and controlled access; §9.8. | Security tests, corruption injection, backup/restore drill | A missing or corrupt risk ledger does not initialize to zero; recovery and authorization are auditable and tested. | **NOT TESTED:** Part 2 describes intended behavior; no implementation or recovery drill exists. | Refuse affected live actions and initiate verified recovery. | R-002, R-007, R-008, R-010, R-012 |
| R-015 | SHOULD | Derive the broadest defensible symbol/timeframe universe from strategy needs, data, costs, statistical budget, and resources; §10. | Source census, calculations, experiments, and resource tests | Each included symbol/timeframe has evidence of eligibility and explicit narrowing/widening conditions. | **BLOCKED:** current listings, per-cell depth, cost and resource measurements are unavailable. | Keep the universe provisional; no unverified cell is admitted to live use. | R-005, R-006, R-011, R-012, R-013 |
| R-016 | HARD | Distinguish design, research, implementation, paper, operational readiness, and live authorization; §11.3. | Acceptance-record inspection | Each dimension has its own evidence and status; no test plan is reported as a test result. | **NOT TESTED as a final deliverable:** final acceptance record has not been assembled. | Withhold any readiness claim. | R-009, R-011, R-012, R-014 |
| R-017 | HARD | Technical methods and architecture are delegated; owner decisions remain limited to non-delegable policy, authorization, and preferences; §§3.1.12–13. | Decision-record inspection | Technical alternatives are evaluated without asking the owner to select delegated methods; pending owner decisions are identified. | **NOT TESTED as a final deliverable:** the complete decision record has not been assembled. | Rework decisions or identify the actual owner-level blocker. | R-005, R-007, R-012 |
| R-018 | HARD | Deliver a traceable design, matching verification matrix, unresolved items, and truthful completeness declaration; §§6, 11, 12, 13. | Register/matrix count and final audit | Every register row has one matching verification row; outstanding blockers and unexecuted tests are disclosed. | **BLOCKED:** the matching matrix and final declaration have not yet been delivered. | Report the design as incomplete. | R-001 through R-017 |

The register contains **18 requirements**. A matching 18-row verification matrix has **not** yet been delivered; no matrix-coverage pass is claimed.

## 2. Candidate research design

### Question and candidates

The research question is whether a causal intraday rule can produce defensible net results on eligible Toobit perpetual contracts under realistic execution assumptions and owner-approved risk constraints.

The candidates introduced in Part 1 remain:

- **Baseline:** a rule using completed candles from one interval.
- **Context candidate:** the baseline conditioned on information from a slower completed interval.
- **Predictive candidate:** a trained model, evaluated only if its data and trial burden are justified.

No candidate has a demonstrated edge. A complete entry rule, exit rule, parameters, eligible instruments, and holding-duration policy must be frozen before the corresponding evaluation. Those values cannot be derived from the supplied summary alone.

### Experiment record

Before evaluating a candidate, its immutable record must contain:

1. Data source, permitted use, symbol and contract identity, interval, coverage, versions, and known gaps.
2. Candidate rule and all parameters, including exit and maximum holding policy.
3. The complete configuration set or deterministic generator, including configurations screened and discarded.
4. Training, selection, validation, and final holdout periods, with the exact boundaries frozen before use.
5. Fees, spread, slippage, funding, order and fill assumptions, and instrument constraints.
6. Selection objective, stopping rule, promotion rule, and conditions for retirement.
7. Code and configuration versions, random seeds where relevant, and all observed outcomes.

If the candidate or selection process changes after observing a holdout, that holdout is no longer an untouched confirmation set for the changed procedure. A new untouched evaluation period or an explicitly exploratory designation is required.

### Trial budget

The supplied prompt reports a constraint against exhaustive permutation grids at intervals of 12 hours or less. It also states that published trial figures require per-cell recomputation. The underlying formulas, panel values, and inputs needed for that recomputation are not supplied in reproducible form here.

**Status: BLOCKED.** No numerical configuration budget is approved.

For each proposed symbol/timeframe evaluation cell, the future research record must provide:

- the published figure and source, if available;
- all inputs and the formula used for independent recomputation, with consistent return and time units;
- the resulting published/recomputed comparison;
- dependence and pooling assumptions;
- the governing limit and explanation of any discrepancy;
- all evaluated variants, including failed and informal variants that influenced selection.

The prompt contains an ambiguity when the published and recomputed values differ by more than a factor of two. Pending clarification, Part 1’s conservative branch uses the smaller value; this does not resolve the wording conflict.

A pre-registered small candidate set is the **provisional first method** because it makes the tested family inspectable and avoids an exhaustive grid. It is not presumed valid merely because it is small. Sequential testing or bounded optimization may be considered if an explicit error-control method and admissible budget can be established.

### Chronology and leakage

For a bar-based signal:

- A bar’s open time, close time, and time at which its final value became available are distinct.
- A decision may consume the final bar only after it is known and has passed quality checks.
- A simulated order cannot fill before its simulated submission time.
- The data set must preserve listings, delistings, contract changes, and missing periods where available.
- Overlapping outcome windows require a separation policy appropriate to the candidate’s holding horizon; purging or embargo is not applied as a magic correction without defining that horizon.
- Cross-symbol and serial dependence must be reflected in uncertainty estimation; more rows do not automatically mean the same number of independent observations.

**Blocked input:** historical point-in-time availability and listing coverage have not been verified. A data set lacking them cannot support a clean point-in-time claim.

### Execution and cost model

Candle data alone cannot establish whether a maker order filled, its queue position, or the order of a stop and profit target touched within one bar. Therefore:

- A candidate relying on maker fills requires order-book/trade evidence or a deliberately conservative fill model whose limitations are reported.
- Where intrabar ordering is unknown, the simulator must not choose whichever sequence produces the better outcome.
- Fees must be reported under both stated taker values, 0.05% and 0.06%, until the discrepancy is resolved.
- Spread, slippage, funding, latency, partial fills, rejection, minimum quantity/notional, and liquidation must be modeled only where their inputs and semantics are supportable.
- Missing cost inputs produce a bounded scenario or an unresolved result—not an assumed zero.

A future result report must separately show gross return, net return, turnover, drawdown, tail exposure, capacity, execution sensitivity, and uncertainty. At least two explicit cost scenarios are required. **No returns or confidence intervals have been calculated here.**

### Controls and promotion

| Check | Purpose | Acceptance consequence | Status |
|---|---|---|---|
| Simple baseline | Measures whether added context or modeling earns its complexity. | More complex candidate requires a predeclared incremental comparison. | **NOT TESTED.** |
| Ablation | Removes one candidate component while keeping the evaluation comparable. | A component without defensible incremental benefit is reconsidered. | **NOT TESTED.** |
| Negative control | Introduces a condition expected to break the claimed predictive relationship or catches deliberately injected future information. | A positive leakage-control result triggers investigation; it is not evidence of strategy performance. | **NOT TESTED.** |
| Chronological holdout | Evaluates a frozen procedure on data not used to select it. | Failure to meet predeclared criteria prevents promotion. | **BLOCKED:** no frozen procedure or holdout data. |
| Cost stress | Tests whether conclusions survive specified adverse cost assumptions. | Report each scenario separately; do not claim robustness from an optimistic scenario alone. | **BLOCKED:** cost inputs are unavailable. |

Promotion to paper requires a frozen candidate, permitted data, an admissible trial record, reproducible evaluation, specified simulation assumptions, and passing tests applicable to paper operation. Promotion to live additionally requires the six live interlocks and any future authorization. A paper result, even if positive, does not establish live profitability.

## 3. Data eligibility and quality rules

| Data class | Material use | Status and constraints | Failure behavior |
|---|---|---|---|
| Toobit candles | Candidate signal and historical evaluation | Owner-ratified interval capability and a maximum observed depth are not proof of depth for any particular cell. | Mark missing or invalid bars; prohibit dependent decisions. |
| Orders, fills, positions, balance | Reconciliation and risk evaluation | Actual authenticated query coverage and semantics are **UNRESOLVED**. | Block live entries when incomplete, stale, or contradictory. |
| Contract metadata | Quantity, price increments, margin and order constraints | Current symbol-specific rules are **UNRESOLVED**. | Reject intents that cannot be validated. |
| Fees, spread, slippage, funding | Net economics and risk estimation | Fee discrepancy is unresolved; funding is a tail term rather than a known bounded cost. | Use explicit scenarios where supported; otherwise withhold feasibility claims. |
| Order-book/trade observations | Maker fill and execution realism | Availability, retention, depth convention, and completeness are **UNRESOLVED**. | Do not claim candle-only evidence proves maker fills. |
| Cross-venue historical candles | Longer research history where permitted | Owner-supplied transfer evidence has bounded timeframe and source scope; legal/access conditions are unresolved. | Preserve source tags and prohibit restricted use. |
| Historical open interest | Possible incremental explanatory feature | Availability remains **UNRESOLVED** in the supplied audit summary. | No candidate may require it until a permitted, verified source exists. |
| Disputed mark-price change field | Possible derived feature | Semantics are conflicted in the owner’s records. | Do not use it as a critical input until semantics are verified; use independently defined values if available. |

**Duplicate observations:** identify by source, instrument, interval, and the source’s event identity or bar time. Identical duplicates may be coalesced while retaining provenance; conflicting duplicates are retained and quarantined pending a source-specific resolution rule.

**Malformed observations:** reject or quarantine observations that fail schema, timestamp, numeric-domain, or internally consistent OHLC checks. A missing value is not zero.

**Stale observations:** the maximum age depends on the decision and measured source behavior; it is **UNRESOLVED**. Until a threshold is derived and verified, a decision requiring freshness cannot pass merely because a value exists.

## 4. Registry update and continuation state

| Artifact | Location | Status |
|---|---|---|
| Checkpoint, capability inventory, candidate comparison | Part 1 | DELIVERED |
| Execution, risk, reconciliation, and recovery proposal | Part 2 | DELIVERED; tests and venue semantics unresolved |
| Requirements register | Part 3, §1 | DELIVERED as the current register; acceptance statuses remain open |
| Research and data protocol | Part 3, §§2–3 | DELIVERED as a proposal; historical evaluation has not run |
| Matching verification matrix | Not yet delivered | BLOCKED as a completed artifact |
| Universe derivation, workload envelope, deployment comparison, and phase plan | Not yet delivered | BLOCKED as completed artifacts |
| Final adversarial audit and completeness declaration | Not yet delivered | BLOCKED as completed artifacts |

**Part completeness:** this part delivers its stated register and research-protocol scope. The design remains incomplete; the 18-row matching verification matrix, resource analysis, and final acceptance record are outstanding.


# Part 4 — Universe, workload, and deployment

**یادداشت وضعیت:** مجموعهٔ نهایی نمادها و تناسب گوشی هنوز قابل تأیید نیست. این بخش روش انتخاب، فرمول‌های منابع و گزینه‌های استقرار را مشخص می‌کند؛ هیچ آزمون عملکردی روی دستگاه انجام نشده است.

Parts 1–3 established the initial candidates, execution and recovery proposal, requirements register, and research protocol. This part addresses how a candidate universe and deployment would be derived without treating the owner’s measurement examples as a recommended universe.

## 1. Universe derivation

### 1.1 Strategy information needs

The first research candidate is a completed-candle, single-timeframe baseline. Its dependency graph is:

```text
Eligible instrument metadata
        +
Completed, validated candles at interval T
        +
Cost and execution assumptions
        ↓
Candidate signal and exit rules
        ↓
Independent risk evaluation
```

**PROVISIONAL:** one interval per experiment is sufficient to define this baseline. No particular interval has yet earned selection: the signal rule, intended holding duration, available history, and execution costs are unresolved.

A slower context interval is a separate candidate, not an assumed dependency. It must demonstrate incremental value against the baseline under the frozen comparison described in Part 3. If it is tested, its bar must be complete and known before the faster-interval decision uses it.

### 1.2 Eligibility screens

For each Toobit perpetual symbol and candidate supported interval:

1. **Instrument:** establish active contract identity, quote currency, trading status, quantity and price increments, minimum order constraints, and applicable margin rules.
2. **Liquidity and execution:** establish whether the intended order size can be executed within the candidate’s cost assumptions. Daily volume alone does not establish executable book depth or maker fill probability.
3. **History:** measure actual usable candle depth and gaps for that symbol and interval. The reported 3,500-candle cap is not an assumed observation count.
4. **Research admissibility:** establish the applicable trial budget and point-in-time coverage.
5. **Resources:** compare the resulting workload with measured capacity for the selected phase.
6. **Strategy information:** retain the interval only if it contributes to a specified signal, exit, or context decision.

A cell with unresolved required evidence remains **BLOCKED for live admission**. It may be investigated as a research candidate if its permitted data and limitations are explicit.

### 1.3 Liquidity threshold: parametric derivation

Define:

- \(E\): equity in USDT;
- \(r\): owner-approved per-trade nominal risk fraction;
- \(d\): assumed adverse price movement to the stop fill, as a fraction;
- \(c\): estimated trade costs in USDT;
- \(N\): intended order notional in USDT;
- \(V_{24h}\): measured 24-hour traded notional in USDT;
- \(x\): maximum permitted ratio of intended notional to measured 24-hour notional.

The planned-risk condition from Part 1 is:

\[
Nd+c \le Er.
\]

When \(d>0\) and \(Er>c\), a risk-derived upper bound is:

\[
N \le \frac{Er-c}{d}.
\]

A **screening proxy**, not an execution guarantee, would require:

\[
\frac{N}{V_{24h}} \le x
\quad\Longleftrightarrow\quad
V_{24h}\ge\frac{N}{x}.
\]

For example, the algebraic threshold for a candidate notional \(N\) is \(N/x\) USDT of measured daily notional. This cannot yet produce an approved numeric threshold:

- \(r\) is an owner decision;
- \(d\), \(c\), and \(N\) depend on the untested candidate and venue rules;
- \(x\) has no evidence-backed value in the supplied material;
- daily notional does not establish spread, depth at the intended size, or fill quality.

**Status: UNRESOLVED.** A future calibration must compare observed execution cost and fill behavior across eligible instruments and sizes, then justify \(x\) as a screening parameter. Even a symbol passing that screen still requires executable-liquidity checks. No number is presented as the final threshold.

### 1.4 Universe register

| Symbol and interval | Inclusion reason | Evidence | Status | Widening or narrowing | Failure behavior |
|---|---|---|---|---|---|
| No cell selected | No candidate has passed the required instrument, data, cost, statistical, and resource screens. | Owner-supplied capability and snapshot summaries; no cell-level census inspected. | **BLOCKED:** cell-level inputs unavailable. | Add a cell only after its required evidence passes; remove or pause it when a required condition fails. | Do not trade an unevaluable cell. |

The ten instruments used in the owner’s storage measurement are not used here as a candidate list. The absence of a selected cell is an evidence limitation, not a conclusion that no instrument can qualify.

### 1.5 Breadth trade-off

A measured Pareto frontier cannot be calculated without the eligible-cell census, workload, and costs. The decision space is nevertheless explicit:

- **More cells on a fixed device:** broader coverage, with greater data, compute, network, and validation demands.
- **Fewer cells on the device:** lower workload, with reduced opportunity coverage and potentially different concentration.
- **Remote processing:** may preserve breadth, but adds infrastructure, network dependence, operating cost, and potentially legal or access constraints.

**Status: BLOCKED.** No point is selected as optimal until both the workload and feasible infrastructure are measured.

## 2. Workload envelope

The following are sizing formulas, not claims that the device meets them.

### 2.1 Storage

The owner-supplied measurement was approximately 1.25 GB for:

\[
3{,}500\ \text{candles}\times14\ \text{intervals}\times10\ \text{symbols}
=490{,}000\ \text{candle records}.
\]

For a matching storage shape:

\[
\text{measured ratio}
=\frac{1.25\ \text{GB}}{490{,}000\ \text{records}}
\approx 2.55\times10^{-6}\ \text{GB per record}.
\]

For a candidate universe with \(S\) symbols and actual retained candle count \(B_{s,t}\) per symbol/interval:

\[
\text{estimated candle storage}
\approx
\left(\sum_{s=1}^{S}\sum_t B_{s,t}\right)
\frac{1.25\ \text{GB}}{490{,}000}.
\]

**Assumption:** the schema, indexing, database overhead, and data shape match the measured case closely enough for linear scaling. This does not estimate orders, audit records, funding, order books, backups, temporary files, or write-ahead-log peaks. Those require separate measurements. The reported 56 GB free space is a past owner snapshot, not current available capacity.

### 2.2 Compute and latency

For each phase, measure or bound:

\[
\text{work} =
\text{records processed}
\times
\text{operations per record}
\times
\text{evaluations},
\]

with separate allowances for I/O, serialization, concurrent ingestion, and recovery.

The operational envelope must include:

- peak data arrival and processing backlog;
- decision-to-submission latency budget, derived from the selected strategy and order type;
- maximum tolerable data age;
- required recovery time and availability target;
- peak memory, disk headroom, thermal behavior, and network usage.

All numerical bounds are **UNRESOLVED**. Processor specifications and a prior charging observation do not establish sustained performance for this workload.

### 2.3 Network

For historical collection, estimate:

\[
\text{transfer bytes}
=
\sum_{\text{request types}}
(\text{request count}\times\text{measured payload bytes}).
\]

Request count depends on actual endpoint pagination, available history, retries, and rate limits. Runtime transfer also includes market updates, account observations, reconciliation, and Telegram traffic. Payload sizes and endpoint weights have not been measured in this engagement.

## 3. Deployment candidates and device tests

### 3.1 Comparison criteria

Evaluate each topology on workload fit, ability to preserve risk during interruptions, recovery, network dependency, secret handling, operator burden, and permitted infrastructure. Telegram remains the sole operator interface regardless of internal topology.

| Topology | Potential fit | Specific gap and status |
|---|---|---|
| **Phone only:** research, paper, and live runtime on the handset | Avoids an additional runtime host if the device meets every phase envelope. | **PROVISIONAL:** sustained compute, process survival, network, recovery, and storage have not been measured. |
| **Phone plus one-off remote research:** operational runtime remains on the phone | Could address a research-only compute shortfall without moving live execution. | **PROVISIONAL:** remote infrastructure availability, cost, permissions, and phone operational fit are unknown. |
| **Phone development with remote live runtime:** research and other phases placed according to measured fit | Could separate live availability from handset process restrictions. | **PROVISIONAL:** an allowed remote host and its availability, cost, security, and network fit are unverified. |
| **Fully remote runtime and research** | Could consolidate workloads away from the handset while retaining Telegram as the interface. | **PROVISIONAL:** provider access, legal conditions, operating cost, and measured workload fit are unknown. |
| **Hybrid with an internal relay:** phone and remote components share responsibilities | Could address a specific network or availability boundary if measured evidence justifies the added component. | **PROVISIONAL:** relay ownership, failure semantics, access, and incremental benefit are unestablished. |

No topology is approved. A topology is not excluded merely because it is remote, and the phone is not selected merely because it is the reference device.

### 3.2 Representative acceptance experiments

Each experiment requires an authorized environment and a workload derived from the eventual strategy. None has been run.

| Phase | Required experiment | Acceptance evidence | Failure consequence |
|---|---|---|---|
| Development/build | Build and run the intended toolchain on the handset with available storage and memory. | Reproducible build and test results under measured resource use. | Move or redesign the affected build workload according to the owner’s compromise order. |
| Historical research | Replay representative data shape and candidate count. | Completion time, peak memory, disk use, thermal behavior, and reproducibility meet the derived envelope. | Reduce breadth or change placement only after recording the measured gap. |
| Calibration | Run the authorized, budgeted evaluation procedure with its actual data and trial count. | No resource exhaustion; results reproduce; the statistical budget is respected. | Block promotion and revise workload or placement. |
| Paper operation | Run representative ingestion, decisions, persistence, alerts, and recovery under interruptions. | The derived freshness and recovery requirements pass, with no silent state divergence. | Paper operational readiness remains unproven. |
| Live runtime readiness | Test process death, network loss, reconciliation, protection, and recovery in an authorized controlled environment. | All applicable interlocks and fault tests pass; venue semantics are verified. | Live transition remains refused. |

If only one phase fails on-device, a narrower relocation may be proposed, explicitly identifying which compromise-order step it derives from, why that narrower move is sufficient, and the measured condition that would trigger broader relocation. No such compromise has yet been selected.

## 4. Phase derivation and promotion dependencies

### Risks and dependencies

The phase structure must address overfitting, data leakage, integration defects, ambiguous orders, stale data, operator error, capital loss, cross-venue restrictions, legal uncertainty, and runtime failure.

The dependency chain is:

```text
Permitted data + frozen candidate + trial controls
        ↓
Historical evaluation and selection
        ↓
Implemented interfaces and fault-tested execution simulation
        ↓
Paper operation and recovery evidence
        ↓
Live interlocks + future owner authorization
```

This chain describes evidence dependencies, not a mandated waiting period or profitability hurdle for the Telegram mode selector.

| Derived phase | Entry condition | Exit evidence | Rollback |
|---|---|---|---|
| **Research and selection** | Permitted data and a frozen experiment specification exist. | Reproducible, selection-aware results with costs and uncertainty; candidate remains unpromoted if evidence fails. | Retire or revise the candidate and record the additional selection attempt. |
| **Integration and fault verification** | Contracts and candidate interfaces are specified sufficiently to implement and test. | Relevant deterministic and fault tests pass, including ambiguous outcomes, risk vetoes, and recovery. | Return to the affected contract or implementation; preserve test evidence. |
| **Paper operation** | Paper configuration, data, and implemented safeguards are evaluable. | Operational behavior and discrepancies are recorded; paper claims remain distinct from live claims. | Pause entries and return to integration or research as indicated by the failure. |
| **Live operation** | Future owner authorization and all six live interlocks pass. | Ongoing reconciliation and risk checks remain valid; no profitability guarantee is implied. | Veto new exposure on a failed or unknown condition; follow the verified recovery policy. |

The number of phases is a **DESIGN_JUDGMENT** based on distinct evidence boundaries. Historical research and extended calibration may overlap operationally, but any selection attempt must remain visible in the experiment record.

### Owner vocabulary mapping

| Owner-intended category | Derived phase | Rationale |
|---|---|---|
| Training | Research and selection | Training is applicable only if the selected candidate needs it; rules-based candidates still require evaluation. |
| Extended initial execution/calibration | Research and selection, with integration checks where applicable | Calibration is research selection; execution behavior requires separately verified interfaces and simulation. |
| Paper operation | Paper operation | Tests operational behavior without representing it as real execution evidence. |
| Live operation | Live operation | Requires future authorization and the six correctness interlocks. |

## Artifact registry update

| Artifact | Location | Status |
|---|---|---|
| Checkpoint, initial candidates, and evidence limitations | Part 1 | DELIVERED |
| Execution, risk, and recovery proposal | Part 2 | DELIVERED; implementation and tests remain open |
| Requirements register and research protocol | Part 3 | DELIVERED; matching verification matrix remains open |
| Universe derivation and parametric liquidity screen | Part 4, §1 | DELIVERED as a method; no cell is approved |
| Workload formulas and topology comparison | Part 4, §§2–3 | DELIVERED as a proposal; measurements remain open |
| Phase derivation and owner-vocabulary mapping | Part 4, §4 | DELIVERED as a proposed dependency plan |
| Matching 18-row verification matrix and final audit | Not yet delivered | BLOCKED as completed artifacts |

**Part completeness:** this part delivers the universe and resource derivation method for its stated scope. A numerical frontier, approved universe, selected deployment, and device-fit result remain unavailable. The overall design remains incomplete.


# Part 5 — Verification matrix and acceptance status

**یادداشت وضعیت:** این بخش ماتریس تأیید متناظر با ۱۸ الزام ثبت‌شده را ارائه می‌کند. «روش آزمون» به معنی اجرای آزمون نیست. طراحی همچنان برای پیاده‌سازی و معاملهٔ واقعی آماده اعلام نمی‌شود.

Parts 1–4 delivered the checkpoint, execution proposal, requirements register, research protocol, and resource-derivation method. This part maps each registered requirement to its verification and records what has actually been observed.

## 1. Requirement-to-verification matrix

The requirement identifiers are defined in the single register in Part 3. **NOT TESTED** means the verification has not run; **BLOCKED** means a required input, decision, implementation, or authorization is unavailable.

| ID | Priority; method; execution context | Required evidence and acceptance condition | Status and observed result | Failure response; regression checks |
|---|---|---|---|---|
| R-001 | HARD; design inspection and integration test; future test harness | Verified adapter configuration and venue responses show that live orders target Toobit and the intended account scope. | **NOT TESTED:** no adapter or exchange integration was inspected. Evidence: Part 3 register. | Block live operation. Recheck R-007, R-008, R-012. |
| R-002 | HARD; interface test; future test harness | One authorized Telegram bot exposes the required controls, alerts, acknowledgements, and read-only review; no parallel routine operator interface is required. | **NOT TESTED:** Part 2 gives action preconditions, not an implemented interface. | Block operational acceptance. Recheck R-009, R-010, R-014. |
| R-003 | HARD; deterministic clock tests; future test harness | Instants and records use UTC; elapsed deadlines use monotonic time; derived offset and synchronization-age tolerances are enforced. | **BLOCKED:** tolerances and implementation are unavailable. Evidence: Part 3 register. | Veto affected live actions and time-dependent decisions. Recheck R-005, R-008, R-009. |
| R-004 | HARD; engagement-action inspection; current review | No account access, credentials, authenticated calls, or order actions occur during this design engagement. | **PASS for Parts 1–5:** no such tool use or action is reported or exposed in this interaction. This does not authorize later actions. | Stop any proposed prohibited action. Recheck R-001, R-012. |
| R-005 | HARD; source/lineage checks and owner or legal decision; future reviewer | Each cross-venue source has verified eligibility and permitted-use tags; restricted paths reject sources whose conditions are unmet. | **BLOCKED:** source identity and applicable access, licensing, and legal conditions are unresolved. Evidence: Part 3, §3. | Exclude the source from affected paths. Recheck R-006, R-011, R-015. |
| R-006 | HARD; historical evaluation and design inspection; future research harness | A frozen strategy has an explicit intraday holding and exit policy supported by relevant data, costs, and evaluation. | **BLOCKED:** no completed rule, data evaluation, or holding-duration result exists. Evidence: Part 3, §2. | Do not promote the candidate. Recheck R-011, R-013, R-015. |
| R-007 | HARD; owner decision and invariant tests; owner and future test harness | All required limits are approved; intact risk state and every applicable limit are evaluable; signals and retries cannot bypass vetoes. | **BLOCKED:** owner limits, implementation, and risk-state tests are unavailable. Evidence: Part 2, §2; Part 3 register. | Refuse live transition and new entries. Recheck R-008, R-009, R-013, R-014. |
| R-008 | HARD; contract, fault-injection, and authorized integration tests; future test harness | Ambiguous outcomes do not cause blind replacement; partial fills, cancel races, and venue/local reconciliation are traceable under verified semantics. | **BLOCKED:** Part 2 proposes states and tests, but venue semantics and implementation are unverified. | Block affected new exposure and reconcile. Recheck R-001, R-007, R-009, R-014. |
| R-009 | HARD; interlock and authorized permission tests; future test harness | Data validity, reconciliation, risk limits, credentials/permissions, configuration integrity, and clock quality each pass independently; failures produce specific refusals. | **BLOCKED:** no implementation, approved risk policy, or authorized account checks exist. Evidence: Part 2, §5. | Refuse live mode. Recheck R-002, R-003, R-007, R-008, R-010. |
| R-010 | HARD; network fault injection and recovery drill; future test harness | Telegram loss does not disable risk enforcement or falsely resolve orders and positions. | **NOT TESTED:** the proposed outage behavior and test fixture are in Part 2, §§4 and 6. | Pause new entries and preserve unresolved state. Recheck R-002, R-008, R-009, R-014. |
| R-011 | HARD; data audit, replay, historical evaluation, and statistical checks; future research harness | Frozen data and experiment records reproduce results; point-in-time integrity, trial accounting, costs, and uncertainty satisfy the declared protocol. | **BLOCKED:** datasets, recomputation inputs, and execution-cost observations are absent. Evidence: Part 3, §2. | Withhold validation and promotion. Recheck R-005, R-006, R-013, R-015. |
| R-012 | SHOULD; workload calculation and representative device experiments; owner or future test harness | Derived phase envelopes are compared with measured handset behavior and feasible topologies; any compromise is disclosed. | **BLOCKED:** Part 4 provides formulas and test specifications, not workload or device measurements. | Do not claim a live deployment fit. Recheck R-001, R-010, R-014, R-015. |
| R-013 | HARD; sizing calculation and venue specification checks; future risk test harness | Each proposed order satisfies verified quantity, notional, margin, cost, and owner-approved risk constraints. | **BLOCKED:** instrument rules, current fee conditions, and risk limits are unavailable. Evidence: Parts 1 and 4. | Reject unevaluable intents. Recheck R-006, R-007, R-011, R-015. |
| R-014 | HARD; security, corruption, authorization, and restore tests; future test harness | Risk history is never silently initialized after loss; access and privileged actions are controlled; restore and reconciliation are auditable and tested. | **NOT TESTED:** intended behavior and an offline-restore consistency table appear in Part 2; no drill occurred. | Refuse affected live actions and use a verified recovery procedure. Recheck R-002, R-007, R-008, R-010, R-012. |
| R-015 | SHOULD; source census, calculation, research and resource tests; future research harness | Every included symbol/interval has evidence of eligibility, sufficient data, admissible evaluation, and resource fit; widening and narrowing rules are explicit. | **BLOCKED:** no symbol/interval cell has passed the screens. Evidence: Part 4, §1. | Keep the universe provisional and exclude unevaluable cells from live use. Recheck R-005, R-006, R-011, R-012, R-013. |
| R-016 | HARD; acceptance-record inspection; current and final reviewer | Design, source review, research, implementation, paper operation, operational readiness, and live authorization are reported separately with evidence. | **NOT TESTED as final acceptance:** §2 below records current dimensions; the complete final acceptance audit remains outstanding. | Withhold readiness claims. Recheck R-009, R-011, R-012, R-014. |
| R-017 | HARD; decision-record inspection; final reviewer | Delegated technical decisions are evaluated without transferring them to the owner; non-delegable decisions are explicitly identified. | **NOT TESTED as final acceptance:** candidate comparisons exist, but the full decision record is incomplete. Evidence: Parts 1 and 4. | Complete the comparisons and isolate actual owner-level decisions. Recheck R-005, R-007, R-012. |
| R-018 | HARD; register/matrix count and final audit; current and final reviewer | One verification row exists per register row; the completed design and honest completeness declaration identify unresolved items and unexecuted tests. | **BLOCKED:** row matching is present below; the final design, audit, and completeness declaration are not complete. | Report the engagement as incomplete. Recheck R-001–R-017. |

**Count check:** the Part 3 register contains 18 rows, R-001 through R-018. This matrix contains 18 rows, R-001 through R-018. Thus \(18-18=0\) unmatched rows by count; the displayed identifiers also match individually. This check does **not** establish that the underlying requirements have passed.

Current matrix status totals are:

\[
1\ \text{PASS} + 0\ \text{FAIL} + 12\ \text{BLOCKED} + 5\ \text{NOT TESTED} = 18.
\]

A blocked or untested criterion is not an observed failure, nor is it a pass.

## 2. Separate acceptance dimensions

| Dimension | Status | Evidence and consequence |
|---|---|---|
| **Design completeness and consistency** | **BLOCKED** | Execution and research proposals exist, but essential contracts, quantitative parameters, and final cross-component audit remain incomplete. Developers would still need unresolved behavior. |
| **Source review and evidence** | **PARTIAL** | The supplied parsed master prompt was read. The underlying PDF, raw archive, venue documentation, and external sources were not inspected. Owner-supplied findings retain their stated scope. |
| **Research and backtest** | **NOT TESTED** | No dataset, candidate backtest, trial-budget recomputation, cost sensitivity result, or out-of-sample result was produced. |
| **Implementation correctness** | **NOT TESTED** | No code or implementation was supplied or executed. |
| **Paper-operational behavior** | **NOT TESTED** | No paper system was run; proposed tests are not observed results. |
| **Operational readiness** | **BLOCKED** | Device fit, restore drills, venue semantics, protections, and incident procedures lack required evidence. |
| **Future authorization for live trading** | **NOT GRANTED** | This engagement explicitly authorizes design only. A future authorization would be separate and would not replace the six live interlocks. |

## 3. Remaining design defects and dependencies

These are material gaps in the delivered design, not merely future implementation tasks.

1. **Strategy specification — BLOCKED.** Entry, exit, parameter domains, and maximum holding duration are not defined. Resolve by obtaining permitted point-in-time data, freezing candidate rules and assumptions, and conducting the research procedure in Part 3. Until then, no strategy is validated or implementation-ready.
2. **Venue contract — BLOCKED.** Order identifiers, lookup coverage, pagination, retention, protection, margin, and reconciliation semantics require source inspection and later separately authorized tests. Until resolved, the proposed lifecycle cannot establish live correctness.
3. **Risk policy — OWNER_DECISION_PENDING.** Per-trade, aggregate, daily-loss, drawdown, and related accounting limits must be selected by the owner after the distinctions in Part 1 are considered. Until then, the live risk interlock cannot pass.
4. **Telegram contract — BLOCKED.** Command schemas, authentication, replay protection, alert delivery, and transport selection are not specified to implementation detail. Part 2 supplies preconditions, not the complete interface.
5. **Deployment and universe — BLOCKED.** No eligible symbol/timeframe cell, measured resource envelope, numeric Pareto frontier, or deployment topology has been established. Part 4 defines how to obtain those results.
6. **Operations and security — NOT TESTED.** Backup cadence, secret storage, release integrity, detailed incident procedures, and recovery acceptance need a complete design and representative drills.
7. **Final audit — BLOCKED.** The full coverage checklist, claim-trace sample, arithmetic walk, individual self-verification record, and overall completeness declaration have not been delivered. They cannot truthfully be marked complete.

### Next highest-value action

The highest-value available design action is to specify the **Telegram command, authorization, and incident contract** against Part 2’s veto and recovery rules. This can advance without account access or a final risk percentage. The highest-value external validation, once a suitable tool and authorization exist, is targeted inspection of Toobit’s order lookup, client-identifier, protection, and reconciliation semantics.

## 4. Artifact registry update

| Artifact | Location | Status |
|---|---|---|
| Checkpoint, initial candidates, evidence limitations | Part 1 | DELIVERED |
| Execution, risk, and recovery proposal | Part 2 | DELIVERED; not implementation-tested |
| Requirements register and research protocol | Part 3 | DELIVERED; research blocked |
| Universe and resource derivation | Part 4 | DELIVERED as a method; measurements blocked |
| Matching verification matrix and acceptance dimensions | Part 5, §§1–2 | DELIVERED; most criteria remain blocked or untested |
| Complete Telegram/security/operations contracts | Not yet delivered | BLOCKED as completed artifacts |
| Final audit and overall completeness declaration | Not yet delivered | BLOCKED as completed artifacts |

**Part completeness:** the matching matrix and current acceptance status are delivered for this part’s scope. The overall design remains incomplete.


# Part 6 — Telegram control, security, and incident operations

**یادداشت وضعیت:** این بخش قرارداد پیشنهادی رابط Telegram و رسیدگی به خطا را تکمیل‌تر می‌کند. شناسه‌ها، سطح دسترسی حساب صرافی، روش استقرار، و ویژگی‌های واقعی API هنوز تأیید نشده‌اند؛ بنابراین این قرارداد آمادهٔ استفادهٔ Live نیست.

This part builds on Part 2’s risk veto and recovery rules and Part 3’s requirements register. Its purpose is to make routine operator actions auditable without giving Telegram authority to override risk or fabricate exchange state.

## 1. Control boundary and transport selection

### Authority

**DESIGN_JUDGMENT:** Telegram carries operator requests and displays results. It does not own exchange positions, determine whether an order succeeded, clear a risk veto, or establish that a market observation is valid.

The control service must distinguish:

1. **Request received:** a message arrived from Telegram.
2. **Request authorized:** the sender, chat, operation, and replay checks passed.
3. **Action accepted:** its preconditions passed and an intent was durably recorded.
4. **Action completed:** the relevant internal or exchange evidence establishes completion.
5. **Outcome unknown:** completion cannot be established; no success message is permitted.

### Transport alternatives

Criteria are outbound connectivity, operational burden, latency, credential exposure, deployment fit, and recovery after process interruption.

| Arrangement | Positive case | Material trade-off | Status |
|---|---|---|---|
| **Long polling from the runtime host** | Uses an outbound connection; does not require a public inbound endpoint on the handset. | Requires a continuously viable polling process and correct recovery of the update cursor; handset process survival is unmeasured. | **PROVISIONAL first candidate.** |
| **Webhook directly to the runtime host** | Telegram can deliver updates to an available endpoint without continuous polling. | Requires a reachable, appropriately protected inbound endpoint and certificate/secret management; stable handset ingress is not established. | **BLOCKED for handset use** until ingress is demonstrated. |
| **Webhook to a remote relay, then delivery to the runtime** | Can separate public ingress from a private runtime and support a host without stable inbound access. | Adds a trusted component, a second durable-delivery boundary, operating cost, and another failure mode. | **PROVISIONAL** only if permitted infrastructure exists and the incremental benefit is verified. |

Long polling is the first transport to test because the owner reports no stable inbound handset connection. It is not an approved deployment choice: Part 4’s device and topology measurements remain necessary.

## 2. Authorization and message handling

### Identity and privilege

**DESIGN_JUDGMENT:** bind privileged operations to an allowlist of numeric Telegram user and chat identifiers configured through a separately controlled provisioning process. Do not authorize based on a display name or username, which can change. Group-chat use requires an explicit policy; absent one, privileged operations are refused outside the designated private chat.

Telegram account control is a material security dependency. An allowlisted identity alone does not prove that the legitimate owner is operating the account at that instant. Sensitive actions therefore require a second confirmation within the bot, bound to the precise operation. This confirmation reduces accidental execution and replay; it is **not** an independent authentication factor against an attacker who already controls the authorized Telegram account.

**UNRESOLVED:** whether a genuinely independent second factor is feasible within the sole-interface requirement. If the owner’s threat model requires one, live enablement remains blocked until a compatible method is designed and tested.

### Processing contract

For each incoming update:

1. Validate the transport and parse only a defined command grammar. Reject unknown commands, malformed fields, and unexpected attachments.
2. Verify the configured user and chat identifiers and the operation’s privilege.
3. Record the Telegram update identifier and outcome durably. Duplicate updates return the previously recorded outcome or a current status; they do not repeat the side effect.
4. For a sensitive action, create a short-lived confirmation record containing the exact action, normalized parameters, requester, configuration version, creation time, and expiry.
5. On confirmation, atomically consume that record once and re-evaluate all action preconditions. A confirmation is not a standing approval.
6. Persist the accepted action before invoking any external side effect. If durable persistence is unavailable, refuse the action.
7. Record the final result or explicitly mark the outcome unknown.

The confirmation lifetime, message-size limits, rate limits, and failed-authorization thresholds are **UNRESOLVED** pending transport measurements and a threat model. They must be finite and configured before use; no numerical value is asserted here.

### Replay, concurrency, and input safety

- Serialize conflicting state-changing operations for the same account or position. A mode transition and a close request must not each act on an inconsistent snapshot.
- Treat command text as data, never as shell input or executable configuration.
- Escape or otherwise safely render untrusted text in replies and logs.
- Apply bounded per-identity and global request rates. Exhaustion must not disable existing risk controls.
- Never place API keys, bot tokens, or other secrets in Telegram messages, command arguments, alerts, or logs.
- A lost response to the operator does not justify repeating the underlying exchange action. The operator can request status using the recorded action identifier.

**Status:** **NOT TESTED.** The handling rules are proposed contracts, not observed Telegram or exchange behavior.

## 3. Command catalog

The command names below are proposed interface identifiers for this part. Parameters are illustrative shapes; final field limits and exact message schemas remain unresolved. Every state-changing command produces an auditable action record.

| Command | Purpose and authorization | Preconditions evaluated at command time | Result and failure behavior |
|---|---|---|---|
| `/status` | Read mode, active vetoes, last reconciliation, open positions and orders, and data freshness; authorized read access. | Requester is authorized to view account-related information. | Return values with their observation times and source; show stale or unknown fields explicitly. Never infer that an unobserved position is closed. |
| `/mode paper` | Select paper mode; privileged, confirmed. | Paper configuration is valid and the request does not conflict with an in-progress transition. The live credential and clock interlocks are not required merely to select paper mode. | Report the selected mode. Any subsequent paper decision still requires valid data and trustworthy time for that decision. |
| `/mode live` | Request live mode; privileged, confirmed. | Evaluate the six interlocks listed in §4. | Enter live mode only if all pass. Otherwise remain in the existing mode and return each failed or unknown check. |
| `/pause` | Pause generation or admission of new entries; privileged. | The control service can durably record the pause. | Report whether the pause was recorded. It does not assert that existing orders were cancelled or positions closed. |
| `/resume` | Request resumption of eligible entries; privileged, confirmed. | Current mode readiness, applicable aggregate state, active vetoes, and required incident acknowledgements are evaluable and pass. No per-trade check is required before a trade intent exists. | Resume only the activities whose preconditions pass. Each later intent still receives its own risk evaluation. |
| `/ack <incident-id>` | Satisfy a configured resume gate after recovery; privileged. | The named incident exists, its underlying veto has cleared, and acknowledgement is applicable. | Record the acknowledgement. If the veto remains active, refuse and report its current cause; acknowledgement never clears it. |
| `/orders` | Read observed order states; authorized read access. | Reconciliation data is available or its absence can be reported. | Show order identity, last observed state, observation time, and ambiguity. |
| `/positions` | Read observed positions and protection status; authorized read access. | Position observations are available or their absence can be reported. | Show quantity, source and observation time, plus whether protection is established, missing, or unknown. |
| `/close <instrument> <scope>` | Request a risk-reducing close; privileged, confirmed. | A separately verified close procedure, fresh enough position evidence, instrument rules, and applicable permissions exist. The requested action must not rely on an unverified assumption that it cannot increase exposure. | Record the intent and submit only under the verified procedure. Report accepted, rejected, completed, or unknown separately. A timeout triggers reconciliation, not blind resubmission. |
| `/config show` | Read active configuration and version; authorized read access. | Configuration integrity is evaluable. | Return non-secret settings and version; mark integrity unknown if it cannot be established. |
| `/config propose <change>` | Propose a change to an authorized non-secret setting; privileged. | The setting is in an explicit allowlist; syntax, domain, and change authority are defined. | Show old and proposed values, affected behavior, and confirmation requirement. Unknown settings are refused. |
| `/config confirm <proposal-id>` | Apply a previously proposed setting; privileged, confirmed. | Proposal is unexpired and unused; requester and exact change match; integrity and applicable safety checks pass. | Persist a new configuration version and audit record atomically. Changes cannot silently disable a hard limit. |

**Configuration boundary:** owner-approved risk limits require an explicit owner-authorized change process and cannot be altered by research or optimization. The detailed approval policy and which changes require a live-mode pause remain **UNRESOLVED**.

**Emergency close limitation:** if venue position state or reduce-only semantics are unverified, the system cannot promise that a close request is executable or risk-reducing. It must say which evidence is missing and retain the unresolved status.

## 4. Live-mode interlocks

Each interlock returns **PASS**, **FAIL**, or **UNKNOWN**, with its observation time, configuration version, and reason. Only six **PASS** results permit live transition.

| Interlock | Evaluation | Fail or unknown condition | Refusal content |
|---|---|---|---|
| Data validity | Validate the required instrument data against the candidate’s defined coverage, integrity, and freshness rules. | Required data is missing, malformed, stale, contradictory, or its freshness threshold is undefined. | Identify instrument/data class and failed or unknown condition. |
| Reconciliation | Compare complete-enough venue observations with local orders, fills, positions, and balances under verified query semantics. | An outcome is ambiguous, observations disagree, query completeness is unknown, or reconciliation is stale. | Identify the affected account, order, or position and unresolved discrepancy without exposing secrets. |
| Risk limits | Verify approved policy, intact historical state, and evaluable current aggregate constraints. | A required limit, equity value, exposure, or historical risk record is absent, inconsistent, or outside its approved boundary. | Name the unevaluable or failed risk condition. Do not initialize missing history to zero. |
| Credentials and permissions | In a future separately authorized environment, verify the identity and permissions needed for the intended operations without exposing secrets. | Credentials are invalid, permissions are excessive or insufficient under the approved policy, or verification cannot be performed. | State that credential or permission verification failed or is unknown; never print credentials. |
| Configuration integrity | Verify the active configuration version, integrity, required fields, and compatibility with the approved candidate and risk policy. | Configuration is corrupt, incomplete, unapproved, or inconsistent. | Name the invalid version or field category. |
| Clock quality | Compare the relevant wall-clock offset and synchronization age with derived tolerances; use monotonic time for elapsed deadlines. | Offset or synchronization age exceeds tolerance, or either cannot be established. | Report measured/unknown offset and tolerance status in UTC-related units. |

**UNRESOLVED:** quantitative freshness, reconciliation-age, and clock tolerances require a selected strategy, venue semantics, and measurements. They cannot be passed merely because no error has been observed.

## 5. Alerts and incidents

### Alert catalog

| Alert | Trigger | Required operator-facing content | System consequence |
|---|---|---|---|
| **Critical risk state** | A required risk record is missing, corrupt, inconsistent, or otherwise unevaluable. | Affected record category, observation time in UTC, active veto, and recovery instruction. | Refuse live transition and new entries. |
| **Ambiguous exchange outcome** | Submission, cancellation, or close outcome cannot be established. | Action identifier, instrument, last known state, and reconciliation status. | Block related replacement and affected new exposure. |
| **Protection unresolved** | A position’s required protection is missing, rejected, ambiguous, or not verified against actual exposure. | Instrument, observed position, protection status, and last observation time. | Block new entries; use only a separately verified risk-reducing procedure. |
| **Data or clock invalid** | A required observation or time check fails or cannot be evaluated. | Affected input, age or offset if known, and the dependent actions refused. | Veto decisions or live actions that require the input. |
| **Storage integrity failure** | Persistent state cannot be safely read or written. | Failed check and instruction to stop before an exclusive offline restore. | Refuse state-changing actions that require durability. |
| **Telegram delivery failure** | An alert cannot be delivered after the configured finite retry policy. | Retain the alert locally for later delivery, with original event time. | Risk controls remain active; failed delivery is not treated as acknowledgement. |

Alert retention, delivery retry limits, and escalation timing are **UNRESOLVED**. The system must preserve an auditable local alert record when Telegram is unavailable, provided storage is healthy.

### Incident sequence

1. Detect and durably record the condition where possible.
2. Apply the condition’s veto to affected actions.
3. Notify the operator through Telegram if available; otherwise retain the undelivered alert.
4. Recover the underlying condition using its verified procedure.
5. Re-evaluate and clear the veto only when its recovery condition passes.
6. Where a resume gate applies, require `/ack` after recovery.
7. Record recovery evidence and any subsequent resumption.

A transient restoration of connectivity alone does not establish that exchange state or local history is consistent.

## 6. Secrets, backups, and the sole-interface constraint

### Secrets

**DESIGN_JUDGMENT:** secrets should be stored outside ordinary configuration and logs, with access limited to the runtime components that need them. Use separately scoped exchange credentials where the venue permits, and disable permissions that are not required.

**UNRESOLVED:** the actual secret-storage mechanism depends on the selected handset or remote host and its available security facilities. Rotation must be designed so that old and new credentials are not exposed in Telegram and so an interrupted rotation cannot silently leave live permissions unknown. Until tested, credential readiness cannot pass.

### Backup and restore

Backups must include the configuration versions, intent and observation ledger, risk history, authorization configuration, and audit records needed to reconstruct state. They must be integrity-checked and protected from unauthorized access.

**UNRESOLVED:** backup destination, frequency, retention, encryption/key recovery, and restore-time target require the selected deployment and owner’s operational constraints. A backup is not accepted as recoverable until a restore drill verifies its contents and reconciliation behavior.

### Out-of-band restore tension

The master prompt makes Telegram the sole **runtime** operator interface while requiring an exclusive offline restore for some corruption cases. If the process and bot are stopped, Telegram cannot itself execute a restore through that stopped runtime.

**UNRESOLVED:** a future operational design must specify an authorized offline maintenance mechanism and determine whether the owner accepts it as outside routine runtime operation. No alternate dashboard or routine operator console is introduced here. Until that boundary and the restore mechanism are established and tested, recovery readiness remains blocked.

## 7. Verification specifications and adversarial review

No tests in this section have been executed.

| Test | Fixture and action | Expected result | What it cannot establish |
|---|---|---|---|
| Duplicate update | Deliver the same authorized state-changing update twice. | One durable action record and at most one side effect; the duplicate returns recorded status. | Venue-side idempotency or completeness of exchange reconciliation. |
| Confirmation replay | Confirm the same proposal twice or after expiry. | The confirmation is consumed at most once; later attempts are refused. | Protection against an attacker controlling the authorized Telegram account. |
| Changed state after confirmation | Create a close or live-mode confirmation, then change relevant state before confirming. | Preconditions are re-evaluated; stale approval is refused or a new confirmation is required. | Real venue behavior without integration testing. |
| Unauthorized identity | Send a privileged command from an unlisted user or chat. | No side effect; refusal and security event are recorded without exposing account details. | Security of Telegram account recovery or the device itself. |
| Telegram outage | Make alert delivery fail while an exchange outcome is ambiguous. | Alert remains pending locally; the outcome stays ambiguous and the veto remains active. | Successful future delivery or exchange-state recovery. |
| Missing risk ledger | Remove the risk-history record, then issue `/ack` and `/mode live`. | Both fail to establish valid risk state; live mode remains refused. | Backup correctness. |
| Offline restore boundary | Corrupt storage during startup and invoke recovery. | Runtime refuses live startup and does not perform an exclusive restore inline while running. | The eventual restore mechanism, which remains unspecified. |

### Adversarial findings

| Finding | Consequence | Containment |
|---|---|---|
| An authorized Telegram account can itself be compromised. | A confirmation inside the same account is not an independent factor. | Treat stronger authentication as an unresolved live-readiness dependency if required by the threat model. |
| A confirmed command can become unsafe before execution. | A stale close or mode transition could act on changed state. | Consume confirmation once and re-evaluate preconditions immediately before the action. |
| A duplicate update or lost reply can repeat a side effect. | Duplicate orders or configuration changes are possible. | Durable update/action deduplication and status lookup; ambiguous exchange outcomes still require reconciliation. |
| An offline restore may be impossible through a stopped sole runtime interface. | Recovery cannot be operationally completed as currently specified. | Retain as unresolved; do not claim recovery readiness or introduce an undeclared routine interface. |

## Artifact registry update

| Artifact | Location | Status |
|---|---|---|
| Checkpoint and initial candidates | Part 1 | DELIVERED |
| Execution and recovery proposal | Part 2 | DELIVERED; venue verification outstanding |
| Requirements and research protocol | Part 3 | DELIVERED; research blocked |
| Universe and deployment derivation | Part 4 | DELIVERED as a method; measurements outstanding |
| Verification matrix and acceptance dimensions | Part 5 | DELIVERED; criteria remain blocked or untested |
| Telegram command, security, interlock, and incident proposal | Part 6, §§1–6 | DELIVERED for stated scope; implementation details and tests remain open |
| Final audit and overall completeness declaration | Not yet delivered | BLOCKED as completed artifacts |

**Part completeness:** the command and incident contracts are delivered for this part’s stated scope. Transport, independent authentication, offline restore, venue integration, and all associated tests remain unresolved. The overall trading-system design remains incomplete.


# Part 7 — Cross-part audit and completeness record

**یادداشت وضعیت:** بازبینی این بخش یک خطای شمارشی در Part 5 را اصلاح می‌کند. نتیجهٔ کلی همچنان این است: طرح برای پیاده‌سازی کامل یا معاملهٔ Live تأیید نشده است. آزمایش، بک‌تست، بررسی حساب یا سند خارجی انجام نشده است.

## 1. Correction to Part 5

Part 5 reported 12 requirements as **BLOCKED** and 5 as **NOT TESTED**. That count was incorrect. Counting the individual matrix rows gives:

- **PASS:** R-004 — 1 row.
- **BLOCKED:** R-003, R-005, R-006, R-007, R-008, R-009, R-011, R-012, R-013, R-015, R-018 — 11 rows.
- **NOT TESTED:** R-001, R-002, R-010, R-014, R-016, R-017 — 6 rows.
- **FAIL:** 0 rows recorded as observed failures.

\[
1+11+6+0=18.
\]

The register and matrix each contain 18 individually matching identifiers. This corrects the count only: it does not change any row’s status or establish that the design is complete.

## 2. Cross-part consistency review

| Question | Finding and evidence | Status and consequence |
|---|---|---|
| Can Telegram acknowledgement clear a risk veto? | Parts 2 and 6 both say the underlying condition must recover first; acknowledgement is a separate resume gate. | **PASS for the stated design rule**, by inspection. Implementation remains **NOT TESTED**. |
| Can a timeout trigger a blind replacement order? | Part 2 sends the outcome to reconciliation; Part 6’s close command preserves unknown status. | **PASS for the stated design rule**, by inspection. Venue behavior and implementation remain **BLOCKED/NOT TESTED**. |
| Does a missing risk ledger initialize loss or drawdown to zero? | Parts 2 and 6 explicitly prohibit this. | **PASS for the stated design rule**, by inspection. Restore and reconstruction remain unverified. |
| Does selecting paper mode require the live clock interlock? | Part 6 says no; it separately requires trustworthy time for a paper decision that depends on time. | **PASS for the stated distinction**, by inspection. Concrete paper-data freshness rules remain unresolved. |
| Is a Telegram confirmation an independent second factor? | Part 6 explicitly says it is not if the same Telegram account is compromised. | **UNRESOLVED:** threat-model and compatible authentication design are needed before claiming this control sufficient. |
| Can an exclusive offline restore be executed by a stopped bot? | Part 6 identifies that it cannot. | **UNRESOLVED:** an authorized maintenance boundary and tested restore mechanism are needed. Recovery readiness remains blocked. |
| Is the strategy implementable from the delivered rules? | Parts 1 and 3 describe candidate families, but not a complete frozen entry, exit, parameter, and holding-duration specification. | **FAIL as design completeness:** research results are not the only missing item; the candidate specification itself remains incomplete. |
| Is live readiness established? | Part 5 separates design, research, implementation, paper, operations, and authorization. None establishes live readiness. | **BLOCKED:** do not implement a live transition based on these documents alone. |

## 3. Evidence trace: ten material claims

| Claim | Inspectable basis | Scope or limitation |
|---|---|---|
| Live execution is specified for Toobit. | Owner’s supplied master prompt §3.1.1; Part 3, R-001. | Owner constraint, not a verified integration. |
| Telegram is the sole routine operator interface. | Master prompt §3.1.2; Part 3, R-002. | The offline maintenance boundary remains unresolved. |
| No account access is authorized during this engagement. | Master prompt §3.1.4; Part 3, R-004. | The observed pass covers this conversation’s reported actions. |
| The 3,500-candle figure is a cap, not guaranteed depth. | Owner-supplied master prompt §5.1; Part 4, §1. | The raw census was not inspected. |
| A reported order timeout can be ambiguous. | Owner-supplied master prompt §5.1; Part 2, §3. | Actual endpoint semantics were not independently checked. |
| The taker-fee records conflict at 0.05% and 0.06%. | Owner-supplied master prompt §5.1; Part 1, §3. | Neither value is established as the current account fee. |
| Historical open interest remains unresolved. | Owner-supplied master prompt §5.5; Part 3, §3. | No external source search was performed. |
| The reference phone’s sustained workload performance is unmeasured. | Owner-supplied master prompt §5.2; Part 4, §3. | Device specifications do not prove runtime fit. |
| Missing risk history must not be reset to zero. | Master prompt §9.6; Parts 2 and 6. | A specified invariant, not an executed test. |
| No candidate strategy has a demonstrated edge in this engagement. | Parts 3 and 5 report no backtest or dataset evaluation. | This is a statement about the work performed, not proof that no edge exists. |

## 4. Arithmetic reproducibility walk

### Archive dispositions

Inputs from the owner-supplied summary: 134 live-pass, 10 live-partial, 3 unsupported-confirmed, and 2 documentation-conflict records.

\[
134+10+3+2=149\ \text{records}.
\]

The total does not mean all 149 passed. The raw archive was not inspected.

### Storage measurement denominator

\[
3{,}500\ \frac{\text{candles}}{\text{interval-symbol}}
\times14\ \text{intervals}
\times10\ \text{symbols}
=490{,}000\ \text{candle records}.
\]

\[
\frac{1.25\ \text{GB}}{490{,}000\ \text{records}}
\approx 0.000002551\ \text{GB per record}.
\]

This is a ratio from the owner’s measured case. It is not a total estimate for the unselected universe and does not include additional data classes or backups.

### Illustrative taker fees

For 100 USDT entry notional:

\[
100\times0.0005=0.05\ \text{USDT};
\qquad
100\times0.0006=0.06\ \text{USDT}.
\]

If an exit has the same notional and the same fee rate, the two-fee totals are:

\[
0.05+0.05=0.10\ \text{USDT};
\qquad
0.06+0.06=0.12\ \text{USDT}.
\]

Actual exit notional may differ. Spread, slippage, funding, and other costs are excluded.

## 5. Self-verification record

These checks assess the delivered parts as they stand. They do not convert plans into executed tests.

| Check | Question answered | Result | Evidence or corrective action |
|---|---|---|---|
| V-1 | Is this part complete for its declared audit scope? | **PASS** | §§1–4 and this record present the correction, consistency findings, trace sample, and arithmetic checks. |
| V-2 | Has this part been checked for prohibited reduction patterns? | **FAIL** | The overall design contains explicitly incomplete material; this audit names it rather than claiming full-content compliance. Completion requires the missing design artifacts. |
| V-3 | Does numbering match an initial fixed plan? | **FAIL** | No fixed total was established because the message limit and autonomous multi-message delivery were unavailable. Parts have been numbered by successive turns. |
| V-4 | Are prior-part references consistent? | **PASS** | §§1–4 identify Parts 1–6 and correct Part 5’s count. |
| V-5 | Is a completeness declaration present? | **PASS** | §6 below contains an honest partial-engagement declaration. |
| V-6 | Does the declaration establish full delivery compliance? | **FAIL** | §6 records missing content and delivery limitations; it does not claim full compliance. |
| V-7 | Is this part added to the artifact registry? | **PASS** | §7 lists this audit and its status. |
| V-8 | Have all planned final parts been delivered? | **FAIL** | No fixed total was established, and material design work remains undelivered. |
| V-9 | Does a declaration exist and disclose incomplete content? | **PASS** | §6 gives counts, limitations, and outstanding work. |
| V-10 | Does the declaration reflect registered requirement statuses? | **PASS** | §1 enumerates the corrected 18-row status count used in §6. |
| V-11 | Have all prior outputs been corrected for every completeness defect? | **FAIL** | Part 5’s count is corrected here; incomplete strategy, venue, operations, and other artifacts are not retroactively complete. |
| V-12 | Are all registered artifacts delivered or identified as blocked? | **PASS** | §7 lists delivered artifacts and the remaining blocked artifacts. |

## 6. Completeness declaration

**Engagement scope:** design-only proposal for an intraday Toobit perpetual-futures system with Telegram as the sole routine operator interface.

**Parts delivered:** 7 conversation parts, including this audit. They were delivered over successive user-requested turns, not as an automatically sent fixed-count sequence.

**Requirements register:** 18 material requirements.

| Status | Count |
|---|---:|
| PASS | 1 |
| FAIL as an individual register row | 0 |
| BLOCKED | 11 |
| NOT TESTED | 6 |
| Additional UNRESOLVED category counted separately | 0 |
| Intentionally excluded requirements | 0 |
| Not-relevant requirements | 0 |

\[
1+0+11+6+0+0+0=18.
\]

Unresolved facts are included within the applicable **BLOCKED** rows rather than double-counted. The design-completeness defect in §2 is disclosed separately: it has not been assigned a new register identifier or silently counted as a passed requirement.

- **D20 completeness: FAIL.** Essential candidate strategy behavior, venue contracts, operations, quantitative thresholds, and other material content are missing or unresolved.
- **D21 anti-abbreviation: FAIL.** Several delivered sections are partial designs rather than the full engineering-level artifacts requested. The unresolved disclosures do not make those missing artifacts complete.
- **D22 multi-message obligation: FAIL.** No evidence-based total part count was set in the first message, and autonomous sequential final messages were not available. The parts were produced through subsequent interaction.
- **Artifact registry: PARTIAL.** Delivered artifacts and known missing artifacts are listed in §7; the registry is not a complete implementation specification.
- **Independent review:** no separate reviewer was available. Cross-part adversarial review was performed by the same assistant in this part and Part 6; it is not independent confirmation.
- **External evidence and execution:** no browsing, file creation, code execution, device measurement, exchange access, backtest, paper operation, or live action occurred.
- **Known limitations:** no approved risk policy; no frozen executable strategy; no recomputed trial budget; no admitted universe; no verified exchange order/protection semantics; no measured device envelope; no approved deployment; no tested backup/restore or Telegram authentication.
- **Next highest-value validation:** inspect the applicable Toobit documentation for client-order identifier scope, order and fill lookup, pagination/retention, protective-order and reduce-only behavior. Preserve exact source sections and treat any remaining ambiguity as a live blocker.

### Material changes from adversarial review

| Finding | Changed location | Change present | Verification |
|---|---|---|---|
| Part 5 status totals were miscounted. | Part 7, §1 | BLOCKED corrected from 12 to 11; NOT TESTED corrected from 5 to 6. | The individual identifiers are enumerated and sum to 18. |
| The proposed candidate was not an implementation-level strategy. | Part 7, §2, strategy row | The gap is classified as a design-completeness failure, not merely an unexecuted backtest. | Entry, exit, parameter, and holding-duration specification are explicitly identified as missing. |

The correction is visible here; Part 5 itself remains historically unchanged. Readers should use the corrected count in this part.

## 7. Artifact registry

| Artifact | Reference | Status |
|---|---|---|
| Pre-research checkpoint and capability inventory | Part 1 | DELIVERED |
| Execution, risk, reconciliation, and recovery proposal | Part 2 | DELIVERED; untested |
| Requirements register and research protocol | Part 3 | DELIVERED; research blocked |
| Universe and deployment derivation method | Part 4 | DELIVERED; numeric results blocked |
| Verification matrix | Part 5 | DELIVERED; count corrected in Part 7 |
| Telegram and incident proposal | Part 6 | DELIVERED; implementation details and tests remain open |
| Cross-part audit and partial completeness declaration | Part 7 | DELIVERED |
| Complete strategy, verified venue contract, full operations design, and final acceptance | Not delivered | BLOCKED by missing design work, evidence, decisions, and tests |


# Part 8 — A testable baseline strategy specification

**یادداشت وضعیت:** بخش مهم باقی‌مانده، تعریف دقیق یک راهبرد آزمایشی بود. این بخش رفتار آن را مشخص می‌کند، اما پارامترها، داده، هزینهٔ اجرا و مدت نگهداری هنوز تعیین یا آزموده نشده‌اند. بنابراین راهبرد زیر برای معاملهٔ واقعی قابل فعال‌سازی نیست.

## 1. Objective and design choice

**Research question:** Can a completed-candle breakout rule on eligible Toobit perpetual contracts produce a defensible net result under causal data, realistic execution costs, and independently enforced risk limits?

**DESIGN_JUDGMENT:** Use a single-timeframe breakout as the first baseline. It is sufficiently explicit to test whether a price-based intraday hypothesis earns its costs without depending on a trained model or cross-instrument features. This choice is a measuring instrument, not a profitability claim.

The comparison candidates remain:

- **No-trade baseline:** zero trading P&L, fees, and funding. It establishes whether taking any trading risk produced a measurable net benefit.
- **Breakout baseline:** the rule below.
- **Context extension:** the same breakout conditioned on a slower completed-bar signal. It is evaluated only as a separately registered candidate.

**Status:** **NOT TESTED.** No candidate has a demonstrated advantage.

## 2. Inputs and parameters

Each experiment concerns one eligible instrument and one supported candle interval. A portfolio experiment across instruments requires a separately specified allocation rule and joint trial accounting.

| Parameter | Meaning and domain | Source and unresolved fields |
|---|---|---|
| `lookback_bars` | Positive integer number of prior completed bars used for the breakout level. | **PROVISIONAL:** values and search budget must be registered before evaluation. |
| `exit_lookback_bars` | Positive integer number of prior completed bars used for the signal exit. | **PROVISIONAL:** values and search budget unresolved. |
| `stop_distance` | Positive price distance between entry reference and protective stop, subject to verified price increments. | **BLOCKED:** derivation, execution behavior, and feasible domain require data and venue rules. |
| `max_hold` | Positive duration measured with a monotonic clock after entry; expressed in seconds. | **BLOCKED:** must be derived from intraday behavior, funding, costs, and evaluation. |
| `entry_expiry` | Maximum permitted elapsed time for an unfilled entry intent. | **BLOCKED:** requires a candidate execution method and latency evidence. |
| `risk_fraction` | Owner-approved nominal loss budget divided by the specified equity basis. | **OWNER_DECISION_PENDING:** never optimized by the strategy. |
| `cost_assumptions` | Fee, spread, slippage, funding, latency, and fill assumptions with units and provenance. | **BLOCKED:** venue and market observations are insufficient. |

For every evaluated parameter configuration, the experiment record must include its calibration data, held-out validation data, uncertainty method, applicability, promotion criteria, rollback criteria, and any re-estimation trigger. Those fields cannot be filled honestly until the data and trial budget are available.

## 3. Signal and position behavior

### 3.1 Information available at a decision

Let \(t\) be a candle that has closed and whose final OHLC values have been received and validated. Let \(H_i\), \(L_i\), and \(C_i\) denote the high, low, and close of completed candle \(i\).

For a registered `lookback_bars` value \(L\), define:

\[
U_t=\max(H_{t-L},\ldots,H_{t-1}),
\qquad
D_t=\min(L_{t-L},\ldots,L_{t-1}).
\]

The breakout levels exclude candle \(t\). This prevents the current candle’s own high or low from defining the threshold against which its close is compared.

A decision is eligible only when:

- all required candles are complete, valid, and within the eventual freshness policy;
- their source and availability times are recorded;
- instrument metadata and current position/order state are evaluable;
- no applicable risk or reconciliation veto is active.

A missing required candle causes **no signal**. It is not filled with zero or silently forward-filled.

### 3.2 Entry

When the instrument has no position and no unresolved entry order:

- If \(C_t>U_t\), propose a **long** entry.
- If \(C_t<D_t\), propose a **short** entry.
- Otherwise, propose no entry.

The signal produces an intent, not an order. The independent risk authority evaluates the exact intent under Part 2’s contract. A rejected intent is recorded and is not repeatedly submitted as a way around the veto.

**Execution method: UNRESOLVED.** A maker limit, marketable limit, or another venue-supported order type has not been selected. The research simulator must evaluate only an explicitly registered method and must not infer maker fills from candles alone.

### 3.3 Exit

For registered `exit_lookback_bars` value \(X\), define:

\[
E^{\text{long}}_t=\min(L_{t-X},\ldots,L_{t-1}),
\qquad
E^{\text{short}}_t=\max(H_{t-X},\ldots,H_{t-1}).
\]

- For an open long, if \(C_t<E^{\text{long}}_t\), propose an exit.
- For an open short, if \(C_t>E^{\text{short}}_t\), propose an exit.
- When elapsed holding time reaches `max_hold`, propose an exit regardless of the signal.
- A verified protective-stop policy may trigger an earlier exit.

An exit proposal does not mean the position has closed. The actual quantity and outcome remain determined by venue observations and reconciliation. If a close outcome is ambiguous, the system follows Part 2’s order lifecycle.

**Intraday constraint:** `max_hold` must be established before paper evaluation of this rule and must be justified by the intended intraday behavior and costs. No fixed duration is asserted here. A position that cannot be closed by the deadline is an incident, not a completed exit.

### 3.4 Conflicting events

If a protective exit and a candle-based exit are both indicated, the execution layer must prevent them from unintentionally creating reverse exposure. The exact mechanism depends on verified venue support for reduce-only or equivalent behavior.

For historical bars where the order of intrabar events is unknown, the simulator must not select the favorable ordering. It must either use finer permitted data with verified availability or report conservative scenario bounds.

## 4. Position sizing and costs

For a proposed order, let:

- \(E\) be the approved equity basis in USDT;
- \(r\) be the pending owner-approved risk fraction;
- \(q\) be contract quantity;
- \(m\) be the verified contract multiplier;
- \(P_{\text{entry}}\) and \(P_{\text{stop}}\) be the assumed entry and stop-fill prices;
- \(C(q)\) be estimated fees, spread, slippage, and funding in USDT.

For a linear contract, the proposed quantity must satisfy:

\[
q\,m\,|P_{\text{entry}}-P_{\text{stop}}|+C(q)\le Er.
\]

It must also satisfy verified quantity increments, minimum order requirements, margin constraints, aggregate exposure limits, and position-count limits. Round quantity in the direction that does not increase the modeled risk; then recalculate the full inequality.

**Important limitation:** this is modeled stop risk, not a guaranteed maximum realized loss. If \(C(q)\), contract mechanics, equity, or any required limit is unknown, the risk check is unevaluable and the live entry is vetoed.

Cost scenarios must include the owner-supplied 0.05% and 0.06% taker-fee records where taker execution is simulated. They must also separately represent fill probability, spread, slippage, funding, and latency when applicable. No numerical net result has been calculated.

## 5. Research registration and acceptance

Before the first evaluation, register:

1. The exact instrument/interval cells and point-in-time data versions.
2. The full parameter set or deterministic generator.
3. The independently recomputed admissible trial limit.
4. The entry order method, expiry, fill model, and exit method.
5. Calibration, selection, and untouched confirmation periods.
6. Cost scenarios and treatment of unknown intrabar ordering.
7. A stopping rule and the metric used to compare candidates.
8. Promotion and retirement conditions.

The values in items 2–8 are **UNRESOLVED**, not implicit defaults. The rule above is a behavioral template until one complete configuration is registered.

A candidate may advance to paper only after its registered evaluation, data-quality checks, execution assumptions, and relevant implementation tests have passed. A paper result does not establish live profitability. Live mode additionally requires future authorization and the six interlocks.

## 6. Verification fixtures

No fixture has been executed.

| Fixture | Input | Expected result | Limitation |
|---|---|---|---|
| Current-bar exclusion | Set the current high above every prior high while the current close remains below the prior breakout level. | No long signal; the current high is not included in \(U_t\). | Does not validate market data availability time. |
| Missing history | Remove one required prior candle. | No signal and a recorded data-quality refusal. | Does not establish a real feed’s gap-detection quality. |
| Risk veto | Produce a long signal while approved risk history is unavailable. | Intent is recorded as vetoed; no live entry is submitted. | Requires an implementation and integration harness. |
| Deadline | Keep a position open until `max_hold` expires. | An exit intent is generated; the position remains open until an actual fill is reconciled. | Does not prove the venue can fill the exit. |
| Ambiguous exit | Simulate an accepted close whose response is lost. | Outcome remains ambiguous; reconciliation precedes any replacement. | Does not prove venue lookup completeness. |
| Intrabar ambiguity | One bar touches both a stop and a signal-related level without event ordering. | Simulator uses registered conservative bounds or finer verified data, not favorable ordering. | Bounds may still be too optimistic if execution costs are incomplete. |

## 7. Effect on the prior audit

Part 7 correctly identified that the candidate lacked a defined entry and exit. This part adds those behavioral rules and verification fixtures. It does **not** resolve the full design-completeness failure: parameter values, intraday duration, order method, trial budget, data eligibility, venue semantics, and acceptance thresholds remain blocked.

The Part 3 requirements register and Part 5 matrix therefore retain their statuses. In particular, the intraday-strategy requirement remains **BLOCKED**, and research validity remains **BLOCKED** until evidence exists.

### Artifact registry update

| Artifact | Reference | Status |
|---|---|---|
| Prior checkpoint, requirements, execution, resource and audit artifacts | Parts 1–7 | DELIVERED with their stated limitations |
| Baseline signal, exit, sizing, and test fixtures | Part 8, §§2–6 | DELIVERED as a parameterized proposal; **NOT TESTED** |
| Frozen configuration and trial-budget calculation | Not delivered | **BLOCKED:** required inputs unavailable |
| Verified venue execution and protection contract | Not delivered | **BLOCKED:** sources and authorized tests unavailable |
| Final implementation-ready design and acceptance | Not delivered | **BLOCKED:** material dependencies remain |

**نتیجه:** قاعدهٔ پایه اکنون قابل ثبت و آزمون است، نه قابل معامله. گام بعدیِ وابسته به شواهد، بررسی مستندات دقیق سفارش و حفاظت Toobit و سپس ثبت یک پیکربندی با داده و بودجهٔ آزمون قابل بازتولید است.