گزارش وضعیت: طراحی در سطح مشخصات آغاز شده است. این کار شامل دسترسی به حساب، انتقال اطلاعات محرمانه، یا اجرای سفارش نیست. ابزار مرور وب، اجرای کد و دسترسی به فایل اصلی در این نشست در دسترس نیست. این پاسخ بخش ۱ از ۱۰ است؛ هر بخش بعدی در پیامی جداگانه ارائه می‌شود.

# Part 1/10 — Capability Envelope, Pre-Research Checkpoint, and Dependency Plan

**Previous parts:** None.  
**This part covers:** available capabilities and boundaries, the pre-research checkpoint, the dependency-derived work order, and the artifact registry.  
**Part 2/10 will cover:** the single requirements register and evidence ledger.

## Delivery plan

The complete design is planned as 10 separately delivered parts:

1. Capability inventory, pre-research checkpoint, dependency analysis, and artifact registry.
2. Single requirements register and evidence ledger.
3. Decision criteria, credible architecture alternatives, deployment-topology enumeration, and candidate strategy framing.
4. Universe derivation, data-class decisions, data lineage and quality rules, and storage calculations.
5. Statistical research design, trial-budget controls, parameter governance, and the required parametric risk examples.
6. Component boundaries, state ownership, interface contracts, and end-to-end system flow.
7. Independent risk authority, veto and resume behavior, order lifecycle, and Telegram command contract.
8. Deployment-envelope analysis, POCO X6 measurement plan, security, reliability, and recovery procedures.
9. Risk-derived operating phases, implementation dependency order, validation matrix, and adversarial review.
10. Final acceptance record, checklist audit, completeness declaration, self-verification record, and Persian closing status.

**Length-tracking method:** No numeric message-size limit or total-output limit is exposed. I will track delivery by complete artifact boundaries and keep each planned part self-contained. If an artifact cannot fit within the available message capacity, the part count will be revised before that artifact is sent. Turn-based multi-message delivery is available; autonomous consecutive messages are not exposed.

## 1. Capability and boundary inventory

**Material question answered:** Which resources can this design rely on without implying unavailable access or authorization?

| Capability | Observed state | Design consequence |
|---|---|---|
| Model/runtime identity | The exact model and runtime identifier are not exposed in the conversation. | No claim about a particular model version, hidden compute setting, or runtime configuration will be made. |
| Reasoning or compute controls | No selectable controls are exposed here. | No claim that a special reasoning mode or elevated compute allocation was used. |
| Context/output limits | A numeric context or message limit is not exposed. | Multi-part delivery is planned by artifact boundaries rather than an asserted token budget. |
| Supplied material | The parsed text of the owner-provided 54-page prompt is visible in the conversation. | It is the available project brief. References to its sections are owner-supplied inputs, not independent source verification. |
| Original PDF and file access | No file-system or PDF-binary inspection tool is exposed; only the parsed text is available. | No claim that the original PDF, its metadata, or embedded attachments were inspected. |
| External sources | No web-browsing or external-source tool is exposed. | Current Toobit documentation, current market data, provider quotes, and legal or licensing sources have not been checked. |
| Repository or archive | No repository, raw evidence archive, or codebase is available in the conversation. | The design will not claim to inspect those materials. Owner-supplied archive summaries retain their stated scope and status. |
| Code execution and testing | No code-execution or test harness is exposed. | No calculation is described as executed code; no software, exchange, device, or backtest test is claimed as run. |
| Independent review | No separate reviewer or model is available in this interaction. | A later adversarial review can be performed as a design review, but it cannot be represented as an independent external review. |
| Account and exchange access | No account access, credentials, or authenticated exchange tool is available or authorized. | The work remains design-only. No authenticated calls, permission changes, orders, cancellations, or modifications will be performed. |
| Multi-message delivery | Separate conversation turns are available; assistant-initiated consecutive messages are not exposed. | Each part is delivered as a complete message. The registry marks the remaining artifacts as not yet delivered. |
| UTC timestamp | No current UTC timestamp is exposed in the conversation metadata. | The checkpoint’s calendar date cannot be stated as verified. This limitation is recorded below rather than guessed. |

**Status:** The capability inventory is recorded from the observable conversation environment.  
**Evidence pointer:** Current conversation capabilities; owner brief §§2.1.1, 3.1.4, 4.3, and 12.4.  
**Consequence:** All source-dependent, device-dependent, exchange-dependent, and test-dependent conclusions remain unverified unless supported by the supplied owner evidence or a transparent calculation in a later part.

## 2. Pre-research design checkpoint

**Material question answered:** What design frame existed before any external research or source inspection?

**Checkpoint date:** **UNRESOLVED.** The runtime does not expose a UTC date or time. Resolution method: use an authoritative host-provided UTC timestamp or a date supplied by the owner. Authorization needed: none beyond access to that timestamp. Consequence: this checkpoint is preserved as the first visible design artifact and predates any external research in this engagement, while its exact calendar date is unverified.

**Persistence:** No file-writing capability is exposed. This message is the durable delivered record.  
**External research performed before checkpoint:** None.

### Objective

Produce a technically actionable, evidence-aware design for a Toobit futures/perpetual-futures trading system, without claiming profitability or validating an untested strategy. The design must preserve the owner’s hard constraints, distinguish evidence from judgment, and identify what requires measurement or an owner decision before implementation or Live operation.

### Binding constraints recorded from the brief

- Toobit is the selected Live venue; reopening that choice requires a material contradiction or explicit owner authorization.
- Telegram is the sole operator interface. It is not a trust boundary or a safety authority.
- UTC governs system computation and records; timestamps must have defined semantics.
- This engagement is design-only. No account access, secret handling, authenticated exchange calls, or live actions.
- Cross-venue data is gated by the owner’s access, licensing, and legal conditions; unresolved conditions prevent its use in Paper or Live paths.
- The trading intent is intraday, but the operational definition and maximum holding duration must be derived from the eventual strategy and validation.
- The symbol and timeframe universe is a breadth preference constrained by measured data, statistical budget, costs, compute, storage, and operations.
- The POCO X6 is a feasibility reference, not a preselected deployment architecture.
- Telegram loss, network loss, process death, and ambiguous exchange outcomes must not weaken risk controls or create false confirmation.
- Risk preferences remain pending. No per-trade risk fraction, drawdown limit, or related risk value is selected or used as an implicit anchor.
- Architecture and technical-method choices are delegated to the design process; they are not questions to return to the owner merely because several technical options exist.

**Evidence pointer:** Owner brief §§3.1–3.3.  
**Status:** Recorded as owner-supplied requirements and preferences, not independently verified external facts.  
**Consequence:** The design can continue on these terms, while unresolved risk, legal, resource, and venue facts remain explicitly bounded.

### Open matters preserved before comparison

1. **Risk policy:** Per-trade risk, aggregate exposure, daily loss, and drawdown limits require an owner decision. The brief explicitly requires parametric treatment until then.
2. **Cross-venue eligibility:** Jurisdiction, sanctions, registration, payment, withdrawal, and licensing conditions remain owner/legal matters. No legal conclusion is made here.
3. **Exchange details:** Current contract specifications, fees, endpoint behavior, rate limits, order constraints, and instrument availability have not been independently checked.
4. **Data gaps and conflicts:** Historical Open Interest remains unresolved; the stated `markPrice`/`klines.change` semantics conflict remains unresolved; order-book depth is non-reproducible in the supplied account.
5. **Device behavior:** Sustained POCO X6 runtime, thermal behavior, background survival, network stability, storage headroom, and restart recovery require measurement.
6. **Infrastructure availability:** Owner-accessible cloud or relay infrastructure, provider costs, and operational ownership are not established.
7. **Strategy evidence:** No strategy has been backtested in this engagement. A later design candidate must remain `NOT TESTED` until relevant calculations or experiments actually exist.

**Evidence pointer:** Owner brief §§3.1, 3.3, 5.1–5.5, and 10.3.  
**Consequence:** These uncertainties do not block independent architecture work. They do block any claim of a final eligible symbol universe, validated strategy performance, measured device fit, or Live readiness.

### Criteria to use when comparing candidates

Hard owner constraints and essential correctness conditions are pass/fail gates. Candidates that fail them cannot compensate through a favorable aggregate score. Among candidates that pass those gates, compare:

- correctness of state, time, and execution handling;
- ability to preserve independent risk vetoes;
- statistical validity and measurable net economic value;
- realistic cost and execution assumptions;
- resilience to Telegram, network, process, storage, and exchange failures;
- fit with measured compute, storage, latency, and operating capacity;
- security and auditability;
- maintainability, verifiability, and reversibility.

These criteria are **DESIGN_JUDGMENT** for this project: they directly address the owner’s stated safety, evidence, operational, and verification requirements. They are not claims that any candidate has already passed.

### Credible directions preserved without selecting one

- **On-device operation:** all relevant processes run on the POCO X6. Its fit remains unknown until representative workload tests exist.
- **Hybrid operation:** the phone handles some phases or the operator interaction, with a separately hosted workload where measured needs justify it.
- **Off-device operation:** research or runtime processes use an owner-authorized external host, with Telegram remaining the sole operator surface.

These are comparison candidates only. This checkpoint does not select a process topology, deployment location, strategy family, database, language, model class, or optimizer.

## 3. Dependency-derived work plan

**Material question answered:** Which findings must exist before dependent design choices can be made?

The following graph is derived from the information dependencies, not from the gate labels’ numbering:

```text
Capability and boundary inventory
              │
              ├──────────────┐
              ▼              ▼
Pre-research checkpoint   Requirements and evidence ledger
              └──────┬───────┘
                     ▼
       Independent candidate generation
       + comparison criteria fixed first
                     │
                     ▼
     Feasibility and comparative evaluation
                     │
                     ▼
              Design synthesis
                     │
                     ▼
          Adversarial design review
                     │
                     ▼
       Targeted revisions and available checks
                     │
                     ▼
      Final acceptance and completeness record
```

### Derived execution order and rationale

1. **Capability and boundary inventory:** required first because later claims must not depend on unobserved tools, sources, or authorizations.
2. **Pre-research checkpoint:** required before external evidence inspection; none has occurred in this engagement.
3. **Requirements and evidence ledger:** depends on the capability boundary and the supplied brief; it will distinguish owner constraints, attestations, ratified findings, and unresolved matters.
4. **Candidate generation and criteria:** depends on requirements. Criteria will be stated before candidates are compared.
5. **Feasibility and comparative evaluation:** depends on both the requirements and the candidate set. Unknowns will be handled parametrically or marked unresolved.
6. **Design synthesis:** depends on the selected candidate and its explicit assumptions, while independent work continues around pending owner decisions.
7. **Adversarial review:** requires a candidate design to attempt to falsify.
8. **Targeted verification and revision:** follows the review; only checks that can actually be performed with available tools and evidence will be reported as executed.
9. **Final acceptance:** depends on the design, evidence status, review findings, validation record, and completeness audit.

This ordering maps to the supplied G0–G8 exit-condition labels because their prerequisites produce this order for the work currently visible. The labels themselves are traceability labels; they are not the reason for the order.

**Status:** The dependency plan is established for this engagement.  
**Evidence pointer:** Owner brief §§2.1.2–2.1.6 and §7.  
**Consequence:** Candidate selection and design synthesis will not be presented as evidence-backed before their requirements, alternatives, and feasibility dependencies are addressed.

## 4. Artifact registry

**Material question answered:** Which artifacts are delivered, which remain outstanding, and where can the work resume?

| Artifact ID | Artifact name | Phase produced | Message reference | Status | Description |
|---|---|---:|---|---|---|
| ART-01 | Capability and boundary inventory | Part 1 | Part 1/10, §1 | DELIVERED | Records observable tools, access, authorization, and capability unknowns. |
| ART-02 | Pre-research design checkpoint | Part 1 | Part 1/10, §2 | DELIVERED | Preserves the initial frame before external research; exact date is unresolved. |
| ART-03 | Dependency plan and delivery plan | Part 1 | Part 1/10, §§3 and opening | DELIVERED | Records the dependency-derived work order and planned message boundaries. |
| ART-04 | Requirements register and evidence ledger | Part 2 | Planned | DEFERRED | Single register with the required fields; reason: separate complete artifact boundary. |
| ART-05 | Candidate comparison and topology enumeration | Part 3 | Planned | DEFERRED | Criteria-first comparison and deployment candidates; reason: requires ART-04. |
| ART-06 | Universe and data design | Part 4 | Planned | DEFERRED | Derived symbol/timeframe procedure, data decisions, and explicit quantitative limits; reason: depends on strategy and evidence decisions. |
| ART-07 | Statistical and parameter-governance design | Part 5 | Planned | DEFERRED | Trial control, validation method, parameter governance, and required parametric risk examples; reason: depends on the candidate strategy and pending risk boundary. |
| ART-08 | Component and end-to-end architecture | Part 6 | Planned | DEFERRED | Component responsibilities, state ownership, interfaces, and complete system flow; reason: depends on selected design direction. |
| ART-09 | Risk, execution, and Telegram contract | Part 7 | Planned | DEFERRED | Veto/recovery behavior, order state machine, and operator command semantics; reason: depends on the component and state model. |
| ART-10 | Deployment and operations design | Part 8 | Planned | DEFERRED | Envelope-first topology fit, device measurement plan, security, resilience, and recovery; reason: depends on the workload and state requirements. |
| ART-11 | Phases, verification, and adversarial findings | Part 9 | Planned | DEFERRED | Risk-derived phases, implementation dependency order, validation matrix, and design-level adversarial review; reason: depends on the complete requirements and design. |
| ART-12 | Final acceptance and completeness record | Part 10 | Planned | DEFERRED | Overall status, checklist audit, completeness declaration, and individual self-verification entries; reason: can only be completed after the preceding artifacts exist. |

Artifact IDs are defined in this registry. `DEFERRED` means the artifact has not yet been delivered; it does not indicate that its content has been verified or completed.

## Part 1 completeness declaration

**Part 1/10 is complete for its declared scope.** Content deferred: none within Part 1’s scope. The remaining artifacts are separately identified in the delivery plan and registry; they are not represented as delivered.

- **Status:** Part 1 delivered; overall engagement remains in progress.
- **Evidence pointer:** This message, §§1–4.
- **Known limitation:** The exact checkpoint date and several tool/source capabilities remain unavailable or unverified, as recorded above.
- **Next logical action:** Deliver Part 2/10, the single requirements register and evidence ledger.
- **Overall completeness:** Not yet declared. The final declaration is reserved for Part 10/10, after the planned artifacts and checks have been addressed.


وضعیت: بخش ۲ از ۱۰. بخش ۱ مستند کرد کدام ابزارها و منابع در دسترس‌اند، حدود این تعامل را تعیین کرد و وابستگی‌های کار را ثبت کرد. این بخش دفتر واحد الزامات و دفتر شواهد را تحویل می‌دهد. بخش ۳ معیارهای مقایسه، گزینه‌های معماری و توپولوژی‌های استقرار را بررسی می‌کند.

# Part 2/10 — Requirements Register and Evidence Ledger

**This part continues from Part 1/10**, which recorded the observable capability limits, the pre-research checkpoint, the dependency-derived work plan, and the artifact registry. **This part covers** the requirements register and the owner-supplied evidence ledger. **Part 3/10 will cover** criteria-first option comparison, architecture candidates, and deployment-topology enumeration.

## Provenance and register fields

The only project source available here is the parsed text supplied in the conversation. The original PDF, raw archive, external sources, code, and exchange endpoints have not been independently inspected. Accordingly, the evidence below preserves the labels and scope supplied in the brief; it does not claim fresh verification.

Section 6 calls the register “11-field” while listing nine fields. This register retains all nine listed fields and adds **Owner / authority** and **Consequence**. Those additions make decision ownership explicit and satisfy the brief’s requirement to state the consequence of a material item’s status. The register therefore has 11 columns.

A requirement’s status concerns its current verification, not whether it appears clearly in the brief. `NOT TESTED` means the relevant design or check has not yet been completed. `UNRESOLVED` means a material fact or owner decision remains outstanding. `PASS` is used only for a condition actually observed within the stated scope.

## Single requirements register

| ID | Priority | Owner / authority | Rationale / source | Verification method | Acceptance condition | Status | Evidence pointer | Failure response | Consequence | Regression checks |
|---|---|---|---|---|---|---|---|---|---|---|
| R-001 | HARD | Owner defines the project objective; the design must not invent a return target or guarantee. | The engagement calls for a defensible system design, not a profit guarantee; the owner has not defined a complete utility function. | DESIGN_INSPECTION; EXPERIMENT for any later strategy claim. | State measurable evaluation quantities where supported; do not promise returns or infer acceptable loss; label untested performance claims as hypotheses. Any unresolved return or risk preference remains explicit. | NOT TESTED | Owner brief §§0, 1, 6, 8.0. | Remove unsupported claims; mark untested performance as NOT TESTED or PROVISIONAL, as applicable. | Strategy promotion cannot rest on an unapproved return or risk target. | R-007, R-013, R-014, R-023, R-026. |
| R-002 | HARD | Owner selected Toobit; the design derives eligible contracts within that venue. | Toobit perpetual futures are the selected Live venue; the supported API intervals are a capability boundary, not a required universe. | DESIGN_INSPECTION; SOURCE_CHECK before any later implementation or venue-facing test. | Keep the Live venue at Toobit absent a material contradiction or owner authorization. Admit only listed Toobit perpetual contracts; verify the current contract and instrument specifications before implementation. Exclude the reported unsupported 3d interval. | NOT TESTED | Owner brief §3.1 item 1; §5.1, C1 and C2. | Exclude a contract or interval whose eligibility or required specifications cannot be established. | The Live universe and order-validity rules depend on verified venue instruments and contract specifications. | R-009, R-011, R-014, R-017, R-018. |
| R-003 | HARD | Owner explicitly prohibits account access and live actions in this engagement. | Design work must not be confused with account operation or authorization. | DESIGN_INSPECTION. | During this engagement, do not request credentials, access the account, make authenticated calls, change permissions, access funds, or submit, cancel, or modify orders. **Current-engagement result: PASS** for this boundary; no such access or action has occurred. | PASS, scoped to this engagement | Owner brief §3.1 item 4; Part 1/10 §1 records the available account-access boundary. | Stop any action that would cross the design-only boundary; keep the work at specification level. | No account or execution result can be claimed from this engagement. | R-017, R-018, R-019, R-026. |
| R-004 | HARD | Owner requires Telegram as the sole operator surface; design authority defines its command and authorization contract. | Runtime control, mode selection, configuration, alerts, acknowledgements, monitoring, and legitimate read-only review must use Telegram. Telegram is not itself a trust boundary. | DESIGN_INSPECTION; DETERMINISTIC_TEST; SECURITY tests when implemented. | Provide the specified runtime operator functions through Telegram only; do not add a parallel dashboard, application, second bot, or routine operator console. Authenticate privileged actions and validate untrusted messages. | NOT TESTED | Owner brief §3.1 item 2 and §9.9. | Reject unauthenticated, unauthorized, malformed, replayed, or otherwise invalid privileged commands; preserve local safety behavior if Telegram fails. | Mode changes and operator actions cannot be accepted safely until command authorization and handling are specified and tested. | R-006, R-020, R-021, R-023, R-026. |
| R-005 | HARD | Owner mandates UTC; the design defines timestamp semantics and clock-failure behavior. | UTC is authoritative for computation, storage, logs, schedules, reports, alerts, exchange communication, and audit events. | DESIGN_INSPECTION; DETERMINISTIC_TEST; SOURCE_CHECK for any venue timestamp rules. | Assign each timestamp a defined meaning; use monotonic time for elapsed deadlines and UTC wall time for instants. Use UTC daily boundaries and ISO-8601 UTC weeks unless a justified alternative is recorded. Derive a Live clock-offset tolerance from relevant measurements and venue requirements; if unresolved, Live must fail closed. | NOT TESTED | Owner brief §3.1 item 3 and §9.8. | Treat stale, unknown, or excessive clock offset as an unevaluable Live interlock; refuse Live actions. | Timestamp errors can corrupt ordering, bar availability, audit records, and order decisions. | R-006, R-011, R-017, R-018, R-022, R-026. |
| R-006 | HARD | Owner prefers a direct Paper/Live selector; the owner requires the six safety interlocks; design defines command-context preconditions. | The selector must not be replaced by arbitrary waiting periods or profit hurdles. Each interlock must be evaluable in the context of the command that invokes it. | DESIGN_INSPECTION; DETERMINISTIC_TEST. | Before a Live transition, evaluate data validity, reconciliation, defined and passing risk limits, credential and permission validity, configuration integrity, and clock offset. Refuse with an explicit reason when a required check fails. Do not make a Paper command depend on Live-only checks or a general resume command depend on per-trade quantities that do not yet exist. | NOT TESTED | Owner brief §3.1 item 10 and §9.9. | Refuse the transition when an applicable interlock fails or cannot be evaluated; leave the existing safe mode unchanged. | A defective selector can either block valid operations indefinitely or permit an unsafe Live transition. | R-004, R-005, R-007, R-015, R-016, R-018, R-020, R-023, R-026. |
| R-007 | HARD | Final risk appetite is an OWNER_DECISION_PENDING matter; the model may derive the control structure, not ratify owner risk limits. | The illustrative drawdown and per-trade figures are preferences, not approved limits, and must not become implicit calculation anchors. | OWNER_DECISION; CALCULATION for later parametric examples. | Keep risk limits pending until explicitly decided by the owner. Before that decision, express dependent calculations parametrically and show sensitivity across a range; do not adopt any one illustrative percentage as a limit or default. | UNRESOLVED — owner decision pending | Owner brief §§2, 3.3, and 9.6. | Do not enable Live risk evaluation or claim a finalized position-sizing policy while required hard limits remain undefined. Continue independent design work parametrically. | Position sizing, exposure limits, loss limits, and Live readiness remain contingent on the owner’s decision. | R-001, R-006, R-008, R-013, R-014, R-016, R-023, R-026. |
| R-008 | HARD | The owner supplies an illustrative planning scale; the design must not treat it as current account equity. | Approximately 200 USDT, with a planning range below 500 USDT, is a feasibility scale only. Quantities require units and correct distinctions. | CALCULATION; DESIGN_INSPECTION; OWNER_DECISION for actual limits. | Treat planning equity as a parameter, not an account fact. Explain equity, initial/current equity, notional, margin, leverage, quantity and multiplier, stop distance, gross loss, fees, funding, spread, slippage, liquidation, per-trade risk, concurrent risk, daily loss, and peak-to-trough drawdown. Express monetary quantities in USDT or the instrument’s quote currency. | NOT TESTED | Owner brief §§3.1 item 11, 3.3, and 9.6. | Correct unit or quantity errors before a sizing calculation is accepted; leave risk-dependent results parametric. | Capital feasibility and all risk calculations depend on these distinctions and on the owner’s still-pending risk policy. | R-007, R-009, R-013, R-014, R-016, R-026. |
| R-009 | HARD for derivation; breadth is SHOULD | The model derives the universe. The owner’s preference for breadth is not a hard coverage target. | The universe must follow the supplied D14 procedure across symbols and timeframes; the 14 reported intervals are a ceiling, not a floor. | DESIGN_INSPECTION; CALCULATION; SOURCE_CHECK; EXPERIMENT where a strategy test is required. | Derive eligible Toobit perpetual symbols and intervals from the exchange boundary, liquidity and cost assumptions, per-symbol data depth, recomputed statistical budget, measured-or-bounded resource envelope, and strategy information needs. Show the liquidity-threshold calculation chain and record a universe entry per admitted symbol and timeframe. Do not use the 10-symbol storage example as a default universe. | NOT TESTED | Owner brief §§3.1 items 7–8, 5.1 C1–C2 and C9–C10, 5.3 C19, 5.4 C23–C24, and §10.1. | Exclude an unsupported item or mark it PROVISIONAL with a measurement path; do not silently widen coverage. | Symbol and interval selection controls data needs, costs, statistical burden, storage, and compute. | R-002, R-008, R-010, R-011, R-013, R-019. |
| R-010 | HARD | Owner sets intraday intent; the model derives the operational definition and duration policy. | A fixed holding duration cannot be invented independently of the candidate strategy, exits, funding, costs, market behavior, risk, and validation. | DESIGN_INSPECTION; EXPERIMENT; CALCULATION. | Define the operational meaning of intraday trading and any maximum holding duration from the selected strategy and its validated inputs. State the evidence and assumptions; do not impose a duration solely to make the specification concrete. | NOT TESTED | Owner brief §3.1 item 6. | Keep the duration policy unresolved or restrict the candidate until its necessary inputs and validation exist. | Holding duration affects timeframe needs, exposure, funding, exits, and the deployment envelope. | R-007, R-009, R-011, R-013, R-014, R-015. |
| R-011 | HARD | Design authority defines data contracts and validation rules; source eligibility remains constrained by the owner’s perimeter. | The design needs causally valid data and explicit handling of missing, stale, duplicate, malformed, contradictory, unavailable, or source-tagged records. | DESIGN_INSPECTION; SOURCE_CHECK; DETERMINISTIC_TEST. | Specify source, coverage, timestamp and availability semantics, historical depth, point-in-time status, quality controls, lineage, retention, cost, and failure behavior for every included input. Never substitute zero for missing data without a justified semantic rule. Address the conflicted mark-price/change semantics and unresolved historical Open Interest with a fallback or mark dependent features UNRESOLVED. | NOT TESTED | Owner brief §§5.1 C13, 5.5 C26, 9.4, and 9.5. | Reject or quarantine invalid data; veto dependent decisions when a required input is unavailable or stale. Keep unresolved fields out of critical features unless a valid fallback is specified. | Data leakage, false values, or incorrect timestamp semantics can invalidate research and live decisions. | R-005, R-009, R-010, R-012, R-013, R-015, R-026. |
| R-012 | HARD | Owner-defined source restrictions bind; unresolved legal, sanctions, licensing, or access questions require owner or legal authority. | Cross-venue evidence is not proof that the owner may register, pay, withdraw, or use that venue under equivalent conditions. | OWNER_DECISION; SOURCE_CHECK; DESIGN_INSPECTION. | Admit another venue’s data only when the owner’s stated registration/KYC or equivalent-access, cost, and legal/licensing conditions are established. Preserve source tags. Until eligibility is established, restrict that data to permitted research/backtesting and exclude it from Paper and Live paths. | UNRESOLVED — eligibility for any proposed source requires owner/legal resolution | Owner brief §3.1 item 5; §5.3 C17–C18 and jurisdiction/licensing statement. | Gate an unverified source away from Paper and Live; do not make a legal conclusion on the owner’s behalf. | Cross-venue-derived features cannot affect Paper or Live decisions while the relevant conditions remain unresolved. | R-009, R-011, R-013, R-015, R-019, R-026. |
| R-013 | HARD | The model selects appropriate research methods; the owner-supplied trial-budget constraints bind their use. | Statistical rigor validates a proposed strategy; it must not be used to reject every strategy before one is proposed. | CALCULATION; EXPERIMENT; DESIGN_INSPECTION. | Propose at least one candidate before judging strategy viability. Test relevant leakage, survivorship, dependence, nonstationarity, repeated search, realistic execution, sensitivity, and uncertainty. Recompute the admissible trial budget per cell; never propose a full permutation grid at intervals of 12h or less. Do not use C23’s provisional counts as hard ceilings without the required recomputation. | NOT TESTED | Owner brief §§5.4 C20–C24 and 8.0–8.4. No candidate test has been run in this engagement. | Revise the strategy, bound the search, or leave the result UNRESOLVED with its consequence; do not make unsupported acceptance or rejection claims. | No strategy or optimizer can be promoted on unverified statistical claims. | R-001, R-009, R-010, R-014, R-015, R-026. |
| R-014 | HARD | Design authority specifies cost and execution assumptions; unresolved fee and market-depth evidence must remain visible. | Gross returns do not establish net economic value; fees, spread, slippage, funding, fills, partial fills, and liquidation matter. | CALCULATION; SOURCE_CHECK; EXPERIMENT. | Report gross and net results separately and include each cost term with source and scope. Preserve the taker-fee uncertainty as a range, use the stated conservative branch until resolved, treat funding as a tail term rather than a guaranteed cap, and show cost sensitivity. Do not treat non-reproducible order-book depth as settled capacity. | NOT TESTED | Owner brief §5.1 C6–C10 and §§8.1–8.3, 9.6. | Refuse unsupported precision; mark a cost input unresolved and restrict conclusions that depend on it. | Strategy feasibility and symbol eligibility may change materially under realistic costs and fills. | R-001, R-007, R-008, R-009, R-010, R-013, R-017. |
| R-015 | HARD | Architecture and method choices are delegated to the model; owner-approved hard risk limits remain outside optimizer authority. | Forecasting, calibration, portfolio construction, and independent risk control serve different functions; adaptation is a candidate, not a required component. | DESIGN_INSPECTION; EXPERIMENT; CALCULATION. | Specify which component produces a forecast, which translates it into positions, and which can veto. Derive whether adaptation is needed; if included, version experiments and parameters, control search, define promotion and rollback, and prevent live outcomes from contaminating prior evaluation sets. No optimizer or model can relax a hard risk limit. | NOT TESTED | Owner brief §§3.1 item 12, 8.5–8.6, and 9.10. | Remove or disable a mechanism that crosses risk authority, lacks required provenance, or cannot be validated. | Blurred authority or ungoverned adaptation can invalidate both risk controls and research claims. | R-006, R-007, R-011, R-013, R-016, R-023, R-026. |
| R-016 | HARD | Risk authority is independent of signals, optimizers, configuration, retries, and operator-interface availability. | Missing or corrupted persistent risk state makes a risk check unevaluable; initializing it from current values could erase known exposure or drawdown. | DESIGN_INSPECTION; DETERMINISTIC_TEST; FAULT_INJECTION. | Treat missing, unreadable, corrupt, stale, or inconsistent risk state as a hard veto. Do not initialize unknown drawdown, daily loss, exposure, or position-count history as zero. Specify the recovery condition that clears each veto separately from any post-recovery acknowledgement gate. | NOT TESTED | Owner brief §9.6. | Block Live entries, issue the required critical alert, and require the specified restoration or recovery path. An acknowledgement cannot clear a still-failing veto or substitute for missing ledger history. | Unknown risk state must not become a fail-open route to Live trading. | R-006, R-007, R-008, R-014, R-015, R-017, R-018, R-020, R-022. |
| R-017 | HARD | Design authority specifies the complete order protocol; venue outcomes and their ambiguity must be represented truthfully. | The supplied venue finding says `-1007 TIMEOUT` does not prove rejection; retries must be finite and rate-limit-aware. | DESIGN_INSPECTION; DETERMINISTIC_TEST; FAULT_INJECTION; SOURCE_CHECK. | Define the complete order state set and transitions, input validation, idempotency, unique client IDs within `[A-Za-z0-9_-]`, finite retry budget and backoff, partial fills, cancel/fill races, rejections, protective orders, timeout ambiguity, and crash recovery. Do not resubmit an ambiguous order as if it had been rejected. | NOT TESTED | Owner brief §5.1 C4–C5 and C11; §9.7. | Halt dependent submissions and reconcile an ambiguous outcome before any action that could duplicate or contradict it. Stop on the finite retry hard limit. | Order uncertainty can create duplicate exposure, incorrect positions, or an unsafe recovery. | R-002, R-005, R-006, R-014, R-016, R-018, R-020, R-026. |
| R-018 | HARD | The design must define authoritative state and reconciliation; the engagement makes no authenticated exchange calls. | Internal replicas must not silently diverge from actual venue positions, orders, balances, or fills. | DESIGN_INSPECTION; DETERMINISTIC_TEST; FAULT_INJECTION; future authorized SOURCE_CHECK. | For every state quantity, identify its authority, cache or replica, validation trigger, mismatch behavior, and reconciliation completion condition. Define what remains blocked while exchange and internal states disagree. | NOT TESTED | Owner brief §§9.3, 9.7, and 9.9; §3.1 item 4 prohibits account access in this engagement. | Freeze new risk-increasing actions while a material mismatch or ambiguous external outcome remains unresolved. | Position sizing, risk evaluation, and mode transitions depend on trustworthy reconciled state. | R-003, R-005, R-006, R-016, R-017, R-019, R-020, R-022. |
| R-019 | HARD | The owner requires envelope-first deployment derivation; phone preservation is an owner preference, not an architecture driver. | The POCO X6 must be compared with the workload envelope after the strategy and operational needs are derived. | CALCULATION; DETERMINISTIC_TEST; EXPERIMENT; DESIGN_INSPECTION. | Derive compute, storage, latency, availability, recovery, and workload needs first. Enumerate every permitted deployment topology before applying the stated compromise order. Give each topology a fit status and specific gap; any later topology must first be added to that enumeration. | NOT TESTED | Owner brief §3.1 item 8 and §§10.3, 13.4. | Do not claim a topology fits without measurements or bounds; apply the documented compromise order only after the envelope comparison. | Deployment and universe breadth remain provisional until workload and infrastructure fit are established. | R-009, R-010, R-019, R-020, R-022, R-027. |
| R-020 | HARD | The owner requires safety to persist independently of Telegram; the design defines disconnected behavior. | No stable inbound handset connection is assumed; Telegram loss must not clear a veto or imply that an exchange outcome is known. | DESIGN_INSPECTION; DETERMINISTIC_TEST; FAULT_INJECTION; EXPERIMENT. | Specify behavior for operator unavailability, Telegram API/token failure, network loss, process interruption, open positions, and pending orders. Local risk logic remains active; uncertain outcomes remain uncertain; open-risk treatment is explicit and does not require the operator to be continuously reachable. | NOT TESTED | Owner brief §§3.1 item 9, 5.2, and 9.9. | Preserve the last safe operating state, prevent unsafe new actions, and apply the specified local order and position-management policy. | Connectivity failure cannot be permitted to release risk controls or conceal exposure. | R-004, R-006, R-016, R-017, R-018, R-019, R-021, R-022. |
| R-021 | HARD | Owner requires secure handling and least privilege; detailed technical choices are delegated. | Telegram input, API credentials, dependencies, and releases cross security boundaries. | DESIGN_INSPECTION; SECURITY tests; DETERMINISTIC_TEST. | Specify secret storage, access, rotation, and redaction; least-privilege API permissions; privileged-action authorization; replay and injection controls; dependency pinning; release verification; and audit of privileged actions. Never log secrets or send them over unencrypted channels. | NOT TESTED | Owner brief §§3.1 item 2 and 9.8. No security tests have been run. | Reject unauthorized commands and invalid credentials; revoke or rotate exposed secrets through a defined authorized procedure. | A credential or command-control defect could compromise funds or change system behavior. | R-003, R-004, R-020, R-022, R-026, R-027. |
| R-022 | HARD | Design authority defines persistence and operations; unresolved exchange retention remains explicitly unresolved. | Recovery, storage corruption, process death, backups, and outage handling affect whether reconstructed state can be trusted. | DESIGN_INSPECTION; DETERMINISTIC_TEST; FAULT_INJECTION; recovery drill. | Define durable records, correction policy, retention, backups and restore tests, controlled startup/shutdown, overload behavior, monitoring, and recovery. Define any severity or outage classes before using them. Treat the provisional three-day value as governing reconciliation deferral only; do not claim it proves exchange retention. | UNRESOLVED — exchange retention and maximum safe outage require authorized evidence or measurement | Owner brief §5.1 C12; §§9.8 and 13.4. | If required recovery evidence is unavailable, refuse startup or Live operation, alert with the failed check, and follow an out-of-band procedure when that procedure requires the process to be stopped. | An outage beyond a supported reconciliation window may leave exchange and internal state uncertain. | R-005, R-016, R-017, R-018, R-019, R-020, R-021, R-026. |
| R-023 | HARD | The model derives operating phases; the owner prefers direct mode selection subject to mandatory interlocks. | Phase vocabulary expresses intent, while phase boundaries must address material risks and verification dependencies. | DESIGN_INSPECTION; DETERMINISTIC_TEST; EXPERIMENT; OWNER_DECISION for any new owner-level trade-off. | Enumerate material risks and verification dependencies; derive the minimum phase structure; define entry, exit, acceptance, and rollback for each phase. Record every mapping from the owner’s training, calibration, Paper, and Live vocabulary. A Live transition has correctness interlocks, not arbitrary waiting periods or profit hurdles. | NOT TESTED | Owner brief §3.1 item 10 and §11.3. | Keep the system in the last phase whose conditions are established; refuse a transition whose applicable interlock fails. | No phase transition or readiness claim is justified by phase names alone. | R-001, R-006, R-007, R-013, R-015, R-016, R-019, R-026. |
| R-024 | HARD | Architecture, language, framework, runtime, library, strategy, and optimizer choices are delegated to the model. | Architecture must be positively derived from requirements, with credible alternatives and a simpler baseline where relevant. | DESIGN_INSPECTION; CALCULATION; SOURCE_CHECK or DETERMINISTIC_TEST where these can distinguish candidates. | State the comparison criteria before candidate comparison; derive candidates from requirements; include a simpler baseline for consequential choices; explain each selected and rejected option with a positive reason. Specify component contracts only where responsibility, state, trust, deployment, failure, testing, or change boundaries justify them. | NOT TESTED | Owner brief §§1, 2.1.3, 3.1 item 12, 9.1–9.2. | Reopen any choice whose rationale depends only on convention, familiarity, or an unverified assumption. | Unsupported architectural choices can impose unnecessary cost or fail a binding constraint. | R-009, R-013, R-015, R-019, R-022, R-027. |
| R-025 | HARD | The model must record actual source access, capability use, evidence, and uncertainty without fabrication. | Claims need inspectable evidence, transparent derivation, explicit reasoning, or an explicit uncertainty label. | DESIGN_INSPECTION; SOURCE_CHECK; CALCULATION; DETERMINISTIC_TEST as available. | Identify which sources and tools were actually inspected or used; distinguish owner summaries from direct inspection; provide pointers for material claims; label unsupported facts UNRESOLVED or NOT ESTABLISHED with a resolution method. Do not claim tests, citations, source access, or reviews that did not occur. | NOT TESTED for the final engagement record; Part 1/10 records the currently observed capability envelope | Owner brief §§2, 2.1.0c, 2.1.1, 4.1, 4.3; Part 1/10 §1. | Correct or withdraw any untraceable assertion and mark the affected acceptance item as failed or untested. | Evidence status determines whether a design choice can be treated as established. | R-001, R-009, R-011–R-014, R-019, R-026, R-029. |
| R-026 | HARD | The design must define acceptance evidence; actual execution depends on available tools, inputs, and authorization. | Design completeness, source review, backtests, implementation, Paper operation, operational readiness, and Live authorization are separate statuses. | DESIGN_INSPECTION; CALCULATION; SOURCE_CHECK; DETERMINISTIC_TEST; EXPERIMENT; OWNER_DECISION. | Give each registered requirement one verification-matrix row. Report test inputs, expected result, observed result, status, evidence pointer, failure response, and regression checks. Report the seven assurance dimensions separately; never treat a test plan as an executed test or design review as Live authorization. | NOT TESTED — matrix and acceptance audit are pending | Owner brief §§2.1.4, 11.1–11.3, 13. | Mark missing checks NOT TESTED or BLOCKED with the specific dependency; do not claim readiness. | Implementation, Paper, operational, and Live claims remain unsupported without their distinct evidence. | R-003, R-013, R-017–R-025, R-029. |
| R-027 | HARD | The model derives any future implementation order and repository structure; no external repository may be modified here. | Implementation order must follow dependency, risk-reduction, and verification needs; structure must not anticipate unjustified features. | DESIGN_INSPECTION. | Specify a future sequence only at the level supported by the design. Keep the implementation sequence, future repository blueprint, production code, and owner knowledge repository distinct. Do not create or modify external files in this engagement. | NOT TESTED | Owner brief §§11.4 and 12.1–12.2; §3.1 item 4. | Remove unsupported boilerplate or future-feature structure; retain design-only scope. | Developers otherwise inherit unnecessary structures or mistaken claims of implementation. | R-003, R-019, R-021, R-024, R-026, R-029. |
| R-028 | HARD | The model makes delegated technical choices; the owner decides only genuinely non-delegable matters or grants missing authorizations. | The brief prohibits unnecessary questions and defines when a newly discovered owner-level decision requires a pause. | DESIGN_INSPECTION; OWNER_DECISION where the pause conditions are met. | Do not ask the owner to choose an algorithm, infrastructure, language, framework, runtime, or model class delegated to the design. Continue independent work around declared unresolved matters. Pause only for a material, owner-level, pre-undeclared, blocking decision when accumulated work can be preserved; present options, trade-offs, recommendation, exact decision, default, delay consequence, and reversibility. | NOT TESTED for future decision points; no delegated choice has been returned to the owner in this part | Owner brief §§1.6, 2.1.7, 3.1 items 12–13. | Make delegated choices with labeled rationale; defer safely when possible; pause for a qualifying owner decision rather than silently assuming it. | Misassigned decisions either burden the owner unnecessarily or hide an owner-level choice. | R-007, R-012, R-019, R-023, R-024, R-029. |
| R-029 | HARD | Delivery must preserve artifacts incrementally and meet the engagement’s declared completeness obligations. | Dependency analysis, evidence records, artifact persistence, and truthful final acceptance are required parts of the work. | DESIGN_INSPECTION; arithmetic check; artifact-registry inspection. | Deliver material artifacts incrementally; keep the registry current; follow the declared part plan; give every part a complete scope declaration; and provide the final completeness declaration with verified counts, statuses, limitations, and individual V-1 through V-12 entries. Do not claim the engagement complete before that final record exists. | NOT TESTED for the full engagement; this part’s artifacts and registry update are delivered below | Owner brief §§2.1.2, 2.2.1–2.2.8, 12, and 13.6; Part 1/10 delivery plan. | Correct a missing artifact or status before advancing to final acceptance; if a dependency is unavailable, identify it and its consequence rather than claiming completion. | A missing or unpreserved artifact prevents an auditable and resumable design record. | R-025–R-028. |

**Register count:** 29 requirements, numbered R-001 through R-029 with no gaps or additional rows. The later verification matrix must contain exactly 29 corresponding rows.

## Evidence ledger

Every C-series reference below is defined in the owner-supplied prompt §5.0. The records are presented as **owner-supplied findings or attestations**, according to their stated status; none is relabeled `SOURCE_VERIFIED` in this engagement.

| Reference | Evidence label and scope | Owner-supplied content | Permitted use and limitation |
|---|---|---|---|
| C1 | RATIFIED_FINDING, with tested-path scope | Toobit’s reported interval set is 1m, 3m, 5m, 15m, 30m, 1h, 2h, 4h, 6h, 8h, 12h, 1d, 1w, and 1M. Extraction for these intervals was reported available with free API keys within the tested scope. 3d was reported unsupported on the three REST kline endpoints, with no WebSocket candle payload observed for it. 3m and 8h were reported `LIVE_PASS` on tested REST/WebSocket paths. | Treat the intervals as a capability ceiling, not a required universe. Preserve the reported scope; do not generalize it to untested symbols or endpoints. |
| C2 | RATIFIED_FINDING, with sampling limitation | The 3,500-candle figure is a cap, not a guarantee. The measured daily sample contained 1,774 bars, approximately 4.86 years at daily cadence, rather than 9.59 years. The cap was measured on perpetual symbols, not spot symbols. The full 544-symbol by 14-interval census was not exhaustive: 58 stratified symbol/endpoint/interval combinations were recorded, and 36 reached 3,500 bars. | Verify actual depth per admitted symbol and interval. Do not infer uniform history from the cap or the sampled census. |
| C3 | RATIFIED_FINDING for the reported ladder; UNRESOLVED for the maximum permitted | The reported BTC risk/leverage ladder has 13 tiers down to 1.0×, correcting an earlier statement that it ended at 5×. | The tier record does not establish the maximum account- or symbol-specific leverage, or a system risk limit. Keep any such ceiling unresolved until supported. |
| C4 | RATIFIED_FINDING, tested environment | `X-Api-Limit-*` response headers were absent in the tested environment. | Use explicit conservative weight accounting; do not make executable accounting depend on header deltas. Any later calibration probe requires narrow scope, control, and separate authorization. |
| C5 | RATIFIED_FINDING | `-1007 TIMEOUT` is an ambiguous outcome and does not prove an order was rejected. `-1003` is the reported rate-limit breach code. | Retries must be bounded, accounted for, backed off, and stopped at a finite limit. Reconcile an ambiguous result rather than assuming rejection. |
| C6 | UNRESOLVED, with stated conservative branch | Taker fees were documented as 0.05% and observed as 0.06%; the discrepancy was not re-established. | Report the unresolved fee as a range and use the more conservative stated value for provisional cost-feasibility analysis until properly resolved. |
| C7 | RATIFIED_FINDING, reported observation | A funding clamp of −30.0000 bp was observed; an alleged ±24 bp cap was refuted. | Treat funding as a tail cost or risk term. Do not present the refuted cap as a safe bound. |
| C8 | UNRESOLVED, non-reproducible record | Order-book depth was non-reproducible, and one-sided versus two-sided convention remained ambiguous. The supplied record cites BTC estimates of 90.6 million and 92.7 million USDT-equivalent under different conventions. | Do not treat these values as settled capacity facts. Any later comparison must define its depth convention and retain the uncertainty. |
| C9 | RATIFIED_FINDING, snapshot rather than timeless fact | The reported snapshot gives median 24-hour notional of approximately 498,844 USDT and 134 symbols at or above 10 million USDT. An earlier record of 515,000 USDT and 136 symbols is superseded. | Use only as a scoped snapshot for derivation. It does not establish present or future liquidity for any specific contract. |
| C10 | RATIFIED_FINDING within the stated cost-model scope | Corrected cost-per-volatility values at 5m and 15m are 1.42 and 0.82, rather than the earlier 0.97 and 0.56. The supplied conclusion is a maker-only floor at 15m and above. | Preserve the correction when assessing the same scope. Do not generalize it to unrelated symbols or market conditions without evidence. |
| C11 | RATIFIED_FINDING | The reported supported `clientOrderId` character intersection is `[A-Za-z0-9_-]`, narrower than an earlier proposed set. | Any designed identifiers must use the supported set and must be unique and non-reused within the supported scope. |
| C12 | UNRESOLVED, with a provisional owner value | Maximum safe outage depends on undocumented exchange retention. A three-day outage threshold was recorded provisionally, but the original “Class-A” term was not fully defined. | Do not present three days as verified exchange retention. The supplied operations instruction assigns that provisional value to reconciliation deferral only. Define any classes before using them; resolve retention separately. |
| C13 | UNRESOLVED, conflicting semantics | Earlier material described `markPrice` or `klines.change` as the mark-price bar’s own return and said index endpoints returned empty. A later archive summary records conflicting documented and observed semantics. | Do not use the disputed field as a critical feature without a scoped resolution or a fallback independent of the disputed meaning. |
| C14 | OWNER_ATTESTED device specification | The reference device is a Xiaomi POCO X6, model 23122PCD1G; Snapdragon 7s Gen 2, octa-core, up to 2.4 GHz; 12.0 GB physical RAM plus 8.0 GB memory extension; Android 16, build BP2A.250605.031.A3; system version 3.0.302.0.WNRMIXM.C07; security update 2026-07-01; kernel 5.10.236-android12-9-00003-gfb24cf99ad97-ab14313284; baseband MPSS.DE.3.1.1-GLB-29d2055e1e; 256 GB total storage and 56 GB available at the owner’s check. | Preserve physical RAM separately from memory extension. Treat free storage as a time-sensitive owner snapshot, and specifications as attested inputs rather than workload benchmarks. |
| C15 | RATIFIED_FINDING | Charging does not exempt an app from Android’s restricted App Standby Bucket. The brief also identifies Doze, foreground-service behavior, process death, OEM process management, battery optimization, thermal throttling, storage interruption, wakelock cost, and unstable inbound connectivity as relevant operational threats. | Do not infer continuous background execution from charging or battery behavior. Test platform behavior against each intended workload. |
| C16 | UNRESOLVED, with an owner operational observation | The owner reports a healthy-performing battery, continuous charging, and a prior 24-hour charging test without observed problems or noticeable heating. Sustained workload performance has not been measured. CPU throughput, thermal behavior, memory pressure, free storage, background survival, network stability, and restart recovery remain unmeasured. | Treat the 24-hour observation as an owner report, not as a sustained-load or workload acceptance test. Use the listed measurements to resolve device fit. |
| C17 | RATIFIED_FINDING, source identity limitation | Owner-ratified cross-venue public candle history reaches 2019-12-16 for 1h and 5m in the recorded scope. The specific venue is not named in the supplied evidence. | Do not claim a source venue or eligibility from this record. Cross-venue access remains subject to the owner’s restrictions. |
| C18 | RATIFIED_FINDING within the stated transfer scope | At 1h, the reported median basis is 0.56 bp and return-transfer correlation is 0.999755. The supplied conclusion supports research use at 1h and 4h but not at 5m. | Preserve source lineage. Gate the data away from Paper and Live unless the owner’s access and legal conditions are established. |
| C19 | RATIFIED_FINDING for one measured storage shape | One relational database file containing 3,500 candles × 14 intervals × 10 selected symbols occupied approximately 1.25 GB. The 10 symbols were chosen for diversity in that storage measurement and are not a universe recommendation or target. | Scale only after independently deriving the universe and confirming that the data shape matches. Any storage calculation must state the GB convention and account for data classes not in the measurement. |
| C20 | RATIFIED_FINDING, corrected units | A reported Deflated Sharpe Ratio near zero resulted from mixing annualized Sharpe units with a per-bar trial count. The supplied unit-consistent figure is approximately 1.5e-2 at N = 100; the original decision was unchanged. | Keep units consistent in any later use. This figure is not a new strategy result. |
| C21 | RATIFIED_FINDING, corrected calculation | The reported corrected MinTRL is 19.54 years. The prior 4.99-year figure was not reproducible from the stated PSR–MinTRL formula and appears to conflate MinTRL with MinBTL. | Keep MinTRL distinct from MinBTL and show the arithmetic if either is used. |
| C22 | RATIFIED_FINDING | When both a published panel value and an independent recomputation exist, `N_max_effective` is their minimum. If they differ by more than 2×, the recomputed value governs and the discrepancy must be recorded. | Recompute per cell before using a trial-budget figure; do not quote a table value alone. |
| C23 | RATIFIED_FINDING for the earlier analysis; figures remain PROVISIONAL pending recomputation | An earlier analysis placed the admissible 4h configuration count at roughly 10–20 after pooling; the 1d count was in the thousands before a sample-length correction. Pooling is limited by cross-cell dependence. | Do not use these figures as current hard ceilings or design justification until the required per-cell recomputation is shown. |
| C24 | RATIFIED_FINDING, binding search restriction | A full permutation grid search is inadmissible at every timeframe of 12h or less. | Any proposed search procedure for those intervals must have explicit, bounded trials and selection controls. This finding does not select an optimizer. |
| C25 | OWNER_SUPPLIED_AUDIT_SUMMARY, not direct archive inspection | The archive summary reports 149 canonical records: 134 `LIVE_PASS`, 10 `LIVE_PARTIAL`, 3 `UNSUPPORTED_CONFIRMED`, and 2 `DOC_CONFLICT`. The counts reconcile: 134 + 10 = 144; 144 + 3 = 147; 147 + 2 = 149. The same summary says historical Open Interest remains unresolved, the authenticated read-only stage was not executed, offline integrity/regression gates reportedly passed, the full 544 × 14 census was not exhaustive, and 3d candles were unsupported in the tested paths. | The 149 records do not mean 149 passes. Treat this as the owner’s summary of an archive, not as an archive personally inspected here. Preserve every listed limitation. |
| C26 | UNRESOLVED | Historical Open Interest remains unresolved in the supplied archive summary. | Do not make a critical feature depend on historical Open Interest without a resolution or explicit fallback. | |

### Evidence consequences for subsequent design work

- No `SOURCE_VERIFIED` claim is made in this part. The source facts are either owner-supplied findings, owner attestations, or unresolved items.
- C23’s earlier trial-count figures cannot justify a search budget until recomputed per cell.
- C9 does not establish current liquidity for a particular instrument, and C8 is not a reproducible capacity measure.
- C17 and C18 do not discharge the owner’s cross-venue access or legal conditions.
- C14’s device specifications and C16’s battery observation do not establish the POCO X6’s sustained workload fit.
- C25 is an owner-supplied archive summary. Its arithmetic reconciles, while the stated partial, unsupported, conflicted, and unexecuted records remain material limitations.

## Artifact registry update

| Artifact ID | Artifact name | Phase produced | Message reference | Status | Description |
|---|---|---:|---|---|---|
| ART-01 | Capability and boundary inventory | Part 1 | Part 1/10, §1 | DELIVERED | Records observable tools, access, authorization, and capability unknowns. |
| ART-02 | Pre-research design checkpoint | Part 1 | Part 1/10, §2 | DELIVERED | Preserves the initial frame before external research; exact date remains unresolved. |
| ART-03 | Dependency plan and delivery plan | Part 1 | Part 1/10, §§3 and opening | DELIVERED | Records the dependency-derived work order and planned message boundaries. |
| ART-04 | Requirements register and evidence ledger | Part 2 | Part 2/10, register and ledger above | DELIVERED | Defines 29 requirements and records C1–C26 with their supplied status and limits. |
| ART-05 | Candidate comparison and topology enumeration | Part 3 | Planned | DEFERRED | Criteria-first comparison and deployment candidates; depends on the requirements register. |
| ART-06 | Universe and data design | Part 4 | Planned | DEFERRED | Derived symbol/timeframe procedure, data decisions, and storage treatment. |
| ART-07 | Statistical and parameter-governance design | Part 5 | Planned | DEFERRED | Trial control, validation method, parameter governance, and parametric risk examples. |
| ART-08 | Component and end-to-end architecture | Part 6 | Planned | DEFERRED | Component responsibilities, state ownership, interfaces, and system flow. |
| ART-09 | Risk, execution, and Telegram contract | Part 7 | Planned | DEFERRED | Veto and recovery behavior, order state machine, and operator command semantics. |
| ART-10 | Deployment and operations design | Part 8 | Planned | DEFERRED | Deployment-envelope analysis, device measurement plan, security, resilience, and recovery. |
| ART-11 | Phases, verification, and adversarial findings | Part 9 | Planned | DEFERRED | Risk-derived phases, implementation dependency order, verification matrix, and design review. |
| ART-12 | Final acceptance and completeness record | Part 10 | Planned | DEFERRED | Overall status, checklist audit, completeness declaration, and individual self-verification entries. |

Artifact IDs are defined in this registry. `DEFERRED` means the artifact has not been delivered; it does not indicate completion or verification.

## Part 2 completeness declaration

**Part 2/10 is complete for its declared scope.** Content deferred: none within the scope of the requirements register and evidence ledger. The register contains 29 requirements, R-001 through R-029, with no gaps or extra rows. The verification matrix is not part of this delivery; its required one-to-one row count is 29.

- **Status:** Part 2 delivered; overall engagement remains in progress.
- **Evidence pointer:** This message, “Single requirements register,” “Evidence ledger,” and “Artifact registry update.”
- **Known limitations:** The original PDF and raw archive were not inspected; external sources were not accessed; no code, backtest, exchange call, or device test was run. Risk limits, cross-venue eligibility, device workload fit, and exchange-retention details remain unresolved as recorded.
- **Next logical action:** Deliver Part 3/10, comparing credible architecture and deployment candidates against declared criteria.
- **Overall completeness:** Not yet declared. The final declaration remains scheduled for Part 10/10 after the remaining artifacts and checks.


وضعیت: بخش ۳ از ۱۰. بخش ۲ ثبت کرد ۲۹ الزام ואת מצב شواهد مالک را. این بخش گزینه‌های معماری و استقرار را با معیارهای ازپیش‌اعلام‌شده مقایسه می‌کند؛ هیچ گزینه‌ای به‌عنوان راهبرد سودآور یا آمادهٔ اجرا معرفی نمی‌شود. بخش ۴ به اشتقاق جهان نمادها، تایم‌فریم‌ها و داده می‌پردازد.

# Part 3/10 — Candidate Comparison and Deployment-Topology Enumeration

**This part continues from Part 2/10**, which delivered the single requirements register and evidence ledger. **This part covers** comparison criteria, strategy and process-architecture candidates, and deployment topology classes. **Part 4/10 will cover** the derived market universe, data inclusion decisions, lineage and quality rules, and storage derivation.

## 1. Decision boundary and evidence status

The project brief supplies owner-attested device information and owner-ratified exchange and research findings, but no raw archive, current external source, implementation, backtest, workload measurement, or independent reviewer was available in this engagement. No quantitative strategy comparison or device-fit result can therefore be claimed.

The choices below are **DESIGN_JUDGMENT**: they are reasoned proposals based on requirements R-001 through R-029 and the owner-supplied findings in Part 2. Candidate strategy performance and deployment fit remain **NOT TESTED** or **PROVISIONAL**, as specified. No option receives a performance-based acceptance.

No new owner-level decision requiring a pause was found. The pending risk boundary in R-007 and cross-venue eligibility in R-012 were already declared by the owner. Technical choices remain delegated under R-024, so the work continues without asking the owner to select an algorithm, model class, process topology, or technology.

## 2. Comparison criteria declared before candidate evaluation

Hard constraints are pass/fail gates; they are not tradeable score factors. A candidate that cannot preserve a required safety invariant is ineligible regardless of its potential return.

For candidates that can be designed to satisfy the hard gates, the following criteria apply:

| Criterion | How it is assessed | Why it matters |
|---|---|---|
| Causality and data provenance | Can each decision use only data available at its decision time, with source and timestamp lineage preserved? | R-005 and R-011 require correct timestamps, point-in-time validity, and traceable inputs. |
| Risk-control separation | Can the signal or optimizer request an action without authorizing it, and can an independent risk authority veto it? | R-006, R-015, and R-016 require risk controls that forecasts, configuration, retries, and Telegram cannot bypass. |
| Research burden | How many data dependencies, parameter choices, symbol interactions, and evaluated configurations are needed? | R-013 limits search and requires credible controls against selection bias. |
| Execution realism | Can the candidate be evaluated with fees, spread, slippage, funding, order ambiguity, and fills represented? | R-014 and R-017 prohibit treating a paper signal or gross return as realized net performance. |
| Resource envelope | What data volume, computation, persistent state, and latency does the candidate require? | R-009 and R-019 require universe and deployment choices to fit measured or bounded resources. |
| Auditability and operational burden | Can an operator or reviewer reconstruct the signal, veto, configuration, order state, and recovery decision? | R-004, R-021, R-022, and R-026 require auditable control and recovery. |
| Reversibility | What rework or loss would follow if the decision changes after research, state persistence, or deployment? | R-029 and the decision-record rule in §2.1.4 require explicit treatment of reversal cost. |

These are comparison criteria, not measured scores. No weighted aggregate is calculated because no evidence justifies weights or a numerical ranking.

**Status:** Criteria are declared for this comparison; none of the candidate strategies has been tested against them.  
**Evidence pointer:** Owner brief §§2.1.3–2.1.4 and 3.1; requirements R-005, R-006, R-009, R-011, R-013–R-019, R-021–R-022, and R-026.  
**Consequence:** Later candidate selection must use the same criteria and distinguish observed results from design judgments.

## 3. Strategy and control candidates

### 3.1 Candidate catalog

The identifiers below are defined here and may be used later only with the meanings in this catalog.

| Identifier | Candidate | Full definition and scope |
|---|---|---|
| **SC-00** | No-trade and randomized-entry controls | A no-trade run checks that the accounting path records zero positions and does not invent trading P&L. A randomized-entry control uses a predeclared randomization procedure and the same eligible symbols, exposure constraints, holding rules, and cost model as the candidate being evaluated. It is a negative control for leakage and selection behavior, not a claim that random returns must equal zero in every sample. |
| **SC-01** | Single-timeframe causal range-breakout candidate | A rule-based directional signal using completed bars from one selected interval per instrument. For a long signal at bar close \(t\), the close must exceed a range computed only from bars preceding \(t\); for a short signal, it must fall below the corresponding preceding range. The signal is emitted after the bar is available, not filled at that same bar’s close. A volatility-derived stop distance and a maximum holding-duration policy are candidate exit controls; their parameters and the operational duration remain to be derived and tested. The signal creates an intent only; the risk authority and order pathway separately determine whether any order may be submitted. |
| **SC-02** | Single-timeframe mean-reversion candidate | A rule-based signal using a deviation of the current completed close from a trailing reference level computed from earlier completed bars. It would enter only under a predeclared deviation rule and exit at a predeclared reversion, stop, or duration condition. It requires tests of its behavior under persistent directional movement and realistic execution costs; no favorable performance is assumed. |
| **SC-03** | Cross-sectional ranking candidate | A portfolio-level rule ranks an eligible, point-in-time set of symbols using a predeclared trailing return or other causal price feature, then requests positions under separate exposure and risk controls. It requires synchronized and lineage-preserving data across the admitted universe and explicit handling of correlated symbol exposures. The eligible universe and its statistical budget are not yet derived. |
| **SC-04** | Supervised forecasting candidate | An offline-trained model estimates a defined forward outcome from causal, versioned inputs. Its forecast is not an order or risk approval. Training, validation, test boundaries, model selection, promotion, retirement, and any recalibration must be governed separately. No online self-modification is implied by this candidate. |

### 3.2 Comparative assessment

The qualitative assessments below are **DESIGN_JUDGMENT**, not empirical performance findings.

| Candidate | Data and causality burden | Research and selection burden | Execution and risk concerns | Resource and audit assessment | Current disposition |
|---|---|---|---|---|---|
| **SC-00** | Requires the same data-quality controls as the strategy under test, except that the no-trade path does not need a signal input. The randomized control must use a defined seed or reproducible randomization record. | No strategy parameters are optimized by the no-trade control. The randomized control still requires a documented generator and must be accounted for when interpreting selection results. | No-trade checks accounting, not trade feasibility. Randomized entries must receive the same risk vetoes, cost model, and execution assumptions as the candidate. | Low signal complexity; useful for checking that the evaluation pipeline does not manufacture performance or bypass cost accounting. | **Retain as a control, not as a trading strategy. NOT TESTED.** Evidence: R-013 and the owner brief §8.2. Consequence: the controls can reveal defects, but do not establish that any candidate is profitable. |
| **SC-01** | Can be expressed using completed candle fields if their precise schema and semantics are verified. It does not require historical Open Interest, cross-venue data, the disputed `markPrice`/`klines.change` interpretation, or non-reproducible order-book depth. | A small, predeclared set of rule parameters can be tested, but its admissible size must follow the per-cell trial-budget calculation required by R-013. No parameter values or trial count are selected here. | Breakout signals can be affected by gaps, delayed data, costs, and stop fills. A stop is an intended exit, not a guaranteed realized-loss cap. The signal cannot authorize a trade or set a hard risk limit. | A single-instrument rule is straightforward to log and replay. Its exact storage, compute, and latency needs depend on the subsequently derived universe and interval. | **Select as the first falsifiable candidate for later testing, not as a production strategy. NOT TESTED.** Rationale: it offers a concrete causal hypothesis that can be expressed with a limited input set and a small parameterization, while avoiding dependence on unresolved evidence. This does not imply superior returns. |
| **SC-02** | Also can use completed candle data, subject to the same schema and availability checks. | Has its own reference-window, entry, exit, and risk-related parameter choices; these cannot be mixed into an unlimited search with SC-01. | Its behavior must be tested under regimes where price continues away from the reference level; no statistical or fill result is available here. | Similar basic data footprint to SC-01, with separate decision rules and validation records. | **Retain as a credible alternative for later comparison. NOT TESTED.** The supplied evidence does not establish whether it is better or worse than SC-01; any comparison must be predeclared and fit within the recomputed trial budget. |
| **SC-03** | Requires point-in-time universe membership, synchronized cross-symbol observations, and source lineage for every contributing instrument. | Uses a portfolio-level candidate set and cross-symbol interactions; dependence and trial accounting cannot be inferred from a count of symbols alone. | A position ranking is not exposure control; concentration and aggregate risk still require an independent portfolio/risk layer. | Data and audit costs grow with the admitted universe and its synchronization requirements. Exact costs are unresolved pending R-009 and R-019. | **Do not use as the first validation candidate. NOT TESTED.** Positive rationale: the required point-in-time universe and cross-symbol dependence have not yet been established, and this candidate adds those dependencies before an incremental benefit has been measured. It remains eligible for later consideration if the derived universe and trial budget support it. |
| **SC-04** | Requires causal features, a precisely defined prediction target, and reliable train/validation/test separation. | Model capacity, feature selection, retraining decisions, and repeated evaluations increase governance and selection-control requirements. The admissible search count must still be recomputed per cell. | A forecast cannot approve an order, alter risk limits, or silently update itself in Live operation. Model uncertainty, drift, and stale model state need explicit handling. | Training and inference fit are unmeasured; model artifacts, versioning, rollback, and data boundaries add operational work. | **Do not use as the first validation candidate. NOT TESTED.** Positive rationale: its incremental value over a lower-dimensional candidate is not established, while its additional validation and governance requirements are material. This is not a claim that machine learning cannot work. |

**Candidate decision:** SC-01 is the initial **research candidate**, with SC-00 retained as controls and SC-02 retained as an alternative. This decision selects what to test first; it does not select what to trade. The reason is limited-input, causal testability under the current evidence constraints, not an assertion of strategy quality.

**Status:** Candidate selection is a design proposal; all strategy performance is **NOT TESTED**.  
**Evidence pointer:** Owner brief §§5.1 C13, 5.4 C22–C24, 5.5 C26, 8.0–8.4; requirements R-009, R-011, R-013, R-014, and R-015.  
**Consequence:** No candidate can be promoted on this comparison. A later statistical design must define the exact data, parameter set, effective sample size, assumptions, stopping rule, selection-bias controls, promotion criteria, and rollback criteria.

### 3.3 First-candidate behavior and limits

The SC-01 rule is specified only to make a research hypothesis falsifiable:

1. Accept a bar only after its close is available and its source, timestamp, interval, and quality checks pass.
2. Compute the candidate’s trailing range from earlier completed bars. The current bar cannot contribute to its own preceding-range threshold.
3. Evaluate a directional signal after the bar becomes available. The simulator must use a subsequent executable price or an explicit execution model; it must not assume a fill at the just-completed close.
4. Send a signal intent to portfolio construction and the independent risk authority. The signal itself has no permission to set quantity, leverage, or a risk limit.
5. A candidate stop distance may be based on a causal volatility estimate. The multiplier and estimator require an explicit parameter record and a bounded evaluation plan before testing.
6. Exit behavior must include an independently defined protective exit and an intraday maximum-duration rule. The latter remains unselected until the strategy, market behavior, funding, costs, and validation support it.
7. Treat a stop as an intended exit. The realized result can differ because of gaps, fill uncertainty, fees, slippage, funding, and contract mechanics.

**Not established:** Exact candle field meanings and endpoint semantics for the eventual data path; admissible symbols and intervals; stop parameters; duration policy; cost model; strategy performance; and trial count.

**Resolution method:** Part 4 derives the data and universe requirements. Part 5 specifies the statistical protocol, parameter governance, cost treatment, and parametric risk examples. No external exchange source or backtest has been used here.

## 4. Process-topology comparison

This choice concerns how logical work is deployed as processes. It does **not** choose whether those processes run on the POCO X6 or another host.

### 4.1 Process-topology catalog

| Identifier | Process topology | Definition |
|---|---|---|
| **PT-01** | Single undivided script | One process and an undifferentiated execution path handle data, signals, risk, orders, state, and operator commands without enforced internal responsibility boundaries. |
| **PT-02** | Modular monolith | One deployable process contains explicit logical modules and contracts for data, signal generation, portfolio/risk authority, order handling, persistent state, and Telegram control. A single process does not mean shared permission to execute: the order submission capability is restricted to the order pathway, which must require a valid risk authorization. |
| **PT-03** | Distributed services | Responsibilities are separate processes or services communicating across process or host boundaries, with independently managed state and explicit network protocols. |

### 4.2 Comparison

| Criterion | PT-01 — Single script | PT-02 — Modular monolith | PT-03 — Distributed services |
|---|---|---|---|
| State consistency | Shared mutable logic can make the authority for position, order, and risk state difficult to inspect. | A single deployment and explicit state ownership make transaction and replay boundaries easier to define, subject to the eventual persistence design. | Can isolate ownership, but replication, network partitions, ordering, and reconciliation add failure cases that must be specified and tested. |
| Risk authority | A direct, loosely separated code path gives weak architectural evidence that signals or configuration cannot bypass risk. | Distinct module contracts and restricted order-submission capability can enforce a single authorization path; property tests must show that no other module can submit a risk-increasing action. | A separate risk service can add a process boundary, but only if the order service rejects requests without valid risk authorization and fails closed when that service is unavailable. |
| Failure containment | A fault affects the whole undifferentiated process; module-level isolation is difficult to inspect. | Module failures can be handled by explicit contracts, but the process remains a shared failure domain. | A process can fail independently, but communication and partial service failure create additional unsafe states to control. |
| Operational burden | Lowest initial deployment complexity; the absence of enforceable boundaries creates later testing and change risks. | Keeps deployment count low while preserving test seams and responsibility boundaries required by R-024. | Requires service discovery or fixed endpoints, authentication between services, deployment coordination, network monitoring, and distributed recovery. |
| Resource and latency | No separate-process overhead, but no workload is measured. | No inter-service network hop for internal decisions; actual performance remains unmeasured. | Additional process and communication overhead; independent scaling could be useful only if workload or failure-isolation measurements justify it. |
| Current assessment | **Not selected.** It weakens inspectability of the independent risk and order boundary required by R-016 and R-017. | **Provisional working candidate.** It supplies explicit logical boundaries without requiring unmeasured distributed operation. | **Retained as a conditional alternative.** No measured scaling or isolation need presently justifies its additional network and recovery paths. |

### 4.3 Working process-architecture decision

**DESIGN_JUDGMENT:** Use PT-02, the modular monolith, as the working process architecture for subsequent design sections. This is a process-boundary decision only. It does not select a device, cloud provider, hosting location, language, database, or final component count.

The positive rationale is that the requirements require inspectable separation of data, signal generation, risk authority, orders, persistent state, and Telegram commands, while the available evidence establishes no independent scaling requirement or measured workload that would justify distributed services. PT-02 retains test seams and one deployment boundary without introducing cross-service state synchronization before a need for that complexity has been demonstrated.

The order pathway must be the only component with the capability to submit exchange orders. It must refuse any risk-increasing request lacking a valid approval from the risk authority. The signal and optimizer paths must not hold exchange credentials. The shared-process failure boundary remains a limitation: process compromise or process-wide failure can affect every module. The recovery design must therefore fail closed and reconcile before resuming. If later threat analysis or measurements show that process isolation is necessary, PT-03 must be evaluated before changing the architecture.

- **Status:** Provisional design decision; implementation and isolation tests are **NOT TESTED**.
- **Evidence pointer:** Owner brief §§9.1–9.3 and 9.6–9.8; requirements R-015–R-018 and R-024.
- **Reversibility:** **COSTLY_REVERSIBLE** once persistent schemas or interfaces are used; no implementation or persisted state was created in this engagement.
- **Consequence:** The next design sections can specify logical boundaries against a single-deployment baseline, while explicitly retaining a service split as a conditional alternative.

## 5. Workload envelope before deployment matching

D15 requires the workload envelope to precede device matching. The specific numeric envelope cannot yet be computed because the eligible universe, data shape, trial count, measured latency needs, and sustained device behavior are unavailable. The following quantities define the envelope to be completed; they are formulas and measurement targets, not claims of measured capacity.

### 5.1 Compute

Let:

- \(N_s\) = admitted instruments;
- \(N_t\) = admitted intervals;
- \(N_b\) = stored or simulated bars per instrument and interval;
- \(C_b\) = processing work per bar for a single candidate;
- \(N_c\) = evaluated candidate configurations under the recomputed trial budget.

A first-order historical evaluation workload is:

\[
W_{\mathrm{history}} =
N_s \times N_t \times N_b \times C_b \times N_c
\]

This expression does not establish a runtime. The actual \(N_s\), \(N_t\), \(N_b\), \(C_b\), and \(N_c\) must be derived or measured. In particular, \(N_c\) cannot be adopted from the provisional C23 counts without the per-cell recomputation required by R-013.

The live signal path is event-driven by eligible data availability. Its per-event work must be measured under the derived universe and workload; no sustained throughput result is available.

### 5.2 Storage

Let \(B_r\) denote bytes per stored record for the actual chosen schema. A simple raw-data estimate is:

\[
S_{\mathrm{raw}} =
N_s \times N_t \times N_b \times B_r
\]

Indexes, transaction logs, checkpoints, audit records, model artifacts, backups, and filesystem overhead must be measured separately. The C19 storage ratio may be scaled only if the proposed schema matches the measured candle-only shape; it cannot be applied unchanged to added funding, order-book, or cross-venue data.

**Status:** Numeric storage demand is **NOT TESTED**; the data shape is not yet selected.  
**Evidence pointer:** Owner brief §5.3 C19 and §10.3; R-009 and R-019.  
**Consequence:** The 56 GB free-storage snapshot cannot be treated as a capacity guarantee, and no topology receives a storage-fit PASS.

### 5.3 Latency, availability, and recovery

For a completed-bar candidate, the relevant operational path includes:

\[
L_{\mathrm{decision}} =
L_{\mathrm{data\ availability}} +
L_{\mathrm{signal}} +
L_{\mathrm{risk}} +
L_{\mathrm{submission}}
\]

Each term must be measured using monotonic elapsed-time clocks. UTC wall time remains authoritative for event and audit instants. The maximum acceptable end-to-end delay must be derived from signal freshness, the intended holding behavior, and verified venue behavior; this engagement has not established a numeric threshold.

A safe recovery criterion is state-based: new risk-increasing actions resume only after stored state is integrity-checked and the internal ledger reconciles with the exchange state. A fixed elapsed-time condition cannot substitute for that reconciliation. The owner supplied no numerical availability or recovery-time target, and this design does not invent one.

**Status:** Numeric latency, availability, and recovery targets are **UNRESOLVED** pending strategy, venue, and workload measurements.  
**Resolution method:** Specify the target workload, measure end-to-end times and outages on the selected host, and require reconciliation before resumption.  
**Consequence:** No topology can be declared operationally ready based on this part.

## 6. Deployment-topology catalog and envelope fit

### 6.1 Catalog definitions

These identifiers define the material placement classes considered. “Phone” means the POCO X6. “External host” means a future owner-authorized computing resource whose availability, location, service terms, and cost have not been established. A Telegram bot or relay is an internal deployment component; the Telegram interface remains the owner’s sole operator surface.

| Identifier | Topology | Workload placement |
|---|---|---|
| **TP-01** | Device-only | Development/build, historical research, any training or calibration that is retained, Paper runtime, Live runtime, Telegram bot process, and authoritative state run on the POCO X6. The external Toobit and Telegram APIs remain external dependencies. |
| **TP-02** | Device execution with one-off remote batch work | The phone owns Paper/Live runtime and execution state. A separately authorized external host runs only selected, finite historical batch workloads such as a backtest. The batch worker receives no Live credential and cannot submit orders. |
| **TP-03** | Device through Paper; external Live runtime | Development, historical research, calibration, and Paper runtime stay on the phone. Live risk/order state and execution run on an external host. A single Telegram control point must route commands to the active operating mode; the command path between the control point and the phone requires authenticated, fail-closed behavior. |
| **TP-04** | Device development/research; external Paper and Live runtime | Development and some or all historical research remain on the phone. Continuous Paper and Live runtime, their authoritative operational state, and the Telegram bot process run on an external host. The phone is an operator client and development device, not the authority for live state. |
| **TP-05** | External research batch; device Paper/Live runtime | The phone retains Paper/Live operation and authoritative execution state. An external host runs ongoing or repeated historical research, calibration, or training, subject to explicit dataset lineage and credential separation. |
| **TP-06** | Fully remote single deployment | Development, research, any retained training/calibration, Paper, Live, Telegram bot process, state, and recovery services run on one external host or a single deployment unit. The phone is only an operator client or development aid. |
| **TP-07** | Split services with remote execution authority and optional relay | Data, research, Telegram ingress, and execution may occupy different phone or external processes. The remote risk/order authority owns the final authorization and Live execution state. Any edge relay carries messages or data only; it cannot clear vetoes, create risk approval, or claim an uncertain exchange outcome is resolved. |

The catalog groups provider, operating-system, and process-count variations under the same placement class when those variations do not materially change phase placement or the authority for Live state. The split-service case is separately catalogued because its message and state paths cross process or host boundaries.

### 6.2 Fit assessment before compromise

No measured POCO X6 workload capacity, external-host access, service quote, network envelope, or end-to-end runtime test is available. Therefore **every topology below is PROVISIONAL**, not PASS or FAIL. This is a truthful envelope-fit status, not a readiness assessment.

| Topology | Envelope-fit status | Specific unresolved gap | Required measurement or resolution | Consequence while unresolved |
|---|---|---|---|---|
| **TP-01** | **PROVISIONAL** | Sustained compute, thermal behavior, memory pressure, Android background survival, storage headroom, network stability, and process recovery have not been measured for the candidate workload. | Run representative workload and process-death/reboot tests on the specified handset, including the derived data volume and runtime duration; remeasure free storage. | The phone cannot be accepted as the continuous Live host on specification or charging observations alone. |
| **TP-02** | **PROVISIONAL** | The phone runtime remains unmeasured; no external batch host, cost, dataset-transfer path, licensing status, or batch isolation has been established. | Measure phone runtime separately; obtain an authorized host and scope-specific cost/access details; verify that the batch worker has no Live credential or order capability. | The external worker cannot be treated as available or secure, and the phone’s runtime fit remains unknown. |
| **TP-03** | **PROVISIONAL** | Neither phone suitability for the non-Live workload nor external Live-host availability is established. The cross-host control path and state boundaries have not been tested. | Test both workloads separately; specify and fault-test command routing, independent Live risk state, and reconciliation after link loss. | No mode can be claimed ready, and a failed bridge must leave Live controls and risk logic intact. |
| **TP-04** | **PROVISIONAL** | External host location, owner access, cost, service conditions, API reachability, key handling, recovery, and actual Paper/Live workload are unknown; phone research fit is also unmeasured. | Establish an authorized host and measure representative workloads, storage, network latency, recovery, and security boundaries. | Remote Paper/Live cannot be assumed operationally available or lawful for the owner merely because it is technically possible. |
| **TP-05** | **PROVISIONAL** | Phone execution fit remains unmeasured; repeated remote research requires an eligible host, controlled data movement, and lineage preservation. | Run the phone workload test and verify the external batch pipeline, data versions, source tags, and credential separation. | Neither recurring batch capacity nor handset Live feasibility is established. |
| **TP-06** | **PROVISIONAL** | No external host, budget, provider scope, operational owner, region, or security configuration is established. | Obtain an authorized host and measure the complete workload, service failure behavior, restoration, and ongoing cost in the provider’s currency. | A cloud topology cannot be represented as provisioned, costed, or ready. |
| **TP-07** | **PROVISIONAL** | The topology introduces additional network, trust, availability, state-ownership, and relay-failure paths; no positive need for an edge relay or distributed service has yet been established. | Specify each service boundary and authority; measure each path; test relay loss, service partition, stale messages, replay, and reconciliation. | The additional components cannot be credited with improved reliability before tests; the relay cannot participate in safety authority. |

### 6.3 D15 status and compromise decision

D15’s envelope-first sequence is **not complete**:

1. **Envelope derivation:** The workload dimensions and formulas are defined above, but their numeric inputs remain pending the derived universe, selected data shape, trial plan, and measured latency needs.
2. **POCO X6 capability measurement:** **NOT TESTED.** The owner-supplied specifications and prior charging observation do not establish sustained workload fit.
3. **Topology matching:** **PROVISIONAL.** Every listed topology has a specific unresolved fit gap; none has a PASS.
4. **Compromise order:** **Not applied.** The phone has not been shown to fail the required envelope, and no topology has been selected. No phone-first assumption or cloud escalation is being made.

No later part may introduce a new deployment-topology class without first adding it to the topology catalog above and recording its envelope-fit status and specific gap. A narrower phase move, if eventually selected, must be explicitly identified as a D15 sub-step and must name the trigger for moving to the fuller compromise-order item.

The topology comparison does not establish that a cloud host is available to this owner. It also does not establish that the phone is unsuitable. Those claims require measurements or authorization.

## 7. Decision record

| Decision | Current disposition and positive rationale | Status and evidence | Reversibility | Consequence and change trigger |
|---|---|---|---|---|
| First strategy architecture to test | Select SC-01 as the first falsifiable candidate because it can be stated using completed single-instrument bars and a limited parameter set, without depending on currently unresolved cross-venue, historical Open Interest, or disputed mark-price semantics. This is a research-order decision, not a return forecast. | **NOT TESTED.** Evidence: R-011 and R-013; owner brief §§5.1, 5.4, 8.0–8.4. | **REVERSIBLE** before implementation or persistent experiment artifacts. | Reject or revise it if the predeclared tests fail, if data semantics cannot be verified, or if another candidate shows incremental net value within the recomputed trial budget. |
| Initial adaptation policy | Do not include autonomous online learning in the initial candidate. The candidate can be evaluated as a frozen, registered rule; adaptation would add a recalibration and selection path whose incremental value is not established. | **NOT TESTED.** Evidence: R-013 and R-015; owner brief §§3.1 item 12, 8.4–8.6, and 9.10. | **REVERSIBLE** before a production lifecycle or persistent model registry is built. | Reconsider only after a bounded offline evaluation shows incremental value and the full parameter, promotion, rollback, and contamination controls are specified. |
| Working process architecture | Use PT-02 as a design baseline: explicit logical authority boundaries in one deployable process, with one restricted order pathway. It supports the required separation while avoiding unmeasured service-to-service state paths. | **PROVISIONAL; NOT IMPLEMENTED OR TESTED.** Evidence: R-016–R-018 and R-024; owner brief §§9.1–9.3 and 9.6–9.8. | **COSTLY_REVERSIBLE** after interfaces or persistent state are adopted; no such state was created here. | Reconsider PT-03 if the threat model requires process isolation or measured workload and recovery requirements demonstrate a need. |
| Deployment topology | Select none yet. The fit comparison is necessarily provisional because the required workload and both handset and external-host capacities are unmeasured or unavailable. | **PROVISIONAL / NOT TESTED.** Evidence: R-019; owner brief §§3.1 item 8, 5.2 C14–C16, and 10.3. | A choice made before persistence is reversible; moving authoritative state after operation is **COSTLY_REVERSIBLE**. | Complete the workload derivation, measure or bound candidate hosts, then apply D15’s ordered compromise rules. No owner question is needed to make that technical comparison. |
| Numerical risk policy | Select none. The risk boundary remains the owner’s declared pending decision; all dependent work remains parametric. | **UNRESOLVED.** Evidence: R-007 and owner brief §§2, 3.3. | Owner policy is not a model-selected parameter. | Live readiness and final sizing remain blocked until the owner establishes the required hard limits. |

## 8. Part 3 completeness and artifact registry

**Part 3/10 is complete for its declared scope.** Content deferred from this part: the derived universe and data design (Part 4), statistical and risk calculations (Part 5), detailed interfaces and system flow (Part 6), order and Telegram contracts (Part 7), full deployment measurements and operations design (Part 8), operating phases and validation matrix (Part 9), and final acceptance records (Part 10). Those are separate artifacts in the declared delivery plan.

| Artifact ID | Artifact name | Phase produced | Message reference | Status | Description |
|---|---|---:|---|---|---|
| ART-01 | Capability and boundary inventory | Part 1 | Part 1/10, §1 | DELIVERED | Records observable tools, access, authorization, and capability unknowns. |
| ART-02 | Pre-research design checkpoint | Part 1 | Part 1/10, §2 | DELIVERED | Preserves the initial frame before external research; exact date remains unresolved. |
| ART-03 | Dependency plan and delivery plan | Part 1 | Part 1/10, §§3 and opening | DELIVERED | Records the dependency-derived work order and planned message boundaries. |
| ART-04 | Requirements register and evidence ledger | Part 2 | Part 2/10, register and ledger | DELIVERED | Defines 29 requirements and records the owner-supplied C1–C26 evidence status. |
| ART-05 | Candidate comparison and topology enumeration | Part 3 | Part 3/10, §§2–7 | DELIVERED | Declares comparison criteria, evaluates strategy and process candidates, defines deployment topology classes, and records provisional envelope fit. |
| ART-06 | Universe and data design | Part 4 | Planned | DEFERRED | Derived symbols and intervals, data-class decisions, lineage and quality rules, and storage derivation. |
| ART-07 | Statistical and parameter-governance design | Part 5 | Planned | DEFERRED | Trial control, statistical validation, parameter governance, and parametric risk examples. |
| ART-08 | Component and end-to-end architecture | Part 6 | Planned | DEFERRED | Component responsibilities, state ownership, interfaces, and end-to-end flow. |
| ART-09 | Risk, execution, and Telegram contract | Part 7 | Planned | DEFERRED | Veto and recovery behavior, order state machine, and command preconditions. |
| ART-10 | Deployment and operations design | Part 8 | Planned | DEFERRED | Envelope measurement plan, device fit, security, reliability, and recovery procedures. |
| ART-11 | Phases, verification, and adversarial findings | Part 9 | Planned | DEFERRED | Risk-derived phases, implementation dependency order, verification matrix, and adversarial review. |
| ART-12 | Final acceptance and completeness record | Part 10 | Planned | DEFERRED | Overall status, checklist audit, completeness declaration, and individual self-verification entries. |

### Part 3 status record

- **Status:** Delivered for the declared comparison and topology scope.
- **Evidence pointer:** This message, §§1–8; supporting owner-supplied evidence is identified in the cited sections of the brief and the Part 2 ledger.
- **Checks performed:** Criteria were stated before the comparisons; candidate and process alternatives were compared; topology classes were enumerated; D15 envelope gaps were recorded.
- **Checks not performed:** No external source inspection, device measurement, provider quote, code execution, backtest, exchange call, implementation test, or independent external review occurred.
- **Next logical action:** Deliver Part 4/10, deriving the symbol/timeframe universe and the data contracts without treating the capability ceiling or storage example as a target.
- **Overall completeness:** Not yet declared. The final completeness declaration remains scheduled for Part 10/10.


وضعیت: **بخش ۴ از ۱۰ — طراحی universe و داده، ART-06، تکمیل شد.** فهرست دقیق جاری قراردادهای دائمی Toobit و دادهٔ تاریخیِ تفکیک‌شده برای هر نماد و تایم‌فریم در دسترس نیست؛ بنابراین هیچ نمادی به‌عنوان پذیرفته‌شده معرفی نمی‌شود. آستانه‌های نقدشوندگی زیر محاسبات غربالگریِ طراحی‌اند، نه اندازه‌گیری ظرفیت یا مجوز معامله. هیچ بررسی بیرونی یا دسترسی به حساب و صرافی انجام نشده است. اعلام تکمیل کل کار برای بخش ۱۰ محفوظ است.

# Part 4/10 — Universe and Data Design (ART-06)

## 1. Scope, evidence status, and provisional outcome

This part derives a candidate universe and the data contract for **SC-01**, the single-timeframe range-breakout research candidate from Part 3. It does not establish that the strategy is profitable, that any instrument currently passes a screen, or that the resulting workload fits the POCO X6.

Evidence labels used below:

- **OWNER-SUPPLIED FINDING:** a finding or summary included in the supplied prompt, not independently verified here.
- **DERIVATION:** arithmetic or a rule derived from the stated inputs.
- **DESIGN JUDGMENT:** a proposed policy choice, not an observed market fact.
- **PROVISIONAL:** a choice to test, not an accepted production decision.
- **UNRESOLVED / BLOCKED:** evidence needed to determine the fact is unavailable.

**Provisional design outcome:**

1. Bound the candidate universe to **active Toobit-listed perpetual contracts**. For the initial sizing/data model, prioritize **linear USDT-margined perpetuals**; do not treat other contract types as eligible until their contract value, PnL, fees, and funding are modeled separately. This does not assert that any particular contract is currently listed.
2. Use **one completed 1-hour candle series** as the provisional baseline for SC-01. Do not add higher-timeframe filters or a second interval to the baseline.
3. Include a symbol only after it passes independently measured activity, depth, data-quality, contract-metadata, and research-coverage checks. **No actual symbol currently passes in this design record.**
4. Use Toobit-native data for Paper and Live. Any cross-venue data remains isolated to research and is gated by the owner’s legal, access, cost, licensing, and approval conditions.
5. Treat the reported candle limit as a request/depth observation—not proof of complete per-symbol history—and treat the phone fit as unmeasured.

## 2. Contract and timeframe derivation

### 2.1 Contract boundary

The system’s venue boundary is Toobit (A1). The candidate universe is therefore not “large-cap crypto,” a generic exchange list, or the ten-symbol storage illustration. It is a **time-stamped census of Toobit-listed perpetual contracts**, subject to the following contract-level checks:

- The contract is verified as a perpetual, not spot or a dated delivery future.
- Its settlement currency, multiplier, tick size, quantity increment, minimum order, price/quantity precision, and any applicable contract limits are known.
- The historical contract status and any listing, suspension, or delisting dates are recorded where available.
- For the initial linear-USDT baseline, contracts with different PnL or contract-value mechanics are not silently mixed into the same sizing equations.

Choosing linear USDT contracts first is a **DESIGN_JUDGMENT**, not a claim about Toobit’s current product inventory. Broadening to inverse or other contract types is credible, but requires separate arithmetic and verification. **Reversibility:** reversible before collection and implementation; more costly after contract-specific research, persistence, and sizing rules are built.

The exact current Toobit symbol list and the per-contract metadata were not supplied or inspected. Accordingly, the contract census is **UNRESOLVED**, and no contract identifiers are invented here.

### 2.2 Baseline timeframe

The reported capability ceiling (C1) is: **1m, 3m, 5m, 15m, 30m, 1h, 2h, 4h, 6h, 8h, 12h, 1d, 1w, and 1M**. This is a reported ceiling, not a requirement to use all intervals. The supplied evidence reports 3d unsupported; 3m and 8h were LIVE_PASS on tested paths. Those statements do not establish coverage for every symbol or current endpoint behavior.

| Interval or group | Part 4 status | Reason tied to SC-01 |
|---|---|---|
| 1m, 3m | Excluded from baseline | No demonstrated information need for this single-timeframe candidate; do not add more frequent bars without a separate hypothesis and cost/coverage evidence. |
| 5m | Excluded from baseline | C10 reports cost-per-volatility of 1.42 in its scope, and C18 does not support cross-venue transfer at 5m. This is not a universal result for every symbol, but it is adverse evidence for the initial baseline. |
| 15m | Not in baseline; possible separate challenger | C10 reports 0.82 in its scope and a “maker-only floor at 15m+.” This is not proof of positive expectancy, and it does not supply per-symbol historical depth. A 15m challenger would be a separate research cell, not an added filter. |
| 30m | Excluded from baseline | No incremental need established over the one-hour hypothesis; adding it would create another research cell without current depth evidence. |
| **1h** | **Provisional baseline** | SC-01 needs one causal, completed-bar interval. C18 reports cross-venue transfer evidence within its 1h scope; the 1h result reported median basis 0.56 bp and return-transfer correlation 0.999755. This does not replace Toobit execution data or prove a 1h cost ratio. |
| 2h, 6h, 8h, 12h | Excluded from baseline | No additional information need is established for the initial single-timeframe hypothesis. C1’s reported support does not make them necessary. |
| 4h | Credible later alternative, not baseline | C18 reports transfer evidence in its 4h scope. A 4h candidate would require a separate, predeclared test and recomputed per-cell trial budget; earlier counts in C23 remain provisional. |
| 1d, 1w, 1M | Excluded from the intraday baseline | No daily-or-longer regime filter is required by the selected first hypothesis. Adding one would introduce a cross-timeframe dependency that has not been justified or freshness-tested. |
| 3d | Excluded | Reported unsupported in C1/C25. |

The **1h selection is provisional**, not a measured claim that 1h has lower costs or better performance than every alternative. C10 supplies exact reported ratios for 5m and 15m, not a 1h ratio. The 1h cell must have its own cost-per-volatility and execution-cost evaluation. No maker fill, fee rebate, or passive-fill probability is assumed.

A one-hour signal bar is **not** a one-hour maximum holding period. The intraday operational definition and maximum holding duration remain to be derived from actual exits, funding, costs, risk, and validation (A6).

**Reversibility:** the 1h baseline is REVERSIBLE before confirmatory testing. If another interval is tested, register it as a separate cell rather than silently altering the baseline.

### 2.3 Trial-budget restriction

For this design, a research cell is at minimum **contract × timeframe × strategy specification**; any material change to fill model, data source, cost model, or validation protocol must be logged as a new trial or cell as appropriate.

- Recompute the effective trial budget independently for each cell.
- Apply C22: use `N_max_effective = min(published panel value, independently recomputed value)` when both exist; if they differ by more than 2×, the recomputed value governs and the discrepancy is recorded.
- Earlier C23 counts are provisional until that recomputation.
- **Do not run exhaustive full-grid search at any interval ≤12h.** C24 makes that inadmissible.
- If the recomputed budget is unavailable, a broad parameter search is not authorized. Use only a small, preregistered and theory-driven set for exploratory work; do not present the results as confirmatory.

The broadest capability ceiling must therefore not be mistaken for a proposed multi-interval dataset or optimizer grid.

## 3. Liquidity screen: calculation and limits

### 3.1 Inputs and their evidential limits

The supplied liquidity evidence is:

- **C9, OWNER-SUPPLIED FINDING:** a ratified snapshot reports median 24-hour notional around **498,844 USDT**, with **134 symbols at or above 10,000,000 USDT**. The older 515k/136 record was superseded.
- C9 is a snapshot, **not current per-symbol liquidity**. The exact symbols, timestamped per-symbol values, and precise window/measurement semantics are not available here.
- **C8, OWNER-SUPPLIED FINDING:** reported order-book depth is non-reproducible; one-sided/two-sided convention is ambiguous. The cited BTC values must not be used as capacity facts.
- **C6, OWNER-SUPPLIED FINDING:** taker fee is unresolved: 0.05% documented versus 0.06% observed. Use **0.06% per side provisionally** for cost feasibility until the discrepancy is resolved; this is not an independently verified current fee tier.
- **C7, OWNER-SUPPLIED FINDING:** a −30 bp funding clamp was observed; an alleged ±24 bp cap was refuted. Funding is a tail cost/risk, not a safe bound.
- **C10, OWNER-SUPPLIED FINDING:** the scoped cost-per-volatility results are 5m = 1.42 and 15m = 0.82, with the ratified finding “maker-only floor at 15m+” within that analysis’s scope. Do not extrapolate exact ratios to 1h or read a ratio below one as evidence of profitability.

### 3.2 Trade-notional formula

For an initial **linear USDT contract**, let:

- \(E\) = effective account equity in USDT;
- \(r\) = per-trade risk fraction, **OWNER_DECISION_PENDING**;
- \(d\) = strategy-derived fractional price distance to the planned adverse exit;
- \(f_e, f_x\) = entry and exit fee fractions;
- \(c_{\text{spread}}, c_{\text{impact}}, c_{\text{funding}}, c_{\text{other}}\) = adverse fractional costs for the full trade.

A first-order risk-sized gross entry notional is:

\[
N_{\text{risk}}
\approx
\frac{E r}
{d + f_e + f_x + c_{\text{spread}} + c_{\text{impact}} + c_{\text{funding}} + c_{\text{other}}}.
\]

For a linear contract, quantity must then be derived using its verified contract multiplier \(M\) and price \(P\), for example \(q=N/(P M)\) under the contract’s documented quantity convention. Neither \(r\), \(d\), all costs, nor the per-symbol contract specifications have been determined. Thus **actual order size cannot yet be computed**. Margin, permitted leverage, maintenance requirements, and liquidation constraints are separate limits; this formula does not override them.

For an illustrative two-taker-leg cost only, assuming C6’s 0.06% is a **per-side** rate:

\[
c_{\text{taker,RT}}=0.0006+0.0006=0.0012=12\text{ bp},
\qquad
C_{\text{taker,RT}}\approx0.0012N.
\]

| Illustrative gross notional \(N\) | Two-taker-leg fee estimate |
|---:|---:|
| 200 USDT | 0.24 USDT |
| 500 USDT | 0.60 USDT |

These are fee arithmetic only; they exclude spread, slippage, funding, and other costs. They are **not** selected risk limits or trades.

To make the liquidity arithmetic concrete, use \(N=E\times1.0\) **only as a 1× notional-normalization scenario**. It is not a leverage recommendation, a system leverage limit, or the actual risk-based trade size. The owner’s approximately 200 USDT and below-500-USDT planning scale is illustrative (A11), not current equity. Actual leveraged notional could exceed these examples and must be screened at its actual size.

### 3.3 Rolling-volume inequality and solved threshold

Define:

- \(V_{24}\) = verified Toobit quote-notional turnover over a consistently defined, timestamped 24-hour window;
- \(N_e\), \(N_x\) = gross entry and exit notionals;
- \(\alpha\) = maximum permitted **round-trip** notional as a fraction of \(V_{24}\).

A single entry and comparable exit conservatively consume approximately \(N_e+N_x\approx2N\) of turnover. Use the screen:

\[
\frac{N_e+N_x}{V_{24}}\leq\alpha
\quad\Longrightarrow\quad
V_{24}\geq\frac{N_e+N_x}{\alpha}
\approx\frac{2N}{\alpha}.
\]

**DESIGN_JUDGMENT:** use \(\alpha=0.0001\), or **0.01% (1 bp) of reported 24-hour turnover**, as the initial screening fraction. It is a conservative *pre-filter heuristic* for a small-account round trip, not a measured price-impact law or a guarantee of execution. Do not relax it merely to obtain more symbols; a change should follow a measured slippage study and be recorded as a reversible design change.

| 1× illustrative entry notional | Approx. round trip \(2N\) | Solved \(V_{24}\) minimum at \(\alpha=0.01\%\) |
|---:|---:|---:|
| 200 USDT | 400 USDT | **4,000,000 USDT** |
| 500 USDT | 1,000 USDT | **10,000,000 USDT** |

At the C9 median snapshot value of 498,844 USDT:

- 400 / 498,844 = approximately **0.0802% (8.02 bp)** of that turnover;
- 1,000 / 498,844 = approximately **0.2005% (20.05 bp)**.

Both exceed the selected 0.01% screen. At 10,000,000 USDT of reported turnover, the two scenarios consume approximately 0.004% and 0.01%, respectively. C9’s count of 134 symbols at or above 10M therefore indicates that the **snapshot had a group above the illustrative 500-USDT volume threshold**—not that those same contracts currently exist, are liquid now, have adequate order-book depth, or pass any other screen. No symbols can be identified from the aggregate count.

The rule scales linearly with actual order size. If actual \(N\) exceeds the 1× examples, use the actual \(N_e+N_x\); the capital-planning scale does not cap leveraged notional. Also verify that the eventual Toobit turnover field uses a compatible quote-notional definition and time window. If its semantics differ or cannot be established, the comparison to C9 is not valid.

### 3.4 Order-book depth-fraction condition

Daily turnover is not displayed executable depth. For a proposed order, define \(D_{\delta,\text{side}}\) as the **same-side cumulative executable quote notional** within an adverse price-move band \(\delta\) around the contemporaneous mid, where \(\delta\) must be derived from the strategy’s cost/risk budget—not invented here.

**DESIGN_JUDGMENT:** require each order leg to be no more than \(\beta=1\%\) of verified depth in that band:

\[
N_{\text{leg}}\leq\beta D_{\delta,\text{side}}
\quad\Longrightarrow\quad
D_{\delta,\text{side}}\geq \frac{N_{\text{leg}}}{\beta}.
\]

At the illustrative one-leg notionals:

| Depth fraction \(\beta\) | Required depth for 200-USDT leg | Required depth for 500-USDT leg |
|---:|---:|---:|
| 0.1% sensitivity | 200,000 USDT | 500,000 USDT |
| **1% provisional choice** | **20,000 USDT** | **50,000 USDT** |
| 5% sensitivity | 4,000 USDT | 10,000 USDT |

The 1% choice gives a 100-to-1 displayed-depth-to-order ratio; it is a conservative heuristic, not evidence that displayed levels will remain available. If order size changes, recalculate. The 0.1% and 5% rows show the breadth-versus-conservatism sensitivity. C8 prevents any of these conditions from being evaluated using the supplied BTC figures. Until a reproducible, correctly sided, timestamped depth measure and a strategy-derived \(\delta\) exist, **the book-depth check is unresolved and cannot pass**.

### 3.5 Combined screening rule

A future symbol-timeframe cell may be considered for research only after its exact data is populated. A candidate execution screen requires **all** of the following:

1. Verified Toobit perpetual contract and usable contract metadata.
2. Current, consistently defined \(V_{24}\) satisfying the formula using the actual risk-sized order.
3. Valid same-side order-book depth satisfying the selected provisional fraction within the approved slippage band.
4. Cost and funding treatment consistent with the exact holding window; no unverified funding cap.
5. Valid completed 1h data and adequate historical coverage for the preregistered test.
6. No source, timestamp, or quality gate failure.

Passing the daily-volume calculation alone does not admit a symbol. Because order-book depth is unresolved, current per-symbol turnover is absent, and actual size depends on pending risk choices, **no symbol is presently designated as execution-eligible**.

## 4. Historical-depth assessment

C2 reports a 3,500-candle cap/observed depth ceiling, not guaranteed historical completeness. It also reports **1,774 measured 1d bars**, about **4.86 years**, and a stratified census of 58 combinations, with 36 reaching 3,500. The census was not exhaustive across 544 × 14 combinations. C25 also says the broader 544 × 14 census was not exhaustive; **544 is not used here as a symbol count or universe target**.

If 3,500 bars were actually available for a given symbol and interval, the corresponding span would be:

| Interval | Calendar span represented by 3,500 bars, **if actually returned** |
|---|---:|
| 5m | 12.15 days |
| 15m | 36.46 days |
| **1h baseline** | **145.83 days** |
| 4h | 583.33 days, about 1.60 years |
| 1d | 3,500 days; however, C2 reports only 1,774 measured 1d bars in its cited case, about 4.86 years |

These are unit conversions, **not per-symbol history claims**. A cap does not establish that every request returns that many bars, that older bars are retrievable by pagination, or that the returned series is continuous. In particular, 3,500 1h bars would be only about 4.8 months if that depth were achieved; the actual Toobit-native 1h depth for each candidate is unknown.

C17/C18 report owner-ratified cross-venue 1h and 5m history reaching 2019-12-16 in recorded scope; exact symbol coverage and the venue are not identified here. C18’s transfer finding is limited to its 1h/4h research scope. This dataset may only be used under the A5 access, registration/KYC or equivalent, legal, sanctions, cost, payment, withdrawal, licensing, and owner-approval conditions. Its prices cannot be silently treated as Toobit candles; the transfer finding does not transfer funding, order-book behavior, fills, or exchange costs.

A research-adequacy bar count or time span must be set from the later preregistered validation design, statistical power, regimes, costs, and per-cell trial budget. No arbitrary minimum history is asserted here. Until the per-symbol evidence is available, a cell’s historical coverage status remains **BLOCKED**.

## 5. Universe register

### 5.1 Current register population

The register is keyed by **verified contract identifier × timeframe × as-of universe snapshot**. It must contain one real row for every evaluated candidate, including exclusions. The prompt did not provide the exact current Toobit contract list, per-symbol turnover/depth, or per-symbol historical coverage. Therefore:

- **Populated, verified symbol rows: 0**
- **Accepted research symbols: 0**
- **Accepted Paper/Live symbols: 0**
- The placeholder below defines the required row structure; it is **not** a symbol and does not imply that any contract passed.

| Register key | Contract / interval | Inclusion reason | Evidence pointer | Status | Coverage conditions | Failure behavior |
|---|---|---|---|---|---|---|
| Template only — not a symbol | `UNRESOLVED contract ID × 1h` | 1h is the provisional single-timeframe SC-01 baseline; contract membership still must be verified | C1, C2, C8–C10, C17–C18; Part 3 SC-01 | **BLOCKED_NOT_POPULATED** | Must be confirmed as a Toobit perpetual; pass the actual-size turnover and depth screens; have valid contract metadata and completed 1h bars; meet the separately preregistered coverage requirement; pass timestamp and data-quality gates | Do not enter the active universe. Do not substitute another venue, interval, or stale value. Record the reason and continue without that cell. |

### 5.2 Required per-symbol register fields

When a real census is available, each row must record:

- Exact exchange contract ID, display symbol, contract type, settlement/quote currency, and effective listing status.
- Timeframe, source/source tier, selection timestamp in UTC, and reason for inclusion or exclusion.
- Timestamped \(V_{24}\), its window semantics, order size used in the calculation, \(\alpha\), depth fraction \(\beta\), measured depth side and band \(\delta\), and the outcome of each gate.
- Requested and returned candle counts, earliest/latest verified bar, gap/duplicate/conflict counts, relevant listing/delisting coverage, and the history-adequacy decision.
- Contract metadata version, fee/funding assumptions, quality state, lineage identifier, and failure response.

Recommended status values are separate rather than collapsed into “eligible”:

`UNPOPULATED` → `LISTING_VERIFIED` → `SCREENED` → `RESEARCH_COVERAGE_VERIFIED` → `RESEARCH_ELIGIBLE` → (future, separately tested) `PAPER_ELIGIBLE` → (future, subject to Live interlocks) `LIVE_ELIGIBLE`.

No stage may be inferred from a later one, and the current register is at `UNPOPULATED`.

## 6. Relevant data classes and inclusion decisions

| Data class | Incremental value for SC-01 | Availability, permission, cost | Correctness / point-in-time risk | Decision and consequence of absence |
|---|---|---|---|---|
| Toobit-native 1h OHLCV | Required signal input and price history | C1 reports interval capability; no endpoint or terms were inspected here. Monetary and rate-limit costs are not established. | Bar-boundary/finality semantics, gaps, revisions, symbol coverage and historical depth unresolved. | **Required.** Without valid completed bars, no signal for that cell. |
| Contract/instrument metadata | Makes contract identity, quantity, fees and PnL interpretable | Per-symbol current and historical metadata not supplied or inspected. | Contract changes, tick/step values, effective dates, multipliers and limits can create invalid sizing or lookahead. | **Required before admitting a symbol.** Missing or conflicting metadata excludes it. |
| 24h quote turnover | Low-cost activity prefilter derived above | C9 supplies aggregate snapshot findings only; no current per-symbol observation was supplied. Endpoint cost/terms and exact window semantics are not verified. | Snapshot is not timeless; rolling-vs-fixed window and quote-conversion semantics matter. Historical point-in-time coverage is absent. | **Required for current screen.** Stale or undefined values fail the screen. |
| Order book / best bid-ask | Spread and same-side executable-depth gate; execution diagnostics | C8 makes cited depth non-reproducible; current per-symbol feed and historical depth are not established. | Sequence gaps, stale levels, sidedness, vanishing depth, and snapshot/delta mismatch. | **Required for the provisional order-depth gate.** No verified book means no pass; C8 numbers are not used. |
| Trade/tick data | Can improve fill, stop-order, and intrabar-path realism | Coverage, terms, costs, retention, and endpoint capability not established. | High volume, duplicate/out-of-order events, event/receipt timestamp differences. | Conditional execution-research source. If unavailable, use explicitly pessimistic assumptions; do not claim realistic fill validation. |
| Funding rates/events | Models funding payments and holding-window risk | C7 reports an observed clamp, not a safe cap; per-symbol history and event schedule are unresolved. | Published rate versus settlement time and actual realized payment must not be conflated. | Required for any test or position whose possible holding window can cross a funding event. If unverified, no such trade/test claim. |
| Fee schedule / tier | Converts fills into realized-cost assumptions | C6 has conflicting 0.05% and 0.06% taker evidence; no account-specific tier was accessed. | Fee may vary by side, tier, maker/taker status, and time. | Use 0.06% per taker side provisionally for feasibility only; no maker credit or account-specific claim. Resolve before Live. |
| Mark/index/last price | May be relevant to valuation, liquidation and exchange reconciliation | C13 reports conflicted `markPrice`/`klines.change` semantics; no independent source inspection. | Wrong semantic field can corrupt stops, valuation, or risk. | Do not use conflicted fields as critical strategy inputs. A future Live risk design requires a separately validated mark/valuation feed or remains blocked. |
| Open Interest | Could be a candidate explanatory/positioning feature | C26 says historical OI is unresolved. | Coverage and revisions unknown; likely point-in-time risk if reconstructed later. | Excluded from SC-01; its absence does not block this candidate because no OI hypothesis is established. |
| Cross-venue public candles | Potentially extends research history and supports transfer analysis | C17/C18 are owner-supplied findings; venue, exact symbol coverage, license, access, registration/KYC, cost and legal approvals remain unresolved under A5. | Contract mapping, basis, missing intervals, timestamps, funding, and execution differences; transfer evidence is limited. | **Conditional, research-only.** Until all gates are met, do not ingest/use. Never silently substitute for Toobit; do not feed unapproved data or its derived signals into Paper/Live. |
| News, sentiment, on-chain, liquidation feeds | No demonstrated incremental value for this first single-timeframe price hypothesis | Providers, licensing, costs and coverage are unspecified. | Publication-time/lookahead bias, revisions, source disagreement. | Excluded from baseline. Reconsider only for a distinct, predeclared hypothesis and point-in-time evidence. |
| Account order/position/balance state | Required for future reconciliation and execution safety, but not for candle-signal research | No account access was used or permitted in this design engagement (A4). Future use requires separate owner authorization and secure, least-privilege integration. | Stale or incomplete state can create duplicate orders or unrecognized exposure. | Future execution design must treat it as a safety dependency; this part does not claim it is available or tested. |

## 7. Source specifications for the proposed data contract

The following are **design specifications**, not statements that the sources were independently accessed or that all required endpoints exist. Toobit terms, provider permissions, and monetary data costs were not reviewed. Use only permitted data under the applicable terms.

### S1 — Toobit-native completed 1h candles — required

- **Purpose / incremental value:** signal calculation, price/return history, and volatility/cost analysis for SC-01. One 1h series satisfies the baseline information need; no cross-timeframe join is required.
- **Availability / coverage:** C1 reports 1h support. C2 provides only a cap/depth observation and limited census; **per-symbol 1h count, earliest date, gaps, and finality are unknown**. A reported capability is not a per-symbol coverage guarantee.
- **Timestamp semantics:** retain the raw exchange timestamps, local UTC receipt time, retrieval time, payload/hash, source symbol, and interval. Normalize bar start/end only after testing the venue’s timestamp convention. Treat the bar as a half-open UTC interval `[start, end)` once verified. Do not use an unfinished bar; preserve corrections as new observations instead of overwriting what was previously known.
- **Freshness / staleness:** only a completed, quality-passing bar can produce a signal. Determine an allowed publish/receipt lag from measured delivery-latency data and a documented safety margin. That threshold is **not yet measured**; until established, no live-feed freshness pass is claimed. A stale or missing bar blocks new entry signals for the affected cell.
- **Historical / point-in-time status:** C2 gives no complete per-symbol 1h matrix. Preserve data “as known at the time”; future corrections must not rewrite past information sets. A current-only symbol list cannot, by itself, remove historical survivorship bias.
- **Quality controls:** finite positive prices; valid OHLC ordering; nonnegative volume where provided; valid and aligned timestamps; expected interval adjacency; exact duplicate idempotency; conflicting duplicate quarantine. Never fill missing prices or volume forward.
- **Lineage / retention:** retain immutable raw observations plus normalized records, source and schema version, retrieval batch, hash, and validation outcome. Keep research and operational provenance. Retention duration remains subject to legal/owner policy; do not silently purge records needed to reproduce research decisions.
- **Failure behavior:** gap, stale bar, invalid timestamp, conflicting revision, or unavailable feed means no new signal for that cell. Do not substitute cross-venue data in Paper/Live or silently switch timeframe.
- **Resource cost:** for a given stored bar schema, estimate by the C19 scaling calculation in Section 10. Actual storage for the proposed schema has not been measured.

### S2 — Contract and instrument metadata — required

- **Purpose / incremental value:** verifies that a row is the intended Toobit perpetual and supplies the contract mechanics necessary to turn a USDT notional into valid quantity and calculate PnL, fees, and funding.
- **Required fields where applicable:** contract type, settlement/quote currency, multiplier or contract value, tick size, quantity step, minimum quantity/notional, price/quantity precision, status, effective listing/suspension dates, funding interval, and applicable leverage/maintenance parameters.
- **Availability / cost / coverage:** exact current and historical per-symbol records are not available here; retrieval permission and endpoint semantics were not inspected. C3’s reported BTC tier ladder is not a complete system risk limit and does not resolve per-symbol/account maximum leverage.
- **Timestamp / freshness:** preserve each metadata version with effective-from/effective-to and observation time. Recheck on startup and when the venue reports a change; a verified refresh interval still needs to be derived.
- **Point-in-time / quality:** historical contracts and metadata must be joined as of decision time. Validate tick/step alignment, multiplier arithmetic, and effective dates. A conflicting or absent field fails the symbol.
- **Lineage / retention:** versioned source snapshot and raw payload retained with each research configuration.
- **Failure / consequence:** exclude the contract from the candidate universe; never guess precision, multiplier, contract type, or leverage.
- **Resource cost:** low-volume metadata relative to candles, but unmeasured; stale or repeated polling can incur rate-limit and availability costs.

### S3 — Toobit 24h turnover snapshots — required for the activity screen

- **Purpose / incremental value:** evaluate \(V_{24}\) against the derived \(V_{24}\geq(N_e+N_x)/\alpha\) rule and preserve the exact as-of liquidity decision.
- **Availability / cost / coverage:** C9 is an aggregate snapshot, not a current per-symbol feed. The exact Toobit field, window semantics, per-symbol history, terms, and costs are not established here.
- **Timestamp / freshness:** record source event time, receipt time, symbol, currency/quote convention, and whether the measure is rolling or fixed-window. Use a fresh as-of value for each universe decision and re-evaluate before an order. A numeric value without valid time/window semantics fails.
- **Point-in-time status:** C9 does not provide per-symbol historical turnover snapshots. Start an append-only point-in-time series before using the screen in prospective tests; historical selection claims are otherwise limited.
- **Quality / lineage / retention:** reject non-finite, negative, wrongly denominated, stale, or unidentifiable data. Preserve source tag, raw response, normalized units, source timestamp, and screen calculation.
- **Failure behavior:** the symbol does not pass the volume screen. No cached stale value and no cross-venue substitute.
- **Resource cost / consequence of absence:** small relative to tick/book archives, but update/rate-limit costs are unmeasured. Without valid current turnover, no liquidity pass.

### S4 — Toobit order book and best bid/ask — conditional mandatory execution gate

- **Purpose / incremental value:** current spread and same-side depth within strategy-approved \(\delta\), plus execution diagnostics. It is not used as a backfilled historical capacity fact.
- **Availability / coverage:** C8 explicitly prevents use of the supplied book-depth figures as reproducible capacity facts. A validated per-symbol feed, history, snapshot/delta protocol, and side convention are not established.
- **Timestamp / freshness:** preserve exchange timestamp, receipt time, sequence/update identifiers, snapshot/delta lineage, side, price, and quantity. Reject out-of-order, incomplete, unsynchronized, or stale books. Set the exact freshness limit from measured feed latency; until then it cannot pass.
- **Point-in-time status:** no trustworthy historical order-book-depth matrix was provided. Any later capture must be decision-time aligned and kept separate from post-event knowledge.
- **Quality / lineage / retention:** validate sequence continuity, non-crossed best prices, level ordering, units, and snapshot reconstruction. Record source tags and the exact depth band used. Retain the snapshots needed to reproduce screen and execution-cost estimates; full-depth high-frequency retention is a separate, unmeasured storage choice.
- **Failure behavior:** invalid or unavailable book means the depth gate fails; no new order is authorized by this data design.
- **Resource cost / consequence of absence:** likely materially higher than hourly candles, but actual event rate, storage and CPU are unknown. Absence blocks the proposed depth test; C8’s BTC numbers must not be used instead.

### S5 — Funding events, rates, and realized payments — required when holding risk can cross funding

- **Purpose / incremental value:** model holding-window costs and tail exposure; distinguish forecast/published rates from actual settlement payments.
- **Availability / coverage:** per-symbol event timing and historical depth were not established. C7’s observed −30 bp is evidence against an assumed ±24 bp cap, not a safe bound.
- **Timestamp / freshness:** store publication time, applicable interval, scheduled settlement time, and realized settlement time/payment as distinct fields where available, all in UTC. Do not treat them as interchangeable.
- **Point-in-time / quality:** preserve what was known at signal time separately from what settled later. Validate symbol, sign, currency, and interval; do not clip rates to an assumed limit.
- **Lineage / retention:** immutable source records and calculation inputs retained with the strategy run.
- **Failure behavior:** if the possible holding window may cross a funding event and its timing/cost cannot be bounded from valid data, the research scenario is incomplete and the trade path must be gated. Do not credit favorable expected funding to compensate for unknown adverse tails.
- **Resource cost / consequence of absence:** expected lower-volume than candles or book data, but source cost and history are unknown. Without it, no validated result may claim funding-aware performance for a crossing position.

### S6 — Fee assumptions / fee schedule — required for cost evaluation

- **Purpose / incremental value:** quantify costs per fill and prevent gross-performance results from being mistaken for net results.
- **Evidence and provisional rule:** C6 conflicts between documented 0.05% and observed 0.06% taker fees. Use **0.06% per side, provisionally**, only as the conservative taker-feasibility input until resolved. Do not infer an account-specific fee tier. Maker fee, rebate, and actual execution classification remain unresolved.
- **Timestamp / point-in-time:** store the assumed or verified rate, applicability period, fee tier/source, and order-side classification with every run and fill. Historical fee-tier coverage is not known.
- **Quality / lineage / retention:** distinguish actual exchange fee records from owner-supplied findings and design assumptions; preserve the exact values used in each test.
- **Failure behavior:** missing fee data does not become zero-cost execution. Use the conservative provisional taker case for exploratory feasibility or mark the result incomplete; do not grant maker credit without evidence of fills and adverse selection.
- **Cost / consequence of absence:** no fee quote or account fee was inspected. If actual fees differ, estimates and decisions must be recomputed.

### S7 — Trades/ticks — conditional execution-research source

- **Purpose / incremental value:** can test intrabar path, entry/exit timing, and execution assumptions more faithfully than 1h OHLCV alone.
- **Availability / coverage / cost:** endpoint availability, historical depth, permitted use, event rate, and monetary cost are unverified. None is assumed.
- **Timestamp / freshness:** keep exchange event time, local UTC receipt time, trade ID/sequence, price, size, and side fields as supplied; do not infer unavailable aggressor-side semantics.
- **Point-in-time / quality:** deduplicate exact event IDs, reject conflicting IDs, and retain out-of-order events with their original sequence evidence; measure data gaps.
- **Lineage / retention:** retain raw source and normalized events for the test windows; size impact must be measured before choosing a long-term retention policy.
- **Failure behavior:** without ticks, SC-01 may still be explored using explicitly pessimistic bar-based fills, but fill realism remains unverified. Same-completed-close fills are prohibited by the Part 3 causal rule.
- **Resource cost:** potentially much higher than candles; no device fit or event-rate benchmark exists.

### S8 — Cross-venue historical candles — research-only, conditional

- **Purpose / incremental value:** potentially extends 1h history for research and permits a separately tagged return-transfer analysis.
- **Owner-supplied coverage:** C17 reports 1h and 5m history to 2019-12-16 in recorded scope; C18 reports 1h transfer evidence. The venue, symbol coverage, exact archive, licensing and time semantics were not inspected here.
- **Permission / cost:** use is blocked until the conditions in A5 are established, including registration/KYC or equivalent access, legal/sanctions, license, payment, withdrawal, and owner authorization. Unestablished conditions remain unresolved owner/legal matters.
- **Timestamp / coverage:** verify contract mapping, bar boundary, missing intervals, revisions, and symbol effective dates before any analysis. C18 does not authorize 5m transfer and does not establish transferred execution, funding, depth, or fees.
- **Point-in-time / quality:** store in a separate source namespace; apply as-of joins and preserve the raw-to-canonical mapping. Never blend it into Toobit-native bars or overwrite a Toobit gap with another venue.
- **Lineage / retention:** label every record and derived dataset `EXTERNAL_RESEARCH_ONLY`; preserve license and approval metadata with the dataset. Retention obligations/cost are unresolved.
- **Failure behavior:** if any gate fails, do not ingest or use it. Even if admitted for research, it does not automatically become a Paper/Live source. Research artifacts derived from it remain gated from Paper/Live pending owner/legal approval and explicit transfer validation.
- **Resource cost / consequence:** archive size, retrieval cost, and device impact cannot be estimated without the actual archive and schema. If unavailable, use Toobit-native history only and mark coverage shortfall honestly.

## 8. Time, provenance, and data-quality policy

### 8.1 UTC and point-in-time joins

All persisted instants and computations use UTC (A3). Store, where applicable:

- Source event/exchange timestamp.
- Source-reported bar or event interval.
- Local UTC receive and persistence timestamps.
- Monotonic receive time for elapsed-time/freshness checks within a running process; do not use it as a persistent UTC instant across restarts.
- Source/venue, exact contract ID, interval, sequence/update ID, schema version, retrieval batch, raw-payload hash, correction status, and validation result.

At a decision timestamp, a source record is eligible only if it was both **valid for the event time** and **available to the system by that decision time**. A historical correction received later must not be backdated into the earlier information set. Build the historical universe from effective-dated contract records and point-in-time turnover where available; if only a current universe can be reconstructed, label survivorship/selection bias.

Use A3’s UTC-day boundaries for daily reports and UTC ISO-8601 weeks for weekly reports where applicable. A rolling 24-hour turnover field is not automatically a UTC-calendar-day measure.

### 8.2 Missing, stale, duplicate, malformed, contradictory, or unavailable data

| Condition | Required handling |
|---|---|
| Missing candle, event, metadata, or source timestamp | Mark the affected symbol/time range as incomplete; do not forward-fill prices or volume. Block signals requiring the missing interval. |
| Stale feed or incomplete current candle | Do not generate a new entry from it. Freshness limits must be measured and configured; none is claimed as already measured. |
| Exact duplicate | Idempotently retain one canonical event while preserving ingestion lineage. |
| Duplicate key with conflicting payload | Quarantine the conflicting records and block the affected decision window; no last-write-wins. |
| Malformed candle | Reject/quarantine non-finite prices, nonpositive prices, invalid OHLC ordering, invalid timestamps, or impossible units. Preserve the raw record for diagnosis. |
| Malformed book or out-of-sequence updates | Mark the reconstructed book invalid; the depth gate fails. |
| Contradiction between sources | Keep source namespaces separate, log the disagreement, and apply no silent priority or venue substitution. |
| Unavailable source or rate-limit error | Finite, explicit retry budget; then mark unavailable and fail the dependent check. Do not turn missing data into a pass. |
| Cross-venue data in a Paper/Live input path | Reject by source-tier allowlist; do not silently normalize it into Toobit-native data. |

C4 reports missing `X-Api-Limit-*` headers in the tested environment; any eventual ingestion controller must therefore use a conservative explicit rate budget rather than assume header deltas. C5 reports `-1007 TIMEOUT` as ambiguous and `-1003` as the reported rate-limit breach. Data retrieval retries must be bounded and idempotent; an ambiguous **order** result must not be treated as a data-retrieval retry result (the order lifecycle is specified later in Part 7).

## 9. Breadth and resource trade-off

A wider symbol set could increase the number of research opportunities, but it also increases:

- The number of independently evaluated symbol-timeframe cells and the multiple-testing burden.
- The need for point-in-time listings, turnover and contract metadata.
- Data-quality, stale-source, book-depth, and ongoing monitoring surface.
- Correlated exposures, which symbol count alone does not diversify.
- Storage, computation, rate-limit consumption, and the chance that a poorly covered contract is mistaken for a comparable sample.

A narrower set of demonstrably high-activity contracts reduces this workload but may sacrifice candidate breadth and does not prove better strategy performance. C9’s **134 symbols at or above 10M** is a snapshot aggregate, **not a target, universe seed, or list of accepted symbols**. The selected \(\alpha\) and \(\beta\) thresholds are provisional heuristics; their breadth impact cannot be determined without exact, current per-symbol values.

The design therefore chooses **measured eligibility over a fixed breadth target**. No symbol count is selected. If the screen yields few or no contracts, do not loosen it silently: first determine whether the cause is account size, risk-derived order notional, measurement error, stale inputs, or an overly restrictive design judgment.

## 10. Workload, storage, and POCO X6 implications

Workload is derived from the selected 1h-only data shape, not from the ten-symbol illustration:

- Let \(S\) be the number of contracts that actually pass the documented gates.
- Let \(B_i\) be the **verified** number of 1h bars for contract \(i\).
- The initial candle row count is \(R=\sum_{i=1}^{S} B_i\). The 3,500 observation is not a guarantee that \(B_i=3{,}500\).
- One continuous 1h series contains 8,760 bars per 365-day year per contract. Lower intervals would multiply rows for the same period; for example, 15m has four bars per 1h and 5m has twelve. They are not part of the current baseline.
- A full feature pass is approximately \(O(R)\) for simple rolling features. Research work grows with per-cell trials and validation folds; caching may reduce repeated work. The search remains bounded by C22/C24 and the recomputed trial budget. No benchmark was run.

C19 reports approximately **1.25 GB** in one relational database file for **3,500 candles × 14 intervals × 10 arbitrary symbols**. The arbitrary symbols were not a recommended universe. Use that figure only as a rough calibration if the proposed table shape, indexes, row content, and storage engine match:

\[
D_{\text{bars}}\approx
1.25\text{ GB}
\times\frac{S}{10}
\times\frac{T}{14}
\times\frac{B}{3500}.
\]

This corresponds to roughly 2.55 kB per candle-interval-symbol row under the measured shape. For the proposed single-timeframe shape, \(T=1\), and \(B=3{,}500\), the rough estimate is about **8.9 MB per symbol**. At 8,760 1h bars per symbol-year it is about **22.3 MB per symbol-year**, again only if the C19 row shape applies. The formula is not an estimate for raw order-book or trade archives, whose size and event rates are unmeasured. Metadata, raw payload retention, indexes, write-ahead logs, backups, reports, and application overhead must also be included in a later measurement.

The selected candle workload alone does not establish a phone fit. C14 is an owner attestation of the POCO X6 specification and a 56 GB free-storage check at the owner’s time of measurement; C16 reports a prior 24-hour charging test without observed problems. They do not measure sustained database growth, peak memory, backtest duration, background survival, thermal throttling, crash recovery, or network conditions. C15 identifies Android background restrictions and related failure modes. **The POCO X6 fit therefore remains provisional and unmeasured.** Part 8 must match actual workload measurements to the permitted deployment topologies before any topology is selected.

## 11. Material decisions and reversibility

| Decision | Status / rationale | Credible alternative | Reversibility |
|---|---|---|---|
| Limit the universe to verified Toobit perpetuals; start with linear USDT contracts | Provisional, simplest initial notional/PnL model; no contract list is asserted | Include other perpetual contract types after separate mechanics and cost models | Reversible before data and sizing implementation; costly after contract-specific research |
| Use one 1h baseline for SC-01 | Provisional; one signal interval, with owner-supplied 1h transfer evidence in its limited scope | 15m or 4h as separately registered challengers | Reversible before confirmatory tests |
| Exclude extra intervals and multi-timeframe filters from baseline | No additional information need has been demonstrated; avoids extra cells and stale joins | Add a predeclared interval/filter hypothesis and its own freshness/trial budget | Reversible with explicit new research registration |
| Initial turnover fraction \(\alpha=0.01\%\) per round trip | Design heuristic, not an impact measurement; explicit sensitivity shown above | More conservative 0.001% or less conservative 0.1%, subject to evidence | Reversible after measured slippage evidence and logged review |
| Initial displayed-depth fraction \(\beta=1\%\) | Design heuristic with a 100:1 displayed-depth ratio; currently cannot pass because C8 data are not reproducible | 0.1% or 5% sensitivity cases | Reversible after reproducible book capture and validation |
| No imputation and no silent source blending | Preserves causality and auditability; source conflicts cannot be repaired by assumption | A formally validated reconstruction for a narrowly defined missing-data class | Safety/data-integrity invariant; any relaxation requires explicit scope, validation, and audit trail |
| Isolate cross-venue sources from Paper/Live | Binding A5 gate; permission and transfer conditions remain unresolved | None until the owner/legal conditions and validation are satisfied | Not removable by a technical convenience or optimizer setting |

## 12. Part 4 handoff

ART-06 records the provisional one-hour research baseline, an explicit dynamic symbol-screen policy, the liquidity calculation and its limitations, a deliberately unpopulated symbol register, source-by-source data requirements, quality/failure handling, and workload scaling. It does **not** report a verified symbol list, per-symbol depth, sufficient native history, profitability, a phone fit, or operational readiness.

The next parts can proceed around the unresolved items. Part 5 must keep the owner’s risk boundary pending, recompute trials per cell, and distinguish risk, notional, margin, leverage, costs, funding, and liquidation. Exact current contract enumeration, per-symbol historical coverage, current turnover/book measurements, fee resolution, and cross-venue permissions remain explicit evidence gaps.

**Registry update:** ART-01 through **ART-06 DELIVERED**; ART-07 through ART-12 remain **DEFERRED**. The engagement-level completeness declaration remains reserved for Part 10.


وضعیت: **بخش ۵ از ۱۰ — روش آماری، حاکمیت پارامترها و محاسبات حساسیت ریسک، ART-07، تکمیل شد.** مرز ریسک همچنان **OWNER_DECISION_PENDING** است. محاسبات أدناه حساسیت‌اند، نه انتخاب یا توصیهٔ حد ریسک. هیچ بک‌تستی اجرا نشده و هیچ نتیجهٔ عملکردی احراز نشده است.

# Part 5/10 — Statistical Methodology, Parameter Governance, and Risk Sensitivity (ART-07)

## 1. Scope and evidence status

This part defines how the proposed **SC-01** research candidate is to be tested and governed, and how position risk should be expressed without selecting an owner risk limit.

- SC-01 remains a **proposed first falsifiable research candidate**, not an accepted strategy. Its exact signal parameters, exits, intraday maximum holding duration, and execution model remain unselected.
- **The risk boundary remains OWNER_DECISION_PENDING.** No per-trade, aggregate, daily-loss, drawdown, leverage, or liquidation threshold is adopted here.
- The preference of approximately **5% per-trade risk** is not adopted as a hard, provisional, illustrative, or implicit limit. Its row in the required sensitivity analysis is arithmetic only, alongside the other unselected cases.
- The owner’s approximately **15–20% maximum-drawdown preference** is not used to choose, derive, or anchor any limit in this design.
- C20–C24 below are **OWNER-SUPPLIED FINDINGS**, not independently verified calculations in this engagement. The raw evidence archive, strategy code, exchange data, and trial records were not available. No backtest, statistical test, benchmark, or external inspection was performed.

The proposed data scope remains the **single completed 1h Toobit-native series** from Part 4. Exact contract membership, per-symbol history, and point-in-time coverage are unresolved. Cross-venue data remain subject to A5 and may not silently enter Paper or Live.

## 2. Research hypothesis and experiment unit

### 2.1 Candidate and comparison

SC-01 is a causal, single-timeframe range-breakout candidate. It must calculate its signal from **completed 1h bars** and use only information available when the decision is made. The range lookback, breakout condition, stop logic, exit logic, order type, and maximum holding duration are not selected.

Use the following comparison structure:

- **SC-00 no-trade control:** establishes the result of taking no strategy exposure over the same sample.
- **SC-00 randomized-entry control:** tests whether the apparent result is distinguishable from entries generated without the candidate’s signal, using comparable timing, sizing, exits, and costs. The randomization protocol and seeds must be registered; results cannot be used to tune SC-01 without being counted as research decisions.
- **SC-02 mean-reversion alternative:** a separate candidate with its own preregistration, trial budget, and validation. It is not a fallback to select after seeing SC-01’s results.
- **SC-03 and SC-04:** remain deferred as recorded in Part 3. Their additional selection and governance burden has not been justified for this first candidate.

A research cell is at minimum **contract × timeframe × strategy specification**. Any pooling across symbols, or selection of a “best” symbol after inspecting results, creates a further selection problem; it must be registered and accounted for rather than treated as independent evidence.

### 2.2 Primary estimand and decision rule

**DESIGN_JUDGMENT:** For SC-01, use **net arithmetic expectancy per completed round trip, expressed in basis points of entry notional**, as the primary research estimand. Include fees, spread, slippage, impact, and any applicable funding under the preregistered execution model.

This should be accompanied—not replaced—by portfolio-level results, including net return, exposure time, turnover, drawdown, tail loss, and costs by category. Per-trade expectancy alone cannot show whether overlapping positions, variable holding times, or correlated losses make the portfolio unacceptable.

A confirmatory test must preregister:

1. The primary estimand, sample, hypothesis, and comparison.
2. A confidence or other uncertainty procedure that accounts for time dependence.
3. The minimum **economic** effect required to matter—not merely a positive point estimate.
4. The decision rule, error/multiplicity treatment, and trial count.

Those numerical decision thresholds are **UNRESOLVED** and must be fixed before results from the confirmatory holdout are inspected. A favorable point estimate alone is not a promotion criterion.

## 3. Causal simulation and execution realism

### 3.1 Signal timing

For a bar representing `[start, end)`, SC-01 may use that bar’s completed values only after the bar has ended and the bar is available to the system. The backtest must use event time and availability time consistently.

- A fill at the same completed bar close is prohibited.
- A model fill must occur at the first **eligible, modeled executable opportunity after the signal is known**, including any latency assumption.
- The next bar’s open is not automatically an executable price: it may occur before the completed bar is received and processed. If used as an approximation, it must be labelled as such, and its timing limitations must be tested.
- Do not use future revisions, later universe membership, later-known contract metadata, or funding values not available at the decision time.

### 3.2 Stops, ambiguous bars, and order type

A 1h OHLC bar does not reveal the intrabar path. If a stop and another exit could both have been reached within one bar, the simulator must not choose the favorable ordering without evidence. Use a conservative adverse ordering or adequately timestamped trade data; record which method was used.

A limit-price touch does not establish a maker fill. Maker-only results require a defensible fill and queue model, including non-fill and adverse-selection effects. The C10 finding of a **“maker-only floor at 15m+”** applies only within its reported analysis scope. It is a warning against assuming that a 1h signal works under taker execution—not a Toobit-specific maker-fill guarantee. C10 does not provide a 1h cost-per-volatility result.

For initial cost feasibility, retain the C6 provisional taker assumption of **0.06% per side**. Do not assume maker rebates, account-specific fee tiers, or fills. A maker-only challenger may be studied separately only if its fill assumptions are explicit and evidence-supported.

### 3.3 Cost and funding treatment

Net results must distinguish:

- Entry and exit fees.
- Spread.
- Slippage and market impact.
- Funding actually paid or received, when applicable.
- Any other execution or contract cost.

Use the same point-in-time cost information in a run’s decision process and preserve it with the result. If a cost source or assumption changes after inspecting outcomes, record a new research decision/trial and rerun the affected analysis.

C7’s reported −30 bp funding clamp is not a funding safety bound. If the possible holding window crosses a funding event and the applicable event timing or cost cannot be modeled, the corresponding result is not a validated funding-aware result.

## 4. Validation and statistical reporting

### 4.1 Chronological splits

Use time-ordered development, validation, and final out-of-sample evaluation. Random shuffling of time-series observations is not an acceptable substitute.

- Parameter selection occurs only on the development data.
- Validation is used only for the predeclared validation purpose.
- A locked out-of-sample segment is inspected only according to the preregistered protocol. If results from that segment are examined and then used to change a strategy, it is no longer an untouched final test; the changed strategy needs a fresh holdout or prospective evidence.
- Purge or embargo overlapping observations around split boundaries where signals, lookbacks, or holding periods could carry information across folds. The exact boundary depends on the eventual parameters and holding duration, which are not yet set.
- Use a predeclared rolling or expanding chronological evaluation. No dates or required history length can be selected from the current evidence because the exact symbol-level coverage and candidate holding horizon are unknown.

A cell without enough valid, point-in-time history for its preregistered validation design is **insufficiently evidenced**, not repaired by shortening the test after seeing results or by silently substituting another venue.

### 4.2 Dependence, uncertainty, and metrics

The number of candles is not the number of independent strategy observations. Trades can overlap, returns can be serially dependent, and crypto symbols can move together. Therefore:

- Use uncertainty estimates that preserve relevant time dependence, such as a preregistered block-based method; do not rely on an IID shuffle of individual trades or bars.
- Where symbols are pooled, resample or otherwise model synchronized time blocks so shared market moves do not create false precision. Report per-cell results as well as any pooled result.
- Select block lengths and dependence assumptions after the strategy’s lookback and holding rules are specified—not from an invented fixed duration.
- Report net expectancy and uncertainty, portfolio returns, exposure, turnover, drawdown, trade count, fees, funding, and adverse-tail outcomes. Sharpe is not sufficient as a sole decision statistic.
- Keep units consistent when calculating return statistics. A per-bar statistic, an annualized statistic, and a trade-level statistic are not interchangeable.

SC-00 controls and secondary metrics provide diagnostics, not permission to select whichever result looks best. If multiple endpoints, symbols, variants, or periods are examined, report that selection and apply the preregistered multiplicity procedure.

### 4.3 Application of owner-supplied findings C20–C24

| Finding | Status and implication for this design |
|---|---|
| **C20 — DSR correction** | The supplied ledger reports a corrected DSR-related result of approximately **1.5e-2 at N=100** after fixing an annualized/per-bar unit mismatch; the original decision was reportedly unchanged. The inputs and raw trial panel are unavailable here. Do not transfer that number to SC-01 or treat it as this candidate’s result. Recompute with consistent units and the actual trial family. |
| **C21 — MinTRL versus MinBTL** | The supplied ledger reports a corrected **MinTRL of 19.54 years**; the earlier 4.99-year value was not reproducible and appears to conflate MinTRL with MinBTL. Preserve the two metrics separately. The reported MinTRL is not asserted here as a universal required history or as a measurement for SC-01; recompute from the actual study assumptions. If the required evidence exceeds valid available history, report the shortfall rather than treating another metric or source as interchangeable. |
| **C22 — effective trial count** | Where both published-panel and independently recomputed values exist, use `N_max_effective = min(published panel value, independently recomputed value)`. If they differ by more than 2×, the recomputed value governs and the discrepancy is recorded. Recompute for each applicable cell/family; do not borrow a budget from another timeframe or candidate. |
| **C23 — provisional counts and pooling** | Earlier admissible counts for 4h and 1d remain provisional pending recomputation. They do not determine the 1h budget. Pooling across cells is limited by cross-cell dependence; neither a large aggregate sample nor a symbol count automatically resolves it. |
| **C24 — full-grid restriction** | Exhaustive full permutation grid search is inadmissible at every timeframe **≤12h**. SC-01’s 1h candidate is subject to this restriction. |

No independently recomputed **1h per-cell trial budget** is available in this engagement. Until it is computed, broad optimization is not authorized. The arithmetic risk sensitivity tables in Section 7 are not performance trials and do not authorize selection of a risk setting.

## 5. Parameter governance

### 5.1 What must be registered

Before a run, preserve at least:

- Research-run and cell identifiers; hypothesis and candidate version.
- Exact contract list, timeframe, source tier, time boundaries, and point-in-time universe rule.
- Raw and normalized data hashes, coverage, exclusions, quality outcomes, and metadata versions.
- Code and configuration versions; all signal, stop, exit, holding-duration, and execution assumptions.
- Fee, spread, slippage, impact, funding, and latency assumptions.
- Development, validation, embargo, and holdout boundaries.
- Primary endpoint, secondary metrics, uncertainty method, trial budget, and planned comparisons.
- Every attempted variant, including failed, abandoned, manually inspected, or unreported variants; random seeds where applicable.
- Results, limitations, and the reason for retaining or rejecting the candidate.

A change to timeframe, source, universe screen, cost model, fill assumptions, feature, parameter, metric, or tested period may change the research claim. Its status as a new trial or cell must be decided and recorded **before** the changed result is assessed.

### 5.2 Search and adaptation limits

- Define parameter domains from a written strategy rationale and the available data resolution. The values for SC-01’s range lookback, buffer, stop, exit, and holding duration remain unselected.
- Do not run a full Cartesian permutation grid at intervals ≤12h. If the independently recomputed budget is unavailable, restrict exploration to a small, preregistered theory-driven set and label it exploratory—not confirmatory.
- Do not repeatedly narrow, widen, or reshape a parameter range in response to observed performance without counting and documenting the resulting research choices.
- A broad optimizer is not selected. Any future optimizer must be compared against a simpler fixed-parameter baseline, fit inside the recomputed budget, and be evaluated on a locked chronological protocol.
- Adaptation or online optimization remains a candidate concept, **not a required feature**. No automatic live parameter change is authorized by this design.
- Strategy parameters and safety limits are separate. A stop distance may be investigated as a strategy exit parameter, but a risk cap, daily-loss limit, aggregate-exposure cap, or kill control must not be tuned to maximize backtest profit.
- A Paper or Live configuration must be versioned and frozen for its approved scope. A material change requires an explicit new review and validation.

## 6. Risk model: distinct quantities and authority

### 6.1 Definitions

For a verified linear USDT contract, let:

- \(E\): the **approved risk-equity basis**, not assumed here to equal wallet balance, available margin, or current owner equity.
- \(r\): the per-trade risk fraction, **OWNER_DECISION_PENDING**.
- \(B=E r\): the monetary per-trade risk budget.
- \(P_e\), \(P_s\): entry and planned stop prices.
- \(d=|P_e-P_s|/P_e\): fractional stop distance, a strategy/exit quantity—not a risk limit.
- \(q\): contract quantity under the actual venue convention.
- \(M\): verified contract multiplier.
- \(N \approx qMP_e\): gross entry notional in USDT under that convention.
- \(c\): round-trip costs expressed as a fraction of notional, including the applicable fees and other adverse costs.
- \(g\): additional adverse gap/stop-execution distance used for a stress case.

For a linear contract, ignoring costs, the planned gross loss at the stop is approximately:

\[
L_{\mathrm{gross,stop}}
= qM|P_e-P_s|
\approx Nd.
\]

A first-order stressed all-in loss is:

\[
L_{\mathrm{stress}}
\approx N(d+g+c).
\]

If actual entry and exit notionals differ, calculate fees and PnL on their actual respective values rather than relying on the approximation. A stop order does not guarantee a fill at its trigger price; \(g=0\) is not a safety assumption.

If—and only if—\(E\), \(r\), \(d\), \(g\), and the relevant costs are established, a first-order risk-sized notional is:

\[
N_{\mathrm{risk}}
\leq
\frac{E r}{d+g+c}.
\]

This equation describes a sizing constraint. It does **not** set \(r\), establish a maximum loss, guarantee execution, or prove that the order is affordable or permitted.

### 6.2 Trade size must also pass other independent constraints

For the Part 4 round-trip volume screen, if entry and exit notionals are approximately equal:

\[
N_{\mathrm{turnover}}\leq\frac{\alpha V_{24}}{2}.
\]

For the Part 4 displayed-depth screen:

\[
N_{\mathrm{book}}\leq\beta D_{\delta,\mathrm{side}}.
\]

A possible authorization design is therefore:

\[
N_{\mathrm{candidate}}
=
\min\!\left(
N_{\mathrm{risk}},
N_{\mathrm{turnover}},
N_{\mathrm{book}},
N_{\mathrm{margin}},
N_{\mathrm{venue}},
N_{\mathrm{portfolio}}
\right),
\]

where every term must be supported by valid, current information. The Part 4 \(\alpha\) and \(\beta\) choices remain provisional design heuristics, and C8 prevents the supplied order-book figures from satisfying the depth test.

After determining a feasible notional, calculate quantity using the verified contract specification, then round **down** to the venue’s valid increment and recompute the resulting risk. Do not round quantity upward to meet a minimum order. If the smallest valid order would exceed the authorized risk budget or other constraint, skip the trade.

### 6.3 Notional, quantity, leverage, and margin are not interchangeable

- **Notional** is the position’s gross exposure in quote terms.
- **Quantity** is the number of contracts or underlying units under the venue’s contract convention.
- **Leverage setting** is a venue setting affecting margin requirements; it does not reduce the PnL loss from a given price move.
- **Initial margin** is collateral required to open or maintain a position under the venue’s rules. In a simplified isolated linear case it may be approximated as \(N/L\), but actual tiers, fees, contract rules, cross-margin exposures, and maintenance requirements can change that result.
- **Effective gross leverage**, if reported as an exposure descriptor, is approximately total absolute position notional divided by equity. It is not necessarily the venue leverage setting.

The sensitivity table’s \(N/E\) column is **not** an exchange leverage setting or authorization. A ratio above one indicates exposure above the illustrative equity amount; it does not show that the account has sufficient margin or that the venue will allow the exposure.

C3’s reported BTC leverage ladder is not a system risk limit, does not resolve other symbols’ tiers, and does not establish account-specific permissions. No account was accessed and no margin calculation was performed.

### 6.4 Liquidation is a separate failure boundary

Liquidation depends on the applicable contract, maintenance margin, margin mode, account and position state, mark-price behavior, fee and funding treatment, and other exposures. A planned stop does not prove that the position will exit before liquidation.

No liquidation price is calculated here. C13 records unresolved/conflicted `markPrice` semantics, and the contract/account inputs needed for a valid calculation are unavailable. Before any future Live authorization, the actual liquidation model, triggering-price semantics, margin tiers, and account-state inputs must be verified. If an adverse stress path can reach liquidation before the intended protective exit, the position must fail the risk gate. Do not substitute an unverified mark-price field or infer liquidation safety from a leverage label.

## 7. Parametric risk sensitivity — no limit selected

The owner-supplied approximate **200 USDT** capital scale is used only as an illustrative planning input (A11), not as current equity or evidence of feasibility. All risk fractions below are **unselected sensitivity cases**: 0.5%, 1%, 2%, 5%, and 10%.

### 7.1 Risk fraction and notional sensitivity

To show the calculation chain, assume solely for arithmetic:

- \(E=200\) USDT.
- \(d=1.00\%\), a hypothetical stop distance, not a selected SC-01 stop.
- A 0.06% taker fee per side from C6, used **provisionally**; two approximately equal taker legs give \(c_{\mathrm{fee}}\approx0.12\%=12\) bp.
- \(g=0\), with spread, slippage, impact, funding, and all other costs also set to zero **only in this simplified calculation**.

Thus \(B=Er\), \(N=B/(0.0100+0.0012)\), gross stop loss is \(0.0100N\), and the fee estimate is \(0.0012N\).

| Unselected \(r\) sensitivity | \(B=Er\) (USDT) | \(N_{\mathrm{risk}}\) (USDT) | Gross loss at 1% stop (USDT) | Two-leg fee estimate (USDT) | \(N/E\) |
|---:|---:|---:|---:|---:|---:|
| 0.5% | 1.00 | 89.29 | 0.89 | 0.11 | 0.446× |
| 1% | 2.00 | 178.57 | 1.79 | 0.21 | 0.893× |
| 2% | 4.00 | 357.14 | 3.57 | 0.43 | 1.786× |
| 5% | 10.00 | 892.86 | 8.93 | 1.07 | 4.464× |
| 10% | 20.00 | 1,785.71 | 17.86 | 2.14 | 8.929× |

The 5% row is present only as one required, unselected sensitivity value; it is **not** a proposed setting or implicit anchor. The same is true of every other row.

These outputs are not safe order sizes. They use fees alone and omit adverse costs and gap loss; adding nonnegative adverse cost terms increases the denominator and reduces the notional allowed by the same \(E r\) budget. The calculation also does not test minimum size, contract precision, liquidity, margin, liquidation, or whether the stop could be filled. The resulting \(N/E\) values are exposure ratios, not leverage instructions. Values above 1× do not imply that margin is available or that the order is feasible.

### 7.2 Stop-distance sensitivity

The formula also shows why risk depends on stop distance. At the same unselected \(E=200\) USDT and \(r=1\%\) sensitivity (\(B=2\) USDT), retaining the same fee-only \(c=0.12\%\) and \(g=0\):

| Hypothetical stop distance \(d\) | \(N_{\mathrm{risk}}=2/(d+0.0012)\) (USDT) | Gross stop loss (USDT) | Fee estimate (USDT) |
|---:|---:|---:|---:|
| 0.5% | 322.58 | 1.61 | 0.39 |
| 1% | 178.57 | 1.79 | 0.21 |
| 2% | 94.34 | 1.89 | 0.11 |

This is formula sensitivity, not evidence that any of these stops is suitable. Actual stop distance must come from the tested strategy; actual costs, gap risk, and funding remain to be established.

### 7.3 Repeated-loss sensitivity is not a drawdown limit

If each consecutive trade loses exactly fraction \(r\) of then-current equity, with position size reset to that fraction after each loss and with no intervening gains or cash flows, the drawdown after ten such losses is:

\[
DD_{10}=1-(1-r)^{10}.
\]

| Unselected \(r\) sensitivity | Drawdown after 10 consecutive full-\(r\) losses |
|---:|---:|
| 0.5% | 4.89% |
| 1% | 9.56% |
| 2% | 18.29% |
| 5% | 40.13% |
| 10% | 65.13% |

This is a deterministic loss-sequence calculation, not a probability forecast, backtest, maximum-drawdown estimate, or drawdown limit. It assumes every loss is exactly the chosen fraction of current equity; real losses can exceed a stop-based budget, particularly under gaps, execution failures, funding, or liquidation. It is not derived from the owner’s drawdown preference.

## 8. Per-trade, aggregate, daily-loss, and drawdown controls

These are different controls and cannot be substituted for one another.

### 8.1 Per-trade risk

Per-trade risk is the permitted stressed loss for a single trade under a defined equity basis. It must specify whether \(E\) is reconciled account equity, another owner-approved risk basis, and how costs and stress gaps enter the budget. Both \(E\) and \(r\) remain unresolved.

### 8.2 Aggregate open risk

A proposed portfolio measure is the sum of stressed losses to protective exits for current positions and any orders that could still fill:

\[
R_{\mathrm{open}}
=
\sum_i L_{\mathrm{stress},i}
+
\sum_j L_{\mathrm{possible\ fill},j}.
\]

A portfolio stress calculation should also cover simultaneous adverse moves, correlation, concentration, and shared margin. Do not assume that offsetting positions remove risk unless the contract, margin, and liquidation model supports that treatment.

For an ambiguous order result, such as the C5-reported `-1007 TIMEOUT`, reserve for the full plausible exposure until reconciliation establishes the order’s state. A timeout is not proof of rejection. This Part 5 requirement is a risk-accounting rule; the complete order state machine is specified in Part 7.

The aggregate risk threshold, concentration bounds, and treatment of correlated scenarios are **OWNER_DECISION_PENDING** or otherwise unresolved. A position cannot pass merely because its individual risk appears small.

### 8.3 Daily loss

**DESIGN_JUDGMENT:** Define daily loss against UTC calendar days, consistent with A3, using net mark-to-market equity that includes realized and unrealized PnL, fees, and funding. To avoid treating deposits or withdrawals as trading profit or loss, a candidate calculation is:

\[
P_{\mathrm{day}}(t)
=
E(t)-E(00{:}00\ \mathrm{UTC})
-F_{\mathrm{net}}(00{:}00,t),
\]

\[
L_{\mathrm{day}}(t)=\max(0,-P_{\mathrm{day}}(t)),
\]

where \(F_{\mathrm{net}}\) is external net cash flow, positive for a deposit and negative for a withdrawal. The denominator, if a fractional daily limit is chosen, must also be defined in advance.

The daily-loss threshold and the response to a breach—blocking new risk, managing open positions, latching, and reset behavior—are not selected here. They must not be inferred from a per-trade value or from the owner’s drawdown preference.

### 8.4 Maximum drawdown

A proposed drawdown calculation uses a cash-flow-neutral equity curve \(U(t)\):

\[
HWM(t)=\max_{s\le t} U(s),
\qquad
DD(t)=1-\frac{U(t)}{HWM(t)}.
\]

The record must define the measurement horizon, valuation source, treatment of unrealized PnL and external flows, and the action associated with a threshold breach. No numerical drawdown cap is adopted. In particular, the owner’s approximately 15–20% preference is not a provisional limit, an assumed target, or a parameter used to derive another risk rule.

C13’s unresolved mark-price semantics matter here: until the equity and valuation inputs used by any future control are independently validated, neither daily-loss nor drawdown monitoring can be declared valid for Live.

## 9. Live risk authority and unresolved inputs

The strategy may propose a signal; it must not define or relax its own risk limits. The eventual risk authority must independently validate the risk basis, calculate the worst-case permitted size, and deny an order if required inputs are missing, stale, contradictory, or outside their verified contract scope. Part 6 defines component and state ownership; Part 7 defines order transitions and command preconditions.

The risk-limit-definition-and-bounds interlock is one of A10’s six required Live interlocks. No interlock is passed by this design document. At minimum, future risk configuration must resolve and validate:

- Risk-equity basis, per-trade limit, and whether costs and stress gaps are included.
- Aggregate open-risk and exposure/concentration limits.
- Daily-loss and maximum-drawdown definitions, thresholds, and breach responses.
- Contract-specific quantity, fee, funding, margin, and liquidation inputs.
- Valid valuation and reconciliation sources.
- Behavior when feed, account state, exchange response, or operator connectivity is unavailable.

These unresolved matters do not prevent continued design work. They do prevent a claim of Live risk readiness.

## 10. Material decisions and reversibility

| Decision | Status and rationale | Credible alternative | Reversibility |
|---|---|---|---|
| Causal completed-bar signals and no same-close fills | Required for SC-01’s information timing and backtest validity | Tick/event-level replay can model execution more finely, if data become available | Safety/data-integrity invariant; any relaxation requires a separate, evidenced hypothesis |
| Chronological development, validation, and locked out-of-sample evaluation | Design judgment to preserve temporal causality and reduce holdout contamination | A different preregistered time-series validation method may be considered | Reversible before results are exposed; costly or effectively irreversible once a holdout has been used for decisions |
| Dependence-aware uncertainty and explicit multiple-testing accounting | Required by cross-time and cross-symbol dependence and C20–C24 | Another justified inference method may be compared before testing | Reversible before confirmatory runs; changes afterward require reanalysis and a new recorded decision |
| No exhaustive full-grid search at intervals ≤12h | C24 restriction | A bounded, preregistered candidate set within the recomputed budget | Binding research restriction for this scope; a technical optimizer cannot override it |
| Provisional 0.06% per-side taker fee in feasibility arithmetic | Conservative use of the unresolved C6 fee finding; not a verified account fee | Replace with validated, time- and tier-appropriate fee evidence and rerun affected tests | Reversible when evidence changes; the old and new runs must remain auditable |
| Risk-sized exposure based on stressed all-in loss, then constrained by liquidity, venue, and margin limits | Separates intended loss budget from notional and execution feasibility | A different formally justified risk model could be reviewed before deployment | Reversible during design; once approved, any change requires independent review and revalidation |
| No automatic live adaptation or risk-limit optimization | Reduces uncontrolled changes; adaptation is not required by A12 | A separately governed, bounded adaptation design may be considered later | Reversible only through a new governance and verification scope |
| Flow-neutral UTC loss reporting | Avoids counting deposits/withdrawals as strategy performance | Another audited accounting method could be used if it is equivalent and explicit | Reversible before implementation and preregistration; must not change silently afterward |

## 11. Part 5 handoff

ART-07 establishes a preregistration and validation discipline, preserves the C20–C24 trial restrictions, defines parameter and cost governance, and gives arithmetically checkable risk sensitivity without selecting a risk limit. It does **not** establish a successful strategy, a 1h trial budget, a verified position size, margin or liquidation safety, or Live authorization.

**Registry update:** ART-01 through **ART-07 DELIVERED**; ART-08 through ART-12 remain **DEFERRED**. The next part is **Part 6/10: component boundaries, state ownership, interfaces, and end-to-end flows**.


وضعیت: **بخش ۶ از ۱۰ — مرزهای مؤلفه‌ها، مالکیت وضعیت، رابط‌ها و جریان‌های کاری، ART-08، تکمیل شد.** معماری مبنا همچنان مونولیت ماژولار **موقت** است؛ این انتخاب به معنی انتخاب یا آزمون محیط اجرا نیست. هیچ حساب، اعتبارنامه یا API صرافی استفاده نشده است. جزئیات کامل چرخهٔ سفارش و پیش‌شرط‌های هر فرمان Telegram در بخش ۷ می‌آید.

# Part 6/10 — Component Boundaries, State Ownership, Interfaces, and End-to-End Flows (ART-08)

## 1. Scope and status

This part turns the provisional **PT-02 modular-monolith baseline** from Part 3 into an inspectable logical architecture. It defines responsibilities, state authority, module interfaces, mode boundaries, and critical flows. It is a design specification, not an implementation or a claim that an endpoint, persistence engine, deployment, or exchange capability has been verified.

The design preserves the following constraints:

- **Toobit** remains the selected Live venue (A1).
- **Telegram is the sole operator interface** (A2). It is a command and notification transport—not a safety authority, trust boundary, or process-topology constraint. This design adds no dashboard, second bot, application, or routine operator console.
- All recorded instants and calculations use **UTC**; monotonic time is used for elapsed deadlines (A3).
- The engagement remains **design-only** (A4). No account access, credential handling, authenticated exchange call, or order action took place.
- Cross-venue sources remain subject to A5 and are denied to Paper/Live unless the applicable permission and validation gates are explicitly satisfied.
- The risk boundary remains **OWNER_DECISION_PENDING**. Live risk authorization cannot be claimed.
- The six Live interlocks from A10 are separate from—and do not replace—per-order risk checks.

**Provisional architectural decision:** use a modular monolith with explicit module interfaces and one durable transactional state boundary as the initial design baseline. Keep the boundaries clear enough that a later move to PT-03 could be evaluated if measured workload, reliability, or threat analysis justifies it. No deployment topology has passed its envelope-fit assessment.

## 2. Logical architecture

```text
                        ┌─────────────────────────┐
 Telegram commands ────▶│ Telegram command adapter│
 Telegram notifications◀│ (sole operator interface)│
                        └────────────┬────────────┘
                                     ▼
                           ┌─────────────────┐
                           │ Control / mode /│
                           │ config authority│
                           └────────┬────────┘
                                    │
 Toobit market inputs              │ mode/config/gates
        │                           │
        ▼                           ▼
┌──────────────────┐     ┌──────────────────────┐
│ Ingest, validate,│────▶│ Versioned market data│
│ source-tag, map  │     │ and universe records │
└──────────────────┘     └──────────┬───────────┘
                                    │ valid completed-bar view
                                    ▼
                           ┌──────────────────┐
                           │ Strategy engine  │
                           │ (signal proposal)│
                           └────────┬─────────┘
                                    │ proposal only
                                    ▼
 Exchange/account ──▶ ┌────────────────────────┐
 observations         │ Reconciliation + risk   │
                      │ authority/reservations  │
                      └────────────┬───────────┘
                                   │ scoped authorization
                                   ▼
                      ┌────────────────────────┐
                      │ OMS: sole exchange-write│
                      │ path; durable intent    │
                      └───────┬──────────┬─────┘
                              │          │
                         Paper path    Future Live path
                         simulator     Toobit adapter
                         no Live key   gated; not accessed
                              │          │
                              └────┬─────┘
                                   ▼
                       Durable journal / audit /
                       projections / outbox
                                   │
                                   ▼
                       Telegram notifications

 Clock validity and health monitoring supervise time-sensitive
 gates; they do not grant trading authority.
```

This diagram shows logical dependencies, not process, machine, or network placement. The system must not use a mode label or successful Telegram interaction as a substitute for valid risk authorization.

## 3. Non-negotiable authority and safety invariants

1. **A strategy emits a proposal, not permission to trade.** It cannot calculate or change the system’s risk limits and cannot reach the exchange-write adapter.
2. **The OMS is the sole exchange-write path.** All exchange order submissions, cancellations, and replacements pass through it. New exposure requires a current, scope-matched risk authorization; risk-reducing actions use a separately scoped authorization. No module bypasses the OMS.
3. **Risk authority is independent of strategy.** It decides whether an intent is permitted using approved limits, validated exposure, reservations, data state, and the applicable operating mode. Missing or invalid inputs deny risk-increasing actions.
4. **Exchange state is not owned by local strategy state.** The exchange is the external authority for actual order, fill, position, and account outcomes. The local system records observations and maintains a reconciled projection; a local belief cannot turn an uncertain exchange result into a confirmed fill or rejection.
5. **The intent journal is authoritative about what the system attempted, not what the exchange did.** Record the intent before an external write. An ambiguous response remains ambiguous until reconciliation.
6. **Telegram is not the safety authority or a trusted execution shortcut.** The adapter forwards commands for validation by control and risk authorities. A Telegram acknowledgement or delivery receipt does not establish that an order was accepted or filled.
7. **Telegram unavailability does not disable reconciliation or safety monitoring.** No open-position safety procedure may depend on the operator replying to a Telegram prompt.
8. **Source tier travels with data and derived decisions.** Unapproved external data cannot silently become a Paper/Live input. Provenance loss or source-policy mismatch fails closed.
9. **A Live mode selection is necessary but not sufficient.** Interlocks and per-order checks still apply. There is no automatic switch into Live.
10. **UTC and monotonic time have different roles.** UTC timestamps record instants. Monotonic time measures elapsed intervals, timeout budgets, and deadlines within a running process.

These are architectural controls; they do not prove that an implementation enforces them. Part 9’s verification matrix must include evidence that module dependencies and exchange-write paths actually preserve them.

## 4. Component responsibilities and permitted authority

| Module | Responsibility | May own or change | Must not do |
|---|---|---|---|
| **Telegram command adapter** | Receive, parse, and route operator commands; return a structured acknowledgement or status notification | Transport and delivery state only | Decide risk, write exchange orders, override gates, or act as the authoritative source of operating state |
| **Control/mode/config authority** | Hold the active operating mode and versioned, approved configuration; validate mode-change requests and relevant interlocks | Durable mode and configuration records | Treat a Telegram message alone as authorization; modify risk bounds in response to a strategy signal |
| **Clock and health supervisor** | Assess clock validity and component/feed health; expose health state to dependent gates | Health observations and time-validity state | Authorize orders or convert an unknown external state into a known one |
| **Universe and contract catalog** | Maintain versioned, effective-dated contract identity and metadata; expose eligible symbol/timeframe rows | Contract metadata and universe-screen results with provenance | Guess missing contract fields or declare a symbol eligible from an aggregate liquidity count |
| **Market-data ingestion and validation** | Retrieve or receive permitted data; validate, timestamp, source-tag, deduplicate, and persist raw and normalized records | Data observations and their quality/lineage status | Silently fill gaps, overwrite conflicting observations, or mix venues without explicit source lineage |
| **Strategy engine** | Read valid information available at decision time; compute a strategy proposal, including version and lineage | Strategy-local state needed to reproduce its computation | Access exchange write credentials, change the approved universe or risk limits, or create orders directly |
| **Portfolio/risk authority** | Evaluate exposure and reservations against valid risk configuration and current reconciled state; issue bounded authorization or denial | Risk decision, scoped authorization, and local risk reservations | Treat an unreconciled position/order as absent, or infer a pending risk limit |
| **Order management system (OMS)** | Own internal order intents and dispatch; enforce mode, permit, idempotency, and lifecycle rules; record outcomes and ambiguity | Durable internal order record, client identifier, dispatch status, and projection | Submit outside the approved adapter path or declare an ambiguous result resolved without evidence |
| **Reconciliation** | Compare external order/position/account observations with local intents and projections; surface discrepancies | Reconciliation snapshot and discrepancy records | Secretly change strategy state, create exposure, or mark a mismatched account “clean” by assumption |
| **Execution adapters** | Isolate execution semantics by mode: non-live Paper simulation and, only in a future eligible Live deployment, the Toobit adapter | Adapter-specific request/response mapping | Let Research or Paper access Live credentials or send Live orders |
| **Persistence, journal, and audit** | Store state, append decision and I/O evidence, support recovery, and preserve lineage | Durable internal records under module ownership | Claim that a local journal entry proves a matching exchange fill |
| **Notification adapter** | Deliver relevant state and outcomes through the same Telegram interface | Notification queue/delivery status | Block core risk or reconciliation loops while waiting for delivery |

In the PT-02 baseline, these are **logical** modules, not promises of separate processes or services. Each module writes only its owned state through its interface. Direct cross-module table writes are prohibited by design; the concrete enforcement mechanism remains an implementation and verification matter.

## 5. State ownership and authority

| State or fact | Authority | Local handling and limitations |
|---|---|---|
| Operator-requested mode and approved configuration version | Control/mode/config authority, based on a validated command or approved configuration change | Persist the request, actor, prior/new versions, and validation result. Telegram itself is not the authority. |
| Actual Toobit orders, fills, positions, balances, and contract outcomes | Toobit, observed through future permitted and validated interfaces | Store observations and a reconciled projection. If observations conflict or are incomplete, preserve the unknown/mismatch state. No exchange state was accessed in this engagement. |
| Internal order intent and dispatch attempt | OMS journal | Record before network I/O. It is evidence of intent, not proof of acceptance, cancellation, or fill. |
| Internal risk authorization and exposure reservation | Risk authority | Bind it to the specific intent, scope, configuration version, and validity window. Retain the reservation until external state supports release. |
| Signal and strategy-local calculation state | Strategy engine | Preserve strategy version, input lineage, and decision time. A signal cannot overrule an exchange or risk state. |
| Raw and normalized data | Data ingestion/store, with source and validation lineage | Preserve source records and changes; later corrections must not rewrite what was known at the earlier decision time. |
| Universe snapshot and instrument metadata | Versioned universe/contract catalog | Use effective time and observation time. Current listing status does not establish historical availability. |
| Paper orders, fills, and simulated positions | Paper simulator | Treat only as simulation results under a specific fill-model version, never as exchange-confirmed fills. |
| Audit events | Append-only audit/journal interface | Records internally observed actions and decisions. A missing audit event is a system fault; an audit event alone does not prove an external outcome. |
| Credentials and secrets | Future, separately secured secret boundary | Only the future Live execution adapter may obtain the required order-write capability. No credentials were requested, received, or used. Specific secure storage and permission design is deferred to Part 8. |
| Telegram delivery/receipt state | Telegram adapter | Transient and non-authoritative. A message’s delivery or absence does not change positions or exchange-order state. |
| Current wall-clock instant | System UTC clock, subject to the validity monitor | UTC instants are persisted. Monotonic timestamps are used for elapsed deadlines and do not substitute for persistent UTC time. |

### 5.1 Persistence and transaction boundary

**DESIGN_JUDGMENT:** use one durable transactional persistence boundary for the initial modular-monolith design, with module-owned tables or equivalent records, an append-only decision/audit journal, and a transactional outbox for external dispatch and notification. The exact database engine, schema, and deployment location remain unselected.

For a new risk-increasing intent, the intended local transaction is:

1. Check that the authorization is still valid and matches the intended instrument, side, quantity/notional, mode, and configuration.
2. Reserve the corresponding internal exposure so concurrent decisions cannot spend the same risk capacity.
3. Write the durable intent and unique client identifier.
4. Write an outbox dispatch record.
5. Commit locally.
6. Only then perform the external exchange write.

The exchange call cannot participate in the local database transaction. Therefore, a crash, timeout, or lost response after dispatch may leave external state uncertain. The system must preserve that uncertainty and reconcile; it must not blindly resubmit.

C11 reports that the supported `clientOrderId` character set is `[A-Za-z0-9_-]` and that identifiers must not be reused within the supported scope. The implementation must enforce that reported constraint and independently validate it against the actual endpoint and applicable scope before use; this engagement did not inspect or call that endpoint.

## 6. Interface contracts

Interfaces below are logical contracts. They do not assert that a particular Toobit API endpoint or field exists.

### 6.1 Common envelope

Every durable event or request should include, as applicable:

- Unique event/request identifier and schema version.
- Source module and source tier.
- Contract identifier and timeframe, where relevant.
- UTC event/decision/receipt timestamps with their semantics.
- A local monotonic timestamp for elapsed-time measurement where needed.
- Configuration, strategy, and data versions or hashes that influenced the decision.
- Correlation/trace identifier and validation outcome.

An event without sufficient identity, time, or source provenance is not silently upgraded to a trusted record.

### 6.2 Core interfaces

| Interface | Producer → consumer | Required semantics |
|---|---|---|
| **Command envelope** | Telegram adapter → control authority | Parsed command type, command ID, sender/context evidence, receipt time, requested scope, and idempotency key. Treat input as untrusted until the authority validates it. The complete command contract is in Part 7. |
| **Market-data observation** | Venue/provider adapter → ingestion/validation | Raw payload reference, source/venue, contract, interval/event ID, source timestamp, receive timestamp, sequence where applicable, and source tier. Preserve raw evidence and reject/flag invalid data rather than silently repairing it. |
| **Valid data view** | Data store/universe catalog → strategy and risk | As-of time, completed-bar status, quality/freshness status, point-in-time universe and contract metadata, source tier, and lineage. A missing or stale required input produces an invalid view, not a synthetic pass. |
| **Strategy proposal** | Strategy engine → risk authority | Signal ID, strategy/config version, contract, direction, proposed entry/exit conditions, intended quantity basis or sizing inputs, signal time, and complete input lineage. It is not an order and grants no execution right. |
| **Risk request** | Strategy/controller → risk authority | Proposed intent, position/order snapshot version, mode, current data validity, contract metadata, and requested risk scope. Do not omit possible fills or unresolved orders. |
| **Risk authorization/denial** | Risk authority → OMS | Authorization ID; exact contract, side, quantity/notional bounds, mode, intent and strategy version, current risk-state/config version, data lineage, scope, UTC expiry, and permitted operation. A denial returns a reason code. New exposure cannot exceed the authorization. A reduce-only authorization cannot be reused to increase exposure. |
| **Order intent** | OMS → durable store/outbox | Unique intent ID, authorization reference, client-order identifier, exact requested operation, and complete audit context. Commit before external dispatch. |
| **Execution request** | OMS → mode-specific execution adapter | Only a committed intent and valid scope-matched authorization. The adapter is selected from the persisted mode, not a Telegram message or strategy request. |
| **Execution observation** | Exchange/Paper adapter → OMS | Raw response/event, source, exchange order/client ID where available, exchange and receipt times, and status evidence. Any non-final or ambiguous outcome remains pending/unknown. |
| **Reconciliation snapshot** | Reconciler → risk authority/control | As-of time, source coverage, observed orders/positions/balances, matched local intents, unresolved differences, and completeness state. An incomplete or inconsistent snapshot cannot establish “no exposure.” |
| **Audit/notification event** | All modules → journal/notifier | Stable event ID, actor or module, before/after references, UTC time, decision/result, and source provenance. Notification failure does not roll back a committed safety decision. |

### 6.3 Authorization as a bounded capability

A simple `allowed=true` flag is insufficient. A future authorization should be non-transferable within the application’s logical model and bound to:

- One intent and one contract.
- A defined operation, side, and maximum size.
- The operating mode and strategy/configuration version.
- The risk-state snapshot on which it was based.
- The data/metadata versions and source tiers required by the decision.
- A short, measured validity interval and one-use behavior.
- A stated purpose—new exposure, reduce-only, or other specifically authorized lifecycle action.

The numeric risk limits and validity duration are not selected here. If the risk state or applicable data changes between authorization and dispatch, the OMS must revalidate or reject and request a new decision.

## 7. Mode separation and Live interlocks

### 7.1 Separate selected mode from execution permission

Maintain two separate concepts:

1. **Selected operating mode:** `RESEARCH`, `PAPER`, or `LIVE`.
2. **Current execution gate:** for example, `DISABLED`, `ENTRY_BLOCKED`, `RISK_REDUCTION_ONLY`, or `ENTRY_ALLOWED`.

The names are a proposed internal vocabulary, not a defined exchange class. A selected `LIVE` mode **does not imply** that new orders may be sent. Each order still requires current risk authorization and applicable data, reconciliation, configuration, clock, and venue checks. A control-mode switch cannot bypass the risk authority.

- Research uses its own historical-data and simulation path; it cannot submit exchange orders.
- Paper uses an isolated, non-live execution adapter. Its fills and results are simulated under a versioned model and cannot authorize Live actions.
- Live uses the Toobit adapter only when all relevant controls pass. No Live adapter was used in this engagement.
- The same strategy code may be evaluated across modes only if source tiers, state, credentials, execution adapters, and audit records remain separated.

### 7.2 The six Live-selection interlocks

The A10 Live selector must evaluate all six required interlocks. Each must be explicitly **PASS** for the applicable scope; unknown, stale, untested, or inconsistent is not a pass.

| Interlock | Architectural owner | Part 6 interpretation |
|---|---|---|
| **Data validity** | Data/universe services and health supervisor | Required source is permitted, fresh by a measured rule, correctly timestamped, complete enough for the decision, and validated for the target contract/timeframe. |
| **Reconciliation** | Reconciler | Relevant positions, orders, and account state are reconciled; no unknown order or exposure is silently assumed absent. |
| **Risk-limit definition and bounds** | Risk/config authority | Approved limits and their calculation basis exist, are internally consistent, and bound the proposed action. **Currently blocked:** owner risk boundary remains pending. |
| **Credential/permission validity** | Future Live execution adapter and security boundary | Credential presence, scope, permission, and validity are checked without exposing secrets to Telegram, strategy, or logs. **Not tested:** no credential or account access occurred. |
| **Configuration integrity** | Control/config authority | The exact approved configuration and code identity are intact, versioned, and match the intended Live scope. No implementation check was run here. |
| **Clock validity** | Clock/health supervisor | UTC time is within a measured and configured validity bound; monotonic deadlines are functioning. No clock test was run here. |

No arbitrary waiting period or profit hurdle is added. The six interlocks do not imply that any one has passed. Because risk-limit definition and bounds are unresolved—and the others have not been implementation-tested—**this design makes no Live-readiness claim**.

Part 7 will specify command-specific preconditions; a command must not be burdened with a check that cannot be evaluated in its context. Part 8 will define operational clock, credential, security, and recovery checks.

## 8. End-to-end flows

### 8.1 Startup and recovery

1. Load the last durable configuration and mode record; verify schema, version, and integrity.
2. Recover the journal, reservations, intents, and outbox. Do not interpret an incomplete replay as a clean account.
3. Validate UTC-clock status and start monotonic deadline tracking.
4. Start source, data-quality, and component-health checks.
5. For a future Live session, obtain current exchange observations and reconcile open orders, positions, and balances before allowing new exposure. Unknown or conflicting state leaves the execution gate blocked.
6. Preserve the last selected mode, but do **not** automatically enable new risk after a restart. Re-evaluate interlocks and per-order gates.
7. Attempt Telegram notification of recovered status. Failure to deliver the message does not stop reconciliation or change external state.

The exact startup reconciliation protocol and exchange query coverage remain unresolved until actual interface semantics are independently validated.

### 8.2 Completed bar to candidate order

1. Ingest and preserve the raw bar and source/receipt timestamps.
2. Validate contract, interval, bar finality, price/volume shape, continuity, source tier, and data freshness.
3. Publish a valid as-of view only when the completed 1h bar is eligible. Do not substitute another interval or venue.
4. The strategy engine computes a versioned proposal from that view. It does not send a request to an exchange adapter.
5. Risk authority checks mode, approved risk configuration, valid contract mechanics, reconciled position/order state, existing reservations, current data validity, and liquidity/cost constraints.
6. If denied, persist the reason and do not create a risk-increasing exchange intent.
7. If authorized, reserve the risk and persist the intent/outbox atomically.
8. The OMS verifies the authorization’s scope and age and dispatches through only the adapter for the selected mode.
9. The OMS records the external observation. It treats ambiguous results as unknown and reconciles before taking another action that could duplicate or worsen exposure.

Part 7 supplies the full order state machine; this flow does not replace it.

### 8.3 External updates and reconciliation

1. Collect exchange order, fill, position, and account observations through permitted interfaces.
2. Preserve raw observations with their source timestamps, receipt times, and identifiers.
3. Match observations to committed local intents and identifiers without assuming that every exchange event is delivered once or in order.
4. Update the local projection idempotently; retain unmatched or conflicting observations as discrepancies.
5. Recompute exposure and reservations from the best validated state. If coverage is incomplete or uncertainty remains, block new risk-increasing actions and retain conservative reservations.
6. Send a concise state update through Telegram when available. A notification is not a reconciliation result.

C5 reports `-1007 TIMEOUT` as ambiguous and `-1003` as the reported rate-limit breach. An ambiguous response is therefore modeled as an unresolved operation; the transport retry policy cannot convert it to rejection by assumption. Rate-limit budgets must be explicit because C4 reports missing `X-Api-Limit-*` headers in the tested environment.

### 8.4 Telegram commands and mode changes

1. The adapter receives and parses a message but grants it no direct execution authority.
2. The control authority validates the command’s identity/context, syntax, idempotency, requested scope, current mode, and command-specific preconditions.
3. A mode-change request updates durable control state only after the applicable checks pass. No order is submitted merely because mode changed.
4. A Live selection evaluates A10’s six interlocks. Every later order remains subject to fresh per-order checks.
5. Return a structured `received`, `accepted`, `rejected`, or `pending` result as appropriate. Do not report an exchange fill from the command acknowledgement.
6. Record the request and outcome in the durable audit trail. Send a notification through the same Telegram interface.

Telegram authentication and transport protections are security topics for Part 8. They do not transform Telegram into a safety authority or replace independent checks in control, risk, and OMS modules.

### 8.5 Operator unreachable or Telegram unavailable

**DESIGN_JUDGMENT — provisional safe behavior:**

- Detect a Telegram **transport health failure** using a measured/configured threshold. An absence of user messages alone does not prove the operator or Telegram is unreachable; it must not trigger repeated alerts or automatic mode changes.
- Continue independent data-quality, reconciliation, risk-monitoring, and already authorized position-management loops. Do not wait for an operator reply to perform a preauthorized safety action.
- Block new risk-increasing entries while the command channel is unavailable, unless a separately approved and explicitly configured unattended policy later permits them. **Until such a policy is defined and approved, the default is block new entries.**
- For known, outstanding risk-increasing entry orders, apply the configured safe policy—provisionally request cancellation when entries are blocked. Do not mark the order canceled until the exchange provides confirming evidence. Preserve its risk reservation while status is unknown.
- Do not routinely cancel protective/reducing orders or close an open position solely because Telegram is unavailable. Continue the position’s already authorized exit and risk-reduction policy.
- If order or position state is uncertain, do not submit speculative duplicate actions. Reconcile and preserve the worst plausible exposure until resolved.
- When Telegram returns, report the current reconciled state and any unresolved items. Do not auto-enable new entries merely because connectivity recovered; require the applicable gate and operator command.

The transport-failure threshold and whether any future unattended Live policy is acceptable remain unresolved. The design’s immediate safe default is nonetheless explicit: **do not add new exposure, do not abandon existing safety management, and do not equate communication failure with exchange-state resolution.**

## 9. Failure containment

| Failure | Required system response |
|---|---|
| Invalid, stale, incomplete, or source-disallowed market data | Block new signals that depend on the affected data; retain evidence; never forward-fill or silently switch source/timeframe. |
| Missing/contradictory contract metadata | Exclude the contract and block dependent sizing/execution. |
| Stale or incomplete reconciliation | Block new risk; retain plausible exposure and unresolved orders; continue bounded reconciliation. |
| Ambiguous exchange write response | Preserve the intent and reservation; do not blind-retry; reconcile using the validated identifiers and available state. |
| Risk/configuration state unavailable or inconsistent | Deny new exposure. Do not use a strategy parameter or Telegram command to supply an implicit limit. |
| Database/journal not durable or recovered consistently | Block new risk-increasing writes. Do not reconstruct a false “flat” state from missing local records. |
| Clock invalid or outside its verified bound | Fail the clock interlock and block time-sensitive new exposure. Any safe management action must use a validated timing basis. |
| Telegram transport unavailable | Apply Section 8.5. Safety loops continue; operator commands are unavailable; no new risk by default. |
| Notification delivery failure | Record delivery failure and continue the committed risk/order/reconciliation process. |
| Paper/Live source-tier mismatch | Reject the data view or intent before it reaches the Live adapter; record the violation. |

These are design responses, not observed recovery outcomes. Part 8 will turn them into operational recovery procedures and measurable service/recovery bounds.

## 10. Material decisions and reversibility

| Decision | Rationale and status | Credible alternative | Reversibility |
|---|---|---|---|
| PT-02 modular monolith as the initial logical baseline | Keeps risk, order, data, state, and Telegram boundaries inspectable without assuming distributed infrastructure. Provisional; no topology has passed envelope fit. | PT-01 single script is simpler but weakens boundary enforcement; PT-03 distributed services may improve isolation or scaling if justified. Both were already cataloged in Part 3. | REVERSIBLE before interfaces and persistence exist; COSTLY_REVERSIBLE after state and module contracts are implemented. |
| One durable transactional boundary plus append-only audit and outbox | Reduces the gap between local reservation and dispatch intent while retaining a simple baseline; external exchange calls remain non-atomic. | Separate event-log-only or distributed/event-bus architecture. Greater complexity is not justified by current measured workload. | COSTLY_REVERSIBLE after persistence and recovery behavior are implemented. |
| OMS as sole exchange writer, requiring scoped authorization | Prevents strategy, Telegram, and reconciliation code from directly creating exposure; enables idempotency and audit at one boundary. | Multiple writers or direct strategy-to-exchange access are simpler initially but weaken safety and traceability. | Safety invariant; changing it requires explicit hazard review and re-verification. |
| Separate selected mode from actual execution permission | Prevents a Paper/Live label from bypassing dynamic interlocks or per-order risk checks. | A single binary mode variable is simpler but conceals blocked/reconciling states. | REVERSIBLE before control-state implementation; change requires state migration and regression testing later. |
| Telegram remains the sole operator interface and non-authoritative | Preserves A2 without making an unreliable transport a safety dependency. | Add another routine UI or make Telegram the execution/risk authority—both conflict with the binding constraints. | Binding interface constraint; not relaxed by convenience. |
| Freeze new risk on Telegram transport loss; preserve open-position management and unresolved risk | Addresses A9 without assuming reliable inbound connectivity or abandoning positions. | Continue autonomous entries while operator contact is lost, but only under a separately approved and tested unattended policy. | PROVISIONAL and reversible before Live; the active policy must be explicit in configuration. |
| Fail closed on source, clock, configuration, reconciliation, or intent ambiguity | Missing evidence cannot safely authorize new exposure. | Continue by imputation or blind retries—rejected because these can conceal missing or duplicate exposure. | Safety/data-integrity invariant; any narrow exception requires scope-specific evidence and review. |

## 11. Part 6 handoff

ART-08 establishes logical component boundaries, state ownership, typed interaction contracts, mode separation, and end-to-end flows. It also defines the proposed behavior when Telegram is unavailable. It does **not** provide the complete order state machine, all command-specific Telegram preconditions, API mapping, credential design, topology fit, implementation, tests, or Live authorization.

The design preserves the outstanding blockers: exact contract and interface semantics; per-symbol data coverage; reconciled risk and account inputs; the owner’s risk decision; unmeasured clock, storage, and device behavior; and implementation proof of these boundaries.

**Registry update:** ART-01 through **ART-08 DELIVERED**; ART-09 through ART-12 remain **DEFERRED**. The engagement-level completeness declaration remains reserved for Part 10.


وضعیت: **بخش ۷ از ۱۰ — مرجعیت ریسک، چرخهٔ سفارش و قرارداد فرمان‌های Telegram، ART-09، تکمیل شد.** مرز ریسک همچنان **OWNER_DECISION_PENDING** است؛ بنابراین در این طرح هیچ سفارش افزایشی مجاز یا حد ریسکی انتخاب نشده است. ماشین حالت زیر مشخصات طراحی است، نه پیاده‌سازی یا آزمون رفتار Toobit. هیچ حساب، اعتبارنامه، API احراز هویت‌شده یا سفارش واقعی استفاده نشده است.

# Part 7/10 — Risk Authority, Order Lifecycle, and Telegram Command Contract (ART-09)

## 1. Scope and binding rules

This part specifies who may authorize risk, how order intent and uncertain exchange outcomes are represented, and the proposed Telegram command surface.

It carries forward:

- **A1:** Toobit remains the selected Live venue.
- **A2:** Telegram is the sole operator interface, but neither a safety authority nor, by itself, a trust boundary. No dashboard, second bot, or parallel routine operator console is added.
- **A3:** UTC is authoritative for recorded instants and calculations; monotonic time is used for elapsed deadlines.
- **A4:** This engagement is design-only. No account access, credentials, authenticated calls, or order actions occurred.
- **A5:** Cross-venue data remains gated away from Paper/Live unless applicable legal, access, cost, licensing, and owner-approval conditions are met.
- **A9:** Telegram loss must not stop independent safety and reconciliation processes or be treated as resolution of an ambiguous exchange result.
- **A10:** A Live-mode selection must enforce all six required interlocks without an arbitrary waiting period or profit hurdle. Each command has only the preconditions relevant to that command.
- **A12:** Technical methods are delegated; unresolved owner decisions are not silently replaced by engineering assumptions.

The owner’s risk boundary remains **OWNER_DECISION_PENDING**. As a result, this design does not authorize Live risk-increasing orders and does not select a per-trade, aggregate, daily-loss, drawdown, leverage, or liquidation threshold. Part 5’s sensitivity calculations are not order authorization.

## 2. Authority model

### 2.1 Risk-increasing actions versus risk-reducing actions

The risk authority classifies an operation by its **possible effect on exposure**, not by its command name.

| Operation class | Example | Required authority |
|---|---|---|
| **Risk-increasing** | New entry, new order that can increase absolute position exposure, replacement that might increase exposure | Current, scope-matched affirmative risk authorization, backed by an approved risk configuration and valid data, contract, and reconciled state |
| **Potentially risk-reducing** | Cancel a verified, working entry order; reduce a verified position | Exact-target authorization and verified evidence that the action cannot increase exposure under the venue’s semantics |
| **Ambiguous or potentially exposure-changing** | Cancel a protective exit; amend/replace an order; close a position without verified reduce-only semantics; act on an unknown order | Deny or hold until the exact state and effect are established; no generic override |
| **Read-only** | View status, order projections, or risk configuration; request reconciliation reads | No trading authorization, although applicable access, freshness, and privacy controls still apply |

A strategy proposal, Telegram command, mode label, accepted request, or local journal entry is **not** a risk authorization. The authorization comes from the risk authority and is enforced by the OMS described in Part 6.

### 2.2 Bounded authorization

A future risk authorization must be bound to:

- A single intent, contract, direction, and operation class.
- Maximum permitted quantity and notional under verified contract rules.
- The approved risk-configuration and portfolio-state versions used to calculate it.
- Required data, metadata, and source lineage.
- The selected operating mode.
- A measured expiry and one-use policy.
- A declared purpose: **risk-increasing**, **cancel entry**, or **reduce-only**.

A generic `allowed=true` flag is insufficient. A stale, consumed, mismatched, or expired authorization cannot be reused. The quantity sent by the OMS cannot exceed its scope. If relevant state changes between authorization and dispatch, the OMS must revalidate or refuse the dispatch.

Because the owner risk boundary remains pending, the Live risk configuration is presently incomplete. **A Live-mode selection and any Live risk-increasing action therefore fail their risk interlock in this design.**

### 2.3 Reservations and open-risk accounting

When a risk-increasing intent is durably committed, the risk authority reserves its possible exposure before the OMS performs an external write. It must also count existing positions, other open orders, and unresolved orders.

For a partially filled order, do not count both the full initial order and its fills as separate full exposures. Track:

\[
\text{possible exposure}
=
\text{risk of reconciled filled position}
+
\text{risk of the still-executable remainder}
+
\text{other open or unresolved exposure}.
\]

For an ambiguous result, use the greatest plausible exposure consistent with the available evidence. Keep the reservation until reconciliation supports its release or conversion to actual position risk. A pending cancellation does not itself eliminate the order’s potential exposure.

This is an accounting rule, not a selected numeric limit. The equations and distinct risk measures are specified in Part 5.

## 3. Internal order model

### 3.1 Keep four kinds of state separate

A single status field would conflate intent, exchange outcome, cancellation, and reconciliation. The OMS therefore keeps separate state dimensions.

1. **Intent lifecycle:** what the system proposed, authorized, persisted, or attempted.
2. **Venue observation:** what the exchange has been observed to report about the order.
3. **Cancel operation:** whether a cancellation was requested and what is known about it.
4. **Reconciliation state:** whether observations match the intent, fills, and position projection.

The names below are the proposed **normalized internal vocabulary**. They are not claims about Toobit’s raw API status names or endpoint behavior.

### 3.2 Lifecycle diagram

```text
STRATEGY PROPOSAL
       │
       ├── risk/validation denial ───────────────▶ DENIED (no external write)
       │
       └── risk authorization + reservation
                          │
                          ▼
                 DURABLY COMMITTED
                          │
                          ▼
                  DISPATCH STARTED
                    │          │
     verified outcome          └── timeout, crash, lost/mismatched response
          │                                 │
          ▼                                 ▼
  accepted/open/filled                  OUTCOME UNKNOWN
          │                                 │
          ├── fills/terminal status ◀───────┘
          │                  after reconciliation
          ▼
   reconciled projection

For an observed open or partially filled order:
  cancel request → cancellation pending → confirmed / rejected / unknown
                                  │
                                  └── fills may still arrive during the race
```

A cancellation is an operation on an existing order, not proof that the order is canceled. Position state is derived from fills and reconciliation, not from the cancel acknowledgement.

### 3.3 Intent and venue-state transitions

| Stage or event | Permitted transition | Required evidence and behavior |
|---|---|---|
| Strategy creates a proposal | `PROPOSED` | Proposal carries strategy/config version, signal time, contract, direction, sizing inputs, and source lineage. It creates no order and reserves no exchange outcome until risk evaluates it. |
| Risk or data check fails | `PROPOSED → DENIED` | Record denial reason and relevant state versions. Do not create an external order or present the proposal as authorized. |
| All checks pass | `PROPOSED → AUTHORIZED` | Issue a bounded authorization. For risk-increasing Live orders this requires a complete, approved risk configuration; that condition is currently unmet. |
| Intent and reservation are durably persisted | `AUTHORIZED → COMMITTED` | Write the immutable core intent, reservation, client identifier, audit record, and dispatch outbox before network I/O. |
| Network dispatch begins | `COMMITTED → DISPATCH_STARTED` | Persist the dispatch-start event before calling the adapter. A crash afterward may leave the external result uncertain. |
| Verified exchange acknowledgement | Venue observation becomes `ACKNOWLEDGED` or `OPEN` | Parse the raw exchange response with a validated adapter mapping. Acceptance is not a fill; retain the reservation. |
| Valid fill event | `OPEN/ACKNOWLEDGED → PARTIALLY_FILLED` or `FILLED` | Store the individual fill and cumulative executed quantity. Deduplicate fills using validated event/trade identifiers; preserve the raw observation. |
| Timeout, process crash, lost response, or untrusted/mismatched response | Venue observation becomes `UNKNOWN` | Do not infer rejection. Retain the reservation, block conflicting new exposure, and reconcile. |
| Verified terminal exchange outcome | Venue observation becomes `FILLED`, `CANCELED`, `REJECTED`, or `EXPIRED` | A terminal order state means no remaining executable quantity only when the venue semantics and observation are validated. It does not, by itself, prove the account is flat. |
| Conflicting identifier, quantity, status, or sequence | Reconciliation becomes `DISCREPANT`; venue observation may become `UNKNOWN` | Preserve all raw evidence and block affected new risk until resolved. Do not apply “last write wins.” |

For a partially filled order that is later canceled or expires, retain both its terminal venue status **and its actual cumulative filled quantity**. For example, `CANCELED` with a nonzero filled quantity means the unfilled remainder is canceled; it does not undo the filled position.

### 3.4 Cancellation state and fill races

Cancellation has its own lifecycle:

```text
NONE
  → CANCEL_REQUESTED
  → CANCEL_DISPATCHED
  → CANCEL_CONFIRMED | CANCEL_REJECTED | CANCEL_UNKNOWN
```

- The order may fill, or partially fill, while cancellation is pending.
- `CANCEL_REQUESTED` or a locally successful API call does not mean the exchange has canceled the order.
- If the cancel response is lost, retain the order’s possible remaining exposure and reconcile.
- On confirmed cancellation, reconcile cumulative fills and the resulting position before releasing any residual reservation.
- A cancellation rejection leaves the order in the last externally evidenced order state; it does not make the order terminal.
- Only one unresolved cancellation action per order is permitted. Do not issue repeated cancellation writes while the first result is unknown.

By default, the operator may request cancellation only of a **known, risk-increasing entry order**. Canceling a protective or reducing order can increase risk and is not allowed through the ordinary `/cancel` command. Replacing protective orders is not in the initial command surface.

### 3.5 Reconciliation is an independent state

Use explicit reconciliation states such as:

- `PENDING` — the required external view is incomplete or still being obtained.
- `MATCHED` — validated observations are consistent with the internal intent, fills, and position projection for the defined scope.
- `DISCREPANT` — observations disagree, are incomplete, or cannot be attributed safely.
- `RESOLVED` — a discrepancy has been closed with recorded evidence and an accountable decision.

A terminal order response with a pending or discrepant reconciliation remains subject to the conservative risk policy. A local journal entry proves that the system recorded an intent; it does not prove that Toobit accepted, canceled, or filled it.

### 3.6 Position state is not order state

Position state is projected separately from order state, based on validated fills and reconciled exchange observations. At minimum, distinguish:

- `FLAT_CONFIRMED`
- `OPEN`
- `REDUCING`
- `FLAT_UNCONFIRMED`
- `UNKNOWN_EXPOSURE`
- `DISCREPANT`

A filled exit order alone does not prove the position is flat. An outside-the-system position or order is not ignored; it is an external discrepancy until reconciled and explicitly handled. Where account observations are incomplete, do not infer “no position” from a missing local order.

### 3.7 Amendments and linked/protective orders

- **In-place amendment is not supported in the baseline.** Treat a change in price or quantity as a separate cancellation and new-order sequence.
- A replacement requires cancellation to be confirmed and reconciled before a new authorization and intent are created. If the original order is unknown or may still be active, do not submit its replacement.
- C11 reports a supported `clientOrderId` character set of `[A-Za-z0-9_-]` and non-reuse within the supported scope. The actual endpoint’s identifier length, scope, lookup behavior, and duplicate-request semantics remain unverified.
- Do not assume exchange-native OCO, atomic brackets, `reduceOnly`, or close-position behavior until each relevant Toobit contract and endpoint semantics are independently validated. Multiple protective orders must not be assumed mutually exclusive.
- Any exit path must prevent a stale or duplicate close order from reversing a position. If this cannot be demonstrated from verified venue semantics, disable that execution path.

## 4. Ambiguous responses, retries, and recovery

### 4.1 Exchange uncertainty is not a negative outcome

C5 reports that `-1007 TIMEOUT` is ambiguous and does not prove rejection; `-1003` is the reported rate-limit breach code. C4 reports that `X-Api-Limit-*` headers were absent in the tested environment. These are **OWNER-SUPPLIED FINDINGS**, not exchange behavior independently tested in this engagement.

Therefore:

1. Treat a timed-out, lost, or inconsistent order response as `UNKNOWN`, not `REJECTED`.
2. Do not submit another risk-increasing order just because the first response did not arrive.
3. Reconcile using verified identifiers and available read paths. Do not assume client-ID lookup, retention, or exchange idempotency until verified.
4. If a response reports a rate limit, apply a finite, explicit rate-budget/backoff policy; do not rely on absent headers or retry indefinitely.
5. Release a reservation or authorize a replacement only when validated evidence establishes the prior order’s relevant state and no delayed acceptance remains plausible under verified venue semantics.
6. On restart, recover all committed, dispatched, cancel-pending, and unknown records before allowing new risk-increasing orders.

At-most-once external submission cannot be proven across a local database transaction and a remote exchange write. The design therefore uses a durable intent, a unique identifier, cautious dispatch, and reconciliation—not a claim of “exactly once.”

### 4.2 Identifiers and idempotency

Generate a new, non-reused client identifier for each distinct order intent, using only the C11-reported character set and any subsequently validated venue length constraint. Persist the mapping among:

- Internal intent ID.
- Client-order identifier.
- Exchange order identifier, when actually observed.
- The relevant command and authorization IDs.

Do **not** assume that a unique client identifier automatically makes repeated submissions idempotent. Verify that behavior before relying on it. If a user repeats a Telegram command, deduplicate delivery of the same command and return its existing state; a new command is not permission to duplicate a pending exchange action.

### 4.3 Bounded recovery and retention

Read-only queries and reconciliations may use finite, configured retry budgets. An order create, cancel, or close operation whose outcome is unknown must not be blindly retried.

C12 says that maximum safe outage duration depends on undocumented exchange retention. Its provisional three-day threshold applies to **reconciliation deferral only**; it does not prove three days of exchange-history retention or a safe maximum outage. If a discrepancy remains deferred to that threshold, escalate and keep new risk blocked. Missing history after an outage does not prove that no order or fill occurred.

### 4.4 What counts as “complete”

An order is considered **internally complete for the intended operation** only when:

- The relevant exchange outcome is evidenced under a validated mapping.
- Cumulative fills and remaining quantity are accounted for.
- The relevant position/exposure projection is reconciled.
- No unresolved cancellation, duplicate submission, or conflicting event remains for that operation.

Any Telegram status sent before those conditions are met must say `PENDING`, `UNKNOWN`, or an equivalent precise status—not “filled,” “canceled,” or “successful.”

## 5. Telegram command contract

### 5.1 Common command rules

Telegram remains the **only operator interface**. It is a transport for requesting a command; it does not make the request safe or authoritative.

Before any mutating command is enabled, the future implementation must provide an application-level authorization and message-integrity policy independent of trusting a Telegram display name or message text alone. Part 8 covers the security design. If that policy, durable audit, or command deduplication is unavailable, mutating commands remain disabled. No credentials or secrets may be sent in a Telegram command or echoed into a response.

Each command must:

- Match an explicitly supported grammar and exact scope; malformed or unsupported text has no side effect.
- Be attributed to a verified operator context under the future security policy.
- Have a durable command ID and audit result; duplicate delivery of the same command must not repeat its side effect.
- Record its receipt and decision time in UTC, and use monotonic time for elapsed deadlines within a running process.
- Return a precise result: `RECEIVED`, `ACCEPTED`, `BLOCKED`, `REJECTED`, `PENDING`, `PARTIAL`, or `COMPLETED`.
- Avoid treating `ACCEPTED` as an exchange acknowledgement or fill. Use `COMPLETED` only after the relevant external outcome is evidenced and reconciled.

For stale read-only views, report the as-of time and freshness. A state-changing command that arrives after its configured validity window, or against a changed state, must be revalidated or rejected. The relevant age bounds require measurement; no arbitrary duration is asserted here.

### 5.2 Supported command surface

The following is the **proposed initial grammar**, not a claim that a bot has been implemented.

| Command | Purpose and side effects | Command-specific preconditions |
|---|---|---|
| `/help` | Lists supported commands, blocked commands, and their effects. Read-only. | Syntax and response authorization only. No data, reconciliation, or Live interlock is needed to return help. |
| `/status` | Reports selected mode, entry gate, data/clock/health status, reconciliation freshness, open/unknown orders, known positions, and risk-config status. Read-only. | Read a consistent local snapshot if available; label stale or unknown information explicitly. It must not wait for, or pretend to perform, a complete exchange reconciliation. |
| `/orders` or `/orders <local_order_ref>` | Displays the local order projection, including raw-versus-normalized status, cumulative fills, cancellation state, reconciliation state, and as-of time. Read-only. | A missing or stale projection is reported as such. No order is sent or canceled. |
| `/risk show` | Displays the active risk-profile version and each configured value/status. If absent, explicitly reports `OWNER_DECISION_PENDING`; no implicit defaults. Read-only. | Read the current risk configuration/projection. No Live interlock is needed to reveal that a limit is unset. |
| `/mode research` | Selects Research for new work. No exchange order is sent. | If leaving a Live session, current reconciliation must confirm no live position, open order, pending cancel, or unknown exposure. Do not abandon Live management through a mode switch. |
| `/mode paper` | Selects the isolated Paper execution path. No Live order is sent. | If leaving Live, require the same confirmed absence of Live obligations as above. Paper state is separately versioned and must not be converted to or represented as an exchange position. Selecting Paper alone does not validate data or enable simulated orders. |
| `/mode live` | Requests selection of Toobit Live mode. It does not itself submit an order. | All six A10 Live interlocks must pass for the applicable scope: data validity, reconciliation, risk-limit definition and bounds, credential/permission validity, configuration integrity, and clock validity. If any is unknown, stale, inconsistent, or blocked, leave the prior mode unchanged and report the failed interlock. **Risk limits are presently pending, so this command cannot pass under the current design.** No arbitrary wait period or profit hurdle is imposed. |
| `/pause entries` | Durably blocks new risk-increasing strategy intents. | Requires a valid command and durable state change. It remains admissible when market data, reconciliation, or other Live gates fail; pausing does not need those sources to be healthy. It does not claim to cancel previously submitted orders; report known working or unknown entry orders. |
| `/pause entries cancel-working` | Blocks new entries and requests cancellation of verified working risk-increasing entry orders within the exact local scope. | In addition to the pause preconditions, each target must be positively identified and currently evidenced as cancellable. Do not cancel a protective/reducing order. Do not blindly cancel an unknown order; reconcile first. A pending or ambiguous cancellation remains pending and retains its reservation. |
| `/resume entries` | Clears the operator’s entry-pause latch; it cannot clear unrelated safety blocks. | In Paper, require an isolated, versioned simulation configuration and valid required Paper inputs. In Live, require the applicable six interlocks, current validated data, complete relevant reconciliation, intact configuration, valid clock and permissions, and no unresolved order/exposure conflict. The risk authority then evaluates each proposed order independently. It cannot resume Research order flow or override a fault latch. |
| `/reconcile` or `/reconcile <exact-contract-id>` | Requests a bounded, read-only refresh of exchange orders, fills, positions, and other required state. It does not create, cancel, or alter an order. | Requires an available, permitted read path and budget for the requested scope. If data, timing, or coverage is insufficient, report an incomplete reconciliation, not a clean state. An already-running request should be reported as `PENDING` rather than duplicated. |
| `/cancel <local_order_ref>` | Requests cancellation of exactly one known, working **risk-increasing entry** order. | Require an unambiguous local reference, current evidence that the order is still open/partially filled, applicable cancellation permission, and no unresolved cancellation for the same order. Reject stale/unknown targets and protective or reducing orders. A partial fill remains a position after the unfilled remainder is canceled. |
| `/close <exact-contract-id>` | Requests a full reduction of the reconciled position in exactly one contract. No wildcard/all-contract action is implied. | Require a current reconciled position, verified contract mechanics, no conflicting ambiguous entry/exit order, a validated execution policy, and verified venue reduce-only/close-position behavior that cannot increase or reverse exposure. Authorize only the current position quantity. If any condition is absent, block the command; do not guess the side, size, price, or order semantics. |

**`/mode live` interlock note:** the six checks govern Live selection; they do not replace the command’s other scope and state checks, nor per-order risk authorization. The mode selector adds no minimum Paper duration, backtest profit hurdle, or arbitrary cooldown. The status of every interlock must be evaluated, not assumed.

**Entry-pause note:** a pause blocks new risk-increasing intents immediately. An already submitted order may still fill unless its cancellation is confirmed. Therefore `/pause entries` reports outstanding orders rather than implying exposure has been removed.

### 5.3 Risk-profile changes

The owner has not selected the risk boundary, so a working command that changes or invents numeric limits is not defined.

A **future, currently disabled** command may be introduced as:

```text
/risk apply <approved-profile-id>
```

If enabled later, it must select only a validated, immutable, owner-approved profile. It must not accept an arbitrary free-text risk percentage or let the strategy tune its own limits. The application must evaluate existing positions and pending/unknown orders against the proposed profile, retain a record of the prior profile and decision, and block new risk if state or bounds are inconsistent. If tighter bounds are violated, the system must apply only an explicitly authorized risk-reduction policy; it must not silently force-close a position. The profile identifier format, authorization path, owner-defined contents, and complete behavior remain unresolved.

### 5.4 Unsupported commands and deliberate omissions

The initial contract does **not** offer:

- A manual risk-increasing order command.
- `/force`, `/ignore-gate`, or a command that bypasses risk authority.
- An arbitrary `/risk set` command.
- In-place order modification or automatic cancel-and-replace.
- `/cancel all` or `/close all`.
- A command that marks an unknown order rejected, manually asserts the account is flat, or clears a reconciliation discrepancy without evidence.

These omissions constrain accidental scope and preserve exact target selection. Any later addition requires a new hazard review, explicit command grammar, authorization and precondition analysis, and regression tests.

## 6. Operator unreachable or Telegram unavailable

### 6.1 Distinguish transport failure from operator silence

A lack of inbound messages does **not** prove that the operator is unreachable. The system must not infer unavailability solely from silence, or send repeated escalating alerts because the operator did not answer.

A future health monitor may classify the command/notification transport as `HEALTHY`, `DEGRADED`, or `UNAVAILABLE` using measured, configured tests. The exact outage-detection threshold is not measured here. A human’s non-response to an informational notification does not authorize a mode change or an order.

### 6.2 Provisional unattended safety policy

**DESIGN_JUDGMENT — provisional default consistent with A9:**

When a verified Telegram transport outage or an explicitly defined operator-unreachable state is detected:

1. Latch **new risk-increasing entries blocked**. Do not treat the communications failure as an exchange or position event.
2. Continue the independent risk-monitoring, reconciliation, and already authorized position-management processes. Do not wait for Telegram confirmation to execute a previously approved risk-reducing action.
3. For a known working risk-increasing entry order, request cancellation under the validated cancellation path. Do not cancel protective or reducing orders just because Telegram is unavailable.
4. For an order whose submission or cancellation result is unknown, preserve the reservation and reconcile. Do not blind-resubmit, declare rejection, or assume the order is absent.
5. Continue the existing position’s preauthorized exit and protection policy. Do **not** automatically close an open position solely because the operator cannot be reached.
6. If an execution or protective-order policy is unavailable or its state cannot be validated, block new exposure and preserve the uncertainty; do not invent a market-close policy.
7. Queue notifications without blocking the risk and reconciliation loop. When communications recover, report the current reconciled state and unresolved issues.
8. Recovery of Telegram connectivity does **not** automatically clear the entry-pause latch. A deliberate `/resume entries` command and the applicable gates are required.

The watchdog thresholds and operational measurement are deferred to Part 8. The core rule is immediate and explicit: communication loss cannot authorize new exposure, stop safety monitoring, or resolve an ambiguous order.

## 7. Required verification before enabling exchange writes

No Toobit order endpoint or account behavior was inspected or tested in this engagement. Before a future implementation could enable a Live write path, the adapter must verify, in a separately authorized and appropriately controlled validation stage:

- Exact request/response mappings and raw status semantics for submit, cancel, fill, and query.
- Whether an acknowledgement means accepted, open, or another specific state.
- How fills, partial fills, cancellations, expiries, and out-of-order observations are represented.
- Client-order-ID length, uniqueness scope, lookup behavior, and duplicate-submission semantics.
- Cancellation behavior and any race between cancellation and fills.
- Contract quantity, tick, precision, minimum-order, and side/position-mode rules.
- Whether and how `reduceOnly` or close-position semantics prevent crossing or reversal.
- Applicable API permissions and the least privilege necessary for the intended actions.
- Read-path coverage and history/retention sufficient for reconciliation.
- Rate-limit weights and a conservative bounded retry/backoff policy, especially given C4/C5.

Until those semantics are validated, they remain **UNRESOLVED**. The normalized state machine above is the required design target, not evidence of current exchange capability.

## 8. Material decisions and reversibility

| Decision | Rationale / status | Credible alternative | Reversibility |
|---|---|---|---|
| One OMS path for every exchange write, gated by independent risk authorization | Prevents strategy, Telegram, and reconciliation code from bypassing order controls and audit. | Direct strategy-to-exchange writes are simpler but weaken safety and traceability. | **SAFETY INVARIANT**; any change requires hazard review and re-verification. |
| Represent intent, venue status, cancellation, and reconciliation separately | Prevents local intent or a cancel response from being mistaken for an exchange outcome or flat position. | One status field is simpler but cannot represent partial fills and unresolved outcomes safely. | **REVERSIBLE** before implementation; costly after persistence and recovery rules exist. |
| Unknown outcomes retain reservations and block conflicting exposure | `-1007 TIMEOUT` is reported ambiguous; a missing response does not establish rejection. | Blind retry is faster but risks duplicate exposure. | **SAFETY INVARIANT**; no technical convenience overrides it. |
| No order modification in the initial command scope | Venue amendment semantics are unverified; a cancel/replacement can leave a race or unprotected interval. | A verified native amend operation could be added later. | **REVERSIBLE** before implementation; any later addition requires endpoint evidence and tests. |
| Only exact order/contract targets for cancel and close commands | Reduces ambiguity and limits unintended broad actions. | Bulk actions could be added with a separately verified group-level policy. | **REVERSIBLE** before implementation; later bulk scope needs independent validation. |
| No numeric risk override command while risk boundary is pending | Prevents an invented or implicit risk value from becoming effective. | A versioned owner-approved profile selector can be designed after the boundary is resolved. | **OWNER_DECISION_PENDING**; no value is inferred here. |
| Live selection checks all six A10 interlocks; per-order authorization still applies | A mode label alone cannot prove data, reconciliation, risk, credentials, configuration, and clock are valid. | A single persistent “Live on” flag is easier but obscures stale or failed interlocks. | Interlocks are a **BINDING GATE**; implementation details can be revised without removing the gate. |
| Telegram outage blocks new entries; existing safety management continues | Addresses unstable connectivity without requiring operator reply or abandoning open positions. | Autonomous new entries during an outage would require a separately approved unattended policy. | **PROVISIONAL / REVERSIBLE** before Live use; no fixed outage threshold is asserted. |
| Telegram is an interface, not authority or trust boundary | A message cannot bypass the risk authority or OMS; security validation is deferred to Part 8. | Treating platform identity or message text alone as authority is rejected. | **BINDING CONSTRAINT** under A2. |

## 9. Part 7 handoff

ART-09 defines the proposed risk authority, bounded authorization, order and cancellation state dimensions, partial-fill handling, reconciliation requirements, ambiguous-result policy, and Telegram command contract. It does **not** validate Toobit endpoint semantics, implement the command bot or OMS, select risk limits, verify permissions, or authorize Live activity.

**Registry update:** ART-01 through **ART-09 DELIVERED**; ART-10 through ART-12 remain **DEFERRED**. The next part is **Part 8/10: envelope-first deployment measurements, security, reliability, and recovery**. The engagement-level completeness declaration remains reserved for Part 10.


وضعیت: **بخش ۸ از ۱۰ — ارزیابی محیط اجرا بر مبنای workload، امنیت، قابلیت اطمینان و بازیابی، ART-10، تکمیل شد.** هیچ توپولوژی استقراری از نظر تناسب منابع پذیرفته نشده است؛ کارایی و رفتار POCO X6 زیر بار واقعی اندازه‌گیری نشده‌اند. هیچ ارائه‌دهندهٔ میزبانی، حساب صرافی یا اعتبارنامه‌ای بررسی یا استفاده نشده است.

# Part 8/10 — Deployment Envelope, Security, Reliability, and Recovery (ART-10)

## 1. Scope and decision status

This part follows the required order:

1. Derive the workload from the provisional strategy and data design.
2. Identify what must be measured on the POCO X6.
3. Assess each deployment topology already cataloged in Part 3.
4. Apply the resource and compromise considerations without weakening safety constraints.

**No deployment topology is selected.** The design does not establish that the phone is unsuitable, that an external host is available, or that any topology is production-ready.

The logical modular-monolith baseline from Part 6 is not a deployment decision. It may be hosted on one device, on one remote host, or within an already cataloged alternative, but it must not be treated as evidence that the phone or any host can meet the workload.

Binding constraints remain: Toobit is the selected Live venue; Telegram is the sole operator interface; there is no assumption of stable handset connectivity; the risk boundary is `OWNER_DECISION_PENDING`; and this engagement remains design-only. No credentials, accounts, authenticated exchange interfaces, orders, or external services were accessed.

## 2. Workload envelope before topology selection

### 2.1 What the provisional design actually requires

Part 4 selected a **single completed 1h candle series** as the provisional SC-01 research baseline. It did not establish an eligible symbol list. Consequently:

- \(S\), the number of eligible contracts, is **unknown**.
- \(B_i\), verified 1h bars for contract \(i\), is **unknown**.
- Per-symbol historical coverage, order-book event rate, and permitted provider costs are **unknown**.
- SC-01’s final parameter set, holding duration, exits, execution model, and confirmatory trial budget are **unresolved**.
- Exhaustive full-grid search at intervals of 12h or less is inadmissible under C24. The applicable per-cell budget must be recomputed under C22 before research workload is bounded.

Define the baseline candle workload as:

\[
R=\sum_{i=1}^{S}B_i
\]

where \(R\) is stored or processed one-hour bars. For a live one-hour series, each continuously covered symbol produces nominally **one completed-bar event per hour**. If multiple contracts share the same bar boundary, the system may receive a burst of up to \(S\) bars at once. Polling, corrections, retries, status queries, and execution data add workload; their rates have not been measured.

### 2.2 Storage and compute scaling

C19 reports approximately **1.25 GB** in one relational database file for a specific shape: 3,500 candles × 14 intervals × 10 arbitrary symbols. It is useful only as a rough calibration for a matching schema and storage shape—not as a universe seed, target, or estimate for trades or order books.

For \(S\) symbols, \(T\) intervals, and \(B\) bars per symbol and interval:

\[
D_{\text{C19-shape}}
\approx
1.25\text{ GB}
\times
\frac{S}{10}
\times
\frac{T}{14}
\times
\frac{B}{3500}
\]

For the provisional 1h-only baseline, \(T=1\). If—and only if—the schema matches C19, this corresponds approximately to:

- **8.9 MB per symbol** for 3,500 one-hour bars.
- **22.3 MB per symbol-year** at 8,760 one-hour bars.

These are approximate scale conversions. Units and storage-engine overhead in the C19 measurement are not sufficiently specified for more precise estimates. Raw payloads, indexes, write-ahead logs, backups, journals, features, and reports may materially change actual storage.

For optional microstructure capture, estimate raw event storage only after measuring the source’s event rate and payload size. For symbol \(i\):

\[
D_{\text{events}}
\approx
\sum_i \lambda_i b_i T
\]

where \(\lambda_i\) is observed events per second, \(b_i\) is bytes per event, and \(T\) is retention time in seconds. For regularly sampled snapshots, substitute snapshots per second for \(\lambda_i\). Indexing, compression, replication, logs, and backups require separate measurement. No order-book or trade-data event rate is available here.

Historical test work is bounded by the actual data, cells, trials, and folds. A first-order workload model is:

\[
W_{\text{research}}
\propto
\sum_{\text{cells }j}
B_j \times N_{\text{trial},j} \times F_j \times c_j
\]

where \(B_j\) is the valid bars in cell \(j\), \(N_{\text{trial},j}\) is its permitted trial count, \(F_j\) is its validation-fold count, and \(c_j\) is per-bar computation for the selected model. This is a scaling model, not a runtime estimate. The actual trial budget, validation design, implementation, and hardware benchmark are unavailable.

A streaming implementation could bound some memory use; materializing full histories or many candidate paths could increase it. Neither approach has been implemented or benchmarked. No compute or memory fit is claimed.

### 2.3 Workloads that need separate measurement

Do not infer a complete operating workload from the hourly candles alone. Assess separately:

1. **Historical research:** ingest, validation, feature generation, simulations, chronological folds, and any explicitly permitted trial set.
2. **Prospective Paper:** live data validation, simulated execution, state persistence, and reconciliation against the simulator’s own recorded events.
3. **Potential Live operation:** permitted Toobit market inputs; validated account/order observations; risk calculation; durable intent and audit writes; bounded API calls; and Telegram command/notification handling.
4. **Optional execution research:** trade/tick or book capture, only if its incremental value and availability are established. C8 means the supplied depth figures cannot be used as capacity data.
5. **Recovery:** journal replay, database checks, backup restore, and reconciliation after process or device interruption.

Paper does not establish Live readiness: it cannot prove actual exchange status semantics, fills, account state, permissions, network behavior, or liquidation safety.

## 3. POCO X6: known facts and measurement plan

### 3.1 What is known—and not known

C14 records an **OWNER-ATTESTED** POCO X6, model 23122PCD1G, with Snapdragon 7s Gen 2 reported up to 2.4 GHz, 12 GB physical RAM plus 8 GB memory extension, Android 16, 256 GB storage, and 56 GB free at the owner’s check. The supplied attestation also identifies software/build and security-patch details. They have not been independently inspected or assessed for currentness.

C16 reports an owner-observed 24-hour charging test without noticeable heating or observed problems. That is not a sustained production-workload benchmark. C15 identifies relevant Android constraints: restricted App Standby Bucket, Doze, foreground-service behavior, process death, OEM process management, thermal throttling, storage interruption, wakelocks, and unstable connectivity. **Charging does not prove that a background process will remain available.**

Do not treat memory extension as equivalent to physical RAM, or the owner’s recorded free space as a current storage budget. There is no device measurement of peak memory, sustained CPU, temperature, throttling, database growth, process survival, network availability, or crash recovery.

### 3.2 Measurements required before a device topology can pass

Run only against a controlled development/Paper workload and synthetic or otherwise safely isolated inputs. **Do not use Live credentials or submit exchange orders as part of these device tests.**

| Measurement | Workload or fault to exercise | Required evidence / acceptance condition |
|---|---|---|
| **Representative workload definition** | Use the actual proposed symbol count, verified history size, data shape, eligible per-cell trial budget, validation folds, and any selected optional data sources | Record inputs, source shape, run configuration, and peak/steady-state load. Since \(S\), history, and trial budget are unresolved, this profile is **BLOCKED**. |
| **CPU and elapsed-time behavior** | Ingestion, validation, incremental feature updates, Paper processing, and the bounded research workload | Measure median and tail elapsed time, sustained CPU load, queue growth, and whether any measured deadline or data-freshness requirement is missed. Exact deadlines and numeric guard bands must be derived before the test; none is asserted here. |
| **Memory pressure** | Representative workload including parsing, database activity, and maximum planned concurrent tasks | Measure physical-memory use, peak process memory, Android reclaim/kill behavior, and recovery. Count only measured physical resources; memory extension is not assumed to provide equivalent capacity. |
| **Storage growth and headroom** | Normalized candles, required raw lineage, journal, database logs, backups, and recovery files | Measure database and filesystem growth under the actual schema; project against a defined retention horizon. The owner’s prior free-space check is not itself an operating threshold. |
| **Thermal and sustained performance** | Sustained workload under intended charging and non-charging conditions | Measure temperature trends, throttling, execution time, and deadline misses. The existing 24-hour charging observation does not pass this test. |
| **Background survival** | Screen-off, Doze, restricted standby, allowed foreground-service behavior, OEM process management, long idle, process kill, and reboot | Record process survival and detection/recovery time. If the process is not continuously available, the topology must demonstrate safe failure and restart before any new risk is permitted. |
| **Storage interruption and crash recovery** | Abrupt process termination, simulated power interruption, full or nearly full storage, database corruption, interrupted write, and restore from backup | Prove that external dispatch cannot precede a durable intent; after recovery, the system must block new risk until journal recovery and required reconciliation complete. No such test has been run. |
| **Connectivity loss** | Outbound internet interruption, mobile/Wi-Fi transition, DNS/API unavailability, elevated latency, and reconnection | Verify bounded retries, preserved uncertainty, and no duplicate risk-increasing dispatch. Do not assume that a successful reconnect resolves an earlier order result. |
| **Telegram loss and recovery** | Delayed/missing command updates and failed notifications while safety loops continue | Verify that no new risk is opened by default, open-position management is not made conditional on an operator reply, and recovery does not automatically resume entries. |
| **Clock validity** | Clock skew, abrupt wall-clock correction, sleep/wake, and loss of time synchronization | Verify UTC-validity gating, monotonic deadline use, and rejection of time-sensitive actions when the clock is outside the future documented bound. No bound or device clock test is available. |
| **Paper behavior** | Data feed gaps, stale bars, duplicate events, restarts, and ambiguous simulator messages | Show source lineage, idempotent local recovery, and truthful pending/unknown reporting. Paper results must remain segregated from Live state. |

A test passes only against an agreed, workload-derived resource budget and service deadline. Measure, at minimum, peak and sustained CPU/memory/storage, data/command latency distributions, queue growth, thermal behavior, battery/charging state, process restarts, and recovery outcomes. Averages alone are insufficient for a system whose safety behavior depends on timely data and order reconciliation.

**Device fit is currently `NOT TESTED`.** No phone-only or device-execution topology passes an envelope-fit assessment here.

## 4. Deployment topologies already cataloged

The seven Part 3 topologies remain the full candidate set. No new topology is introduced. The following comparison is qualitative and uses Part 3’s predeclared criteria: causal data/provenance, independent risk controls, research burden, execution realism, resource envelope, auditability/operational burden, and reversibility. No weighted score is used.

| ID | Cataloged topology | What depends on the POCO X6 | Conditional benefit | Fit status and primary blockers |
|---|---|---|---|---|
| **TP-01** | Device-only | Research, Paper, operational processes, persistence, and any future Live execution | No remote-host dependency; potentially simpler physical deployment | **UNASSESSED.** Workload fit, Android background survival, connectivity, storage, recovery, and safe position management are unmeasured. A 24-hour charging test is insufficient. |
| **TP-02** | Device execution with one-off remote batch work | Phone remains the operational execution environment; remote work is one-off research/batch work | Can move infrequent heavy research away from the handset without moving the operational runtime | **UNASSESSED.** The device still needs to pass operational resilience tests; remote batch service, cost, transfer lineage, and permitted data handling are unverified. |
| **TP-03** | Device through Paper with external Live runtime | Device runs the cataloged local development/Paper role; an external runtime handles Live operation | Separates Live runtime availability from handset process survival while retaining local Paper work | **UNASSESSED.** Remote host, secure state/config handoff, recovery ownership, cost, jurisdiction, and sole-Telegram-interface placement are unresolved. Paper does not prove the external Live runtime. |
| **TP-04** | Device development/research with external Paper/Live runtime and Telegram bot | Phone is limited to development/research; external runtime carries Paper and potential Live operation | Reduces phone dependence for ongoing Paper/Live services | **UNASSESSED.** No host, region, availability, security, operating cost, or operational burden is established. It must remain one Telegram operator interface, not a second bot. |
| **TP-05** | External research/batch with device Paper/Live runtime | Phone runs Paper and potential Live operational services | Offloads research computation while retaining local operational placement | **UNASSESSED.** Like TP-01/02, device continuity and safe recovery remain blockers; remote batch work still needs source provenance and resource/cost assessment. |
| **TP-06** | Fully remote single deployment | No operational workload need run on the phone | Can remove Android process-lifecycle constraints from the trading runtime and keep the logical modules co-located | **UNASSESSED.** Hosting availability, cost, location/legal review, network, secrets management, backups, and service recovery have not been examined. “Remote” does not itself mean reliable. |
| **TP-07** | Split services with remote execution authority and optional relay | Depends on the exact partition; a relay must not become order authority | Could isolate execution authority or resource-heavy duties if measured need justifies it | **UNASSESSED.** Distributed state, network partitions, replay, authorization, service discovery, and recovery add complexity. An optional relay cannot bypass the OMS/risk authority or become another operator interface. |

For every topology:

- The sole operator interface remains Telegram under A2. If a bot component moves between devices or hosts, it remains one interface and one authorization contract.
- Cross-venue sources remain gated according to A5 regardless of where a service runs.
- An optional relay is not a trust authority, risk authority, or independent order path.
- The current location, cost, ownership, security, and availability of any external host are **UNRESOLVED**.
- No topology has been benchmarked or checked for legal, licensing, or operational fit.

### 4.1 Topology selection gates

A topology may be compared for selection only after the team has:

1. Defined a representative, bounded workload, including actual \(S\), coverage, retention, permitted research trials, and operational data classes.
2. Measured the phone workload relevant to any topology that uses it.
3. Verified host/network/cost/security conditions for any external topology.
4. Tested persistence and recovery behavior for order intent, ambiguous responses, and restart.
5. Shown that the topology can keep one Telegram operator interface without making safety dependent on inbound handset connectivity.
6. Demonstrated mode and source segregation, risk authority, and the single OMS exchange-write path.

These are evidence gates, not an implicit selection of TP-06 or any other topology.

## 5. Compromise order and resource trade-offs

A7 makes broad symbol/timeframe coverage a preference, not a target. Resource or measurement shortfalls must therefore be reported as explicit trade-offs; they must not be hidden by silently adding symbols, intervals, sources, or compute.

**Source limitation:** the currently available project record does not reproduce the exact ordinal wording of the owner-specified compromise order referred to in A8. I will not claim that an invented sequence is owner-ratified. The exact source order remains an **UNRESOLVED traceability item** for the final source audit.

Pending recovery of that exact wording, use this clearly marked **provisional, non-destructive design sequence** for comparison only:

1. Keep safety, authorization, reconciliation, source provenance, data validity, credential isolation, and clock gates intact. These are not resource trade-offs.
2. Remove optional research sources or intervals that add no demonstrated information value; do not add a multi-timeframe dependency by default.
3. Narrow research breadth by applying the documented symbol and coverage screens; do not lower a screen silently.
4. Bound research trials and concurrency by the independently recomputed per-cell budget; never bypass C22/C24.
5. Schedule or move bounded research batches to a tested, permitted topology before treating the phone as a compute server.
6. Consider a different already cataloged deployment topology only after its security, cost, recovery, and availability are assessed.

This ordering is a **DESIGN JUDGMENT**, not an attribution to the owner’s missing ordinal text. It does not decide which topology is best. It explicitly avoids “solving” a resource problem by weakening risk controls or assuming a cloud service is available.

## 6. Reliability model and recovery requirements

### 6.1 Availability is not the same as safe operation

The system can be running but not safe to trade—for example, if data are stale, exchange state is unreconciled, the clock is invalid, the journal is unavailable, or the approved risk configuration is missing. Therefore, operational readiness must distinguish:

- **Process availability:** a process is running.
- **Data readiness:** required, permitted data are fresh and valid.
- **State readiness:** journal recovery and required reconciliation are complete.
- **Execution readiness:** all applicable mode, risk, credential, configuration, and clock gates pass.
- **Operator-channel availability:** Telegram can receive commands and deliver notifications.

A Telegram notification failure does not undo a committed risk decision. Process availability alone does not open the execution gate.

### 6.2 Failure handling

| Failure | Required behavior |
|---|---|
| **Stale, missing, malformed, or source-disallowed market data** | Block dependent new entries; preserve the bad or missing-data evidence; do not forward-fill, change timeframe, or substitute an unapproved venue. |
| **Phone process killed, Android background restriction, or device reboot** | On recovery, block new risk until durable state is recovered and relevant external state is reconciled. Do not infer a flat account from an empty local process. |
| **Power, network, or host outage** | Do not blindly replay external writes. Preserve committed intents and plausible exposure; reconcile after connectivity returns. Continue only safety actions that are already authorized and supported by validated state. |
| **Telegram unavailable** | Apply Part 7: block new risk-increasing entries by default; keep independent risk/reconciliation processes running; preserve uncertainty; do not require an operator reply for an already authorized safety action. |
| **Toobit timeout or ambiguous order response** | Treat as `UNKNOWN`, retain the risk reservation, block conflicting exposure, and reconcile. C5’s `-1007 TIMEOUT` is not treated as proof of rejection. |
| **Reported rate-limit breach** | Use a finite, explicitly accounted request budget and bounded backoff. C4 reports absent `X-Api-Limit-*` headers in the tested environment, so header deltas cannot be assumed. |
| **Disk full, failed durable write, or corrupt journal** | Do not dispatch a new exchange write. Preserve recoverable data, report the fault through Telegram when available, restore from a verified backup, and reconcile before new exposure. |
| **Invalid UTC clock or time jump** | Fail the clock interlock for time-sensitive new risk. Use monotonic time for elapsed deadlines; do not use it as a persistent wall-clock instant. |
| **Credential or permission state unknown** | Block Live writes. Do not fall back to a broader or unverified key. Keep credentials out of Telegram, strategy state, and logs. |
| **Configuration mismatch, changed artifact, or incomplete startup** | Keep entries blocked until the intended version and configuration integrity are verified. |
| **Protective-order semantics or current position are unknown** | Do not assert the position is protected, flat, or safe to close. Continue only actions whose exact effect is validated; preserve the unknown state and block new exposure. |

C12’s provisional three-day reconciliation-deferral threshold is **not** verified exchange retention or proof that a three-day outage is safe. If a reconciliation discrepancy reaches that threshold, the system must escalate and keep new risk blocked; it must not infer absence of orders or fills.

### 6.3 Durable intent, recovery point, and restoration

**Design requirement:** write and durably commit the internal order intent, bounded authorization reference, reservation, unique client ID, audit record, and dispatch outbox **before** any external order write. This does not make the exchange request atomic with local storage. A response lost after dispatch remains ambiguous.

The intended local recovery objective for a successfully committed order intent is **no loss of that committed record**. This is an architectural invariant to verify under process crash, storage interruption, and power loss—not a claim that the selected database or device already provides it. If the required durable-commit semantics cannot be established, the system must not dispatch a Live order.

After restart:

1. Verify configuration identity, clock status, persistence integrity, and application artifact.
2. Replay internal journal and recover committed intents, reservations, and pending outbox actions.
3. **Do not blindly reissue** any order or cancellation whose external outcome is uncertain.
4. Reconcile relevant exchange orders, fills, and positions through validated read paths.
5. Retain the conservative possible exposure for any unresolved state.
6. Permit new risk only after recovery is complete and all applicable gates pass.
7. Send the reconciled result through Telegram when the channel is available. Delivery failure does not change the underlying state.

Backup frequency and retention must follow an explicit data-loss analysis. Backups must be protected from the same access failures as the primary store and tested by restoring into a non-Live context. A backup that restores an old order projection must **not** authorize order activity until reconciliation. No backup or restore test has been performed.

No numeric recovery-time objective (RTO) is asserted. The safety condition for resuming risk is state-based, not “the service restarted within a chosen number of minutes.” A distinct maximum acceptable period without risk-management capability for an open position has not been determined. That value depends on strategy holding duration, validated exchange-side protection, execution semantics, monitoring, and market risk. No topology can be declared operationally adequate until those dependencies are resolved.

### 6.4 Exchange-side protection is a material deployment dependency

A process or device outage may remove the system’s ability to inspect or manage a position. This design does not assume that an exchange-native stop, bracket, `reduceOnly`, or close-position instruction has the required semantics or will remain active during such an outage. Those semantics are unverified.

Before any Live deployment is considered, establish whether the selected strategy and order design can maintain appropriate protection through process/network interruption. If safety depends on an exchange-side protective order, verify its creation, persistence, trigger-price semantics, partial-fill behavior, cancellation races, and position-reduction effect for the relevant contract and mode. If that cannot be demonstrated, the deployment is blocked for Live; a phone-only assumption or a remote host does not cure the missing order semantics.

## 7. Security design

### 7.1 Trust boundaries

Treat the following as separate security boundaries:

1. **Telegram platform and operator account → command adapter.** A Telegram message is untrusted input until its origin, scope, freshness, authorization, and idempotency are checked.
2. **Market-data providers → ingestion.** Source identity, time, units, and permission must survive normalization.
3. **Research and Paper → potential Live runtime.** Source tier, credentials, state, and artifacts are segregated. Unapproved cross-venue data and their derived signals do not enter Paper/Live.
4. **Application → persistence and audit.** Durability, integrity, access, backup, and recovery are separate risks.
5. **Application → Toobit execution interface.** The future order-writing capability is isolated behind the OMS and adapter.
6. **Runtime → secret store and host/device OS.** Runtime compromise may expose data or secrets unless privilege and storage are constrained.
7. **Runtime → Telegram/network services.** Outbound service availability and message integrity cannot be assumed from the existence of a mobile connection.

These boundaries describe the design; no penetration test, security audit, endpoint inspection, or credential test has occurred.

### 7.2 Threats and controls

| Threat | Required control | Residual limitation |
|---|---|---|
| **Telegram account or bot-token compromise** | Protect the owner’s Telegram account and bot secret; keep a narrowly allowlisted operator principal and private chat scope; reject unsupported/group/forwarded contexts; authorize commands in application logic; allowlist command grammar and scope; deduplicate mutating messages; never send secrets through Telegram. | A compromised account or platform session may still make valid-looking requests. Independent risk and OMS gates must limit effects. No Telegram security settings were inspected. |
| **Replay or duplicate command delivery** | Durable command ID/idempotency record, short measured validity for mutating requests, and no repeated side effects for the same command. Report the existing state instead. | Exact platform update semantics and the suitable command-age bound are unverified. |
| **Malicious or malformed input** | Strict parser, finite command set, canonical contract/order identifiers, bounded field sizes, and no dynamic code or shell execution from message text. Invalid input has no side effect. | No parser or test exists. |
| **Exchange credential theft or over-privilege** | Store secrets outside source, messages, strategy state, and ordinary logs; expose a Live key only to the future execution adapter; require the narrowest available permission and no withdrawal permission; separate environments and identities where supported; rotate/revoke on suspected compromise. | Toobit’s exact permission granularity, key behavior, and revocation semantics were not inspected. If adequate least privilege cannot be achieved, Live remains blocked. |
| **Device loss or compromise** | Apply owner-controlled device lock and storage protection, restrict debugging and app permissions, review root/developer state, and ensure credentials are not recoverable from notifications or logs. Revoke affected Live permission through a separately secured recovery procedure. | Device configuration and hardware-backed key behavior are unmeasured. The supplied patch/build attestation was not independently assessed. |
| **Remote-host compromise** | Limit OS/service identities, isolate the execution secret, restrict network exposure, patch the host, protect backups and logs, and review changes to the approved artifact/configuration. | No host or provider has been selected or assessed; these controls have not been implemented. |
| **Unapproved or poisoned source data** | Preserve source tags, raw observations, timestamps, and quality outcomes; allowlist permitted sources by mode; reject source-tier mismatches; keep external research in a separate namespace. | Historical point-in-time coverage and exact provider permissions remain unresolved. |
| **Dependency or software-supply-chain compromise** | Version and review dependencies; preserve build/config identity and audit history; validate updates before enabling Live; keep a reproducible record of the deployed artifact. | No language, framework, library, build pipeline, or software bill of materials has been selected or produced. |
| **Network, DNS, or transport attack** | Use authenticated encrypted transport; validate peer identity and certificates; minimize inbound exposure; bound timeouts and retries; log source and outcome without secrets. Prefer outbound-only paths where compatible with the selected topology. | No endpoint list, network configuration, or transport test is available. |
| **Secret or private data leakage through logs/notifications** | Redact credentials and tokens; minimize account and personal data in Telegram responses; restrict access to logs and backups; test redaction using synthetic secrets. | No implementation or leakage test exists. |
| **Storage or audit tampering** | Separate write responsibilities, protect the durable journal and backup, preserve checksums/versioning where appropriate, and treat missing audit records as a fault. | Append-only behavior and tamper resistance have not been implemented or tested. |
| **Clock manipulation or drift** | Validate UTC clock health against an agreed bound; use monotonic time for elapsed deadlines; fail relevant time-sensitive gates on an unverified clock. | No time source or clock-error bound has been selected. |

### 7.3 Telegram authorization design

A future command adapter must not rely on a display name or message text alone. At minimum:

- Bind commands to a specifically owner-authorized operator principal and expected private-chat context.
- Validate the platform-originated update using the supported transport mechanism for the chosen integration; if authenticity cannot be established, disable mutating commands.
- Reject unauthorized chats, groups, forwarded messages, bots, malformed scopes, and unknown commands.
- Apply command allowlists, durable deduplication, bounded request rates, and command-specific authorization.
- Separate “command received” from “command authorized,” “external request sent,” and “exchange outcome reconciled.”
- Treat a mode-selection command as insufficient to authorize an order; the six Live interlocks and per-order authorization still apply.
- Keep all tokens, credential strings, and secrets out of chat messages, notifications, logs, support reports, and research artifacts.

The Telegram user identity, authorization policy, and integration method are not yet configured or tested. This design does not make Telegram a safety authority; it makes the application independently validate requests and limits their possible effect.

### 7.4 Credential and environment isolation

No credentials were requested, received, or used. Before any future Live credential can be enabled:

- Determine the exact minimum permissions available for Toobit; do not assume read/write separation or IP restrictions exist.
- Do not use a key with withdrawal permission. If the required trade permission cannot be separated from withdrawal permission, Live is blocked pending owner review.
- Keep Live secrets unavailable to research and Paper processes, code, Telegram, and notifications.
- Encrypt secrets at rest and limit read access to the one process/component that needs them.
- Treat credential rotation, revocation, backup, incident response, and permissions as versioned operational procedures.
- Verify permissions through an appropriately authorized procedure before relying on them. No such procedure was performed here.

## 8. Operational observability through the sole operator interface

Telegram remains the only operator interface. This design adds no dashboard or second bot. Internal telemetry may be stored for diagnosis and audit, but routine operational status and alerts are presented through the same Telegram interface where available.

Record, with suitable redaction:

- Feed freshness, missing-bar and validation counts.
- Current clock validity and estimated uncertainty once defined.
- Reconciliation time, scope, completeness, and unresolved discrepancies.
- Open intents, unknown outcomes, working entry orders, and reservations.
- Current mode, execution gate, configuration version, and risk-interlock status.
- Database health, persistence failures, storage growth, and recovery status.
- Queue/outbox backlog, bounded retry counts, exchange response classifications, and rate-budget use.
- Process restarts, memory/storage pressure, and device thermal or background-survival observations where available.
- Telegram transport and notification-delivery health.

Numeric warning thresholds must be derived from service needs, measured latency, device/host envelope, and safety analysis. None is selected or measured in this design. Deduplicate notifications and prevent alert loops. If Telegram is unavailable, continue safety behavior and retain notification events for later reporting; do not allow a notification backlog to block reconciliation.

## 9. Material decisions and reversibility

| Decision | Rationale / status | Credible alternative | Reversibility |
|---|---|---|---|
| Derive the workload before choosing where it runs | \(S\), coverage, trial budget, and optional execution-data rates are unresolved; topology-first selection would be unsupported. | Select a favored device or cloud target first and fit the research to it; rejected because A8 makes the phone a constraint, not an architecture driver. | **REVERSIBLE** until any deployment or persistent state is created. |
| Do not declare the POCO X6 fit from the owner’s specification or 24-hour charging test | Neither test measures representative sustained workload, Android background behavior, or recovery. | Treat published specifications as adequate; rejected as an unsupported feasibility claim. | **REVERSIBLE** when measured evidence is available. |
| Retain all seven cataloged topologies for comparison; select none | Each has unresolved resource, network, security, cost, or recovery fit. | Choose fully remote or device-only without measurements; unsupported. | **REVERSIBLE** before deployment; deployment choice becomes **COSTLY_REVERSIBLE** once state and operations exist. |
| Require durable intent before any external write | Prevents an external action from being dispatched without locally recoverable intent and reservation. | Send first and persist later; rejected because a crash can erase evidence of a possibly live order. | **SAFETY INVARIANT**; altering it requires hazard review and re-verification. |
| Resume risk only after recovery and reconciliation | A process restart does not prove external account state. | Auto-resume after service restart; rejected because state may be stale or incomplete. | **SAFETY INVARIANT**. |
| Treat Android, Telegram, network, host, and exchange failures as separate states | A running process or working bot does not establish valid data or reconciled positions. | Collapse into one “online” flag; rejected as insufficient for safety. | **REVERSIBLE** before implementation; migration and regression cost later. |
| Keep the owner’s exact compromise order unresolved until its source wording is available | Avoids attributing an invented sequence to the owner. A non-destructive temporary sequence is clearly labelled as design judgment. | Claim the provisional ordering is owner-ratified; rejected for lack of traceable evidence. | **REVERSIBLE** when the source text is reviewed; must be reconciled in Part 10. |
| Use Telegram for routine operator interaction while retaining emergency security administration separately | Preserves A2 without making a compromised or unavailable bot the only way to revoke a credential or secure a host. Emergency infrastructure administration is not a routine trading UI or order interface. | Add another routine trading console or permit trades through infrastructure administration; rejected under A2 and the OMS authority model. | A2 is **BINDING**; the emergency procedure is **PROVISIONAL** and must be defined for the selected topology. |

## 10. Part 8 handoff

ART-10 derives the current variable workload, provides valid use of the C19 storage calibration, defines the POCO X6 evidence gap and measurement plan, assesses all seven existing deployment topologies without selecting one, and specifies security, reliability, and recovery requirements.

It does **not** establish a phone fit, a host/provider, a numerical uptime or recovery objective, exchange-side protective-order behavior, a credential scope, a tested backup, or Live readiness. The owner-specified compromise order’s exact wording remains an explicit traceability gap because it is not present in the available project record; the temporary sequence in Section 5 is not presented as ratified.

**Registry update:** ART-01 through **ART-10 DELIVERED**; ART-11 and ART-12 remain **DEFERRED**. The next part is **Part 9/10: risk-derived phases, implementation order, the 29-row verification matrix, and adversarial review**. The engagement-level completeness declaration remains reserved for Part 10.


وضعیت: **بخش ۹ از ۱۰ — مراحل مبتنی بر ریسک، ترتیب وابستگی‌ها، ماتریس راستی‌آزمایی ۲۹‌ردیفی و بازبینی خصمانه، ART-11، تکمیل شد.** ماتریس دقیقاً یک ردیف برای هر شناسهٔ R-001 تا R-029 دارد؛ آزمون پیاده‌سازی یا بازبینی مستقل انجام نشده است. بخشی از ارزیابی‌های عملیاتی به‌دلیل نبود داده، تصمیم مالک یا سنجش منابع مسدود است. اعلام نهایی تکمیل کار و سوابق V-1 تا V-12 برای بخش ۱۰ محفوظ است.

# Part 9/10 — Risk-Derived Phases, Verification Matrix, and Adversarial Review (ART-11)

## 1. Scope and status conventions

This part converts the design in ART-01 through ART-10 into a risk- and dependency-based implementation plan. It provides the requested verification matrix of exactly **29 rows**, one for each requirement ID R-001 through R-029.

The requirement titles in the matrix are **short navigation labels**. ART-04 remains the authoritative requirements register; this matrix does not amend its full requirement wording.

No implementation, test, backtest, exchange call, device measurement, credential check, topology benchmark, or independent review has occurred. Future tests below are **acceptance proposals**, not results.

Primary status meanings:

- **PASS:** directly supported for the specific scope stated. It does not imply system or Live readiness.
- **BLOCKED:** a stated decision or evidence gap prevents acceptance for the relevant operational scope.
- **NOT TESTED:** a design is specified, but implementation or acceptance testing has not been performed.
- **UNRESOLVED:** available evidence does not establish the relevant fact.
- **FAIL:** an executed acceptance test demonstrated a failure. None is recorded in this matrix; no such tests were run.

## 2. Hazards and dependency-derived execution order

The proposed phases prioritize hazards and prerequisite evidence—not the numbering of earlier design sections.

| Hazard | Why it matters | Controls and predecessor evidence |
|---|---|---|
| **H1 — Invalid or non-point-in-time data** | Incorrect, stale, revised, or misattributed data can create false signals and invalidate research. | Establish source semantics, contract identity, timestamp meaning, per-symbol coverage, provenance, and data-quality behavior before accepting a data-dependent research result. |
| **H2 — Selection bias and false confidence** | Repeated searches, dependent observations, short histories, and cost-free fills can make weak evidence look strong. | Preregister the candidate, estimand, validation plan, and per-cell trial budget before confirmatory results; respect C20–C24. |
| **H3 — Unbounded or duplicate exposure** | An order may be accepted even if the response is lost; concurrent intents may exceed available risk. | Risk authorization, durable intent and reservation, one OMS write path, bounded identifiers, and reconciliation must precede any potential Live order. |
| **H4 — Unknown exchange state** | A timeout, cancellation race, process death, or incomplete history cannot safely be interpreted as rejection or “flat.” | Maintain explicit unknown/pending/discrepant states, retain conservative reservations, and reconcile before releasing risk. |
| **H5 — Operational interruption** | A phone, host, database, clock, network, or Telegram failure can interrupt monitoring or order management. | Measure workload and recovery, test durable intent and restoration, and define safe outage behavior before selecting a deployment topology. |
| **H6 — Compromised command or credential** | A Telegram request or over-privileged key could create unsafe actions. | Validate commands independently, isolate secrets, enforce least privilege, and keep the OMS and risk authority as the only route to exchange writes. |
| **H7 — Inappropriate resource/topology choice** | A topology selected before workload measurement may fail under normal use or recovery load. | Derive a bounded workload first; measure the POCO X6 and assess all seven cataloged topologies before selecting any. |

### 2.1 Dependency graph

```text
ART-04 requirements/evidence baseline
        │
        ├──────────▶ Toobit contract, metadata, source, and coverage verification
        │                                 │
        │                                 ▼
        │                      immutable ingestion and quality tests
        │                                 │
        │                                 ▼
        │                   preregistered SC-01 research and controls
        │
        ├──────────▶ module/state interfaces ──▶ OMS and persistence test doubles
        │                                                   │
        │                                                   ▼
        └──────────▶ security and fault requirements ──▶ isolated Paper integration
                                                            │
                                  bounded research workload ─┤
                                                            ▼
                                             device and topology measurements
                                                            │
                  owner risk decision + verified Toobit semantics
                         + permission/legal approval + six interlocks
                                                            │
                                                            ▼
                                         future Live-eligibility assessment
```

Research preparation and OMS test-double work can proceed in parallel once their respective interfaces and constraints are stable. Paper integration depends on valid inputs and the OMS simulation path. Topology selection depends on measured workload. A future Live assessment depends on completed operational evidence and nondelegable owner decisions; it does **not** gain an arbitrary waiting-period or profit hurdle.

## 3. Proposed implementation phases

These phases describe a future implementation plan. Their IDs are labels, not an inflexible sequence. Work may proceed in parallel where the dependency graph permits it. No phase is represented as already started or passed.

### Phase P0 — Preserve the design and evidence baseline

**Risk addressed:** Requirements or owner-supplied evidence are silently altered, overstated, or lost.

- Preserve ART-01 through ART-10, the 29-row ART-04 register, the C1–C26 evidence ledger, and their evidence labels.
- Retain the distinction between owner constraint, preference, attestation, owner-supplied finding, derivation, design judgment, unresolved fact, and pending owner decision.
- Make no external data, account, credential, repository, device, or exchange access as part of this design engagement.
- Resolve the exact wording of the owner-specified compromise order only if that source wording becomes available. Until then, retain Part 8’s provisional sequence as **DESIGN_JUDGMENT**, not as owner-ratified wording.

**Exit evidence:** versioned, internally consistent design and evidence baseline; all claims have traceable sources or are explicitly marked unresolved.

**Does not require:** a chosen programming language, framework, cloud provider, strategy parameter, or owner decision already delegated to the design.

### Phase P1 — Verify contract and permitted data inputs

**Risk addressed:** Building a universe or sizing rule from aggregate or stale facts.

- Establish a timestamped census of Toobit-listed perpetual contracts and the contract metadata needed for valid quantity, notional, PnL, fee, and funding calculations.
- Verify per-contract, per-timeframe historical depth and coverage; treat C2’s reported candle cap as a cap/observation, not a completeness guarantee.
- Populate actual per-symbol turnover observations with their window and quote-notional semantics.
- Validate an order-book source, sides, sequence behavior, timing, and reproducibility before using it for the depth gate; C8’s cited figures do not pass that gate.
- Establish interval finality/timestamp semantics, freshness measurements, fee and funding applicability, and rate-budget assumptions.
- Evaluate cross-venue access only under A5. Unapproved sources and their derived features remain blocked from Paper/Live.

**Exit evidence:** reproducible source snapshots, timestamped per-symbol registers, quality outcomes, explicit exclusions, and approved source tiers. If any input is unavailable, that contract or source remains excluded or gated; do not fabricate a pass.

**Parallel path:** preliminary interface and persistence work may use synthetic inputs without asserting that the synthetic data represent Toobit.

### Phase P2 — Implement immutable ingestion and data-quality controls

**Risk addressed:** Data gaps, corrections, conflicts, or source changes silently contaminating research or decisions.

- Implement raw-input preservation, source tags, normalized records, hashes or equivalent lineage references, schema versions, and validation results.
- Enforce the missing, stale, duplicate, malformed, contradictory, and unavailable-data behaviors in ART-06.
- Create as-of views that distinguish source event time from when the information became available to the system.
- Test UTC normalization and monotonic elapsed-time handling without conflating the two.
- Implement source-tier allowlists so unapproved cross-venue information—and indicators derived from it—cannot flow into Paper/Live.

**Exit evidence:** automated tests show that invalid input is rejected or isolated, corrections do not rewrite earlier information sets, and source lineage survives transformations.

### Phase P3 — Preregistered research and statistical validation

**Risk addressed:** Overfit or causally invalid results promoted as evidence.

- Define SC-01’s operational signal, exits, maximum holding duration, execution assumptions, costs, and data scope before confirmatory results are inspected.
- The holding duration remains derived from the strategy, costs, funding, risk, and validation; a one-hour signal interval is not itself a one-hour maximum holding duration.
- Recompute the effective per-cell trial budget under C22; enforce C24’s ban on exhaustive full-grid search at intervals of 12h or less.
- Preregister the primary estimand, economic relevance rule, chronological splits, dependent-observation treatment, and multiple-testing method.
- Compare to SC-00 no-trade and randomized-entry controls. Keep SC-02 separate with its own preregistration rather than selecting it after seeing SC-01 results.
- Use causally available data and costs; do not fill at the same completed bar close or claim maker fills from price touch alone.

**Exit evidence:** a reproducible research package with data hashes, trials, exclusions, costs, validation boundaries, uncertainty estimates, and stated limitations. No profitability result is presumed.

**Hard stop:** if valid history is insufficient for the preregistered analysis or the trial budget cannot be recomputed, mark the result insufficiently evidenced rather than shortening or broadening the test after observing outcomes.

### Phase P4 — Implement authority, persistence, and OMS test doubles

**Risk addressed:** An unvalidated strategy, command, or retry path creates an order or loses evidence of a possible order.

This phase can proceed in parallel with P1–P3, using mock or synthetic adapters only.

- Implement module boundaries and owned state from ART-08.
- Implement risk authorization as a bounded capability; an unresolved limit denies risk-increasing actions.
- Persist intent, reservation, audit context, unique client identifier, and dispatch outbox before any external write.
- Implement the ART-09 intent, exchange-observation, cancellation, reconciliation, and position-state dimensions.
- Use a test adapter to inject accepted, rejected, partial-fill, delayed, duplicated, out-of-order, timed-out, and conflicting outcomes.
- Ensure ambiguity retains exposure reservation and never causes blind resubmission.

**Exit evidence:** deterministic state-machine and property tests demonstrate the safety invariants under the modeled events. These tests do not verify Toobit’s actual endpoint semantics.

### Phase P5 — Isolated Paper integration and fault testing

**Risk addressed:** Separate components work in isolation but fail under integrated state, data, or communications failures.

- Connect validated market-data views, candidate strategy proposals, risk authority, OMS, simulator, journal, reconciliation projection, and the single Telegram command interface.
- Keep Paper data, simulated fills, order state, and credentials isolated from any future Live scope.
- Test data outage, stale input, process kill, restart, clock error, disk full, network loss, Telegram loss, notification delay, and simulated ambiguous responses.
- Verify that a pause blocks new exposure but does not falsely assert that working orders are canceled.
- Verify that existing position-management policy does not depend on an operator reply, while no unapproved new risk is opened.

**Exit evidence:** reproducible fault-injection reports and correct, auditable recovery behavior. A Paper result remains a simulation result; it does not validate account permissions, real fills, or exchange state semantics.

### Phase P6 — Measure workload, device, and deployment-topology fit

**Risk addressed:** Selecting a phone or external host based on specifications, convenience, or a sample workload that does not match the actual system.

- Use the representative, measured workload from the previous phases, including the actual eligible contract count, verified coverage, retention, and allowed trial/fold budget.
- Measure the POCO X6’s sustained CPU, physical-memory use, storage growth, Android process survival, thermal behavior, connectivity interruption, and crash recovery under that workload.
- Assess all seven topology candidates from Part 3 against the same criteria. If a candidate uses an external host, establish cost, legal/jurisdictional, access, security, backup, and operating constraints before assessing it as feasible.
- Preserve the A2 single-Telegram-interface constraint and A9’s requirement not to depend on stable inbound handset connectivity.
- Do not silently widen data scope or weaken safety controls to make one topology appear to fit.

**Exit evidence:** comparative measurements, defined operating and recovery limits, documented trade-offs, and an explicit topology decision—or an explicit finding that none passes.

### Phase P7 — Future Live-eligibility assessment

**Risk addressed:** Live access is enabled before limits, permissions, exchange semantics, or operational recovery are established.

A future Live assessment requires:

- The nondelegable owner risk-boundary decision and a versioned, internally consistent risk profile. The preferences of approximately 5% per-trade risk and 15–20% maximum drawdown remain **unadopted** until the owner decides otherwise.
- Verified Toobit order, cancel, fill, client-ID, contract, rate-limit, and reconciliation semantics for the intended scope.
- Established credential permissions and a security-reviewed secret boundary; no withdrawal-capable or broader key is assumed acceptable.
- A tested recovery and outage policy appropriate to the actual strategy and protection mechanics.
- The six A10 interlocks: data validity, reconciliation, risk-limit definition and bounds, credential/permission validity, configuration integrity, and clock validity.
- A strategy and configuration review based on preregistered evidence and stated residual risks. This is separate from an arbitrary Telegram selector profit hurdle.

There is **no arbitrary waiting period, fixed Paper-duration requirement, or ad hoc profit threshold** in the `/mode live` selector. The six interlocks remain mandatory, and each order still requires fresh authorization. If any required decision, source, test, or permission remains missing, the applicable Live scope remains blocked. This phase describes a future assessment, not authorization or a recommendation to trade.

## 4. Verification approach

Before marking an acceptance criterion PASS in a future implementation, retain evidence sufficient for another reviewer to reproduce the result. Depending on the requirement, evidence may include:

- Requirements-to-code and requirements-to-test traceability.
- Unit tests for formulas, timestamp normalization, parsers, and contract rounding.
- Property tests for risk and order-state invariants.
- Replay tests over immutable, point-in-time data.
- Statistical reports with complete trial histories and costs.
- Fault-injection runs with recovered journals and reconciliation results.
- Device/host measurements for a representative workload.
- Permission, configuration, source-policy, and build-integrity checks.
- Logs or reports that identify test version, inputs, outcomes, failures, and corrective action.

A test should fail safely if the required state is unknown. “No observed failure” in a short run does not prove availability, security, performance, or exchange correctness. In particular, C12’s provisional three-day reconciliation-deferral threshold is not verified exchange-history retention or a safe maximum outage duration.

## 5. Verification matrix — 29 register requirements

The matrix has exactly 29 data rows: R-001 through R-029, with no gaps. A `BLOCKED` status refers to acceptance for the indicated operational scope; it does not mean that the design work itself cannot continue.

| ID | Short requirement label | Acceptance evidence and rationale | Current status | Failure response and regression check |
|---|---|---|---|---|
| **R-001** | Design-only scope and prohibited actions | Verify engagement records contain no account access, credentials, authenticated calls, funds access, order submissions, cancellations, or modifications. A4; ART-01/02. | **PASS — engagement boundary only.** This is not a system or trading-readiness pass. | Stop and disclose any prohibited action; do not proceed as if the engagement remained design-only. Regression: review each proposed research or validation step for account, credential, network-write, and funds effects. |
| **R-002** | Evidence provenance and claim status | Trace every C-series assertion to its owner-supplied status; distinguish supplied summary, attestation, derivation, design judgment, and source verification. Verify raw-archive claims are not made from C25’s summary alone. ART-02/04; C25. | **UNRESOLVED.** Raw PDF metadata/archive and independent sources were unavailable; C-series findings are not independently verified here. | Downgrade any unsupported claim to its actual evidence status. Regression: a provenance audit must reject unlabeled sources and unreviewed changes to evidence status. |
| **R-003** | Toobit venue and contract universe | Verify every candidate is an actual Toobit perpetual with effective-dated contract metadata. No invented symbol list or use of the ten-symbol illustration. A1; ART-06; C1/C2/C9. | **BLOCKED.** The exact current contract list and per-symbol metadata were not supplied or inspected. | Keep the candidate register unpopulated for the affected symbols; do not infer eligibility from an aggregate count. Regression: rerun contract-identity and metadata checks for each dated universe snapshot. |
| **R-004** | Telegram as sole operator interface | Confirm exactly one operator interface, strict command scope, and no dashboard, second bot, or routine console; Telegram must not grant direct risk authority. A2; ART-08/09. | **NOT TESTED.** Only the design contract exists; no application or bot was implemented. | Disable any unapproved interface or bypass path. Regression: architecture/dependency scan and command-surface test confirms strategy and Telegram adapter cannot write to the exchange. |
| **R-005** | UTC and timestamp semantics | Test UTC persistence, interval boundary semantics, source/receipt/decision timestamps, monotonic elapsed deadlines, and UTC-day/ISO-week calculation where used. A3; ART-06/08. | **NOT TESTED.** No clock, parser, or persistence implementation was exercised. | Block time-sensitive actions if clock validity or timestamp semantics fail. Regression: boundary tests across UTC day/week changes, sleep/wake, and wall-clock correction. |
| **R-006** | Intraday operational definition and holding duration | Define maximum holding duration only after strategy exits, market behavior, fees, funding, risk, and validation establish it. A6; ART-05/06/07. | **BLOCKED.** SC-01’s exits and holding duration are unselected; a 1h signal bar is not a holding-period definition. | Do not claim intraday risk control or funding-aware performance without the rule. Regression: changes to exits, funding treatment, or holding duration trigger a new documented research decision. |
| **R-007** | Strategy candidate comparison and no guarantee | Preserve SC-00 controls, SC-01 as a falsifiable research candidate, SC-02 as a separate alternative, and deferred candidates without claiming profitability. ART-05/07. | **NOT TESTED.** No candidate was backtested or validated. | Withdraw any performance or profitability claim lacking evidence. Regression: every reported strategy result identifies candidate/version, controls, costs, data, and limitations. |
| **R-008** | Statistical validation and uncertainty | Verify causal timing, chronological splits, point-in-time inputs, dependence-aware uncertainty, unit consistency, and complete trial reporting; keep DSR and MinTRL distinct under C20/C21. ART-07; C20–C23. | **NOT TESTED.** No strategy dataset, trial panel, or statistical calculation was independently reproduced. | Mark the result exploratory or insufficiently evidenced; no promotion based solely on a favorable point estimate. Regression: rerun preregistration, split-contamination, units, dependence, and full-trial-history tests. |
| **R-009** | Owner-defined risk boundary | Confirm no hard, provisional, illustrative, or implicit numeric limit was adopted from the 5% per-trade or 15–20% drawdown preferences. Require a future explicit owner decision before Live risk authorization. ART-07; A10/A11. | **BLOCKED.** Risk boundary is `OWNER_DECISION_PENDING`. | Deny risk-increasing authorization; do not substitute a strategy setting or engineering judgment. Regression: configuration validation rejects missing or unapproved limits and verifies their version/authority. |
| **R-010** | Risk arithmetic and distinct quantities | Reproduce risk sensitivity for 0.5%, 1%, 2%, 5%, and 10%; distinguish notional, quantity, stop distance, costs, margin, leverage, liquidation, per-trade, aggregate, daily loss, and drawdown. ART-07; C3/C6/C7/C13. | **NOT TESTED.** Part 5 contains hand-checkable formulas, but no implementation or contract-specific calculation was run. | Block sizing if inputs, contract mechanics, or valuation are invalid. Regression: unit-tested formula checks include cost/gap sensitivity, quantity rounding down, and a rule that 5% is not silently selected. |
| **R-011** | Per-cell trial budget | Recompute `N_max_effective` for each cell; apply C22’s minimum rule and >2× discrepancy rule; prohibit exhaustive grids at intervals ≤12h under C24. ART-07; C22–C24. | **BLOCKED.** No independently recomputed 1h cell budget or reproducible trial panel is available. | Do not authorize broad search or confirmatory claims until the budget exists. Regression: search logs reject over-budget runs and exhaustive ≤12h full-grid configurations. |
| **R-012** | Universe and liquidity screens | Verify actual-size turnover and same-side depth against the disclosed formulas, units, assumptions, and as-of data. Preserve 0.01% turnover and 1% depth values as provisional design judgments—not measured capacity. ART-06; C8/C9/C10. | **BLOCKED.** No current per-symbol turnover, reproducible book depth, or risk-derived actual notional is available. | No symbol passes by aggregate snapshot or unsupported depth; exclude/block affected cells. Regression: unit tests check the inequalities and audit records retain inputs, bands, sides, and timestamps. |
| **R-013** | Timeframes and per-symbol historical depth | Verify the selected 1h series is completed and sufficiently covered for each candidate. Treat the reported 3,500 cap as non-guaranteed; do not claim unmeasured coverage. ART-06; C1/C2/C17/C18/C25. | **BLOCKED.** Per-symbol, per-timeframe depth and exact universe history are unavailable. | Mark coverage `BLOCKED`; do not substitute an interval or venue silently. Regression: each universe snapshot stores requested/returned bars, verified span, gaps, and history-adequacy decision. |
| **R-014** | Data quality, lineage, and failure behavior | Exercise missing, stale, duplicate, malformed, contradictory, and unavailable inputs; preserve raw provenance and source tier. ART-06/08. | **NOT TESTED.** Policies are specified but not implemented or fault-tested. | Quarantine or reject invalid input; block dependent signals and preserve evidence. Regression: fault-injection suite checks no forward-fill, no last-write-wins for conflicts, and idempotent exact-duplicate handling. |
| **R-015** | Cross-venue permission and isolation | Verify A5 access, legal/sanctions, licensing, cost, and owner-approval conditions before use; prove external and derived data are denied to Paper/Live without explicit approval and transfer validation. ART-06; C17/C18/C26. | **BLOCKED.** Provider identity/terms and owner/legal conditions are not established. | Do not ingest or use the source; retain Toobit-native and external namespaces separately. Regression: mode/source allowlist tests reject direct and transformed external inputs in Paper/Live. |
| **R-016** | Workload, storage, and POCO X6 fit | Use the C19 scaling formula only for a matching row shape; measure representative workload, storage, memory, sustained CPU, thermal response, Android background survival, and recovery. ART-06/10; C14–C16/C19. | **BLOCKED.** \(S\), verified data shape, actual device workload, and sustained behavior are not established. | Make no phone-fit claim; keep any device-dependent topology unapproved. Regression: repeat measurements after workload, schema, retention, or runtime changes. |
| **R-017** | Deployment topology and trade-off assessment | Assess all seven Part 3 topologies against the derived envelope and A8’s compromise requirements before selecting one. Preserve the exact owner-ratified compromise order only if its wording is available; Part 8’s temporary ordering is not ratified. ART-05/10. | **BLOCKED.** No topology has passed envelope fit; host conditions are unknown and the exact ordinal source wording is unavailable in the record. | Select none on assumptions; document residual evidence gaps. Regression: topology changes require a refreshed workload, security, recovery, and compromise comparison. |
| **R-018** | Component boundaries and state ownership | Verify strategy cannot write orders; risk authority owns authorization; OMS is the sole exchange writer; exchange facts, local intent, Paper state, and Telegram delivery state are not conflated. ART-08. | **NOT TESTED.** Logical boundaries are designed, not implemented. | Block any discovered bypass or state-authority ambiguity. Regression: dependency/permission tests prove the only exchange-write route and reject direct module writes. |
| **R-019** | Independent risk authority and authorization scope | Test that every risk-increasing intent requires a current, bounded, single-use, scope-matched authorization, accounting for positions, working orders, and reservations. ART-08/09; ART-07. | **BLOCKED.** Approved numeric risk limits and the owner risk boundary are absent. | Deny risk-increasing actions and retain conservative reservations. Regression: changed state, expired permits, or mismatched quantity/contract invalidates authorization. |
| **R-020** | Order lifecycle and reconciliation | Exercise `UNKNOWN`, partial fills, cancellation races, duplicate/out-of-order events, terminal status, and separate reconciliation state. Verify no blind retry after ambiguity and no assumption that a local intent proves exchange outcome. ART-09/10; C5/C11/C12. | **BLOCKED.** Actual Toobit endpoint semantics, identifier lookup scope, and reconciliation coverage were not verified. | Keep outcome and exposure unknown; block conflicting new risk; reconcile. Regression: mock and later validated-adapter tests cover timeout-after-acceptance, delayed fills, and cancel/fill races. |
| **R-021** | Telegram command contract | Validate every supported command’s syntax, idempotency, exact target, authority, and command-specific preconditions; prohibit unsupported broad or risk-override commands. ART-09. | **NOT TESTED.** No command adapter or authorization policy was implemented. | Reject malformed, unauthorized, stale, duplicate, or unsupported commands without side effects. Regression: parser, duplicate-delivery, stale-command, and per-command precondition tests. |
| **R-022** | Operator unreachable and Telegram-loss behavior | Demonstrate that new risk is blocked by default during defined transport failure, while independent reconciliation and authorized position management continue; unknown exchange outcomes stay unknown. A9; ART-08/09/10. | **NOT TESTED.** Transport-health thresholds and outage behavior were not implemented or measured. | Do not infer operator absence from silence; do not abandon open positions or blindly cancel protective orders. Regression: outage/restore tests verify no auto-resume and no dependency on operator reply for authorized safety actions. |
| **R-023** | Six Live interlocks | Independently evaluate data validity, reconciliation, risk-limit definition/bounds, credential/permission validity, configuration integrity, and clock validity for Live selection. A10; ART-08/09. | **BLOCKED.** Risk definition is pending; the other interlocks have not been implemented or tested. | Any unknown/stale/failed interlock blocks Live selection; mode selection cannot bypass per-order checks. Regression: one-at-a-time and combined-failure tests prove each interlock is enforced. |
| **R-024** | Security, command authorization, and credential isolation | Verify application-level Telegram authorization, secret redaction/isolation, least privilege, source and artifact integrity, and no credential exposure to strategy or chat. ART-10; A2/A4/A5. | **BLOCKED.** No credential scope, Telegram integration, host, or security implementation has been reviewed or tested. | Keep mutating commands and Live writes disabled where identity, permission, or secret isolation is unverified. Regression: access-control, redaction, threat, and permission-change tests. |
| **R-025** | Durability, reliability, and recovery | Test pre-dispatch durable intent, crash/storage interruption, restore, restart, and post-restart reconciliation; do not treat C12’s provisional three-day threshold as verified retention. ART-08/10; C12. | **NOT TESTED.** No database, backup, fault-injection, or recovery exercise occurred. | Block new exposure until journal recovery and reconciliation are complete; escalate persistent discrepancies. Regression: crash-at-each-write-boundary and restore tests retain intents and never auto-resubmit unknown orders. |
| **R-026** | Auditability and traceability | Verify requirements, decisions, data lineage, trials, commands, authorization, and external observations have reproducible identifiers and artifact links. ART-02/04/06–10. | **NOT TESTED.** The design messages are the available artifact layer; no software audit journal exists. | Treat missing or inconsistent audit context as a fault and preserve records for correction. Regression: sampled end-to-end trace links source data through signal, permit, intent, outcome, and reconciliation. |
| **R-027** | Costs and execution realism | Validate fees, spread, slippage/impact, funding, fill timing, and stop-gap assumptions; distinguish the scoped C10 ratios from any unmeasured 1h result and do not assume maker fill. ART-06/07; C6/C7/C10. | **NOT TESTED.** No execution dataset, fee resolution, or strategy result is available. | Mark cost-dependent conclusions incomplete; do not report gross performance as net or claim fills from bar touches. Regression: cost-model changes create new versioned runs and are checked against hand calculations. |
| **R-028** | Risk-derived implementation and verification phases | Confirm dependency ordering, parallelizable work, safe phase exits, and explicit blockers; no topology selection before workload measurements and no arbitrary Live waiting/profit hurdle. ART-11; A8/A10. | **NOT TESTED.** This plan has not been executed; no implementation phase has passed. | Keep future changes within the dependency and safety constraints; revise the plan when evidence changes. Regression: phase-entry review verifies prerequisite artifacts and identifies unresolved blockers. |
| **R-029** | Final completeness and self-verification | At project close, reconcile all requirements, status counts, exclusions, not-relevant items, artifacts, design changes, and V-1 through V-12 records. ART-03/04 and the Part 10 acceptance package. | **NOT TESTED / DEFERRED.** The final acceptance and completeness declaration belongs to Part 10. | Do not declare the engagement complete until counts reconcile arithmetically and each verification record has evidence and, if needed, corrective action. Regression: independently check every R ID, V ID, and artifact disposition before release. |

**Interim status arithmetic for the 29 requirements:** PASS 1 + FAIL 0 + BLOCKED 13 + NOT TESTED 14 + UNRESOLVED 1 = **29**. This is the matrix’s primary-status tally—not the final engagement completeness declaration. No requirement is classified as intentionally excluded or not relevant in this matrix.

## 6. Desk-based adversarial review

This is an **internal design challenge**, not an independent review. No separate reviewer, source archive, exchange endpoint, test environment, or device was available. The purpose is to expose credible failure paths in the proposed design and state the resulting controls and residual evidence gaps.

| Adversarial scenario | Why it is credible | Design clarification or strengthening | Residual limitation |
|---|---|---|---|
| **Treat 3,500 candles as guaranteed history for every contract** | C2 reports a cap/observed depth, limited census coverage, and a measured 1d example—not a complete symbol/timeframe guarantee. | Require per-contract, per-timeframe coverage evidence. A shortfall blocks the cell; the cap cannot populate the universe register. | Actual Toobit-native depth by contract remains unknown. |
| **Seed the universe from “134 symbols ≥10M” or the ten-symbol storage example** | C9 is an aggregate snapshot; C19’s ten symbols are arbitrary and not a universe recommendation. Neither provides the current contract list. | Accept no symbol on aggregate counts or storage examples. Require exact, as-of contract rows and measurements. | Current contract IDs, turnover, and book depth remain unavailable. |
| **Call the liquidity fractions measured capacity limits** | The 0.01% turnover fraction and 1% displayed-depth fraction were chosen as design heuristics; C8’s depth evidence is non-reproducible. | Label \(\alpha\) and \(\beta\) **DESIGN_JUDGMENT**; keep them sensitivity-testable and do not admit symbols without actual inputs. | The heuristics still require prospective slippage evidence and review; no book-depth pass currently exists. |
| **Use the completed hourly close as an executable entry** | That close may not be available until after the decision and does not reveal intrabar path or fill. | Require post-signal executable timing; prohibit same-completed-close fills and favorable assumptions for ambiguous bars. | Real fill and latency behavior remains untested. |
| **Mistake 1h signal cadence for maximum intraday holding duration** | Signal interval and position holding period are different quantities; exits, funding, and costs are unresolved. | Derive duration from the actual strategy, costs, funding, risk, and validation; do not invent a fixed holding period. | SC-01’s exits and duration remain unselected. |
| **Let an old cross-venue candle silently repair a Toobit gap** | Transfer evidence is limited; venue contract mapping and licensing are unresolved, and execution/funding do not transfer automatically. | Preserve source tags, prohibit silent blending, gate external and derived data away from Paper/Live until A5 and validation pass. | Exact provider, permissions, coverage, and terms are unknown. |
| **Retry an order after timeout and double the exposure** | C5 says `-1007 TIMEOUT` is ambiguous; a missing response is not proof of rejection. | Persist intent and reservation before dispatch; represent outcome as `UNKNOWN`; reconcile rather than blind-resubmit. | Actual Toobit lookup, ID, retention, and duplicate semantics are unverified. |
| **Assume a cancellation removed the position or stopped a fill** | Fill/cancel races and partial fills can occur; a cancel request or acknowledgement is not a reconciled position. | Separate cancellation, order, fill, and position state; retain reservations until confirmed and reconciled. | Endpoint status mappings and protective-order semantics are unknown. |
| **Let Telegram silence decide that the operator is absent—or make safety wait for a reply** | Lack of messages is not proof of transport failure; inbound connectivity is unstable. | Detect transport health separately; block new entries by default on verified loss, continue authorized position management and reconciliation, and never equate silence with resolution. | Outage thresholds and unattended-policy details need measurement; no implementation exists. |
| **Assume charging and a 24-hour test prove the phone can run the system** | Android standby/background rules and sustained workload behavior are unmeasured. | Measure representative CPU, physical memory, storage, thermal, background, network, and recovery behavior before judging TP-01/02/03/05. | No topology has passed; the workload size is still unknown. |
| **Treat `/mode live` as an order permission or add an arbitrary profit/cooldown hurdle** | A selector can be confused with risk authority; an arbitrary delay or PnL threshold is not a substitute for controls. | Separate selected mode from execution gate; enforce A10’s six interlocks; require fresh per-order authorization without an arbitrary wait or profit hurdle. | Risk, credentials, data, configuration, clock, and reconciliation have not passed in implementation. |
| **Let the 5% preference become a default because it appears in a sensitivity table** | Repeated illustrative values can become implicit configuration. | Preserve the pending boundary, show all required sensitivities, and prohibit defaults derived from the preference. | The owner’s eventual decision remains pending; no value is inferred. |
| **Turn a provisional study result into an unbounded search** | C20–C24 identify unit, trial-count, and full-grid risks. | Recompute the per-cell trial budget, retain every trial, and prohibit exhaustive full grids at intervals ≤12h. | The independently recomputed 1h budget remains unavailable. |
| **Release a risk reservation because the process restarted or the local database says “flat”** | Local state may be incomplete while an external order is still active or unknown. | Recover journal and outbox, query validated exchange state, and reconcile before releasing reservations or allowing new risk. | Restore and reconciliation behavior is not yet tested; exchange retention is unresolved. |

### 6.1 Material design clarifications from this review

The adversarial pass did not alter any binding owner constraint. It made the following controls explicit across the proposed design:

1. **No aggregate-evidence shortcut:** C9’s count, C19’s storage example, and C2’s candle cap cannot admit a symbol or establish complete coverage.
2. **Liquidity values remain provisional:** turnover and depth fractions are visible design choices with explicit formulas—not measured impact limits or capacity facts.
3. **Signal and execution time remain separate:** completed-bar information cannot be filled at the same close by assumption.
4. **Mode and authority remain distinct:** a Live mode selection cannot replace six interlocks or per-order risk authorization.
5. **Intent, exchange outcome, cancellation, and position remain distinct:** ambiguous writes and cancel/fill races preserve possible exposure.
6. **Recovery is state-based:** process restart or Telegram recovery cannot automatically clear unknown state, release a reservation, or resume entries.
7. **Device and topology fit remain open:** hardware specifications and a prior charging test cannot substitute for representative workload measurement.
8. **The owner’s exact compromise order is not inferred:** Part 8’s temporary ordering remains design judgment until the source wording is available.
9. **Risk preferences remain unselected:** sensitivity tables do not become a default or implicit limit.
10. **Source provenance includes derived data:** a transformation does not remove an unapproved source’s Paper/Live restriction.

## 7. Part 9 handoff

ART-11 delivers the proposed risk-derived implementation phases, the dependency graph, a future verification approach, an exactly 29-row matrix, and a clearly bounded desk-based adversarial review. It does **not** report code, tests, backtests, a verified strategy, a selected deployment topology, or Live readiness.

The unresolved items remain visible rather than treated as design failures that require invented values: exact current Toobit contracts and per-symbol data; per-cell trial budget; strategy exits and holding duration; owner risk boundary; cross-venue permissions; endpoint semantics; credential permissions; POCO X6/workload measurements; topology fit; and the exact owner-ratified compromise-order wording.

**Registry update:** ART-01 through **ART-11 DELIVERED**; ART-12 remains **DEFERRED**. Part 10 will provide the final acceptance and traceability audit, the complete reconciled completeness declaration, artifact-registry closure, individual V-1 through V-12 records, and the final self-verification.


وضعیت: **بخش ۱۰ از ۱۰ — ارزیابی نهایی، حسابرسی، اعلام تکمیل و خودراستی‌آزمایی، ART-12، تکمیل شد.** این پذیرش فقط به کامل‌بودن بستهٔ مستندات طراحی در محدودهٔ این کار اشاره دارد؛ نه پذیرش رسمی مالک، نه تأیید صحت پیاده‌سازی و نه مجوز فعالیت معاملاتی. ریسک همچنان **OWNER_DECISION_PENDING** است و Live مجاز نیست.

# Part 10/10 — Final Acceptance, Audit, Completeness Declaration, and Self-Verification (ART-12)

## 1. Final acceptance scope

This is the final **design-package acceptance assessment** for the design-only engagement. It is not an owner sign-off or an acceptance test of a built system.

The only project source available was the conversation’s parsed text of the owner-supplied 54-page “MASTER PROMPT.” The original PDF, its metadata, the raw evidence archive, and a repository were unavailable. No external browsing, exchange or account access, credential use, code execution, backtest, device measurement, implementation test, or independent review was performed.

Accordingly:

- C1–C26 remain **owner-supplied findings or summaries**, not source-verified facts from this engagement.
- C25 is an **OWNER_SUPPLIED_AUDIT_SUMMARY**; no claim is made that its 149 underlying records were inspected.
- The earlier research checkpoint was delivered before external research, but its date remains unresolved because no verified UTC date was available.
- The exact wording of the owner-specified compromise order is not reproduced in the available project record. Part 8’s interim ordering remains a design judgment, not an owner-ratified sequence.

## 2. Readiness dimensions — reported separately

| Dimension | Final assessment | What this does—and does not—mean |
|---|---|---|
| **Design-document completeness** | **PASS — document scope** | ART-01 through ART-12 are delivered; all 29 register requirements are dispositioned. Blocked and unresolved items are disclosed rather than filled with invented facts. This does not mean the system has been implemented or validated. |
| **Formal owner acceptance** | **Not received / not asserted** | The user requested continuation of the design. No separate owner sign-off is represented here. |
| **Source review** | **LIMITED / UNRESOLVED** | Only the parsed prompt text was available. Owner-supplied summaries have not been independently checked against the original files or external sources. |
| **Backtest or research evidence** | **NOT TESTED** | SC-01 has no backtest result or profitability evidence. No strategy was accepted for deployment. |
| **Implementation correctness** | **NOT TESTED** | No code or system implementation was available to test. |
| **Paper behavior** | **NOT TESTED** | No Paper system or simulator was implemented or run. |
| **Operational readiness** | **BLOCKED / NOT TESTED** | No topology was selected or measured. POCO X6 workload, host conditions, recovery, and API behavior remain untested. |
| **Live authorization** | **NOT AUTHORIZED / BLOCKED** | This was a design-only engagement. The risk boundary remains pending and the six Live interlocks have not been implementation-tested. No account or order activity took place. |

A complete design document is not a live-ready system. The seven deployment topologies remain unassessed for actual envelope fit, and no strategy performance claim is made.

## 3. Final completeness declaration

### 3.1 Requirement dispositions

The final tally covers exactly the **29 requirements R-001 through R-029**. The Part 9 matrix had exactly 29 rows. Its interim `NOT TESTED / DEFERRED` status for R-029 is superseded here: the final declaration and document-level self-check have now been delivered, so R-029 is **PASS at document scope only**. No other requirement status changes.

| Final status | Requirement IDs | Count |
|---|---|---:|
| **PASS — document/engagement scope only** | R-001, R-029 | **2** |
| **FAIL** | None | **0** |
| **BLOCKED** | R-003, R-006, R-009, R-011, R-012, R-013, R-015, R-016, R-017, R-019, R-020, R-023, R-024 | **13** |
| **NOT TESTED** | R-004, R-005, R-007, R-008, R-010, R-014, R-018, R-021, R-022, R-025, R-026, R-027, R-028 | **13** |
| **UNRESOLVED** | R-002 | **1** |
| **Intentionally excluded requirements** | None | **0** |
| **Not-relevant requirements** | None | **0** |

**Arithmetic:** `2 + 0 + 13 + 13 + 1 + 0 + 0 = 29`.

No requirement has been omitted, intentionally excluded, or classified as irrelevant. The design-only scope still excludes activities such as account access, credential use, authenticated exchange calls, funds access, and order actions; those are binding constraints, **not omitted requirement rows**.

### 3.2 Meaning of the two PASS entries

- **R-001 — PASS, engagement boundary only:** no prohibited account, credential, authenticated exchange, funds, or order action occurred in this design engagement. This is not a system-safety test.
- **R-029 — PASS, document scope only:** the final completeness declaration, arithmetic, artifact registry, and V-1 through V-12 records are present. This is not implementation acceptance.

The `FAIL` count is zero because no executed implementation acceptance test failed; it must **not** be read as evidence that untested software passed.

## 4. Final self-verification records: V-1 through V-12

These are final **document and scope self-checks**, not independent reviews or implementation tests. “Corrective action” states how to close a gap or respond if a check fails.

| ID | Check and evidence pointer | Result | Corrective action if failed or still blocked |
|---|---|---|---|
| **V-1** | **Engagement boundary:** check that the deliverable remains design-only and does not claim account access, credentials, authenticated calls, funds access, or order actions. Evidence: Part 1 scope/checkpoint; A4; R-001; this Part 10 §1. | **PASS — engagement-record scope only.** | If any such action is later identified, stop the affected work, disclose it, preserve the incident record, and review any credentials or permissions involved. Do not describe the engagement as design-only without qualification. |
| **V-2** | **Requirement coverage:** check that each register ID R-001–R-029 appears in the Part 9 verification matrix without a gap. Evidence: ART-04; Part 9 §5; Part 10 §3. | **PASS — document audit.** | If an ID is missing or duplicated, reconcile it against ART-04, restore one disposition for every requirement, and reissue the arithmetic before claiming completion. |
| **V-3** | **Source provenance:** check that owner-supplied summaries are not described as externally verified and that raw-archive review is not claimed. Evidence: Part 1 environment/checkpoint record; ART-04 C1–C26; Part 10 §1. | **UNRESOLVED.** The parsed prompt was available; the original PDF and raw evidence archive were not. | If source files become available under proper authorization, inspect the original and archive, reconcile each C-series claim, update statuses and evidence pointers, and correct any unsupported statement. Until then, retain the limitation. |
| **V-4** | **Displayed calculation and unit audit:** hand-check the stated turnover inequality, C19 storage scaling, two-leg fee arithmetic, and Part 5 risk-sensitivity formulas. Evidence: Part 4 §§3 and 10; Part 5 §7. | **PASS — hand-check at displayed precision only.** No code was run. | If a discrepancy is found, correct the inputs, units, equations, and affected tables; rerun the calculation and associated regression checks before using the value. |
| **V-5** | **Universe and per-symbol coverage:** check that no current Toobit symbol list, per-symbol book depth, or per-symbol historical depth has been invented. Evidence: Part 4 §§4–5; C1/C2/C8/C9/C25; R-003/R-012/R-013. | **BLOCKED.** No exact current symbol census or per-symbol depth matrix was available. The universe register remains unpopulated. | Obtain permitted, timestamped contract, metadata, turnover, book, and history evidence; populate inclusion and exclusion rows; recalculate each screen. Do not infer eligibility from C9’s aggregate count or C19’s storage example. |
| **V-6** | **Research and trial governance:** check that SC-01 is not presented as profitable, that C20–C24 remain scoped, and that no exhaustive full-grid search at intervals ≤12h is proposed. Evidence: Parts 3 and 5 §§2–5; C20–C24; R-007/R-008/R-011/R-027. | **NOT TESTED / BLOCKED.** No strategy data, backtest, or independently recomputed 1h trial budget was available. | Preregister the candidate and validation design, recompute the per-cell budget, use point-in-time data and realistic costs, retain all trials, and report insufficient history honestly. Do not promote the result without the specified evidence. |
| **V-7** | **Risk-boundary integrity:** check that the 0.5%, 1%, 2%, 5%, and 10% rows remain sensitivities; neither the 5% per-trade preference nor the 15–20% drawdown preference became a limit. Evidence: Part 5 §§1, 6–9; R-009/R-010/R-019. | **PASS — document-level safeguard check.** No risk limit was selected. | If any implementation or configuration makes a preference effective by default, remove that default and block risk-increasing authorization until the nondelegable owner decision and necessary configuration validation exist. |
| **V-8** | **Component authority and order state:** check that strategy proposals are not orders, the OMS is the only exchange-write path, and intent, venue observation, cancellation, fill, position, and reconciliation states are distinct. Evidence: Part 6 §§3–6; Part 7 §§2–4; R-018/R-020. | **NOT TESTED.** These are design contracts; no implementation or endpoint test exists. | Implement the boundaries and state transitions; test partial fills, ambiguous outcomes, duplicates, out-of-order events, and cancellation races using controlled test adapters, then validate actual exchange semantics under separately authorized procedures. |
| **V-9** | **Telegram, outage, and Live interlocks:** check that the command contract is explicit, Telegram is not the risk authority, outage does not resolve exchange ambiguity, and all six A10 interlocks remain required. Evidence: Part 7 §§5–7; Part 8 §§6–7; R-004/R-021/R-022/R-023. | **NOT TESTED.** No command adapter, authorization policy, transport test, or interlock implementation exists. | Implement and test the command-specific preconditions, authorization, deduplication, and outage behavior. Demonstrate that each interlock independently blocks Live selection when unknown or failed and that no command bypasses per-order authorization. |
| **V-10** | **Workload and topology fit:** check that workload is derived before topology selection, all seven cataloged options are assessed, and phone or host readiness is not claimed without measurement. Evidence: Parts 4 §10 and 8 §§2–5; R-016/R-017. | **BLOCKED / NOT TESTED.** Actual workload and POCO X6 measurements are unavailable; no topology passed envelope fit. | Define and measure representative research and operating loads; measure the phone where applicable; establish external-host conditions for remote options; compare all seven topologies and record an explicit decision—or that none passes. |
| **V-11** | **Security, recovery, and venue-semantics audit:** check that no credentials, permissions, recovery tests, exchange status semantics, or protective-order behavior are claimed as verified. Evidence: Parts 7 §§4/7 and 8 §§6–9; C5/C11/C12/C13; R-020/R-024/R-025. | **BLOCKED / NOT TESTED.** No credentials, exchange interface, deployment, backup, or security test was available. | Verify the intended API and permissions through an appropriately authorized procedure; implement least privilege and secret isolation; test recovery, backup restoration, and ambiguous outcomes. Keep Live writes blocked until those controls are evidenced. |
| **V-12** | **Final completeness and artifact closure:** check the final count, R-029 closure, artifact disposition, and presence of individual V records. Evidence: Part 10 §§3–5; ART-01–ART-12 registry below. | **PASS — document-level self-check.** | If any count or artifact pointer ceases to reconcile, reopen ART-12, correct the register and evidence links, and withhold the completion declaration until the arithmetic and dispositions reconcile. |

**Self-verification limit:** no V record represents an external audit, an independent reviewer’s opinion, or an executed system test. The untested and blocked results remain explicitly open.

## 5. Material design clarifications following adversarial review

The Part 9 adversarial review was desk-based, not independent. It did not alter any binding owner constraint. It made the following consequential safeguards explicit:

| Clarification | Design treatment | Evidence pointer |
|---|---|---|
| Aggregate snapshot counts do not admit instruments | C9’s “134 symbols ≥10M” is not a list or target; C19’s ten arbitrary symbols are not a universe seed. The Part 4 register stays unpopulated until real contract-specific evidence exists. | Part 4 §§3–5; Part 9 §6 |
| Candle caps do not prove per-symbol completeness | The reported 3,500 depth is not a guarantee. Each symbol-timeframe requires actual coverage evidence. | Part 4 §4; Part 9 §6 |
| Liquidity fractions are heuristics, not capacity measurements | The 0.01% turnover and 1% displayed-depth fractions are explicitly `DESIGN_JUDGMENT`; C8’s non-reproducible depth does not pass the book gate. | Part 4 §3 |
| Signal interval and holding duration are distinct | The 1h baseline does not imply a fixed maximum holding period. Duration must be derived from strategy exits, costs, funding, risk, and validation. | Part 4 §2; Part 5 §1 |
| Signal availability and execution price are distinct | Same-completed-close fills are prohibited; candle touches alone do not establish maker fills. | Part 5 §3 |
| Mode selection is not order permission | The six Live interlocks and fresh per-order risk authorization are separate requirements. No arbitrary wait or profit hurdle is introduced. | Parts 6–7 |
| Intent, exchange outcome, cancellation, and position remain distinct | Unknown outcomes retain reservations; cancellation and partial fills require reconciliation; no blind retry is allowed. | Part 7 §§3–4 |
| Recovery does not imply a flat state | Restart, Telegram recovery, and a local “flat” projection do not clear unknown exposure without reconciliation. | Part 8 §6; Part 9 §6 |
| Device and topology fit require measurement | The supplied phone specification and prior charging observation do not establish workload, survival, or recovery fit. | Part 8 §§2–4 |
| Risk preferences and unverified source order are not silently adopted | Risk remains pending; the exact owner-specified compromise order remains unresolved instead of being invented. | Part 5 §1; Parts 8–10 |

## 6. Outstanding blockers and nondelegable matters

These are disclosed dependencies, not requests to choose delegated technical methods.

| Outstanding item | Why it remains open | Consequence |
|---|---|---|
| **Owner risk boundary** | The owner has not resolved the risk limit definitions and bounds. The 5% per-trade and 15–20% drawdown preferences remain unadopted. | No Live risk authorization; no implicit default may substitute for the decision. |
| **Exact current Toobit universe and per-symbol evidence** | The current contract list, metadata, turnover, reproducible depth, and per-symbol historical coverage were not supplied or inspected. | No symbol is declared research-, Paper-, or Live-eligible by this design. |
| **Research specification and per-cell trial budget** | SC-01 exits, holding duration, execution assumptions, and the independently recomputed 1h budget remain open. | No confirmatory or profitability claim; no broad search. |
| **Toobit interface and account semantics** | Order, cancel, fill, fee, funding, mark-price, retention, identifier, permission, and reconciliation semantics were not independently checked. | The order state machine is a design target; Live execution remains blocked. |
| **Cross-venue access and approval** | Registration/KYC or equivalent, legal/sanctions, licensing, payment, withdrawal, cost, and owner-approval conditions remain unresolved where applicable. | No unapproved external data or derivatives may enter Paper/Live. |
| **Deployment envelope and recovery** | No POCO X6 workload benchmark, host assessment, backup test, or topology fit test exists. | No deployment topology is selected or declared operationally ready. |
| **Source and traceability gaps** | The raw PDF/archive and exact compromise-order wording were unavailable; the checkpoint date is unresolved. | No independent source audit or owner-ratified ordering claim is made. |

Technical choices—including architecture, model class, programming language, framework, and optimizer—were not returned to the owner for selection. The nondelegable risk decision remains pending; cross-venue use remains gated by the applicable owner/legal conditions.

## 7. Artifact registry — final

“Delivered” means the design artifact was provided in this conversation. It does **not** mean software was built, tested, or deployed.

| Artifact | Content | Part | Final status |
|---|---|---:|---|
| **ART-01** | Capability and boundary inventory | 1 | **DELIVERED** |
| **ART-02** | Pre-research checkpoint and evidence boundary | 1 | **DELIVERED** |
| **ART-03** | Dependency graph and delivery plan | 1 | **DELIVERED** |
| **ART-04** | Requirements register and owner-supplied evidence ledger | 2 | **DELIVERED** |
| **ART-05** | Strategy/process candidates and deployment-topology catalog | 3 | **DELIVERED** |
| **ART-06** | Universe derivation, liquidity screens, and data contract | 4 | **DELIVERED** |
| **ART-07** | Statistical methodology, parameter governance, and risk sensitivity | 5 | **DELIVERED** |
| **ART-08** | Component boundaries, state ownership, interfaces, and flows | 6 | **DELIVERED** |
| **ART-09** | Risk authority, order lifecycle, and Telegram command contract | 7 | **DELIVERED** |
| **ART-10** | Workload-first topology assessment, security, reliability, and recovery | 8 | **DELIVERED** |
| **ART-11** | Risk-derived phases, 29-row verification matrix, and adversarial review | 9 | **DELIVERED** |
| **ART-12** | Final acceptance assessment, completeness declaration, audit, and V-1–V-12 | 10 | **DELIVERED** |

**Artifact arithmetic:** `12 delivered + 0 deferred = 12 planned artifacts`.

## 8. Final acceptance statement

The design-only document package is **complete at the declared specification scope**: the 29 requirements are dispositioned, the planned artifacts are delivered, the status arithmetic reconciles, and the open evidence gaps and owner decisions are explicit.

This is **not** a claim of source-verified market facts, strategy profitability, implementation correctness, Paper validation, operational readiness, or Live authorization. No account access, credentials, authenticated calls, funds access, or order activity occurred. The risk boundary remains pending, no deployment topology has passed its envelope assessment, and **Live is not authorized**.

**پایان کار:** هر ۱۲ artifact طراحی تحویل شد و وضعیت ۲۹ نیازمندی از نظر مستندات حسابرسی شد. این نتیجه به معنی آزمون نرم‌افزار یا آمادگی معامله نیست: بک‌تست، پیاده‌سازی، Paper و آمادگی عملیاتی آزمون نشده‌اند؛ مرز ریسک هنوز **در انتظار تصمیم مالک** است و Live مجاز نیست.

