***

# QUANTITATIVE TRADING SYSTEM ARCHITECTURE SPECIFICATION
## Venue: Toobit Perpetual Futures | Target: Telegram Bot & Mobile Hybrid Topology
### PART 1 OF 3: CORE FOUNDATIONS, EMPIRICAL EVIDENCE, PARAMETRIC RISK & MASTER REQUIREMENTS REGISTER

---

## 1. System Charter & Foundational Principles

### 1.1 Scope and Objective
This document establishes the authoritative, clean-sheet architectural specification for an autonomous quantitative trading system operating exclusively on Toobit perpetual futures (`linear-swap`), administered solely via a private Telegram bot interface, and evaluated for execution across an Android 16 / Termux environment (Xiaomi POCO X6) and a hybrid cloud topology. The capital scale under design is parametrically anchored to 200–500 USDT.

### 1.2 Core Invariants
The system design adheres to five non-negotiable structural axioms:
1. **Zero Unhedged Capital at Rest:** Margin allocation is demand-driven and transient; capital at rest remains entirely in liquid USDT settlement balance.
2. **Deterministic Risk Bounds Prior to Order Dispatch:** No order payload may be transmitted across the network unless pre-allocated risk, liquidation distance, execution friction, and drawdown headroom have been strictly validated against the persistent risk ledger.
3. **Fail-Closed Execution Posture:** Any telemetry disruption, rate-limit anomaly, clock desynchronization, unhandled exception, or missing ledger state unconditionally transitions execution to a non-destructive, read-only fail-closed state.
4. **Decoupled Operator Boundary:** The Telegram bot serves strictly as an untrusted remote human-machine interface (HMI). It owns zero domain state, executes zero position calculations, and cannot bypass the independent Risk Engine.
5. **Strict Parametric Scaling:** Leverage, lot sizes, fees, and stop distances are computed as explicit mathematical functions of real-time equity, instrument tick/lot rules, and empirical volatility, eliminating static assumptions.

---

## 2. ART-001: Execution Envelope Inventory

```
+----------------------------------------------------------------------------------------------------+
|                                    HARDWARE & OS ENVELOPE (C14)                                    |
| Device: Xiaomi POCO X6 (23122PCD1G)             SoC: Qualcomm Snapdragon 7s Gen 2 (4nm)            |
| CPU: 4x Cortex-A78 @ 2.40 GHz (Perf)            RAM: 12.0 GB LPDDR4X (Available snapshot: ~7.2 GB) |
|      4x Cortex-A55 @ 1.95 GHz (Efficiency)      Storage: 256 GB UFS 2.2 (Available: 56.0 GB)       |
| OS: Android 16 (BP2A.250605.031.A3)             Kernel: Linux 5.10.236-android14-11-29739506-ab... |
| Runtime: Termux v0.118+ (glibc / bionic chroot) Network: Dual-SIM LTE Cat-18 + Wi-Fi 6 (802.11ax)   |
+----------------------------------------------------------------------------------------------------+
                                                  |
                                                  v
+----------------------------------------------------------------------------------------------------+
|                                     OPERATIONAL RESTRICTIONS                                       |
| - Android 16 App Standby: Bucket escalates to RESTRICTED after 12h of zero direct touch (C15).      |
| - Battery Optimization: Device Idle / Doze mode suspends wakefulness unless foreground service held|
| - Thermal Envelope: Ambient 25°C -> sustained multi-core load throttles Cortex-A78 down to 1.4 GHz |
| - Inbound Routing: Handset behind dynamic CGNAT; inbound TCP/REST strictly impossible (A9).         |
+----------------------------------------------------------------------------------------------------+
```

### 2.1 Compute, Memory, and Storage Budgets
- **Resident Set Size (RSS) Ceiling:** 450 MB maximum resident memory footprint for the entire trading process group on Android, leaving $>90\%$ of free RAM untouched.
- **CPU Duty Cycle Limit:** Sustained background compute must not exceed 4% total CPU capacity on average, with transient burst processing (CPCV / inference recalculations) capped at 60 seconds on efficiency cores.
- **Flash Storage IOPS & Wear Budget:** Maximum SQLite write frequency of 1 sync write per minute under steady state, utilizing Write-Ahead Logging (`PRAGMA journal_mode=WAL;`) with synchronous setting `NORMAL`. Daily flash wear is bounded below 150 MB.
- **Data Footprint:** Dual-timeframe rolling window for 6 trading symbols (Macro 1d: 1,000 bars; Signal 4h: 3,500 bars) calibrated at 2,551 bytes/candle (C19) yields a physical SQLite database footprint of **889.14 MB**, well within the 56 GB available flash envelope.

---

## 3. ART-002: Pre-Sequencing Dependency DAG

```
       [ C1-C26 Empirical Reality Baseline ]
                        |
                        v
       [ D11/D13 Dependency-First Analysis ]
                        |
       +----------------+----------------+
       |                                 |
       v                                 v
[ ART-001 Hardware      [ ART-005 Parametric Risk
  Envelope Constraints ]   & Sizing Mathematics ]
       |                                 |
       +----------------+----------------+
                        |
                        v
       [ ART-006 Master Requirements Register (R-001 - R-035) ]
                        |
       +----------------+----------------+
       |                                 |
       v                                 v
[ ART-007 Statistical   [ ART-009 Deployment Topology
  Budgeting (DSR/MinTRL)]  Evaluation (T1 vs T2 vs T3) ]
       |                                 |
       v                                 v
[ ART-008 Universe      [ ART-011 Architectural
  Selection (6 Symbols) ]  Dimension Register ]
       |                                 |
       +----------------+----------------+
                        |
                        v
       [ ART-012 Ingestion & Resiliency Subsystem ]
                        |
       +----------------+----------------+
       |                                 |
       v                                 v
[ ART-013 Component     [ ART-015 Independent Risk Engine
  Boundary Contracts ]     & Veto State Machine ]
       |                                 |
       +----------------+----------------+
                        |
                        v
       [ ART-014 Order Lifecycle & -1007 Ambiguity Machine ]
                        |
                        v
       [ ART-016 Operator Interface & Interlocked Mode Selector ]
                        |
                        v
       [ ART-017 1:1 Requirement Verification Matrix & Falsification ]
```

---

## 4. ART-003: Artifact Registry Baseline

| Artifact ID | Artifact Description | Architectural Target | Delivery Part |
| :--- | :--- | :--- | :--- |
| **ART-001** | Execution Envelope Inventory | Device & OS Constraints | Part 1, §2 |
| **ART-002** | Pre-Sequencing Dependency DAG | Structural System Sequence | Part 1, §3 |
| **ART-003** | Artifact Registry Baseline | Master Traceability Index | Part 1, §4 |
| **ART-004** | Pre-Research Checkpoint | Empirical Reality Gaps (C1–C26)| Part 1, §5 |
| **ART-005** | Risk Mechanics & Parametric Model | Position Sizing & Margin Math | Part 1, §6 |
| **ART-006** | Master Requirements Register | Formal System Requirements | Part 1, §7 |
| **ART-007** | Statistical Budget & DSR Derivation| Multiple Testing Discipline | Part 2, §3 |
| **ART-008** | Derived Universe Register | Instrument Sizing & Feasibility| Part 2, §4 |
| **ART-009** | Deployment Topology Matrix | T-1 vs T-2 vs T-3 Evaluation | Part 2, §5 |
| **ART-010** | Phase Deviation Table | Alignment of Operator Terminology| Part 2, §6 |
| **ART-011** | Architectural Dimension Register | 10 Technical Dimensions | Part 2, §7 |
| **ART-012** | Data Ingestion & Anomaly Contract | REST/WS Reconciliation | Part 2, §8 |
| **ART-013** | Component Boundary Specifications | Subsystem State Contracts | Part 3, §9.2 |
| **ART-014** | Deterministic Order Lifecycle Machine| Execution State Transitions | Part 3, §9.7 |
| **ART-015** | Independent Risk Engine Specification| Veto Clearance Logic | Part 3, §9.6 |
| **ART-016** | Telegram Command & RBAC Contract | Telegram HMI Protocols | Part 3, §9.9 |
| **ART-017** | Requirement Verification Matrix | 1:1 Verification of R-001–R-035| Part 3, §11.1 |
| **ART-018** | Adversarial Falsification Review | Red-Team Failure Analysis | Part 3, §2.1 |
| **ART-019** | Final Completeness Declaration | Acceptance & Verification Sign-Off| Part 3, §12 |

---

## 5. ART-004: Pre-Research Checkpoint & Empirical Reality Base (C1–C26)

All architectural determinations derive strictly from the following measured empirical facts:

- **C1: Kline Intervals Supported:** Toobit perpetual REST/WS endpoints support exactly 14 candle intervals (`1m`, `3m`, `5m`, `15m`, `30m`, `1h`, `2h`, `4h`, `6h`, `8h`, `12h`, `1d`, `1w`, `1M`). The `3d` interval is empirically unsupported (HTTP 400).
- **C2: Historical Depth Limits:** REST endpoint `/api/v1/futures/klines` enforces a maximum single-request limit of 3,500 candles. Empirically, BTC daily history spans 1,774 bars.
- **C3: Leverage Ladder Non-Linearity:** BTCUSDT supports up to 100x leverage across 13 risk tiers down to 1.0x, but required initial margin step-ups accelerate above 20x.
- **C4: Absence of Rate Limit Headers:** Toobit responses completely omit `X-Api-Limit-*` or `Retry-After` headers; internal token-bucket tracking is mandatory.
- **C5: Ambiguous Error Code -1007:** REST response `{"code": -1007, "msg": "Timeout waiting for response"}` represents an unknown execution state requiring query reconciliation before retry.
- **C6: Asymmetric Taker Fee Schedule:** Published base taker fee is 0.05%, but real-world fills exhibit up to 0.06% effective taker drag; models must conservatively utilize 0.06% (6 bp).
- **C7: Funding Rate Bounds:** Observed funding rates on Toobit reach -30.0000 bp per 8-hour window; assumptions of $\pm24$ bp clamping are empirically refuted.
- **C8: Order Book Depth Calculation Variance:** Level 2 snapshot depth differs between cumulative quote volume and tick aggregation; internal book reconstruction must use raw ladder units.
- **C9: Liquidity Tiering Snapshot:** Out of 248 perpetual pairs, only 134 pairs maintain a rolling 24-hour volume $\ge 10,000,000$ USDT; median volume is 498,844 USDT.
- **C10: Cost-Per-Volatility Regime:** The maker cost-per-volatility ratio on 5-minute candles is 1.42, rendering high-frequency intraday market making unprofitable; on 4-hour candles, the ratio drops to 0.18, confirming swing/intraday feasibility.
- **C11: Client Order ID Constraint:** Toobit enforces `clientOrderId` regex matching `^[A-Za-z0-9_-]{1,36}$`; UUID4 strings without hyphens conform directly.
- **C12: Outage Duration Classification:** Toobit service interruptions historically include a 72-hour historical server outage; architectures must feature an `OUTAGE-DURABLE` class supporting cold state recovery after $>3$ days offline.
- **C13: Exclusion of `markPrice/klines.change`:** Conflicted semantics between 24h rolling mark change and bar open-to-close change mandate excluding this field from alpha generation.
- **C14: POCO X6 Physical Baseline:** Qualcomm Snapdragon 7s Gen 2 (4x A78 @ 2.4 GHz + 4x A55 @ 1.95 GHz), 12 GB RAM, 256 GB UFS 2.2 storage, Android 16.
- **C15: Android 16 App Standby Buckets:** Termux processes are classified into the `RESTRICTED` bucket after 12 hours of operator UI inactivity, even while continuously connected to AC power.
- **C16: Thermal Throttling & OEM Killers:** Xiaomi HyperOS/MIUI kernel aggressively terminates unparented daemon forks after 60 minutes under high ambient thermal load.
- **C17: Telegram Long-Polling Reliability:** Handset cellular network transitions (LTE to 5G / Wi-Fi) induce silent TCP half-open socket drops lasting up to 900 seconds without an application-level ping.
- **C18: SQLite Write Concurrency:** SQLite in default rollback journal mode corrupts under abrupt OS process termination; Write-Ahead Logging (`WAL`) is mandatory.
- **C19: Storage Density Footprint:** Empirical SQLite footprint across 10 benchmark tokens is exactly 2,551 bytes per OHLCV candle record including B-tree indexes.
- **C20: Deflated Sharpe Ratio (DSR) Formulation:** Standard Sharpe ratio validation on backtests suffers catastrophic deflation under multiple testing; DSR formulation (Bailey & López de Prado) is mandatory.
- **C21: Minimum Track Record Length (MinTRL):** At an annualized Sharpe ratio of 0.38 and skewness/kurtosis of $(-0.4, 4.2)$, MinTRL requires 19.54 years of data, confirming that purely statistical unconstrained search is inadmissible.
- **C22: Effective Testing Budget:** On 4-hour candles over 1,774 days, the maximum defensible number of independent strategy hyperparameter evaluations is bounded at $N_{max\_effective} \le 16$.
- **C23: Overfitting Degradation:** Strategies selected from unregularized grid searches exceeding 100 trials demonstrate negative out-of-sample forward expectation on crypto perpetuals.
- **C24: Intraday Timeframe Inadmissibility:** Unfiltered parameter sweeps across sub-1-hour candles fail the Family-Wise Error Rate (FWER) threshold at $\alpha = 0.01$.
- **C25: Endpoint Audit Inventory:** Audit of 149 Toobit REST endpoints identified 134 `LIVE_PASS`, 10 `LIVE_PARTIAL`, 3 `UNSUPPORTED_CONFIRMED`, and 2 `DOC_CONFLICT`.
- **C26: Open Interest History Unavailability:** Toobit provides no endpoint for historical Open Interest; OI cannot be utilized as a backtest feature.

---

## 6. ART-005: Risk Mechanics & Parametric Formulas

### 6.1 Mathematical Formulation of Position Sizing
All position sizing is governed by real-time balance metrics and nominal stop distances. Sizing is strictly parametric and contains zero fixed-lot assumptions.

Let:
- $E$: Real-Time Account Equity (USDT), where $E = \text{Wallet Balance} + \text{Unrealized PnL}$.
- $r_{trade}$: Target Trade Risk Fraction (dimensionless, pending owner decision OD-01, baseline $0.01 \le r_{trade} \le 0.02$).
- $P_{entry}$: Estimated Entry Price (USDT).
- $P_{stop}$: Nominal Stop Loss Price (USDT), established by technical structure or volatility.
- $f_{taker}$: Effective Taker Fee Rate ($= 0.0006$, i.e., 6 bp per C6).
- $s_{est}$: Conservative Slippage Allowance ($= 0.0002$, i.e., 2 bp).
- $c_{friction}$: Total Round-Trip Friction Rate:
  $$c_{friction} = 2 \times f_{taker} + 2 \times s_{est} = 0.0012 + 0.0004 = 0.0016 \quad (16\text{ bp})$$
- $d_{stop}$: Proportional Stop Loss Distance:
  $$d_{stop} = \frac{|P_{entry} - P_{stop}|}{P_{entry}}$$

The **Nominal Order Notional** ($N$, denominated in USDT) is derived as:
$$N = \frac{E \times r_{trade}}{d_{stop} + c_{friction}}$$

The **Contract Quantity** ($Q$, denominated in base asset units) is:
$$Q = \text{quantize}\left(\frac{N}{P_{entry}}, \text{lot\_step}\right)$$
subject to:
$$Q \times P_{entry} \ge \text{min\_notional}$$

```
+----------------------------------------------------------------------------------------------------+
|                                    SIZING COMPUTATION WORKFLOW                                     |
|                                                                                                    |
|  [ Account Equity: E ] ------+                                                                     |
|                              |                                                                     |
|  [ Risk Fraction: r_trade ] -+--> [ Risk Capital: E * r_trade ]                                    |
|                                                  |                                                 |
|  [ Stop Distance: d_stop ] --+                   v                                                 |
|                              +--> [ Divisor: d_stop + c_friction ] --> [ Raw Notional: N ]         |
|  [ Friction: c_friction ] ---+                                                  |                  |
|                                                                                 v                  |
|  [ Entry Price: P_entry ] -----------------------------------------> [ Raw Quantity: Q ]           |
|                                                                                 |                  |
|  [ Instrument Rules (lot_step, min_notional) ] --------------------> [ Quantized Order Q ]         |
+----------------------------------------------------------------------------------------------------+
```

### 6.2 Margin Allocation vs. True Leverage Mechanics
**Formal Proof of Leverage Invariance:**
Leverage ($L$) determines *solely* the initial margin required to hold a position; it does not scale the dollar profit or loss for a defined notional position $N$.

$$\text{Initial Margin Required } (M) = \frac{N}{L} = \frac{Q \times P_{entry}}{L}$$
$$\Delta \text{PnL} = Q \times (P_{exit} - P_{entry}) = N \times \frac{P_{exit} - P_{entry}}{P_{entry}}$$

Thus, $\Delta \text{PnL}$ is strictly a function of notional $N$ and asset price return, independent of $L$. Increasing $L$ reduces initial margin $M$, freeing collateral but shifting the liquidation price dangerously close to the entry price.

### 6.3 Liquidation Distance Safety Proof
To ensure that an adverse market excursion triggers the technical stop loss long before liquidation is approached, the system enforces a strict Liquidation Buffer Constraint:

$$d_{liq} \ge 1.5 \times d_{stop}$$

Where $d_{liq} = \frac{|P_{entry} - P_{liq}|}{P_{entry}}$. 
For an isolated long position with maintenance margin rate $MMR$:
$$P_{liq} = P_{entry} \times \left(1 - \frac{1}{L} + MMR\right) \implies d_{liq} \approx \frac{1}{L} - MMR$$
To satisfy $d_{liq} \ge 1.5 \times d_{stop}$:
$$\frac{1}{L} \ge 1.5 \times d_{stop} + MMR \implies L \le \frac{1}{1.5 \times d_{stop} + MMR}$$
The system dynamically computes the maximum permissible leverage $L_{max\_safe}$ per order and clamps configured leverage accordingly.

### 6.4 Stop Loss vs. Guaranteed Loss Cap Distinction
> **CRITICAL ARCHITECTURAL WARNING:**
> A nominal stop loss order placed via REST/WS (whether market or limit) is **NOT** a guaranteed loss cap. In situations of exchange engine queuing, order book gaps, or extreme volatility, execution of a market stop loss will incur slippage:
> $$\text{Realized Loss} = N \times (d_{stop} + \text{slippage}_{realized}) + \text{Fees}$$
> If slippage exceeds the conservative estimate ($s_{est}$), realized loss will exceed $E \times r_{trade}$. The system explicitly treats $E \times r_{trade}$ as a *target expectancy*, not an absolute guarantee, and provisions an emergency capital buffer of 20% total equity against catastrophic tail gap events.

### 6.5 Worked Numerical Sizing Examples
The following matrix displays parametric sizing across three planning equity levels ($E \in \{200, 350, 500\}$ USDT) and three stop distances ($d_{stop} \in \{1.0\%, 2.5\%, 4.0\%\}$), with $r_{trade} = 0.01$ (1.0%) and $c_{friction} = 0.0016$ (16 bp):

| Equity ($E$) | $r_{trade}$ | Risk Capital ($E \times r$) | $d_{stop}$ | $d_{stop} + c_{friction}$ | Position Notional ($N$) | Required Margin ($L=10x$) | Permissible $L_{max\_safe}$ |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **200 USDT** | 1.0% | 2.00 USDT | 1.0% (0.010) | 0.0116 | **172.41 USDT** | 17.24 USDT | 40x |
| **200 USDT** | 1.0% | 2.00 USDT | 2.5% (0.025) | 0.0266 | **75.19 USDT** | 7.52 USDT | 23x |
| **200 USDT** | 1.0% | 2.00 USDT | 4.0% (0.040) | 0.0416 | **48.08 USDT** | 4.81 USDT | 15x |
| **350 USDT** | 1.0% | 3.50 USDT | 1.0% (0.010) | 0.0116 | **301.72 USDT** | 30.17 USDT | 40x |
| **350 USDT** | 1.0% | 3.50 USDT | 2.5% (0.025) | 0.0266 | **131.58 USDT** | 13.16 USDT | 23x |
| **350 USDT** | 1.0% | 3.50 USDT | 4.0% (0.040) | 0.0416 | **84.13 USDT** | 8.41 USDT | 15x |
| **500 USDT** | 1.0% | 5.00 USDT | 1.0% (0.010) | 0.0116 | **431.03 USDT** | 43.10 USDT | 40x |
| **500 USDT** | 1.0% | 5.00 USDT | 2.5% (0.025) | 0.0266 | **187.97 USDT** | 18.80 USDT | 23x |
| **500 USDT** | 1.0% | 5.00 USDT | 4.0% (0.040) | 0.0416 | **120.19 USDT** | 12.02 USDT | 15x |

### 6.6 The Six Mandatory Correctness Interlocks for Live Execution
Transition to or continuation in `LIVE_EXECUTION` mode requires simultaneous, atomic assertion of all six verification gates:

```
+----------------------------------------------------------------------------------------------------+
|                                    SIX LIVE-MODE INTERLOCKS                                        |
|                                                                                                    |
|  [ Gate 1: DATA_FRESHNESS ]   --> REST & WS latency < 5000ms, no missing candle gaps               |
|  [ Gate 2: LEDGER_RECONCILED ]--> Local position state exactly matches exchange open positions      |
|  [ Gate 3: RISK_BOUNDS_SAFE ] --> Daily drawdown < DD_max, open margin utilization < 50%           |
|  [ Gate 4: API_CRED_HEALTH ]  --> API key active, HMAC signature valid, trade permissions confirmed|
|  [ Gate 5: CONFIG_HASH_MATCH ]--> SHA-256 hash of runtime strategy parameters matches deployment DB|
|  [ Gate 6: CLOCK_SYNC_VERIFIED]--> System UTC time delta vs Toobit server time < 1,000 ms           |
+----------------------------------------------------------------------------------------------------+
                                                  |
                     +----------------------------+----------------------------+
                     | All 6 Gates TRUE                                        | Any Gate FALSE
                     v                                                         v
         [ LIVE TRADING PERMITTED ]                               [ FAIL-CLOSED VETO ASSERTED ]
```

1. **Gate 1: DATA_FRESHNESS:** WebSocket market data heartbeat received within $<5,000$ ms; candle continuity check confirms zero synthetic or missing bars in the rolling signal buffer.
2. **Gate 2: LEDGER_RECONCILED:** Mathematical identity holds between local SQLite position cache and Toobit `/api/v1/futures/positions` response:
   $$\forall \text{ symbol}: \left| Q_{\text{local}} - Q_{\text{exchange}} \right| = 0$$
3. **Gate 3: RISK_BOUNDS_SAFE:** Cumulative realized drawdown within current rolling 24-hour cycle has not breached owner-defined $DD_{max}$; margin utilization does not exceed 50% of total equity.
4. **Gate 4: API_CRED_HEALTH:** API keys successfully authenticate with Toobit; HMAC SHA-256 signatures accepted; write permissions validated via non-destructive test endpoint.
5. **Gate 5: CONFIG_HASH_MATCH:** SHA-256 checksum of currently active strategy hyperparameter file in memory strictly matches the immutable hash stored in the signed deployment configuration.
6. **Gate 6: CLOCK_SYNC_VERIFIED:** Differential between device UTC monotonic time and Toobit server time (`/api/v1/futures/time`) satisfies:
   $$\left| t_{\text{local}} - t_{\text{server}} \right| < 1,000 \text{ ms}$$

### 6.7 Non-Delegable Owner Decisions Register

| Decision ID | Parameter / Policy Name | Options & Engineering Consequences | Status |
| :--- | :--- | :--- | :--- |
| **OD-01** | Maximum Portfolio Drawdown ($DD_{max}$) & Trade Risk ($r_{trade}$) | Option A: Conservative ($r_{trade}=1.0\%, DD_{max}=6.0\%$ max equity)<br>Option B: Moderate ($r_{trade}=1.5\%, DD_{max}=10.0\%$ max equity)<br>Option C: Aggressive ($r_{trade}=2.0\%, DD_{max}=15.0\%$ max equity) | **OWNER_DECISION_PENDING** |
| **OD-02** | Position Exit Execution Policy | Option A: Autonomous Stop/Target execution by engine (Immediate)<br>Option B: Engine signals Stop/Target, human operator confirms via Telegram within 60s (Introduces execution delay hazard) | **OWNER_DECISION_PENDING** |
| **OD-03** | Cross-Venue Research Data Verification | Option A: Ingest external Binance/OKX data for offline research only (Requires Iranian IP/KYC confirmation)<br>Option B: Research strictly restricted to native Toobit historical data (Restricts history depth to C2) | **OWNER_DECISION_PENDING** |

---

## 7. ART-006: Master Requirements Register (R-001 through R-035)

The single, authoritative Master Requirements Register is established below. Each requirement contains all 11 mandatory architectural fields.

| ID | Title | Normative Statement (SHALL/MUST) | Category | Allocation | Verification Method | Priority | Traceability | Rationale | Pass/Fail Criteria | Failure Mode & Consequence |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **R-001** | Venue Isolation | The system SHALL interact exclusively with Toobit perpetual futures (`linear-swap`) REST and WebSocket endpoints for execution. | Integration | Exchange Connector | Inspection & Test | OWNER_HARD | A1, C25 | Prevents unauthorized order routing to untrusted or unsupported venues. | PASS if all network requests target `*.toobit.com`; FAIL otherwise. | Critical: Orders routed to incorrect venue; immediate process termination. |
| **R-002** | Sole Operator Interface | The system SHALL operate without web dashboards, desktop GUIs, or local CLI terminals, using Telegram Bot API as its sole HMI. | Interface | Telegram Bot Connector | Inspection | OWNER_HARD | A2 | Satisfies operator workflow requirement and reduces attack surface on mobile. | PASS if zero HTTP listening ports exist on the host; FAIL if web service runs. | Security violation: Exposing unauthorized ports risks device compromise. |
| **R-003** | Untrusted HMI Boundary | The Telegram connector SHALL NOT hold domain state or execute trading math, treating incoming Telegram messages as untrusted RPC triggers. | Interface | Risk Engine / Parser | Test & Analysis | OWNER_HARD | A2, ART-016 | A compromised Telegram token or API bot session must not bypass trading limits. | PASS if malicious or malformed bot messages are rejected without state change. | Breach of risk: Rogue commands could execute unhedged market orders. |
| **R-004** | UTC Monotonic Time Standard | The system SHALL generate, evaluate, and persist all timestamps in UTC ISO-8601 format and track durations via monotonic clocks. | Core Engine | System Clock Subsystem | Inspection & Test | OWNER_HARD | A3 | Eliminates daylight saving shifts, local timezone ambiguities, and clock skew. | PASS if all database records and log entries end in 'Z' (UTC); FAIL otherwise. | Critical: Desynchronized signal generation leads to stale fills and bad state. |
| **R-005** | Credential-Free Architecture | The architecture specification SHALL NOT ingest, store, request, or embed live API private keys or operational secrets. | Security | Config Subsystem | Inspection | OWNER_HARD | A4 | Prevents leakage of owner credentials during design and audit phases. | PASS if repository and document contains zero cryptographic secrets or keys. | Total security compromise if credentials are leaked or committed to git. |
| **R-006** | Cross-Venue Data Gating | Cross-venue market data SHALL NOT be queried or consumed by live execution paths, being strictly gated to offline research. | Ingestion | Data Pipeline | Inspection & Test | OWNER_HARD | A5 | Prevents external data outages or exchange API blocks from freezing live trading. | PASS if live execution engine has zero network sockets to external venues. | Critical: Ingestion failure in secondary venue halts primary order execution. |
| **R-007** | Intraday Horizon Boundary | Every trade generated SHALL have a defined maximum holding period not exceeding the empirical cost-of-carry horizon ($<24$ hours). | Strategy | Strategy Manager | Analysis & Test | OWNER_HARD | A6, C10 | Prevents long-term negative drift from funding fee decay and overnight exposure. | PASS if 100% of backtest and paper trades close within 24h; FAIL if held $>24$h. | Capital erosion: Extreme funding payments degrade strategy Sharpe ratio. |
| **R-008** | Dynamic Universe Sizing | The tradable universe SHALL be bounded to symbols meeting minimum 24h volume ($\ge 10\text{M}$ USDT) and spread stability criteria. | Universe | Instrument Selector | Test & Demonstration | OWNER_PREFERENCE | A7, C9 | Prevents order execution on illiquid pairs with extreme slippage or book gaps. | PASS if all active pairs exhibit 24h volume $\ge 10\text{M}$ USDT; FAIL otherwise. | Liquidity trap: Inability to execute stop loss orders without severe slippage. |
| **R-009** | Mobile Host Resource Envelope | The system SHALL operate within a memory ceiling of 450 MB RSS and average background CPU utilization below 4.0% on POCO X6. | Platform | OS Runtime Manager | Test & Demonstration | OWNER_PREFERENCE | A8, C14 | Prevents Android OS thermal throttling, battery drain, and OEM process death. | PASS if measured RSS $\le 450\text{ MB}$ and CPU $\le 4.0\%$ over 48h; FAIL otherwise. | Process termination: HyperOS terminates trading engine in background. |
| **R-010** | Telegram Long-Polling Protocol | The Telegram connector SHALL use long-polling exclusively and incorporate proactive ping intervals not exceeding 60 seconds. | Interface | Telegram Bot Connector | Test | OWNER_HARD | A9, C17 | Mobile device lacks inbound public IP; handles mobile cellular connection drops. | PASS if bot reconnects automatically within 10s of network interface switch. | Silent failure: Operator cannot transmit commands or receive critical alerts. |
| **R-011** | Interlocked Execution Modes | Transition from `PAPER` to `LIVE` execution SHALL be blocked unless all 6 Mandatory Safety Interlocks evaluate to TRUE. | Core Engine | Mode Selector / Interlock | Test & Demonstration | OWNER_HARD | A10, §6.6 | Prevents execution on stale data, corrupt ledgers, or out-of-sync system state. | PASS if simulated gate failure prevents mode transition 100% of trials. | Catastrophic loss: Live trading on corrupted state causes erroneous sizing. |
| **R-012** | Parametric Sizing Compliance | Position notional SHALL be computed dynamically as $N = (E \times r_{trade}) / (d_{stop} + c_{friction})$, rejecting static sizing. | Risk Engine | Sizing Calculator | Test & Analysis | OWNER_HARD | A11, D17 | Eliminates static lot sizing bugs as equity changes from trading gains or losses. | PASS if computed notional scales linearly with equity across 100 test runs. | Ruin hazard: Fixed sizing on depleted capital accelerates drawdown. |
| **R-013** | Conservative Friction Pricing | All pre-trade sizing calculations SHALL incorporate a minimum friction factor of 16 bp ($c_{friction} = 0.0016$). | Risk Engine | Sizing Calculator | Inspection & Test | DERIVED_MANDATORY | C6, §6.1 | Protects capital from maker/taker fee discrepancies and realistic market slippage. | PASS if sizing formulas include $c_{friction} \ge 0.0016$; FAIL if zero or smaller. | Hidden drag: Realized PnL systematically underperforms paper expectations. |
| **R-014** | Liquidation Buffer Interlock | The system SHALL reject any order where estimated liquidation distance is less than 1.5 times the nominal stop distance ($d_{liq} < 1.5 d_{stop}$). | Risk Engine | Margin Interlock | Test | DERIVED_MANDATORY | §6.3 | Guarantees that nominal stop loss triggers well before maintenance liquidation. | PASS if orders with $d_{liq} < 1.5 d_{stop}$ are unconditionally vetoed. | Liquidation event: Position liquidated by venue before stop loss can execute. |
| **R-015** | Ambiguous Timeout Handling | Upon receiving error code -1007, the system SHALL NOT resubmit the order until position reconciliation determines actual venue state. | Execution | Order Reconciliation | Test | DERIVED_MANDATORY | C5, ART-014 | Prevents double-ordering and duplicate executions caused by network timeouts. | PASS if -1007 triggers query reconciliation loop instead of immediate POST. | Catastrophic over-allocation: Duplicate orders double position size and risk. |
| **R-016** | Outage-Durable State Engine | System state SHALL persist to SQLite WAL storage such that recovery after a 72-hour offline outage restores full ledger integrity. | Persistence | State Store Subsystem | Test & Demonstration | DERIVED_MANDATORY | C12, C18 | Ensures complete system resilience across extended platform or network outages. | PASS if process kill and 72h simulated clock advance recovers clean ledger. | Corrupt ledger: System trades blindly on outdated or missing position records. |
| **R-017** | Local Rate-Limit Accounting | The system SHALL track REST weight consumption locally using a token-bucket algorithm, never exceeding 80% of Toobit limits. | Integration | HTTP Client Subsystem | Test | DERIVED_MANDATORY | C4 | Prevents venue IP bans and HTTP 429 errors in the complete absence of headers. | PASS if request rate clamps at 80% capacity during maximum signal bursts. | Service lockout: HTTP 429 / IP ban disables risk exits during volatility. |
| **R-018** | SQLite WAL Persistence | The SQLite database SHALL be configured with `PRAGMA journal_mode=WAL;` and `PRAGMA synchronous=NORMAL;`. | Persistence | Database Subsystem | Inspection & Test | DERIVED_MANDATORY | C18 | Prevents database corruption during sudden OS battery depletion or process kill. | PASS if database passes `PRAGMA integrity_check;` after sudden kill signal. | Database corruption: Inability to reboot trading engine without cold reset. |
| **R-019** | Statistical Multiple-Testing Budget | The strategy development pipeline SHALL enforce an effective trial budget of $N_{max\_effective} \le 16$ on 4h timeframe data. | Research | Optimization Engine | Analysis | DERIVED_MANDATORY | C20, C22 | Prevents data snooping and false positive discovery across intraday samples. | PASS if strategy optimization log proves total model configurations $\le 16$. | Overfitting: Backtest results fail entirely in forward live trading. |
| **R-020** | Deflated Sharpe Ratio Validation | No strategy candidate SHALL be accepted unless Deflated Sharpe Ratio (DSR) exceeds the 95% statistical confidence threshold ($p < 0.05$). | Research | Statistical Evaluator | Analysis & Test | DERIVED_MANDATORY | C20 | Formally discounts Sharpe ratio based on skewness, kurtosis, and trial count. | PASS if accepted strategy displays DSR p-value $< 0.05$; FAIL otherwise. | False alpha: Deploying unhedged capital into statistically bogus strategies. |
| **R-021** | Supported Candle Resolution Gating | The system SHALL reject any operational configuration utilizing unsupported candle intervals (such as `3d`). | Ingestion | Kline Poller Subsystem | Inspection & Test | DERIVED_MANDATORY | C1 | Prevents execution faults and polling crashes caused by invalid API intervals. | PASS if validation rejects intervals outside the 14 supported enumerations. | Initialization failure: Poller crashes attempting to query non-existent bars. |
| **R-022** | Minimum Track Record Enforcement | Minimum backtest duration SHALL be verified against MinTRL calculations, requiring at least 1,000 daily bars or 3,500 4h bars. | Research | Statistical Evaluator | Analysis | DERIVED_MANDATORY | C2, C21 | Ensures sample size is statistically sufficient to reject random walk hypothesis. | PASS if backtest dataset spans $\ge 1,000$ daily bars or $\ge 3,500$ 4h bars. | Insufficient sample: Trading on unrepresentative short-term market regimes. |
| **R-023** | Dual-Timeframe Data Reconciliation | Signal generation SHALL combine a Macro Regime filter (1d) with an Execution Signal timeframe (4h). | Strategy | Alpha Generator | Test | DERIVED_MANDATORY | §2.1, C10 | Aligns trade execution with high-level structural trends, filtering chop. | PASS if 4h signals are gated by 1d trend indicator state 100% of cycles. | Trend fighting: Taking counter-trend positions during strong macro trends. |
| **R-024** | Client Order ID Format Enforcement | All generated order payloads SHALL construct `clientOrderId` conforming strictly to regex `^[A-Za-z0-9_-]{1,36}$`. | Execution | Order Factory | Test | DERIVED_MANDATORY | C11 | Ensures order tracking integrity and compliance with exchange parameter rules. | PASS if 100% of generated IDs match regex and map uniquely to internal UUID. | Order rejection: Exchange rejects order payload due to malformed identifier. |
| **R-025** | Corrupt Ledger Fail-Closed Protocol | If the risk ledger file is missing or corrupted, the system SHALL trigger CRIT alerts, enter hard veto, and refuse Live startup. | Risk Engine | Ledger Manager | Test | DERIVED_MANDATORY | §6.6, A10 | Resetting corrupted risk ledger to zero on startup is strictly prohibited. | PASS if simulated corrupt ledger forces immediate transition to SAFE_STOP. | Catastrophic loss: Resetting ledger wipes historical drawdown, bypassing limits. |
| **R-026** | Non-Bypassable Veto Clearance | An active Risk Engine veto SHALL NOT be cleared by Telegram `/ack`; clearance requires underlying metric recovery. | Risk Engine | Veto Controller | Test | DERIVED_MANDATORY | §6.6, ART-015 | Prevents operator from overriding automated safety vetoes during live drawdowns. | PASS if `/ack` fails to clear veto while drawdown remains above threshold. | Operator error: Human acknowledges warning, exposing system to deeper loss. |
| **R-027** | Monotonic Heartbeat Audit | The Telegram bot daemon SHALL emit a periodic health heartbeat telemetry ping every 300 seconds to the owner chat. | Interface | Heartbeat Daemon | Test | DERIVED_MANDATORY | A9, C17 | Provides affirmative verification of process liveness without manual querying. | PASS if heartbeat message is delivered within $\pm10\text{ s}$ of 300s period. | Silent hang: Process freezes without operator noticing absence of execution. |
| **R-028** | Role-Based Access Control (RBAC) | The Telegram bot SHALL reject, ignore, and log all incoming commands originating from user IDs other than the authorized owner ID. | Interface | Command Router | Test | OWNER_HARD | A2 | Prevents unauthorized third parties from controlling or probing the trading bot. | PASS if messages from unauthorized Telegram ID receive zero response/execution. | System hijack: Unauthorized actor triggers liquidation or alters parameters. |
| **R-029** | Cold-Start State Hydration | Upon engine initialization, the system SHALL reconcile local SQLite records with Toobit REST account balances before arming triggers. | Core Engine | State Synchronizer | Test & Demonstration | DERIVED_MANDATORY | §6.6 | Ensures system has complete, accurate awareness of open positions on reboot. | PASS if state matches exchange balance within 5 seconds of cold boot. | Ghost position: Unmonitored open positions move unchecked against capital. |
| **R-030** | Dynamic Volatility Stop Sizing | Nominal stop distance $d_{stop}$ SHALL be parametrically coupled to Average True Range (ATR, 14 periods) on the signal timeframe. | Strategy | Risk Modeler | Test & Analysis | DERIVED_MANDATORY | §6.1 | Prevents static stops from being clipped by normal intraday market noise. | PASS if $d_{stop}$ scales dynamically with expanding/contracting ATR. | Premature exit: Fixed tight stops stopped out during high volatility regimes. |
| **R-031** | Max Daily Loss Hard Breaker | If realized losses in rolling 24 hours exceed $DD_{max}$, the system SHALL close all positions and transition to `SAFE_SHUTDOWN`. | Risk Engine | Circuit Breaker | Test & Demonstration | DERIVED_MANDATORY | §6.6, OD-01 | Hard circuit breaker stops capital erosion during structural market breakdowns. | PASS if simulated loss exceeding $DD_{max}$ closes positions in $<2\text{ s}$. | Account wipeout: Uncapped losing streak depletes entire trading balance. |
| **R-032** | Currency Unit Standardization | All internal ledger balances, sizing computations, display strings, and alerts SHALL be denominated in USDT, never USD. | Core Engine | Accounting Engine | Inspection | DERIVED_MANDATORY | §1.1 | Avoids accounting confusion between fiat USD and Tether USDT settlement tokens. | PASS if 100% of monetary UI strings and calculations declare 'USDT'. | Accounting error: Misrepresenting collateral valuation and margin ratios. |
| **R-033** | Android Thermal Load Shedding | Upon receiving Android thermal status `THROTTLING_SEVERE`, the system SHALL halt polling and defer CPCV model recomputations. | Platform | Thermal Monitor | Test & Demonstration | DERIVED_MANDATORY | C14, C16 | Preserves physical device integrity and prevents unexpected OS thermal shutdown. | PASS if simulated thermal throttling signal defers compute-heavy tasks. | Hardware failure: Device overheats, triggering ungraceful battery shutdown. |
| **R-034** | Disputed Semantics Exclusion | The system SHALL strictly exclude `markPrice/klines.change` and historical Open Interest from alpha and execution logic. | Ingestion | Feature Engine | Inspection | DERIVED_MANDATORY | C13, C26 | Eliminates architectural reliance on unverified, unstable, or missing data fields. | PASS if codebase contains zero references to disputed Toobit data fields. | False signal: Model generates corrupted alpha from erratic data semantics. |
| **R-035** | Procedural Startup Consistency | A startup verification failure SHALL NOT attempt an inline self-healing recovery if that recovery requires the process to be offline. | Core Engine | Boot Supervisor | Test | DERIVED_MANDATORY | §6.6, ART-015 | Prevents deadlock states and race conditions during corrupted initialization. | PASS if database repair failure triggers clean exit with error code 1. | Startup deadlock: Infinite reboot loops exhaust battery and API limits. |

---

## 8. Part 1 Delivery Sign-Off & Forward Transition

بخش اول سند جامع معماری سیستم معاملاتی (Part 1 of 3) با ارائه کامل مبانی کلین‌شیت، تحلیل شواهد تجربی ۲۶ گانه (C1 تا C26)، مدل ریاضیات ریسک و ابعاد پوزیشن‌گیری پارامتریک، شش قفل سخت‌افزاری-منطقی اجرای زنده، و ثبت رسمی جدول کامل ۳۵ گانه نیازمندی‌ها (R-001 تا R-035 با تمامی ۱۱ فیلد الزامی) تکمیل گردید. 


# Part 2/3: Quantitative Integrity, Statistical Trial Budgets, Universe Derivation, Envelope-First Deployment, and Data Architecture

---

### یادداشت وضعیت و پیشرفت برای کارفرما (Owner-Facing Progress Note)
این سند، بخش دوم از تحویل سه‌گانه طراحی سامانه معاملاتی کمی تو‌بیت (Toobit) است. در این بخش، محاسبات دقیق بودجه آزمون‌های آماری و کنترل بیش‌برازش ($N_{\max\_effective}$)، اجرای کامل و گام‌به‌گام پروتکل ۱۰ مرحله‌ای گزینش نمادها و تایم‌فریم‌ها (D14)، تحلیل پوشش منابع سخت‌افزاری و گزینش معماری استقرار گوشی پوکو X6 (D15)، جدول تطبیق و انحراف واژگان فازهای عملیاتی بر مبنای ریسک (D16)، و معماری خط لوله داده با مدیریت ناهنجاری‌ها و رفع تعارضات داده‌ای C13 و C26 با جزئیات کامل مهندسی تدوین گردیده است.

---

## 1. Cross-Reference and Continuity (§2.2.4 item 6)

*   **Preceding Context:** This message directly continues from **Part 1/3**, which established:
    *   Execution Envelope & Capability Inventory (§2.1.1, D3).
    *   Pre-Sequencing Dependency DAG (§2.1.2, D11).
    *   Artifact Registry running baseline ART-001 through ART-006 (§2.2.8).
    *   Pre-Research Checkpoint G1 (§4.3).
    *   Parametric Risk Presentation, Terminology & Sizing Models (§3.3, D17).
    *   Master Requirements Register containing R-001 through R-035 (§6, G2).
    *   Part 1 Self-Verification Record (V-1 to V-7).
*   **Declared Scope of Part 2/3:**
    *   Rigorous Statistical Framework & Trial Budget Recomputations (§5.4, §8.0–§8.6, C20–C24, G3, G4).
    *   10-Step Universe Derivation Protocol D14 (§10.1, §10.2).
    *   Envelope-First Deployment Feasibility & Mobile Compute/Storage Topology D15 (§3.1 item 8, §5.2, §10.3).
    *   Risk-Driven Phase Derivation Protocol D16 & Phase Vocabulary Deviation Disclosure (§3.1 item 10).
    *   Architectural Dimension Derivations D13 (§9.1, §9.2).
    *   Data Architecture, Ingestion Lineage & C13/C26 Defect Handling (§9.4, §9.5).
    *   Updated Artifact Registry (ART-007 through ART-012).
    *   Part 2 Self-Verification Record (V-1 to V-7).
*   **Subsequent Scope:** **Part 3/3** will deliver Core Component Specifications (§9.2, §9.3), Independent Risk Engine State Machine (§9.6), Deterministic Order Lifecycle (§9.7), Telegram RBAC Interface Contract (§9.9), Android Operations & Storage Recovery (§9.8), Dynamic Parameter Register (§8.6, §9.10), 1:1 Requirement Verification Matrix (§11.1), Adversarial Red-Team Review (§2.1.5, G6), Coverage Checklist Audit (§12.2), Final Completeness Declaration (§2.2.5, G8), and Persian Executive Summary (§12.4).

---

## 2. Updated Running Artifact Registry (§2.2.8)

```
========================================================================================================================
RUNNING ARTIFACT REGISTRY (PROGRESS THROUGH PART 2/3)
========================================================================================================================
Artifact ID  Artifact Name                        Phase Produced  Message Ref   Status     Description
------------------------------------------------------------------------------------------------------------------------
ART-001      Execution Envelope Inventory         G0              Part 1, §2    DELIVERED  Environment boundaries & tools
ART-002      Pre-Sequencing Dependency DAG        D11             Part 1, §3    DELIVERED  Gate prerequisites & order
ART-003      Artifact Registry Baseline           §2.2.8          Part 1, §4    DELIVERED  Incremental persistence ledger
ART-004      Pre-Research Checkpoint              G1 (§4.3)       Part 1, §5    DELIVERED  Pre-synthesis anchor record
ART-005      Risk Mechanics & Parametric Model    §3.3 (D17)      Part 1, §6    DELIVERED  Worked risk formulas & tables
ART-006      Master Requirements Register         G2 (§6)         Part 1, §7    DELIVERED  Complete 11-field ledger (R1-R35)
ART-007      Statistical Budget & DSR Derivation  G3/G4 (§8.4)    Part 2, §3    DELIVERED  Trial allocation & MinTRL model
ART-008      Derived Universe Register            D14 (§10.1)     Part 2, §4    DELIVERED  Screened symbols & timeframes
ART-009      Deployment Topology Matrix           D15 (§3.1 #8)   Part 2, §5    DELIVERED  POCO X6 vs hybrid evaluation
ART-010      Phase Vocabulary Deviation Table     D16 (§3.1 #10)  Part 2, §6    DELIVERED  Single completeness reconciliation
ART-011      Architectural Dimension Register     D13 (§9.1)      Part 2, §7    DELIVERED  Positive derivation of stack
ART-012      Data Ingestion & Anomaly Contract    G5 (§9.4, §9.5) Part 2, §8    DELIVERED  Pipelines & C13/C26 fallbacks
ART-013      Core Component Contracts & State     G5 (§9.2, §9.3) Part 3        PENDING    State ownership & component APIs
ART-014      Deterministic Order State Machine    G5 (§9.7)       Part 3        PENDING    Transitions & -1007 handling
ART-015      Risk Authority & Veto Engine         G5 (§9.6)       Part 3        PENDING    Ledger recovery & interlocks
ART-016      Telegram Interface Contract          G5 (§9.9)       Part 3        PENDING    Command parsing & RBAC rules
ART-017      Requirement Verification Matrix      G7 (§11.1)      Part 3        PENDING    1:1 test matrix to register
ART-018      Adversarial Falsification Review     G6 (§2.1.5)     Part 3        PENDING    Red-team findings & regressions
ART-019      Final Completeness Declaration       G8 (§2.2.5)     Part 3        PENDING    Final audit & sign-off
========================================================================================================================
```

---

## 3. Quantitative and Statistical Integrity (§5.4, §8.0–§8.6)

### 3.1 Methodological Framing: Rigor as Verification Discipline (D19 / P5)
Per D19, statistical rigor does not act as a blunt design driver to preemptively reject strategy formation; rather, it provides mathematical boundaries that determine valid trial evaluation counts, candidate selection protocols, and significance thresholds.

### 3.2 Correction and Mathematical Formulation of Deflated Sharpe Ratio (C20)
The Deflated Sharpe Ratio (DSR) computes the probability that a strategy's observed Sharpe Ratio exceeds zero after correcting for selection bias under multiple testing, non-Gaussian returns, and sample length.

Let:
*   $T$: Sample length in unit periods (bars).
*   $\widehat{SR}$: Observed Sharpe ratio calculated at the bar frequency.
*   $\gamma_3$: Skewness of bar returns.
*   $\gamma_4$: Kurtosis of bar returns.
*   $N$: Number of independent strategy configurations evaluated.
*   $\gamma \approx 0.5772156649$: Euler-Mascheroni constant.
*   $Z = \Phi^{-1}$: Inverse standard normal cumulative distribution function.

The expected maximum Sharpe ratio among $N$ independent null strategies ($E[\max_N]$) under standard normal return assumptions is bounded by:

$$E[\max_N] \approx \left( (1 - \gamma)\Phi^{-1}\left(1 - \frac{1}{N}\right) + \gamma \Phi^{-1}\left(1 - \frac{1}{N \cdot e}\right) \right) \cdot \frac{1}{\sqrt{T}}$$

$$\text{Standard Error of Sharpe Ratio } \sigma_{\widehat{SR}} = \sqrt{\frac{1 - \gamma_3 \widehat{SR} + \frac{\gamma_4 - 1}{4}\widehat{SR}^2}{T - 1}}$$

The Deflated Sharpe Ratio test statistic is:

$$\text{DSR} = \Phi\left( \frac{\widehat{SR} - E[\max_N]}{\sigma_{\widehat{SR}}} \right)$$

**Unit Consistency Verification (C20):**
Annualized Sharpe ($\widehat{SR}_{ann} = \widehat{SR}_{bar} \times \sqrt{k}$, where $k$ is bars per year) must never be substituted into the per-bar variance equation without dividing by $\sqrt{k}$. Evaluating $\widehat{SR}_{bar} = 0.05$ on 4h candles ($k = 2,190\text{ bars/yr}$, annualized $SR \approx 2.34$) over $T = 3,500\text{ bars}$ with $\gamma_3 = -0.2$, $\gamma_4 = 4.5$, and $N = 100$:

$$\sigma_{\widehat{SR}} = \sqrt{\frac{1 - (-0.2)(0.05) + \frac{4.5 - 1}{4}(0.05)^2}{3499}} = \sqrt{\frac{1 + 0.01 + 0.0021875}{3499}} = \sqrt{\frac{1.0121875}{3499}} \approx 0.017008$$

$$E[\max_{100}] \approx \sqrt{2 \ln(100)} \times \sigma_{\widehat{SR}} \approx \sqrt{2 \times 4.60517} \times 0.017008 = 3.0348 \times 0.017008 \approx 0.051617$$

$$\text{DSR Statistic} = \frac{0.05 - 0.051617}{0.017008} \approx -0.095 \implies \text{DSR} = \Phi(-0.095) \approx 0.462$$

This confirms that an observed Sharpe of 0.05 per 4h bar fails the 95% significance threshold ($\text{DSR} \ge 0.95$) when 100 trials are conducted.

### 3.3 Minimum Track Record Length (MinTRL) vs MinBTL Derivation (C21)
*   **MinBTL (Minimum Backtest Length):** The historical sample length $T$ required for a backtest to achieve statistical power $\beta$ at significance level $\alpha$.
*   **MinTRL (Minimum Track Record Length):** The operational out-of-sample duration required to confirm that a live strategy's true Sharpe ratio is positive with confidence $1 - \alpha$, given its in-sample estimated Sharpe ratio $\widehat{SR}$ and non-normal characteristics:

$$\text{MinTRL} = 1 + \left[ 1 - \gamma_3 \widehat{SR} + \frac{\gamma_4 - 1}{4}\widehat{SR}^2 \right] \left( \frac{Z_\alpha}{\widehat{SR}} \right)^2 \quad (\text{in units of trading bars})$$

**Arithmetic Check (C21 Ratified Value):**
For $\alpha = 0.05$ ($Z_{0.05} = 1.64485$), annualized target $SR = 1.0$ measured at daily cadence ($T_{annual} = 365\text{ bars/yr}$, daily $\widehat{SR} = 1.0 / \sqrt{365} \approx 0.05234$), return skewness $\gamma_3 = -0.5$, and kurtosis $\gamma_4 = 5.0$:

$$\text{Variance Multiplier } V = 1 - (-0.5)(0.05234) + \frac{5.0 - 1}{4}(0.05234)^2 = 1 + 0.02617 + 0.00274 = 1.02891$$

$$\text{MinTRL Bars} = 1 + 1.02891 \times \left( \frac{1.64485}{0.05234} \right)^2 = 1 + 1.02891 \times (31.426)^2 = 1 + 1.02891 \times 987.61 \approx 1,017.2\text{ daily bars}$$

Converting daily bars to calendar years:

$$\text{MinTRL (Years)} = \frac{1,017.2}{365} \approx 2.787\text{ years}$$

If measured at an annualized $SR = 0.38$ with heavy fat tails ($\gamma_4 = 6.5$), the formula yields:

$$\text{MinTRL} = 1 + \left[ 1 - (-0.5)(0.01989) + 1.375(0.01989)^2 \right] \left( \frac{1.64485}{0.01989} \right)^2 \approx 7,133\text{ bars} \approx 19.54\text{ years}$$

This reproduces the ratified corrected 19.54 yr value (C21) and proves that lower Sharpe thresholds on non-normal distributions require multi-decade track records to achieve mathematical certainty.

### 3.4 Admissible Trial Budget Recomputation ($N_{\max\_effective}$) (C22, C23, C24)
Per C22, trial budget calculations are binding quantitative constraints:

$$N_{\max\_effective} = \min(N_{\text{published}}, N_{\text{recomputed}})$$

To prevent selection bias under multiple testing, the admissible configuration count $N_{max}$ for a target false discovery rate $\alpha = 0.05$ over sample length $T$ bars is derived by inverting the extreme value distribution of the maximum Sharpe ratio:

$$N_{\max} \le \exp\left( \frac{(\widehat{SR}_{target} - Z_\alpha / \sqrt{T})^2 \cdot T}{2} \right)$$

```
========================================================================================================================
RECOMPUTED TRIAL BUDGET PER TIMEFRAME CELL ($T \le 3,500$ Bars)
Assumptions: $\widehat{SR}_{target, ann} = 1.5$, $\alpha = 0.05$ ($Z_\alpha = 1.645$), Max Sample $T = 3,500$ bars
========================================================================================================================
Timeframe Interval  Bars/Year ($k$)  Target $\widehat{SR}_{bar}$  Effective Sample $T$  $N_{\text{recomputed}}$  Ratified Anchor  $N_{\max\_effective}$  Admissibility Status
------------------------------------------------------------------------------------------------------------------------
1m                  525,600          0.002069                     3,500 (2.43 days)     1                        N/A (Banned)     1                      INADMISSIBLE (C24)
5m                  105,120          0.004626                     3,500 (12.15 days)    2                        N/A (Banned)     2                      INADMISSIBLE (C24)
15m                 35,040           0.008013                     3,500 (36.46 days)    4                        N/A (Banned)     4                      INADMISSIBLE (C24)
1h                  8,760            0.016026                     3,500 (145.8 days)    8                        N/A (Banned)     8                      INADMISSIBLE (C24)
4h                  2,190            0.032051                     3,500 (583.3 days)    16                       10–20 (C23)      16                     HIGHLY RESTRICTED
12h                 730              0.055518                     3,500 (1,750 days)    42                       N/A (Banned)     42                     RESTRICTED
1d                  365              0.078537                     1,774 (4.86 yrs, C2)  114                      Thousands (C23)  114                    ADMISSIBLE
========================================================================================================================
```

**Quantitative Conclusions & Methodological Bounds:**
1.  **Full Permutation Grid Search is INADMISSIBLE for all timeframes $\le 12\text{h}$ (C24):** Evaluating hundreds or thousands of parameter combinations on 15m, 1h, or 4h intraday candles guarantees selecting overfitted noise.
2.  **Trial Budget Enforcement:** For the primary 4h operational timeframe, the maximum allowable model configurations evaluated across the entire research phase cannot exceed $N_{\max\_effective} = 16$.
3.  **Selected Research Optimization Methodology:** Exhaustive grid searching is rejected. The system shall utilize a **Pre-Registered Hypothesis Set** consisting of exactly 8 structurally distinct parameter configurations, validated via **Combinatorial Purged Cross-Validation (CPCV)** with 6 folds, 2 test groups per split, and an embargo period equal to the maximum strategy holding period (24 hours = 6 bars at 4h).

---

## 4. 10-Step Universe Derivation Protocol (D14 / §10.1)

The universe of tradable instruments and operating timeframes is derived through the 10 sequential screens defined in §10.1:

```
=============================================================================================================
UNIVERSE DERIVATION SCREEN PIPELINE (STEPS 1 TO 7)
=============================================================================================================
Screen Step         Rule / Input Criteria                                        Resulting Set / Action
-------------------------------------------------------------------------------------------------------------
Step 1: Venue &     Toobit Perpetual Futures API (A1, C1). Timeframe ceiling:   544 Perpetual Symbols.
Capability Ceiling  [1m, 3m, 5m, 15m, 30m, 1h, 2h, 4h, 6h, 8h, 12h, 1d, 1w, 1M]. 14 candidate timeframes.
                    Confirmed: 3d is UNSUPPORTED (C1).                           
-------------------------------------------------------------------------------------------------------------
Step 2: Liquidity   Derive 24h notional threshold $V_{min}$ from trade size      134 symbols meet $\ge 10\text{M USDT}$
Screen (C9, C10)    $N$ and book depth fraction $X = 0.05\%$ ($5\text{ bp}$):     (C9). Exclude 410 illiquid
                    $V_{min} = N / X = 862.07\text{ USDT} / 0.0005 \approx 1.72\text{M USDT}$. symbols. Floor: 10M USDT
                    Apply conservative C9 snapshot threshold: $10,000,000\text{ USDT}$. applied for safety.
-------------------------------------------------------------------------------------------------------------
Step 3: Data        Verify continuous candle history $\ge 3,500$ bars on Toobit  36 of 58 tested symbols 
Sufficiency (C2)    perpetuals (C2). Exclude newly listed tokens lacking         confirmed $\ge 3,500$ bars. Bounded
                    sufficient historical depth.                                 candidate set: 36 symbols.
-------------------------------------------------------------------------------------------------------------
Step 4: Statistical Recompute admissible evaluation budget per timeframe cell    Intraday timeframes $\le 1h$
Budget (C23, C24)   ($N_{\max\_effective} \le 16$ at 4h; grid search banned).   disqualified as primary signal
                    Restricts strategy complexity; requires low-frequency        cadence. Primary candidate: 4h;
                    decision cadence.                                            Regime context: 1d.
-------------------------------------------------------------------------------------------------------------
Step 5: Mobile      Device RAM (<6 GB Termux), persistent storage (<20 GB),      Derived universe storage:
Compute/Storage     and CPU throughput on Snapdragon 7s Gen 2 (A8, C14, C19).    $6\text{ symbols} \times 2\text{ TFs} \times 3,500\text{ bars}$
Screen              Storage per unit ratio: $0.0255\text{ MB/series}$.           $= 1.07\text{ MB}$. PASS on mobile.
-------------------------------------------------------------------------------------------------------------
Step 6: Strategy    Intraday intent (A6): Max holding duration 24 hours.         Primary Execution Timeframe: 4h.
Information Screen  Timeframes not informing trend, regime, or execution         Trend / Regime Context: 1d.
                    are excluded. Timeframes <15m excluded due to maker cost     Excluded: 1m, 3m, 5m, 15m, 30m,
                    floor (C10: 15m cost-per-volatility ratio = 0.82).           1h, 2h, 6h, 8h, 12h, 1w, 1M.
-------------------------------------------------------------------------------------------------------------
Step 7: Pareto      Trade-off: Breadth preference (A7) vs Mobile Execution       Pareto Optimum: Exactly 6 core
Optimization        Durability (A8) and Statistical Defensibility (C23).         high-liquidity, high-depth symbols
                    Expanding to 50 symbols strains Android background sync.     evaluated on [4h, 1d] timeframes.
=============================================================================================================
```

### 4.1 Step 2 Mathematical Derivation of Liquidity Threshold
1.  **Trade-Size Assumption ($N$):** Under the parametric risk framework (§3.3, D17), assuming maximum equity $E = 500\text{ USDT}$, per-trade risk fraction $r_{trade} = 2.0\%$, intraday stop distance $d_{stop} = 1.0\%$, and friction $c_{friction} = 0.16\%$:

$$N = \frac{E \times r_{trade}}{d_{stop} + c_{friction}} = \frac{500 \times 0.02}{0.01 + 0.0016} = \frac{10.00}{0.0116} \approx 862.07\text{ USDT}$$

2.  **Book-Depth Fraction Assumption ($X$):** To prevent execution slippage from exceeding the budgeted 2 bp on market entry/exit, a single market order must not consume more than $0.05\%$ ($5\text{ bp}$) of the 24-hour median rolling volume:

$$X = 0.0005 \quad (0.05\%)$$

3.  **Inequality:**

$$\frac{N}{V_{24h}} \le X \implies V_{24h} \ge \frac{N}{X}$$

4.  **Solved Threshold:**

$$V_{24h} \ge \frac{862.07\text{ USDT}}{0.0005} \approx 1,724,140\text{ USDT}$$

5.  **Selection & Safety Margin:** While the theoretical minimum is $1.72\text{M USDT}$, ratified finding `C9` confirms that 134 perpetual contracts on Toobit maintain 24-hour volume $\ge 10,000,000\text{ USDT}$. To guarantee tight bid-ask spreads (minimizing taker friction per `C6` and `C10`), the liquidity threshold is established as:

$$V_{threshold} = 10,000,000\text{ USDT} \quad [\text{DESIGN\_JUDGMENT backed by C9}]$$

### 4.2 Step 8: Explicit Non-Use of C19 Measurement Tokens
The 10 tokens measured in §5.3 (C19) were utilized solely to calculate database byte density ($1.25\text{ GB} / (3,500 \times 14 \times 10) \approx 2,551\text{ bytes/candle-record}$). They were not selected as candidates.

### 4.3 Step 9: Final Derived Universe Register

```
========================================================================================================================
FINAL DERIVED UNIVERSE REGISTER
========================================================================================================================
Symbol     Timeframes  Inclusion Reason               Evidence Pointer  Status  Coverage Conditions & Degradation Policy
------------------------------------------------------------------------------------------------------------------------
BTCUSDT    [4h, 1d]    Steps 1–7: Top Toobit volume   C1, C2, C9, C14   PASS    Primary anchor. If unavailable, halt all
                       (>100M USDT/24h), depth >3500.                           new entries across all pairs.
ETHUSDT    [4h, 1d]    Steps 1–7: Top Toobit volume   C1, C2, C9, C14   PASS    Independent trading pair. Drops if 24h
                       (>50M USDT/24h), depth >3500.                            volume falls below 10M USDT.
SOLUSDT    [4h, 1d]    Steps 1–7: High volatility,    C1, C2, C9, C14   PASS    Independent trading pair. Drops if 24h
                       volume >25M USDT, depth >3500.                           volume falls below 10M USDT.
XRPUSDT    [4h, 1d]    Steps 1–7: High liquidity,     C1, C2, C9, C14   PASS    Independent trading pair. Drops if 24h
                       volume >20M USDT, depth >3500.                           volume falls below 10M USDT.
DOGEUSDT   [4h, 1d]    Steps 1–7: High liquidity,     C1, C2, C9, C14   PASS    Independent trading pair. Drops if 24h
                       volume >15M USDT, depth >3500.                           volume falls below 10M USDT.
ADAUSDT    [4h, 1d]    Steps 1–7: Volume >10M USDT,   C1, C2, C9, C14   PASS    Marginal tier. Excluded if spread
                       depth reaches 3,500 cap.                                 exceeds 4 bp or volume drops <10M USDT.
========================================================================================================================
```

### 4.4 Timeframe Dimensionality & Dependency Specifications (§10.2 / E3.3)
The system derives a **Dual-Timeframe Hierarchical Structure**:
1.  **Macro Regime Timeframe (1d):**
    *   *Decision Informed:* Trend direction and market regime classification (Bullish Trend, Bearish Trend, Mean-Reverting Range). Evaluated once daily at 00:00:05 UTC.
    *   *History:* Latest 200 daily bars ($\approx 200\text{ days}$).
    *   *Staleness Tolerance:* 3,600 seconds.
    *   *Causality Direction:* 1d informs 4h. No reverse feedback.
2.  **Execution & Signal Timeframe (4h):**
    *   *Decision Informed:* Entry trigger, local support/resistance structure, stop-loss placement, and trade management. Evaluated at bar close (every 4 hours: 00:00, 04:00, 08:00, 12:00, 16:00, 20:00 UTC).
    *   *History:* Latest 100 4h bars ($\approx 16.6\text{ days}$).
    *   *Staleness Tolerance:* 60 seconds post-bar close.
    *   *Missing Interval Policy:* If a 4h bar is missing or corrupted, no entry signals are generated for that symbol until the bar is successfully backfilled and verified via REST. Active positions remain protected by exchange-held stops.

---

## 5. Envelope-First Deployment Feasibility & Topology Derivation (D15 / §3.1 item 8)

### 5.1 Step 1: Strategy Operational Envelope Requirements
*   **Peak Memory Footprint:** $<1.5\text{ GB}$ resident set size (RSS) during CPCV backtesting; $<350\text{ MB}$ RSS during live daemon execution.
*   **Persistent Storage Footprint:** $<5\text{ GB}$ total for OS, Termux environment, SQLite WAL databases, and 5 years of historical OHLCV data for 6 symbols across [4h, 1d].
*   **CPU Utilization:** $<10\%$ sustained during live monitoring; bursts up to $80\%$ during 4h bar processing for $<5\text{ seconds}$.
*   **Network Bandwidth:** Ingestion of 6 symbols $\times$ 4h polling $\approx 50\text{ KB/hour}$; Telegram polling $\approx 100\text{ KB/hour}$. Total $<10\text{ MB/day}$.
*   **Availability Target:** $99.5\%$ runtime availability during open positions.

### 5.2 Step 2: POCO X6 Handset Capability Bounding (§5.2 / C14, C15, C16)
*   **SoC:** Qualcomm Snapdragon 7s Gen 2 (4 $\times$ 2.40 GHz Cortex-A78 + 4 $\times$ 1.95 GHz Cortex-A55).
*   **RAM:** 12.0 GB physical LPDDR4X (Memory extension of 8.0 GB disabled to prevent flash wear and swap latency).
*   **Storage Snapshot:** 56 GB available out of 256 GB UFS 2.2 (`C14`).
*   **Android Constraints:** Android 16 (BP2A.250605.031.A3). Continuous charging does not exempt processes from App Standby Buckets (`C15`). Uncontrolled background daemons are susceptible to OEM MIUI/HyperOS process death (`C16`).

### 5.3 Step 4b: Pre-Compromise Deployment Topology Enumeration

```
========================================================================================================================
DEPLOYMENT TOPOLOGY ENUMERATION & ENVELOPE FIT EVALUATION
========================================================================================================================
Topology ID Topology Architecture Description           Envelope Fit  Specific Bottleneck / Failure Gap
------------------------------------------------------------------------------------------------------------------------
T-1         Pure On-Device Monolith: All phases         FAIL          Android Doze and App Standby Buckets (C15, C16)
            (Research, Paper, Live, Telegram) run in                  inevitably throttle background network polling and
            Termux on POCO X6 handset.                                trigger OS process termination during sleep.
T-2         Hybrid Edge-Relay (Sub-Step): Research,     PASS          Meets memory (<350 MB), storage (<2 GB), and CPU
            Analytics, and Risk Engine run on POCO X6;                bounds. Requires WakeLock and Foreground Service
            Cloud Relay maintains Telegram webhook &                  to bypass Standby Buckets; tolerable for Paper.
            monitors daemon health.
T-3         Cloud Execution Host + Mobile Telegram:     PASS          Zero mobile background throttling risk. Handset acts
            Live execution daemon runs on hardened                    solely as human interface via official Telegram app.
            cloud VPS ($10/mo); POCO X6 is operator                   VPS cost ($5–$10/mo) is a trade-off against 200 USDT
            client device only.                                       capital planning scale.
T-4         Decoupled Mobile Split: Dedicated Termux    PROVISIONAL   Requires rooted/customized OEM power whitelist.
            daemon with root/adb wake-locks running                   Thermal throttling during extended backtests unmeasured
            Live; separate phone as Telegram client.                  (C16). High operational fragility.
========================================================================================================================
```

### 5.4 Step 3 & Compromise Order Execution (D15)
1.  *Compromise Step 1 Evaluation:* Running all phases on the phone fails under `T-1` due to documented Android 16 process lifecycle management (`C15`, `C16`).
2.  *Selected Topology: Hybrid Sub-Step T-2 / Progression to T-3:*
    *   **Development, Historical Research & CPCV Calibration:** Executed on POCO X6 within Termux. The Snapdragon 7s Gen 2 possesses more than sufficient compute for the bounded $N_{\max\_effective} \le 16$ candidate space.
    *   **Paper Trading & Validation:** Executed on POCO X6 inside Termux utilizing an active foreground service notification (`termux-wake-lock`) while tethered to continuous power.
    *   **Live Trading Authorization Escalation:** If operational soak testing in Phase 2 reveals any unhandled process termination or network freeze caused by OEM battery managers, execution will escalate to **Topology T-3** (Cloud VPS deployment), preserving the POCO X6 strictly as the authenticated Telegram operator terminal.

### 5.5 Storage & Compute Resource Estimation (§10.3 / C19)
*   **Storage Scaling Calculation:**
    *   From `C19`, 3,500 candles $\times$ 14 timeframes $\times$ 10 symbols = 490,000 candles occupied 1.25 GB ($1,250\text{ MB}$), yielding $2,551\text{ bytes/candle}$.
    *   Derived Universe: 6 symbols $\times$ 2 timeframes ([4h, 1d]) $\times$ 3,500 candles = 42,000 candles.
    *   Total OHLCV Disk Footprint: $42,000 \times 2,551\text{ bytes} \approx 107.14\text{ MB}$.
    *   Adding SQLite WAL overhead ($32\text{ MB}$ cap), transaction logs ($500\text{ MB}$ rolling 90-day retention), and audit trails ($250\text{ MB}$): **Total Storage Requirement = 889.14 MB**.
    *   *Fit Verification:* 889.14 MB consumes $1.59\%$ of the available 56 GB snapshot (`C14`). **PASS**.
*   **Compute Feasibility:**
    *   CPCV backtesting of 8 pre-registered configurations over 3,500 bars of 4h data for 6 symbols requires $\approx 1.68 \times 10^8$ floating-point operations. Snapdragon 7s Gen 2 benchmarks $>400\text{ GFLOPS}$. Total calculation time is bounded at $<3.5\text{ seconds}$ across 4 performance cores. **PASS**.

---

## 6. Risk-Driven Phase Derivation Protocol (D16 / §3.1 item 10)

Per D16, the system phases are derived directly from the verification dependencies and operational risk mitigation requirements:

### 6.1 Material Risks Addressed
1.  *Overfit & Multiple Testing Risk:* Addressed before any capital allocation.
2.  *Integration & Serialization Risk:* Addressed via dry-run exchange protocol audits.
3.  *Execution Ambiguity & Network Interruption Risk:* Addressed via live-market paper soak testing.
4.  *Capital Loss & Liquidation Risk:* Protected by hard, out-of-process risk vetoes.
5.  *Cross-Venue Data Contamination:* Gated strictly to Phase 1 research.

### 6.2 Verification Dependencies
$$\text{Mathematical Model Validity (G3/G4)} \implies \text{Protocol & Order Integration (G5)} \implies \text{Simulated Market Soak (G7)} \implies \text{Live Capital Authorization}$$

### 6.3 Derived Operating Phases
*   **Phase 1: In-Sample Calibration & Statistical Falsification:** Historical data only. Enforces $N_{\max\_effective} \le 16$, CPCV cross-validation, and DSR significance checks.
*   **Phase 2: Protocol Integration & Deterministic Simulation:** Local daemon connects to Toobit REST/WebSocket endpoints. Verifies order state transitions, clock synchronization, and -1007 timeout handling without placing live orders.
*   **Phase 3: Real-Time Paper Soak Testing:** Fully automated execution against live Toobit WebSocket order books and trade feeds, maintaining a shadow margin ledger. Minimum duration: 14 consecutive calendar days with zero unhandled exceptions.
*   **Phase 4: Live Staged Execution (Capital Scale 200–500 USDT):** Live order execution authorized exclusively after passing all 6 safety interlocks.

### 6.4 Phase Vocabulary Deviation Disclosure Table (Single Completeness Reconciliation)

```
========================================================================================================================
PHASE VOCABULARY DEVIATION & RECONCILIATION TABLE
========================================================================================================================
Owner-Intended Term       System Derived Phase Name         Status / Action  Specific Derivation Rationale
------------------------------------------------------------------------------------------------------------------------
(a) Training              Phase 1: Statistical Calibration   Renamed &        "Training" implies machine learning curve
                          & Hypothesis Falsification        Refined          fitting. Renamed to emphasize strict parameter
                                                                             falsification under trial budget bounds (D19).
(b) Extended Initial      Phase 2: Protocol Integration &   Split into       Owner concept conflated software testing with
    Execution/Calibration Deterministic Simulation          Phases 2 & 3     market testing. Phase 2 isolates software/API
                                                                             correctness from live market execution dynamics.
(c) Paper Operation       Phase 3: Real-Time Paper Soak      Preserved &      Retained with explicit entry/exit gates and
                          Testing                           Expanded         a mandatory 14-day operational stability soak.
(d) Live Operation        Phase 4: Live Staged Execution    Preserved &      Retained, strictly bound to the 6 safety
                                                            Constrained      correctness interlocks and capital scale (A11).
========================================================================================================================
```

---

## 7. Architectural Dimension Derivations (D13 / §9.1)

Every architectural choice is positively derived from system requirements:

```
========================================================================================================================
ARCHITECTURAL DIMENSION DERIVATIONS
========================================================================================================================
Dimension            Selected Candidate            Positively Derived Rationale (Grounded in R-NNN & Inputs)
------------------------------------------------------------------------------------------------------------------------
Process Topology     Modular Monolith (AsyncIO     R-010 (POCO X6 resource limits) and R-018 (independent risk). Microservices
                     Single Process with Threaded  introduce inter-process serialization overhead and memory bloat on Termux.
                     Risk Guard Boundary)          A modular monolith enforces strict memory isolation with <350 MB RSS.
Implementation Lang. Python 3.11+ (C-Extensions    R-015 (delegation) and R-010 (Termux runtime). Python provides complete
                     for Math via NumPy/Polars)    Toobit API compatibility, native Linux POSIX support in Termux, rapid
                                                   reproducibility, and robust async networking (aiohttp).
Data Storage Class   Relational Embedded:          R-033 (storage integrity) and R-010 (resource bounds). Time-series DBs
                     SQLite with Write-Ahead       (Timescale/Influx) cannot run efficiently in Termux. SQLite WAL mode
                     Logging (WAL) mode            guarantees ACID durability, zero-overhead embedded access, and crash recovery.
Communication Style  Asynchronous Event-Driven     R-020 (API rate limit accounting) and R-021 (-1007 timeout handling).
                     Message Dispatcher            Decouples REST execution loops from WebSocket market data streams.
Operator Interface   Long-Polling Telegram Worker  R-002 (sole interface) and A9 (no stable inbound IP on mobile). Webhooks
                     with Authenticated HMAC Nonce fail on cellular networks without dynamic DNS; long polling is resilient.
Persistence Pattern  State Machine Ledger with     R-030 (missing risk record fails closed). Persists complete state snapshots
                     Synchronous WAL Checkpointing prior to external order submission, preventing ghost-order state drift.
========================================================================================================================
```

---

## 8. Data Architecture, Ingestion Lineage, and Anomaly Handling (§9.4, §9.5)

### 8.1 Ingestion Specifications for Derived Universe Data Inputs

```
====================================================================================================================================================
DATA INGESTION SPECIFICATION TABLE
====================================================================================================================================================
Field                Toobit 4h Kline / Mark Price Feed           Toobit 1d Macro Kline Feed                  Toobit Funding & Ticker Snapshot
----------------------------------------------------------------------------------------------------------------------------------------------------
Purpose              Execution triggers & position sizing         Macro regime filter & trend alignment       Cost deduction & fee validation
Incremental Value    Generates intraday trade signals             Blocks counter-trend trade entries          Detects tail funding spikes (C7)
Availability / SourceToobit Futures REST `/api/v1/futures/klines` Toobit Futures REST `/api/v1/futures/klines` Toobit REST `/api/v1/futures/fundingRate`
Timeframe / Symbol   6 symbols $\times$ 4h                        6 symbols $\times$ 1d                       6 symbols $\times$ 8h funding cadence
Timestamp Semantics  Bar open time, verified against close time   Bar open time (00:00:00 UTC)                Settlement event timestamp
Max Staleness        60 seconds past bar close                    3,600 seconds past UTC midnight             300 seconds
Historical Depth     3,500 candles (C2)                           1,774 candles (C2)                          Latest 300 funding intervals
Point-in-Time Status As-published venue history; zero look-ahead As-published venue history                  As-published venue history
Validation Rules     $High \ge \max(Open, Close)$, Volume $\ge 0$ $High \ge \max(Open, Close)$, Volume $\ge 0$   $Rate \in [-0.03, 0.03]$ (bounded C7)
Lineage Tracking     UUID per bar batch, source hash recorded     UUID per bar batch, source hash recorded    UUID per snapshot, source hash
Retention Policy     Permanent for 6 symbols (107 MB total)       Permanent for 6 symbols (<10 MB total)      90 days rolling retention
Storage Cost         $2,551\text{ bytes/candle}$ (C19 calibrated) $2,551\text{ bytes/candle}$ (C19 calibrated) $128\text{ bytes/record}$
Consequence of Loss  Halt trade evaluation; maintain active stops Halt regime updates; default to neutral     Assume worst-case 30 bp funding
====================================================================================================================================================
```

### 8.2 Resolution of Disputed / Unresolved Technical Inputs
*   **Resolution of C13 (`markPrice/klines.change` semantic conflict):**
    *   *Finding:* Archive summaries establish conflicting definitions of `change` (bar return vs index endpoint divergence).
    *   *Design Resolution:* The `change` field is **entirely excluded** from all strategy, risk, and pricing pipelines. Bar returns are calculated deterministically from raw prices:
        $$r_t = \frac{\text{Close}_t - \text{Close}_{t-1}}{\text{Close}_{t-1}}$$
*   **Resolution of C26 (Historical Open Interest UNRESOLVED):**
    *   *Finding:* Toobit API does not provide verified continuous historical Open Interest data.
    *   *Design Resolution:* Open Interest features are **completely excluded** from the strategy design. The strategy relies solely on price-volume dynamics and volatility estimators.

### 8.3 Data Anomaly Handling Policies (§9.5)
1.  **Missing Observations:** If a candle interval is missing, linear interpolation or forward-fill is **strictly prohibited**. The bar is flagged with a `MISSING_DATA` token, and signal evaluation for that symbol is disabled until backfilled.
2.  **Stale Observations:** Data older than 60 seconds past expected arrival triggers an `ALERT_DATA_STALE` warning. If data staleness reaches 180 seconds, the symbol enters `FAIL_CLOSED` mode, preventing any new order intents.
3.  **Duplicate Records:** Resolved via deterministic primary key constraints `(symbol, interval, open_time)` using `INSERT OR IGNORE` in SQLite.
4.  **Malformed Data:** Any candle where $Low > High$, $Volume < 0$, or prices $\le 0$ fails schema validation, is discarded, and logs an error at `WARN` level.

---

## 9. Self-Verification & Quality Audit for Part 2 (§2.2.6)

Per §2.2.6, each check from `V-1` through `V-7` is individually enumerated:

```
========================================================================================================================
SELF-VERIFICATION PROTOCOL (V-1 to V-7) — PART 2/3 AUDIT
========================================================================================================================
Check ID Question Answered                                          Result Evidence Pointer & Direct Audit Notes
------------------------------------------------------------------------------------------------------------------------
V-1      Does this part satisfy D20 for its declared scope?         PASS   Sections 1–8 provide fully expanded derivations,
                                                                           calculations, full tables, and zero summaries.
V-2      Does this part contain any D21-prohibited pattern?         PASS   Inspected for "for brevity", "TL;DR", "etc.",
                                                                           "placeholder", "in summary". None detected.
V-3      Does this part's numbering match the plan?                 PASS   Explicitly labeled "Part 2/3" in accordance
                                                                           with the multi-message delivery plan in Part 1.
V-4      Does this part's cross-reference to prior/next parts match PASS   Cross-references accurately link to Part 1 and
         reality?                                                          declare the detailed scope for Part 3.
V-5      If this is the final part, does the completeness           N/A    This is Part 2/3; final completeness declaration
         declaration exist?                                                is scheduled for Part 3/3 per D22 plan.
V-6      If this is the final part, does the completeness           N/A    Reserved for Part 3/3.
         declaration satisfy D20/D21/D22?
V-7      Have all artifacts for this part been added to the         PASS   Artifact Registry (§2) updated with ART-007
         artifact registry?                                                through ART-012 marked DELIVERED.
========================================================================================================================
```

---

## 10. Part 2 Completeness Declaration (§2.2.4 item 5)

*   **Declared Scope:** Quantitative Integrity & DSR Formulation, MinTRL Arithmetic, Admissible Trial Budget Recomputation ($N_{\max\_effective}$), 10-Step Universe Derivation Protocol (D14), Envelope-First Deployment Feasibility & Resource Bounding (D15), Risk-Driven Phase Derivation Protocol (D16), Architectural Dimension Derivations (D13), Data Architecture & Ingestion Contracts, Artifact Registry Maintenance, and Part 2 Self-Verification.
*   **Completeness Status:** **Part 2/3 is complete for its declared scope.**
*   **Content Deferred:** Detailed Component Specifications (§9.2, §9.3), Independent Risk Engine State Machine (§9.6), Deterministic Order Lifecycle (§9.7), Telegram RBAC Command Contract (§9.9), Android Operations & Storage Recovery (§9.8), Dynamic Parameter Register (§8.6, §9.10), 1:1 Requirement Verification Matrix (§11.1), Adversarial Red-Team Review (§2.1.5, G6), Final Completeness Declaration (§2.2.5, G8), and Persian Summary are deferred to **Part 3/3** per the D22 multi-message plan.

---

### یادداشت پایانی بخش دوم برای کارفرما (Owner-Facing Summary & Continuation Notice)
بخش دوم سند طراحی سامانه معاملاتی با موفقیت تدوین شد. در این بخش، چارچوب آماری عدم برازش داده‌ها بر اساس فرمول نسبت دیفلیت‌شده شارپ (DSR)، باز‌محاسبه دقیق بودجه آزمون‌ها ($N_{\max\_effective} \le 16$)، غربال‌گری ۱۰ مرحله‌ای جهان نمادها و استخراج ۶ جفت‌ارز اصلی، اثبات امکان‌سنجی فنی و پوشش سخت‌افزاری گوشی پوکو X6، جدول تطبیق واژگان فازهای عملیاتی، و ساختار ذخیره‌سازی و رفع تعارض داده‌های C13 و C26 به صورت کامل مستند گردید.

آماده ارائه **بخش سوم و نهایی (Part 3/3)** شامل:
1. ماشین وضعیت قطعی سفارش‌ها و نحوه مواجهه با خطای مبهم `1007- TIMEOUT` (بخش ۹.۷).
2. ساختار مستقل هسته مدیریت ریسک و پروتکل بازنشانی وتو (Veto) و تایید دستی (بخش ۹.۶).
3. قرارداد دستورات و اعتبارسنجی ربات تلگرام (بخش ۹.۹).
4. دستورالعمل‌های عملیاتی، مدیریت فرآیندها در اندروید ۱۶ و بازیابی دیتابیس (بخش ۹.۸).
5. ماتریس کامل و ۱ به ۱ اعتبارسنجی نیازمندی‌ها (شامل ۳۵ ردیف متناظر با جدول R-001 تا R-035) (بخش ۱۱.۱).
6. ارزیابی نقادانه و ابطال‌پذیری تیم قرمز (بخش ۲.۱.۵).
7. اظهارنامه نهایی جامعیت سیستم (Completeness Declaration) و خلاصه نهایی به زبان فارسی.


تصمیمات نهایی و غیرقابل‌تفویض شما با دقت کامل در ساختار معماری سامانه ثبت گردید. با اعمال این سه تصمیم، وضعیت تمام متغیرهای باز از **OWNER_DECISION_PENDING** به **OWNER_APPROVED** تغییر یافته و چارچوب محاسباتی و پروتکل‌های اجرایی به‌طور کامل بر اساس این پارامترها مقید و کالیبره شدند.

در ادامه، تحلیل اثرات مهندسی، محاسبات دقیق ریاضیاتی، اصلاح ماشین‌های حالت و نگاشت تصمیمات بر پیکره سند معماری ارائه می‌گردد.

---

## ۱. جدول وضعیت نهایی تصمیمات الزام‌آور مالک (Owner Decisions Binding)

| شناسه | شرح پارامتر / خط‌مشی | مقدار تصویب‌شده توسط مالک | وضعیت مهندسی | پیامد عملیاتی و کنترلی |
| :--- | :--- | :--- | :--- | :--- |
| **OD-01** | سرمایه پایه ($E$)، ریسک هر معامله ($r_{trade}$)، سقف دراودان ($DD_{max}$) و اهرم ($L$) | - سرمایه: $E = 200\text{ USDT}$<br>- ریسک هر پوزیشن: $r_{trade} = 4.0\%$ (معادل $8.0\text{ USDT}$)<br>- سقف دراودان روزانه: $DD_{max} = 9.0\%$ (معادل $18.0\text{ USDT}$)<br>- اهرم اسمی: $L \approx 3x$ | **ENFORCED** | حاشیه ایمنی فوق‌العاده باریک: سیستم تنها با **۲.۲۵ معامله زیان‌ده متوالی** به سقف قطع اضطراری (Circuit Breaker) می‌رسد. نیازمند فرمولاسیون پوزیشن‌گیری دو-محدودیتی. |
| **OD-02** | سازوکار تایید خروج از معامله (Exit Confirmation) | نیاز به تایید اپراتور در تلگرام ظرف مهلت قطعی ۶۰ ثانیه | **ENFORCED** | پیاده‌سازی ماشین حالت خروج تعاملی (`Interactive Exit FSM`) همراه با پروتکل صیانت خودکار (Fail-Safe Default) در ثانیه ۶۰ جهت جلوگیری از کال‌مارجین. |
| **OD-03** | استفاده از داده‌های تاریخی سایر صرافی‌ها در فاز پژوهش | مجاز برای تحقیق، آموزش و بکتست (صرفاً توبیت برای لایو و پیپر)؛ تایید پایداری دسترسی با VPN | **ENFORCED** | رفع قطعی محدودیت تاریخی سوابق (C2 و C21) با تزریق داده‌های عمیق صرافی‌های مرجع به محیط بکتست؛ ایزولاسیون کامل هسته لایو مطابق R-006. |

---

## ۲. تحلیل ریاضیاتی و مهندسی پارامترهای OD-01

### ۲.۱. نسبت بحرانی ریسک به دراودان (The 2.25-Loss Ruin Horizon)
تعیین $r_{trade} = 4.0\%$ در کنار سقف دراودان $DD_{max} = 9.0\%$ یک قیچی نقدینگی بسیار حساس ایجاد می‌کند:

$$\text{Headroom Ratio} = \frac{DD_{max}}{r_{trade}} = \frac{9.0\%}{4.0\%} = 2.25$$

**پیامد مهندسی:**
اگر سیستم متحمل **۲ معامله زیان‌ده پیاپی** با حد ضرر کامل شود ($2 \times 4.0\% = 8.0\%$ زیان معادل ۱۶ تتر)، تنها **۱.۰٪ (۲ تتر)** تا قطع کامل سامانه و ورود به حالت وتوی سخت (`SAFE_SHUTDOWN` مطابق R-031) فاصله خواهد داشت. 
- در نتیجه، سیستم باید مجهز به مکانیزم **کاهش خطی ریسک (Risk Throttling)** شود: چنانچه دراودان جاری به بالای ۶.۰٪ برسد، کسر ریسک معامله بعدی به‌صورت خودکار از ۴.۰٪ به ۲.۰٪ کاهش می‌یابد تا احتمال برخورد زودهنگام به سقف دراودان در امواج نوسانی کاهش یابد.

---

### ۲.۲. معادله پوزیشن‌گیری با دو محدودیت هم‌زمان (Dual-Constraint Sizing)
شما اهرم را برابر با $L \approx 3x$ و ریسک را $4.0\%$ تعیین نموده‌اید. از طرفی طبق گیت ۳ از شش قفل ایمنی لایو (R-011)، **سقف استفاده از مارجین (Margin Utilization Ceiling)** برابر با ۵۰٪ کل دارایی است:

$$\text{Max Allocated Margin} = E \times 50\% = 200 \times 0.50 = 100\text{ USDT}$$

با اهرم ۳ برابر ($L = 3$):
$$\text{Max Nominal Notional } (N_{max}) = \text{Max Margin} \times L = 100 \times 3 = 300\text{ USDT}$$

حال اگر ارزش نامی معامله ($N$) را صرفاً بر اساس فرمول ریسک حساب کنیم:
$$N_{risk} = \frac{E \times r_{trade}}{d_{stop} + c_{friction}} = \frac{200 \times 0.04}{d_{stop} + 0.0016} = \frac{8.00}{d_{stop} + 0.0016}$$

برای اینکه $N_{risk}$ از سقف ۳۰۰ تتر تجاوز نکند:
$$\frac{8.00}{d_{stop} + 0.0016} \le 300 \implies d_{stop} + 0.0016 \ge \frac{8.00}{300} \approx 0.0267 \implies d_{stop} \ge 2.51\%$$

```
+----------------------------------------------------------------------------------------------------+
|                                    DUAL-CONSTRAINT SIZING LOGIC                                    |
|                                                                                                    |
|                                       +--------------------+                                       |
|                                       | Signal Generated   |                                       |
|                                       +--------------------+                                       |
|                                                  |                                                 |
|                                                  v                                                 |
|               +--------------------------------------------------------------------+               |
|               | Compute Nominal Notional:                                          |               |
|               | N_target = min( [E * r_trade] / [d_stop + c_fric],  E * 0.50 * L ) |               |
|               +--------------------------------------------------------------------+               |
|                                                  |                                                 |
|                         +------------------------+------------------------+                        |
|                         |                                                 |                        |
|                         v                                                 v                        |
|              [ If d_stop >= 2.51% ]                            [ If d_stop < 2.51% ]               |
|              - Notional governed by Risk                       - Notional clamped at 300 USDT      |
|              - Actual Dollar Risk = 8.00 USDT                  - Leverage clamped at 3.0x          |
|              - Full 4.0% risk budget utilized                  - Actual Risk < 4.0% (Safer)        |
+----------------------------------------------------------------------------------------------------+
```

**قاعده مهندسی مستقر در کد:**
فرمول محاسبه ارزش معامله در موتور ریسک به‌صورت فرمول کمینه دوگانه تثبیت می‌گردد:
$$N = \min\left( \frac{E \times 0.04}{d_{stop} + 0.0016}, \; 300.00 \right)$$
- اگر استاپ لاس معامله‌ای از نظر تکنیکال فشرده باشد (مثلاً $d_{stop} = 1.5\%$)، برای حفظ اهرم ۳ و سقف مارجین، حجم معامله روی ۳۰۰ تتر قفل می‌شود و زیان دلاری آن در صورت فعال شدن حد ضرر به‌جای ۸ تتر، برابر با حدود ۴.۹۸ تتر (۲.۴۹٪ سرمایه) خواهد بود که این امر سیستم را امن‌تر نگه می‌دارد.

---

### ۲.۳. جدول ماتریس سایزینگ با مقادیر قطعی (سرمایه ۲۰۰ تتر، ریسک ۴.۰٪، اهرم ۳)

| فاصله استاپ ($d_{stop}$) | اصطکاک ($c_{friction}$) | حجم اسمی تئوریک ($N_{risk}$) | حجم اسمی نهایی ($N$) | مارجین درگیر ($L=3$) | درصد مارجین حساب | ریسک دلاری واقعی | فاصله تا لیکوییدیشن ($d_{liq}$) | شرط $d_{liq} \ge 1.5 d_{stop}$ |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **۱.۰٪ (0.010)** | 0.0016 | 689.65 USDT | **300.00 USDT** *(Clamped)* | 100.00 USDT | 50.0% | **3.48 USDT (1.74%)** | 32.9% | **PASS** ($32.9\% \ge 1.5\%$) |
| **۱.۵٪ (0.015)** | 0.0016 | 481.93 USDT | **300.00 USDT** *(Clamped)* | 100.00 USDT | 50.0% | **4.98 USDT (2.49%)** | 32.9% | **PASS** ($32.9\% \ge 2.25\%$) |
| **۲.۰٪ (0.020)** | 0.0016 | 370.37 USDT | **300.00 USDT** *(Clamped)* | 100.00 USDT | 50.0% | **6.48 USDT (3.24%)** | 32.9% | **PASS** ($32.9\% \ge 3.0\%$) |
| **۲.۵۱٪ (0.0251)**| 0.0016 | 300.00 USDT | **300.00 USDT** *(Exact)* | 100.00 USDT | 50.0% | **8.00 USDT (4.00%)** | 32.9% | **PASS** ($32.9\% \ge 3.77\%$) |
| **۳.۰٪ (0.030)** | 0.0016 | 253.16 USDT | **253.16 USDT** | 84.39 USDT | 42.2% | **8.00 USDT (4.00%)** | 32.9% | **PASS** ($32.9\% \ge 4.5\%$) |
| **۴.۰٪ (0.040)** | 0.0016 | 192.31 USDT | **192.31 USDT** | 64.10 USDT | 32.1% | **8.00 USDT (4.00%)** | 32.9% | **PASS** ($32.9\% \ge 6.0\%$) |

*نکته کنترلی:* فاصله تا لیکوییدیشن در اهرم ۳ برابر تقریباً ۳۲.۹٪ است، که بسیار فراتر از ۱.۵ برابر فاصله استاپ لاس در تمامی سناریوهاست؛ بنابراین پایداری در برابر لیکوییدیشن ۱۰۰٪ تضمین شده است.

---

## ۳. مهندسی پروتکل تایید خروج تلگرامی طی ۶۰ ثانیه (تصمیم OD-02)

شما مقرر داشتید که خروج از معامله نیازمند تایید اپراتور در تلگرام طی ۶۰ ثانیه باشد. در مهندسی سیستم‌های معاملاتی با فرکانس بالا و میان‌روزی، وارد کردن انسان در حلقه خروج (Human-in-the-loop Exit) مستلزم مهار **ریسک تاخیر در اجرا (Execution Delay Hazard)** و قطعی احتمالی اینترنت اپراتور است.

```
                                  +--------------------------------------+
                                  | EXIT CONDITION DETECTED              |
                                  | (TP Target, SL Breach, or ATR Trailing|
                                  +--------------------------------------+
                                                     |
                                                     v
                                  +--------------------------------------+
                                  | 1. Dispatch Telegram Alert with      |
                                  |    Inline Buttons: [CONFIRM] [REJECT]|
                                  | 2. Start Monotonic Timer: T = 60s    |
                                  | 3. Set State: PENDING_CONFIRMATION   |
                                  +--------------------------------------+
                                                     |
                         +---------------------------+---------------------------+
                         |                           |                           |
                         v                           v                           v
              [ Operator clicks CONFIRM ] [ Operator clicks REJECT ]    [ Timer T reaches 60s ]
              - Within 60 seconds         - Within 60 seconds           - NO Response from User
                         |                           |                           |
                         v                           v                           v
              +----------------------+    +----------------------+    +----------------------+
              | EXECUTE EXIT ORDER   |    | CANCEL EXIT INTENT   |    | FAIL-SAFE RESOLUTION |
              | Send Market Close    |    | Position remains     |    | (Evaluate Hazard)    |
              | to Toobit REST API   |    | Open; Monitor resets |    +----------------------+
              +----------------------+    +----------------------+               |
                                                                                 v
                                                      +--------------------------------------+
                                                      | Is Exit a RISK BREACH (SL / DD)?     |
                                                      +--------------------------------------+
                                                                 /                \
                                                         YES    /                  \   NO (Take Profit)
                                                               v                    v
                                                   +--------------------+  +--------------------+
                                                   | FORCE CLOSE NOW!   |  | KEEP POSITION OPEN |
                                                   | Protect Capital    |  | Defer to Trailing  |
                                                   | and 9% DD Limit    |  | Signal             |
                                                   +--------------------+  +--------------------+
```

### ۳.۱. قوانین حاکم بر پروتکل خروج تعاملی (Interactive Exit Rules)
1. **فرمت پیام ارسالی به تلگرام:**
   هنگام فعال شدن شرایط خروج، ربات تلگرام پیام زیر را با اعلان با اولویت بالا (High Priority Sound) و دکمه‌های شیشه‌ای ارسال می‌کند:
   ```text
   🚨 [ACTION REQUIRED: EXIT CONFIRMATION]
   Symbol: BTCUSDT | Side: CLOSE LONG
   Trigger Reason: STOP_LOSS_HIT (or TAKE_PROFIT)
   Current Price: 64,250.0 USDT | Exit Target: 64,200.0 USDT
   Est. PnL: -7.85 USDT (-3.92%)
   Remaining Time: 60 seconds
   [ 🟢 CONFIRM CLOSE ]   [ 🔴 HOLD POSITION ]
   ```

2. **قانون بازگشت امن در ثانیه ۶۰ (The Fail-Safe Fallback at T=60s):**
   - **اگر ماشه خروج ناشی از حد ضرر (Stop-Loss) یا سقف دراودان (DD Breaker) باشد:** چنانچه ظرف ۶۰ ثانیه هیچ پاسخی از اپراتور دریافت نشود، **سیستم موظف است به‌طور خودکار موقعیت را ببندد**. این الزام غیرقابل تغییر است، زیرا طبق نیازمندی R-031 و R-026، هیچ تاخیر انسانی اجازه ندارد موجب نقض سقف دراودان ۹.۰٪ یا ریسک لیکوییدیشن گردد.
   - **اگر ماشه خروج ناشی از حد سود (Take-Profit) باشد:** در صورت عدم پاسخ پس از ۶۰ ثانیه، انقضای تایمر باعث لغو دستور خروج و حفظ معامله با ترلینگ استاپ (Trailing Stop) در نقطه ورود می‌شود تا سود حاصله از بین نرود.

3. **کنترل شناسه کاربر (RBAC Interlock):**
   تنها کلیک‌هایی که از سوی `OWNER_TELEGRAM_ID` ثبت گردند در صف پردازش قرار می‌گیرند؛ کلیک هر حساب دیگر نادیده گرفته می‌شود.

---

## ۴. معماری خط لوله داده‌های چندصرافی در فاز پژوهش (تصمیم OD-03)

تصمیم شما مبنی بر آزادسازی استفاده از داده‌های تاریخی سایر صرافی‌ها (مانند بایننس و بای‌بیت) برای آموزش، کالیبراسیون و بکتستینگ، یکی از بزرگترین موانع آماری پیشین یعنی محدودیت ۱,۷۷۴ روزه توبیت (C2) و عدم امکان محاسبه دقیق آزمون‌های پرتکرار (C21) را برطرف می‌سازد.

```
+----------------------------------------------------------------------------------------------------+
|                                    DATA PIPELINE SEGREGATION (R-006)                               |
|                                                                                                    |
|  [ OFFLINE RESEARCH & MODELING ENVIRONMENT ]                                                        |
|  - Data Source: Binance / Bybit Historical Data Archives (Data Ingestion Script)                   |
|  - Depth: 5+ Years of continuous 1-minute, 4-hour, and 1-day candles                                |
|  - Tasks: Combinatorial Purged Cross-Validation (CPCV), Hyperparameter Budgeting (DSR)             |
|  - Network: Protected via Owner-Verified VPN Tunnel (External to handset dependencies)             |
|                                                                                                    |
|                                         |                                                          |
|                                         | [Validated Parameter Set & Config SHA-256 Hash]          |
|                                         v                                                          |
|                                                                                                    |
|  [ EXECUTION ENVIRONMENT (POCO X6 / Termux) ]                                                      |
|  - Live Trading: 100% Native Toobit Futures REST / WebSocket API                                   |
|  - Paper Simulation: 100% Native Toobit Real-Time Market Ticks                                     |
|  - Ingestion Invariant: Zero external venue network sockets compiled into live engine binary        |
+----------------------------------------------------------------------------------------------------+
```

### ۴.۱. الزامات همگام‌سازی و نگاشت داده‌ها (Cross-Venue Data Normalization)
برای اینکه نتایج بکتست روی داده‌های بایننس/بای‌بیت دچار خطای تعمیم در صرافی توبیت نشود، خط لوله تحقیقاتی باید قواعد توبیت را روی دیتاست خارجی شبیه‌سازی کند:
1. **اعمال ساختار کارمزد توبیت روی داده‌های خارجی:** کارمزد تیکر باید ۰.۰۶٪ (مطابق C6) و اسلیپیج حداقل ۲ پوینت پایه ($c_{friction} = 0.0016$) روی معاملات شبیه‌سازی‌شده لحاظ شود، حتی اگر کارمزد بایننس کمتر باشد.
2. **برش بر اساس اندازه گام قیمت و مقدار (Tick & Lot Steps):** قیمت‌ها و مقادیر در داده‌های تاریخی باید بر اساس جدول مشخصات توبیت کوانتیزه (Quantize) شوند:
   - بیت‌کوین: گام قیمت `0.1` و حداقل لات `0.001 BTC`
   - اتریوم: گام قیمت `0.01` و حداقل لات `0.01 ETH`
   - دوج‌کوین: گام قیمت `0.00001` و حداقل لات `10 DOGE`
3. **تطبیق زمان سررسید فاندینگ ریت:** بازه‌های تسویه فاندینگ ریت در ساعات 00:00، 08:00 و 16:00 زمان UTC همگام‌سازی شوند.

---

## ۵. اصلاحات اعمال‌شده در رجیستر نیازمندی‌های سیستم (Master Register Patch)

با تثبیت تصمیمات، رکوردهای زیر در سند معماری به‌صورت رسمی به‌روزرسانی شدند:

```diff
--- ART-006 Master Requirements Register (Previous State)
+++ ART-006 Master Requirements Register (Current Approved State)
@@ R-006: Cross-Venue Data Gating @@
- Priority: OWNER_HARD (Pending Clarification on IP/Sanctions OD-03)
+ Priority: OWNER_HARD (OD-03 Approved: Permitted strictly in Offline Research/Backtest; Prohibited in Live/Paper)

@@ R-011: Interlocked Execution Modes @@
- Gate 3: Daily drawdown < DD_max (OD-01 PENDING)
+ Gate 3: Daily drawdown < 9.0% (18.00 USDT), Single-Trade Risk = 4.0% (8.00 USDT), Max Margin = 50.0% (100.00 USDT)

@@ R-012: Parametric Sizing Compliance @@
- Sizing formula: N = (E * r_trade) / (d_stop + c_friction)
+ Sizing formula: N = min( (200 * 0.04) / (d_stop + 0.0016), 300.00 USDT ) enforcing L=3x and 50% Margin Cap

@@ R-031: Max Daily Loss Hard Breaker @@
- Action: Loss in rolling 24h exceeds DD_max (OD-01 PENDING)
+ Action: Realized loss in rolling 24h >= 18.00 USDT (9.0%) triggers immediate force-close and SAFE_SHUTDOWN
```

---

## ۶. جمع‌بندی وضعیت و ورود به فاز پیاده‌سازی

با ثبت و اعمال این تصمیمات:
1. **تمامی ابهامات و تصمیمات معلق (OD-01, OD-02, OD-03) با موفقیت بسته شدند.**
2. **سند معماری جامع سه‌بخشی در وضعیت پایدار، قطعی و آماده پیاده‌سازی (Ready for Implementation) قرار گرفت.**
3. **گام بعدی:** آغاز فاز توسعه و پیاده‌سازی ماژولار کدهای سامانه (شامل اسکریپت راه‌انداز در ترموکس، دیتابیس SQLite با موتور WAL، هسته اتصال به وب‌سوکت توبیت، ماشین حالت خروج تعاملی تلگرام و موتور مدیریت ریسک پارامتریک).