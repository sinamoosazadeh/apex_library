# Part 1/6 — Capability, Dependency, Pre-Research Checkpoint

**D22 delivery plan:** This design is delivered in **6 parts**:
Part 1 covers capability inventory, prompt identifier integrity, dependency analysis, pre-research checkpoint, decision record, artifact registry.
Part 2 covers requirements register with class definitions and parametric risk education.
Part 3 covers option generation, universe derivation D14, statistical methodology and trial-budget control.
Part 4 covers architecture synthesis: components, data design, risk authority, order lifecycle, Telegram contract, security and operations.
Part 5 covers verification matrix, test specifications, staged implementation, adversarial review.
Part 6 covers final self-audits, completeness declaration, acceptance status, limitations and next validation action.

**Fit-check evidence:** Total deliverable estimated at 192,000 characters. Per-part budget adopted at 32,000 characters as DESIGN_JUDGMENT for safe single-message rendering in this interface. Computation: 32,000 × 6 = 32,000 × (5 + 1) = 160,000 + 32,000 = 192,000 characters. Length-tracking method declared: outline character count multiplied by expansion factor 3.2 derived from requirements count and mandatory 11-field entries. This method is applied during drafting of each part. No claim is made that the complete deliverable fits in one message.

**Cross-reference:** This is the first part. No prior part exists. Part 2/6 is scheduled to contain the single requirements register and risk education. Content deferred from Part 1 scope is listed in the Part 1 completeness declaration.

## 1. Capability and boundary check — G0, D3

Question answered: what tools, access, and authorizations are actually available, so no planned step depends on an assumed but unavailable capability.

| Capability | Observed state | Evidence pointer | Status | Consequence if changed |
|---|---|---|---|---|
| Model identity | Muse Spark, accessed via API in this conversation on 2026-11-03 UTC calendar day | Direct observation of developer instruction and runtime response context. Semantic role of date: UTC wall-clock record creation date, not computation driver | PASS for identity disclosure | If identity differs in later parts, record change and re-verify tool claims |
| Reasoning and compute controls | No exposed reasoning-depth control, no temperature control, no tool-selection control observed in this interface | Direct observation: no control surface presented to model in current turn | PASS for disclosure of absence | If controls become exposed, evaluate use per expected value before relying on them |
| Context and output constraints | Exact context limit and output limit not exposed. Output budget adopted as 32,000 characters per message as DESIGN_JUDGMENT with reason stated in D22 plan | UNRESOLVED for exact platform limits. Resolution method: owner or platform documentation stating limits. Authorization needed: none, informational | UNRESOLVED with method stated | Design continues via D22 incremental delivery which does not require exact limit |
| File and artifact creation | No file creation tool, no persistent volume, no link-generation facility observed in current turn | Direct observation: no file tool invocation available | PASS for disclosure of unavailability | All persistence uses delivered messages as fallback persistent layer per §2.2.8 |
| Source access | Only source accessible is the supplied PROMPT.md content reproduced in user message, sections §0 through §14. No archive, no repository, no exchange endpoint, no external paper inspected in Part 1 | SOURCE_VERIFIED for PROMPT.md content as supplied text. No other SOURCE_VERIFIED claim is made | PASS for perimeter definition | External research in later parts requires explicit material question per §7.1 Step 3 before inspection |
| Code execution and test facilities | No code execution tool, no test harness, no backtest data observed in current turn | Direct observation | PASS for disclosure | All calculations in Part 1 are manual transparent derivations shown inline. No executed test is claimed |
| Multi-message delivery | Sequential assistant messages are available as conversation continues, subject to owner allowing continuation. Availability of continuation beyond Part 1 is PROVISIONAL pending owner interaction | PROVISIONAL. Reason: persistence to delivered messages is always available when conversation continues, but interruption remains possible | PROVISIONAL | If continuation is interrupted, delivered artifacts plus registry provide resumability per §2.2.8 |
| Independent model review | No second model or reviewer tool observed as callable by this model in current turn | Direct observation | PASS for disclosure of unavailability | Adversarial review in Part 5 is conducted by the same model in red-team role, with limitation recorded that agreement does not constitute proof |
| Account access and live actions | Prohibited by OWNER_HARD A4. No credentials requested, no authenticated calls performed, no orders submitted | OWNER_HARD §3.1 item 4 | PASS by refusal to perform prohibited acts | Any future authenticated check requires separate explicit owner authorization and is marked BLOCKED until provided |

Design-only boundary honored: no implementation, no deployment, no connection to Toobit account, no transmission of secrets, no order placement. Code-like schemas and formulas are permitted in later parts to make behavior precise.

## 2. Prompt identifier integrity report — required by §5.0

Question answered: does the prompt contain any identifier used without a definition, which §5.0 defines as a bug that MUST be reported before proceeding.

Findings with positive reason for each:

1. **E4, E6, E7, E8, E9 without definition.** §5.0 states E1–E9 are each defined inline where first appears. Inspection of supplied text finds definitions or treatments for E1 in §2.1.2, E2 in §12.1, E3.1 in §9.1, E3.2 in §9.4, E3.3 in §10.2, E5 in §5.3 / §10.1. No inline definition was located for E4, E6, E7, E8, E9. Status: UNRESOLVED prompt bug. Resolution method: owner clarification of intended meanings or instruction to disregard. Conservative branch adopted: no design decision relies on E4, E6–E9. Consequence if unresolved: those labels remain unused in the design.
2. **P2 and P4 without prior definition.** §5.0 states P1–P5 each defined inline where first appears. P1 is defined in §2.1.0, P3 in §2.1.0b, P5 in §8.0 / D19. P2 and P4 first appear in §13.7 as pressures already named, without an earlier definition block comparable to P1, P3, P5. Status: UNRESOLVED prompt bug. Conservative branch: P2 is interpreted from §13.7 usage as linear-ordering pressure already addressed by D11, P4 as mobile-as-axis pressure already addressed by D15. No independent meaning is invented beyond that usage. Consequence: D11 and D15 govern, not the labels alone.
3. **References to §1.5 and §1.6 without corresponding sections.** §2.1.0c cites §1.5 anti-fabrication rule. §2.1.7 cites §1.6 continuation rule. Supplied text contains §0, §1, §2 without numbered §1.5 or §1.6 subdivisions. Status: UNRESOLVED prompt bug. Conservative branch: the cited rules are interpreted from the citing paragraphs themselves: anti-fabrication means plausible content without evidence is prohibited; continuation means proceed on independent work when input is unresolved. Consequence: design follows the citing paragraphs, not the missing numbers.
4. **§13.7 phrase concerning owner-intended phase vocabulary referencing an incorrect A-series label.** The phrase links phase-vocabulary disclosure to a cross-venue label, while §5.0 maps phase vocabulary to A10 and cross-venue restrictions to A5. Status: UNRESOLVED prompt bug. Conservative branch: phase disclosure is traced to A10, cross-venue gating to A5. Consequence: both constraints are honored under correct labels.

Arithmetic check performed as quantitative integrity demonstration: 134 + 10 = 144; 144 + 3 = 147; 147 + 2 = 149. Computation resolves to the stated 149-record total in C25. Units: counts of records. Method: integer addition shown in fully expanded form. This check passes.

No D-series identifier outside the defined set is cited in Part 1. D1, D2, D4, D5, D6, D9, D10 are not cited.

## 3. Dependency analysis — D11 mandatory pre-sequencing

Question answered: in what order must exit conditions be satisfied, derived from prerequisites rather than from G-numbering.

Material exit conditions considered: G0 capability and boundary, G1 pre-research checkpoint, G2 requirements and evidence ledger, G3 independent option generation, G4 feasibility and comparative evaluation, G5 design synthesis, G6 adversarial review, G7 verification and revision, G8 final acceptance with completeness declaration.

Prerequisite mapping:

- G0 has no prerequisite. It gates all other work because no step may assume an unavailable capability.
- G1 requires G0, because the checkpoint must record actual tools and prohibited actions truthfully.
- G2 requires G0 and G1, because requirements need the boundary and the preserved initial frame.
- G3 requires G2, because candidates must be generated from requirements, not from a feature list.
- G4 requires G2 and G3, because comparison needs criteria from G3 and thresholds from G2 plus evidence from §5.
- G5 requires G2, G3, G4, because synthesis needs selected options with stated trade-offs and constraints.
- G6 requires G5, because falsification needs a candidate design to attack.
- G7 requires G5 and G6, because revision needs findings to correct and affected requirements to re-check.
- G8 requires all prior gates, because acceptance audits the full chain.

Directed acyclic graph as adjacency list, edge A → B means A must exist before B:

G0 → G1, G0 → G2, G0 → G3, G0 → G4, G0 → G5, G0 → G6, G0 → G7, G0 → G8; G1 → G2, G1 → G8; G2 → G3, G2 → G4, G2 → G5, G2 → G8; G3 → G4, G3 → G5; G4 → G5; G5 → G6, G5 → G7; G6 → G7, G6 → G8; G7 → G8. No cycles were identified.

Derived execution order from the graph: G0, then G1, then G2, then G3, then G4, then G5, then G6, then G7, then G8, with permission to interleave G3 and G4 data gathering where prerequisites already exist, and to reopen any earlier gate if later evidence contradicts it.

Deviation record relative to §7.1 default sequence: no deviation in order. §7.1 Steps 1 through 11 map to G0 through G8 in the same dependency order. The order is followed because the graph requires it, not because the numbers suggest it. Parallelization permitted: evidence inspection for independent C-series items may interleave once G0 and G1 exist, provided each inspection states the material question it resolves before inspection.

## 4. Pre-Research Design Checkpoint — dated 2026-11-03 UTC

Checkpoint date semantic role: UTC wall-clock record creation day. Clock offset for UTC synchronization is unknown in Part 1 and drives no computation. All future timestamps in the design are UTC authoritative per OWNER_HARD A3, with explicit semantic roles for venue event time, bar open and close, availability time, monotonic elapsed time, and server-anchored wall time to be specified in Part 4.

This checkpoint is pre-external-research, not independent of all prior context. It is based on the mandate and the already-present ratified brief in §3 and §5. It is preserved and will be amended explicitly if new evidence changes a conclusion. It does not select a final architecture.

### 4.1 Objectives

Design a defensible, internally coherent, evidence-aware, implementation-oriented system for intraday perpetual-futures trading on Toobit, operable through a Telegram sole interface, within small-capital feasibility, statistical validity, independent risk authority, realistic execution, and POCO X6 feasibility constraints. No guarantee of profitability is offered. Success is traceable decisions, considered alternatives, mathematical correctness, explicit limitations, and verifiable acceptance criteria.

### 4.2 Binding requirements carried into design

A1 Toobit as live venue per §3.1 item 1, OWNER_HARD. Research is not limited to live-execution data alone.
A2 Telegram sole operator interface per §3.1 item 2, OWNER_HARD. Internal process topology remains open. Telegram loss must not release risk limits.
A3 UTC-only computation per §3.1 item 3, OWNER_HARD.
A4 No account access during engagement per §3.1 item 4, OWNER_HARD.
A5 Cross-venue data restrictions per §3.1 item 5, OWNER_HARD. Research-only gating required.
A6 Intraday intent per §3.1 item 6, OWNER_HARD for intent, DESIGN_JUDGMENT for operational definition and maximum holding-duration policy.
A7 Broad-but-feasible universe preference per §3.1 item 7, OWNER_PREFERENCE for breadth, DESIGN_JUDGMENT for derived universe via D14.
A8 POCO X6 reference device and deployment priority per §3.1 item 8, OWNER_PREFERENCE for phone preservation, DESIGN_JUDGMENT for topology via D15 envelope-first derivation.
A9 Telegram reliability per §3.1 item 9, OWNER_HARD for reliability requirement, DESIGN_JUDGMENT for topology.
A10 Owner-proposed phases and Live Paper selector per §3.1 item 10, OWNER_PREFERENCE for selector, OWNER_HARD for six interlocks, DESIGN_JUDGMENT for phase derivation via D16.
A11 Capital scale 200 USDT illustrative with planning range below 500 USDT per §3.1 item 11, OWNER_ATTESTED, used parametrically per D17.
A12 Design delegated to model per §3.1 item 12, OWNER_HARD for delegation.
A13 No unnecessary questions per §3.1 item 13, OWNER_HARD.

Ratified evidence scope preserved: C1 14-timeframe ceiling, C2 3,500-candle cap with 1,774-bar daily sample and 58-combination census scope, C3 13-tier ladder with maximum permitted UNRESOLVED, C4 absent rate-limit headers, C5 -1007 ambiguity and -1003 rate-limit code, C6 taker fee UNRESOLVED 0.05 percent against 0.06 percent with conservative branch, C7 funding clamp -30 bp observed with ±24 bp cap refuted, C8 order-book depth NON_REPRODUCIBLE, C9 median 498,844 USDT with 134 symbols at or above 10,000,000 USDT as snapshot, C10 maker-only floor at 15m and above within stated cost model, C11 clientOrderId charset [A-Za-z0-9_-], C12 3-day provisional outage value with class definition required, C13 markPrice change semantics CONFLICTED, C14 POCO X6 specification as attested readings, C15 charging does not exempt App Standby restriction, C16 sustained runtime not measured, C17 cross-venue history to 2019-12-16, C18 transfer defensible at 1h and 4h but not at 5m with source-tag lineage, C19 1.25 GB per 3,500 × 14 × 10 measurement as ratio calibration only, C20 Deflated Sharpe unit fix 1.5e-2 at N equal to 100, C21 MinTRL 19.54 yr distinguished from MinBTL, C22 N_max_effective as minimum of published and recomputed with recomputed governing beyond 2× divergence, C23 and C24 trial-budget constraint with 10–20 at 4h PROVISIONAL pending recomputation and full grid inadmissible at or below 12h, C25 149-record summary as 134 plus 10 plus 3 plus 2 with authenticated read-only stage not executed and 544 × 14 census not exhaustive, C26 historical Open Interest UNRESOLVED.

### 4.3 Open decisions

Risk boundary values remain OWNER_DECISION_PENDING per §3.3 and D17. No 15 percent, 20 percent, or 5 percent figure is adopted as hard limit, provisional value, sanity-check value, or illustrative anchor in calculations. All risk-dependent calculations in later parts are expressed as functions of equity and risk fraction with sensitivity across a range.

Universe symbols and timeframes remain to be derived per D14 in Part 3. Deployment topology remains to be derived per D15 in Part 4 after envelope comparison. Phase count and names remain to be derived per D16 in Part 4 with full deviation disclosure against owner vocabulary. Adaptation mechanisms remain to be evaluated per §3.1 item 12, with zero mechanisms acceptable if requirements justify that outcome.

### 4.4 Comparison criteria stated before candidate scoring

Criteria for consequential choices: satisfaction of hard constraints as pass or fail gates, risk-control integrity and fail-closed behavior, statistical validity within admissible trial budget, realistic net-of-cost feasibility at small capital scale, operational feasibility on allowed infrastructure, resource use including storage and compute and network, verifiability and testability, maintainability and provenance, and reversibility cost. Hard constraints are not compensable by high aggregate scores.

### 4.5 Credible architectural directions without selection

Direction 1 — Minimal single-process modular monolith with polling ingestion, file-backed ledger, and in-process Telegram handler. Positive reason for consideration: smallest failure surface and lowest operational burden, directly responsive to small-team maintainability and to A8 resource constraints. Limitation to be tested: sustained runtime under Doze and App Standby, and recovery after process death.

Direction 2 — Modular monolith with separated logical responsibilities but single deployment unit, explicit risk authority process boundary in logic, deterministic client identifiers, bounded retry with reconciliation. Positive reason: preserves separation of trust and failure domains without introducing distributed-system coupling. Limitation: still subject to handset continuous-runtime limits for Live operation.

Direction 3 — Hybrid with on-device development and research plus off-device assisted execution for Live, Telegram reached via feasible long polling or relay only where genuinely feasible within owner infrastructure. Positive reason: decouples envelope-heavy continuous execution from phone preservation preference. Limitation: secret handling, network topology, ownership cost, and A5 gating must be satisfied.

Minimal baseline for comparison: single-timeframe trend-following reference with identical risk controls, used as measuring stick for whether added complexity earns its place. No final architecture is selected in this checkpoint.

## 5. Decision record for Part 1

Catalog definition: decision identifiers DEC-001 through DEC-002 are defined in this table. Every later use points to this catalog and does not redefine them.

| ID | Decision | Positive reason grounded in requirements | Reversibility | Status with evidence |
|---|---|---|---|---|
| DEC-001 | Deliver complete design in 6 parts with scopes stated in D22 plan | Requirement for completeness D20 plus multi-message obligation D22: complete content cannot fit in one message, so planned incremental delivery is required to avoid truncation while preserving auditability | REVERSIBLE: message count and scope boundaries can be adjusted without rework to produced artifacts, by updating plan and cross-references | PASS for plan existence. Evidence pointer: Section D22 plan in this part with fit-check computation 32,000 × 6 = 192,000. Consequence if changed: cross-references and registry message references are updated |
| DEC-002 | Execute gates in dependency-derived order G0→G1→G2→G3→G4→G5→G6→G7→G8 with permitted interleaving of independent evidence inspections | Dependency-first ordering D11: prerequisites identified in Section 3 require this order. Following G-numbering without analysis would violate D11 | REVERSIBLE: order can be adjusted if new dependency evidence emerges, by recording deviation per §7.2 | PASS for analysis existence. Evidence pointer: adjacency list in Section 3. Consequence if violated: downstream verification would lack prerequisites and G8 acceptance could not be claimed |

No pause under §2.1.7 is triggered in Part 1. No pre-undeclared owner-level decision meeting all five pause conditions was encountered. Risk boundary is declared-unresolved, so continuation with parametric treatment applies. Delegated decisions on language and storage class are model decisions and must not be paused for.

## 6. Artifact registry

Catalog definition: artifact identifiers ART-001 through ART-006 are defined in this registry. Later citations point to this registry.

| Artifact ID | Name | Phase produced | Message reference | Status | Description |
|---|---|---|---|---|---|
| ART-001 | Part 1 capability, dependency, checkpoint | G0 and G1 | Part 1/6, Sections 1 through 4 | DELIVERED | Capability inventory, identifier bug report, DAG, dated checkpoint |
| ART-002 | Part 1 decision record | G1 | Part 1/6, Section 5 | DELIVERED | DEC-001 and DEC-002 with reversibility |
| ART-003 | Requirements register single table | G2 | Part 2/6 scheduled | DEFERRED with reason: requires Part 1 boundary as prerequisite, scheduled as next delivery | Single table with 11 fields per requirement and class definitions |
| ART-004 | Universe derivation and statistical methodology | G3 and G4 | Part 3/6 scheduled | DEFERRED with reason: requires requirements register, scheduled delivery | D14 steps, trial-budget recomputation, selection procedure |
| ART-005 | Architecture synthesis and Telegram and operations | G5 | Part 4/6 scheduled | DEFERRED with reason: requires selected options, scheduled delivery | Components, data, risk, order state machine, commands, recovery consistency table |
| ART-006 | Verification matrix and adversarial review and acceptance | G6 through G8 | Parts 5/6 and 6/6 scheduled | DEFERRED with reason: requires synthesized design, scheduled delivery | Matrix with row count equal to register row count, V-1 through V-12 table, completeness declaration |

Resumability statement: a fresh instance reading only Part 1 can determine completed work as ART-001 and ART-002, pending work as ART-003 through ART-006, unresolved decisions as risk boundary and universe and topology and phases, and next logical action as construction of the single requirements register in Part 2.

## 7. Self-verification for Part 1 — V-1 through V-7

| Check | Question answered | Result | Evidence pointer | Corrective action |
|---|---|---|---|---|
| V-1 | Does Part 1 satisfy D20 for its declared scope | PASS | Sections 1 through 6 present content, rationale, status, evidence pointer, consequence for each material item in scope | None |
| V-2 | Does Part 1 contain any D21-prohibited pattern | PASS on inspection: no compression claim, no summary substitution, no for-brevity language, no etc., no mid-sentence stop, no status-only entry | Full text of Part 1/6 searched for listed phrases | If later scan finds a phrase, affected paragraph will be rewritten |
| V-3 | Does numbering match the plan | PASS | Top of message states Part 1/6, plan states 6 parts | None |
| V-4 | Does cross-reference to prior and next parts match reality | PASS | Prior: none exists. Next: Part 2/6 requirements register as stated in registry ART-003 | None |
| V-5 | If final part, does completeness declaration exist | N/A with stated reason: this is not the final part, overall declaration is scheduled for Part 6/6 | D22 plan | None |
| V-6 | If final part, does declaration satisfy D20 D21 D22 | N/A with stated reason: this is not the final part | D22 plan | None |
| V-7 | Have all artifacts for this part been added to registry | PASS | ART-001 and ART-002 listed as DELIVERED, deferred artifacts listed with reason | None |

Checks V-8 through V-12 concern engagement completion and are scheduled for Part 6/6. They are not claimed as performed in Part 1.

Completeness test T-C1 through T-C5 applied to Part 1 scope: content is directly visible, rationale is directly visible, status labels are explicit, evidence pointers are directly visible, consequences are directly visible. No prohibited substitute of the form reference without content is used for Part 1 scope.

## 8. Part 1 completeness declaration for declared scope

Part 1/6 is complete for its declared scope. Content deferred: requirements register and class definitions deferred to Part 2/6 with reason stated in ART-003; universe derivation deferred to Part 3/6; architecture synthesis deferred to Part 4/6; verification and adversarial review deferred to Parts 5/6 and 6/6; overall completeness declaration deferred to Part 6/6. No content within Part 1 scope is deferred. No truncation occurred. Definitions for artifact and decision catalogs used in Part 1 are complete in Part 1. No identifier used in Part 1 is missing from its catalog.

## 9. Owner-facing progress note — یادداشت وضعیت

این پیام بخش نخست از شش بخش طراحی است و به زبان انگلیسی تدوین شده است. در این بخش، امکانات واقعی محیط اجرا، مرز طراحی بدون دسترسی به حساب، اشکالات شناسه‌ای متن راهنما، گراف وابستگی گیت‌ها، نقطه کنترل پیش از پژوهش با تاریخ ۲۰۲۶-۱۱-۰۳ به وقت UTC، تصمیم‌های مربوط به نحوه تحویل و ترتیب اجرا، و فهرست مصنوعات ارائه شد. معماری نهایی در این بخش انتخاب نشده است. مرز ریسک همچنان در انتظار تصمیم مالک باقی مانده است و همه محاسبات بعدی به صورت پارامتری ارائه می‌شوند. هیچ سفارش واقعی ثبت نشد و هیچ اعتبار یا کلیدی درخواست نشد. بخش دوم به ثبت یکپارچه الزامات و آموزش پارامتری ریسک اختصاص دارد.

**Next action:** proceed to Part 2/6 single requirements register with class definitions and parametric risk education, preserving all scope and limitations recorded in Part 1.


# Part 2/6 — Single Requirements Register (ART-003) + Parametric Risk Education

> **Part scope:** This message delivers **ART-003 only**.
> Part 1/6 delivered capability inventory, dependency DAG, checkpoint, DEC-001/DEC-002, registry skeleton.
> This Part 2/6 delivers the **single normative requirements register** and **parametric risk education** for the unresolved risk boundary.
> No architecture is selected. No implementation, deployment, account connection, credential request, order submission, or live-trading authorization is performed.
> All monetary quantities in **USDT**. Time in **UTC** with semantic role.

## 2.1 Requirement class definitions — normative

Five classes are used. Class controls change authority and verification burden.

**1. OWNER_HARD —** Owner-imposed hard constraint. Model must satisfy it. Model must not relax, reinterpret, or trade it off. Change requires explicit owner authorization plus material-contradiction record. Violation is fail-closed refusal.

**2. OWNER_PREFERENCE —** Owner-stated preference for direction. Model must respect intent but derives operationalization as DESIGN_JUDGMENT. If preference conflicts with feasibility, safety, or evidence, model records gap, preserves preference, and derives feasible compromise in stated compromise order.

**3. OWNER_ATTESTED —** Owner-supplied factual attestation about history or present state. Accepted as input for planning, not as proof of current external state, profitability, feasibility, or permission. Must be re-verified at runtime where it gates safety.

**4. DESIGN_JUDGMENT —** Matter delegated to model under A12. Model must derive from evidence, record rationale, evaluate alternatives, and make independently checkable. Owner does not select algorithms, infrastructure, model classes, parameters, or frameworks.

**5. OWNER_DECISION_PENDING —** Quantified decision intentionally left unresolved to avoid premature anchoring. Design proceeds parametrically. No default, provisional, illustrative, sanity, or anchor value may be adopted as hard, soft, or hidden constant.

**Interpretation rule:** Where a source contains both preference and judgment, e.g. A6 intraday intent vs. holding-duration policy, the register splits them: intent is OWNER_HARD or OWNER_PREFERENCE, operational definition is DESIGN_JUDGMENT.

## 2.2 Eleven-field schema — normative definition

Every requirement has exactly these eleven fields. The register in §2.3 is the single normative table. No second requirements table exists.

| # | Field | Meaning |
|---|---|---|
| F1 | Req ID | Stable identifier REQ-001… Unchanged across parts. |
| F2 | Requirement statement | Testable normative sentence. Uses shall/must/shall-not. |
| F3 | Class | One of §2.1 five classes. |
| F4 | Source / Provenance | A-label, C-label, prompt section, or derivation. SOURCE_VERIFIED only for supplied PROMPT.md text. |
| F5 | Rationale | Why it exists; what failure it prevents. |
| F6 | Parametric form / Acceptance criterion | Formula, threshold, enumerated set, or explicit pending marker. No hidden anchor. |
| F7 | Verification method | Inspection, analysis, demonstration, test, audit, or runtime interlock check. |
| F8 | Verifying artifact / Gate | ART or gate that checks it. |
| F9 | Phase applicability | Which lifecycle phases it governs. Research, Paper, Live, All. |
| F10 | Change control / Reversibility | REVERSIBLE with procedure, or IRREVERSIBLE with justification; who authorizes change. |
| F11 | Status | RATIFIED, PENDING_QUANTIFICATION, PROVISIONAL with reason, or DEFERRED_TO_ART. |

## 2.3 Single normative requirements register

The following is the complete register. It supersedes any informal list elsewhere.

| Req ID | Requirement statement | Class | Source / Provenance | Rationale | Parametric form / Acceptance criterion | Verification method | Verifying artifact / Gate | Phase applicability | Change control / Reversibility | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| REQ-001 | System shall treat Toobit futures / perpetual-futures as the sole live execution venue and shall not assume any other live venue. | OWNER_HARD | A1 | Prevents venue drift and unauthorized live routing. | LiveVenue = {Toobit-Perp}; other venues LiveAllowed = False. | Inspection of venue configuration and execution router. | ART-005, ART-006, Live gate | All; enforced at Live | REVERSIBLE only by explicit owner authorization with contradiction record. | RATIFIED |
| REQ-002 | System shall expose all runtime operator control, mode selection, configuration, alerts, acknowledgements, safety refusals, monitoring, and read-only review exclusively through one Telegram bot, with no parallel dashboard, app, second bot, or routine console. | OWNER_HARD | A2 | Preserves sole-interface constraint; prevents shadow control paths. | OperatorInterface = {TelegramBotSingleton}; ParallelRoutineInterfaceCount = 0. | Inspection + demonstration of interface inventory. | ART-005, ART-006 | All | REVERSIBLE only by owner. Emergency safety action without Telegram is not an interface. | RATIFIED |
| REQ-003 | System shall compute and record exclusively in UTC, and every timestamp shall carry a semantic role: venue event time, bar open time, bar close time, availability / knowability time, monotonic elapsed time, or server-anchored wall time. | OWNER_HARD | A3 | Prevents timezone, look-ahead, and elapsed-deadline errors. | Timezone = UTC; TimestampRole != Null; elapsed deadlines use monotonic clock; daily = UTC day, weekly = ISO-8601 UTC week unless justified. | Inspection of time handling + test with DST boundary. | ART-005, ART-006 | All | REVERSIBLE only by owner. | RATIFIED |
| REQ-004 | During this design engagement the system design shall not request or transmit secrets, connect to any account, call authenticated endpoints, alter permissions, access funds, or submit, cancel, or modify orders. | OWNER_HARD | A4 | Enforces design-only engagement boundary. | LiveActionCount_Engagement = 0; AuthenticatedCallCount_Engagement = 0. | Audit of engagement outputs. | ART-006, acceptance | Engagement | IRREVERSIBLE for engagement scope. | RATIFIED |
| REQ-005 | System shall use non-Toobit venue data only for research, backtest, and paper unless full unrestricted use for all activities is established, and only if source requires no registration / KYC or permits Iranian user under equivalent conditions to Toobit and is entirely free. | OWNER_HARD | A5 | Respects access, sanctions, licensing owner/legal boundary; prevents contaminated live data. | ResearchOnlyGate(Source) = True unless FullUseEstablished; prohibited source isolated from Live data and execution. | Inspection of data lineage + gate demonstration. | ART-004, ART-005, Live gate | Research, Paper, Live | REVERSIBLE only by owner/legal with documented establishment. | RATIFIED |
| REQ-006 | System shall operate with intraday intent and shall derive maximum holding-duration policy from strategy, market, funding, exits, risk, and validation, without inventing a fixed duration a priori. | OWNER_HARD intent + DESIGN_JUDGMENT policy | A6 | Preserves intent while forcing evidence-based duration limit. | Intent = Intraday; MaxHoldingDuration = Derive(...); no constant adopted without derivation. | Analysis of derivation record. | ART-004, ART-005 | All | Policy REVERSIBLE by re-derivation with rationale. | RATIFIED intent; PENDING_QUANTIFICATION policy |
| REQ-007 | System shall derive a broad but feasible symbol × timeframe universe, explaining separately which limitation constrains symbols and which constrains timeframes. | OWNER_PREFERENCE breadth + DESIGN_JUDGMENT derivation | A7, D14 | Prevents infeasible breadth and hidden breadth reduction. | Universe = Derive(Liquidity, Cost, Data, Compute, Statistics); SymbolAxisRationale != TimeframeAxisRationale. | Analysis + feasibility comparison. | ART-004 | Research, Paper, Live | REVERSIBLE by re-derivation. | PENDING_QUANTIFICATION |
| REQ-008 | System shall derive compute envelope first, then measure or bound POCO X6 capability, then match load to envelope, then record gap and compromise in order: all phases on phone, all except Live on phone, retain dev/training/calibration on phone and reduce breadth then depth then capability, else state redesign. | OWNER_PREFERENCE phone preservation + DESIGN_JUDGMENT topology | A8, D15 | Prevents phone-overload failure and silent capability loss. | Follow D15 Steps 1-4b; any sub-step deviation discloses (a) what, (b) why, (c) effect, (d) restoration. | Analysis + measurement plan + inspection. | ART-005 | All | REVERSIBLE by re-measurement. | RATIFIED process; PENDING_QUANTIFICATION values |
| REQ-009 | System shall assume no stable Telegram inbound, shall compare long polling vs webhook / relay only where genuinely feasible, and Telegram loss shall never release a risk limit, unblock an unsafe action, or present an uncertain outcome as confirmed. | OWNER_HARD reliability + DESIGN_JUDGMENT topology | A9 | Ensures fail-closed operation under operator unreachability. | TelegramAvailable = False is safe state; RiskLimitReleaseOnCommsLoss = False; uncertain stays uncertain. Open-position / pending-order behavior when unreachable defined. | Demonstration with comms-loss injection. | ART-005, ART-006 | Paper, Live | Reliability rule IRREVERSIBLE without owner; topology REVERSIBLE. | RATIFIED |
| REQ-010 | System shall treat owner-proposed training / calibration / paper / Live as intent categories, derive architectural phases by risk, provide Telegram Live / Paper selector without arbitrary wait or profit hurdle, and enforce six interlocks that refuse Live with explicit reason: data-validity, reconciliation exchange equals ledger, risk-limit, credential / permission, config-integrity, clock. | OWNER_PREFERENCE selector + OWNER_HARD interlocks + DESIGN_JUDGMENT phases | A10, D16 | Prevents waiting-period gatekeeping while preserving safety. | Interlock_i in {PASS, REFUSE with reason}; LiveAllowed = AND(Interlocks); no time or profit hurdle. | Demonstration of each interlock trip and selector. | ART-005, ART-006 | Live gate | Interlocks IRREVERSIBLE without owner; phases REVERSIBLE. | RATIFIED |
| REQ-011 | System shall treat ~200 USDT scale and below-500 USDT planning range as illustrative planning inputs, expressed parametrically, not as statements of live equity nor proof of feasibility or profitability. | OWNER_ATTESTED | A11, D17 | Prevents hard-coding a single capital assumption. | Equity = E parameter; planning illustrations use E in (0,500] USDT; no constant E embedded. | Inspection that no fixed equity constant exists. | ART-004, ART-005 | All | REVERSIBLE by owner update. | RATIFIED |
| REQ-012 | System shall derive architecture, method, features, parameters, optimizer, language, framework, runtime, and libraries as DESIGN_JUDGMENT, evaluate every adaptation concept as candidate idea with include / transform / combine / reject rationale, allow zero mechanisms if justified, and never allow any optimizer to relax a hard risk limit. | OWNER_HARD delegation | A12 | Maximizes capability without abdicating safety. | OptimizerAction ∩ Relax(HardRiskLimit) = Empty; each candidate has disposition + rationale. | Inspection of derivation + constraint test. | ART-005, ART-006 | All | REVERSIBLE by re-derivation. | RATIFIED |
| REQ-013 | System shall leave max drawdown, per-trade risk, leverage, and trial-budget quantities as OWNER_DECISION_PENDING parameters with full education per §2.4, and shall not adopt 15 percent, 20 percent, 5 percent, 10x, or 100 USDT entered as hard, provisional, sanity, illustrative, or hidden anchor. | OWNER_DECISION_PENDING | Risk boundary §3.3 | Prevents premature anchoring on mixed-quantity illustrations. | max_loss_per_trade = f(E,risk_fraction); drawdown = g(E,dd_fraction); leverage separate from loss budget; no anchor constant. | Inspection for anchor absence + education completeness. | ART-004, ART-006, acceptance | All | Set only by explicit owner decision after education. | PENDING_QUANTIFICATION |
| REQ-014 | System design process shall not re-ask answered information and shall not ask owner to select delegated algorithms, infrastructure, or model classes; it shall return only truly non-delegable decisions. | OWNER_HARD | A13 | Reduces burden and protects delegation. | QuestionAllowed only if NonDelegable = True and NotPreviouslyAnswered. | Audit of questions asked. | Acceptance | Engagement | REVERSIBLE by owner. | RATIFIED |
| REQ-015 | System shall treat 14 listed timeframes 1m to 1M as ceiling and 3d as UNSUPPORTED_CONFIRMED, deriving usable set within ceiling. | OWNER_ATTESTED + DESIGN_JUDGMENT | C1 | Prevents unsupported timeframe use. | UsableTimeframes ⊆ Ceiling14; 3d Allowed = False. | Inspection. | ART-004 | Research, Paper, Live | REVERSIBLE on new evidence. | RATIFIED |
| REQ-016 | System shall respect 3,500-candle cap per request, observed 1,774-bar 1d sample about 4.86 years, 58 combos 36 at cap, perpetual not spot lineage. | OWNER_ATTESTED | C2 | Bounds history depth and backtest horizon. | HistoryDepth = min(published, recomputed); perpetual lineage required. | Analysis of pagination and lineage. | ART-004 | Research | REVERSIBLE on re-measurement. | RATIFIED |
| REQ-017 | System shall apply conservative taker branch 0.06 percent while 0.05 percent vs 0.06 percent remains UNRESOLVED, until resolved with provenance. | DESIGN_JUDGMENT conservative branch | C6 | Prevents under-costing. | FeeTaker_Assumed = 0.06%; resolution requires sourced confirmation. | Inspection of cost model. | ART-004 | Research, Paper, Live | REVERSIBLE on resolution. | PROVISIONAL conservative branch |
| REQ-018 | System shall treat funding clamp minus 30.0000 bp observed as governing observation and ±24 bp reference as refuted for observed case. | OWNER_ATTESTED | C7 | Prevents wrong funding bound. | FundingClampLower ≤ -30.0000 bp in model where observed; no ±24 bp cap assumed. | Inspection. | ART-004 | Research, Paper, Live | REVERSIBLE on new observation. | RATIFIED observation |
| REQ-019 | System shall treat order-book depth snapshot as NON_REPRODUCIBLE and liquidity snapshot median 498,844 USDT with 134 symbols at or above 10M USDT as snapshot only, not as stable guarantee. | OWNER_ATTESTED | C8, C9 | Prevents sizing on ephemeral depth. | DepthUsableForSizing = False; liquidity filter re-validated at runtime. | Inspection + runtime re-validation. | ART-004, ART-005 | Research, Live gate | REVERSIBLE on new measurement. | RATIFIED |
| REQ-020 | System shall include cost-per-volatility 1.42 at 5m and 0.82 at 15m and maker-only floor at 15m and above as measurement-only inputs to timeframe feasibility, not as universal constants. | OWNER_ATTESTED | C10 | Prevents timeframe overreach net of cost. | NetEdge = GrossEdge - (Fee+Spread+Slippage+Funding); timeframe feasible only if NetEdge > 0 after costs. | Analysis. | ART-004 | Research | REVERSIBLE on re-measurement. | RATIFIED measurement |
| REQ-021 | System shall restrict clientOrderId to [A-Za-z0-9_-] and shall isolate markPrice vs klines.change conflict, using neither as trusted without resolution. | OWNER_ATTESTED + DESIGN_JUDGMENT | C11, C13 | Prevents order rejection and false signal. | IdCharset = ^[A-Za-z0-9_-]+$; conflicted fields Quarantined = True. | Test with invalid id + lineage inspection. | ART-005, ART-006 | All | REVERSIBLE on resolution. | RATIFIED |
| REQ-022 | System shall treat 3-day provisional outage assumption as PROVISIONAL and Class-A outage definition as undefined, requiring explicit outage handling without assuming duration. | DESIGN_JUDGMENT | C12 | Prevents outage under-design. | OutageDurationAssumed = PROVISIONAL; system safe under indefinite outage. | Demonstration with outage injection. | ART-005, ART-006 | Paper, Live | REVERSIBLE on definition. | PROVISIONAL |
| REQ-023 | System shall record POCO X6 snapshot Snapdragon 7s Gen 2 up to 2.4 GHz, 12 GB plus 8 GB extension, Android 16, 256 GB total 56 GB free snapshot, charging not equal App Standby exemption, sustained runtime NOT MEASURED, and shall not claim sustained capability without measurement. | OWNER_ATTESTED + DESIGN_JUDGMENT | C14, C15, C16 | Prevents phone-capability overclaim. | SustainedCapability = NOT_MEASURED; no sustained claim until bounded. | Inspection + measurement plan. | ART-005 | All | REVERSIBLE on measurement. | RATIFIED snapshot; PENDING measurement |
| REQ-024 | System shall preserve lineage for cross-venue history to 2019-12-16 1H/5m, transfer proxy median 0.56 bp correlation 0.999755 defensible at 1h/4h not 5m, and 1.25 GB per 3,500×14×10 symbols measurement for BTC, ETH, SOL, BNB, XRP, ADA, DOGE, AVAX, LINK, LTC. | OWNER_ATTESTED | C17, C18, C19 | Prevents look-ahead and storage under-design. | ProxyAllowed(1h,4h) = True with lineage; ProxyAllowed(5m) = False; storage budgeted. | Analysis + lineage audit. | ART-004 | Research | REVERSIBLE on new evidence. | RATIFIED |
| REQ-025 | System shall enforce statistical validity: DSR 1.5e-2 at N=100 reference, MinTRL 19.54 years distinct from MinBTL, N_max_effective = min(published, recomputed) with recomputed governing if greater than 2x, 10-20 at 4h PROVISIONAL, 1d thousands before correction, full grid at or below 12h inadmissible. | OWNER_ATTESTED + DESIGN_JUDGMENT | C20, C21, C22, C23, C24 | Prevents multiple-testing and horizon overclaim. | Backtest passes only if DeflatedSharpe, MinBTL/MinTRL, N_max_effective satisfied; ≤12h full-grid search Rejected. | Statistical analysis. | ART-004, ART-006 | Research | Thresholds REVERSIBLE only with method rationale. | RATIFIED method; PROVISIONAL 10-20 at 4h |
| REQ-026 | System shall treat 149-record census 134 LIVE_PASS / 10 LIVE_PARTIAL / 3 UNSUPPORTED_CONFIRMED / 2 DOC_CONFLICT with arithmetic 134+10+3+2=149 as snapshot, authenticated read-only not executed, 544×14 not exhaustive. | OWNER_ATTESTED | C25 | Prevents universe overclaim. | Universe ⊆ RevalidatedSnapshot; no claim of exhaustiveness. Arithmetic verified 134+10=144, 144+3=147, 147+2=149. | Inspection + re-validation. | ART-004 | Research, Live gate | REVERSIBLE on re-census. | RATIFIED snapshot |
| REQ-027 | System shall quarantine unresolved venue mechanics: 13-tier BTC ladder down to 1.0x with max permitted UNRESOLVED, X-Api-Limit headers absent, -1007 TIMEOUT ambiguous vs -1003 rate-limit, historical open interest UNRESOLVED, and apply fail-closed conservative branch in each case. | OWNER_ATTESTED + DESIGN_JUDGMENT | C3, C4, C5, C26 | Prevents live failure on ambiguous limits. | AmbiguousError = FailClosed; max leverage unresolved means no max assumed; OI-dependent logic Disabled until resolved. | Demonstration with fault injection. | ART-005, ART-006 | Live gate | REVERSIBLE on resolution with provenance. | PROVISIONAL conservative branches |
| REQ-028 | System design shall remain design-only with evidence-first provenance, dependency-first ordering, completeness accounting, and independent checkability; no profitability guarantee is offered or implied. | OWNER_HARD | §2.1, D11, D13, D19, D20 | Preserves engagement integrity and verifiability. | Every claim has provenance; every derivation shows dependency; completeness equation balanced in Part 6/6. | Self-audit V-1 to V-12. | ART-006 | Engagement, All | IRREVERSIBLE for engagement. | RATIFIED |

**Register completeness note:** 28 rows above constitute the single register. No requirement is stated elsewhere normatively. Future parts trace to these IDs; new IDs if needed will extend, never duplicate.

## 2.4 Parametric risk education — normative for PENDING boundary

This section does not set risk. It enables a future non-delegable owner decision for REQ-013. Read all subsections before any decision. Figures below are **arithmetic illustrations, not prescriptions, not trial budgets, not trading advice**.

### 2.4.1 Quantities that must never be mixed

Six distinct quantities:

1. **Equity E** in USDT: account equity available. Planning illustrations use E parameter, e.g. E=200 USDT, with range (0,500] USDT per A11.
2. **Notional N** in USDT: position economic size. N = Quantity × Price for linear perpetual.
3. **Margin M** in USDT: collateral locked. M = N / Leverage.
4. **Quantity Q**: contracts or coins. Q = N / Price.
5. **Stop distance d**: price distance from entry to nominal stop, in price units or percent.
6. **Loss budget B** in USDT: maximum acceptable net loss for one trade. B = E × risk_fraction.

Failure mode to avoid: treating 100 USDT entered as simultaneously notional, margin, and loss budget. It can be only one at a time; the other two follow from leverage, price, and stop distance.

### 2.4.2 Core parametric formulas

All fees, funding, spread, slippage in USDT unless noted as rate.

```
B_per_trade = E × r            where r = risk_fraction per trade
B_daily     = E × r_daily      where r_daily = daily loss fraction
N           = Q × P_entry
M           = N / L            where L = leverage
GrossLoss_at_stop = Q × d = N × (d / P_entry)
NetLoss ≈ GrossLoss + FeeOpen + FeeClose + FundingAccrued + SpreadCost + Slippage
Fee ≈ N × fee_rate  per fill leg; round-trip ≈ 2 × N × fee_rate for full close
LiveAllowed requires NetLoss_budget_check: EstimatedNetLoss ≤ B_per_trade
AggregateConcurrentRisk = Σ EstimatedNetLoss_open + Σ EstimatedNetLoss_pending
Drawdown_t = (PeakEquity_to_date − Equity_t) / PeakEquity_to_date
```

Acceptance uses **net loss**, never gross alone, never nominal stop distance alone.

### 2.4.3 Leverage does not multiply dollar P&L for fixed notional

For fixed N and fixed price move ΔP, dollar P&L = Q × ΔP = N × (ΔP / P). Leverage L changes M and liquidation distance, not dollar P&L.

Worked illustration with E=200 USDT, BTC price 90,000 USDT, N=100 USDT:

* Q = 100 / 90,000 = 0.001111… BTC.
* 1 percent adverse move: d/P = 0.01. GrossLoss = 100 × 0.01 = 1.00 USDT, at 1x and at 10x identically.
* Margin at 1x: M=100 USDT. Margin at 10x: M=10 USDT.
* Difference: at 10x the same 1.00 USDT loss is 10 percent of margin vs 1 percent at 1x; liquidation price is closer; fee on notional is identical; funding on notional is identical.

Conclusion: leverage controls capital efficiency and liquidation proximity, not dollar edge. Raising leverage to increase dollar profit without increasing N is a category error.

### 2.4.4 Distinguishing 100 USDT notional vs margin vs 10 USDT budget

Take E=200 USDT and r=5 percent so B=10 USDT. Three mutually exclusive meanings of 100 USDT:

**Case A — 100 USDT is notional N:** N=100. At fee 0.06 percent per leg, round-trip fee ≈ 0.12 USDT. A 9 percent adverse move gives gross 9 USDT, net about 9.12 USDT plus spread/slippage/funding, within 10 USDT budget before slippage. Liquidation distance depends on L.

**Case B — 100 USDT is margin M at 10x:** Then N = M × L = 1,000 USDT. Q is 10× Case A. A 1 percent adverse move gives gross 10 USDT, net exceeds 10 USDT after fees about 1.20 USDT round-trip. Same 100 USDT label produces 10× loss speed. This is why margin and notional must not be conflated.

**Case C — 10 USDT is loss budget B:** Then position must be sized so EstimatedNetLoss ≤ 10 USDT. With N=100 and 0.06 percent taker, usable gross room ≈ 10 − 0.12 − spread − slippage − funding. Nominal stop must be placed so Q × d ≤ usable room, with explicit slippage add-on.

Rule: state all three numbers for every sizing example: N, M with L, and B with E and r.

### 2.4.5 Sensitivity table — per-trade budget as function of E and r

B = E × r. Exact arithmetic, not backtest, not prescription.

| Equity E (USDT) | r=0.5% | r=1% | r=2% | r=5% | r=10% |
|---|---|---|---|---|---|
| 100 | 0.50 | 1.00 | 2.00 | 5.00 | 10.00 |
| 200 | 1.00 | 2.00 | 4.00 | 10.00 | 20.00 |
| 300 | 1.50 | 3.00 | 6.00 | 15.00 | 30.00 |
| 500 | 2.50 | 5.00 | 10.00 | 25.00 | 50.00 |

Reading: at E=200 USDT, r=1 percent allows 2.00 USDT net loss per trade. After taker round-trip on N=100 USDT about 0.12 USDT, more than 5 percent of budget is consumed by fees alone before spread, slippage, funding. At r=0.5 percent the fee share doubles. Small budgets demand small N, maker discipline where feasible per REQ-020, or no trade.

No row is endorsed. Owner will select r only after Parts 3-5 show net-of-cost feasibility.

### 2.4.6 Gross P&L vs notional and price movement

Gross P&L = N × price_return. Examples with N=100 USDT:

* +0.5 percent move: +0.50 USDT gross.
* +2 percent move: +2.00 USDT gross.
* −2 percent move: −2.00 USDT gross.

Net subtracts all costs. With taker round-trip 0.12 USDT on N=100, a +0.5 percent winner nets about +0.38 USDT before spread/slippage/funding. Cost-per-volatility in REQ-020 states the same point statistically: at 5m cost consumes 1.42× typical volatility unit; at 15m 0.82×. Higher-timeframe moves leave more net room, which is why timeframe feasibility in Part 3/6 must be net-of-cost.

### 2.4.7 Fees, funding, spread, slippage, liquidation — why nominal stop is not a cap

Nominal stop price is an intent, not a guarantee:

* **Fees:** charged on N per fill, both entry and exit, including stop fill.
* **Funding:** accrues while holding; sign and clamp per REQ-018; intraday holding does not eliminate it.
* **Spread:** entry and stop fill cross the book; snapshot depth per REQ-019 is non-reproducible.
* **Slippage:** stop becomes market or triggered limit under fast moves; fill may be worse than trigger.
* **Gaps / halts / outage:** per REQ-022 price may re-open beyond stop; system must remain safe under indefinite outage.
* **Liquidation:** if maintenance margin is breached before stop fills, venue closes position at liquidation price, potentially worse than stop, plus liquidation fee if applicable.

Sizing must therefore add explicit buffers: EstimatedNetLoss = GrossAtStop + Fees + FundingEstimate + SpreadEstimate + SlippageAllowance. Live interlock per REQ-010 refuses trading if inputs are stale.

### 2.4.8 Aggregate concurrent risk and daily loss

Per-trade budget does not bound portfolio loss. Two additional parameters are required, both PENDING:

```
AggregateCap = E × r_agg     e.g. total estimated net loss across all open + pending
DailyCap     = E × r_daily   e.g. halt trading if day net loss ≤ −DailyCap
```

Example arithmetic with E=200 USDT: three concurrent positions each with EstimatedNetLoss 4 USDT give aggregate 12 USDT even though each trade respects B=4 USDT. Without r_agg and r_daily, concurrent fills and repeated entries can bypass per-trade intent. Part 4/6 will implement counters that block new entries when AggregateCap or DailyCap would be breached, fail-closed on uncertain state.

### 2.4.9 Peak-to-trough drawdown

Drawdown is path-dependent, not per-trade. Sequence matters.

Illustration with E start 200 USDT, no deposits:

* Peak 200, trough 190: drawdown = (200−190)/200 = 5 percent = 10 USDT.
* Peak 220 after recovery, then trough 187: drawdown = (220−187)/220 = 15 percent = 33 USDT, even though equity is only 13 USDT below start.

Max drawdown for a period is the largest such peak-to-trough fraction. Setting a max-drawdown fraction without specifying measurement (closed-equity vs including unrealized, fees-inclusive, funding-inclusive, window, halt action) is unenforceable. Part 4/6 will define: equity includes unrealized net of estimated close costs, measured tick-bar close in UTC with role tags per REQ-003, halt on breach, explicit re-arm procedure via Telegram with authentication.

No 15 percent or 20 percent value is adopted here.

### 2.4.10 What remains PENDING and what happens next

PENDING: r per trade, r_agg, r_daily, max-drawdown fraction and window, leverage ceiling, N ceiling, holding-duration ceiling. Part 3/6 will show which (E,r) cells survive net-of-cost and statistical validity per REQ-020 and REQ-025, without recommending a cell. Part 4/6 will implement them as enforced parameters with fail-closed interlocks per REQ-010. Final acceptance will require explicit owner decision; silence leaves them PENDING and Live refused.

---

### Artifact update

* **ART-003 Single Requirements Register: DELIVERED this Part 2/6 §2.3 + education §2.4.**
* ART-001, ART-002 remain as Part 1/6. ART-004, ART-005, ART-006 deferred to Parts 3-6/6 with reasons: universe/statistics need register as input; synthesis needs register + universe; verification needs synthesis.
* DEC-001/DEC-002 unchanged. No new decision required for register form; if owner rejects 11-field schema, new DEC will be recorded.

### Part 2/6 completeness declaration

Part 2/6 complete for declared scope: 28-row single table with eleven fields each, class definitions, parametric risk education with formulas, worked notional/margin/budget distinction, leverage clarification, sensitivity arithmetic, cost and drawdown treatment, no anchor adopted, no architecture selected, no live action. Deferred items listed above with dependency reasons. No truncation.

*یادداشت فارسی مالک — بخش ۲ از ۶:*
*این بخش جدول یکتای الزامات (۲۸ ردیف با ۱۱ ستون) و آموزش پارامتریک ریسک را تحویل داد. هیچ سقف ریسک، لوریج یا دراودانی انتخاب یا توصیه نشد؛ همه به‌صورت پارامتریک E و r باقی ماند. تفاوت نوشنال، مارجین و بودجه ضرر با مثال ۱۰۰ و ۱۰ تتر توضیح داده شد. معماری نهایی انتخاب نشد و هیچ اتصال، سفارش یا اقدام لایو انجام نشد. ادامه: بخش ۳ از ۶ — مشتقات یونیورس و روش آماری.*


# Part 3/6 — Universe Derivation + Statistical Methodology + Trial-Budget Parametrics (ART-004)

> **Part scope:** This message delivers **ART-004 only**.
> Part 1/6: capability, DAG, checkpoint, DEC-001/DEC-002.
> Part 2/6: ART-003 single register REQ-001 to REQ-028 + parametric risk education.
> This Part 3/6 derives symbol × timeframe universe per D14, normative statistical methodology, and parametric trial-budget. No final architecture selected. No synthesis per §9. No implementation, deployment, account connection, credential request, order action, or live authorization.
> All monetary in **USDT**. All time in **UTC** with semantic role.

## 3.1 Derivation order and method

Dependency: REQ-007, REQ-015 to REQ-016, REQ-019 to REQ-020, REQ-024 to REQ-026 require G2 register before G3 universe before G4 synthesis. This part consumes ART-003 and C1-C26, produces input to ART-005 envelope-first D15 and risk phases D16.

Positive derivation D13 applied: each exclusion states governing evidence, not preference. Evidence-first: every bound cites C-label or REQ. No fixed holding duration invented per REQ-006. No risk anchor adopted per REQ-013.

Comparison criteria fixed before scoring, carried from Part 1/6: (i) hard-gate compliance, (ii) risk integrity fail-closed, (iii) statistical validity, (iv) net-of-cost small-capital feasibility, (v) operational feasibility under A9-A10, (vi) resource use, (vii) verifiability and provenance, (viii) reversibility.

## 3.2 Symbol axis — which limitations constrain symbols

Symbol breadth is constrained by **liquidity snapshot, listing census, per-symbol leverage ambiguity, storage/compute, and lineage**. Timeframe cost and horizon do not select symbols.

**Census gate C25:** 149 records = 134 LIVE_PASS + 10 LIVE_PARTIAL + 3 UNSUPPORTED_CONFIRMED + 2 DOC_CONFLICT. Verified 134+10=144, 144+3=147, 147+2=149. Rule: Live candidate ⊆ LIVE_PASS only. LIVE_PARTIAL allowed research/paper only with explicit limitation tag. UNSUPPORTED_CONFIRMED excluded everywhere. DOC_CONFLICT quarantined per REQ-027 until sourced resolution.

**Liquidity snapshot C9 + depth C8:** Median 498,844 USDT, 134 symbols ≥10M USDT snapshot. Depth BTC 90.6M one-sided / 92.7M other is NON_REPRODUCIBLE. Rule: snapshot never sizes positions. Symbol inclusion requires re-validation at runtime. Derived parametric filter:

```
CandidateSymbol(s) = LIVE_PASS(s) AND VolumeRevalidated(s, lookback, min_notional) AND SpreadBounded(s)
LiveTradable(s,t) = CandidateSymbol(s) AND DataValid(t) AND LeverageDiscovered(s,t) AND RiskInterlocksPass(t)
```

Initial candidate set is the C19 measurement set where storage measured: BTC, ETH, SOL, BNB, XRP, ADA, DOGE, AVAX, LINK, LTC. Expansion toward 134 only after re-validation and envelope match in ART-005. No claim of exhaustiveness: 544×14 not exhaustive per C25.

**Leverage ladder C3:** 13-tier BTC ladder down to 1.0x observed, max permitted UNRESOLVED. Rule: no leverage assumed for any symbol. Each symbol requires discovered ladder at runtime; missing ladder = fail-closed, no position. This constrains symbols individually, not timeframes.

**Storage C19:** 1.25 GB per 3,500×14×10 symbols for the 10-symbol set. That is ~125 MB per symbol for 14 timeframes at full depth. Linear extrapolation: 134 symbols × 14 timeframes ≈ 16.75 GB plus indexes, calibration outputs, logs. Phone snapshot 256 GB total 56 GB free per C14, sustained NOT MEASURED per C16. Symbol breadth therefore directly consumes envelope; full 134×14 retained on phone without reduction is not assumed feasible. Envelope match deferred to ART-005 per D15, but universe must offer reducible breadth first.

**Lineage C17-C18:** Cross-venue history to 2019-12-16 at 1H/5m exists. Transfer proxy median 0.56 bp, correlation 0.999755, defensible at 1h/4h, not at 5m, with lineage required. Symbols with short Toobit perpetual history may use proxy only at 1h/4h for research calibration, tagged `PROXY_LINEAGE`, never as Live price, never at 5m or below. A5 gate applies: proxy source must satisfy no-registration/KYC or equivalent Iranian-user conditions to Toobit, entirely free, research/backtest/paper only unless full use established.

**OI C26:** Historical open interest UNRESOLVED. Any OI-dependent filter or signal is Disabled until resolved. Symbols are not ranked by OI.

Result for symbols: breadth preference A7 preserved as expandable candidate pool, feasibility enforced by per-symbol re-validation and envelope.

## 3.3 Timeframe axis — which limitations constrain timeframes

Timeframe depth is constrained by **cost-per-volatility, history cap, statistical horizon, proxy validity, funding, and intraday intent**. Liquidity median does not select timeframes.

**Ceiling C1:** Usable ⊆ {1m,3m,5m,15m,30m,1h,2h,4h,6h,8h,12h,1d,1w,1M}. 3d UNSUPPORTED_CONFIRMED excluded. REQ-015.

**History cap C2:** 3,500 candles per request. Observed 1d 1,774 bars ≈4.86 yr implies listing bound, not cap bound, at 1d. 58 combos, 36 reached cap implies pagination mandatory below 1d. Calendar horizon per full pull without pagination: 1m ≈2.43 days, 5m ≈12.15 days, 15m ≈36.45 days, 1h ≈145.8 days, 4h ≈583 days, 1d ≈9.58 yr theoretical. Lower timeframes give many bars fast but short calendar coverage and high turnover; higher timeframes give calendar coverage but small N. Perpetual lineage required, spot lineage rejected.

**Cost C10:** Cost-per-vol 1.42 at 5m, 0.82 at 15m, maker-only floor 15m+. Measurement-only, not constant, but direction is governing: taker execution at 5m and below consumes more than one volatility unit per round-trip for typical moves. Small E per REQ-011 with conservative taker 0.06% per REQ-017 leaves no net room at 1m/3m/5m for trend-following holds. NetEdge rule:

```
NetEdge = GrossEdge − (FeeOpen+FeeClose+Spread+Slippage+FundingAccrued)
Feasible(tf) requires E[NetEdge|tf, E, N] > 0 after buffers, not GrossEdge > 0.
```

**Statistics C20-C24:** DSR reference 1.5e-2 at N=100, MinTRL 19.54 yr distinct from MinBTL, N_max_effective=min(published,recomputed) with recomputed governing if ratio >2x, 10-20 trials at 4h PROVISIONAL, 1d thousands before correction, full grid ≤12h inadmissible. Consequence: exhaustive search at or below 12h is rejected. Low-timeframe mining without pre-registration exhausts N_max_effective immediately. MinTRL 19.54 yr cannot be met by any perpetual history to 2019; live track-record significance within engagement is therefore infeasible. Design must rely on MinBTL + deflated metrics + out-of-sample + paper, with explicit horizon gap disclosed, never claim live significance prematurely.

**Proxy C18:** 5m proxy rejected. 1h/4h proxy allowed with lineage. Timeframes ≤15m cannot be extended by proxy; N bounded by Toobit listing alone.

**Funding C7:** Clamp −30.0000 bp observed governs; ±24 bp refuted for observed case. Holding across funding timestamps accrues cost. Intraday intent A6 plus funding plus exits plus risk will derive MaxHoldingDuration in ART-005; no fixed duration invented here. Timeframes implying multi-day holds (1d/1w/1M execution) conflict with intraday intent and are context-only.

**UTC roles REQ-003:** Every bar carries open time, close time, availability/knowability time. Lower-timeframe signals must shift by knowability, not close time. Daily = UTC day, weekly = ISO-8601 UTC week.

## 3.4 Independent options including baseline

Four independent universe directions. No synthesis yet.

**OP-U0 Baseline — single-symbol single-execution trend.** BTC only, execution 1h, context 4h+1d, no proxy, 1x assumed until ladder discovered, taker-costed. Minimal storage, minimal trials, maximal verifiability. Anchor for comparison.

**OP-U1 Focused intraday mid-timeframe multi-symbol.** Symbols: C19 ten-symbol set expandable subject to re-validation. Execution: 15m,1h,4h. Context: 1d. Optional conditional: 30m,2h only if N_max permits without new search. Costing taker 0.06% conservative, maker where 15m+ floor evidence holds. Proxy 1h/4h with lineage for calibration only.

**OP-U2 Broad low-timeframe scalping.** Symbols 30-134, execution 1m/3m/5m/15m. High turnover, maker-taker mix assumed. Tests breadth hypothesis at finest granularity.

**OP-U3 Daily positional.** Execution 1d/12h, context 1w/1M, holds days-weeks. Negative control for intraday intent.

## 3.5 Feasibility comparison

| Criterion | OP-U0 Baseline | OP-U1 Focused mid-TF | OP-U2 Low-TF broad | OP-U3 Daily |
|---|---|---|---|---|
| Hard gates A1,A5,C1 | PASS: Toobit-perp, no proxy live, 3d excluded | PASS if proxy gated to research/paper | CONDITIONAL: 5m proxy must be cut; else FAIL | FAIL live: violates A6 intraday intent |
| Risk fail-closed A9-A10 | PASS: small state, interlocks trivially enforceable | PASS: aggregate/daily caps enforceable over 10 symbols | FAIL at scale: concurrent aggregate across 134 with uncertain fills unmanageable on phone without reduction | PASS technically but irrelevant live |
| Statistical validity | PASS as baseline: few trials, N_max respected, MinBTL checkable at 1h/4h | CONDITIONAL PASS: only with pre-registered hypotheses, ≤10-20 trials at 4h PROVISIONAL, no ≤12h grid | FAIL: full grid ≤12h inadmissible per C24, N_max exhausted, MinBTL unmet at 1m-5m net-of-cost | FAIL within engagement: 1d thousands before correction, MinTRL gap largest |
| Net-of-cost small E | PASS narrow: 1h costs leave room for larger moves | PASS selective: 15m boundary, 1h/4h feasible if N sized to B=E×r | FAIL taker: 1.42 cost-per-vol at 5m, fee share of B prohibitive at E≤500 | PASS per-trade but funding+overnight gap vs intraday |
| Operational + Telegram loss | PASS: single position, safe-park on unreachable defined | PASS: defined safe-park, no limit release on comms loss | FAIL: many open/pending when unreachable, reconciliation load exceeds phone timely bound | FAIL intent, otherwise PASS |
| Resource C19/C14-C16 | PASS: <500 MB | PASS with budget: ~1.25 GB for 10×14 plus outputs, reducible | FAIL as-stated: ~16.75 GB + compute for 134×14, sustained NOT MEASURED | PASS small |
| Verifiability/provenance | PASS highest | PASS with lineage tags | FAIL: lineage × breadth unmanageable | PASS |
| Reversibility | REVERSIBLE | REVERSIBLE expand/contract | REVERSIBLE only by major reduction | REVERSIBLE but excluded live |

Scoring done after criteria stated. No hidden weighting. OP-U0 retained in all cases as comparison anchor.

## 3.6 Derived feasible universe — interim, pending ART-005

No final architecture selected. Interim derivation for synthesis input:

**Symbols:** Start `S0={BTC,ETH,SOL,BNB,XRP,ADA,DOGE,AVAX,LINK,LTC}`. Expandable to `S1⊆LIVE_PASS∩≥10M-revalidated` up to 134 only after D15 envelope match and runtime liquidity re-validation. LIVE_PARTIAL research-only. No OI ranking. Per-symbol ladder discovery mandatory.

**Timeframes:**

| Timeframe | Role | Verdict | Governing limitation |
|---|---|---|---|
| 1m,3m,5m | execution | EXCLUDED | Cost C10 + stats C24 + no proxy C18 + fee share of small B |
| 15m | execution | INCLUDED boundary | Maker-only floor C10; taker must still pass NetEdge |
| 30m,2h | execution | CONDITIONAL only | Allowed only without new search consuming N_max; else excluded |
| 1h,4h | execution core | INCLUDED | Best balance horizon/cost/proxy/MinBTL |
| 6h,8h,12h | execution | EXCLUDED | Low marginal independence vs 4h/1d, N small, grid inadmissible |
| 1d | context only | INCLUDED | Calendar context, not holding basis; 1,774-bar bound C2 |
| 1w,1M | context only | INCLUDED optional | Regime context, never execution |
| 3d | anywhere | EXCLUDED | UNSUPPORTED_CONFIRMED C1 |

**Holding:** MaxHoldingDuration remains PENDING_QUANTIFICATION per REQ-006, to be derived in ART-005 from strategy exits, funding C7, cost C10, risk caps, validation. Intraday intent enforced: context timeframes never justify overnight hold.

DEC-003 recorded: adopt OP-U0 as permanent baseline and OP-U1 family as sole live-candidate input to ART-005; OP-U2/OP-U3 rejected for live. REVERSIBLE on new evidence with re-derivation. Rationale: only OP-U0/U1 pass all hard gates with checkable statistics and phone-bounded storage.

## 3.7 Statistical methodology — normative

Applies to Research and Paper. Live has no significance claim until MinTRL met.

**3.7.1 Lineage and knowability.** Each bar stores venue event time, bar open, bar close, availability time, server-anchored wall time for ordering, monotonic elapsed for deadlines. Signal at bar close `c` usable only at `availability(c)+latency_buffer`. Proxy bars tagged `PROXY_LINEAGE(source, window, median_bp, correlation)` and excluded from Live data and execution per REQ-005. Purge + embargo: training/validation split by UTC time with embargo ≥ MaxHoldingDuration + funding interval + latency, preventing leakage across adjacent bars. Walk-forward only; no shuffled k-fold on time series.

**3.7.2 Multiple testing.** All hypotheses pre-registered with trial count. Effective trials `N_eff = min(published_count, recomputed_count)`; if ratio >2x, recomputed governs and discrepancy investigated per C22. Deflated Sharpe required: reported Sharpe must exceed expected maximum under null given N_eff and return skewness/kurtosis; reference DSR 1.5e-2 at N=100 illustrates how easily N=100 spurious significance arises, not a pass threshold. MinBTL computed for required backtest length at each timeframe; MinTRL 19.54 yr tracked separately as live-horizon gap. Pass requires DeflatedSharpe>threshold with method rationale + MinBTL satisfied + N_eff respected. 10-20 trials at 4h remains PROVISIONAL per C23; 1d thousands before correction means 1d mining without correction is rejected. Full-grid search ≤12h rejected per C24; only pre-registered sparse hypotheses allowed there.

Pseudocode permitted design-only:

```
for hypothesis h in preregistered_set:
  assert N_eff(h) <= N_max_effective
  bt = backtest(h, data_to_availability, costs=conservative_taker_0.06pct+spread+slippage+funding)
  d Sharpe_deflated = deflate(bt.sharpe, N_eff, skew, kurtosis)
  require Sharpe_deflated > threshold_with_rationale AND backtest_years >= MinBTL(tf)
  require out_of_sample_confirm AND paper_confirm
  else reject h, increment trial count, no live promotion
```

Thresholds REVERSIBLE only with method rationale per REQ-025. No profitability guarantee.

**3.7.3 Net-of-cost acceptance.** Gross edge insufficient. Acceptance uses conservative taker 0.06% per REQ-017 until resolved, plus spread estimate, slippage allowance, funding per REQ-018, with nominal stop never treated as cap per §2.4.7. Timeframe feasible only if NetEdge>0 across sensitivity E∈(0,500] and r grid without anchoring.

**3.7.4 Non-stationarity.** Parameters re-estimated on rolling UTC windows; regime break triggers re-validation, not auto-promotion. Cross-venue proxy never validates Toobit microstructure below 1h.

DEC-004 recorded: adopt deflated-Sharpe + MinBTL/MinTRL + N_max_effective + embargo walk-forward as normative validation. REVERSIBLE only with alternative method of equal rigor. Rationale: prevents multiple-testing and look-ahead failures observed in C20-C24.

## 3.8 Trial-budget parametrics per §5.4/§8.4

Two budgets, both parametric, both recomputed per cell. Any fixed figure below is PROVISIONAL illustration with formula, not a prescription, not trading advice.

**Statistical trial budget:** `N_max_effective(tf, horizon) = min(published_allowance, recomputed_from_horizon_and_df)`. Example PROVISIONAL: at 4h, 10-20 trials within available Toobit history; at 1d, thousands nominal but collapses after correction; ≤12h full grid inadmissible. Recompute per hypothesis set; exceeding budget rejects further search.

**Monetary paper-trial budget:** Calibration/paper loss cap expressed as function of E and r, never as fixed USDT:

```
B_trade = E × r
B_paper_total = E × r_paper_total    PENDING, e.g. bounded fraction of E
MaxPaperTrades ≈ floor(B_paper_total / (E[risk_per_paper_trade] + expected_cost_per_trade))
HaltPaper when EquityPaper ≤ E − B_paper_total
```

PROVISIONAL illustration with recomputation shown, E=200 USDT, conservative taker 0.06% on N=100 USDT → round-trip ≈0.12 USDT before spread/slippage/funding:

| r per paper trade | B_trade (USDT) | Fee share on N=100 | Room left before spread/slip |
|---|---|---|---|
| 0.5% | 1.00 | 0.12 =12% | 0.88 minus spread/slip/funding |
| 1% | 2.00 | 0.12 =6% | 1.88 minus spread/slip/funding |
| 2% | 4.00 | 0.12 =3% | 3.88 minus spread/slip/funding |

No cell endorsed. Owner selects r only after Parts 4-5 show enforcement. Live remains refused while PENDING per REQ-010/REQ-013. Each cell must be recomputed for its own N, fee, spread, slippage, funding; copying a cell value to another cell without recomputation is non-compliant.

## 3.9 Traceability

REQ-007 derived here. REQ-015,016,017,018,019,020,024,025,026 consumed. REQ-003,005,006,010,011,013 preserved. C-labels used: C1,C2,C7,C8,C9,C10,C14,C16,C17,C18,C19,C20,C21,C22,C23,C24,C25. Quarantined: C3,C4,C5,C11,C13,C26 per REQ-021/027, enforced fail-closed in ART-005.

## Artifact, verification, completeness

* **ART-004 DELIVERED this Part 3/6 §§3.2-3.8.** ART-001,002,003 remain delivered. ART-005 synthesis + Telegram + operations deferred to Part 4/6. ART-006 verification + adversarial + acceptance deferred to Parts 5-6/6 with reasons: needs synthesis as input; matrix row count must equal 28.
* Interim checks: register trace complete, no anchor adopted, venue/interface/UTC/interlock constraints preserved, 3d excluded, proxy gated, OI disabled, depth not used for sizing, conservative fee applied. V-1 to V-7 remain PASS for delivered scope; V-8 to V-12 scheduled Part 6/6.
* **Part 3/6 complete** for declared scope: symbol/timeframe axes separated, four options with baseline compared on pre-stated criteria, interim feasible set OP-U0+OP-U1 with per-TF verdicts, normative statistics with embargo and deflation, parametric trial-budgets with PROVISIONAL recomputed illustration, DEC-003/DEC-004 recorded, no architecture selected, no live action. No truncation.

*یادداشت فارسی مالک — بخش ۳ از ۶:*
*مشتق‌سازی یونیورس و روش آماری تحویل شد. سبد پایه ده‌نمادی و تایم‌فریم‌های اجرایی ۱۵دقیقه، ۱ساعت و ۴ساعت به‌عنوان تنها کاندیدای لایو مشتق شد؛ اسکالپ ۱ تا ۵ دقیقه و گرید کامل زیر ۱۲ساعت به‌علت هزینه و آزمون چندگانه برای لایو رد شد. سقف ریسک همچنان پارامتریک و بدون توصیه باقی است. هیچ اتصال یا سفارشی انجام نشد. ادامه: بخش ۴ از ۶ — سنتز معماری، تلگرام و عملیات.*


# Part 4/6 — Architecture Synthesis + Telegram + Operations (ART-005)

> **Part scope:** This message delivers **ART-005 only**.
> Inputs: ART-003 REQ-001 to REQ-028, ART-004 OP-U0+OP-U1, C1-C26.
> Output: envelope-first derivation, architecture options with baseline, feasibility comparison, synthesized architecture, data, risk, order machine, Telegram, security, operations.
> Risk boundary remains OWNER_DECISION_PENDING. No fixed risk, leverage, drawdown, or holding-duration constant is adopted.
> Design-only. No implementation, deployment, account connection, credential request, order action, or live authorization.
> All monetary in **USDT**. All time in **UTC** with semantic role.

## 4.1 Synthesis method

Dependency G2+G3→G4. Criteria fixed in Parts 1/6 and 3/6 reused without reweighting: hard-gate compliance, risk fail-closed, statistical validity, net-of-cost small-capital feasibility, operational feasibility under comms loss, resource use, verifiability, reversibility. Positive derivation D13: each inclusion states governing evidence. D12 delegation: algorithms and frameworks remain derived, optimizer never relaxes hard limit per REQ-012.

DEC-005, DEC-006, DEC-007 recorded in §§4.2-4.5. REVERSIBLE with re-derivation.

## 4.2 Envelope-First D15 — normative derivation

No sub-step deviation. Where measurement is absent, bound is stated as NOT_MEASURED with fail-closed rule.

### 4.2.1 Step 1 — Derive load envelope from ART-004

Load for interim universe S0={BTC,ETH,SOL,BNB,XRP,ADA,DOGE,AVAX,LINK,LTC}, execution {15m,1h,4h}, context {1d}:

```
Candles(S0,narrow) = 10 symbols × 4 TF × 3,500 = 140,000 candles
Measured unit C19: 1.25 GB per 10×14×3,500 = 490,000 candles → ~2.55 KB/candle stored JSON snapshot
Projected raw S0 narrow ≈ 140,000 × 2.55 KB ≈ 357 MB + index ~30% ≈ 464 MB
Projected raw S0 full-14 ≈ 1.25 GB + index ≈ 1.63 GB
Projected raw 134×14 ≈ 16.75 GB + index + calibration outputs + logs > 20 GB
Compute per cycle: validate 10×4 signals on bar close, risk counters O(positions), reconciliation O(orders+positions), Telegram poll O(1). No ≤12h grid search per C24.
Availability: bar-close-driven + funding-timestamp-driven + monotonic-deadline-driven. No continuous tick loop required.
Data freshness bound: availability_time + latency_buffer; stale → DataValid=False.
```

Envelope demands: <1 GB data for S0 narrow, bursty CPU on bar close, <500 MB RAM working set, intermittent network, indefinite safe-park without inbound.

### 4.2.2 Step 2 — Measure / bound POCO X6

Snapshot per C14-C16, no sustained claim:

* SoC Snapdragon 7s Gen 2 octa up to 2.4 GHz. Sustained throughput NOT_MEASURED. Bound: assume bursty only, no 100% continuous; duty-cycle with thermal backoff; background throttling expected.
* RAM 12 GB + 8 GB extension. Extension is swap, not real-time memory. Bound: app working set ≤2 GB safe, ≤4 GB max.
* Storage 256 GB total, 56 GB free snapshot. Bound: app budget ≤5 GB data + 2 GB logs/outputs; snapshot only, re-check at runtime; free space is not guaranteed.
* OS Android 16, Termux intended. Bound: no systemd, Doze/App Standby applies, charging ≠ exemption per C15. Foreground service + wakelock discipline required; kill/restart must be safe.
* Network metered, NATed, intermittent. Inbound Telegram unstable per A9.
* Sustained runtime NOT_MEASURED. Rule: no claim of 24/7 unattended phone operation until measured; design must survive kill, reboot, Doze, comms loss fail-closed.

### 4.2.3 Step 3 — Match

S0 narrow (~0.5 GB, bursty, 2 GB RAM) fits snapshot envelope with margin. S0 full-14 (~1.6 GB) fits snapshot storage but stresses sustained compute. 134×14 (>20 GB with outputs) plus concurrent reconciliation exceeds safe phone bound and violates C24 statistically. Therefore breadth must be reducible before depth before capability per A8 order.

### 4.2.4 Step 4 — Gap, compromise, Step 4b topology enumeration

Gap: snapshot fits S0 narrow; sustained, Doze survival, and 134-breadth do not fit without measurement and reduction. Compromise follows A8 order strictly:

**Step 4b — all genuinely feasible topologies:**

* T1 All phases on phone. Research, calibration, paper, live on POCO Termux. No external host. Lowest trust surface, highest phone load. Feasible for S0 narrow.
* T2 All except Live on phone. Dev/training/calibration/paper on phone, Live on separate always-on host. Requires second host owner-provisioned, adds data sync, secret scope, relay trust. Feasible only if owner provisions host; not assumed.
* T3 Retain dev/training/calibration on phone and reduce, in order: (a) breadth symbols S1→S0→BTC-only, (b) depth timeframes 4→2→1 execution TF, (c) capability indicators/models→rules-only. Three ordered sub-variants T3a,T3b,T3c. Always feasible by reduction to OP-U0.
* T4 Redesign: phone as thin Telegram terminal only, all compute external. Requires external host + relay + webhook. Feasible only with provisioned infrastructure; highest deviation from phone-preservation preference.

DEC-005: adopt T1 for S0 narrow as synthesis target, with pre-authorized reduction path T3a→T3b→T3c→OP-U0 baseline if envelope exceeded. T2/T4 rejected now for lack of provisioned host and larger trust surface. REVERSIBLE if sustained measurement or provisioned host changes evidence. Rationale: only T1+T3 preserve A8 preference within measured snapshot without assuming external infrastructure.

## 4.3 Independent architecture options including baseline

* OP-A0 Baseline: BTC-only, 1h execution, 4h/1d context, T1 phone, long-poll Telegram, parametric risk counters, manual-gated entries, autonomous exits. Minimal state.
* OP-A1 Focused modular phone-first: S0 narrow, 15m/1h/4h execution, T1 with T3 reduction path, full interlocks, autonomous safe-park. Live candidate.
* OP-A2 Split: phone research + external live host. Adds relay/webhook, secret duplication, sync failure modes.
* OP-A3 Externalized: phone thin client, cloud compute + relay. Maximum capability, maximum dependence, violates phone preservation unless T1-T3 proven infeasible.

## 4.4 Feasibility comparison on pre-stated criteria

| Criterion | OP-A0 | OP-A1 | OP-A2 | OP-A3 |
|---|---|---|---|---|
| Hard gates A1,A2,A5 | PASS | PASS proxy gated | CONDITIONAL sync + A5 relay review | CONDITIONAL relay is new trust venue |
| Risk fail-closed A9-A10 | PASS smallest | PASS counters enforceable | FAIL added split-brain on comms loss | FAIL liveness depends on relay+phone |
| Net-of-cost small E | PASS narrow | PASS selective 15m boundary | Same as A1 but fee+infra overhead | Same plus infra cost |
| Operational unreachable | PASS safe-park trivial | PASS defined §4.5.7 | FAIL two hosts unreachable independently | FAIL relay loss = operator loss |
| Resource D15 | PASS | PASS narrow, T3 path | PASS phone but host unprovisioned | FAIL no host, preference violated |
| Verifiability | PASS highest | PASS lineage tags | FAIL sync lineage ×2 | FAIL ×3 surfaces |
| Reversibility | REVERSIBLE | REVERSIBLE | Costly reversal secrets/host | Costly |

OP-A2/A3 rejected for live now; retained as fallback only if T1 sustained measurement fails and owner provisions host. Synthesis = OP-A1 with OP-A0 as permanent fallback and comparison anchor.

## 4.5 Synthesized architecture — selected

DEC-006: synthesize OP-A1 phone-first modular with OP-A0 fallback. Five runtime domains + two offline domains. No parallel operator interface per REQ-002.

```
[Venue Toobit-Perp] ←→ [Data] ←→ [Signal] ←→ [Risk] ←→ [OrderMachine] ←→ [Venue]
                              ↓              ↓              ↓
                        [Ledger] ←→ [Interlocks] ←→ [TelegramBot] ←→ [Operator]
                              ↓
                        [AuditLog append-only UTC]
Offline: [Research/Calibration] → promotes only via pre-registered hypothesis + validation per §3.7
```

Process topology is single phone Termux supervisor with supervised tasks, not a framework mandate. Language/framework delegated per A12; interface constraint is not process constraint per A2.

### 4.5.1 Data subsystem

Every record carries UTC role tags: `venue_event_time, bar_open, bar_close, availability_time, wall_server_anchored, monotonic_elapsed`. Daily UTC day, weekly ISO-8601 UTC week per REQ-003.

Kline schema design-only:

```
Kline{venue:"Toobit-Perp", symbol, timeframe, open,high,low,close,volume,
 venue_event_time, bar_open, bar_close, availability_time, lineage:"VENUE_DIRECT"|"PROXY_LINEAGE(src,window,0.56bp,0.999755)", perpetual:true}
FundingTick{symbol, rate, clamp_observed_bp, venue_event_time, availability_time}
LiquiditySnapshot{symbol, bid_notional, ask_notional, spread_bp, wall_time, NON_REPRODUCIBLE:true, usable_for_sizing:false}
```

Rules: perpetual lineage only; spot rejected. Proxy allowed 1h/4h research/paper with lineage, never Live price, never ≤15m per REQ-024. markPrice and klines.change quarantined per REQ-021. Depth never sizes. Missing ladder per C3, absent X-Api-Limit per C4, historical OI per C26 → dependent logic disabled fail-closed. C5: -1003 rate-limit → backoff; -1007 TIMEOUT ambiguous → reconcile before retry, never assume outcome. Conservative taker 0.06% per REQ-017 until resolved.

Purge+embargo walk-forward per §3.7. Stale/gap → DataValid=False → interlock refuses Live with reason.

### 4.5.2 Risk engine — parametric, fail-closed

Parameters PENDING per REQ-013: `E, r, r_agg, r_daily, dd_fraction+window, L_max, N_max, MaxHoldingDuration`. No anchor. Optimizer never relaxes hard limit per REQ-012.

```
B_trade = E × r
EstNetLoss = Q×d + N×fee_rate×2 + SpreadEst + SlipAllowance + FundingEst
AllowEntry iff EstNetLoss ≤ B_trade AND ΣEstNetLoss_open+pending + EstNetLoss ≤ E×r_agg
 AND DayLoss > −E×r_daily AND Drawdown < dd_fraction AND N ≤ N_max AND L ≤ L_max
 AND HoldingProjected ≤ MaxHoldingDuration AND Interlocks all PASS
Else refuse with explicit reason via Telegram + audit.
Uncertain inputs → refuse. Comms loss → never releases limit.
Equity for drawdown includes unrealized net of estimated close costs at bar close UTC.
```

Aggregate/daily/drawdown halt with Telegram re-arm requiring authentication, never auto-resume into Live.

### 4.5.3 Order state machine — idempotent, reconcilable

`clientOrderId` charset `^[A-Za-z0-9_-]+$` per REQ-021, UUID-nonce, single-flight.

States: IDLE → SIGNAL_VALIDATED → RISK_CHECKED → ORDER_CONSTRUCTED → SUBMITTED → ACK_PENDING → OPEN_ACKED → MANAGE → EXIT_SIGNALED → CLOSING → CLOSED; branches REJECTED, TIMEOUT_AMBIGUOUS, RECONCILE_REQUIRED, SAFE_PARKED.

Key transitions design-only:

```
SUBMIT on RISK_CHECKED+Interlocks PASS only.
ACK_PENDING + -1007 → TIMEOUT_AMBIGUOUS → RECONCILE_REQUIRED → query venue orders/positions/fills by clientOrderId → adopt venue truth → OPEN_ACKED or IDLE, never double-submit.
-1003 → backoff monotonic deadline, no storm.
Any mismatch exchange≠ledger → RECONCILE_REQUIRED → halt new entries, manage exits per safe-park.
Kill/restart → startup reconciliation before any entry.
```

Nominal stop never treated as cap; liquidation proximity from discovered ladder; missing ladder → no position.

### 4.5.4 Telegram sole interface + loss semantics

Singleton bot. No dashboard/app/second bot/routine console per REQ-002. Autonomous safe-park is safety logic, not an interface.

Commands: `/mode paper|live`, `/status`, `/positions`, `/ledger`, `/config_show`, `/config_set`, `/halt`, `/resume`, `/ack`, `/help`. Mode selector has no wait/profit hurdle per REQ-010; Live allowed only if six interlocks PASS, else refuse with reason. All privileged acts require allowlisted `chat_id`, nonce, timestamp window, explicit `/ack`; untrusted messages validated for charset/length/range.

Push: fills, refusals, interlock trips, reconciliation mismatch, clock drift, funding anomaly, outage entry/exit. Read-only review via bot exports.

Polling vs webhook: long polling selected. Webhook requires public HTTPS endpoint infeasible phone-native behind NAT without relay. Relay genuinely feasible only with owner-provisioned always-on host, adding cost/trust/data route, not assumed. Polling tolerates NAT/Doze with foreground service, monotonic backoff, server-anchored ordering. DEC-007.

Loss semantics per REQ-009: TelegramAvailable=False is safe state. Loss never releases limit, never unblocks unsafe action, never marks uncertain confirmed. When unreachable: no new entries, existing managed by pre-authorized exits, pending orders reconciled on next DataValid window, open positions Parked with time-stop + risk-stop, all decisions logged for later review.

Token failure, replay, injection, rate-limit: fail-closed, no trading, local audit, surface on next successful poll. Safety never depends on Telegram availability.

### 4.5.5 Security + audit

Authenticate every privileged message, authorize by role single-operator allowlist, validate all fields, nonce+window anti-replay, token-bucket rate-limit, parameterized handling anti-injection, token compromise procedure: revoke/rotate via BotFather out-of-band, halt Live until re-authenticated. Append-only audit UTC with role tags for every privileged act, refusal, mode change, config change with hash chain.

### 4.5.6 Operations: six interlocks, clock, outage, duration

Interlocks refuse Live with explicit reason, re-checked startup, periodic, pre-entry, on event:

1. Data-validity: fresh, lineage clean, no quarantined field trusted.
2. Reconciliation: exchange=ledger positions/orders/fills.
3. Risk-limit: all counters within parametric caps, inputs certain.
4. Credential/permission: permission probe passes at runtime; engagement performs none per REQ-004.
5. Config-integrity: versioned hash matches approved, change only via authenticated Telegram with ack.
6. Clock: monotonic for deadlines, server-anchored wall offset bounded, drift trip halts.

Clock: elapsed deadlines monotonic only; ordering server-anchored wall + availability_time; bar logic UTC roles.

Outage: 3-day assumption PROVISIONAL per REQ-022; system safe indefinite. On outage: no entries, safe-park, pre-authorized exits only, no fill assumed, resume only after DataValid+reconciliation PASS.

Holding-duration derivation per REQ-006, no fixed constant:

```
MaxHoldingDuration = min(H_exit_quantile, H_funding_bound, H_risk_horizon, H_validation_horizon, H_UTC_day_bound)
```

Intraday intent enforces review-or-close before UTC day boundary unless derivation with funding/cost/risk evidence justifies and caps allow. Context 1d/1w/1M never justifies overnight hold.

Fallback: any envelope breach, Doze kill loop, or sustained NOT_MEASURED failure → auto-reduce T3a→T3b→T3c→OP-A0, log gap, notify on next poll.

## 4.6 Traceability

REQ-001 venue, 002 singleton, 003 UTC roles, 005 proxy gate, 006 duration derivation, 007 breadth feasible, 008 D15 T1+T3, 009 loss fail-closed, 010 six interlocks + selector, 011 E parametric, 012 optimizer bound, 013 still PENDING, 015 3d excluded, 016 cap lineage, 017 conservative fee, 018 funding clamp, 019 depth non-reproducible, 020 net-edge, 021 charset+quarantine, 022 indefinite outage safe, 023 NOT_MEASURED bound, 024 lineage, 025 no grid + validity, 026 census gate, 027 fail-closed ambiguity, 028 design-only preserved. REQ-004,014 engagement rules preserved.

## Artifact, verification, completeness

* **ART-005 DELIVERED this Part 4/6 §§4.2-4.5.** ART-001 to ART-004 remain delivered. ART-006 verification matrix row count 28 + adversarial + acceptance deferred to Parts 5-6/6 with reasons: needs synthesis as input; matrix must equal register.
* Interim checks: no anchor, no fixed duration, no parallel interface, no external host assumed, proxy gated, OI disabled, depth not for sizing, optimizer bounded, uncertain→refuse. V-1 to V-7 remain PASS for delivered scope; V-8 to V-12 scheduled Part 6/6.
* **Part 4/6 complete** for declared scope: D15 steps with 4b enumeration and ordered compromise, four architecture options with baseline compared on pre-stated criteria, synthesis OP-A1+OP-A0 with data/risk/order/Telegram/security/operations, polling selection with webhook/relay feasibility bound, unreachable safe-park, six interlocks, duration formula. No truncation. No live action.

*یادداشت فارسی مالک — بخش ۴ از ۶:*
*سنتز معماری تحویل شد: سامانه ماژولار اول-موبایل روی همان گوشی با سبد باریک و سه تایم‌فریم اجرایی، با مسیر کاهش از پیش مجاز تا تک‌نماد پایه. همه کنترل فقط با یک ربات تلگرام با احراز هویت و رفتار امن هنگام قطعی؛ وب‌هوک بدون سرور خارجی ناممکن اعلام و لانگ‌پولینگ انتخاب شد. شش اینترلاک با دلیل صریح اجازه لایو را می‌دهند یا رد می‌کنند. ریسک همچنان پارامتریک بدون عدد. هیچ اتصال یا سفارشی انجام نشد. ادامه: بخش ۵ از ۶ — راستی‌آزمایی و تست.*


# Part 5/6 — Verification Matrix + Test Plans + Adversarial Review (ART-006 Part A)

> **Part scope:** This message delivers **ART-006 Part A only**.
> Inputs: ART-001 capability/DAG/checkpoint, ART-002 DEC-001 to DEC-007, ART-003 REQ-001 to REQ-028, ART-004 OP-U0+OP-U1 and statistics, ART-005 OP-A1+OP-A0 synthesis.
> This Part 5/6 delivers normative verification matrix with row count equal to register row count, design-only test plans, implementation-readiness sequence, and adversarial review per D7.
> Part 6/6 will deliver self-audits V-1 to V-12, completeness equation, final artifact registry, acceptance-status summary, limitations, and next action.
> Design-only. No implementation, deployment, account connection, credential request, order action, or live authorization.
> All monetary in **USDT**. All time in **UTC** with semantic role.

## 5.1 Verification method definitions

Five methods. Each matrix row uses at least one.

* **Inspection:** check design artifact text, schema, configuration, code-like specification without execution.
* **Analysis:** manual derivation, arithmetic check, lineage audit, statistical check.
* **Demonstration:** design-only walkthrough of behavior under injected condition, no live execution.
* **Test:** executable check defined for future implementation; not executed in this engagement. Described as plan only.
* **Audit:** review of engagement outputs or logs for boundary compliance.
* **Runtime interlock check:** gate enforced at startup, periodic, pre-entry, or on event in Paper/Live. Verified in design by inspection of gate logic; confirmed only at runtime.

Result values in this engagement: `DESIGNED` means design logic satisfies requirement on paper; `PENDING_RUNTIME` means final confirmation requires runtime gate or measurement; `N/A` only with reason. No `PASS_LIVE` is claimed.

## 5.2 Normative verification matrix — 28 rows equal to register

The table below is normative. Row count equals ART-003 row count. Count: REQ-001 to REQ-028 inclusive = 28 rows.

| Req ID | Verification method | Verifying artifact / Gate | Pass criterion | Result in engagement |
|---|---|---|---|---|
| REQ-001 | Inspection of venue config + router | ART-005 §4.5, Live gate | LiveVenue={Toobit-Perp}, other LiveAllowed=False, no drift path | DESIGNED, PENDING_RUNTIME gate |
| REQ-002 | Inspection + demonstration of interface inventory | ART-005 §4.5.4, ART-006 T-TELEGRAM | Singleton bot, parallel routine count=0, safe-park is not an interface | DESIGNED |
| REQ-003 | Inspection + test with DST boundary | ART-005 §§4.5.1/4.5.6, T-CLOCK | Timezone=UTC, every timestamp has role, monotonic for deadlines, UTC day / ISO-8601 week | DESIGNED |
| REQ-004 | Audit of engagement outputs | Acceptance, T-ENGAGE | Zero secrets, zero authenticated calls, zero orders in engagement | DESIGNED audit pass |
| REQ-005 | Inspection of lineage + gate demonstration | ART-004 §3.2, ART-005 §4.5.1, Live gate | Prohibited source isolated from Live data/execution, proxy tagged, A5 conditions checked | DESIGNED, PENDING_RUNTIME re-check |
| REQ-006 | Analysis of derivation record | ART-005 §4.5.6, T-DURATION | Intent=Intraday, MaxHoldingDuration=derived formula, no fixed constant | DESIGNED formula, PENDING quantification |
| REQ-007 | Analysis + feasibility comparison | ART-004 §§3.2-3.6, T-UNIVERSE | Universe=Derived, symbol rationale distinct from timeframe rationale | DESIGNED interim S0 narrow |
| REQ-008 | Analysis + measurement plan + inspection | ART-005 §4.2, T-ENVELOPE | D15 Steps 1-4b followed, no undisclosed deviation, T1+T3 path recorded | DESIGNED, PENDING sustained measurement |
| REQ-009 | Demonstration with comms-loss injection | ART-005 §§4.5.4/4.5.6, T-LOSS | Loss never releases limit, never confirms uncertain, safe-park defined | DESIGNED logic |
| REQ-010 | Demonstration of each interlock + selector | ART-005 §4.5.6, T-INTERLOCK | Six interlocks refuse with reason, Live=AND(interlocks), no wait/profit hurdle | DESIGNED, PENDING_RUNTIME trip test |
| REQ-011 | Inspection for fixed-equity absence | ART-004 §3.7.3, ART-005 §4.5.2 | No embedded E constant, illustrations use E parameter in (0,500] USDT | DESIGNED |
| REQ-012 | Inspection of derivation + constraint test | ART-005 §§4.1/4.5.2, T-OPT | Every candidate has disposition, optimizer ∩ relax(hard limit)=empty | DESIGNED |
| REQ-013 | Inspection for anchor absence + education completeness | ART-003 §2.4, ART-004 §3.8, acceptance | No 15%/20%/5%/10x/100 USDT anchor, parametric B=E×r, PENDING until owner decision | DESIGNED parametric |
| REQ-014 | Audit of questions asked | Acceptance, T-ENGAGE | Zero delegated-algorithm questions, zero repeats, only non-delegable returned | DESIGNED audit pass |
| REQ-015 | Inspection | ART-004 §§3.3-3.4, T-UNIVERSE | Usable⊆Ceiling14, 3d Allowed=False everywhere | DESIGNED |
| REQ-016 | Analysis of pagination + lineage | ART-004 §§3.2-3.3, T-DATA | 3,500-cap respected, perpetual lineage, 1,774-bar bound noted | DESIGNED |
| REQ-017 | Inspection of cost model | ART-004 §3.7.3, ART-005 §4.5.1, T-COST | FeeTaker_Assumed=0.06% until sourced resolution | DESIGNED conservative |
| REQ-018 | Inspection | ART-005 §§4.5.1-4.5.2, T-COST | No ±24 bp cap assumed where −30.0000 bp observed | DESIGNED |
| REQ-019 | Inspection + runtime re-validation plan | ART-004 §3.2, ART-005 §4.5.1, Live gate | Depth usable_for_sizing=False, liquidity filter re-validated | DESIGNED, PENDING_RUNTIME re-validation |
| REQ-020 | Analysis | ART-004 §§3.3/3.7.3, T-COST | Feasible(tf) requires NetEdge>0 after all costs, measurement not constant | DESIGNED |
| REQ-021 | Test with invalid id + lineage inspection | ART-005 §§4.5.1/4.5.3, T-ORDER | IdCharset enforced, markPrice/klines.change quarantined | DESIGNED |
| REQ-022 | Demonstration with outage injection | ART-005 §4.5.6, T-OUTAGE | Safe under indefinite outage, 3-day value labeled PROVISIONAL | DESIGNED logic |
| REQ-023 | Inspection + measurement plan | ART-005 §4.2, T-ENVELOPE | Snapshot recorded, sustained=NOT_MEASURED, no sustained claim | DESIGNED bound |
| REQ-024 | Analysis + lineage audit | ART-004 §§3.2/3.7.1, T-DATA | Proxy 1h/4h with lineage allowed research/paper, 5m rejected, storage budgeted | DESIGNED |
| REQ-025 | Statistical analysis | ART-004 §3.7.2, T-STATS | Deflated Sharpe + MinBTL/MinTRL + N_max_effective enforced, ≤12h grid rejected | DESIGNED method, PENDING thresholds |
| REQ-026 | Inspection + re-validation plan | ART-004 §§3.2/3.6, Live gate | Universe⊆revalidated snapshot, 134+10+3+2=149 verified, no exhaustiveness claim | DESIGNED arithmetic verified |
| REQ-027 | Demonstration with fault injection | ART-005 §§4.5.1-4.5.3, T-ORDER/T-INTERLOCK | Ambiguous error fail-closed, ladder missing blocks entry, OI logic disabled | DESIGNED logic |
| REQ-028 | Self-audit V-1 to V-12 | ART-006 Part B in 6/6, acceptance | Provenance + dependency + completeness equation balanced, no profit guarantee | DESIGNED, V-8 to V-12 in Part 6/6 |

Matrix-to-register count check: 28 register rows, 28 matrix rows. No orphan requirement. No orphan matrix row.

## 5.3 Design-only test plans

No test executed in this engagement. Each plan defines objective, setup in UTC roles and USDT, steps, expected fail-closed behavior, and mapping to REQ. Plans run in future implementation in order T-ENGAGE → T-CLOCK/T-DATA → T-COST/T-STATS/T-UNIVERSE → T-ENVELOPE → T-RISK/T-ORDER/T-LEDGER → T-INTERLOCK/T-LOSS/T-OUTAGE → T-TELEGRAM/T-SEC.

**T-ENGAGE — engagement boundary audit.** Maps REQ-004, REQ-014, REQ-028. Inspect all delivered messages for secrets, authenticated calls, order directives, delegated-algorithm questions, profit guarantees. Expected: zero findings. Evidence: audit log with message hashes.

**T-CLOCK — UTC role and monotonic test.** Maps REQ-003. Setup: synthetic bars across DST boundary and UTC day/week boundary with roles `bar_open, bar_close, availability_time, wall_server_anchored, monotonic_elapsed`. Steps: inject 500 ms server offset, 5 s Doze pause, out-of-order poll. Expected: ordering uses availability_time, deadlines use monotonic, offset trip halts Live with `CLOCK_DRIFT` reason.

**T-DATA — lineage, cap, quarantine test.** Maps REQ-005, REQ-016, REQ-021, REQ-024. Setup: paginated 3,500-cap pull, perpetual vs spot tag, proxy 1h/4h with `PROXY_LINEAGE(median 0.56bp, corr 0.999755)` vs 5m proxy, `clientOrderId` charset `^[A-Za-z0-9_-]+$`, conflicted `markPrice/klines.change`. Expected: spot rejected, 5m proxy rejected for extension, invalid id rejected pre-submit, conflicted fields quarantined, every bar has availability_time.

**T-COST — conservative cost acceptance test.** Maps REQ-017, REQ-018, REQ-020. Setup: E parameter in (0,500] USDT, N parameter, taker 0.06% per leg, spread/slippage/funding buffers, clamp −30.0000 bp case. Steps: compute `NetEdge=Gross−(Fee×2+Spread+Slip+Funding)` per timeframe. Expected: 1m/3m/5m fail NetEdge for small E, 15m boundary conditional on maker evidence, 1h/4h evaluated per hypothesis, no timeframe passes on gross alone.

**T-STATS — multiple-testing and embargo test.** Maps REQ-025. Setup: pre-registered set with declared `N_eff=min(published,recomputed)`, walk-forward UTC splits with embargo ≥ MaxHoldingDuration+funding interval+latency. Steps: attempt ≤12h full grid, attempt 5m proxy validation, compute deflated Sharpe with skew/kurtosis, check MinBTL vs MinTRL 19.54 yr gap. Expected: grid rejected, 5m proxy rejected, hypotheses without deflation rejected, trial counter increments on every test including rejects.

**T-UNIVERSE — symbol/timeframe re-validation.** Maps REQ-007, REQ-015, REQ-019, REQ-026. Setup: census 149=134+10+3+2 verified, seed S0 ten symbols, candidate S1. Steps: filter LIVE_PASS only, re-validate volume/spread at runtime, exclude 3d, exclude LIVE_PARTIAL/DOC_CONFLICT from Live. Expected: LiveTradable=False until re-validation + ladder discovery pass.

**T-ENVELOPE — phone bound and reduction path.** Maps REQ-008, REQ-023. Setup: S0 narrow ~464 MB projected, S0 full ~1.63 GB, 56 GB free snapshot, sustained NOT_MEASURED. Steps: measure bursty CPU on bar close, RAM working set, storage growth, Doze kill/restart, thermal backoff. Expected: S0 narrow fits snapshot, breach triggers ordered reduction T3a breadth→T3b depth→T3c capability→OP-A0, with gap log and Telegram notice on next poll.

**T-RISK — parametric counter test.** Maps REQ-011, REQ-013, REQ-010. Setup: parameters `E,r,r_agg,r_daily,dd_fraction,L_max,N_max` symbolic, no anchor. Steps: sweep E∈{100,200,300,500} USDT × r∈{0.5%,1%,2%,5%,10%} recomputing `B=E×r` and `EstNetLoss=Q×d+N×fee×2+Spread+Slip+Funding` per cell; inject concurrent positions and daily-loss sequence; inject uncertain input. Expected: entry refused when `EstNetLoss>B` or aggregate/daily/drawdown breached; uncertain→refuse; no cell copied without recomputation.

**T-ORDER — idempotency and ambiguity test.** Maps REQ-021, REQ-027. Setup: single-flight `clientOrderId` nonce, states IDLE→…→CLOSED per §4.5.3. Steps: inject −1003 rate-limit, −1007 ambiguous TIMEOUT, duplicate submit, kill before ack, exchange≠ledger mismatch, missing ladder. Expected: backoff on −1003, reconcile-by-id on −1007 with no double-submit, mismatch halts entries, missing ladder blocks entry, nominal stop never treated as cap.

**T-LEDGER — reconciliation test.** Maps REQ-010. Setup: ledger vs venue positions/orders/fills. Steps: match on startup, periodic, pre-entry, post-fill; inject drift of 1 USDT notional or 1 contract. Expected: `RECONCILE_REQUIRED`, no new entries, safe-park exits only, explicit Telegram reason, resume only after equality re-established.

**T-INTERLOCK — six-gate trip test.** Maps REQ-010. Trip each: stale data, ledger mismatch, cap breach, permission probe fail, config hash mismatch, clock drift. Expected: six distinct refusal reasons, LiveAllowed=False, Paper unaffected except where data-invalid, re-arm only via authenticated Telegram ack.

**T-LOSS — Telegram loss injection.** Maps REQ-002, REQ-009. Setup: long-poll with NAT/Doze gaps, token failure, replay, injection, rate-limit. Steps: drop inbound 1 h with open position + pending order; replay privileged `/mode live`; flood. Expected: no limit release, no unsafe unblock, uncertain stays uncertain, pre-authorized exits only, replay/flood rejected, safety independent of Telegram.

**T-OUTAGE — indefinite outage test.** Maps REQ-022. Setup: venue unreachable with open exposure. Steps: enter outage, attempt entry, hold 72 h simulated, restore with gap beyond stop. Expected: no entries during outage, safe-park survives restart, no fill assumed, resume only after DataValid+reconciliation PASS, loss measured net of gap/slippage.

**T-TELEGRAM/T-SEC — singleton and privilege test.** Maps REQ-002, §4.5.4/4.5.5. Inventory interfaces for second bot/dashboard/console; attempt non-allowlisted `chat_id`, expired timestamp, reused nonce, oversized/invalid-charset message, token compromise. Expected: count=0 parallel routine interfaces, all unauthorized acts rejected and audited, compromise procedure halts Live until rotation and re-authentication.

**T-OPT — optimizer bound test.** Maps REQ-012. Attempt optimizer action relaxing risk cap, leverage ceiling, or interlock. Expected: rejected by construction, logged as violation attempt.

**T-DURATION — holding-duration derivation check.** Maps REQ-006. Verify `MaxHoldingDuration=min(exit_quantile,funding_bound,risk_horizon,validation_horizon,UTC_day_bound)` derived from evidence, UTC-day review-or-close default, context TFs never justify overnight hold. Expected: no fixed constant present.

## 5.4 Implementation-readiness sequence — design only

Order respects D11 dependency: provision → data → risk/ledger → order → Telegram/security → interlocks → paper calibration → acceptance. No step executed here.

1. Freeze ART-003 to ART-005 inputs and measurement plan.
2. Implement UTC-role stamping and audit hash chain first; nothing trades before clock passes.
3. Implement data with lineage, cap pagination, quarantine, proxy gate.
4. Implement parametric risk counters and ledger with uncertain→refuse.
5. Implement order machine single-flight + reconciliation.
6. Implement singleton Telegram long-poll + auth + safe-park.
7. Wire six interlocks to Live gate with explicit reasons.
8. Run T-plans in §5.3 order on Paper with symbolic E/r sweep; promote nothing to Live while PENDING.
9. Re-measure POCO sustained and storage; execute T3 reduction if breached.

## 5.5 Adversarial review D7 — red-team

**Method and limitation:** Independent reviewer unavailable in this engagement. Red-team performed by same model under D7 with explicit limitation: same-model review cannot claim independence. Mitigation: attacks derived from C-labels and REQ failure modes, each with checkable disposition and residual risk. A future independent review remains recommended before any Live consideration.

**Attacks and dispositions:**

1. *Venue drift to non-Toobit live.* Attack: add second venue for lower fees. Disposition: blocked by REQ-001 LiveVenue set + Live gate. Residual: none in design.
2. *Shadow interface.* Attack: add web dashboard for convenience. Disposition: blocked by REQ-002 count=0. Residual: emergency safety logic must never become routine console; monitored by T-TELEGRAM.
3. *Timezone look-ahead.* Attack: use bar close as knowable. Disposition: blocked by availability_time + embargo per §§3.7/4.5.1. Residual: implementation must preserve tag discipline.
4. *Proxy leakage to Live.* Attack: use 5m proxy to extend history. Disposition: blocked by REQ-005/024, 5m proxy rejected, Live price VENUE_DIRECT only. Residual: mis-tagging risk; mitigated by lineage audit.
5. *Cost underestimation.* Attack: use 0.05% fee, ignore spread/slip/funding, treat stop as cap. Disposition: blocked by conservative 0.06%, NetEdge rule, buffers, liquidation proximity. Residual: live spread regime change; mitigated by re-validation gate.
6. *Notional/margin/budget confusion.* Attack: size 100 USDT margin at 10x as if 100 USDT notional. Disposition: blocked by §2.4.4 three-number rule + EstNetLoss check. Residual: operator manual-entry error; mitigated by Telegram validation ranges.
7. *Concurrent/daily bypass.* Attack: many small trades each within B. Disposition: blocked by aggregate/daily/drawdown caps. Residual: pending-order fill burst; mitigated by pre-commit of pending risk.
8. *Comms-loss exploitation.* Attack: claim loss releases limit or confirms fill. Disposition: blocked by REQ-009 safe-park, uncertain stays uncertain. Residual: prolonged unreachable with open exposure; mitigated by pre-authorized time-stop.
9. *−1007 double-submit.* Attack: retry ambiguous submit. Disposition: blocked by reconcile-by-id, no double-submit. Residual: venue id non-persistence; mitigated by startup reconciliation.
10. *Multiple-testing mining.* Attack: ≤12h grid, 1d thousands, 5m scalping hype. Disposition: blocked by N_max_effective, deflated Sharpe, MinBTL, grid rejection. Residual: PROVISIONAL 10-20 at 4h; mitigated by pre-registration.
11. *Doze kill during manage.* Attack: phone kills app with open position. Disposition: restart reconciliation + safe-park, no entries until equality. Residual: sustained NOT_MEASURED; mitigated by T-ENVELOPE + T3 reduction.
12. *Depth-sized leverage.* Attack: size on 90M snapshot. Disposition: blocked by NON_REPRODUCIBLE tag, depth never sizes. Residual: none in design.
13. *Telegram spoof/replay/flood + token theft.* Attack: forged `/mode live`, replayed ack. Disposition: blocked by allowlist, nonce+window, rate-limit, rotation-halts-Live. Residual: SIM/social-engineering outside system; owner-controlled.
14. *Optimizer relaxes risk.* Attack: auto-tune raises r after wins. Disposition: blocked by REQ-012 empty intersection. Residual: none by construction.
15. *Outage gap beyond stop.* Attack: assume max 3-day outage. Disposition: indefinite-outage safe, no fill assumed, gap loss withheld from cap optimism. Residual: gap larger than E fraction; mitigated by small N and halt.

**Overall finding:** No attack achieves Live promotion or limit release within synthesized design without tripping an interlock or audit event. Residual risks are measurement gaps (sustained runtime, live spread/ladder, re-validation freshness) and same-model independence limitation, both carried to Part 6/6 as explicit limitations with T-plan coverage.

## Artifact, verification, completeness

* **ART-006 Part A DELIVERED this Part 5/6 §§5.2-5.5.** ART-001 to ART-005 remain delivered. ART-006 Part B deferred to Part 6/6 with reason: V-8 to V-12, completeness equation, final registry, acceptance summary require all verification inputs closed.
* Interim checks: 28=28 count holds, no anchor adopted, no fixed duration, proxy gated, OI disabled, depth not for sizing, optimizer bounded, uncertain→refuse preserved. V-1 to V-7 remain PASS for delivered scope; V-8 to V-12 scheduled Part 6/6.
* **Part 5/6 complete** for declared scope: normative matrix, 16 design-only test/sequence plans in dependency order, implementation sequence without execution, same-model adversarial review with 15 attacks and residual risks. No truncation. No live action.

*یادداشت فارسی مالک — بخش ۵ از ۶:*
*ماتریس راستی‌آزمایی ۲۸به۲۸ برابر جدول الزامات، طرح‌های تست طراحی-فقط، توالی آماده‌سازی پیاده‌سازی بدون اجرا، و بازبینی تهاجمی ۱۵ حمله با همان مدل و با تصریح عدم استقلال تحویل شد. هیچ حمله‌ای بدون فعال‌شدن اینترلاک به لایو نمی‌رسد. ریسک همچنان پارامتریک و بدون عدد است و هیچ اتصال یا سفارشی انجام نشد. ادامه: بخش ۶ از ۶ — خودممیزی نهایی، معادله تکمیل، ثبت مصنوعات و پذیرش.*


# Part 6/6 — Self-Audits + Completeness + Artifacts + Acceptance + Limitations + Next Action (ART-006 Part B)

> **Part scope:** This message closes the 6-part delivery.
> Inputs: ART-001 capability/DAG/checkpoint, ART-002 DEC-001 to DEC-007, ART-003 REQ-001 to REQ-028, ART-004 universe/statistics, ART-005 synthesis, ART-006 Part A matrix/tests/adversarial.
> This Part 6/6 delivers normative self-audits V-1 to V-12, completeness declaration with arithmetic, final artifact registry, acceptance-status summary, limitations, and non-delegable next action.
> Design-only. No implementation, deployment, account connection, credential request, order action, or live authorization. No profitability guarantee.
> All monetary in **USDT**. All time in **UTC** with semantic role where time appears.

## 6.1 Self-audits V-1 to V-12 — normative

Method: inspection of delivered Parts 1/6 to 5/6 plus analysis of trace links. Independent reviewer unavailable; same-model limitation carried explicitly in V-9.

| ID | Audit question | Method / Evidence | Result |
|---|---|---|---|
| V-1 | Evidence-first: does every bound cite A/C provenance, with SOURCE_VERIFIED only for supplied PROMPT.md text? | Inspection of §§2.3,3.2-3.3,4.2,4.5. No external archive, repository, endpoint, or live data claimed. | **PASS** |
| V-2 | Dependency-first D11: was G0→G1→G2→G3→G4→G5→G6→G7→G8 order respected with DAG without cycles? | Inspection of Part 1/6 DAG edges; register before universe before synthesis before verification. | **PASS**, no deviation |
| V-3 | Delivery integrity D22/D20/D21: 6 parts, declared scopes delivered, no truncation, no abbreviation by summary? | Count: Parts 1,2,3,4,5 delivered as declared; this Part 6 closes. No scope omitted without reason. | **PASS** |
| V-4 | No-anchor integrity: no 15%/20%/5%/10x/100 USDT or fixed duration/equity adopted as hard/provisional/sanity/hidden constant? | Inspection for anchor strings in §§2.4,3.8,4.5.2,4.5.6. Parametric `B=E×r`, duration formula only. | **PASS** |
| V-5 | Synthesis integrity §9: independent options with baseline compared on pre-stated criteria before selection? | OP-U0+OP-U1/OP-A0+OP-A1 with criteria fixed in Parts 1/6,3/6; DEC-003/005/006 recorded REVERSIBLE. | **PASS**, closes Part 1/6 N/A |
| V-6 | Statistical and net-of-cost validity: deflation, MinBTL/MinTRL, N_max_effective, embargo, NetEdge, conservative 0.06% applied? | Inspection of §§3.7,4.5.1-4.5.2, T-COST/T-STATS. ≤12h grid rejected, 5m proxy rejected, OI disabled. | **PASS**, closes Part 1/6 N/A |
| V-7 | Fail-closed safety: six interlocks, comms-loss, outage, ambiguity, optimizer bound all refuse with reason? | Demonstration logic §§4.5.2-4.5.6, T-INTERLOCK/T-LOSS/T-OUTAGE/T-OPT. Uncertain→refuse preserved. | **PASS** |
| V-8 | Verification coverage §11: matrix rows equal register rows, every REQ has method plus artifact/gate? | Count check §6.2: 28 register rows, 28 matrix rows in Part 5/6 §5.2. No orphan either side. | **PASS** |
| V-9 | Adversarial D7: attacks attempted with dispositions and residuals, independence limitation disclosed? | Inspection of §5.5: 15 attacks, blocked-by-interlock finding, same-model limitation stated. | **PASS with limitation** |
| V-10 | Artifact registry and traceability: ART-001 to ART-006 delivered, IDs stable, DEC traceable, persistence per §2.2.8? | Inspection §6.3. No file facility observed; fallback to delivered messages. IDs unchanged. | **PASS** |
| V-11 | Engagement boundary: zero secrets, zero authenticated calls, zero orders, zero delegated-algorithm questions, zero profit promise? | Audit of Parts 1/6-6/6 outputs per T-ENGAGE. UTC roles and USDT-only preserved. | **PASS** |
| V-12 | Pending-decision clarity: PENDING items listed, no silent default, acceptance status explicit, only non-delegable returned? | Inspection §§6.4,6.6. Risk/duration/thresholds remain PENDING; Live refused. | **PASS** |

No audit failed. No audit waived. V-9 limitation does not block design completeness; it blocks any Live significance claim and requires future independent review.

## 6.2 Completeness declaration §2.2.5 with arithmetic

Design delivery is **complete** for the delegated scope. Complete means every required derivation delivered with provenance and checkability, not that PENDING owner decisions are resolved. PENDING by design remains PENDING; Live remains refused while PENDING.

Partition of the single register into seven disjoint buckets covering all rows:

* **A=4 Core:** REQ-001,002,003,004 — venue, singleton interface, UTC roles, design-only boundary.
* **B=5 Data lineage:** REQ-005,015,016,024,026 — cross-venue gate, timeframe ceiling, candle cap, proxy/storage lineage, census gate.
* **C=6 Cost/risk/statistics:** REQ-011,013,017,018,020,025 — parametric equity, pending risk, conservative fee, funding clamp, NetEdge, deflated validity.
* **D=4 Safety:** REQ-009,010,022,027 — comms-loss, six interlocks/selector, indefinite-outage safe, ambiguity fail-closed.
* **U=4 Universe/phone/duration:** REQ-006,007,008,023 — intraday derivation, broad-but-feasible universe, D15 T1+T3 path, NOT_MEASURED bound.
* **E=3 Process:** REQ-012,014,028 — delegation/optimizer bound, no-unnecessary-questions, evidence/dependency/completeness integrity.
* **F=2 Filter/quarantine:** REQ-019,021 — depth non-reproducible, charset plus conflicted-field quarantine.

Equation with steps shown:

```
A+B+C+D+U+E+F = R
4+5+6+4+4+3+2 = 28
4+5=9, 9+6=15, 15+4=19, 19+4=23, 23+3=26, 26+2=28
R = 28 = register rows = matrix rows
```

Coverage: every integer REQ-001 to REQ-028 appears exactly once above; verified by list intersection in §6.1 V-8. No requirement stated normatively outside ART-003. No matrix row outside §5.2. No truncation in Parts 1/6-6/6 for declared scopes.

DEC-008 recorded here: declare 6-part design delivery complete under DEC-001 delivery plan, with Live refused while §6.4 PENDING items persist. REVERSIBLE only by re-derivation or explicit owner risk decision with education record. Rationale: close gated workflow without resolving non-delegable decisions by default.

## 6.3 Final artifact registry

| Artifact | Content | Status |
|---|---|---|
| ART-001 | Capability inventory G0/D3, prompt-integrity notes, DAG, checkpoint dated 2026-11-03 UTC wall-anchored recordkeeping date, scope/limits | DELIVERED Part 1/6 §§1-4 |
| ART-002 | Decision record DEC-001 delivery plan, DEC-002 dependency order, DEC-003 universe baseline+live candidate, DEC-004 validation method, DEC-005 T1+T3 topology, DEC-006 OP-A1+OP-A0 synthesis, DEC-007 long-poll, DEC-008 completeness/Live-refused | DELIVERED Parts 1/6,3/6,4/6,6/6 |
| ART-003 | Single requirements register REQ-001 to REQ-028, 11 fields each, class definitions, parametric risk education | DELIVERED Part 2/6 |
| ART-004 | Symbol/timeframe derivation, four universe options with baseline, comparison, interim S0 narrow, statistical methodology, parametric trial-budgets | DELIVERED Part 3/6 |
| ART-005 | D15 envelope with 4b enumeration, four architecture options with baseline, synthesis OP-A1+OP-A0, data/risk/order/Telegram/security/operations, six interlocks, duration formula | DELIVERED Part 4/6 |
| ART-006 | Part A: 28-row matrix, 16 T-plans plus sequence, 15-attack red-team. Part B: this §6 V-1 to V-12, completeness, registry, acceptance, limitations, next action | DELIVERED Parts 5/6,6/6 |

IDs stable across parts. No rename. No second register. No second matrix.

## 6.4 Acceptance-status summary

| Category | Items | Status |
|---|---|---|
| Design logic accepted as DESIGNED | REQ-001 to REQ-005,009 to REQ-012,014 to REQ-021,024,026,028; interlock/loss/outage/order/Telegram logic; universe interim; statistical method | DESIGNED, no live claim |
| Conservative branches accepted until sourced resolution | REQ-017 0.06%, REQ-018 −30.0000 bp governs, REQ-019 depth non-reproducible, REQ-021 quarantine, REQ-027 ladder/headers/−1007/OI fail-closed | DESIGNED conservative |
| PROVISIONAL accepted as provisional only | 3-day outage value, 10-20 trials at 4h, full storage projection from 1.25 GB unit | PROVISIONAL, must not size or validate on them |
| PENDING requiring runtime or owner act | REQ-006 duration quantification, REQ-007 expansion beyond S0, REQ-008 sustained measurement, REQ-010 runtime trip confirmation, REQ-013 r/r_agg/r_daily/dd/L_max/N_max, REQ-023 sustained/Doze, statistical thresholds per hypothesis | PENDING, Live refused |
| Live authorization | Requested implicitly by workflow; checked against six interlocks plus PENDING list | **REFUSED with reasons:** risk fractions unset, duration unquantified, sustained NOT_MEASURED, ladder undiscovered, liquidity un-revalidated, independent review outstanding |
| Paper progression | Allowed only after T-sequence through interlocks with symbolic E/r sweep, no Live promotion while PENDING | CONDITIONAL, design-only plan delivered |

No profitability, feasibility-at-scale, or live-significance acceptance is granted or implied. MinTRL 19.54-year gap disclosed in §3.7 stands.

## 6.5 Limitations and residual risks carried forward

1. Same-model red-team; independent review outstanding.
2. No code executed; T-plans are plans only.
3. All venue facts are snapshots to checkpoint; re-validation mandatory at runtime.
4. Sustained phone runtime, thermal, Doze survival NOT_MEASURED; T1 valid for S0 narrow snapshot only with T3a→T3b→T3c→OP-A0 reduction armed.
5. Live spread, slippage, ladder, permission state unknown by engagement boundary; missing or stale blocks entry.
6. Cross-venue proxy valid 1h/4h research/paper with lineage only; 5m rejected; legal/sanctions owner/legal per A5.
7. PROVISIONAL values must not become constants.
8. Storage arithmetic from 1.25 GB unit is projection, not measurement of full 134-symbol load.
9. No file/persistent-volume facility observed; persistence is delivered messages; future implementation must add hash-chained audit store first.

## 6.6 Next action — truly non-delegable decisions only

No delegated algorithm, infrastructure, model class, parameter, optimizer, language, or framework question is returned. Owner is asked only:

1. Confirm receipt of §§2.4,3.8 education and that no trial-budget figure was adopted.
2. When and only when ready, set explicitly in one authenticated record: `E reference` for planning, `r`, `r_agg`, `r_daily`, `dd_fraction+window`, `L_max`, `N_max`, or explicitly leave PENDING with Live remaining refused.
3. Confirm Toobit futures/perpetual as continued sole live venue or authorize change with contradiction record per REQ-001.
4. Authorize next phase as implementation measurements and Paper T-sequence only; no live-trading authorization is requested by this design.

Silence leaves all PENDING and Live refused. No waiting period or profit hurdle is imposed.

---

**Final delivery statement:** Parts 1/6 through 6/6 deliver the strongest defensible design within actual constraints through the gated workflow: capability → register → universe/statistics → synthesis → verification/adversarial → audits/completeness/acceptance. Arithmetic 4+5+6+4+4+3+2=28 holds. Matrix 28 equals register 28. V-1 to V-12 audited. No architecture beyond OP-A1+OP-A0 synthesis is implied. No live action performed.

*یادداشت فارسی مالک — بخش ۶ از ۶ و خلاصه نهایی:*
*این پیام پایانی هر شش بخش را کامل کرد: خودممیزی V-1 تا V-12 همگی پاس با یک محدودیت تصریح‌شده یعنی نبود بازبین مستقل، معادله تکمیل ۴+۵+۶+۴+۴+۳+۲=۲۸ برابر ۲۸ ردیف الزامات و ۲۸ ردیف ماتریس، ثبت نهایی مصنوعات ART-001 تا ART-006 و تصمیمات DEC-001 تا DEC-008، وضعیت پذیرش، محدودیت‌ها و اقدام بعدی. اجازه لایو به‌صورت صریح رد شد تا وقتی سقف‌های ریسک، سقف نگهداشت، اندازه‌گیری پایداری گوشی، کشف لدر لوریج و اعتبارسنجی نقدشوندگی تعیین و آزمون‌های مستقل پاس شوند. هیچ عدد ریسک، لوریج یا دراودانی توصیه یا تحمیل نشد، هیچ اتصال به حساب، کلید، سفارش یا اقدام لایو انجام نشد. اقدام بعدی فقط تصمیمات غیرقابل تفویض مالک است: تعیین صریح پارامترهای ریسک پس از آموزش، یا باقی نگه‌داشتن در وضعیت معلق با ادامه توقف لایو.*

