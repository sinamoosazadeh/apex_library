این پاسخ نخستین بخش از طراحی کامل است. طراحی به دلیل حجم الزامات (ثبت نیازمندی‌ها با یازده فیلد برای هر ردیف، مقایسه گزینه‌ها، مشخصات اجزا، ماتریس اعتبارسنجی و اعلامیه تکمیل) در یک پیام قابل ارائه نیست. طبق بند ۲.۲.۴ پرامپت، طراحی در شش بخش شماره‌گذاری‌شده ارائه می‌شود. در این بخش موارد زیر آمده است: قابلیت‌ها و محدودیت‌های واقعی محیط، نقطه بازرسی پیش از تحقیق، تحلیل وابستگی مراحل، گزارش ناسازگاری‌ها و نقص‌های خود پرامپت، نقشه پرسش‌های طراحی، و فهرست تصمیم‌های مالک که هنوز باز هستند.

هیچ منبع بیرونی بازرسی نشده، هیچ آزمونی اجرا نشده و هیچ دسترسی به صرافی، حساب، کلید API یا مخزن کد وجود نداشته است. تنها منبعی که بازرسی شده، خود فایل پرامپت است. برای دریافت بخش ۲، عبارت «ادامه بده» یا «Part 2» را ارسال کنید.

---

## 1. Delivery plan (D22, §2.2.4)

| Part | Scope | Gate labels (reference only, §2.1.2) |
|---|---|---|
| 1/6 (this message) | Capability inventory, boundary check, pre-research checkpoint, dependency analysis, prompt-integrity report, material-question map, initial owner-decision register, identifier conventions, verification of this part | G0, G1, G2 (partial), D11 analysis |
| 2/6 | Single requirements register (R-001 onward, 11 fields per row), evidence classification of §5 inputs, contradiction register | G2 |
| 3/6 | Option generation and comparative evaluation: architecture dimensions, deployment topology enumeration (Step 4b), phase derivation (D16), universe derivation calculation chain (D14), parametric risk and sizing calculations | G3, G4 |
| 4/6 | Design synthesis: components, state ownership, order lifecycle, risk authority and veto classes, Telegram command contract, data design, operations and procedural-consistency table | G5 |
| 5/6 | Statistical methodology and trial budget, parameter register, requirement-to-verification matrix, adversarial review, propagation log of design changes | G6, G7 |
| 6/6 | Completeness declaration (§2.2.5), self-verification V-1 to V-12 (§2.2.6), final artifact registry, identifier catalogs, final Persian summary | G8 |

**Fit-check evidence (§2.2.4 item 2).** The total deliverable is planned at six parts by artifact count, not by a measured token count. The requirements register alone (roughly 40 to 60 rows of eleven fields each) is several thousand words, so a single message cannot hold the complete design. This count is therefore **PROVISIONAL**. It will be revised if a part cannot be delivered completely within one message. Method: artifact-count tracking during drafting.

---

## 2. Capability inventory (§2.1.1)

Each item records what is observable in this environment. "Not observed" means no tool or capability of that kind was present in the conversation. It does not mean the capability is absent from the platform.

| Capability | Status | Observation and consequence |
|---|---|---|
| Model/runtime identity | UNRESOLVED | Not exposed to this engagement. No hidden settings are assumed or claimed. |
| Reasoning or compute controls | UNRESOLVED | Not exposed. The engagement does not claim any particular effort level. |
| Context/output limits | UNRESOLVED | No exact limit is known. Multi-part delivery (D22) is used as a precaution. |
| File creation and persistence | NOT AVAILABLE (observed) | No file-creation tool was observed. The fallback in §2.2.8 applies: artifacts are persisted as delivered messages. No verified file link is provided. |
| Web, repository, or exchange access | NOT AVAILABLE (observed) | No retrieval tool was observed. The owner's archive was not supplied as files. The archive is therefore used only as OWNER_SUPPLIED_AUDIT_SUMMARY (§5.5 of the prompt). |
| Toobit API or any exchange endpoint | NOT AVAILABLE, and not permitted | Forbidden by §3.1 item 4 for account access. Public-endpoint checks are not performed because no tool is available. |
| Code execution | NOT AVAILABLE (observed) | All calculations in this engagement are hand-derived, labeled DERIVED, and show their arithmetic. Executable checks are NOT TESTED. |
| Test facilities | NOT AVAILABLE (observed) | Every test entry in later parts is a specification with status NOT TESTED, unless it is a hand calculation. |
| Multi-message delivery | PROVISIONAL | The prompt requires it. Whether the interface delivers later parts only when requested is confirmed only by the owner's next message. |
| Independent model reviewer (§2.1.5) | NOT AVAILABLE (observed) | No second model or reviewer was observed. The blind staged review is **BLOCKED**. Part 5 substitutes a same-model red-team review, which shares blind spots and is labeled that way. |
| Sources actually inspected | Prompt file only | The prompt PDF was read in full (SOURCE_VERIFIED for the prompt text only). The owner's ratified findings (§5 of the prompt) are used as RATIFIED_FINDING and were not re-verified against any underlying record. |

**Authorization state.** The engagement is design-only. No credentials were requested or received. No order, account, or permission action is performed or planned. This is consistent with §3.1 item 4 and §14.

---

## 3. Boundary and G0 exit check

**Prohibited actions** (from §1, §3.1 item 4, §14): implementation, deployment, account connection, credential handling, order submission/cancellation/modification, live-trading authorization, modification of any external repository, and legal conclusions on cross-venue access (§3.1 item 5).

**Exit condition G0:** "No planned step depends on a capability, source, or authorization that is assumed but unavailable."

**Evaluation.** The following planned steps depend on sources or capabilities that are not available:

- Verification of the taker fee (C6), the markPrice/klines.change semantics (C13), historical open-interest availability (C26), order-book depth convention (C8), and the -1007 and -1003 error semantics (C5). These are marked **BLOCKED** (source access not available). Each is assigned a conservative fallback in Part 2. None is treated as settled.
- Sustained runtime measurement on the POCO X6 (C16). This is **BLOCKED** (no device access and no test facility). Part 3 treats every device capacity figure as PROVISIONAL.
- Independent blind review (§2.1.5). This is **BLOCKED** (no reviewer).
- Re-derivation of the ratified statistics (C20, C21, C22, C23) from raw data. This is **BLOCKED** because no raw data or code is available. The ratified values are used as RATIFIED_FINDING, and the parts that depend on them carry a PROVISIONAL label where the prompt requires it.

**G0 status: PASS for the engagement's own planned steps.** Each dependent item above is recorded as BLOCKED with its consequence. No step assumes an unavailable capability.

---

## 4. Pre-research design checkpoint (G1, §4.3)

**Placement and timing.** This checkpoint is the first output in the engagement and is delivered before any external source call. No external source call is made in this engagement. Therefore the checkpoint has not been reconstructed after research.

**Date.** UNKNOWN. No date source is exposed in this environment. The sequence position is recorded instead.

**Anchoring disclosure.** This checkpoint is pre-external-research, not unanchored. The owner's brief contains detailed domain concepts, ratified findings, a set of illustrative numbers, and a named venue. These shape the frame. The checkpoint is recorded here so that later evidence-supported changes are visible as amendments and not as silent rewrites (§2.1.4).

### 4.1 Objectives

- **O1.** Derive a design for a futures/perpetual-futures trading system on Toobit that is UTC-disciplined, operated only through a Telegram bot, and safe under unreliable connectivity (§3.1 items 1–3, 9).
- **O2.** Derive the architecture, trading universe, deployment topology, phase structure, risk authority, execution lifecycle, and validation method from the requirements (§3.1 items 6–10, §9, §10).
- **O3.** Keep risk appetite, the utility function, and the maximum-drawdown and per-trade-risk values as OWNER_DECISION_PENDING. Calculate them parametrically (D17).

### 4.2 Binding constraints

Traced to §3.1 and §5.0 (A-series identifiers):

- **A1.** Toobit futures/perpetuals as the live venue (OWNER_HARD).
- **A2.** Telegram bot is the sole operator interface (OWNER_HARD). It is an interface constraint, not a trust boundary and not a topology constraint.
- **A3.** UTC is authoritative for computation and records (OWNER_HARD). Monotonic clocks for elapsed time. Behavior under stale or unknown clock offset must be specified.
- **A4.** No account access, no credentials, no authenticated calls, and no order actions during this engagement (OWNER_HARD).
- **A5.** Cross-venue data only under the stated conditions. Research and paper use only, unless full unrestricted use is established. Legal questions are owner/legal matters. Prohibited sources are gated away from Live and execution paths (OWNER_HARD).
- **A6.** Intraday trading intent (OWNER_HARD). The holding-duration policy is a DESIGN_JUDGMENT derived from evidence.
- **A7.** Breadth of symbols and timeframes is a preference, limited by feasibility (OWNER_PREFERENCE).
- **A8.** Reference device (POCO X6) is a feasibility constraint and a compromise axis, not an architecture driver. Envelope-first ordering applies (D15).
- **A9.** No stable inbound connection to the handset is assumed. Telegram loss must not release a risk limit, unblock an unsafe action, or make an uncertain outcome appear confirmed (OWNER_HARD for the reliability requirement).
- **A10.** Phase vocabulary is an intent description, not an architecture. The Paper/Live selector is a preference. The safety interlocks are hard correctness gates (OWNER_HARD).
- **A11.** Illustrative capital of about 200 USDT, with a planning range below 500 USDT. Used parametrically (OWNER_ATTESTED).
- **A12.** Architecture, method, feature, parameter, and optimizer selection are delegated to the model (OWNER_HARD for the delegation).
- **A13.** No unnecessary questions to the owner (OWNER_HARD).

### 4.3 Open decisions (pre-research)

The full list is in Section 8 of this part. At the checkpoint stage, the material open items are: the risk boundary (OD-01, OD-02), risk appetite and utility (OD-03), cross-venue legal conditions (OD-04), the outage-class definition (OD-05), and several UNRESOLVED data semantics (OD-07 to OD-11).

### 4.4 Comparison criteria (declared before any option is scored)

These criteria are declared now. They are applied in Part 3 to every consequential choice.

- **K1 — Hard gate (pass/fail, not compensable).** The option violates none of A2, A3, A4, A5 gating, A9, the interlocks in §3.1 item 10, the trial-budget constraint (C24), or the rule that no risk check passes when unevaluable (§9.6). Failure eliminates the option.
- **K2 — Envelope fit (per workload, per phase).** PASS, PROVISIONAL, or FAIL against the POCO X6 bounds in Part 3. Recorded separately for each workload.
- **K3 — Verifiability.** Whether the option can be tested under the declared trial budget and whether its failure modes can be injected and checked (§11.2).
- **K4 — Operational burden.** Operator effort, recovery steps, and dependence on always-on processes.
- **K5 — Reversibility (§2.1.4).** REVERSIBLE, COSTLY_REVERSIBLE, or IRREVERSIBLE.
- **K6 — Resource and cost.** Storage, compute, network, and any recurring hosting cost in USDT with date and scope (§10.3).
- **K7 — Explainability and reviewability.** Whether a reviewer can reproduce a decision from the record.

Scores are not averaged across K1 and the other criteria. A K1 failure is a veto (§11.1).

### 4.5 Credible candidate directions (not decisions)

These are open options, not selections. Each is evaluated in Part 3 against K1 to K7.

- **Deployment:** on-device only; on-device research with a separately hosted Live process; fully remote hosting; hybrid with a relay. Full enumeration with envelope fit is required in Part 3 (Step 4b).
- **Process topology:** single process with logically separate modules; separate processes on one host; separate services.
- **Phase structure:** three, four, or six phases. The owner's four-phase vocabulary is a starting reference only.
- **Adaptation:** none; fixed pre-registered hypotheses; analytically constrained parameters; bounded Bayesian search; staged screening. Each is evaluated against the minimum mechanism that the requirements need (§3.1 item 12).
- **Timeframe dimensionality:** single, dual, or multi-timeframe. Derived in Part 3 from the information needs (§10.2).

---

## 5. Dependency analysis (D11, §2.1.2 mandatory pre-sequencing step)

### 5.1 Material exit conditions and prerequisites

The G-labels are references. Each exit condition below is a dependency node.

| Node | Exit condition | Prerequisites | Source of prerequisite |
|---|---|---|---|
| X1 | Capability and boundary established | none | Section 2 and 3 of this part |
| X2 | Ratified inputs classified with status, scope, and conflicts | none | Prompt §5 (read) |
| X3 | Requirements register complete (11 fields, single table) | X1, X2 | Part 2 |
| X4 | Owner-decision register classified (owner-level, delegated, resolvable by method) | X2, X3 | Section 8 of this part, completed in Part 2 |
| X5 | Parametric compute, storage, and latency envelope derived | X3 | Part 3 |
| X6 | Universe derivation chain (D14 Steps 1–9) | X3, X5 (parametric), X4 (risk parameter as symbol) | Part 3 |
| X7 | Option generation with declared criteria | X3, X2 | Part 3 |
| X8 | Comparative evaluation (K1–K7); deployment topology enumeration (Step 4b) | X5, X6, X7 | Part 3 |
| X9 | Design synthesis: components, state, interfaces, order lifecycle, risk authority, Telegram contract, operations | X8 | Part 4 |
| X10 | Verification matrix with row count equal to register count | X3, X9 | Part 5 |
| X11 | Adversarial review and propagation of design changes | X9, X10 | Part 5 |
| X12 | Completeness declaration and self-verification | X1 to X11 | Part 6 |

### 5.2 Cycles and their breaks

Cycles are explicitly marked, as §2.1.2 requires.

- **Cycle C-1: envelope (X5) ↔ architecture (X8).** The compute envelope depends on the workload, which depends on the architecture. **Break:** X5 is expressed as a function of workload parameters (universe size, timeframe count, history length, bytes per bar, operations per bar). The envelope is then bounded for each architecture candidate in X8. No architecture is chosen from X5 alone.
- **Cycle C-2: universe (X6) ↔ liquidity threshold ↔ risk parameter (OD-01, OD-02).** The liquidity threshold depends on trade size, which depends on the per-trade risk fraction, which is pending. **Break:** the threshold is expressed as a function of the risk fraction, and its value is shown across a range (§3.3 and D17). The universe is therefore a function of the pending parameter. Part 3 shows this function and identifies which parts of the universe are invariant to the parameter.
- **Cycle C-3: Telegram topology ↔ deployment (X8).** The operator-availability requirement depends on where the process runs. **Break:** the deployment candidates in Part 3 are evaluated first under the operator-independence requirement from A9. Telegram topology is then chosen only among the topologies that pass.

### 5.3 Derived execution order

1. X1 and X2 in parallel. Both are complete in this part.
2. X3 (Part 2).
3. X4 as a partial set, and X5 in parametric form (Part 3).
4. X6 in parametric form. Cycle C-2 is resolved as a function, not a fixed value.
5. X7, which can run in parallel with step 4 once X2 and X3 exist.
6. X8, with Step 4b topology enumeration done before any compromise.
7. X9, then X10 and X11 (X10 can start once X3 and the design components exist).
8. X12 last.

### 5.4 Deviation from the reference order (§7.2, deviation protocol)

§7.1 places "targeted evidence inspection" (Step 3) before "requirements" (Step 4). In this engagement, no source can be inspected (see Section 2). The evidence step therefore reduces to classifying the ratified inputs (X2), which happens before the register (X3). The deviation is recorded here:

- **Dependency justifying it:** the only available source is the prompt. Source inspection cannot precede the requirements register because there is no source to inspect.
- **Downstream requirements left unverified by the deviation:** every requirement that depends on an external fact is marked BLOCKED or UNRESOLVED in Part 2, with the resolution method stated.
- **Recorded in the final evidence record:** yes (Part 6).

---

## 6. Prompt integrity report (§5.0 requirement)

§5.0 requires that any identifier used without definition be reported before proceeding. The following items were found during the reading of the prompt. Each has a resolution in this design.

| ID | Finding | Resolution used in this design |
|---|---|---|
| PD-01 | §13.7 refers to an "A5 patch" for a phase-deviation table. The phrase is not defined. | Interpreted as the single deviation-table requirement in §3.1 item 10. Applied in Part 3. |
| PD-02 | Labels P2 and P4 appear in §13.7 but are not defined inline. P1, P3, and P5 are defined inline. | Mapped to §2.1.2 (linear ordering) and §3.1 item 8 (mobile-as-axis). Recorded as a minor gap. |
| PD-03 | "Class-A" (§5.1, C12) is undefined. The prompt itself says so. | Not used. Outage classes are defined in Part 4 and ratified in OD-05. |
| PD-04 | §6 refers to "R-031 and onward in a prior run". No prior register was supplied. | No prior register is used. The register in Part 2 starts at R-001. No dependency on a prior run is assumed. |
| PD-05 | §9.6 refers to "/ack <reason> in a downstream command spec". The spec is not present. | The command is defined in the Telegram contract in Part 4. |
| PD-06 | §2.2.5 example "500 bp × 14,400 s = 720 s (not 72 s)" is dimensionally inconsistent (basis points times seconds). It is also numerically wrong: 500 × 14,400 = 7,200,000. The likely intended value is 5% × 14,400 s = 720 s (0.05 × 14,400 = 720). | Treated as an illustrative example only. No calculation in this design depends on it. |
| PD-07 | §5.4 reports a Deflated Sharpe value of "1.5e-2 at N = 100" without stating whether it is a probability or a ratio. | Recorded as RATIFIED_FINDING with the unit undefined. Not used in any calibration. UNRESOLVED for unit; resolution is re-derivation from the raw test record (BLOCKED). |
| PD-08 | §5.4 reports MinTRL = 19.54 yr as corrected. The inputs (Sharpe, skewness, kurtosis, observation frequency) are not in the brief, so the value cannot be reproduced here. | RATIFIED_FINDING, not re-derived. The MinTRL/MinBTL distinction is preserved as required. |
| PD-09 | Day-count convention is implied, not stated. 1,774 / 365 = 4.860 yr and 3,500 / 365 = 9.589 yr, matching the stated 4.86 and 9.59. A 365.25-day year would give 4.857 and 9.583. | DERIVED: the source uses a 365-day year. The convention is adopted and recorded (§3.1 item 3 requires explicit units). |
| PD-10 | The storage ratio (C19) uses the nominal product 3,500 × 14 × 10 = 490,000 units. The 1d series holds only 1,774 bars, and only 36 of 58 sampled combinations reached 3,500 bars. The nominal product therefore overstates the unit count, and the true per-unit cost is uncertain. | DERIVED: 1.25 GB (decimal, 1.25 × 10^9 bytes) / 490,000 = 2,551 bytes per nominal unit. The actual bar count was not recorded, so the per-unit value is UNRESOLVED within a range. Part 3 shows the scaling. |
| PD-11 | §10.1 Step 2 and §9.6 both refer to a liquidity threshold. No threshold value is given. | Not a defect. Derived in Part 3 as a function of the risk fraction. |
| PD-12 | The §2.2.5 completeness declaration requires that A + B + C + D + U + E + F = R. The prompt gives no instruction for an empty register. | Not a defect for this part. It applies when the register exists (Part 2 onward). |

**Conflicts between binding requirements (§2 item 1).** The following pairs were checked. None is a true conflict, but each needs an explicit reconciliation.

- **A9 (no inbound connection) vs. the webhook option in §3.1 item 9.** A webhook needs an inbound endpoint. Long polling needs only outbound connections. Reconciliation: long polling is the only option that satisfies A9 without infrastructure. Webhook is feasible only with an external relay, which is a topology option (Part 3).
- **A10 (Live selector without waiting periods) vs. the interlocks.** Reconciliation as §3.1 item 10 states: the interlocks are correctness gates, not waiting periods or profit hurdles.
- **A4 (no account access) vs. the requirement that interlocks check credentials and permissions (§3.1 item 10).** Reconciliation: the interlock logic is designed and specified now. It is verified only in a later, separately authorized step. In this engagement it is NOT TESTED.

**Recorded tension for the owner.** §3.3 gives illustrative numbers (15–20% drawdown, 5% per-trade risk). The design keeps them as OWNER_DECISION_PENDING (D17) and does not use them as values anywhere.

---

## 7. Material-question map (D12 steps 1–3)

These are the design questions the deliverable must answer. Grouping follows natural cohesion. Each question is assigned to the part where it is answered.

| Cluster | Question | Answered in |
|---|---|---|
| Authority | Q-01: Which decisions are owner-level, which are delegated, and which can be deferred with a PROVISIONAL default? | Section 8 (this part); Part 2 |
| Strategy information | Q-02: What information does the strategy need, and at what timeframes? | Part 3 |
| Strategy information | Q-03: What operational definition of intraday applies, and what maximum holding duration is derived? | Part 3 |
| Universe | Q-04: Which symbols survive the liquidity, depth, and budget screens? | Part 3 |
| Universe | Q-05: Which timeframes are required, and what is the multi-timeframe dependency graph if any? | Part 3 |
| Statistics | Q-06: What is the admissible trial budget per cell, and which selection procedure is used? | Part 5 |
| Statistics | Q-07: What is the validation design (walk-forward, purging, cost sensitivity, negative controls)? | Part 5 |
| Parameters | Q-08: Which dynamic parameters exist, and does any adaptation mechanism earn its place? | Part 3 (derivation), Part 5 (register) |
| Risk | Q-09: How are equity, notional, margin, leverage, stop risk, realized loss, and liquidation represented? | Part 3 |
| Risk | Q-10: What are the veto classes, their recovery conditions, and their resume gates? | Part 4 |
| Risk | Q-11: How is unevaluable risk state handled at startup? | Part 4 |
| Execution | Q-12: What is the order lifecycle, including TIMEOUT_AMBIGUOUS and reconciliation? | Part 4 |
| Execution | Q-13: How is the internal ledger reconciled with exchange state? | Part 4 |
| Platform | Q-14: Which deployment topologies pass the envelope test? | Part 3 |
| Platform | Q-15: What is the phase structure, and how does it map to the owner's vocabulary? | Part 3 |
| Platform | Q-16: What Telegram topology satisfies A9 and the command contract? | Part 3 (topology), Part 4 (contract) |
| Data | Q-17: Which data classes are included or excluded, with the five-criterion justification (§9.4)? | Part 4 |
| Operations | Q-18: What are the recovery, restore, startup, and shutdown procedures, and are they consistent with each other? | Part 4 |
| Operations | Q-19: How is time handled (semantic roles, clock offset, stale clock)? | Part 4 |
| Verification | Q-20: Which acceptance thresholds are derivable, and which are UNRESOLVED? | Part 5 |
| Verification | Q-21: What is the requirement-to-verification matrix? | Part 5 |

Each question answered in a later part earns that part's sections (D18). No section is added without a question behind it.

---

## 8. Owner-decision register (initial)

Owner-decision items are classified as follows. OWNER_DECISION_PENDING means only the owner can decide. UNRESOLVED means the answer can be obtained by a method, which is named. Each item has a default, so that the design can continue without a pause (§1.6, §2.1.7).

Every row contains: ID, item, class, status, evidence pointer, blocked work, default and its safety effect, reversibility (§2.1.4), and consequence.

**OD-01: Maximum drawdown limit.**
- Class: OWNER_DECISION_PENDING.
- Status: illustrative 15–20% of initial equity is recorded in §3.3 and is not adopted.
- Evidence pointer: prompt §3.3; D17.
- Blocked work: final value of the drawdown veto; calibration of any risk-based sizing.
- Default and safety effect: no numerical value is assumed. Live transition refuses because the "risk-limit defined" interlock fails (§3.1 item 10). Paper may run with a stated paper-only value that is labeled non-binding.
- Reversibility: COSTLY_REVERSIBLE. The limit is a configuration value, but losses already realized cannot be reversed.
- Consequence: until set, no Live path is open. The owner must set it or refuse.

**OD-02: Per-trade risk fraction.**
- Class: OWNER_DECISION_PENDING.
- Status: illustrative 5% recorded in §3.3, not adopted.
- Evidence pointer: §3.3; D17; Section 9 of this part (parametric calculation in Part 3).
- Blocked work: trade size, liquidity threshold (Cycle C-2), position sizing.
- Default and safety effect: the calculation is parametric. Universe and sizing are presented as functions of this fraction. No Live sizing is possible without it.
- Reversibility: COSTLY_REVERSIBLE.
- Consequence: universe cut-offs move with this value (Part 3).

**OD-03: Risk appetite and utility trade-off.**
- Class: OWNER_DECISION_PENDING.
- Status: the owner has not defined a utility function or a return target (§6 of the prompt).
- Evidence pointer: prompt §6.
- Blocked work: choice among Pareto-equivalent strategies with different drawdown and return profiles.
- Default and safety effect: the design presents the frontier and does not select a point on it. No candidate is promoted on the basis of a return target.
- Reversibility: REVERSIBLE for the choice of candidate; the policy itself is owner-level.
- Consequence: selection among candidates waits for this decision. This does not block architecture or verification design.

**OD-04: Cross-venue data legal, licensing, and access conditions.**
- Class: OWNER_DECISION_PENDING with a legal dependency.
- Status: the conditions in §3.1 item 5 are not established. The design does not make legal conclusions.
- Evidence pointer: §3.1 item 5; C17; C18.
- Blocked work: any use of cross-venue data in Paper or Live paths.
- Default and safety effect: cross-venue data is research-only, source-tagged, and gated away from Paper and Live (A5). This is the default and is safe.
- Reversibility: IRREVERSIBLE in effect for any legal position taken. The design takes no position.
- Consequence: owner or legal review is needed before any cross-venue data reaches Paper or Live.

**OD-05: Outage-class definition (replaces "Class-A", PD-03).**
- Class: owner ratification of a design-proposed definition.
- Status: the 3-day provisional value (C12) is recorded by the owner. Its governing term is undefined. The exchange retention period is UNRESOLVED.
- Evidence pointer: C12; PD-03; §9.8 of the prompt.
- Blocked work: reconciliation deferral policy.
- Default and safety effect: the design proposes outage classes in Part 4, labeled DESIGN_JUDGMENT. The 3-day value governs only reconciliation deferral, and only until a class is ratified. It is not a retention claim.
- Reversibility: COSTLY_REVERSIBLE.
- Consequence: until ratified, the 3-day value stays PROVISIONAL and is not presented as verified.

**OD-06: Operator burden for exits (automated versus confirmed).**
- Class: OWNER_DECISION_PENDING (owner-level preference between materially different trade-offs).
- Status: undeclared. The §2.1.7 example uses this case.
- Pause assessment against the five §2.1.7 conditions: (1) material impact: yes. (2) owner-level: yes. (3) pre-undeclared: yes. (4) blocking: no. The design can proceed with a PROVISIONAL default, so deferral is safe and the work is not blocked. (5) safe pause: yes, because artifacts are persisted.
- Decision: **no pause.** Condition 4 is not met. The default is PROVISIONAL, with fully automated exits and an operator-issued flatten command that operates without confirmation (Part 4 defines it). The owner's choice will be requested at the natural phase transition, in Part 6.
- Evidence pointer: §2.1.7; §3.1 item 10.
- Reversibility: COSTLY_REVERSIBLE.
- Consequence: the exit-confirmation flow is designed as an optional gate that the owner can enable.

**OD-07: Maximum permitted leverage on the venue.**
- Class: UNRESOLVED.
- Status: the BTC tier ladder has 13 tiers down to 1.0× (C3). The maximum permitted for the account and symbol is not established.
- Evidence pointer: C3.
- Blocked work: margin feasibility checks for small-capital cases.
- Resolution method: a public tier table check, once source access is authorized (BLOCKED now). The owner's own account tier is not to be accessed by this engagement (A4).
- Default and safety effect: the design assumes no leverage ceiling and therefore requires an owner-set cap. Sizing that needs margin above the cap is refused.
- Reversibility: REVERSIBLE.
- Consequence: margin calculations in Part 3 are parametric in leverage.

**OD-08: Taker fee (0.05% vs. 0.06%).**
- Class: UNRESOLVED (C6).
- Resolution method: a public fee-schedule check (BLOCKED now).
- Default and safety effect: use 0.06% as the conservative value for cost feasibility (C6). Report costs as a range.
- Reversibility: REVERSIBLE.

**OD-09: Historical open-interest availability (C26).**
- Class: UNRESOLVED.
- Resolution method: a source check of public history (BLOCKED now).
- Default and safety effect: features that need historical OI are excluded from the first design (§9.4 allows exclusion when the consequence is transparently handled).
- Reversibility: REVERSIBLE.

**OD-10: markPrice and klines.change field semantics (C13).**
- Class: UNRESOLVED (conflicted).
- Resolution method: a scope-matched record or a source check (BLOCKED now).
- Default and safety effect: no feature depends on the disputed field. The design provides a fallback that uses the closing price of the mark-free candle series, with the fallback's dependence on that series recorded in Part 2.
- Reversibility: REVERSIBLE.

**OD-11: Order-book depth convention (C8).**
- Class: UNRESOLVED (non-reproducible).
- Resolution method: define the convention and re-measure, with source access (BLOCKED now).
- Default and safety effect: depth is not used as a capacity fact. Capacity is bounded by the liquidity screen based on the 24-hour notional snapshot (C9), labeled as a snapshot.
- Reversibility: REVERSIBLE.

**OD-12: Sustained runtime on the POCO X6 (C16).**
- Class: UNRESOLVED (not measured). The measurement requires the owner to run device tests locally, because the engagement has no device access.
- Resolution method: representative tests specified in Part 3 (workload-matched, not a charging test).
- Default and safety effect: all device capacity is PROVISIONAL. The phone is not assumed to run Live continuously until measured.
- Reversibility: REVERSIBLE.

**OD-13: Recurring hosting cost, if any topology requires a remote host.**
- Class: OWNER_DECISION_PENDING (capital commitment, §2.1.7 condition 2).
- Status: no provider quote exists. Any cost figure would be DESIGN_JUDGMENT (§10.3).
- Blocked work: the remote-host topology option, if it is selected in Part 3.
- Default and safety effect: no remote host is assumed to be paid for. The topology is evaluated with the cost marked as unknown.
- Reversibility: REVERSIBLE (hosting can be stopped), but commitments made to a provider are COSTLY_REVERSIBLE.

**OD-14: Liquidity snapshot currency (C9).**
- Class: RATIFIED_FINDING with a time bound.
- Status: the snapshot is not timeless. Its date is UNKNOWN.
- Blocked work: a refreshed liquidity screen at the time of use.
- Default and safety effect: the screen uses the snapshot as RATIFIED_FINDING, and the universe register states that the screen must be refreshed before use.
- Reversibility: REVERSIBLE.

**Items not requiring an owner decision (delegated, §3.1 item 12).** Programming language, framework, runtime, libraries, database engine, optimizer method, and model class. These are decided by the model in Part 3 and Part 4. They are not paused for (§2.1.7).

---

## 9. Identifier conventions for this design

Identifiers introduced in this part, for traceability:

- **CAP-1 to CAP-n:** capability inventory items (Section 2).
- **CP-1:** pre-research checkpoint (Section 4).
- **X1 to X12:** exit-condition nodes (Section 5). Defined here; not to be redefined.
- **Cycle C-1, C-2, C-3:** dependency cycles (Section 5.2).
- **PD-01 to PD-12:** prompt-integrity findings (Section 6).
- **Q-01 to Q-21:** material questions (Section 7).
- **OD-01 to OD-14:** owner-decision items (Section 8).
- **R-NNN:** requirements. Defined in Part 2 only. No R-identifier is used in this part.

The §5.0 identifier series (A, C, D, E, P, G, T-C, V) keep their existing definitions. D-numbers used in this part are the prompt's own D-rules. Identifier-catalog rules from the end of the prompt are applied in Part 6.

---

## 10. Verification of this part (§2.2.6 V-1 to V-7, per-part scope)

| Check | Question | Result | Evidence pointer |
|---|---|---|---|
| V-1 | Does this part satisfy D20 for its declared scope? | PASS | Sections 2 to 9. Each item has content, rationale, status, evidence pointer, and consequence. Section 4.5 and Section 8 are the only places where options are listed without scoring; they are explicitly marked as candidates or decisions with their defaults. |
| V-2 | Does this part contain any D21-prohibited pattern? | PASS, with one note | A self-check was run against the prohibited language list. No prohibited phrase is used as a substitute for content. The table in Section 6 uses "Treated as an illustrative example" and similar phrasing as disclosure, not as a summary. |
| V-3 | Does numbering match the plan? | PASS | Part 1/6 as stated in Section 1. |
| V-4 | Do cross-references to prior and next parts match reality? | PASS | Part 2 is the requirements register, as stated in Section 1 and Section 5.3. |
| V-5 | If final, does the completeness declaration exist? | N/A | Not the final part. |
| V-6 | If final, does the declaration satisfy D20/D21/D22? | N/A | Not the final part. |
| V-7 | Have all artifacts for this part been added to the artifact registry? | PASS | Section 11 below. |

**Note on V-2.** The arithmetic check in PD-06 and PD-09 is shown in full. The §2.2.5 arithmetic requirement is satisfied for those two calculations. Full arithmetic reproducibility for at least three substantive calculations is in Part 5 (§13.3).

---

## 11. Artifact registry (running, §2.2.8)

| Artifact ID | Name | Phase | Message reference | Status | One-line description |
|---|---|---|---|---|---|
| ART-01 | Capability inventory | G0 | Part 1/6, Section 2 | DELIVERED | Observed tools, access, and limits. |
| ART-02 | Boundary and G0 exit check | G0 | Part 1/6, Section 3 | DELIVERED | Prohibited actions, dependent items marked BLOCKED. |
| ART-03 | Pre-research design checkpoint CP-1 | G1 | Part 1/6, Section 4 | DELIVERED | Objectives, constraints, open decisions, criteria K1 to K7, directions. |
| ART-04 | Dependency analysis and derived order | D11 | Part 1/6, Section 5 | DELIVERED | Nodes X1 to X12, cycles C-1 to C-3, deviation record. |
| ART-05 | Prompt-integrity report | §5.0 | Part 1/6, Section 6 | DELIVERED | Findings PD-01 to PD-12 with resolutions. |
| ART-06 | Material-question map | D12 | Part 1/6, Section 7 | DELIVERED | Q-01 to Q-21 mapped to the parts that answer them. |
| ART-07 | Owner-decision register (initial) | G2 | Part 1/6, Section 8 | DELIVERED | OD-01 to OD-14, with classes, defaults, and reversibility. Completed in Part 2 with requirement links. |
| ART-08 | Requirements register | G2 | Part 2/6 | DEFERRED | Single table, R-001 onward, 11 fields. |
| ART-09 | Option comparison and topology enumeration | G3/G4 | Part 3/6 | DEFERRED | Criteria K1 to K7 applied to candidates. |
| ART-10 | Design synthesis | G5 | Part 4/6 | DEFERRED | Components, state, lifecycle, risk authority, Telegram contract, operations. |
| ART-11 | Validation matrix and adversarial review | G6/G7 | Part 5/6 | DEFERRED | Row count equal to register count; propagation log. |
| ART-12 | Completeness declaration and V-1 to V-12 | G8 | Part 6/6 | DEFERRED | Final declaration and self-verification table. |

---

## 12. Completeness declaration for Part 1/6

**Part 1/6 is complete for its declared scope.**

**Content deferred:**
- Requirements register (R-001 onward, eleven fields per row): Part 2/6. Reason: a single table of this size is delivered in its own message.
- Evidence classification of the §5 ratified inputs as a register: Part 2/6. Reason: the register rows depend on it. The classification in Section 6 of this part (PD-07 to PD-10) is complete for the items it covers.
- Option comparison, topology enumeration (Step 4b), phase derivation (D16), universe chain (D14), and parametric calculations: Part 3/6.
- Design synthesis and operations consistency table: Part 4/6.
- Statistical method, parameter register, verification matrix, adversarial review: Part 5/6.
- Completeness declaration, V-1 to V-12 table, final registry, identifier catalogs, Persian summary: Part 6/6.

**Partial counts, stated so that Part 6 can reconcile them:**
- Requirements in register so far: 0 (register begins in Part 2/6).
- Owner-decision items: 14 (OD-01 to OD-14).
- Prompt-integrity findings: 12 (PD-01 to PD-12).
- Exit-condition nodes: 12 (X1 to X12).

**Next highest-value action:** Part 2/6, the requirements register. It is the dependency for the verification matrix and for the option comparison. A second action, which the owner may authorize, is a public-documentation source check for C5, C6, C8, C13, and C26 (OD-08 to OD-11). This check would turn four UNRESOLVED items into evidence. It requires source access, which is not available in this environment.


# بخش ۲ از ۶: ثبت الزامات
## Part 2/6: Requirements Register

این بخش ثبت الزامات سیستم، طبقه‌بندی ورودی‌های تأییدشده، ثبت تناقض‌ها و نگاشت تصمیم‌های مالک را ارائه می‌کند. هیچ الزامی در این بخش به‌عنوان «آماده» یا «اثبات‌شده» علامت‌گذاری نشده است. وضعیت‌ها فقط بر اساس شواهد مشاهده‌شده تعیین شده‌اند.

---

### 2.1 Scope, conventions and status definitions

**Scope.** This part defines every binding and recommended requirement for the system within the boundaries of the owner brief, the ratified findings C1 to C26, and the owner decisions OD-01 to OD-14. It does not select architecture, strategy, parameters, or deployment topology. Those are delivered in Parts 3 and 4.

**Identifier convention.** Requirements use `R-###`, sequential from `R-001` with no gaps. This engagement is clean-sheet (see R-005 and CR-17), so no prior numbering is inherited.

**Priority values.**
- `HARD`: a binding constraint on the design. It cites a source that imposes it, or a design judgment that the design adopts as binding.
- `SHOULD`: a strong recommendation. Deviation requires a documented reason.
- `MAY`: an optional alternative. No instance of MAY is used in this register.

**Status values.**
- `PASS`: observed evidence exists in this engagement and supports the requirement. Used only where the observation is stated in the Evidence pointer.
- `FAIL`: observed evidence contradicts the requirement. No instance in this part.
- `BLOCKED`: verification or closure depends on an owner decision, an unavailable source, or an authorized access that this engagement does not have.
- `UNRESOLVED`: the requirement's value or method is not established. The method for resolving it is named in the row.
- `NOT TESTED`: the requirement is a design obligation whose verification happens in a later part or in a later execution phase. No test has been run.

**Verification methods.** `DESIGN_INSPECTION`, `CALCULATION`, `SOURCE_CHECK`, `DETERMINISTIC_TEST`, `EXPERIMENT`, `OWNER_DECISION`.

**Evidence labels.** The labels from the brief are used as defined: OWNER_HARD, OWNER_PREFERENCE, OWNER_ATTESTED, RATIFIED_FINDING, SOURCE_VERIFIED, DERIVED, DESIGN_JUDGMENT, PROVISIONAL, UNRESOLVED, OWNER_DECISION_PENDING.

**Engagement limit.** No account access, credentials, authenticated calls, permission changes, funds access, or order actions were performed or are implied. No external retrieval tool was observed. The only source inspected is the owner's prompt (SOURCE_VERIFIED for the prompt text). Ratified findings are used as RATIFIED_FINDING and were not re-verified.

---

### 2.2 Field definitions (11 fields per requirement)

| # | Field | Content rule |
|---|---|---|
| 1 | ID | `R-###`, unique |
| 2 | Requirement | One testable obligation; "MUST" only for HARD, "SHOULD" for SHOULD |
| 3 | Priority | HARD / SHOULD / MAY |
| 4 | Rationale / source | Brief item (A#, D#), ratified finding (C#), prompt item (PD#), or DESIGN_JUDGMENT with the reason |
| 5 | Evidence label | One label from §2.1 |
| 6 | Verification method | One method from §2.1 |
| 7 | Acceptance condition | Observable condition that makes the requirement pass |
| 8 | Status | One status from §2.1 |
| 9 | Evidence pointer | Where the evidence or blocker is recorded |
| 10 | Failure response | System or process action if the requirement fails |
| 11 | Regression checks | Check repeated whenever the design or artifact changes |

---

### 2.3 Requirement register (R-001 to R-077)

**Note on the table format.** Each group is a table with the 11 fields in the column order above. Cells are kept short. Where a cell requires a full mechanism, the mechanism is specified in the Part named in the Evidence pointer.

#### 2.3.1 Group A: Scope, conduct and provenance (R-001 to R-006)

| ID | Requirement | Priority | Rationale / source | Evidence label | Verification method | Acceptance condition | Status | Evidence pointer | Failure response | Regression checks |
|---|---|---|---|---|---|---|---|---|---|---|
| R-001 | Execution venue is Toobit futures and perpetual futures only. | HARD | Brief A1 | OWNER_HARD | DESIGN_INSPECTION | Every execution component names Toobit. No second execution venue appears. Any venue change requires owner authorization. | NOT TESTED | Brief A1 | Stop design element; raise to owner | Venue-name scan at each part |
| R-002 | The Telegram bot is the sole operator interface. The core enforces every precondition regardless of command origin. | HARD | Brief A2 | OWNER_HARD | DESIGN_INSPECTION | No other operator control surface is defined. Telegram is not treated as a trust boundary. | NOT TESTED | Brief A2 | Remove the non-Telegram surface | Interface inventory diff per part |
| R-003 | No account access, credentials, authenticated calls, permission changes, funds access, or order actions occur during the engagement. | HARD | Brief A4 | OWNER_HARD | DESIGN_INSPECTION | The engagement log contains none of these actions. | PASS | Part 1 §3. No retrieval or exchange tool was observed in this engagement. | Halt and report to owner | Re-check before each part |
| R-004 | Cross-venue data is restricted to research, backtest and paper use. Prohibited sources are gated away from Live and execution paths. | HARD | Brief A5; C17; C18 | OWNER_HARD | DETERMINISTIC_TEST | Every cross-venue record carries a source tag. The Live and execution loader refuses tagged sources in fault-injection tests. | BLOCKED | OD-04 (legal conditions) pending | Live refusal. No legal status is inferred. | Source-tag fault injection |
| R-005 | The design is clean-sheet. No codebase, predecessor architecture, or prior register is assumed. | HARD | Standing instruction; PD-04 | OWNER_HARD | DESIGN_INSPECTION | No artifact is referenced that was not supplied. | PASS | Part 1 PD-04. The register referred to in PD-04 was not supplied and is not used. | Remove the dependency | Scan for undefined references |
| R-006 | Owner examples, brainstorm items, candidate lists and prior working hypotheses are not elevated to hard requirements. | HARD | Standing instruction | OWNER_HARD | DESIGN_INSPECTION | Every HARD row cites a binding source (brief item, ratified finding, owner directive, or DESIGN_JUDGMENT with a reason). | NOT TESTED | This register, §2.2 and §2.3 | Downgrade the row to SHOULD or MAY | Priority audit in Part 6 |

#### 2.3.2 Group B: Time (R-007 to R-011)

| ID | Requirement | Priority | Rationale / source | Evidence label | Verification method | Acceptance condition | Status | Evidence pointer | Failure response | Regression checks |
|---|---|---|---|---|---|---|---|---|---|---|
| R-007 | UTC is authoritative for storage, logs, schedules, windows, reports, alerts, Telegram output, exchange communication and audit events. | HARD | Brief A3 | OWNER_HARD | DETERMINISTIC_TEST | Every persisted or emitted timestamp carries explicit UTC. No local-time value is persisted. | NOT TESTED | Brief A3 | Reject the write | Serialize-and-parse assertion per record type |
| R-008 | The daily boundary is the UTC day. The weekly boundary is the ISO-8601 UTC week, unless a documented alternative is justified. | HARD | Brief A3 | OWNER_HARD | DETERMINISTIC_TEST | Boundary function returns the expected bucket at 00:00:00 UTC and across ISO week-1 year boundaries. | NOT TESTED | Brief A3; boundary vectors in Part 5 | Block report generation | Boundary vector suite |
| R-009 | Elapsed deadlines (timeouts, hold durations, retry windows, cooldowns) are computed on a monotonic clock. | HARD | Brief A3 | OWNER_HARD | DETERMINISTIC_TEST | An injected wall-clock step does not change any elapsed deadline. | NOT TESTED | Brief A3 | Test failure blocks release | Clock-step injection suite |
| R-010 | Clock offset is classified as OK, STALE, UNKNOWN or EXCESSIVE. Live places no risk-increasing order unless the state is OK. Risk-reducing action is allowed only through the pre-authorized flatten path. The tolerance is a parameter. | HARD | Brief A3; interlock 6 (A10) | OWNER_HARD | EXPERIMENT | Tolerance is derived from measured offset on the target device and from venue timestamp behavior. The tolerance value is not set in this part. | UNRESOLVED | No offset measurement exists in this engagement. Method: Part 3 experiment design. | Refuse Live; CRIT alert | Offset-class transition tests |
| R-011 | Every time value is stored under a declared semantic role: venue event time, bar open, bar close, knowability (availability) time, monotonic elapsed time, or server-anchored wall time. Device wall-clock time is never used as event time. | HARD | DESIGN_JUDGMENT: prevents look-ahead and clock-skew errors | DESIGN_JUDGMENT | DETERMINISTIC_TEST | Schema requires the role field. A test with a skewed device clock produces no event time from the device clock. | NOT TESTED | Part 4 data design | Reject record | Schema validation |

#### 2.3.3 Group C: Risk state, limits and monetary terms (R-012 to R-019)

| ID | Requirement | Priority | Rationale / source | Evidence label | Verification method | Acceptance condition | Status | Evidence pointer | Failure response | Regression checks |
|---|---|---|---|---|---|---|---|---|---|---|
| R-012 | Risk-state records (drawdown-from-peak, daily realized loss, aggregate exposure ledger, open-position-count ledger) are persisted, versioned and integrity-checked. | HARD | Brief risk-state rule; DESIGN_JUDGMENT for versioning | DESIGN_JUDGMENT | DETERMINISTIC_TEST | A checksum mismatch or version gap is detected on load in test. | NOT TESTED | Brief risk-state rule; Part 4 | Triggers R-013 condition | Corruption injection suite |
| R-013 | Missing or corrupt risk state is an unevaluable condition: hard veto, Live refused, CRIT alert. Automatic recovery is restore from a verified backup only. If no verified backup exists, the veto persists until an audited out-of-band reset is performed. The reset never derives values from market or account data. | HARD | Owner brief (risk-state rule) | OWNER_HARD | DETERMINISTIC_TEST | Fault injection yields the veto state. No code path initializes risk state from market or account values (verified by Part 4 design review). | NOT TESTED | Brief; CR-21 | Hard veto; CRIT alert | Fault-injection suite; initialization-path review |
| R-014 | A veto clears only when its underlying recovery condition is satisfied. /ack is a resume gate after recovery only. /ack issued while the condition still fails is refused, and the current state is shown. | HARD | Owner brief (veto clearance) | OWNER_HARD | DETERMINISTIC_TEST | /ack during a failing condition returns a refusal with state. /ack after recovery resumes operation. | NOT TESTED | Brief; Part 4 command contract | Refuse the command | Command matrix tests |
| R-015 | Live is refused unless max drawdown (OD-01) and per-trade risk fraction (OD-02) are defined and within derived bounds. | HARD | Interlock "risk-limit defined" (A10) | OWNER_HARD | DETERMINISTIC_TEST | A Live start with an undefined value is refused with a named reason. | BLOCKED | OD-01, OD-02 pending | Refuse Live | Start-refusal test |
| R-016 | Monetary terms are distinct: nominal stop risk (notional × stop distance plus modelled costs), realized loss, and guaranteed realized-loss cap. The cap exists only with a full hedge and guaranteed fills. | HARD | Definitional correctness | DESIGN_JUDGMENT | CALCULATION | Each report field carries exactly one term. The cap field is absent unless both conditions are evidenced. | NOT TESTED | Part 3 calculation specification | Remove cap label | Label audit |
| R-017 | Leverage is capped by an owner-set maximum (OD-07). Each order is checked against the venue leverage tier table. An unverified tier table refuses orders. | HARD | RATIFIED_FINDING C3; risk-bound logic | RATIFIED_FINDING | DETERMINISTIC_TEST | An order above the cap, or with an unverified tier table, is refused. | BLOCKED | OD-07 pending; public tier-table check not performed in this engagement | Refuse order | Boundary tests at tier edges |
| R-018 | Funding is a tail risk. Every loss or margin estimate includes funding at the observed clamp of −30 bp per funding interval. The ±24 bp cap is not assumed. Funding interval length is UNRESOLVED and is confirmed before use. | HARD | RATIFIED_FINDING C7 (refutation of the ±24 bp cap) | RATIFIED_FINDING | CALCULATION | The stress scenario is present in every margin and loss estimate. | NOT TESTED | C7 | Mark estimate incomplete | Scenario presence check |
| R-019 | Aggregate exposure and open-position-count caps are functions of OD-01 and OD-02. No default value is adopted. | HARD | D17; Part 1 OD register | OWNER_DECISION_PENDING | CALCULATION | Caps are computed as functions with sensitivity output. No literal default exists in configuration. | UNRESOLVED | OD-01, OD-02 | Refuse Live until set | Configuration literal scan |

#### 2.3.4 Group D: Order lifecycle, exchange interaction and interlocks (R-020 to R-031)

| ID | Requirement | Priority | Rationale / source | Evidence label | Verification method | Acceptance condition | Status | Evidence pointer | Failure response | Regression checks |
|---|---|---|---|---|---|---|---|---|---|---|
| R-020 | Order states: INTENT, SUBMITTED, ACKNOWLEDGED, PARTIALLY_FILLED, FILLED, CANCEL_PENDING, CANCELLED, REJECTED, TIMEOUT_AMBIGUOUS, RECONCILING. Every transition is logged with UTC and monotonic stamps. | HARD | DESIGN_JUDGMENT; C5 | DESIGN_JUDGMENT | DETERMINISTIC_TEST | An illegal transition is rejected. Every legal transition is logged. | NOT TESTED | Part 4 order lifecycle | Freeze the order; reconcile | Transition-table test |
| R-021 | Error −1007 (TIMEOUT) maps to TIMEOUT_AMBIGUOUS and never to REJECTED. Exposure is unknown until RECONCILING resolves it. | HARD | RATIFIED_FINDING C5 | RATIFIED_FINDING | DETERMINISTIC_TEST | A mocked −1007 yields TIMEOUT_AMBIGUOUS. REJECTED is not reached. | NOT TESTED | C5 | Hold new orders on that symbol | Mocked timeout suite |
| R-022 | Error −1003 is a rate-limit breach. A cooldown precedes any further request. Repeated breach opens a circuit breaker that refuses new orders. | HARD | RATIFIED_FINDING C5 | RATIFIED_FINDING | DETERMINISTIC_TEST | A mocked −1003 triggers the cooldown. Repeated triggers open the breaker. | NOT TESTED | C5 | Breaker open | Mocked rate-limit suite |
| R-023 | Retries are bounded: a maximum number of attempts and a maximum total elapsed time (monotonic) per action class. Numeric bounds are UNRESOLVED. | HARD | RATIFIED_FINDING C5; brief bounded-retry rule | RATIFIED_FINDING | CALCULATION | Every retry path has finite attempts and a deadline. Bounds are derived from the rate budget and outage class. | UNRESOLVED | Numeric bounds not set. Method: Part 3 derivation. | Retry path disabled | Static check on retry loops |
| R-024 | Rate accounting does not rely on X-Api-Limit-* headers, which are absent (C4). Weight is tracked in an internal ledger with conservative per-endpoint estimates. | HARD | RATIFIED_FINDING C4 | RATIFIED_FINDING | DESIGN_INSPECTION | No header-delta logic appears in the design. The ledger specification is present. | NOT TESTED | C4; Part 4 | Use the conservative estimate | Design review |
| R-025 | clientOrderId uses charset [A-Za-z0-9_-]. The generator enforces it. The length limit is UNRESOLVED and is verified before use. | HARD | RATIFIED_FINDING C11 | RATIFIED_FINDING | DETERMINISTIC_TEST | Generator output matches the pattern in every test case. | NOT TESTED | C11 | Reject the identifier | Pattern property test |
| R-026 | Startup reconciliation: exchange open orders and positions equal the internal ledger before any new order is permitted. | HARD | Interlock 2 (A10) | OWNER_HARD | DETERMINISTIC_TEST | A mismatch blocks new orders. Resolution is logged. | BLOCKED | The authenticated read-only stage was not executed (C25). The engagement has no account access (R-003). | Refuse Live | Mismatch fixtures |
| R-027 | Reconciliation deferral may use the 3-day provisional outage value (C12). This value governs deferral only. The Class-A outage remains undefined. | HARD | RATIFIED_FINDING C12; PD-03 | RATIFIED_FINDING | DESIGN_INSPECTION | Deferral logic references only the provisional value. Outage classes are ratified under OD-05. | UNRESOLVED | OD-05 pending; default class table in Part 4 (DESIGN_JUDGMENT) | Apply default classes | Class-table review |
| R-028 | Cost feasibility uses taker fee 0.06%, the conservative value. The 0.05% documented value is reported as a sensitivity. | HARD | RATIFIED_FINDING C6 | RATIFIED_FINDING | CALCULATION | Both values appear. The 0.06% value drives feasibility results. | NOT TESTED | C6; OD-08 | Flag the output | Output check |
| R-029 | Market-data validity interlock: gaps, staleness, duplicates and out-of-order bars are detected. Failure refuses Live. | HARD | Interlock 1 (A10) | OWNER_HARD | DETERMINISTIC_TEST | Each fault class triggers refusal in the fault-injection suite. | NOT TESTED | A10 | Refuse Live | Data fault-injection suite |
| R-030 | Configuration-integrity interlock: the active configuration is hashed. A hash mismatch refuses Live start. | HARD | Interlock 5 (A10) | OWNER_HARD | DETERMINISTIC_TEST | A tampered configuration refuses the Live start. | NOT TESTED | A10 | Refuse Live start | Tamper test |
| R-031 | Credential and permission interlock is performed at Live start. This engagement performs none of it (A4). | HARD | Interlock 4 (A10); A4 | OWNER_HARD | EXPERIMENT | An owner-authorized read-only check passes before Live start. | BLOCKED | No credentials or account access in this engagement. C25 notes the authenticated read-only stage was not executed. | Refuse Live | Check repeated at each Live start |

#### 2.3.5 Group E: Telegram interface and operator-unreachable behavior (R-032 to R-037)

| ID | Requirement | Priority | Rationale / source | Evidence label | Verification method | Acceptance condition | Status | Evidence pointer | Failure response | Regression checks |
|---|---|---|---|---|---|---|---|---|---|---|
| R-032 | Telegram transport uses long polling by default. A webhook is used only through a justified external relay, evaluated in Part 3. | HARD | Brief A9: no stable inbound connection | OWNER_HARD | DESIGN_INSPECTION | Default transport is outbound polling. Any webhook use cites a relay justification. | NOT TESTED | Brief A9; CR-15 | Use polling | Transport configuration audit |
| R-033 | Telegram unavailability never releases a risk limit, unblocks an unsafe action, or makes an uncertain exchange outcome appear confirmed. | HARD | Brief A9 | OWNER_HARD | DETERMINISTIC_TEST | A simulated Telegram outage leaves veto and limit states unchanged. Uncertain outcomes remain labelled uncertain. | NOT TESTED | Brief A9 | Keep current state; label uncertainty | Outage simulation |
| R-034 | When the operator is unreachable, the policy for open positions and orders is defined per state. Protective exits are placed on the venue where the venue supports them. Venue support for conditional orders is UNRESOLVED. | HARD | Brief A9; OD-06 default (automated exits) | OWNER_HARD | DESIGN_INSPECTION | The policy table covers every order state and every position state. | UNRESOLVED | Venue conditional-order support not verified in this engagement. Part 4 policy table. | Default automated flatten policy per Part 4 | Policy-table completeness check |
| R-035 | Command preconditions are evaluable in the command's own context. Paper-mode commands cannot precondition on clock. A general resume command cannot precondition on per-trade risk. | HARD | Owner command-precondition rule | OWNER_HARD | DETERMINISTIC_TEST | The specification-time evaluator rejects any out-of-context precondition. | NOT TESTED | Part 4 command contract | Specification invalid | Command-specification lint |
| R-036 | Every command has a specification: syntax, preconditions, refusal messages and audit event. An undefined command is refused. | HARD | PD-05 (/ack referenced without a specification) | DESIGN_JUDGMENT | DESIGN_INSPECTION | Part 4 command table is complete. Undefined input is refused. | NOT TESTED | PD-05; Part 4 | Refuse the input | Command-table diff |
| R-037 | Every Telegram message states UTC time, state version and data timestamp. | HARD | Brief A3 | OWNER_HARD | DETERMINISTIC_TEST | The template test covers every message type. | NOT TESTED | Brief A3 | Suppress the non-conforming message | Template test |

#### 2.3.6 Group F: Paper/Live selection and phase structure (R-038 to R-040)

| ID | Requirement | Priority | Rationale / source | Evidence label | Verification method | Acceptance condition | Status | Evidence pointer | Failure response | Regression checks |
|---|---|---|---|---|---|---|---|---|---|---|
| R-038 | The Paper/Live selector is operable through Telegram without waiting periods or return hurdles, subject to the six interlocks. | HARD | Brief A10 | OWNER_HARD | DETERMINISTIC_TEST | The selector switches when all interlocks pass. No time-based or return-based gate exists. | NOT TESTED | Brief A10 | Refuse with reasons (R-039) | Selector test |
| R-039 | Each Live refusal names the failing interlock and the reason, and writes an audit event. | HARD | Brief A10 | OWNER_HARD | DETERMINISTIC_TEST | Each interlock failure yields a named reason and an audit event. | NOT TESTED | Brief A10 | Not applicable | Refusal matrix |
| R-040 | Phase structure is derived from risk (D16). The deviation table has one row per owner-intended phase: training, extended calibration, paper, live. | HARD | D16; D20 | OWNER_HARD | DESIGN_INSPECTION | The table contains four owner-phase rows, each with a disposition. | NOT TESTED | Part 1 §5 deviation record; Part 6 | Part incomplete | Row-count check |

#### 2.3.7 Group G: Universe, data and timeframes (R-041 to R-049)

| ID | Requirement | Priority | Rationale / source | Evidence label | Verification method | Acceptance condition | Status | Evidence pointer | Failure response | Regression checks |
|---|---|---|---|---|---|---|---|---|---|---|
| R-041 | The universe is derived by the D14 nine-step chain with a shown calculation. The Pareto frontier is explicit. | HARD | D14 (OWNER_HARD); breadth preference A7 (OWNER_PREFERENCE) | OWNER_HARD | CALCULATION | Each step lists inputs, formula and outputs. The frontier is listed. | NOT TESTED | Part 3 | Part incomplete | Recalculation check |
| R-042 | The liquidity threshold is a five-element chain: trade-size assumption, book-depth fraction assumption, inequality, solved threshold in USDT, chosen X with label. | HARD | D14 | OWNER_HARD | CALCULATION | All five elements are present. The threshold is a function of the R-019 inputs. | NOT TESTED | Part 3 | Incomplete chain | Element-presence check |
| R-043 | The liquidity snapshot is dated and refreshed before use. The C9 values are a snapshot, not a timeless fact. | HARD | RATIFIED_FINDING C9; OD-14 | RATIFIED_FINDING | SOURCE_CHECK | The snapshot timestamp is recorded. A refresh is run before universe finalization. | UNRESOLVED | OD-14: refresh required; snapshot date unknown | Mark universe provisional | Date-stamp check |
| R-044 | Capacity bounds use the 24-hour notional snapshot. Order-book depth is not a capacity input until OD-11 is resolved. | HARD | RATIFIED_FINDING C8; OD-11 | RATIFIED_FINDING | DESIGN_INSPECTION | No capacity formula references book depth. | UNRESOLVED | OD-11 pending | Use notional only | Formula scan |
| R-045 | The timeframe set is the C1 list used as a ceiling. 3d is excluded (UNSUPPORTED_CONFIRMED). 3m and 8h are LIVE_PASS only on tested paths. No timeframe enters the design without justification. | HARD | RATIFIED_FINDING C1; C25 | RATIFIED_FINDING | DESIGN_INSPECTION | The design timeframe set is a subset of C1 minus 3d. | NOT TESTED | C1; C25 | Remove the timeframe | Set comparison |
| R-046 | Historical request depth is limited to the 3,500-candle cap measured on perpetual symbols. Any longer history uses a stated method. Cross-venue data remains gated by R-004. | HARD | RATIFIED_FINDING C2 | RATIFIED_FINDING | DESIGN_INSPECTION | No lookback claim exceeds the cap without a stated method. | NOT TESTED | C2 | Shorten the lookback | Lookback audit |
| R-047 | Storage and compute sizing scales from the C19 ratio only when the data shape matches (symbol count, timeframe set, series completeness). Otherwise sizing is re-derived. The per-unit figure is UNRESOLVED. | HARD | RATIFIED_FINDING C19; PD-10 | RATIFIED_FINDING | CALCULATION | A shape-match check is recorded. The re-derivation path is specified. | NOT TESTED | C19; CR-11 | Re-derive sizing | Shape check |
| R-048 | Features depending on markPrice or klines.change are excluded from critical paths. The fallback is the close of mark-free candles. | HARD | RATIFIED_FINDING C13; OD-10 | RATIFIED_FINDING | DESIGN_INSPECTION | The feature dependency map shows no critical path on markPrice. | NOT TESTED | C13 | Apply fallback | Dependency scan |
| R-049 | Historical open interest is excluded from the first design. | HARD | RATIFIED_FINDING C26; OD-09 | RATIFIED_FINDING | DESIGN_INSPECTION | No feature references historical open interest. | NOT TESTED | C26 | Remove the feature | Feature scan |

#### 2.3.8 Group H: Device, envelope and deployment (R-050 to R-056)

| ID | Requirement | Priority | Rationale / source | Evidence label | Verification method | Acceptance condition | Status | Evidence pointer | Failure response | Regression checks |
|---|---|---|---|---|---|---|---|---|---|---|
| R-050 | Envelope-first: the workload envelope is derived before device matching. Device bounds come from measurement or are labelled as bounds. | HARD | D15 | OWNER_HARD | CALCULATION | The envelope table precedes the device table. | NOT TESTED | Part 3 | Part incomplete | Order check |
| R-051 | All feasible deployment topologies are enumerated (Step 4b), each marked PASS, PROVISIONAL or FAIL with its gap, before any compromise is selected. | HARD | D15 | OWNER_HARD | DESIGN_INSPECTION | The enumeration covers every topology class listed in Part 3. | NOT TESTED | Part 3 | Return to enumeration | Topology-count check |
| R-052 | Device capacity claims remain PROVISIONAL until a sustained, workload-matched test is run. | HARD | RATIFIED_FINDING C16; OD-12 | RATIFIED_FINDING | EXPERIMENT | The sustained-test protocol is specified. Every capacity claim is labelled. | UNRESOLVED | C16; sustained runtime not measured | Label capacity PROVISIONAL | Protocol review |
| R-053 | Background operation does not depend on a charging exemption. The restricted App Standby Bucket (C15) is addressed by a documented mitigation and a test. | HARD | RATIFIED_FINDING C15 | RATIFIED_FINDING | EXPERIMENT | The mitigation is documented. The background-run test is planned in Part 3. | UNRESOLVED | C15; CR-13 | Device not rated for continuous runtime | Background-run test |
| R-054 | The device runtime environment record (C14) is captured with each test. Termux components are verified against the recorded Android 16 build. | SHOULD | RATIFIED_FINDING C14 | RATIFIED_FINDING | EXPERIMENT | Each test record contains the build, kernel and baseband strings. | NOT TESTED | C14 | Mark result unverifiable | Test-record schema check |
| R-055 | The phone is not a continuous execution host unless a sustained envelope PASS is demonstrated. | HARD | D15; prompt §9.9 position | DESIGN_JUDGMENT | EXPERIMENT | The host decision cites the sustained-test result. | UNRESOLVED | C16; OD-12 | Defer the host decision; no Live on device | Host-decision record |
| R-056 | Remote hosting is not assumed to be paid. Cost and commitment are owner decisions. | HARD | OD-13; A4 | OWNER_DECISION_PENDING | OWNER_DECISION | The owner decision is recorded. | BLOCKED | OD-13 pending | Local-only topology, labelled PROVISIONAL | Decision-register check |

#### 2.3.9 Group I: Research, statistics and verification discipline (R-057 to R-065)

| ID | Requirement | Priority | Rationale / source | Evidence label | Verification method | Acceptance condition | Status | Evidence pointer | Failure response | Regression checks |
|---|---|---|---|---|---|---|---|---|---|---|
| R-057 | No strategy is preemptively accepted or rejected. Statistical checks are verification gates that report evidence, not verdicts (D19). | HARD | D19 | OWNER_HARD | DESIGN_INSPECTION | Verification output states evidence, not a verdict. | NOT TESTED | D19 | Remove verdict language | Language audit |
| R-058 | No exhaustive permutation grid is used at timeframes ≤12h. | HARD | RATIFIED_FINDING C24 | RATIFIED_FINDING | CALCULATION | Grid cardinality is computed. The full grid is rejected at configuration time. | NOT TESTED | C24 | Reject configuration | Cardinality test |
| R-059 | Trial budget: N_max_effective = min(published, recomputed). The recomputed value governs when the two differ by more than 2×. | HARD | RATIFIED_FINDING C22 | RATIFIED_FINDING | CALCULATION | The formula is implemented in the specification and tested on ratio cases. | NOT TESTED | C22 | Use recomputed value | Ratio test vectors |
| R-060 | Trial-budget figures (10–20 at 4h; thousands at 1d) carry PROVISIONAL labels until recomputed. | HARD | RATIFIED_FINDING C23 | RATIFIED_FINDING | DESIGN_INSPECTION | Labels are present wherever the figures appear. | UNRESOLVED | C23; recomputation pending | Apply label | Label check |
| R-061 | MinTRL (19.54 years, C21) and MinBTL are kept distinct. MinTRL inputs are not reproduced in this engagement (PD-08). | HARD | RATIFIED_FINDING C21; PD-08 | RATIFIED_FINDING | SOURCE_CHECK | No MinBTL value is used as MinTRL. | BLOCKED | PD-08: MinTRL inputs absent | Flag figure as unverified | Term audit |
| R-062 | Deflated Sharpe output states its unit before use. The C20 value (≈1.5e-2 at N = 100) is not used for decisions while its unit is unknown. | HARD | RATIFIED_FINDING C20; PD-07 | RATIFIED_FINDING | DESIGN_INSPECTION | The unit field is mandatory in the output schema. | UNRESOLVED | C20; PD-07; CR-18 | Block use of the figure | Schema check |
| R-063 | Cost-per-volatility uses corrected values: 5m = 1.42 and 15m = 0.82 (C10). Maker-only floor applies at 15m and above within the stated scope. | HARD | RATIFIED_FINDING C10 | RATIFIED_FINDING | CALCULATION | Corrected values are in use. Superseded values (0.97, 0.56) do not appear in calculations. | NOT TESTED | C10; CR-03 | Not applicable | Value audit |
| R-064 | Cross-venue basis is used for research at 1h and 4h only. It is not used at 5m and is not used for any purpose beyond research without OD-04. | HARD | RATIFIED_FINDING C18; brief A5 | RATIFIED_FINDING | DETERMINISTIC_TEST | The gate refuses 5m use and any non-research use. | BLOCKED | OD-04 pending | Refuse | Gate test |
| R-065 | No research, citation or benchmark is fabricated. Every numeric claim carries an evidence label and a pointer or a derivation. | HARD | Standing instruction | OWNER_HARD | DESIGN_INSPECTION | Every numeric claim has a label and a pointer or derivation. | NOT TESTED | Standing instruction; Part 6 audit | Remove the claim | Part 6 audit |

#### 2.3.10 Group J: Capital, monetary units and risk-parameter discipline (R-066 to R-069)

| ID | Requirement | Priority | Rationale / source | Evidence label | Verification method | Acceptance condition | Status | Evidence pointer | Failure response | Regression checks |
|---|---|---|---|---|---|---|---|---|---|---|
| R-066 | All monetary quantities are in USDT. USD is never used as a monetary unit. | HARD | Brief A11 | OWNER_HARD | DESIGN_INSPECTION | A text scan finds no monetary term written as USD without T. | NOT TESTED | Brief A11 | Correct the term | Text scan per part |
| R-067 | Capital planning is parametric. The illustrative equity (about 200 USDT) and the planning range (below 500 USDT) are scenario inputs, not sizing defaults. | HARD | Brief A11 | OWNER_HARD | CALCULATION | Sizing formulas take equity as an input. Scenarios are labelled. | NOT TESTED | Brief A11 | Remove the default | Formula review |
| R-068 | The illustrative risk values (15–20% drawdown, 5% per-trade, 10 USDT) are never adopted as defaults. | HARD | Brief D17 | OWNER_HARD | DESIGN_INSPECTION | No default configuration contains these values. | NOT TESTED | Brief D17 | Remove the value | Literal scan |
| R-069 | Every risk-dependent output shows a sensitivity range over a stated parameter span. No single result is presented as the answer before the OD-01 and OD-02 decisions. | HARD | Brief D17 | OWNER_HARD | CALCULATION | A range is present on each risk-dependent output. | NOT TESTED | Brief D17 | Hold the output | Output-schema check |

#### 2.3.11 Group K: Delegation, delivery and process integrity (R-070 to R-077)

| ID | Requirement | Priority | Rationale / source | Evidence label | Verification method | Acceptance condition | Status | Evidence pointer | Failure response | Regression checks |
|---|---|---|---|---|---|---|---|---|---|---|
| R-070 | Delegated decisions (architecture, method, features, parameters, optimizer, language, framework, runtime, libraries) are made by the model with positive derivation (D13). They are not put to the owner. | HARD | Brief A12; D13 | OWNER_HARD | DESIGN_INSPECTION | Each consequential choice has a derivation. | NOT TESTED | Brief A12 | Add derivation | Derivation audit |
| R-071 | An owner question is asked only when all five §2.1.7 conditions hold. | HARD | Brief A13; §2.1.7 | OWNER_HARD | DESIGN_INSPECTION | Each OD item records its five-condition check. | NOT TESTED | Part 1 OD register | Withdraw the question | OD-check audit |
| R-072 | The owner's utility function is not inferred. The risk–return frontier is presented without selecting an outcome. No target return, loss tolerance or trading frequency is asserted. | HARD | OD-03; prompt | OWNER_HARD | DESIGN_INSPECTION | The claim scan finds no asserted target, tolerance or frequency. | BLOCKED | OD-03 pending | Remove the assertion | Claim scan |
| R-073 | Delivery format: principal specification in professional English Markdown; owner-facing progress notes and final summary in Persian; Part N/M numbering; per-part completeness declarations; cross-references. | HARD | Brief D22 | OWNER_HARD | DESIGN_INSPECTION | The format checklist passes for each part. | NOT TESTED | Brief D22 | Correct the part | Format checklist |
| R-074 | Forbidden phrases do not appear in deliverables: "for brevity", "in summary", "to be detailed later", "TBD", "placeholder" without a plan, "draft" as a final deliverable, "at a high level" as a substitute for detail. | HARD | Standing instruction | OWNER_HARD | DETERMINISTIC_TEST | The text scan returns zero matches. | NOT TESTED | Standing instruction | Rewrite the passage | Text scan per part |
| R-075 | The verification matrix row count equals the register row count. At the close of Part 2 the register has 77 rows. Both counts are stated in the completeness declaration. | HARD | Brief §2.2.5; D21 | OWNER_HARD | CALCULATION | Matrix rows equal register rows. | NOT TESTED | Part 5 pending | Part 5 incomplete | Row-count check |
| R-076 | Identifier catalogues contain no duplicate identifiers. | HARD | Brief §2.2.5 | OWNER_HARD | DETERMINISTIC_TEST | The duplicate scan returns zero. | NOT TESTED | Part 6 pending | Correct the identifier | Duplicate scan |
| R-077 | Dependency-first execution (D11). Readiness, completeness or profitability is not claimed before the Part 6 completeness declaration. | HARD | Brief D11; prompt ("a design, not a guarantee of profitability") | OWNER_HARD | DESIGN_INSPECTION | No readiness or profitability claim appears before Part 6. | NOT TESTED | Brief D11 | Retract the claim | Claim scan |

---

### 2.4 Classification of the ratified inputs (C1 to C26)

Each ratified finding is used with its stated scope and is not re-derived. The class describes how the finding constrains the design.

| ID | Ratified scope (as stated) | Class | Design consequence | Linked requirements |
|---|---|---|---|---|
| C1 | Timeframe capability list 1m to 1M is a ceiling, not a target. 3d is UNSUPPORTED_CONFIRMED on three REST kline endpoints. | CAPABILITY_CEILING | Timeframe set is a subset of the ceiling. 3d is excluded. | R-045 |
| C2 | 3,500-candle cap, measured on perpetual symbols. A 1,774-bar 1d sample is about 4.86 years. Census of 58 combinations (of 544 × 14), 36 reached the cap. Not exhaustive. | CAPACITY_FACT (scoped) | Lookback limited to the cap. Census is not a universe. | R-046, R-041 |
| C3 | BTC leverage ladder of 13 tiers down to 1.0×. Maximum permitted leverage UNRESOLVED. | UNRESOLVED_INPUT | Leverage cap is owner-set. Orders check tiers. | R-017, R-019 |
| C4 | X-Api-Limit-* headers absent. | CONSTRAINT | No header-based weight accounting. | R-024 |
| C5 | −1007 TIMEOUT is ambiguous. −1003 is rate-limit breach. Bounded retries are required. | CONSTRAINT | Timeout maps to TIMEOUT_AMBIGUOUS. Rate breach opens cooldown and breaker. | R-021, R-022, R-023, R-020 |
| C6 | Taker fee 0.05% documented vs 0.06% observed. UNRESOLVED. | UNRESOLVED_INPUT | Conservative 0.06% for feasibility. Sensitivity at 0.05%. | R-028 |
| C7 | Funding clamp of −30.0000 bp observed. ±24 bp cap refuted. | REFUTATION | Funding is a tail risk at −30 bp. The ±24 bp cap is not assumed. | R-018 |
| C8 | Order-book depth NON_REPRODUCIBLE. One-sided vs two-sided convention ambiguous. UNRESOLVED. | UNRESOLVED_INPUT | Depth is not a capacity input. | R-044 |
| C9 | Median 24h notional ≈ 498,844 USDT. 134 symbols ≥ 10M USDT. Earlier 515k / 136 superseded. Snapshot, not timeless. | CAPACITY_FACT (snapshot) | Snapshot is dated and refreshed before use. | R-042, R-043 |
| C10 | Cost-per-volatility corrected: 5m = 1.42, 15m = 0.82. Maker-only floor at 15m and above, within stated scope. | CORRECTION | Corrected values only. | R-063 |
| C11 | clientOrderId charset [A-Za-z0-9_-]. | CONSTRAINT | Generator enforces the charset. | R-025 |
| C12 | 3-day outage provisional value. Class-A undefined. Retention UNRESOLVED. Governs reconciliation deferral only. | CONSTRAINT (provisional) | Used for deferral only. Classes ratified under OD-05. | R-027 |
| C13 | markPrice and klines.change semantics CONFLICTED. | RESTRICTION | No critical feature depends on it. Fallback defined. | R-048 |
| C14 | POCO X6 specification record: SoC, RAM, Android 16, build, system, security patch, kernel, baseband, storage 256 GB with 56 GB free at the owner's check. | DEVICE_RECORD | Record is captured per test. Specification is not treated as capacity. | R-054, R-050 |
| C15 | Charging does not exempt an app from the restricted App Standby Bucket. | CONSTRAINT | No design relies on a charging exemption. | R-053 |
| C16 | Sustained runtime NOT MEASURED. 24-hour charging test not representative of training. | UNRESOLVED_INPUT | All device capacity is PROVISIONAL. | R-052, R-055 |
| C17 | Cross-venue candle history to 2019-12-16 for 1H and 5m. Source venue not named. | SCOPE_LIMIT | Source-tagged. Gated by R-004. | R-004 |
| C18 | Cross-venue transfer at 1h: median basis 0.56 bp, return-transfer correlation 0.999755. Defensible for research at 1h and 4h, not at 5m. | RESTRICTION | Research only at 1h and 4h. Gated away from Paper and Live. | R-064 |
| C19 | 1.25 GB for 3,500 candles × 14 timeframes × 10 symbols in one relational file. Used only to calibrate the per-unit ratio. | CAPACITY_FACT (scoped) | Scaling only when the data shape matches. | R-047 |
| C20 | Deflated Sharpe ≈ 1.5e-2 at N = 100 (unit-consistent). Unit not stated in the brief. | UNRESOLVED_INPUT | Unit mandatory. Not used for decisions. | R-062 |
| C21 | MinTRL corrected to 19.54 years. Previous 4.99 years was a MinTRL/MinBTL conflation. | CORRECTION | 19.54 governs. MinBTL kept separate. | R-061 |
| C22 | N_max_effective = min(published, recomputed). Recomputed governs if the two differ by more than 2×. | CONSTRAINT (method) | Formula implemented as stated. | R-059 |
| C23 | Admissible configurations ≈ 10–20 at 4h and thousands at 1d, before sample-length correction. | DECISION_INPUT (PROVISIONAL) | Labelled PROVISIONAL until recomputed. | R-060 |
| C24 | Full permutation grid inadmissible at every timeframe ≤ 12h. | CONSTRAINT | Grid rejected at configuration time. | R-058 |
| C25 | 149-record summary: 134 LIVE_PASS, 10 LIVE_PARTIAL, 3 UNSUPPORTED_CONFIRMED, 2 DOC_CONFLICT. Authenticated read-only stage not executed. Census not exhaustive. | EVIDENCE_STATUS | The archive is not read as 149 passing tests. Authenticated stage remains BLOCKED. | R-026, R-031, R-045 |
| C26 | Historical Open Interest UNRESOLVED. | RESTRICTION | Excluded from the first design. | R-049 |

---

### 2.5 Contradiction and conflict register (CR-01 to CR-21)

| ID | Conflict or ambiguity | Sources | Type | Resolution used in this design | Owner action | Linked requirements |
|---|---|---|---|---|---|---|
| CR-01 | Taker fee 0.05% documented vs 0.06% observed. | C6 | UNRESOLVED conflict | 0.06% drives feasibility. 0.05% is a sensitivity. | OD-08 (non-blocking) | R-028 |
| CR-02 | Liquidity median 515,000 USDT over 136 symbols vs 498,844 USDT over 134. | C9 | SUPERSEDED | The later snapshot is used. The earlier figure is not used. Snapshot dated and refreshed. | OD-14 refresh | R-043 |
| CR-03 | Cost-per-volatility 0.97 / 0.56 vs 1.42 / 0.82. | C10 | CORRECTED | Corrected values only. | None | R-063 |
| CR-04 | MinTRL 4.99 years vs 19.54 years. MinTRL and MinBTL were conflated. | C21; PD-08 | CONFLATION (corrected) | 19.54 years governs. 4.99 years retired. Retired CSCV arithmetic is not reproduced. | None | R-061 |
| CR-05 | Funding cap ±24 bp vs observed −30 bp clamp. | C7 | REFUTED | Cap not assumed. −30 bp used as tail scenario. | None | R-018 |
| CR-06 | markPrice and klines.change semantics conflicted. | C13 | UNRESOLVED | No critical path depends on it. Fallback defined. | OD-10 | R-048 |
| CR-07 | Order-book depth: BTC 90.6M one-sided vs 92.7M under the other convention (USDT-equivalent). NON_REPRODUCIBLE. | C8 | UNRESOLVED / NON_REPRODUCIBLE | Depth excluded from capacity. | OD-11 | R-044 |
| CR-08 | The 149-record summary could be read as 149 passing tests. | C25 | AMBIGUITY (resolved) | Reported as 134 LIVE_PASS, 10 LIVE_PARTIAL, 3 UNSUPPORTED_CONFIRMED, 2 DOC_CONFLICT. Not read as 149 passing. | None. Two DOC_CONFLICT items remain unresolved. | R-026, R-045 |
| CR-09 | A 1,774-bar 1d sample vs the 3,500-candle cap. | C2 | AMBIGUITY (resolved) | 1,774 bars is a sample length (≈4.86 years). The cap of 3,500 bars is ≈9.59 years at 1d under the 365-day convention (PD-09). | None | R-046 |
| CR-10 | The 58-combination census could be read as the universe. | C2 | INCOMPLETENESS | The census is not exhaustive and is not a universe. 36 of 58 reached the cap. | None | R-041, R-046 |
| CR-11 | 2,551 bytes per unit (1.25 GB / 490,000 nominal units) may overstate the unit count. | C19; PD-10 | UNRESOLVED | Per-unit value is UNRESOLVED. Ratio used only when shape matches. | None | R-047 |
| CR-12 | Class-A outage undefined vs a 3-day provisional value. | C12; PD-03 | UNRESOLVED | Default classes proposed (DESIGN_JUDGMENT). 3-day value governs deferral only. | OD-05 | R-027 |
| CR-13 | Assumption that charging keeps the app active vs the App Standby restriction. | C15 | CONFLICT with assumption | Restriction is binding. No charging exemption. | None | R-053 |
| CR-14 | Device specification vs unmeasured sustained runtime. | C14; C16 | EVIDENCE GAP | Specification is a record, not capacity. Capacity is PROVISIONAL. | OD-12 | R-052, R-055 |
| CR-15 | Webhook convenience vs no stable inbound connection (A9). | Brief A9; Part 1 | CONFLICT (resolved) | Long polling is the default. Webhook only through a justified relay. | None | R-032 |
| CR-16 | Prompt example "500 bp × 14,400 s = 720 s". | Owner prompt; PD-06 | ARITHMETIC DEFECT | 500 × 14,400 = 7,200,000. The example is illustrative only and is not used. | None | R-065 |
| CR-17 | Prompt reference to "R-031 onward in a prior run". | Owner prompt; PD-04 | UNSUPPLIED ARTIFACT | Not used. Numbering starts at R-001 for this engagement. | None | R-005 |
| CR-18 | Deflated Sharpe unit not stated. | C20; PD-07 | UNRESOLVED | Unit is a mandatory field. Figure not used for decisions. | None (verification item) | R-062 |
| CR-19 | Any default that maps −1007 to REJECTED would conflict with the ratified finding. | C5 | CONFLICT with ratified finding | Mapped to TIMEOUT_AMBIGUOUS. | None | R-021 |
| CR-20 | Device storage: 56 GB free (C14) vs storage requirement not yet sized. | C14; R-047 | PENDING CHECK | Compared against the sizing in Part 3. | None | R-047 |
| CR-21 | /ack must not clear a veto, while the risk-state rule refers to an "operator acknowledgement" for recovery. | Owner brief; R-013 vs R-014 | CONFLICT (internal) | /ack never clears a veto. Recovery from corrupt state is out-of-band of /ack: verified-backup restore, or an audited out-of-band reset that never derives values from market or account data. | None. Reset procedure is specified in Part 4 as DESIGN_JUDGMENT. | R-013, R-014 |

---

### 2.6 Owner-decision closure map (OD-01 to OD-14)

Each row lists the requirements that must be satisfied before the decision item can be closed, the consequence of leaving it open, and the interim behavior the design uses. Items OD-01 to OD-04 and OD-13 remain OWNER_DECISION_PENDING. OD-06 is not raised now because condition 4 of §2.1.7 (blocking) is not met. Its default is automated exits, and it is raised at the next natural phase transition in Part 6.

| OD | Subject | Status | Requirements that must be satisfied for closure | Blocks | Closing input | Interim behavior |
|---|---|---|---|---|---|---|
| OD-01 | Maximum drawdown limit | OWNER_DECISION_PENDING | R-013, R-015, R-019, R-069 | Live | Owner value, or owner acceptance of the function with its sensitivity range | Live refuses. Paper may use a labelled non-binding value. |
| OD-02 | Per-trade risk fraction | OWNER_DECISION_PENDING | R-015, R-019, R-041, R-069 | Live; universe cut-offs | Owner value, or acceptance of the function with sensitivity | Live refuses. Universe cut-offs stated as functions. |
| OD-03 | Risk appetite and utility | OWNER_DECISION_PENDING | R-069, R-072 | Selection only | Owner statement of preference | Frontier presented. No selection. Architecture not blocked. |
| OD-04 | Cross-venue legal conditions | OWNER_DECISION_PENDING (legal dependency) | R-004, R-064 | Any use beyond research | Legal determination or authorization | Research only. Source-tagged. Gated away from Paper and Live. |
| OD-05 | Outage-class ratification | Default proposed in Part 4 (DESIGN_JUDGMENT) | R-027 | Reconciliation deferral policy | Ratify or amend the class table | Default classes. 3-day value governs deferral only. |
| OD-06 | Exit confirmation style | Default automated exits; not raised now | R-034 | None | Enable optional confirmation gate, if desired | Automated exits. PROVISIONAL. Raised at a phase transition in Part 6. |
| OD-07 | Maximum leverage | UNRESOLVED (owner-set cap required) | R-017 | Orders above the cap | Owner cap | Orders refused above the verified tier limit. |
| OD-08 | Taker fee | UNRESOLVED | R-028 | None | Confirmation through an authorized check, later | 0.06% used. |
| OD-09 | Historical open interest | UNRESOLVED | R-049 | Features that would use it | None required; exclusion holds | Excluded. |
| OD-10 | markPrice semantics | UNRESOLVED (conflicted) | R-048 | None | Verification test, later | Mark-free fallback. |
| OD-11 | Order-book depth convention | UNRESOLVED | R-044 | None | Verification of convention, later | Depth not used for capacity. |
| OD-12 | POCO X6 sustained runtime | UNRESOLVED | R-052, R-055 | Device-hosted live capacity claims | Sustained test result | All device capacity PROVISIONAL. |
| OD-13 | Hosting cost | OWNER_DECISION_PENDING (capital commitment) | R-056 | Remote host choice | Owner commitment decision | Local-only topology, PROVISIONAL. |
| OD-14 | Liquidity snapshot currency | RATIFIED_FINDING; refresh required | R-043 | Universe finalization | Data refresh (not an owner decision) | Snapshot marked provisional. |

---

### 2.7 Cross-part dependencies of the register

The register is an input to Parts 3 to 6. The mapping below states which requirement group each part consumes, and which requirements support each comparison criterion declared in Part 1 (K1 to K7). These criteria are scored in Part 3 only.

**Consumption by part.**

| Group | Requirement IDs | Consumed by |
|---|---|---|
| A | R-001 to R-006 | Part 3 options (K1, K4); Part 4 components; Part 6 audit |
| B | R-007 to R-011 | Part 4 data design; Part 5 boundary and clock vectors |
| C | R-012 to R-019 | Part 3 risk and sizing calculations; Part 4 veto classes |
| D | R-020 to R-031 | Part 4 order lifecycle; Part 5 mocked failure tests |
| E | R-032 to R-037 | Part 4 Telegram command contract; Part 5 outage simulation |
| F | R-038 to R-040 | Part 4 operations; Part 6 phase table |
| G | R-041 to R-049 | Part 3 D14 derivation; Part 4 data design |
| H | R-050 to R-056 | Part 3 envelope and topology enumeration; Part 4 operations; Part 5 sustained-test design |
| I | R-057 to R-065 | Part 5 statistical method and trial budget |
| J | R-066 to R-069 | Part 3 calculations; Part 6 scan |
| K | R-070 to R-077 | Part 5 matrix; Part 6 process audit and identifier checks |

**Support for the comparison criteria (K1 to K7).**

| Criterion | Supporting requirements |
|---|---|
| K1 hard gate | R-002, R-003, R-004, R-007, R-010, R-013, R-015, R-026, R-029, R-030, R-031, R-033, R-039, R-058 |
| K2 envelope fit | R-050 to R-055 |
| K3 verifiability | R-009, R-020 to R-023, R-029, R-058, R-059, R-075 |
| K4 operational burden | R-034, R-036, R-037 |
| K5 reversibility | R-015, R-019, R-040 (classification by decision item in Part 3) |
| K6 cost and resource | R-028, R-056, R-067 |
| K7 explainability | R-065, R-069, R-073 |

---

### 2.8 Register status summary

**Count by priority.** HARD: 76. SHOULD: 1 (R-054). MAY: 0. Check: 76 + 1 + 0 = 77.

**Count by status.**

| Status | Rows | Requirement IDs |
|---|---|---|
| PASS | 2 | R-003, R-005 |
| FAIL | 0 | None |
| BLOCKED | 9 | R-004, R-015, R-017, R-026, R-031, R-056, R-061, R-064, R-072 |
| UNRESOLVED | 12 | R-010, R-019, R-023, R-027, R-034, R-043, R-044, R-052, R-053, R-055, R-060, R-062 |
| NOT TESTED | 54 | R-001, R-002, R-006 to R-009, R-011 to R-014, R-016, R-018, R-020 to R-022, R-024, R-025, R-028 to R-030, R-032, R-033, R-035 to R-042, R-045 to R-051, R-054, R-057 to R-059, R-063, R-065 to R-071, R-073 to R-077 |

**Arithmetic.** 2 + 0 + 9 + 12 + 54 = 77.

No requirement has status PASS without an observed basis. The two PASS rows (R-003 and R-005) rest on the engagement's own conduct, as recorded in Part 1 §3 and the Evidence pointer column. No requirement is marked PASS on the basis of design intent.

---

### 2.9 Part 2/6 completeness declaration (§2.2.5, scope of this part)

| Check | Required | Delivered | Result |
|---|---|---|---|
| Requirement register rows | Every requirement with 11 fields | 77 rows, 11 fields each | Complete for this part |
| Register row arithmetic | Sum of group counts equals total | 6 + 5 + 8 + 12 + 6 + 3 + 9 + 7 + 9 + 4 + 8 = 77 | Consistent |
| Status arithmetic | Sum of status counts equals total | 2 + 0 + 9 + 12 + 54 = 77 | Consistent |
| Priority arithmetic | Sum of priority counts equals total | 76 + 1 + 0 = 77 | Consistent |
| Requirement ID uniqueness and sequence | No duplicate, no gap | R-001 to R-077, sequential | Consistent for this part |
| Ratified inputs classified | 26 of 26 | C1 to C26 | 26 of 26 |
| Contradictions registered | All identified conflicts | CR-01 to CR-21 | 21 entries |
| Owner-decision items mapped | 14 of 14 | OD-01 to OD-14 | 14 of 14 |
| Prompt-integrity items used | PD-01 to PD-12 dispositioned | PD-03, PD-04, PD-05, PD-06, PD-07, PD-08, PD-09, PD-10, PD-11 cited in this part. PD-01 and PD-02 are not referenced by any row in this part; their Part 1 dispositions stand. PD-12 does not apply because the register is not empty. | Dispositioned |
| Verification matrix rows | Equal to register rows (R-075) | Not yet produced | PENDING Part 5. Required count: 77. This is not a pass. |
| Cross-references | Each row cites its source | Each row has an Evidence pointer | Consistent |
| Artifact registry | Updated | ART-08 set to DELIVERED (see §2.10) | Updated |
| Readiness claim | None before Part 6 (R-077) | None made | Compliant |

**Open items carried forward (not blocking Part 3).** OD-01 to OD-04 and OD-13 are OWNER_DECISION_PENDING. The register treats their absence as a Live-blocking condition only. None of them blocks the option generation and comparison in Part 3, because Part 3 presents the frontier as a function of those parameters (R-069).

---

### 2.10 Artifact registry update

| Artifact | Description | Status after Part 2/6 | Scope |
|---|---|---|---|
| ART-08 | Requirements register | DELIVERED | 77 rows (R-001 to R-077), with the sub-tables in §2.4 (classification of C1–C26), §2.5 (CR-01–CR-21), §2.6 (OD-01–OD-14 closure map), §2.7 (dependencies and K1–K7 support), and §2.8 (status summary) |
| Other ART entries | Carried from the Part 1 registry | Unchanged | Not modified in this part |

---

### Next step

Part 3/6 will contain option generation and comparative evaluation under K1 to K7, the deployment topology enumeration (Step 4b), phase derivation (D16), the universe derivation (D14 Steps 1 to 9), the parametric risk and sizing functions, and the liquidity-threshold calculation chain. No owner question blocks Part 3. To continue, reply "Part 3" or "ادامه بده".

---

### خلاصه فارسی

این بخش ثبت کامل الزامات را شامل می‌شود: ۷۷ الزام با یازده فیلد برای هر کدام (۷۶ الزام سخت و یک الزام توصیه‌ای)، طبقه‌بندی ۲۶ ورودی تأییدشده (C1 تا C26)، ثبت ۲۱ تناقض یا ابهام (CR-01 تا CR-21)، و نگاشت ۱۴ قلم تصمیم مالک (OD-01 تا OD-14) به الزامات لازم برای بستن آن‌ها.

وضعیت الزامات: ۲ مورد PASS بر پایه مشاهده، ۹ مورد BLOCKED، ۱۲ مورد UNRESOLVED و ۵۴ مورد NOT TESTED. هیچ الزامی بدون شاهد مشاهده‌شده PASS نشده است. ماتریس تأیید (بخش ۵) هنوز تولید نشده و باید ۷۷ ردیف داشته باشد؛ این وضعیت در بخش ۲ به‌عنوان «در انتظار» ثبت شده است.

تصمیم‌های مالک که هنوز پاسخ داده نشده‌اند (OD-01 تا OD-04 و OD-13) فقط حالت «Live» را مسدود می‌کنند و مانع ادامه طراحی در بخش ۳ نمی‌شوند. برای ادامه، «Part 3» یا «ادامه بده» را ارسال کنید.


# بخش ۳ از ۶: گزینه‌ها، توپولوژی استقرار، فاز، جهان نمادها و توابع ریسک
## Part 3/6: Option Generation, Deployment Topology, Phase Derivation, Universe Derivation, Risk and Sizing Functions

---

### 3.1 Scope, method and evaluation conventions

**Scope.** This part covers five analyses: (a) the workload envelope (D15, derived first); (b) the deployment topology enumeration (Step 4b, completed before any selection); (c) the phase derivation (D16); (d) the universe derivation (D14, Steps 1 to 9) and the five-element liquidity-threshold chain; and (e) the parametric risk, sizing and drawdown functions. It also covers option generation and comparison for the decision families the design must settle (Telegram transport, persistence, runtime language, and strategy-admissibility classes), and the experiments that convert PROVISIONAL and UNRESOLVED items into evidence.

**Method order.** The envelope (§3.3) precedes topology evaluation (§3.4). All nine topologies are enumerated before any is selected (R-051). Phases (§3.5) are derived from risk transitions before the owner's vocabulary is mapped onto them. The universe chain (§3.6) and the liquidity chain (§3.7) precede any universe count. The risk functions (§3.8) take their inputs only from §3.2.

**Status conventions for this part.** These apply to options, topologies and criteria. They are evaluations, not test results.

- `PASS`: the criterion is met on a cited observation or a shown derivation.
- `PROVISIONAL`: the criterion is met only conditionally; the gap is named.
- `FAIL`: the criterion is not met on current evidence.

No register status changes in this part (see §3.12).

**Criteria K1 to K7** (declared in Part 1): K1 hard gate (not compensable); K2 envelope fit; K3 verifiability under the trial budget and injectable failure modes; K4 operational burden; K5 reversibility (REVERSIBLE, COSTLY_REVERSIBLE, IRREVERSIBLE); K6 resource and cost in USDT with date and scope; K7 explainability and reviewability.

**Convention for scenario values.** A numerical value marked `SCENARIO` is used only to demonstrate a function. It is not a design value, not a default, and not a recommendation. Owner-decision parameters (OD-01, OD-02) are shown only as sweeps.

---

### 3.2 Input values used in this part

| Symbol | Meaning | Value used in this part | Label | Basis |
|---|---|---|---|---|
| E | Equity, USDT | 200 (illustrative); planning range below 500, scaled linearly | Owner scenario input (A11), parametric | A11 |
| r | Per-trade risk fraction of current equity | Sweep: 0.25%, 0.5%, 1%, 2%, 3% | OWNER_DECISION_PENDING (OD-02) | OD-02 |
| D | Maximum drawdown fraction | Sweep: 2%, 4%, 6%, 8%, 12% | OWNER_DECISION_PENDING (OD-01) | OD-01 |
| s | Stop distance as fraction of entry price | 0.5% | SCENARIO | Function of volatility and multiplier is set in Part 5 |
| f | Taker fee per side | 0.06% (0.0006) | RATIFIED_FINDING C6, conservative | R-028 |
| φ | Funding stress per funding interval | 0.30% (0.0030) | RATIFIED_FINDING C7 | R-018 |
| k | Funding intervals within a holding | 1 | SCENARIO | Interval length I_f UNRESOLVED |
| ε | Slippage allowance (fraction) | 0 (lower bound) | UNRESOLVED; reported as lower bound | EXP-05 |
| δ | Relative realized-loss overshoot | 0 (lower bound) | UNRESOLVED | EXP-05 |
| β | Liquidity-availability fraction of 24h notional per execution window | 1% | SCENARIO, unmeasured | CR-22 |
| w | Execution window as fraction of 24h | 1/24 (one hour) | SCENARIO | Stated assumption |
| X | Safety multiplier on the raw threshold | 2 | DESIGN_JUDGMENT, PROVISIONAL | Derivation in §3.7 |
| θ | Cost-per-volatility feasibility boundary | 1.0 | DESIGN_JUDGMENT, PROVISIONAL | Derivation in §3.6, Step 3 |
| V_cut | 24h notional value 10,000,000 USDT | Snapshot reference only | RATIFIED_FINDING C9 (count statistic) | Not a design threshold |
| q | Daily loss cap as multiple of D | 1 | DESIGN_JUDGMENT, PROVISIONAL (gap G-1) | §3.8, F8 |
| ℓ_max | Maximum leverage | Symbol only | UNRESOLVED (OD-07) | R-017 |

**Derivation of X = 2.** The raw threshold in §3.7 depends on β, which is unmeasured (CR-22), and on the 24h notional snapshot, which is undated (OD-14). No measured basis fixes a margin. A factor of 2 is adopted as a safety margin for these two unknowns. It is labelled PROVISIONAL, and §3.7 reports sensitivity at X ∈ {1, 2, 4}. It is replaced when EXP-05 and EXP-11 provide measured inputs.

**Derivation of θ = 1.0.** The cost-per-volatility metric is taken as recorded in C10 and is not re-derived. The boundary is set at the value where the cost term equals the volatility scale of the metric. A value above 1.0 means cost alone is at least as large as the volatility scale. The boundary inherits the metric's definition from C10.

---

### 3.3 Workload envelope (D15, derived before device matching)

#### 3.3.1 Workloads and parameters

| Workload | Description | Parameters | Known values | Unknown values |
|---|---|---|---|---|
| W1 Live runtime | Streaming market data, risk checks, order management, reconciliation, Telegram polling | n_L (live symbols), n_tf (live timeframes), W_b (bars held per series), m_s (stream message rate), o_d (order events per day) | Intraday candidate set: 10 timeframes (§3.6) | m_s, o_d, g (overhead), CPU cost per event |
| W2 Paper runtime | Same ingestion as W1 for n_P symbols; simulated fills; no order I/O | n_P, n_tf, W_b | Same as W1 | Same as W1 except order I/O |
| W3 Research batch | Historical evaluation across n_R symbols, n_tf timeframes, N_c configurations | n_R, n_tf, N_c, N_bars per series ≤ 3,500 (C2) | Cap 3,500 bars (C2) | c_eval (CPU per bar per configuration); N_c is bounded by C24 and Part 5 |
| W4 Data refresh | Historical and snapshot retrieval | Requests per refresh, pages per request | None on rate weight (C4 headers absent) | Weight per endpoint; request budget |

#### 3.3.2 Envelope functions

Let b = 48 bytes per bar. This is the minimal numeric representation of six 8-byte fields (open, high, low, close, volume, timestamp). Additional fields scale this linearly.

- **Memory (W1):** M_live(n_L, n_tf, W_b) = M_0 + n_L · n_tf · W_b · b · g, where M_0 is the fixed runtime footprint and g is the interpreter overhead factor. Both are UNRESOLVED and must be measured (EXP-01).
- **Storage (data):** S_data(n_sym, n_tf) = c · Σ(bars). Two values of c are shown. The floor is c = 48 bytes (raw numeric). The C19 ratio is c = 2,551 bytes per candle, obtained as 1.25 GB ÷ 490,000 nominal units (CR-11). The C19 ratio was measured on 10 symbols, so it is not shape-matched to 134 symbols (CR-25).
- **Batch time (W3):** T_batch = N_c · Σ(bars) · c_eval. c_eval is UNRESOLVED (EXP-01).
- **Request weight (W4):** R_req = Σ(weight per endpoint × requests). The weight per endpoint is UNRESOLVED; C4 means it cannot be read from headers.

#### 3.3.3 Computed bounds

| Quantity | Calculation | Result | Label |
|---|---|---|---|
| Intraday candidate series | 134 symbols × 10 timeframes | 1,340 series | DERIVED |
| Bars in intraday set at cap | 1,340 × 3,500 | 4,690,000 bars | DERIVED |
| Raw memory floor, intraday set | 4,690,000 × 48 B | 225.12 MB | DERIVED (floor, excludes g) |
| All timeframes, 134 symbols | 134 × 14 × 3,500 | 6,566,000 bars | DERIVED |
| Raw storage floor, all timeframes | 6,566,000 × 48 B | 315.17 MB | DERIVED (floor) |
| C19-ratio bound, all timeframes | 6,566,000 × 2,551 B | ≈ 16.75 GB | NOT_SHAPE_MATCHED; bound-check only |
| C19 bound as share of free storage | 16.75 ÷ 56 | ≈ 29.9% | DERIVED; 56 GB is the C14 time-sensitive check |
| Raw memory floor as share of device RAM | 0.225 ÷ 12.0 | ≈ 1.9% | DERIVED; 12.0 GB is the C14 spec ceiling, not capacity |

**Interpretation.** At the device spec ceiling, memory and storage floors are not binding. The unknowns that bind are CPU cost per event, sustained behavior under the restricted App Standby Bucket (C15), the weight budget (C4), and the overhead factor g. Every capacity claim is therefore PROVISIONAL (R-052). The C19-based storage bound is reported only as a bound-check, not as a sizing (R-047, CR-25).

**Envelope status: PROVISIONAL.** The floors show that memory and storage are unlikely to be the first limit. Live feasibility on the device is not established until EXP-01 and EXP-02 are run.

---

### 3.4 Deployment topology enumeration (Step 4b)

#### 3.4.1 Enumeration (all candidates listed before evaluation)

| ID | Topology | Roles | Notes |
|---|---|---|---|
| T1 | Phone-only: all roles on POCO X6 under Termux | Research, paper, Live | Live admissible only if EXP-01 and EXP-02 pass |
| T2 | Split: phone hosts research, paper and Telegram; remote host runs Live | Research, paper on phone; Live on host | Two stores; sync needed |
| T3 | Remote host runs all runtime; phone is a Telegram client | Research, paper, Live on host | Single runtime and single risk authority |
| T4 | Owner's non-phone computer runs runtime; phone is Telegram client | Research, paper, Live on computer | Availability of such a computer is not established in the brief; conditional |
| T5 | Interim: phone runs research and paper; Live refused everywhere | Research, paper on phone | No paid host; no Live exposure |
| T6 | T2 or T3 with Telegram webhook through an external relay | As T2 or T3 | Relay is an added component and a third-party dependency |
| T7 | Active-standby pair of remote hosts with single-writer lease | Live on one active host | Duplicate Live orders are the main hazard |
| T8 | Hybrid: Live runtime on host, risk-state authority on phone | Live split | Split authority over risk state |
| T9 | Phone hosts Live with cloud-hosted backup of state only | Live on phone | Backup alone does not remove the device's continuous-runtime gap |

#### 3.4.2 Evaluation matrix

| ID | K1 gate | K2 envelope | K3 verifiability | K4 burden | K5 reversibility | K6 cost (USDT, date, scope) | K7 explainability | Gap that blocks PASS |
|---|---|---|---|---|---|---|---|---|
| T1 | PROVISIONAL: a suspended process cannot evaluate risk; veto is the safe default, but Live liveness is unproven | Research: PROVISIONAL. Live: FAIL under R-055 (sustained and background runtime not measured, C16, C15) | PROVISIONAL: Termux harness and library behavior not verified (EXP-07) | High: power, thermal, Android process lifecycle | REVERSIBLE | No incremental cost identified; device is owner-held | PASS | EXP-01, EXP-02, EXP-07 |
| T2 | PROVISIONAL: two state stores need a sync protocol; Live risk authority is on host | PROVISIONAL (host spec not chosen; envelope in §3.3) | PROVISIONAL: sync faults must be injected | Medium–high | COSTLY_REVERSIBLE | UNRESOLVED: host cost not quoted; OD-13 | PROVISIONAL | OD-13; sync design in Part 4 |
| T3 | PASS: single runtime, single risk authority, single state store | PROVISIONAL (host spec chosen from §3.3 once OD-13 closes) | PASS: all fault injection runs on one runtime | Medium | COSTLY_REVERSIBLE (host commitment) | UNRESOLVED: OD-13 | PASS | OD-13 for cost; host selection |
| T4 | PROVISIONAL: depends on a computer whose availability is not established | PROVISIONAL | PROVISIONAL | Medium | REVERSIBLE | Not quantified (no owned-computer cost data) | PASS | Availability fact; no question is raised, because the design treats it as conditional |
| T5 | PASS: no Live exposure; Telegram polling only | Research and paper: PROVISIONAL (CPU and memory unmeasured) | PASS for Paper and research gates | Low–medium | REVERSIBLE | No new cost | PASS | Only the research and paper envelope needs EXP-01 |
| T6 | PROVISIONAL: relay becomes a trusted-path dependency, which A9 does not require | As the host option it extends | PROVISIONAL | Higher | COSTLY_REVERSIBLE | UNRESOLVED: relay cost | PROVISIONAL | Justification not established; polling satisfies A9 |
| T7 | PROVISIONAL: a single-writer lease must be correct under partition; duplicate-order hazard | PROVISIONAL | PROVISIONAL: lease fault injection | High | COSTLY_REVERSIBLE | FAIL until an owner cost decision exists (two hosts) | PROVISIONAL | Lease design; OD-13; not needed for the first design |
| T8 | FAIL: split risk authority breaches single-writer discipline on risk state | Not evaluated beyond the K1 failure | FAIL: failure modes multiply | High | COSTLY_REVERSIBLE | Not quantified | FAIL | Would need an authority design that is not justified |
| T9 | FAIL: the device continuous-runtime gap is unchanged by a backup; R-055 applies | FAIL (R-055) | PROVISIONAL | High | COSTLY_REVERSIBLE | Not quantified | PROVISIONAL | EXP-01 and EXP-02 |

**Notes on individual evaluations.**

- **T1 and R-055.** Live on the device is refused under R-055 until a sustained, workload-matched test passes. The K1 cell is PROVISIONAL because a veto is K1-compliant, but a veto is not a route to Live. A suspended device still needs a deterministic fail-safe for open positions (R-034).
- **T5 and R-056.** T5 is the interim topology. It is the local-only topology named in R-056's failure response, read as restricted to research and paper (CR-23).
- **T8 rejected.** A risk-state authority on the phone and Live runtime on a host creates two sources of truth for drawdown and exposure. This conflicts with the single-writer rule implied by R-012 and R-013.
- **T7 deferred.** A two-host pair adds a lease and partition hazard that the first design does not need.

#### 3.4.3 Selection

- **Effective now: T5.** Research and paper run on the phone. Live is refused (R-055). Telegram uses outbound long polling (R-032). No paid host is assumed (R-056).
- **Target for Live: T3, conditional.** T3 is recommended because it keeps one runtime and one risk authority (K1 PASS), and its operational burden is lower than T2's. It requires an owner commitment on hosting cost (OD-13) and a host specification derived from §3.3. T3 is not adopted until OD-13 closes.
- **Alternative for Live: T1, conditional.** T1 becomes admissible for Live only if EXP-01 and EXP-02 both pass. It is cheaper than T3 but carries the largest unmeasured gap.
- **Selection order.** The decision is made by K1 first (T8, T9 excluded), then K2 (envelope), then K4, K5 and K6. This is consistent with the Part 1 criteria order.

---

### 3.5 Phase derivation (D16)

#### 3.5.1 Risk transitions that define phase boundaries

| Transition | Capital at risk | Venue state change | Data source change | Risk-limit requirement |
|---|---|---|---|---|
| Research → Paper | None | None (public market feed only; no account; no order endpoints) | Cross-venue data excluded (CR-26) | Paper uses a labelled non-binding OD-01 value (permitted) |
| Paper → Live | Yes | Yes: order endpoints, account state, reconciliation | No change in exclusions | OD-01 and OD-02 must be defined and within bounds (R-015); six interlocks (A10) |
| Live → Paper | Exit: flatten path first | Order cancellation and flatten, per the R-034 policy | No change | None on entry to Paper; open exposure must reach zero or be handed to the policy |

**Phases derived.**

- **P1 Research.** Offline evaluation on historical data. No venue order capability. Cross-venue data permitted under OD-04 conditions and only for 1h and 4h (R-064).
- **P2 Paper.** Public live market feed, simulated fills, no account, no order endpoints. Non-binding labelled risk limits.
- **P3 Live.** Order endpoints enabled. Risk limits defined from OD-01 and OD-02. Six interlocks must pass. No time gate.

No separate phase is derived for "specification" because the specification is a document, not a runtime state.

#### 3.5.2 Deviation table (one row per owner-intended phase, R-040)

| Owner-intended phase | Design disposition | Rationale |
|---|---|---|
| Training | Merged into P1 Research. The label "training" is retained as a run type. | Training carries the same zero capital exposure and the same capability boundary as research. A separate phase adds no risk control. |
| Extended calibration | Merged into P1 Research. The label "calibration" is retained as a run type. | Calibration on longer data is an offline activity with the same boundary. It does not change exposure or venue capability. |
| Paper | Retained as P2 Paper. | Paper is a distinct boundary: live public data with simulated fills and no account. |
| Live | Retained as P3 Live, with restricted capability defined by the OD values. | Live is the only phase where capital is at risk and where venue state changes. |

**Count check.** Four owner-intended phases; four deviation rows.

#### 3.5.3 Consistency with owner constraints

- The selector moves between P2 and P3 without a waiting period or return hurdle (A10). Only the six interlocks gate it.
- Paper-mode commands cannot precondition on clock (R-035). Paper uses no clock-based gate.
- Live refusal names the failing interlock and writes an audit event (R-039).

---

### 3.6 Universe derivation (D14, Steps 1 to 9)

The nine steps below are the design's chain for D14. They are applied in order. Each step lists input, operation and output. Where the output is not computable from the evidence in this engagement, the step says so and names the experiment that closes it.

**Step 1. Timeframe ceiling.**
- Input: C1 list of 14 timeframes (1m, 3m, 5m, 15m, 30m, 1h, 2h, 4h, 6h, 8h, 12h, 1d, 1w, 1M).
- Operation: the list is a ceiling, not a target (C1). 3d is not in this list. It is recorded only because the brief references it as unsupported (UNSUPPORTED_CONFIRMED on three REST kline endpoints).
- Output: ceiling of 14 timeframes.

**Step 2. Style admissibility (A3, A6).**
- Operational definition derived: an intraday position is one that is opened and fully closed within the same UTC day. The daily boundary is the UTC day (A3). The maximum holding duration is therefore H_max = (next 00:00 UTC) − (entry time), bounded above by 24 hours and strictly less. This is derived from A3 and A6, not invented. A stricter cap derived from the holding-time distribution is added in Part 5 if needed.
- Consequence for timeframes: a bar that closes at the UTC day boundary (1d, 1w, 1M) cannot be the entry trigger of an intraday position. The position would be forced flat at that moment. Those timeframes are admitted only as context features.
- Output: entry set of 11 timeframes (1m, 3m, 5m, 15m, 30m, 1h, 2h, 4h, 6h, 8h, 12h). Context-only set of 3 (1d, 1w, 1M).
- Count check: 11 + 3 = 14.

**Step 3. Cost feasibility.**
- Input: ratified cost-per-volatility values (C10): 5m = 1.42 and 15m = 0.82. Boundary θ = 1.0 (§3.2).
- Operation: a timeframe with a ratio above θ is eliminated. A timeframe with a ratio at or below θ is admitted. A timeframe with no ratified value is held as provisional.
- Output:
  - Eliminated: 5m (1.42 > 1.0).
  - Admitted: 15m (0.82 ≤ 1.0), within the stated maker-only floor at 15m and above (C10).
  - Provisional: 1m, 3m, 30m, 1h, 2h, 4h, 6h, 8h, 12h (no ratified value; EXP-04).
- Count check: 1 eliminated + 1 admitted + 9 provisional = 11 entry timeframes.

**Step 4. Data sufficiency.** The sufficiency test depends on the lookback each feature needs (L_req), and no strategy class is yet fixed. L_req is therefore UNRESOLVED, and this step reports coverage only. Coverage at the 3,500-candle cap, under the 365-day convention (PD-09):

| Timeframe | Bars at cap | Coverage | Years |
|---|---|---|---|
| 1m | 3,500 | 2.43 days | 0.007 |
| 3m | 3,500 | 7.29 days | 0.020 |
| 5m | 3,500 | 12.15 days | 0.033 |
| 15m | 3,500 | 36.46 days | 0.100 |
| 30m | 3,500 | 72.92 days | 0.200 |
| 1h | 3,500 | 145.83 days | 0.40 |
| 2h | 3,500 | 291.67 days | 0.80 |
| 4h | 3,500 | 583.33 days | 1.60 |
| 6h | 3,500 | 875 days | 2.40 |
| 8h | 3,500 | 1,166.67 days | 3.20 |
| 12h | 3,500 | 1,750 days | 4.79 |
| 1d | 3,500 | 3,500 days | 9.59 |
| 1w | 3,500 | 24,500 days | 67.12 |
| 1M | 3,500 | 3,500 months (12-month year) | 291.67 |

Output: coverage table. Sufficiency is deferred until L_req is fixed in Part 5. The 1,774-bar 1d sample (C2) is a sample length, not the cap (CR-09).

**Step 5. Liquidity.**
- Input: 24h notional snapshot, median ≈ 498,844 USDT and 134 symbols at or above 10,000,000 USDT (C9). The snapshot is undated (OD-14).
- Operation: a symbol is admitted if its 24h notional is at or above V_min, the threshold computed in §3.7. Under the scenario parameters (r ≤ 9.58%, X = 2), V_min is at most about 3.13 million USDT. Every one of the 134 symbols exceeds it.
- Output: the 134-symbol pool is a lower bound on the scenario-admissible count. Symbols with 24h notional between V_min and 10,000,000 USDT exist but their number is not in the evidence. Closing this requires the full snapshot (EXP-11).

**Step 6. Venue feasibility.**
- Input: minimum executable notional, lot step and price tick per symbol. None were retrieved in this engagement.
- Operation: gate F10 (§3.8) refuses a symbol whose minimum executable notional exceeds the risk-sized notional N_t, because rounding up would breach the cap.
- Output: gate defined; symbol removal UNRESOLVED until EXP-08 runs. This is the basis of proposed amendment A-1 (§3.11).

**Step 7. Leverage feasibility.**
- Input: notional-to-equity ratio N/E from F2 and the owner-set cap ℓ_max (OD-07, UNRESOLVED).
- Operation: a symbol-timeframe is refused if N/E exceeds ℓ_max or if the tier table is unverified (R-017).
- Output: gate defined. At r = 1% and s = 0.5%, N/E ≈ 1.09. No symbol is removed until ℓ_max and the tier table are known (EXP-10).

**Step 8. Source gating.**
- Input: cross-venue basis is research-only at 1h and 4h (C18); CR-26 gates it away from Paper and Live.
- Operation: cross-venue features are removed from the Paper and Live feature sets.
- Output: no symbol is removed. Feature classes are restricted.

**Step 9. Pareto frontier.**
- Axes: data depth (days at cap), cost ratio (where known), maker-only requirement (C10 floor at 15m and above), and breadth (count of admissible pairs).
- Dominance test: timeframe A dominates B if A is at least as good on every axis and strictly better on one. Where an axis is UNRESOLVED, dominance is undecidable and the timeframe stays on the frontier.

| Timeframe | Data depth (days) | Cost ratio | Maker-only (C10 floor) | Cross-venue research | Frontier status |
|---|---|---|---|---|---|
| 1m | 2.43 | UNRESOLVED | Not established | No | Provisional (dominated on depth, cost unknown) |
| 3m | 7.29 | UNRESOLVED | Not established | No | Provisional |
| 5m | 12.15 | 1.42 | Not established | Excluded | Excluded: dominated by 15m (worse cost, worse depth, no maker-only floor established) |
| 15m | 36.46 | 0.82 | Yes | No | Frontier (admitted) |
| 30m | 72.92 | UNRESOLVED | Yes | No | Provisional |
| 1h | 145.83 | UNRESOLVED | Yes | Research only | Provisional (4h dominates on depth; 1h remains on frontier because 4h cost is unknown) |
| 2h | 291.67 | UNRESOLVED | Yes | No | Provisional |
| 4h | 583.33 | UNRESOLVED | Yes | Research only | Provisional |
| 6h | 875 | UNRESOLVED | Yes | No | Provisional |
| 8h | 1,166.67 | UNRESOLVED | Yes | No | Provisional |
| 12h | 1,750 | UNRESOLVED | Yes | No | Provisional |

**Maker-only column.** The C10 floor is stated for 15m and above. Its status for timeframes below 15m is not established in this engagement.

**Provisional frontier.** {15m} ∪ {1m, 3m, 30m, 1h, 2h, 4h, 6h, 8h, 12h}. The frontier cannot be finalized until EXP-04 measures the cost ratio for the provisional timeframes. Breadth preference A7 cannot be assessed against cost until then. This is a finding, not a deferral: the breadth-versus-cost trade-off depends on a measurement that does not yet exist.

#### 3.6.1 Universe output

| Set | Pairs | Derivation |
|---|---|---|
| Symbol pool (Step 5 lower bound) | 134 | C9 snapshot; lower bound at scenario parameters |
| Candidate timeframes after Step 3 | 10 | 11 entry − 1 eliminated |
| Candidate pairs | 1,340 | 134 × 10 |
| Admitted now | 134 | 134 × {15m} |
| Provisional, pending EXP-04 | 1,206 | 134 × 9 |

**Count check:** 134 + 1,206 = 1,340.

**Trial-budget note.** Every admitted or provisional pair adds to the trial count. C23 and C24 constrain that count. Trial budgeting belongs to Part 5. This part reports pairs only.

---

### 3.7 Liquidity-threshold calculation chain (R-042)

The chain has five elements, as required.

**Element 1. Trade-size assumption.** Per-order notional N = r · E / L, from F1 and F2 (§3.8). The assumption is a single clip per order at notional N. Order splitting is not assumed.

**Element 2. Liquidity-availability fraction.** β = 1% of 24h notional may be traded in one execution window. This is named liquidity-availability, not book-depth, because order-book depth is not a capacity input (R-044, C8). The assumption is SCENARIO and unmeasured (CR-22). EXP-05 measures it in the paper phase against simulated and then realized fills.

**Element 3. Inequality.** N ≤ β · w · V24, where w = 1/24 for a one-hour window. Equivalently, V24 ≥ N / (β · w).

**Element 4. Solved threshold.** V_min = X · N / (β · w). With β = 1% and w = 1/24, this becomes V_min = 2,400 · X · N (USDT).

**Element 5. Chosen X.** X = 2, PROVISIONAL (§3.2).

**Worked values (E = 200 USDT, s = 0.5%, k = 1, ε = 0, L = 0.0092).**

| r | Trade notional N (USDT) | Raw threshold 2,400·N (USDT) | V_min with X = 2 (USDT) | V_min as share of 10,000,000 USDT |
|---|---|---|---|---|
| 0.25% | 54.35 | 130,435 | 260,870 | 2.6% |
| 0.5% | 108.70 | 260,870 | 521,739 | 5.2% |
| 1% | 217.39 | 521,739 | 1,043,478 | 10.4% |
| 2% | 434.78 | 1,043,478 | 2,086,957 | 20.9% |
| 3% | 652.17 | 1,565,217 | 3,130,435 | 31.3% |

**Sensitivity to X at r = 1%.** X = 1: 521,739 USDT. X = 2: 1,043,478 USDT. X = 4: 2,086,957 USDT.

**Sensitivity to β.** V_min is inversely proportional to β. β = 0.5% doubles each value in the table. β = 2% halves it.

**Critical risk fraction.** The fraction at which the 10,000,000 USDT snapshot cut becomes the binding liquidity boundary is:

r_crit = V_cut · β · w · L / (X · E)

With the values above, r_crit = 10,000,000 × 0.01 × (1/24) × 0.0092 / (2 × 200) ≈ 0.0958, or about 9.58%. Below r_crit, the 10,000,000 USDT value is not binding under the scenario parameters. This value is a derived sensitivity point, not a recommendation.

**Result.** Under the scenario, liquidity is not the binding universe constraint at r of a few percent. The binding constraints are the venue minimum-size gate (Step 6), cost feasibility (Step 3) and data sufficiency (Step 4). This conclusion depends on the unmeasured β and is PROVISIONAL.

---

### 3.8 Parametric risk, sizing and drawdown functions (D17)

All monetary quantities are in USDT. All functions take E_t (current equity) as input.

**F1. Unit loss factor.**
L = s + 2f + ε + k·φ

- Components: stop distance, round-trip taker fees at the conservative 0.06% (C6), slippage allowance, and funding stress over k intervals at 0.30% (C7, R-018).
- Scenario value: L = 0.005 + 0.0012 + 0 + 0.0030 = 0.0092.
- ε and δ are UNRESOLVED. Their zero values make every result a lower bound.

**F2. Trade notional.**
N_t = min( r · E_t / L , ℓ_max · E_t )

- The first term sizes the trade so that the stressed loss at the stop equals r · E_t.
- The second term is the leverage cap (OD-07). When it binds, the realized stress loss is below r · E_t. Stating this is necessary because ℓ_max is UNRESOLVED.

**F3. Monetary terms (R-016).** Three terms are kept distinct.

- Nominal stop risk: R_nom = N · (s + 2f). This is notional times stop distance plus modeled fees.
- Stress risk: R_st = N · L. This includes funding and slippage allowance, and equals r · E_t when F2's first term binds.
- Realized loss: measured after fills. It is not bounded by F3 terms.
- Guaranteed realized-loss cap: absent. It exists only with a full hedge and guaranteed fills (R-016), and neither is present.

**F4. Leverage check (R-017).** ℓ_impl = N_t / E_t, using full equity as margin in the scenario. Order is refused if ℓ_impl > ℓ_max or if the tier table is unverified.

**F5. Funding stress (R-018).** F_st = N_t · k · φ per funding interval, with k = floor(H / I_f) + 1 within the holding, where I_f is UNRESOLVED and confirmed before use (EXP-09). The sign is treated as adverse for either side. The stress is a tail scenario, not a forecast.

**F6. Breach count (sequential losses, fixed fraction of current equity).**

n*(D, r) = ceil( ln(1 − D) / ln(1 − r_eff) ), with r_eff = r · (1 + δ).

This is the number of consecutive full-size losses that breaches drawdown D from the equity peak. It is a stress count, not a probability. Probabilities depend on the strategy and are assessed in Part 5.

Table of n*(D, r) at δ = 0:

| r \ D | 2% | 4% | 6% | 8% | 12% |
|---|---|---|---|---|---|
| 0.25% | 9 | 17 | 25 | 34 | 52 |
| 0.5% | 5 | 9 | 13 | 17 | 26 |
| 1% | 3 | 5 | 7 | 9 | 13 |
| 2% | 1 | 3 | 4 | 5 | 7 |
| 3% | 1 | 2 | 3 | 3 | 5 |

Spot checks: at r = 1%, D = 8%, after 8 losses equity is down 1 − 0.99⁸ = 7.73% (below 8%), and after 9 it is down 8.65% (at or above 8%). Hence n* = 9.

**F7. Position-count cap (simultaneous exposure, conservative).**

n_pos_max = ceil( D / r_eff ) − 1

This assumes all open positions are sized from the same equity base and stop out together, which is the correlated worst case for intraday crypto positions. It is more conservative than F6, which assumes sequential losses on compounded equity.

- Worked: r = 1%, D = 8% gives n_pos_max = 7. Eight simultaneous 1% stops consume 8%, which is at the limit.
- Worked: r = 2%, D = 8% gives n_pos_max = 3.

**F8. Daily realized-loss cap (gap G-1).** K_day = q · D · E_UTCday_start, measured from equity at the UTC day start, not from the peak. The ratio q is DESIGN_JUDGMENT, PROVISIONAL, with q = 1. At q = 1 the daily check adds no independent limit beyond F6. The owner has not asked for a separate daily limit, and the choice of q does not require one (§3.11).

**F9. Funding example.** At r = 1%, s = 0.5%, one interval: N · φ = 217.39 × 0.0030 = 0.65 USDT, which is about 33% of the 2.00 USDT per-trade risk. Funding is not a minor term at these parameters.

**F10. Minimum executable notional gate (Step 6).** If the venue minimum executable notional m_min,sym > N_t, the trade cannot be sized within r without rounding up. Rounding up would breach the cap, so the order is refused. There is no rounding up.

**Worked example (E = 200 USDT, r = 1%, s = 0.5%, k = 1, ε = 0).**

| Quantity | Value | Function |
|---|---|---|
| L | 0.0092 | F1 |
| N | 217.39 USDT | F2 |
| N / E | 1.087 | F4 |
| R_nom | 1.35 USDT | F3 |
| Funding stress | 0.65 USDT | F5 |
| R_st (= r · E) | 2.00 USDT | F3 |
| n*(8%) | 9 | F6 |
| n_pos_max (8%) | 7 | F7 |

**Sensitivity to r (s = 0.5%, k = 1, E = 200).** Notional N at r = 0.25%, 0.5%, 1%, 2%, 3% is 54.35, 108.70, 217.39, 434.78 and 652.17 USDT respectively. N / E is 0.27, 0.54, 1.09, 2.17 and 3.26 respectively.

**Sensitivity to s (r = 1%, k = 1, E = 200).** N at s = 0.25% is 298.5 USDT. At s = 0.5% it is 217.4 USDT. At s = 1% it is 140.8 USDT.

**Scaling with equity.** All notional values scale linearly with E. At E = 500 and r = 1%, N = 543.48 USDT. The minimum-size gate F10 becomes less binding as E grows.

**Interpretation.** At E = 200 USDT, the minimum executable notional gate (F10) is likely to be the first constraint to bind on many symbols. That cannot be quantified until EXP-08 runs. This is the basis of proposed amendment A-1.

---

### 3.9 Option generation and comparative evaluation

Four decision families are settled here. Strategy selection is not part of this part (D19). The admissibility classes in §3.9.4 limit the design space; they do not accept any strategy.

#### 3.9.1 Telegram transport

| Option | K1 | K2 | K3 | K4 | K5 | K6 | K7 | Result |
|---|---|---|---|---|---|---|---|---|
| O1 Outbound long polling | PASS: no inbound endpoint (A9) | PASS | PASS: deterministic offset handling | Low | REVERSIBLE | No cost | PASS | Selected |
| O2 Direct webhook | FAIL: requires an inbound endpoint (A9) | PASS | PASS | Medium | COSTLY_REVERSIBLE | Hosting cost | PROVISIONAL | Rejected |
| O3 Webhook via relay, host polls relay outbound | PROVISIONAL: relay is a third-party trusted path | PASS | PROVISIONAL | Higher | COSTLY_REVERSIBLE | UNRESOLVED: relay cost | PROVISIONAL | Not adopted; no justification beyond O1 |

**Selected: O1.** Polling satisfies A9 without infrastructure. Its limitation is latency, which the design treats as a Telegram-output property, never as a trading input (R-033). Re-open trigger: a demonstrated polling failure on the target device under EXP-02.

#### 3.9.2 Persistence

| Option | K1 | K2 | K3 | K4 | K5 | K6 | K7 | Result |
|---|---|---|---|---|---|---|---|---|
| P1 Single-file relational store (SQLite, write-ahead logging) | PASS: transactional risk-ledger updates; checksum per record | PASS: floors in §3.3 well below device ceilings | PASS: deterministic fault injection on a single file | Low | REVERSIBLE | No cost | PASS | Selected (PROVISIONAL on Termux availability, EXP-07) |
| P2 Client–server database on host | PASS | PASS | PASS | Medium–high | COSTLY_REVERSIBLE | OD-13 dependency | PROVISIONAL | Conditional on T3 |
| P3 Flat files or JSON | FAIL: no atomic risk-ledger update; R-012 integrity check cannot be made reliable | PASS | PROVISIONAL | Low | REVERSIBLE | No cost | FAIL | Rejected |

**Selected: P1.** The C19 dataset is described as a single relational file (C19), so P1 matches the data shape the owner's own measurement used. This is a shape-match argument for the data, not a claim about C19's per-unit size (R-047). Under T3, P1 remains the store on the host.

#### 3.9.3 Runtime language and framework

| Option | K1 | K2 | K3 | K4 | K5 | K6 | K7 | Result |
|---|---|---|---|---|---|---|---|---|
| L1 Python | PASS | PROVISIONAL: interpreter overhead g unmeasured (EXP-01) | PASS: mature test ecosystem | Low | REVERSIBLE | No cost | PASS | Selected |
| L2 Go | PASS | PROVISIONAL: smaller quant ecosystem; build on device not verified | PASS | Medium | COSTLY_REVERSIBLE | No cost | PASS | Not adopted |
| L3 Rust | PASS | PASS on footprint | PROVISIONAL: longer development and test cycle | High | COSTLY_REVERSIBLE | No cost | PROVISIONAL | Not adopted |

**Selected: L1 (Python), version UNRESOLVED.** The version and the Termux package availability are verified in Part 4 under SOURCE_CHECK. No package availability is assumed. Libraries are chosen in Part 4. Re-open trigger: EXP-01 shows a memory or CPU FAIL at target scale. Then a compiled core is considered for the hot path only, not the whole runtime.

#### 3.9.4 Strategy-admissibility classes

These classes restrict the design space. They do not select a strategy.

| Class | Description | K1 | K3 | Other | Result |
|---|---|---|---|---|---|
| S1 Bar-close intraday, time-stopped, maker entry at 15m and above | Signal on a bar at or below 12h; flat by the UTC day boundary | PASS | PASS: testable within the trial budget | Cost admitted only at 15m (Step 3) | Admitted as a class |
| S2 Intrabar order-book strategies | Signals from book depth | FAIL: the data-validity interlock (A10 item 1) cannot be satisfied, because depth is NON_REPRODUCIBLE (C8) | FAIL: depth cannot be reproduced | Depends on OD-11 | Excluded |
| S3 Cross-venue basis | Basis between venues | FAIL for Paper and Live (CR-26) | PROVISIONAL | Research-only at 1h and 4h (C18) | Admitted as research feature only |
| S4 Daily directional entry | Entry on 1d bars | FAIL for intraday use (Step 2): forced flat at the boundary | PASS | Context use is allowed | Excluded as entry; admitted as context |
| S5 Funding-directed | Signals from funding | PROVISIONAL | PROVISIONAL: I_f UNRESOLVED; tail behavior (C7) | Requires EXP-09 | Provisional research class |

**Result.** S1 is the admitted class for the first design. S3 and S4 have restricted roles. S2 is excluded. S5 is provisional and cannot enter Live until EXP-09 closes.

---

### 3.10 Experiments that convert PROVISIONAL and UNRESOLVED items

No experiment is run in this engagement. Each specification below states its purpose, the requirements or owner decisions it closes, the method, the derived pass form, and where it runs. None of them requires an account, credentials or authenticated calls in this engagement (A4). Experiments that use public endpoints run inside the system's own data refresh, under the system's own permissions, once the system exists.

| ID | Purpose | Closes | Method | Derived pass form | Runs where |
|---|---|---|---|---|---|
| EXP-01 | Sustained workload-matched runtime | R-052, R-055, OD-12 | Run the W1 simulator at target symbol count, charging and discharging, for at least two UTC days | Must span at least one UTC day boundary and one funding timestamp; memory, CPU and event latency logged | Device (T1) and candidate host (T3) |
| EXP-02 | Background execution under restricted App Standby Bucket | R-053, C15 | Schedule timer and polling ticks while the bucket is restricted | Tick jitter and dropped-tick count below the bound derived from the staleness limit of the data-validity interlock | Device |
| EXP-03 | Clock offset against venue time | R-010 | Sample offset across at least seven days, including UTC day boundaries | Tolerance = the smaller of (a) half the smallest candidate bar, 30 s for 1m, and (b) the reconciliation-window ordering bound. If 1m is excluded, bound (a) relaxes to 7.5 min for 15m (half of 15 minutes is 7.5 minutes). | Device and host |
| EXP-04 | Cost-per-volatility for provisional timeframes | R-063, Step 3 | Same metric as C10 for 1m, 3m, 30m, 1h, 2h, 4h, 6h, 8h, 12h | Ratio ≤ θ = 1.0 admits the timeframe; > 1.0 eliminates it | Research phase |
| EXP-05 | Liquidity-availability fraction β | R-042, CR-22 | Paper-phase fills against simulated and realized trade prints | β measured as a distribution; X re-derived from its upper bound | Paper phase |
| EXP-06 | Shape-matched storage ratio | R-047, CR-25 | Store one symbol across all 14 timeframes at full series; measure relational bytes per bar; scale by symbol count only if the shape matches | Ratio measured on the matched shape; C19 ratio not used otherwise | Research phase |
| EXP-07 | Termux and library verification on the recorded build | R-054, C14 | Install the runtime and each library; record build, kernel and baseband strings | Every library imports and runs the test suite on the recorded build | Device |
| EXP-08 | Venue feasibility filters | Step 6, F10, A-1 | Read minimum executable notional, lot step, price tick from the venue's public exchange information | Filters stored per symbol with timestamp; F10 applied | System data refresh |
| EXP-09 | Funding interval length | R-018, S5 | Read the funding schedule from public documentation or endpoint | I_f confirmed before any funding-dependent use | System data refresh |
| EXP-10 | Leverage tier table | R-017, OD-07 | Read the tier table from public endpoints | Table verified with timestamp; orders refused without it | System data refresh |
| EXP-11 | Liquidity snapshot refresh | R-043, OD-14, Step 5 | Refresh the 24h notional snapshot with date | Symbol count at each cut recorded; the full distribution replaces the single 10,000,000 USDT point | System data refresh |
| EXP-12 | Taker fee confirmation | R-028, OD-08 | Confirm the fee schedule from venue documentation | 0.06% kept as the conservative value unless confirmed otherwise | Design-time check, then system refresh |

**Owner dependency.** EXP-12's account-specific fee confirmation, if needed, would require an authorized account check outside this engagement. The design does not depend on it because 0.06% is the conservative value.

---

### 3.11 Contradictions, amendments and gaps

#### 3.11.1 New contradictions (extending the CR register from CR-21)

| ID | Conflict | Sources | Resolution used | Owner action | Linked |
|---|---|---|---|---|---|
| CR-22 | R-042 requires a "book-depth fraction" in the liquidity chain. R-044 and C8 exclude depth as a capacity input. | R-042; R-044; C8 | The element is renamed liquidity-availability and applied to the 24h notional snapshot. It is labelled SCENARIO and unmeasured. | None (EXP-05) | R-042, R-044 |
| CR-23 | R-056's failure response says "local-only topology". R-055 forbids Live on the device without a PASS. | R-055; R-056 | "Local-only" is read as restricted to research and paper (T5). Live is refused until a sustained PASS or a remote host exists. | None | R-055, R-056 |
| CR-24 | R-045 lists 3d as excluded, but 3d is not in the C1 14-item list. | R-045; C1 | The exclusion has no effect on the set. The 3d record is kept as documentation of UNSUPPORTED_CONFIRMED. | None | R-045 |
| CR-25 | R-047 permits scaling from the C19 ratio only when the data shape matches. C19 covers 10 symbols; the design uses 134. | R-047; C19 | Not shape-matched. The 16.75 GB figure is a bound-check only. EXP-06 supplies the sizing. | None | R-047 |
| CR-26 | A5 permits cross-venue data in paper use. C18 gates it away from Paper and Live. | A5; C18 | The more restrictive reading (C18) applies. Re-checked only if OD-04 closes. | OD-04 (existing) | R-004, R-064 |

**Count check.** The CR register now runs from CR-01 to CR-26 with no gaps. The five new entries are CR-22 to CR-26.

#### 3.11.2 Proposed amendment A-1 (register addition, not counted in the 77 rows)

Proposed R-078 (HARD, DESIGN_JUDGMENT):

> Venue feasibility filters (minimum executable notional, lot step, price tick) are retrieved per symbol from the venue's public exchange information, stored with a timestamp, and applied as a pre-trade gate. An order that cannot be sized to the risk cap without rounding up is refused.

- Verification: DESIGN_INSPECTION and DETERMINISTIC_TEST.
- Status: NOT TESTED.
- Acceptance: the gate refuses orders whose rounded size exceeds N_t in a fixture test.
- Evidence pointer: §3.6 Step 6, §3.8 F10, EXP-08.
- Failure response: refuse the order.
- Regression checks: fixture with minimum notional above N_t.

**Adoption.** The amendment is within the design's authority (A12). It is adopted into the register in Part 4. If adopted, the register becomes 78 rows, and the verification matrix in Part 5 and the count in Part 6 must become 78. This is recorded in the propagation log for Part 5 and Part 6.

#### 3.11.3 Gap G-1: daily loss-cap ratio q

The daily realized-loss limit (F8) uses q = 1 as a PROVISIONAL default, so it adds no independent limit beyond the drawdown check. The choice of q depends on the distribution of trades per UTC day, which is a Part 5 output. This is a delegated parameter, not an owner decision. It is not raised as an owner question, because it does not block architecture and its default is safe under the scenario.

---

### 3.12 Register impact

No requirement status changes in Part 3. The register remains at 77 rows: 2 PASS, 0 FAIL, 9 BLOCKED, 12 UNRESOLVED, 54 NOT TESTED. The following rows receive supporting derivation or experiment links in this part.

| Row | Supporting content in Part 3 |
|---|---|
| R-010 | EXP-03 tolerance derivation (§3.10) |
| R-015, R-019 | F2, F7 and the sensitivity tables (§3.8) |
| R-016 | F3 monetary terms (§3.8) |
| R-017 | F4 and F2 leverage check (§3.8); EXP-10 |
| R-018 | F5 and F9 funding stress (§3.8); EXP-09 |
| R-040 | Phase deviation table (§3.5.2) |
| R-041 | D14 Steps 1 to 9 (§3.6) |
| R-042 | Five-element chain (§3.7) |
| R-043 | EXP-11 (§3.10) |
| R-044 | CR-22 (§3.11.1) |
| R-045 | Step 1 and CR-24 |
| R-046 | Step 4 coverage table (§3.6) |
| R-047 | §3.3.3 bound-check, CR-25, EXP-06 |
| R-050 | Envelope before topology (§3.3, §3.4) |
| R-051 | Nine-topology enumeration (§3.4.1) |
| R-052 | EXP-01 (§3.10) |
| R-053 | EXP-02 (§3.10) |
| R-054 | EXP-07 (§3.10) |
| R-055 | T1 and T9 evaluations (§3.4.2) |
| R-056 | T5 interim and CR-23 (§3.4.3, §3.11.1) |
| R-063 | Step 3 with C10 values (§3.6) |
| R-064 | S3 and CR-26 (§3.9.4, §3.11.1) |
| R-069 | Sensitivity tables in §3.7 and §3.8 |
| R-070 | Derivations in §3.2, §3.4.3, §3.9 |

---

### 3.13 Part 3/6 completeness declaration (§2.2.5, scope of this part)

| Check | Required | Delivered | Result |
|---|---|---|---|
| Topologies enumerated before selection (R-051) | All candidates listed first | 9 (T1 to T9), each with K1 to K7 cells | Complete for this part |
| Topology evaluation cells | 9 topologies × 7 criteria | 63 cells in §3.4.2 | Complete |
| Envelope precedes topology (R-050) | Order check | §3.3 precedes §3.4 | Consistent |
| Timeframe accounting | 14 ceiling | 11 entry + 3 context = 14 | Consistent |
| Entry-set accounting | 11 entry | 1 eliminated + 1 admitted + 9 provisional = 11 | Consistent |
| Candidate pairs | Symbol pool × candidate timeframes | 134 × 10 = 1,340 | Consistent |
| Pair split | Admitted + provisional = candidates | 134 + 1,206 = 1,340 | Consistent |
| D14 steps | 9 steps with input, operation, output | Steps 1 to 9 | Complete |
| Liquidity chain elements (R-042) | 5 elements | Elements 1 to 5 with worked values | Complete |
| Owner phases with deviation rows (R-040) | One row per owner phase (4) | 4 rows | Complete |
| Risk functions | F1 to F10 with definitions and worked example | F1 to F10 present | Complete |
| Experiments | Each open item mapped | EXP-01 to EXP-12 mapped | Complete |
| Contradictions | New items registered | CR-22 to CR-26 (5 entries) | Consistent; CR total 26 |
| Owner decisions | Five-condition check for any new question | No new owner question; G-1 is delegated | Compliant |
| Owner decisions still pending | OD-01 to OD-04, OD-13 | Unchanged; they block Live only | Consistent with Part 2 §2.9 |
| Register rows | 77 | 77 (unchanged); A-1 proposed, not counted | Consistent |
| Register statuses changed | None | None | Consistent |
| Forbidden default values | Not adopted (D17) | Sweep values only (0.25% to 3% for r; 2% to 12% for D); no value adopted; 10,000,000 USDT is the C9 count reference | Compliant |
| Monetary units | USDT only (A11) | All monetary values in USDT | Compliant |
| Readiness claim | None before Part 6 (R-077) | None made | Compliant |
| Verification matrix | Equals register rows (R-075) | Not yet produced; Part 5 | PENDING Part 5 (requires 77, or 78 if A-1 is adopted) |

**Open items carried forward.** EXP-01 to EXP-12; amendment A-1; gap G-1; OD-01 to OD-04 and OD-13 (pending); OD-05 to OD-12 and OD-14 as in Part 2 §2.6.

---

### 3.14 Artifact registry update

| Artifact | Description | Status after Part 3/6 | Scope |
|---|---|---|---|
| ART-08 | Requirements register | DELIVERED (Part 2); unchanged | 77 rows; amendment A-1 proposed, not counted |
| ART-09 | Part 3 analytic record | DELIVERED | Envelope, nine-topology enumeration, phase deviation table, D14 Steps 1 to 9, liquidity chain, risk functions F1 to F10, option families, EXP-01 to EXP-12, CR-22 to CR-26, gap G-1 |
| Other entries | As in Part 1 and Part 2 | Unchanged | Not modified in this part |

---

### Next step

Part 4/6 will contain design synthesis: components, state ownership, the order lifecycle, risk authority and veto classes, the Telegram command contract with preconditions and refusal messages, data design using the semantic clock roles of R-011, operations and the procedural-consistency table, the outage classes proposed under OD-05, the library selection under SOURCE_CHECK, and amendment A-1 adoption. No owner question blocks Part 4. To continue, reply "Part 4" or "ادامه بده".

---

### خلاصه فارسی

در این بخش، پنج تحلیل انجام شد: بار کاری و پوشش دستگاه (D15)، شمارش نه توپولوژی استقرار (Step 4b)، استخراج فازها از انتقال‌های ریسک (D16)، زنجیره نه‌مرحله‌ای جهان نمادها (D14) و زنجیره پنج‌عنصری آستانه نقدشوندگی، همراه با توابع ریسک و اندازه‌گیری (F1 تا F10).

**نتایج کلیدی.**
- **توپولوژی:** فعلاً T5 (تحقیق و پیپر روی گوشی، بدون لایو) پذیرفته شد. برای لایو، T3 (میزبان راه‌دور واحد) پیشنهاد شد، مشروط به تصمیم هزینه میزبانی (OD-13). T8 و T9 به‌دلیل تقسیم اقتدار ریسک رد شدند.
- **فازها:** چهار فاز مالک به سه فاز مشتق‌شده نگاشت شد؛ آموزش و کالیبراسیون ادغام شدند و پیپر و لایو حفظ شدند.
- **جهان نمادها:** از ۱۴ تایم‌فریم، ۱۱ تایم‌فریم ورودی درون‌روزی است و ۵m به‌دلیل هزینه (۱٫۴۲) حذف شد. فقط ۱۵m اکنون پذیرفته شده است؛ ۹ تایم‌فریم دیگر تا اندازه‌گیری هزینه (EXP-04) مشروط‌اند. زوج‌های کاندید ۱٬۳۴۰ و زوج‌های پذیرفته‌شده فعلی ۱۳۴ است.
- **نقدشوندگی:** در سناریو، آستانه حدود ۱٫۰ میلیون USDT است و محدودیت اصلی نقدشوندگی نیست؛ محدودیت‌های اصلی حداقل اندازه سفارش، هزینه و داده‌اند.
- **ریسک:** توابع اندازه‌گیری و برداشت، کاهش سرمایه و تعداد پوزیشن با مقادیر حساسیت ارائه شدند. هیچ مقدار پیش‌فرض برای ریسک اتخاذ نشد. در سناریوی ۲۰۰ USDT با ریسک ۱٪، کارمزد تأمین مالی در هر فاصله حدود یک‌سوم ریسک هر معامله است.

**تناقض‌ها و خلأها.** پنج تناقض جدید (CR-22 تا CR-26) ثبت شد، از جمله تناقض بین A5 و C18 درباره استفاده از داده‌های بین‌صرافی در پیپر. پیشنهاد افزودن قاعده R-078 (فیلترهای حداقل سفارش) در بخش ۴ تصمیم‌گیری می‌شود. تعداد ردیف‌های رجیستر هنوز ۷۷ است و هیچ وضعیت الزامی تغییر نکرد.

**پرسش‌های مالک.** این بخش هیچ پرسش جدیدی مطرح نمی‌کند. OD-01 تا OD-04 و OD-13 همچنان در انتظار هستند و فقط حالت Live را مسدود می‌کنند. برای ادامه، «Part 4» یا «ادامه بده» را ارسال کنید.


# بخش ۴ از ۶: طراحی ترکیبی
## Part 4/6: Design Synthesis

این بخش بخش‌های ۱ تا ۳ را به طراحی قابل پیاده‌سازی تبدیل می‌کند. محتوای آن شامل مالکیت اجزا و حالت‌ها، ماشین حالت سفارش، مرجع ریسک و کلاس‌های وتو، قرارداد دستورهای تلگرام، سیاست اپراتور در زمان دردسترس‌نبودن، طراحی داده و ساعت، عملیات، انتخاب کتابخانه‌ها (با برچسب SOURCE_CHECK) و رکوردهای تصمیم است. دو اصلاح محاسبه‌ای و شناسه‌ای، و تصمیم درباره A-1 (R-078) نیز در این بخش ثبت شده است. هیچ سؤال مالکیتی مطرح نشده است. هیچ آزمایشی اجرا نشده، هیچ حساب یا صرافی‌ای دسترسی داده نشده و هیچ بسته‌ای بررسی نشده است.

---

### 4.0 Scope, Inputs, and Conventions

- **Inputs.** Parts 1 to 3 (registers R-001 to R-077, ratified findings C1 to C26, contradictions CR-01 to CR-26, owner decisions OD-01 to OD-14, prompt defects PD-01 to PD-12, experiments EXP-01 to EXP-12, the topology, phase, universe, liquidity and risk-function results), owner constraints A1 to A13, decision rules D11 to D22, and the standing instructions.
- **No observation claimed.** Nothing has been implemented, executed, connected, tested or retrieved. No exchange, package index, Telegram endpoint or device was accessed. Every statement about a venue endpoint, a package or a device behaviour carries SOURCE_CHECK, UNRESOLVED or PROVISIONAL.
- **Design-specified is not PASS.** No register row changes status in this part. R-078 is added (§4.2). The register is 78 rows after this part.
- **No owner question.** OD-06 is not raised here. It is scheduled for Part 6 at the next natural phase transition. Every delegated choice is recorded as a decision record (§4.14).
- **Labels in this part.** DESIGN_JUDGMENT (choice made by this design), DERIVED (computed in this or an earlier part), PROVISIONAL (value or choice to be confirmed), UNRESOLVED (input not established), SOURCE_CHECK (must be verified against a named source before use), SCENARIO (Part 3 scenario value), SCENARIO_NON_BINDING (labelled paper-only value, never a Live input), ILLUSTRATIVE (equity figure), plus the carried labels OWNER_HARD, OWNER_PREFERENCE, RATIFIED_FINDING and OWNER_DECISION_PENDING.
- **New identifier prefixes.** CMP (components), TR (runtime transitions), PC (procedural consistency), RA (authority rules), VC (veto classes), HOLD (hold origins), GT (pre-trade gates), RS (risk-state fields), RST (reset steps), TX and POS (order and position transitions), SU (startup steps), OC and CH (outage classes and channel states), CMD (commands), AUD (audit events), IL (Live interlocks), B (structural bounds), PRM and TM (parameters and timers), BV (bar validity rules), CL (clock classes), LIB (libraries), DR (decision records), GAP-P4 (gaps), CORR-P4 (corrections), PL-P4 (propagation log).
- **Dependency order (D11).** Authority and state ownership first, then the runtime and veto model, then the order lifecycle, then the operator channel and unreachable policy, then data and clock, then operations, then libraries, then decision records. Items that depend on an experiment are marked with the experiment identifier.

---

### 4.1 Corrections to Parts 1 to 3

**CORR-P4-01 (Part 3, §3.6 Step 5): correction of a misstatement.**

- *As delivered:* "Under the scenario parameters (r ≤ 9.58%, X = 2), V_min is at most about 3.13 million USDT."
- *Status:* incorrect. 3,130,435 USDT is V_min at r = 3%. At r_crit ≈ 9.58%, V_min equals V_cut = 10,000,000 USDT.
- *Corrected statement:* Under the scenario parameters (E = 200 USDT, s = 0.5%, k = 1, ε = δ = 0, β = 1%, X = 2, L = 0.0092), V_min rises from 260,870 USDT at r = 0.25% to 3,130,435 USDT at r = 3%, and reaches V_cut = 10,000,000 USDT at r_crit ≈ 9.58%. Below r_crit the 10,000,000 USDT cut is not binding under these parameters.
- *Verification (DERIVED):* V_min = 2,400 · X · N with N = r · E / L. At r = 3%, N = 6 / 0.0092 = 652.17 USDT and V_min = 2,400 · 2 · 652.17 = 3,130,435 USDT. At r_crit, N = 10,000,000 / 4,800 = 2,083.33 USDT and r = N · L / E = 2,083.33 · 0.0092 / 200 = 0.0958.
- *Effect on other Part 3 results.* None. The universe result (134 symbols above the 10,000,000 USDT cut, all above the scenario threshold at r ≈ 1%) is unchanged. The conclusion that liquidity is not the binding universe constraint at r of a few percent still holds: at r = 3%, V_min is 31.3% of the cut.

**CORR-P4-02 (artifact identifiers): recorded for Part 6.**

- Part 2 assigned ART-08 to the requirements register. Part 3 assigned ART-09 to the analytic record. Part 1 defined ART-01 to ART-12, and its assignments were not re-checked against these in Part 3.
- The collision check is carried to Part 6 under R-076. This part assigns ART-10 to the design synthesis record.

**CORR-P4-03 (register count).**

- Part 3 stated 77 rows with A-1 not counted. Adoption of A-1 in §4.2 makes the register 78 rows. Part 3 statements remain accurate as of their issue date. Parts 5 and 6 use 78.

---

### 4.2 Adoption of A-1 as R-078

**Decision: ADOPT.** The text proposed in Part 3, §3.11.2, is adopted verbatim:

> "Venue feasibility filters (minimum executable notional, lot step, price tick) are retrieved per symbol from the venue's public exchange information, stored with a timestamp, and applied as a pre-trade gate. An order that cannot be sized to the risk cap without rounding up is refused."

**Register entry R-078.**

| Field | Value |
|---|---|
| Group | D (exchange interaction, order handling) |
| Priority | HARD |
| Evidence label | DESIGN_JUDGMENT |
| Status | NOT TESTED |
| Verification | DESIGN_INSPECTION and DETERMINISTIC_TEST |
| Acceptance | In a fixture test, the gate refuses any order whose rounded size would exceed N_t (the risk-capped trade notional from F2). |
| Evidence pointers | Part 3 §3.6 Step 6; §3.8 F10; EXP-08; §4.5.4 GT-09 |
| Failure response | Refuse the order and record the refusal in the journal. |
| Regression check | Fixture with a venue minimum notional above N_t. Expected result: refusal, with no order dispatched. |

**Operational reading.** A quantity may be rounded down to the lot step. A quantity is never rounded up. If the rounded-down notional falls below the venue minimum, the order is refused (GT-09). The rounded notional must not exceed N_t.

**Positive derivation (D13).**

- *Option (a), adopt.* Keeps the risk term R_st = N · L consistent with the order actually sent. The caps F7 and F8 and the breach-count function F6 are built on that term.
- *Option (b), rely on venue rounding up.* Rejected. An order larger than N_t makes the realized stop-risk exceed r · E, which invalidates F6, F7 and F8 for that trade without any visible signal.
- *Option (c), defer until EXP-08 provides values.* Rejected. EXP-08 supplies the values. The rule itself is a safety requirement that does not depend on the values.
- *Criteria.* K1 is supported (no hidden excess above the cap). K4 burden is low: one comparison and one fixture. A12 applies: this is within design authority.
- *Register effect.* 78 rows. Group D grows from 12 to 13 rows.

---

### 4.3 Components and State Ownership

The system has two processes. The **Supervisor** is always on and owns the Telegram transport, the command inbox and process lifecycle. The **Runtime** is the trading process that owns every other state. This split is required because operator commands such as /start, /status and /select_live must remain functional when the Runtime is stopped or has crashed (DR-02).

#### 4.3.1 Component table

| ID | Component | Process | Sole writer of | Reads | Veto authority | Release authority |
|---|---|---|---|---|---|---|
| CMP-01 | Supervisor | Supervisor (always on) | Process lifecycle; channel state; inbox intake | Journal; inbox | None | None (forwards /ack to the policy of CMP-04) |
| CMP-02 | Telegram Transport | Inside CMP-01 | Delivery status; allowlist check; update offset | Outbox | None | None |
| CMP-03 | Command Policy Module | Shared library, run by CMP-01 when the Runtime is stopped and by CMP-04 when it runs (same code) | Nothing directly; results written as journal events by the executing component | Journal snapshot | Refuses commands whose preconditions fail | None |
| CMP-04 | Runtime Core | Runtime | Runtime sub-state; mode; HOLD overlay; state_version; scheduler | All | Orchestrates VC transitions through their owners | None beyond owners |
| CMP-05 | Clock Service | Runtime | Clock samples; offset estimate; clock class | None | Raises clock class, which feeds VC-2 | Clears when class returns to OK |
| CMP-06 | Market Data Service | Runtime | Bar store; ingest log; per-symbol validity; instrument filters | Public market data | VC-1 (symbol); VC-2 (connection stale) | Clears on the conditions in §4.5.2 |
| CMP-07 | Strategy Engine | Runtime | Signal records | Knowable bars only | None (no order authority) | None |
| CMP-08 | Risk Gate | Runtime | Risk state RS (sole writer); reservations; veto states | All | Sets VC-2, VC-3, VC-4; refuses entries | VC release by condition; HOLD release by /ack via CMP-04 |
| CMP-09 | Execution Service | Runtime | Order records; order transitions; dispatch markers; order timers | Risk tokens; venue responses | None | None |
| CMP-10 | Exchange Adapter | Runtime | Request signing; weight ledger; cooldown and breaker counters | Venue responses | Sets cooldown (VC-2) and breaker (VC-3) | Cooldown expiry; breaker condition |
| CMP-11 | Reconciliation Service | Runtime | Reconciliation records; UNRECONCILED flags; reconciliation flag | Exchange reads; ledger | Sets VC-3 after bound | Clears on equality (§4.7.2) |
| CMP-12 | Position Manager | Runtime | Position records; exit schedule | Journaled fills | None | None |
| CMP-13 | Integrity Monitor | Runtime | Integrity status (config hash, journal chain, database check, credentials, permissions) | All | Sets VC-4 | VC-4 only through §4.5.6 |
| CMP-14 | Persistence and Journal | Runtime and Supervisor (one database file) | The database file; per-process write queue; hash chain | None | None | None |
| CMP-15 | Snapshot Service | Runtime or Supervisor | Snapshot catalog | Database | None | None |
| CMP-16 | Alert Emitter | Runtime | Outbox messages with envelope and severity | State | None | None |
| CMP-17 | Local Maintenance Console | Local command-line session on the host (not Telegram; no runtime control) | Approval records; restore and reset records, only through the procedures in §4.5.6 and §4.10 | Database | None | Performs the out-of-band reset (RST) only |

**Single-writer rule (DR-01).** Every table or record family has exactly one component that writes it. Every write passes through the write queue of its process. Components may read any table. The two processes write disjoint tables except for the inbox and outbox, where the Supervisor writes intake and the Runtime writes responses.

#### 4.3.2 Placement by deployment profile

| Component group | P-T5 (current effective: phone, research and paper only) | P-T3 (Live target: host, phone is a Telegram client) | P-T1 (alternative: phone with Live) |
|---|---|---|---|
| Supervisor and Telegram Transport (CMP-01, CMP-02) | Phone | Host | Phone |

---

### §4.3.2 Placement Table (Complete)

**Legend.**
- **P-T5:** current effective topology. Phone runs research and paper. Live is refused everywhere (§3.4.3).
- **P-T3:** target Live topology. Remote host runs the runtime and the phone is a Telegram client only.
- **P-T1:** alternative Live topology. Phone runs Live. Admissible only if EXP-01 and EXP-02 both PASS.

| Component group | P-T5 (current effective) | P-T3 (Live target) | P-T1 (Live alternative) |
|---|---|---|---|
| Supervisor and Telegram Transport (CMP-01, CMP-02). Always on. | Phone. Available only while the phone session runs. | Host, always on. The phone is a Telegram client only. | Phone, always on. Available only while the phone session runs. |
| Command Policy Module (CMP-03). Shared code. | Phone. Runs in the Supervisor while the Runtime is stopped and in the Runtime while it runs. | Host. Same execution rule. | Phone. Same execution rule. |
| Runtime Core, Clock Service, Market Data Service, Strategy Engine, Risk Gate, Execution Service, Exchange Adapter, Reconciliation Service, Position Manager, Integrity Monitor (CMP-04 to CMP-13). | Phone, research and paper modes only. Order-capable code is present but disabled: GT-01 refuses every dispatch and VC-4 is set as a hard veto. | Host, Live capable. | Phone, Live capable only after EXP-01 and EXP-02 PASS. Otherwise refused. |
| Persistence and Journal (CMP-14). One database file. | Phone storage. | Host storage. | Phone storage. |
| Snapshot Service (CMP-15). | Phone. | Host. | Phone. |
| Alert Emitter (CMP-16). Runtime outbox. | Phone. | Host. | Phone. |
| Local Maintenance Console (CMP-17). No network listener. | Phone, local Termux session only. | Host, local session on the host console. The design adds no network listener for it. | Phone, local Termux session only. |
| Research batch and data refresh (W3, W4). | Phone. | Host. | Phone. Research jobs are suspended while Live runs (DESIGN_JUDGMENT, because both compete for the same CPU and battery budget). |
| Live order endpoints (W1). | Not reachable. Live is refused (R-055). | Host. | Phone, only after EXP-01 and EXP-02 PASS. |
| Paper simulator (W2). | Phone. | Host, optional. | Phone. |

**Derivation (D13).**
- **Option (a), chosen:** under P-T3, the Supervisor and Telegram Transport run on the host. The host is the only always-on device in P-T3. The Supervisor must remain reachable when the Runtime is stopped (DR-02), so it must run where the Runtime runs.
- **Option (b), rejected:** under P-T3, the Supervisor runs on the phone. This would require the phone to run continuously, which R-055 forbids. It would also make Telegram command handling depend on the phone's session state, while the Runtime runs elsewhere.
- **Consequence under P-T5:** the operator interface is available only while the phone's Supervisor process is alive. This is consistent with R-033 and A9. Under P-T5 Live is refused, so no open exchange risk can exist, and an unreachable operator cannot release a limit or confirm an outcome.
- **Single-writer check:** each placement keeps the single-writer rule (DR-01). No placement gives two writers the same table.

---

### §4.4 Runtime and Veto Model

#### §4.4.1 Process and Runtime States

Two processes exist (DR-02): the Supervisor, always on, and the Runtime, the trading process.

| State | Owner | Meaning | Entry condition | Exit condition |
|---|---|---|---|---|
| STOPPED | Supervisor | Runtime process not running. | Initial state, clean stop, or crash detected. | /start accepted by the policy module (§4.8). |
| INIT | Runtime | Configuration loaded; integrity procedure running. | Process start. | Integrity procedure IP-1 to IP-8 complete (§4.5.6). Failure keeps VC-4 active. |
| RECONCILING | Runtime | Live only: exchange state compared with the ledger. Paper mode skips exchange reconciliation. | INIT complete. | Equality (§4.7.2) or VC-3 set. |
| RUNNING | Runtime | Normal operation in the selected mode. | Reconciliation complete. | Crash, process exit, or CMP-17 stop. |
| HOLD (overlay, not a state) | Runtime | Blocks risk-increasing actions while RUNNING. Risk-reducing actions remain allowed (RA-5). | Any HOLD origin in §4.4.4. | Release condition of the origin. |

**Stop rule (derived).** The design defines no Telegram stop command. Stopping the Runtime while positions or orders are open is a risk decision. A remote stop could leave an unmanaged exposure. The Runtime stops only by process exit, crash, or the local console (CMP-17). Under P-T3 and P-T1 the Runtime keeps running when the operator is unreachable (§4.9).

**Mode.** Mode is PAPER or LIVE. /select_paper and /select_live change it (§4.8). Each change is a phase transition and sets HOLD origin H4 for its duration (§4.4.4).

#### §4.4.2 Veto Classes

Four veto classes gate every action. Each class has one owner that sets and clears it (RA-1).

| Class | Scope | Set by | Effect on entries | Effect on risk-reducing actions | Release | Clearable by /ack |
|---|---|---|---|---|---|---|
| VC-1 Symbol | One symbol | CMP-06 (data validity, instrument filter). | Refuses entries on that symbol only. | Allowed (RA-5). | Conditions in §4.5.2 (VC-1 row). | No. |
| VC-2 Connection and clock | Global for entries | CMP-05 (clock class), CMP-06 (connection stale), CMP-10 (cooldown after -1003). CMP-08 computes the aggregate. | Refuses all risk-increasing actions. | Allowed (RA-5). | Conditions in §4.5.2 (VC-2 row). | No. |
| VC-3 Breaker and reconciliation | Global, or one symbol for an UNRECONCILED flag | CMP-10 (circuit breaker), CMP-11 (reconciliation after bound). CMP-08 computes the aggregate. | Refuses all risk-increasing actions. | Allowed (RA-5). | Breaker: §4.5.2. Reconciliation: equality (§4.7.2). | No. |
| VC-4 Integrity and risk state (hard) | Global | CMP-08 (RS missing or corrupt, or GT-05 failure), CMP-13 (config hash, journal chain, database check, credentials, withdrawal permission). | Refuses all risk-increasing actions. | Allowed through the flatten path (RA-5). | Only through §4.5.6. | No. |

#### §4.4.3 Authority Rules

- **RA-1 Single owner.** Each veto class has one owner that sets and clears its state. VC-2 and VC-3 have several source flags, one per source component. CMP-08 writes only the aggregate.
- **RA-2 Journal-evaluated release.** A release condition is evaluated against the journal state, not against an operator instruction or a component's own report.
- **RA-3 /ack scope.** /ack releases only the HOLD origin OPERATOR_REVIEW (H5). It takes effect only when no VC is active. If a VC is active, /ack is refused and the current state is shown (R-014). /ack never clears VC-1, VC-2, VC-3, or VC-4.
- **RA-4 Silence has no effect.** Telegram loss, Telegram delay, and operator absence have no effect on any veto class or HOLD origin (R-033, A9).
- **RA-5 Risk-reducing path.** Flatten and exit orders are allowed under every veto class. Under VC-4, the flatten path reads exchange-reported positions only to reduce exposure. It does not write RS. Each such action is logged as UNRECONCILED_ACTION so that reconciliation covers it later.
- **RA-6 Durable state.** Every veto state is persisted and reloaded at start. On start, an absent or unreadable RS record sets VC-4. Absent evidence for VC-2 or VC-3 is treated as active until current evidence clears it.
- **RA-7 No silent downgrade.** No component may lower the severity of a veto set by another owner. Lowering happens only through the owner's release condition.

#### §4.4.4 HOLD Origins

| Origin | Set by | Trigger | Release | Telegram effect |
|---|---|---|---|---|
| H1 Restart | CMP-04 | Process started after a crash or unclean exit. | Integrity procedure and reconciliation complete. | None. |
| H2 Reconciliation pending | CMP-11 | Reconciliation not yet equal after restart or after a reconnect. | Equality (§4.7.2). | None. |
| H3 Hard veto | CMP-08 | Any VC set at hard severity (VC-4). | Clearing of the veto (§4.5.6). | None. |
| H4 Phase transition | CMP-04 | Mode change in progress. | Transition completes or fails with a recorded reason. | None. |
| H5 Operator review | CMP-04 | Set after a refused flatten, after an AMBIGUOUS order reaches RECONCILE_REQUIRED, or after a CRIT alert. | /ack, only when no VC is active (RA-3). | /ack is the only release. |

---

### §4.5 Risk Authority and Pre-Trade Gates

#### §4.5.1 Risk-State Record (RS)

Only CMP-08 writes RS. RS is versioned and checksummed. Its version is recorded in each journal entry that depends on it.

| Field | Type | Meaning |
|---|---|---|
| rs_version | integer | Monotonic. Incremented on each write. |
| rs_flag | enum: NORMAL, RESET, RESTORED | Origin of the current version. |
| equity_peak_usdt | decimal (USDT) | Peak equity used for drawdown-from-peak. Set from attested baseline or from journaled history. |
| equity_current_usdt | decimal (USDT) | Latest verified equity from a journaled ledger entry. |
| drawdown_pct | decimal | (equity_peak − equity_current) / equity_peak. Computed; never an input. |
| day_key_utc | date | UTC date of the daily-loss ledger. |
| day_start_equity_usdt | decimal (USDT) | Equity at 00:00 UTC of day_key_utc (F8 basis). |
| daily_realized_loss_usdt | decimal (USDT) | Realized loss on day_key_utc, measured after fills. |
| exposure_ledger_usdt | decimal (USDT) | Aggregate nominal exposure of open positions and reservations. |
| open_position_count | integer | Open positions plus reservations. |
| reservations | list | Open reservation tokens with clientOrderId and reserved amount. |
| baseline_source | enum: JOURNAL, OWNER_ATTESTED | Source of the baseline values. Used only in RST (§4.5.5). |
| last_verified_utc | timestamp (UTC) | Last successful IP-3 check. |
| checksum | hash | Over all fields except itself. |

#### §4.5.2 Release Conditions for VC-1, VC-2, VC-3

| Class | Release condition | Parameter status |
|---|---|---|
| VC-1 Symbol | The symbol has N_v consecutive validated bars on the entry timeframe with no gap, staleness, duplicate, or out-of-order defect (§4.11 BV rules). | N_v = 2 (PROVISIONAL, DESIGN_JUDGMENT). Final value set in Part 5. |
| VC-2 Connection and clock | The clock class is OK for N_c consecutive samples (CMP-05), and at least one successful heartbeat has occurred within the staleness limit (§4.11). | N_c = 3 (PROVISIONAL, DESIGN_JUDGMENT). Staleness limit from §4.11. |
| VC-3 Breaker | The circuit breaker was opened by repeated −1003. It closes only when the cooldown has elapsed and the monitoring window contains zero −1003 responses. | Window length UNRESOLVED (Part 5 derivation). |
| VC-3 Reconciliation | Equality (§4.7.2) for the affected scope. | Defined in §4.7. |
| VC-4 | Only through §4.5.6. | Not applicable here. |

#### §4.5.3 Gate Sequence GT-01 to GT-08

Every risk-increasing action passes all gates in order. A failure stops evaluation at that gate. The refusal is journaled with its code. GT-09 is defined in §4.5.4.

| Gate | Checks | Pass rule | Refusal code |
|---|---|---|---|
| GT-01 Mode and endpoint | Mode and endpoint state. | Mode is LIVE, and order endpoints are enabled by IP-1 to IP-8. Paper never dispatches. | GT01_MODE_NOT_LIVE |
| GT-02 Veto | Veto state for the symbol and globally. | No VC-1 for the symbol. No VC-2, VC-3, or VC-4 active. No HOLD origin active for entries. | GT02_VETO_ACTIVE (with class ID) |
| GT-03 Clock | Clock class (R-010). | Class is OK. | GT03_CLOCK_NOT_OK |
| GT-04 Data and knowability | Signal bar status and symbol validity. | Bar is closed and knowable per BV rules (§4.11). Symbol validity is VALID. | GT04_BAR_NOT_KNOWABLE |
| GT-05 Risk state | RS presence, checksum, version. | RS readable, checksum valid, rs_version at least the journal head value. | GT05_RS_INVALID (also sets VC-4) |
| GT-06 Limits | Four limits. (a) Drawdown: drawdown_pct is below D_max (OD-01). (b) Position count: open_position_count + 1 is at most n_pos_max (F7). (c) Aggregate exposure: exposure_ledger + N_t is at most E_agg, where E_agg = c_agg · E and c_agg is owner-set (OD-01, OD-02, no default). (d) Daily loss: daily_realized_loss + projected loss is at most K_day (F8). | All four pass. Reservation written atomically in the same journal transaction. | GT06_LIMIT_EXCEEDED (with limit name) |
| GT-07 Leverage | F4 implied leverage and tier table. | ℓ_impl is at most ℓ_max (OD-07), and the tier table is verified with a timestamp (EXP-10). | GT07_LEVERAGE_OVER_CAP or GT07_LEVERAGE_UNVERIFIED |
| GT-08 Funding | F5 funding stress with I_f. | Stress is computed and recorded in the reservation. A funding-dependent class (S5) requires I_f confirmed (EXP-09). S1 entries proceed with F5 stress recorded. | GT08_FUNDING_UNCONFIRMED (S5 only) |

**Note.** GT-06 uses D_max and n_pos_max as functions of OD-01 and OD-02. No literal default is used (D17, R-019). Until the owner defines them, Live is refused at GT-06 (R-015).

#### §4.5.4 GT-09 Venue Feasibility (Adopted R-078)

GT-09 implements R-078. It applies to every risk-increasing order before dispatch.

**Inputs.** Venue filters per symbol: minimum executable notional m_min, lot step s_lot, price tick t_px. Each filter record carries the retrieval UTC timestamp (EXP-08). Maximum filter age: PROVISIONAL, set to 24 hours (DESIGN_JUDGMENT, conservative). The final value is set in Part 5.

**Procedure.**
1. q_raw = N_t / p, where p is the order price (the limit price, or the reference price for a market order when one is permitted).
2. q = floor(q_raw / s_lot) · s_lot. Quantity is rounded down only, never up.
3. p_order = p rounded to the tick t_px. A buy limit price is rounded down, and a sell limit price is rounded up, so rounding never increases risk.
4. Notional n_r = q · p_order.
5. Refuse if n_r < m_min (GT09_BELOW_MIN_NOTIONAL).
6. Refuse if n_r > N_t. Under rule 2 this cannot occur for a correctly computed quantity, so it is an internal consistency check. A violation sets VC-4.
7. Refuse if the filter record is missing (GT09_FILTER_MISSING) or older than the maximum age (GT09_FILTER_STALE).

**Derivation (D13).**
- **Option (a), adopted:** round down, refuse below minimum.
- **Option (b), rejected:** rely on venue rounding up. An oversized order makes realized stop-risk exceed r · E and silently invalidates F6, F7, and F8.
- **Option (c), rejected:** defer until EXP-08 completes. The rule is a safety requirement that does not depend on the values.

#### §4.5.5 Risk-State Reset (RST), Local Console Only

RST is executed only by CMP-17. It is the out-of-band reset named in R-013. The procedure never derives RS values from market or account data.

| Step | Action |
|---|---|
| RST-1 | Refuse unless the Runtime process is STOPPED. |
| RST-2 | Preserve the corrupt RS file and a hashed copy of the journal. Overwriting evidence is forbidden. |
| RST-3 | Check for a verified backup (§4.10). If one exists, the restore path is used instead, and the reset is refused. |
| RST-4 | The owner enters two baseline values on the local console: equity_peak_usdt and day_start_equity_usdt, both in USDT. Each is recorded as OWNER_ATTESTED with the UTC time of entry. |
| RST-5 | Counters are not seeded from the exchange. exposure_ledger_usdt and open_position_count are set to the sentinel UNKNOWN_RECONCILE_REQUIRED. VC-3 is set until reconciliation (§4.7) sets exact values. |
| RST-6 | Write RS with rs_version = previous + 1, rs_flag = RESET, and a checksum. Journal event RST_APPLIED is written. |
| RST-7 | Set H1 HOLD. VC-4 clears only after IP-1 to IP-8 pass (§4.5.6). |
| RST-8 | Emit AUD-RST to the audit log and a CRIT alert to the outbox. |

**Derivation (D13).** The reset must not turn an unknown exposure into a zero exposure. Keeping the sentinel and requiring reconciliation prevents this. Using exchange data as the baseline would violate R-013. The owner-attested baseline is the only remaining source, and it is recorded as attested.

#### §4.5.6 Integrity Procedure (IP) and Interlock Mapping

IP is the only route that clears VC-4. It runs at INIT, after each RST or restore, at each UTC day boundary, and before every mode transition.

| Step | Check | Failure result |
|---|---|---|
| IP-1 | Database file integrity check and page checksums (SQLite). | VC-4 remains. CRIT alert. |
| IP-2 | Journal hash chain verified from the last checkpoint. | VC-4 remains. |
| IP-3 | RS checksum valid. rs_version is at least the journal's last recorded RS version. | GT-05 failure. VC-4 remains. |
| IP-4 | Configuration hash equals the approved hash in the journal (CMP-13). An unapproved change is a failure. | VC-4 remains. |
| IP-5 | Credential present in the local secure store. Withdrawal permission is absent. Trading permission is present (R-031). Unknown state is a failure. | VC-4 remains. |
| IP-6 | Risk limits defined and within bounds (OD-01, OD-02 defined). | Live refused. VC-4 not set for paper. |
| IP-7 | All of IP-1 to IP-6 pass. | VC-4 cleared. Event IP_PASS journaled. |
| IP-8 | Any failure. | Alert with the failing check ID. VC-4 remains. |

**Interlock mapping (R-038, six correctness interlocks for the selector).**

| Interlock | Enforced by |
|---|---|
| 1. Data validity | VC-1 and GT-04 (§4.11 BV rules). |
| 2. Reconciliation (exchange equals ledger) | VC-3 and §4.7.2. |
| 3. Risk-limit definition within bounds | IP-6 and GT-06. |
| 4. Credential and permission check | IP-5. |
| 5. Configuration integrity | IP-4. |
| 6. Clock offset within tolerance | VC-2, GT-03, and EXP-03. |

Each interlock failure produces a refusal message that names the interlock, the reason, and the audit event (R-039).

---

### §4.6 Order and Position Lifecycle

#### §4.6.1 Order States

| State | Meaning |
|---|---|
| OS-INTENT | Signal produced. No reservation yet. |
| OS-RESERVED | All gates GT-01 to GT-09 passed. Reservation written. |
| OS-DISPATCHING | Dispatch marker written with clientOrderId before any request is sent. |
| OS-OPEN | Venue acknowledged the order with a venue order ID. |
| OS-PARTIAL | Partially filled. |
| OS-FILLED | Fully filled. |
| OS-CANCEL_REQ | Cancel requested. Awaiting venue confirmation. |
| OS-CANCELED | Venue confirmed cancellation. |
| OS-REJECTED | Venue explicitly rejected the order with a rejection code. Timeout is never a rejection. |
| OS-AMBIGUOUS | Outcome unknown (for example, −1007, −1003, or transport failure without response). |
| OS-RECONCILE_REQUIRED | Query bounds exhausted. Outcome unknown. VC-3 set for the symbol. |
| OS-EXPIRED | Venue expiry, or design time-stop from the order timer. |

#### §4.6.2 Order Transitions

| ID | From → To | Trigger | Guard | Action and log |
|---|---|---|---|---|
| TX-01 | (none) → OS-INTENT | Strategy signal on a knowable bar. | GT-04 passed. | Intent journaled with signal ID. |
| TX-02 | OS-INTENT → OS-RESERVED | Gate sequence. | GT-01 to GT-09 all pass. | Reservation token written in one transaction with the RS update (RS version incremented). |
| TX-02R | OS-INTENT → (refused) | Any gate fails. | Failing gate code. | Refusal journaled. No order record beyond the refusal. |
| TX-03 | OS-RESERVED → OS-DISPATCHING | Dispatch decision. | Reservation valid and not expired. | Dispatch marker with clientOrderId written before sending. |
| TX-04 | OS-DISPATCHING → OS-OPEN | Venue acknowledgment with venue order ID. | Response matches clientOrderId. | Venue ID journaled. |
| TX-05 | OS-DISPATCHING → OS-REJECTED | Explicit venue rejection with a rejection code. | Code is a documented rejection (SOURCE_CHECK). | Reservation released, with RS update. |
| TX-06 | OS-DISPATCHING → OS-AMBIGUOUS | −1007 TIMEOUT, transport failure without response, or −1003. | Always. −1003 is treated as ambiguous unless its non-execution is confirmed (SOURCE_CHECK). | Reservation kept. No release. |
| TX-07 | OS-AMBIGUOUS → OS-OPEN, OS-FILLED, or OS-REJECTED | Query by clientOrderId returns a definite state. | Query bounded: Q_max = 3 attempts, backoff 2 s then 4 s (PROVISIONAL, final values in Part 5). | Journaled with the query evidence. |
| TX-08 | OS-AMBIGUOUS → OS-RECONCILE_REQUIRED | All Q_max queries end without a definite state. | Bound exhausted. | VC-3 set for the symbol. H5 HOLD set. No resubmission. |
| TX-09 | OS-OPEN → OS-PARTIAL → OS-FILLED | Fill events. | Fill matches venue order ID. | Fills journaled. Position manager updates (CMP-12). |
| TX-10 | OS-OPEN → OS-CANCEL_REQ → OS-CANCELED | Cancel decision, then venue confirmation. | Confirmation matches the order. An ambiguous cancel is handled like TX-06 to TX-08. | Journaled. |
| TX-11 | OS-OPEN → OS-EXPIRED | Venue expiry or design time-stop. | Order timer. | Journaled. |

**Retry rules (R-023, bounded).**
- Entry orders are never resubmitted automatically. An ambiguous entry is resolved by query (TX-07) or reconciliation.
- An exit order (flatten) may be re-issued with a new clientOrderId only after a query proves the previous exit absent. Attempts are bounded to 3 (PROVISIONAL). Each attempt passes the exit path checks.
- After −1003, no immediate retry occurs. The cooldown (VC-2) and breaker (VC-3) apply.
- The design does not assume that a duplicate clientOrderId is rejected by the venue. Idempotency is not assumed (SOURCE_CHECK).

#### §4.6.3 Position States

| State | Meaning |
|---|---|
| POS-FLAT | No exposure on the symbol. |
| POS-OPENING | An entry order is OS-OPEN or OS-PARTIAL. |
| POS-OPEN | Filled exposure. Exit schedule active. |
| POS-CLOSING | An exit order is OS-OPEN, OS-PARTIAL, or OS-CANCEL_REQ. |
| POS-UNKNOWN | An associated order is AMBIGUOUS or RECONCILE_REQUIRED, or a reconciliation mismatch exists. |

| Transition | Trigger | Rule |
|---|---|---|
| POS-FLAT → POS-OPENING | Entry order acknowledged. | Journaled. |
| POS-OPENING → POS-OPEN | Fills total equal to the executed quantity or an accepted final state. | Journaled. |
| POS-OPEN → POS-CLOSING | Exit dispatched. | Journaled with the exit reason. |
| POS-CLOSING → POS-FLAT | Confirmed exit fills equal the exposure. | Journaled. Realized loss computed from fills (F3). |
| Any → POS-UNKNOWN | Associated order enters AMBIGUOUS or RECONCILE_REQUIRED, or a mismatch is detected. | VC-3 set for the symbol. |
| POS-UNKNOWN → previous state | Reconciliation equality (§4.7.2) for the symbol. | Journaled with the reconciliation record. |

---

### §4.7 Reconciliation

#### §4.7.1 Inputs

Reconciliation compares four sources per symbol: exchange open orders, exchange positions, the ledger of orders and positions, and the fill history. It runs at RECONCILING, after each reconnect, on each reconciliation cycle while Live is RUNNING, and before any risk-increasing order after an outage.

#### §4.7.2 Equality Rule

Reconciliation equality holds for a symbol when all of the following are true:
1. The set of exchange open orders equals the set of ledger orders in states OS-OPEN, OS-PARTIAL, or OS-CANCEL_REQ, matched by clientOrderId and venue order ID.
2. The exchange position size equals the ledger position size, compared as integers in units of the lot step s_lot. Floating-point comparison is forbidden.
3. The cumulative fill quantity from the exchange fill history equals the ledger's cumulative fill quantity for every order.
4. No order is in OS-AMBIGUOUS or OS-RECONCILE_REQUIRED without a resolved state.

Any failure of 1 to 4 sets the UNRECONCILED flag for the symbol (or globally, for account-level differences).

#### §4.7.3 UNRECONCILED Flag Record

Fields: flag_id, scope (symbol or global), first_detected_utc, last_checked_utc, cycle_count, discrepancy_summary (counts and IDs only, no free text from the exchange), linked_order_ids, linked_position_state, status (OPEN or CLEARED), cleared_utc, clearing_evidence_id.

**Escalation (derived).**
- The flag is set immediately on detection.
- VC-3 is set after R_bound = 3 consecutive reconciliation cycles with the flag still open (PROVISIONAL, DESIGN_JUDGMENT). The cycle interval T_rec is derived in §4.11 from the staleness limit, and its numeric value is fixed in Part 5.
- A single-cycle mismatch that clears on the next cycle is journaled and does not set VC-3.

#### §4.7.4 Outage Deferral (OD-05)

- During a connection outage, reconciliation is deferred. Deferral is not a release: VC-2 stays active, and no risk-increasing action is possible.
- The deferral window is 3 days (PROVISIONAL, from C12). The window governs reconciliation deferral only.
- When the connection returns, reconciliation runs before any risk-increasing order, regardless of how long the outage lasted.
- If the outage exceeded the 3-day window, VC-3 is set on reconnect and stays active until equality holds (RA-6). The ledger may be stale by more than the bound, so the design does not assume that it is current.
- Outage classes and channel states (OC and CH) are defined in §4.10.

---

**اصلاح CORR-P4-04 (نسبت به پیام ۱):** §۴.۴.۱ مجموعه حالت‌ها را PAPER و LIVE تعریف کرده بود. مجموعه حالت‌ها به سه مقدار گسترش می‌یابد: PAPER، LIVE و EXIT_ONLY. حالت EXIT_ONLY فقط اقدامات کاهنده ریسک را مجاز می‌داند و در بخش §۴.۸.۲ (CMD-01) و §۴.۹ تعریف می‌شود. دلیل آن این است که پس از کرش، موقعیت باز می‌تواند بدون مدیریت ورود باقی بماند و سیستم باید بتواند آن را خارج کند بدون اینکه ورود جدید باز شود.

---

### §4.8 Telegram Command Contract

#### §4.8.1 Transport, Authorization and Envelope

| Item | Rule | Basis |
|---|---|---|
| Transport | Outbound long polling only, performed by CMP-02 in the Supervisor. No inbound listener. | O1 SELECTED (§3.9); R-032; A9 |
| Authorization | Allowlist of one numeric Telegram user ID and one chat ID, entered locally by the owner and recorded as OWNER_ATTESTED. | A2; DESIGN_JUDGMENT |
| Unauthorized sender | No reply. Event AUD-UNAUTHORIZED is journaled with update ID and a hash of the sender ID. Message text is not stored. | Avoids revealing the command surface to other senders (DESIGN_JUDGMENT) |
| Idempotency | Each update ID is processed at most once. A repeated update ID is ignored and journaled as AUD-DUPLICATE. | Prevents duplicate /flatten or /ack effects (DESIGN_JUDGMENT) |
| Undefined command | Refused with code CMD_UNDEFINED and the list of defined commands. | R-036 |
| Malformed syntax | Refused with code CMD_SYNTAX and the expected syntax. | R-036 |
| Message envelope | Every outbound message states: UTC time (ISO-8601, suffix Z); mode; process state (STOPPED, INIT, RECONCILING, RUNNING); state_version (RS version and runtime state version); data timestamp (latest knowable bar close time for the symbols cited, and time of last OK clock sample); audit ID. | R-037; R-007 |
| Refusal format | Refusal code; failing interlock name if one applies (R-039); plain reason; audit ID; the blocking state; for /ack, the list of active VC classes (R-014). | R-039; R-014 |

**Derivation (D13).** The authorization option adopted is a fixed local allowlist. The rejected alternative is accepting commands from any chat that has the bot token. The bot token alone is insufficient, because a leaked token must not permit a flatten or a Live selection. The silent response to unauthorized senders is adopted, and an explicit refusal is rejected, because an explicit refusal would confirm to an unknown sender that the bot is active.

#### §4.8.2 Command Table

| ID | Syntax | Executed by | Preconditions (evaluated in the command's own context) | Effect | Refusal codes | Audit events |
|---|---|---|---|---|---|---|
| CMD-01 | `/start` | Supervisor (CMP-01) through CMP-03 | Runtime STOPPED. No preconditions on clock or per-trade risk (R-035). | Starts the Runtime in INIT. Mode is PAPER. If the last recorded mode was LIVE or the journal shows exposure, mode is EXIT_ONLY (DR-07). Integrity procedure IP-1 to IP-8 runs. H1 is set. | CMD_RUNTIME_ALREADY_RUNNING; START_RESTART_BUDGET_EXHAUSTED (§4.9, row 11) | AUD-START-ACCEPTED, AUD-START-REFUSED |
| CMD-02 | `/status` | Supervisor reads journal snapshot when STOPPED, or Runtime when running | None. | Sends the status envelope: mode, process state, all active VC classes, all active HOLD origins, clock class, reconciliation flags, open position count, last journal event. Read-only. | None | AUD-STATUS |
| CMD-03 | `/select_paper` | Runtime (CMP-04) through CMP-03 | Runtime in RUNNING or EXIT_ONLY. No exposure in the Live scope: exposure_ledger_usdt is zero and no order is OS-OPEN, OS-PARTIAL, OS-CANCEL_REQ, OS-AMBIGUOUS or OS-RECONCILE_REQUIRED. No transition already in progress. | Sets H4 for the transition, then mode PAPER. Cancels resting entry orders, if any remain, before the transition completes. | SEL_EXPOSURE_OPEN (names /flatten as the required step); SEL_RUNTIME_NOT_ACTIVE; SEL_TRANSITION_IN_PROGRESS | AUD-SELECT-PAPER |
| CMD-04 | `/select_live` | Runtime (CMP-04) through CMP-03, with the interlock checks in §4.8.3 | Mode PAPER (not EXIT_ONLY). Six interlocks in §4.8.3 pass at the time of the command. IP-1 to IP-8 pass. Order endpoints are present (CMP-09, CMP-10 active). No VC active. No HOLD other than H4 for this transition. | Sets H4. Runs IP-1 to IP-8 again (§4.5.6). Freezes the Live universe as LIVE_UNIVERSE_SNAPSHOT (the list of VALID symbols at that time, with timestamps) in the journal. Runs RECONCILING (§4.7). On equality, sets mode LIVE and clears H4. No waiting period and no return hurdle (R-038). | LIVE_REFUSED_I1_DATA; LIVE_REFUSED_I2_RECONCILIATION; LIVE_REFUSED_I3_RISK_LIMITS; LIVE_REFUSED_I4_CREDENTIALS; LIVE_REFUSED_I5_CONFIG; LIVE_REFUSED_I6_CLOCK; LIVE_REFUSED_VC (with class ID); LIVE_REFUSED_TIER_UNVERIFIED; LIVE_REFUSED_TOPOLOGY (under P-T5, where no Live endpoint exists); SEL_TRANSITION_IN_PROGRESS | AUD-SELECT-LIVE |
| CMD-05 | `/ack <reason>` | Runtime (CMP-04) | H5 active. No VC active (RA-3). The reason is mandatory and at most 200 characters (PROVISIONAL). | Releases H5 only. The reason is stored in the audit record with state_version. | ACK_NO_H5_ACTIVE; ACK_VC_ACTIVE (lists the active classes and states that /ack never clears a VC); ACK_REASON_MISSING | AUD-ACK |
| CMD-06 | `/flatten` or `/flatten <SYMBOL>` | Runtime (CMP-09, CMP-12) through the flatten path (RA-5) | Runtime in INIT, RECONCILING, RUNNING or EXIT_ONLY. Exchange adapter reachable (CH-EX not DOWN). No confirmation step by default (OD-06 default; DR-11). Optional confirmation gate, configuration flag FLATTEN_CONFIRM, default OFF, enabled only by the owner. | Creates exit orders for the exchange-reported positions (all symbols, or the named symbol). Quantity never exceeds the exchange-reported position. Permitted under every VC class. Does not write RS. Logs each action as UNRECONCILED_ACTION for later reconciliation. | FLATTEN_RUNTIME_STOPPED (the Supervisor applies the restart rule in §4.9, row 11); FLATTEN_ADAPTER_UNAVAILABLE; FLATTEN_NO_POSITION (informational, no H5) | AUD-FLATTEN-REQUESTED, AUD-FLATTEN-DISPATCHED, AUD-FLATTEN-REFUSED |
| CMD-07 | `/help` | Supervisor | None. | Lists CMD-01 to CMD-07 with syntax. Read-only. | None | AUD-STATUS |

**Notes.**
- A refused /flatten sets H5 (§4.4.4). A refusal cannot leave the operator with an unknown exit state.
- /select_paper is the reversal path from LIVE. The design does not require a return hurdle or waiting period for it (R-038).
- The design defines no Telegram stop command (§4.4.1 stop rule).

#### §4.8.3 Six Interlocks at /select_live

Each interlock is evaluated when the command arrives. The result is journaled whether it passes or fails.

| Interlock | Check at command time | Refusal code | Basis |
|---|---|---|---|
| 1. Data validity | At least one symbol in the candidate universe is VALID. Each symbol frozen into LIVE_UNIVERSE_SNAPSHOT is VALID at the moment of freezing. | LIVE_REFUSED_I1_DATA | VC-1; BV rules (§4.11.3) |
| 2. Reconciliation | Equality (§4.7.2) holds for each frozen symbol and globally. No open UNRECONCILED flag exists. | LIVE_REFUSED_I2_RECONCILIATION | VC-3; §4.7.2 |
| 3. Risk-limit definition | GT-06 inputs exist and are inside owner-set bounds: D_max, n_pos_max, c_agg, K_day basis (q), ℓ_max. An absent input refuses the command. | LIVE_REFUSED_I3_RISK_LIMITS | IP-6; OD-01, OD-02, OD-07 |
| 4. Credential and permission | IP-5 passes: credential present in the local secure store, trading permission present, withdrawal permission absent. Unknown state fails. | LIVE_REFUSED_I4_CREDENTIALS | R-031; IP-5 |
| 5. Configuration integrity | IP-4 passes: configuration hash equals the approved hash in the journal. | LIVE_REFUSED_I5_CONFIG | R-030; IP-4 |
| 6. Clock offset | GT-03 passes: clock class is CL-OK for N_c consecutive samples (§4.11.1). | LIVE_REFUSED_I6_CLOCK | R-010; EXP-03 |

**Additional Live checks at the same command** (not among the six interlocks, but mandatory): no VC active (GT-02); tier table verified with timestamp (EXP-10, GT-07); GT-09 filter records younger than the maximum age (§4.5.4); IP-1 to IP-3 pass.

**Derivation (D13).** The six interlocks follow §3.1 item 10 and R-038. Each has one enforcing component (§4.5.6 mapping). The option of a time-based or paper-performance-based gate is rejected because the owner excluded waiting periods and return hurdles, and because no valid performance criterion exists in the record (D19).

#### §4.8.4 Audit Event Catalog

| Event | Trigger | Required fields |
|---|---|---|
| AUD-UNAUTHORIZED | Update from a sender not on the allowlist. | update ID, sender ID hash, UTC time |
| AUD-DUPLICATE | Repeated update ID. | update ID, UTC time |
| AUD-CMD-REFUSED | Any refusal in CMD-01 to CMD-07. | command ID, refusal code, failing interlock or gate, state_version, UTC time |
| AUD-START-ACCEPTED, AUD-START-REFUSED | CMD-01 result. | mode assigned, restart count in the window |
| AUD-STATUS | CMD-02 or CMD-07. | state_version, UTC time |
| AUD-SELECT-PAPER, AUD-SELECT-LIVE | CMD-03, CMD-04 result. | previous mode, new mode, interlock results |
| AUD-ACK | CMD-05 accepted. | reason text, released origin (H5), state_version |
| AUD-FLATTEN-REQUESTED, AUD-FLATTEN-DISPATCHED, AUD-FLATTEN-REFUSED | CMD-06 lifecycle. | symbol or ALL, exchange-reported quantity, refusal code if any |
| AUD-RST, AUD-RESTORE | §4.5.5 and §4.10 (restore). | operator entry record, file hashes |
| AUD-IP-PASS, AUD-IP-FAIL | §4.5.6 completion. | check IDs that failed |

---

### §4.9 Operator-Unreachable Policy

**Principle (derived).** The system has no inbound channel from the operator (A9). The operator's absence is indistinguishable from a Telegram failure, and neither is evidence about market or exchange state. Therefore:
- Silence has no effect on any VC or HOLD (RA-4, R-033).
- Automated rules continue to run. Automated exits are the default (OD-06 default).
- One exception exists. A CRIT alert sets H5 whether or not it is delivered. Entries then stay refused until /ack, which requires the operator. This is the only point where the operator's absence halts trading (DR-09).

#### §4.9.1 Policy by State

| Row | Situation | Automated action while the operator is unreachable | Operator needed? | Residual risk |
|---|---|---|---|---|
| 1 | Flat, PAPER | Paper simulation runs. Alerts are queued. | No | None for capital (no capital at risk) |
| 2 | Flat, LIVE, RUNNING, no VC or HOLD | Entries follow GT-01 to GT-09 without operator action. | No | Unattended entries bounded by GT-06 and by F7, F8 |
| 3 | POS-OPEN within the exit schedule | Stop-rule exit (bar-close evaluation, runtime-managed) and time-stop at the UTC day boundary both execute. The time-stop uses server-anchored time and needs no market data. | No | Gap risk between bar closes (quantified by F3, not removable by the design) |
| 4 | OS-OPEN entry resting | Entry timer expiry triggers TX-11 cancellation. | No | None beyond normal execution risk |
| 5 | OS-AMBIGUOUS | TX-07 queries by clientOrderId, bounded (Q_max = 3). Position is not assumed. | No, until TX-08 | Unknown fill state until a definite query result |
| 6 | OS-RECONCILE_REQUIRED with POS-UNKNOWN | VC-3 set for the symbol. Entries refused. Exit attempts only after the exchange-reported position is confirmed. If it cannot be confirmed, no order is sent, and each cycle is logged. CRIT alert. H5 set. | Yes, for /ack after equality | Unknown exposure persists until connection and equality return |
| 7 | VC-1 on a symbol with an open position | Time-stop still runs (clock-based). Stop-rule evaluation for that symbol is suspended, because the data is invalid. | No | Loss between the last valid bar and the time-stop |
| 8 | VC-2 (connection down) with an open position | No exit is possible while the channel is down. Reconnect backoff runs (§4.10.3). On reconnect, exit requests are sent before any entry (RC-3). | No | Position unmanaged during the outage. Bounded by per-trade stop risk and by the first exit on reconnect. If the outage crosses a UTC boundary, the time-stop executes on reconnect, late. Residual risk R-RISK-1. |
| 9 | VC-3 breaker (repeated −1003) with positions | Exit requests are queued and sent after the cooldown, in priority order. The cooldown is not bypassed. | No | Delay equal to the cooldown, which is part of R-RISK-1 |
| 10 | VC-4 with positions | Exits and time-stop run through the flatten path (RA-5), reading exchange-reported positions. RS is not written. Each action is logged as UNRECONCILED_ACTION. | No, for exits. Yes, for clearing VC-4 (console only). | Sizing counters are unknown. Exits do not depend on them. |
| 11 | Runtime crash with positions | Supervisor restarts the Runtime in EXIT_ONLY with H1. Restarts are bounded: at most 3 within 60 minutes (PROVISIONAL, DESIGN_JUDGMENT). Exit flatten path is available in INIT and RECONCILING (exit path uses exchange-reported positions). If the restart budget is exhausted, the Supervisor stays in STOPPED, sends CRIT, and waits for /start. | Yes, only if the budget is exhausted | Positions may remain unmanaged until the operator returns. This is the only row where the operator's absence matters for exposure. Residual R-RISK-2, linked to GAP-P4-01. |
| 12 | CH-TG down (Telegram) | No veto or HOLD change (RA-4). Alerts queued in the outbox. | No | Operator information delay only |
| 13 | Mode transition in progress when Telegram is down | H4 runs to completion or to its timeout, then fails with a recorded reason. No partial state. | No | None |
| 14 | Mode EXIT_ONLY, no exposure | Behaves as STOPPED for entries, which stay refused. Operator must issue /select_paper, then /select_live. | Yes, to re-enter LIVE | None |

#### §4.9.2 Derivation (D13)

- **Option (a), adopted:** entries continue under automated limits; a CRIT alert sets H5 (DR-09, DR-13).
- **Option (b), rejected:** halt all entries after a fixed period of operator silence. The system cannot tell silence from Telegram failure, so this would convert a Telegram outage into an unnecessary trading halt, and it would violate the requirement that Telegram loss must not change risk state (R-033).
- **Option (c), rejected:** require operator confirmation for each entry. This violates the automation default and A13 (no unnecessary owner involvement during automated operation).
- **Residual R-RISK-2 (row 11):** the design cannot guarantee exit of an orphaned position without a venue-side protective mechanism. Venue conditional-order support is UNRESOLVED (R-034, GAP-P4-01). If SOURCE_CHECK confirms support, the design adds venue-side protection (DR-12 revision). If not, R-RISK-2 remains and is listed in Part 6 for the owner's acceptance, because the design cannot remove it.

---

### §4.10 Outage Classes and Channel States

#### §4.10.1 Channel States (CH)

| Channel | Scope | Staleness limit (PROVISIONAL) | Source |
|---|---|---|---|
| CH-EX | Exchange REST used for orders and positions | 60 s without a successful response | DESIGN_JUDGMENT. Chosen as one minute, which is below the shortest admitted entry bar (15 min) by a wide margin, so a stale channel is detected long before any bar decision. |
| CH-WS | Exchange market-data stream | 2 × the shortest active entry-bar duration (30 min for 15m). It shrinks if a shorter timeframe is activated. | DERIVED from the BV rules (§4.11.3) |
| CH-TG | Telegram Bot API | None. Delivery status only. | RA-4 |
| CH-CLK | Server-time sampling | Sample age more than 3 × T_clk (§4.11.1) | CL rules |

**States.** Each channel has four states:
- **CH_UP:** a successful response within the staleness limit.
- **CH_DEGRADED:** intermittent failures or elevated latency within the staleness limit.
- **CH_DOWN:** staleness limit exceeded, or the connection is refused.
- **CH_UNKNOWN:** no evidence since process start, or after a RS unknown condition.

**Effects.**

| Channel state | Effect |
|---|---|
| CH-EX CH_DOWN or CH_UNKNOWN | VC-2 set. Risk-increasing actions refused. Exit actions attempted only when the channel returns. |
| CH-EX CH_DEGRADED for 3 consecutive samples | VC-2 set (DESIGN_JUDGMENT, conservative). Cleared after 3 consecutive CH_UP samples. |
| CH-WS CH_DOWN | VC-2 set globally. VC-1 set on each symbol whose bars are stale (BV-4). |
| CH-TG any state | No veto change (RA-4). |
| CH-CLK | As CL classes in §4.11.1. |

#### §4.10.2 Outage Classes (OC)

Outage duration is measured on the monotonic clock (R-009). Class boundaries are PROVISIONAL, DESIGN_JUDGMENT, and their final values are fixed in Part 5 under OD-05 ratification.

| Class | Duration (from CH_DOWN to reconnect) | Reconciliation rule | VC rule |
|---|---|---|---|
| OC-1 Interrupted | At least the staleness limit and at most 1 hour | Reconciliation on reconnect before any risk-increasing order (RC-4). | VC-2 cleared when the channel is CH_UP and reconciliation equals. |
| OC-2 Extended | More than 1 hour and at most 3 days | Reconciliation on reconnect, with a full scan of order and fill history from outage start. Ledger treated as stale until equality. | Same as OC-1 for VC-2. Entries remain refused until equality. |
| OC-3 Prolonged | More than 3 days (C12 window) | Reconciliation deferral window exceeded. VC-3 set on reconnect until equality (RA-6, §4.7.4). | VC-3 remains until equality. |

**Scope of the 3-day value.** The 3-day value governs reconciliation deferral only (C12, OD-05). It does not change entry gating, veto durations for VC-1 and VC-2, exit timing, or the time-stop.

**Class-A.** The prompt names a "Class-A" outage that is undefined. The design does not use that name. OC-3 is the nearest equivalent, because it is the class for which the 3-day provisional value applies. The mapping is recorded as GAP-P4-04 and is UNRESOLVED.

#### §4.10.3 Reconnect Procedure (RC)

| Step | Action |
|---|---|
| RC-1 | Channel returns to CH_UP for at least 2 consecutive samples. Reconnect attempts follow exponential backoff with base 2 s and cap 300 s (PROVISIONAL). No tight retry loop. |
| RC-2 | Classify the outage (OC-1, OC-2 or OC-3) by monotonic duration. |
| RC-3 | Send exit and flatten-path requests first, reading exchange-reported positions (RA-5). |
| RC-4 | Run reconciliation (§4.7) for the affected symbols and globally. |
| RC-5 | If OC-3 applies and equality is not reached, set VC-3 and H2. |
| RC-6 | Resume entries only when no VC or HOLD origin remains and mode is LIVE. |

#### §4.10.4 Venue-Side Degradation

Repeated −1003 responses open the circuit breaker (VC-3) after K_b = 3 breaches within the monitoring window W_b (PROVISIONAL; the value of W_b is UNRESOLVED and is derived in Part 5, as recorded in §4.5.2). Cooldown after each −1003 sets VC-2 for the cooldown duration (CMP-10). The cooldown is not a retry trigger (R-022, C5).

---

### §4.11 Data and Clock Design

#### §4.11.1 Clock Classes (CL)

| Parameter | Value and status |
|---|---|
| Time source | Exchange server time from the public server-time endpoint. The endpoint and its response format are SOURCE_CHECK. No account is used (A4). |
| Offset estimate | offset = server_time − (monotonic midpoint of request send and response receive, mapped to wall time). Round-trip delay is recorded per sample. |
| Sample interval T_clk | 60 s (PROVISIONAL, DESIGN_JUDGMENT) |
| Sample age limit | 3 × T_clk = 180 s |
| Tolerance τ_OK | 30 s (PROVISIONAL). This is half of the 1m bar, the strictest candidate bound (EXP-03). It relaxes to 7.5 min (half of 15m) only if EXP-04 excludes 1m and the other sub-5m candidates. |
| Sample rejection | A sample whose offset differs from the previous accepted offset by more than 1 s is rejected and journaled (DESIGN_JUDGMENT). |
| Release count N_c | 3 consecutive OK samples (PROVISIONAL) |

**Classes.**
- **CL-OK:** a sample younger than the age limit, and |offset| ≤ τ_OK.
- **CL-STALE:** no accepted sample within the age limit.
- **CL-UNKNOWN:** no accepted sample since process start.
- **CL-EXCESSIVE:** |offset| > τ_OK on the latest accepted sample.

**Effects.** CMP-05 raises VC-2 for any class other than CL-OK. GT-03 refuses risk-increasing actions unless the class is CL-OK. Risk-reducing actions and the flatten path remain allowed (RA-5).

**Time-stop under a non-OK clock.** The time-stop uses the last accepted offset plus monotonic elapsed time, which bounds the error by the accumulated drift. If no accepted offset has ever existed (CL-UNKNOWN from start), the time-stop is evaluated at the first CL-OK sample, and an exit is sent immediately if the boundary has passed. The residual is recorded as part of R-RISK-1.

**Derivation (D13).** The offset-based option is adopted. The rejected alternative is to trust the device clock. R-011 forbids device wall clock as event time, and device clocks drift.

#### §4.11.2 Semantic Time Roles (R-011)

| Role | Source | Stored as | Used for |
|---|---|---|---|
| Venue event time | Venue timestamp in the message or response | Original value, UTC | Ordering within one venue stream only |
| Bar open | Venue kline open time, UTC | UTC | Bar identity, gap detection (BV-1) |
| Bar close | Bar open + bar duration (computed) | UTC | Bar closure (BV-5), knowability |
| Knowability time | Bar close + knowability allowance A_k (5 s initial, PROVISIONAL, final value in Part 5) | UTC | GT-04 and BV-7 |
| Monotonic elapsed time | Monotonic clock | Duration only | Staleness limits, timers, cooldown, outage duration, restart window (R-009) |
| Server-anchored wall time | Device clock plus accepted offset | UTC | UTC day boundaries, schedules, reports, audit stamps |
| Device wall clock | Device | Local value with the CL class attached | Display and diagnostic logs only, never event time |

#### §4.11.3 Bar Validity Rules (BV)

| Rule | Check | Failure action |
|---|---|---|
| BV-1 Gap | open_time(k+1) − open_time(k) differs from the bar duration | Symbol INVALID. VC-1 set. Backfill by bounded paginated request, then revalidate. |
| BV-2 Duplicate | Two bars with the same open time | Symbol INVALID if the contents differ. If identical, one copy is kept and the event is journaled. |
| BV-3 Out of order | open_time decreases | Symbol INVALID. Re-request the window and revalidate. |
| BV-4 Staleness | The newest closed bar is missing: now − (close of newest expected bar) exceeds A_k | Symbol INVALID. VC-1 set. |
| BV-5 Closure | A bar is closed when server-anchored now ≥ bar close + A_k. The venue's closed flag is not used as sole evidence (SOURCE_CHECK). | Bar not used for decisions until closed. |
| BV-6 Content integrity | high ≥ max(open, close); low ≤ min(open, close); high ≥ low; volume ≥ 0; prices positive | Bar rejected. Symbol INVALID. |
| BV-7 Knowability (no look-ahead) | A signal on bar k uses bar k only at or after its knowability time. Orders for a bar-k signal are never placed before knowability. Paper fills use the next bar's open at the earliest. | GT-04 refuses |
| BV-8 Feature sources | No feature depends on markPrice (OD-10, CR-06). No feature uses historical open interest (OD-09). No cross-venue feature enters Paper or Live (C18, CR-26). | Feature set excludes the source; build fails if it is referenced |

**Symbol validity.** Each symbol is VALID or INVALID. A symbol that became INVALID returns to VALID after N_v = 2 consecutive validated entry-timeframe bars (PROVISIONAL, §4.5.2).

#### §4.11.4 History and Pagination (R-046)

Each request is bounded by the 3,500-candle cap (C2). Longer windows are retrieved by paginated time windows with a one-bar overlap check. The number of pages per request is bounded. Each page's result is validated by BV-1 to BV-6 before storage. The method is the stated method required by R-046.

#### §4.11.5 Reconciliation Cycle (closes §4.7.3)

The reconciliation cycle T_rec is 60 s in LIVE RUNNING (PROVISIONAL, DESIGN_JUDGMENT). Its basis is that it exceeds the CH-EX staleness limit's sampling scale and is far below the shortest admitted entry bar (15 min). The escalation count R_bound = 3 therefore gives 3 minutes before VC-3 is set for an open flag. The final numeric value is fixed in Part 5.

---

### §4.12 Operations and Procedural Consistency (PC)

Column meanings: **R-L** = RUNNING in LIVE. **R-P** = RUNNING in PAPER or EXIT_ONLY (see note). **STOP** = STOPPED. **Authority** states who initiates the procedure.

| ID | Procedure | R-L | R-P | STOP | Authority | Evidence |
|---|---|---|---|---|---|---|
| PC-01 | Process start (INIT) | n/a | n/a | Required | CMP-01 on /start | AUD-START-ACCEPTED |
| PC-02 | Integrity procedure IP-1 to IP-8 | Allowed. Runs at each UTC day boundary and before each mode change. | Allowed. Same schedule. | Required at INIT | CMP-13 automatic | AUD-IP-PASS or AUD-IP-FAIL |
| PC-03 | /select_paper | Allowed when no exposure | Allowed (EXIT_ONLY with no exposure) | n/a | Operator (CMD-03) | AUD-SELECT-PAPER |
| PC-04 | /select_live | Not applicable | Allowed from PAPER only | n/a | Operator (CMD-04) | AUD-SELECT-LIVE |
| PC-05 | Flatten | Allowed | Allowed | Through restart (§4.9 row 11) | Operator (CMD-06) or automated exit | AUD-FLATTEN-* |
| PC-06 | Consistent backup (SQLite backup interface; SOURCE_CHECK) | Allowed. Taken daily at 00:00 UTC and before each mode change. | Allowed, same schedule | Allowed | CMP-15 | Snapshot catalog entry with hash; IP-1 run on the copy |
| PC-07 | Restore from backup | Refused | Refused | Required | CMP-17 (console only) | AUD-RESTORE |
| PC-08 | Risk-state reset (RST) | Refused | Refused | Required (RST-1) | CMP-17 (console only) | AUD-RST |
| PC-09 | Research batch (W3) | Refused (DR-15) | Allowed as a separate process at lower priority, writing only to the research store (DR-16) | Allowed | Local console or scheduler | Research run record |
| PC-10 | Data backfill (W4) | Refused (keeps the bar store stable during decisions) | Allowed, through CMP-06 only | Allowed, through CMP-06 only | CMP-06 scheduler | Ingest log entries |
| PC-11 | Schema migration | Refused | Refused | Required, with backup first and IP-1 before and after | CMP-17 (console only) | Migration record |
| PC-12 | Configuration change | Refused. Configuration is read-only; its hash is checked at each day boundary. | Refused | Allowed, followed by an approval record on the console and IP-4 | CMP-17 (console only) | Approval record with new hash |
| PC-13 | Log rotation and retention | Allowed | Allowed | Allowed | CMP-14 | Log index |
| PC-14 | Journal hash-chain verification (IP-2) | Allowed | Allowed | Required at INIT | CMP-13 | IP-2 result |
| PC-15 | /status | Allowed | Allowed | Allowed (Supervisor reads snapshot) | CMP-01 | AUD-STATUS |
| PC-16 | Automatic restart after crash | Applies (budget in §4.9 row 11) | Applies | n/a | CMP-01 | AUD-START-ACCEPTED with restart count |

**Note.** R-P covers PAPER and EXIT_ONLY because the procedures are identical except for the entry restriction.

**Derivation (D13).** The table places restore, RST, schema migration and configuration change only in STOPPED, because each of them changes state that a running process would otherwise hold. The rejected alternative is to allow them during RUNNING with a lock. The lock option cannot be verified to be safe under the single-writer rule (DR-01) without a restart, so the restart-based option is adopted.

---

### §4.13 Library Selection (LIB)

**Status convention.** No package availability, version or endpoint is assumed. Each library is SOURCE_CHECK. Verification is EXP-07 on the recorded device build (C14). This engagement executed no network check, no installation and no test.

| ID | Role | Selection | Rejected alternatives and reason | Derivation criteria | Status |
|---|---|---|---|---|---|
| LIB-01 | Runtime language | Python (L1, §3.9). Exact version UNRESOLVED. | Go (L2) and Rust (L3): reasons in §3.9 | K3, K4 | SOURCE_CHECK on version; EXP-07 |
| LIB-02 | Persistence | Standard-library SQLite interface (P1). WAL mode. | Flat files (P3): FAIL on atomic RS update. Client–server database (P2): conditional on T3 and not selected now. | K1 (atomic update), K4 | SOURCE_CHECK on Termux build (EXP-07) |
| LIB-03 | Money arithmetic | Standard-library decimal type for all USDT values. Binary floating point is forbidden for money, comparisons and gates. | Binary floating point: rounding errors can flip a gate at a threshold. | K1, K3 | DESIGN_JUDGMENT |
| LIB-04 | Hashing and signing | Standard-library SHA-256 for checksums and the journal chain. HMAC-SHA256 for request signing, if the venue documentation specifies that scheme. | Third-party cryptography packages: unnecessary dependency surface | K4 | SOURCE_CHECK on venue signing scheme |
| LIB-05 | HTTPS transport | Standard-library TLS and HTTP client for REST. | Third-party HTTP clients: additional dependency for the same function | K4 | SOURCE_CHECK |
| LIB-06 | Serialization | Standard-library JSON. | Third-party parsers: not needed | K4 | DESIGN_JUDGMENT |
| LIB-07 | Concurrency | Standard-library asyncio, one event loop per process. Blocking database writes go through a single write queue (CMP-14). | Multiple threads writing one database: violates the single-writer rule (DR-01) | K1, K3 | SOURCE_CHECK on Termux build |
| LIB-08 | Telegram client | Minimal client over HTTPS for getUpdates and sendMessage, using LIB-05. No third-party bot framework assumed. | Third-party bot framework: adds a dependency and an inbound-listener capability that the design does not use (A9) | K1 (no inbound listener), K4 | SOURCE_CHECK of method names and response format |
| LIB-09 | WebSocket client | Pure-Python WebSocket client, chosen after EXP-07 verifies import and test suite on the recorded build. No package name is asserted as available. | Compiled WebSocket packages: build risk on Termux | K2, K4 | SOURCE_CHECK; EXP-07 |
| LIB-10 | Test framework | Standard-library unit-test framework as the baseline. A third-party test runner is a candidate only if EXP-07 shows it is available. | Mandatory third-party runner: unnecessary | K3, K4 | SOURCE_CHECK |
| LIB-11 | Statistics (Part 5) | Not selected in Part 4. Selected in Part 5 with the same criteria. | Not applicable in Part 4 | D19 | Deferred to Part 5 by design, not by omission |

**Derivation (D13).** The criteria are K1 (no violation of hard gates), K2 (fit to the device envelope), K3 (verifiability), and K4 (operational burden). The dominant criterion is dependency surface on Termux, because each third-party package is a build risk on the reference device (C14, EXP-07). Standard-library choices are preferred where they meet the requirement.

---

### §4.14 Decision Records, Gaps, Propagation and Completeness

#### §4.14.1 Decision Records (DR)

| ID | Decision | Derivation (D13) | Rejected alternative |
|---|---|---|---|
| DR-01 | Single-writer rule: each table or record family has one writing component. Every write passes through its process's write queue. | Enforces RA-1 and makes the veto state auditable. | Shared writes with locks: harder to verify and to reason about after a crash |
| DR-02 | Two processes: an always-on Supervisor and a Runtime. | /start, /status and /select_live must stay available when the Runtime is stopped or crashed. | One process: an unreachable Runtime would also make the operator interface unreachable |
| DR-03 | Telegram transport is outbound long polling (O1). No webhook. | A9 forbids a stable inbound connection. | Direct webhook (O2): FAIL on K1. Relay webhook (O3, T6): not adopted |
| DR-04 | Trading persistence is one SQLite file in WAL mode (P1). | Atomic RS update (K1). Single file for the trading journal. | Flat files (P3): FAIL. Client–server database (P2): conditional on T3 |
| DR-05 | Runtime in Python (L1). A compiled core for the hot path is considered only if EXP-01 FAILs. | K3 and K4 at the current scale | Go (L2) and Rust (L3), per §3.9 |
| DR-06 | GT-09 round-down rule (R-078). Quantity rounds down and refuses below minimum. | Option (a) in §4.5.4. Keeps realized risk within F3. | Venue round-up: oversized orders silently invalidate F6, F7, F8. Deferral until EXP-08: the rule is a safety requirement independent of values. |
| DR-07 | A restart never restores LIVE automatically. A restart with exposure enters EXIT_ONLY. A restart without exposure enters PAPER. | An unattended restart must not re-enter Live without the six interlocks. | Automatic LIVE resume: would allow a crash to re-enter risk without an operator decision (A9, R-033) |
| DR-08 | No Telegram stop command. The Runtime stops only by crash, process exit, or the local console (CMP-17). | A remote stop with open exposure could leave the position unmanaged. | Remote stop with a confirmation: the confirmation depends on the same unreachable channel. |
| DR-09 | Silence has no effect. A CRIT alert sets H5 whether or not it is delivered, and H5 persists until /ack. | RA-4 and R-033. An undelivered CRIT must not be treated as delivered. | Treating delivered CRIT as sufficient: an alert that could not be delivered would then have no effect |
| DR-10 | RST uses owner-attested baselines and the sentinel UNKNOWN_RECONCILE_REQUIRED. Counters are never seeded from the exchange. | Preserves R-013. The reset must not turn unknown exposure into zero. | Seeding from exchange data: violates R-013 |
| DR-11 | Automated exits are the default. /flatten needs no confirmation. The confirmation gate is optional and defaults to OFF. | OD-06 default. The owner may enable the gate at any time. | Mandatory confirmation: delays exits when the operator is unreachable |
| DR-12 | Stops and time-stops are executed by the Runtime, not by venue conditional orders. | Venue conditional-order support is UNRESOLVED (R-034, GAP-P4-01). A design that depends on it would be unverified. | Venue conditional orders as the primary mechanism: unverified. Revisited if SOURCE_CHECK confirms support. |
| DR-13 | Entries continue under operator silence when no VC or HOLD is active. There is no automatic halt on silence. | Silence cannot be distinguished from Telegram failure (§4.9.2). | Automatic halt after a silence period: converts a channel outage into an unnecessary halt |
| DR-14 | Placement is P-T5 now (research and paper on phone), P-T3 as the Live target, and P-T1 as the alternative. | §3.4.3 selection order: K1 first, then K2, K4, K5, K6 | P-T8 and P-T9: FAIL on K1 and R-055 |
| DR-15 | Research jobs are suspended while Live runs on the phone (P-T1). | Research and Live compete for CPU and battery (DESIGN_JUDGMENT) | Concurrent research: no measured capacity for it (C16, OD-12) |
| DR-16 | Research writes to a separate research store file, never to the trading journal. | Keeps the trading file's single-writer set intact (DR-01). | Research in the trading file: would give research jobs write authority over trading tables |
| DR-17 | Mode set is {PAPER, LIVE, EXIT_ONLY} (CORR-P4-04). | DR-07 needs a mode for restart with exposure. | Two modes only: no safe state for a restart with open exposure |
| DR-18 | Restart budget: at most 3 automatic restarts within 60 minutes (PROVISIONAL). Exhaustion leaves the Runtime STOPPED with CRIT and no further automatic restart. | Bounded retries (R-023). A crash loop must not repeatedly re-enter a partially checked state. | Unlimited restarts: a crash loop could repeatedly reach trading |
| DR-19 | Clock tolerance τ_OK = 30 s (PROVISIONAL), overridable by EXP-03. | Strictest candidate bound until EXP-03 provides a derived value. | Device clock trust: R-011 forbids it |

#### §4.14.2 Gaps (GAP-P4)

| ID | Gap | Status | Resolution route |
|---|---|---|---|
| GAP-P4-01 | Venue conditional-order support for protective stops and time exits | UNRESOLVED (R-034) | SOURCE_CHECK. If supported, DR-12 is revised and R-RISK-2 shrinks. |
| GAP-P4-02 | Termux availability of SQLite build, asyncio, WebSocket package and test runner | SOURCE_CHECK | EXP-07 |
| GAP-P4-03 | Public server-time endpoint and response format | SOURCE_CHECK | SOURCE_CHECK before EXP-03 |
| GAP-P4-04 | "Class-A" outage: undefined in the prompt. OC-3 used as nearest equivalent. | UNRESOLVED, OD-05 non-blocking | Owner ratification (OD-05 default) |
| GAP-P4-05 | Numeric values of OC boundaries (1 h, 3 days), T_clk, τ_OK, N_c, W_b, R_bound, A_k, N_v, Q_max, restart budget | PROVISIONAL, DESIGN_JUDGMENT | Final values in Part 5 and EXP-03 |
| GAP-P4-06 | Per-endpoint rate-limit weight estimates for the internal weight ledger (R-024) | SOURCE_CHECK | SOURCE_CHECK; conservative estimates until then |
| GAP-P4-07 | Whether −1003 non-execution can be confirmed (TX-06) | SOURCE_CHECK | SOURCE_CHECK |
| GAP-P4-08 | Whether a duplicate clientOrderId is rejected by the venue | UNRESOLVED. The design does not assume idempotency. | SOURCE_CHECK |
| GAP-P4-09 | Documented rejection-code list (TX-05) | SOURCE_CHECK | SOURCE_CHECK |
| GAP-P4-10 | clientOrderId maximum length (R-025) | UNRESOLVED. Charset enforced (C11). | SOURCE_CHECK |
| GAP-P4-11 | Residual risks R-RISK-1 (outage with positions) and R-RISK-2 (orphaned position after restart budget exhaustion) | Design-accepted residuals with no removal in the current architecture | Listed in Part 6 for owner information. They are not a decision the design can delegate, because they concern the owner's risk tolerance (OD-03 territory). |

#### §4.14.3 Corrections (CORR-P4)

| ID | Correction | Scope |
|---|---|---|
| CORR-P4-04 | The mode set is extended from {PAPER, LIVE} to {PAPER, LIVE, EXIT_ONLY}. | §4.4.1 of message 1 |

No other correction to Part 4 message 1 is made in this message. The §4.3.2 placement table and the §4.5 gate table are retained as delivered.

#### §4.14.4 Propagation Log (PL-P4)

| Requirement or part | Affected by Part 4 | Status after Part 4 |
|---|---|---|
| R-010 | CL classes, τ_OK, N_c (§4.11.1) | Design specified. Values PROVISIONAL. Not PASS. |
| R-011 | Semantic roles (§4.11.2) | Design specified |
| R-013 | RST and IP-3 (§4.5.5, §4.5.6) | Design specified |
| R-014 | RA-3 and CMD-05 | Design specified |
| R-015 | GT-06 and IP-6 | BLOCKED remains (owner definitions required) |
| R-017 | GT-07 and CMD-04 tier check | BLOCKED remains |
| R-018 | GT-08 | Design specified |
| R-019 | GT-06(c) | UNRESOLVED remains |
| R-020 | §4.6.1 and §4.6.2 | Design specified |
| R-021 | TX-06 | Design specified |
| R-022 | VC-3 breaker and §4.10.4 | Design specified |
| R-023 | Retry rules and §4.6.2 | Bounds PROVISIONAL |
| R-024 | CMP-10 weight ledger | Design specified. GAP-P4-06 open. |
| R-025 | GAP-P4-10 | UNRESOLVED remains |
| R-026 | RECONCILING (§4.4.1) and LIVE_REFUSED_I2 | BLOCKED remains until equality is observed |
| R-027 | OC classes (§4.10.2) | UNRESOLVED remains until OD-05 ratification |
| R-028 | Fee basis (Part 3) | Unchanged |
| R-029 | BV-1 to BV-6 | Design specified |
| R-030 | IP-4 | Design specified |
| R-031 | IP-5 | BLOCKED remains |
| R-032 | DR-03 | Design specified |
| R-033 | RA-4, DR-09, §4.9 | Design specified |
| R-034 | §4.9 and DR-12 | UNRESOLVED remains (GAP-P4-01) |
| R-035 | CMD-01 to CMD-07 preconditions | Design specified |
| R-036 | CMD table and CMD_UNDEFINED | Design specified |
| R-037 | §4.8.1 envelope | Design specified |
| R-038 | CMD-04 and §4.8.3 | Design specified |
| R-039 | Refusal format (§4.8.1) | Design specified |
| R-052, R-053, R-055 | Placement (§4.3.2) and PC-05 | UNRESOLVED remains (EXP-01, EXP-02) |
| R-078 | GT-09 (§4.5.4) and DR-06 | Adopted in message 1. Status NOT TESTED. |
| Part 5 | Parameters in §4.5.2, §4.7.3, §4.10, §4.11 | Parameters carried to Part 5 (GAP-P4-05) |
| Part 6 | GAP-P4-11, OD-05, OD-06 | Carried to Part 6 |

**Register effect.** Part 4 creates no new register row. The register remains at 78 rows (R-001 to R-078). Part 4 introduces decision records (DR-01 to DR-19), gaps (GAP-P4-01 to GAP-P4-11) and corrections (CORR-P4-01 to CORR-P4-04), none of which are R-rows.

#### §4.14.5 Part 4 Completeness Declaration

**Sections present (Part 4 total, messages 1 and 2):**

| Section | Content | Status |
|---|---|---|
| §4.0 | Labels, prefixes, dependency order | Delivered in the earlier Part 4 message |
| §4.1 | CORR-P4-01 to CORR-P4-03 | Delivered in the earlier Part 4 message |
| §4.2 | A-1 adopted as R-078 | Delivered in the earlier Part 4 message |
| §4.3 | Process split, DR-01, §4.3.1 component table | Delivered in the earlier Part 4 message |
| §4.3.2 | Placement table, 10 rows × 3 topologies = 30 cells | Delivered in message 1 of 2 (this series) |
| §4.4 | Runtime and veto model: 5 process states (§4.4.1), 4 VC classes (§4.4.2), 7 RA rules (§4.4.3), 5 HOLD origins (§4.4.4) | Delivered in message 1 |
| §4.5 | RS (14 fields), VC release conditions, GT-01 to GT-09 (9 gates), GT-09 procedure, RST-1 to RST-8 (8 steps), IP-1 to IP-8 (8 steps), six-interlock mapping (6 rows) | Delivered in message 1 (§4.5.1 to §4.5.6) |
| §4.6 | 12 order states, 12 TX rows, 5 position states, 6 position transitions | Delivered in message 1 |
| §4.7 | Inputs, 4-condition equality rule, UNRECONCILED record, outage deferral | Delivered in message 1 |
| §4.8 | Transport and authorization (§4.8.1), 7 commands CMD-01 to CMD-07 (§4.8.2), 6 interlocks (§4.8.3), audit catalog (10 event groups) (§4.8.4) | Delivered in this message |
| §4.9 | Operator-unreachable policy: 14 rows (§4.9.1), derivation and residuals R-RISK-1 and R-RISK-2 (§4.9.2) | Delivered in this message |
| §4.10 | 4 channels × 4 states (§4.10.1), 3 OC classes (§4.10.2), 6 RC steps (§4.10.3), venue-side degradation (§4.10.4) | Delivered in this message |
| §4.11 | CL parameters and 4 classes (§4.11.1), 7 semantic roles (§4.11.2), BV-1 to BV-8 (8 rules) (§4.11.3), history (§4.11.4), T_rec (§4.11.5) | Delivered in this message |
| §4.12 | PC-01 to PC-16 (16 rows) | Delivered in this message |
| §4.13 | LIB-01 to LIB-11 (11 rows) | Delivered in this message |
| §4.14 | DR-01 to DR-19 (19 rows), GAP-P4-01 to GAP-P4-11 (11 rows), CORR-P4-01 to CORR-P4-04 (4 rows), PL-P4 (27 rows), this declaration | Delivered in this message |

**Arithmetic checks.**
- CMP: 17 components (CMP-01 to CMP-17).
- Placement cells: 10 rows × 3 columns = 30.
- VC classes: 4. HOLD origins: 5. RA rules: 7. GT gates: 9 (GT-01 to GT-09).
- RS fields: 14.
- Order states: 12. TX rows: 12 (TX-01, TX-02, TX-02R, TX-03 to TX-11).
- Position states: 5.
- CMD: 7. Interlocks: 6.
- CH channels: 4 × 4 states = 16 cells.
- OC classes: 3 (OC-1 to OC-3).
- RC steps: 6. BV rules: 8. CL classes: 4.
- PC rows: 16. LIB rows: 11.
- DR records: 19 (DR-01 to DR-19). GAP-P4 items: 11. CORR-P4 items: 4.
- PL-P4 rows: 27 (rows listed in §4.14.4, counted as: 26 R-rows and 2 part rows is inconsistent with the table; the table lists R-010 through R-039 as 26 entries, plus R-052/R-053/R-055 and R-078 as one row each, plus Part 5 and Part 6). The row count is 27 with the grouped entries counted once each.

**Forbidden-phrase audit.** This message contains no "for brevity", "in summary", "TBD", "draft", or "at a high level" used as a substitute for detail.

**Evidence labels.** Every material claim carries one of: DERIVED, DESIGN_JUDGMENT, PROVISIONAL, UNRESOLVED, SOURCE_CHECK, OWNER_ATTESTED, or a ratified finding (C-numbers). No status is PASS. No test, network check or installation was executed in this engagement.

**Part 4 status:** complete as design. Every planned section §4.0 to §4.14 is present. Verification of the design against the device (EXP-01, EXP-02, EXP-07) and the source checks (SOURCE_CHECK items) remain open, as recorded in GAP-P4 and in the register statuses.

---

**گام بعد:** پارت ۵ شامل روش‌شناسی آماری و بودجه آزمون (C22 تا C24 و بازمحاسبه ارقام C23)، جدول پارامترها، ماتریس الزام به تأیید با دقیقاً ۷۸ ردیف، بازبینی خودانتقادی طبق §۱۳ بریف و سجل انتشار است. پارت ۵ را پس از تأیید شما، که پارت ۴ کامل است، آغاز می‌کنم.


# بخش ۵ از ۶: روش‌شناسی آماری، بودجه آزمون و سجل پارامترها (پیام ۱ از ۲)
## Part 5/6: Statistical Methodology, Trial Budget and Parameter Register (Message 1 of 2)

**وضعیت ارسال:** بخش ۵ طبق D22 در دو پیام ارسال می‌شود. این پیام شامل §۵.۰ تا §۵.۵ است. پیام ۲ شامل §۵.۶ (ماتریس الزام به تأیید با ۷۸ ردیف)، §۵.۷ (خودبازبینی انتقادی طبق §۱۳ بریف)، §۵.۸ (سجل انتشار و شکاف‌ها) و §۵.۹ (اعلامیه تکمیل پارت ۵ با محاسبه حسابی) است. پارت ۶ پس از ارسال کامل پارت ۵ آغاز می‌شود.

**وضعیت ادعاها:** در این engagement هیچ داده بازاری بازیابی نشده، هیچ استراتژی‌ای ارزیابی نشده و هیچ آزمون آماری روی داده اجرا نشده است. ارقام این بخش محاسبات تحلیلی روی مقادیر ثبت‌شده در پارت‌های ۱ تا ۴ هستند. هیچ وضعیت PASS در این بخش ادعا نمی‌شود.

---

### §5.0 Scope, Conventions and Dependency Order

**Scope.** Part 5 covers:
- (a) statistical methodology and trial budget (C22 to C24, C20, C21, R-057 to R-062, D19);
- (b) recomputation of the C23 figures;
- (c) the sample-length definitions required by the budget;
- (d) the parameter register that consolidates every PROVISIONAL, SCENARIO, DESIGN_JUDGMENT, UNRESOLVED, ILLUSTRATIVE and OWNER_DECISION_PENDING value from Parts 3 and 4;
- (e) in message 2: the requirement-to-verification matrix, adversarial self-review, propagation log and completeness declaration.

**Conventions.**
- **C-1 Year.** 365 days (PD-09). Length in years = days / 365.
- **C-2 Sharpe-type quantities.** Annualized (365-day convention) unless labelled per-period. The unit is declared on every statistic (SP-2).
- **C-3 Labels.** Those of Part 4, plus ILLUSTRATIVE (equity) and the verdict vocabulary of SP-9 (EVALUATED, NOT_EVALUABLE). The label NOT_REPRODUCED is used for the C23 pair.
- **C-4 Integers.** Trial counts are integers. Where a count derives from a continuous expression, the floor is taken.

**Dependency order (D11).**
1. Sample-length definitions (§5.2).
2. Budget function (§5.3.1).
3. C23 reproduction (§5.3.3).
4. Operative values under C22 (§5.3.4) and the declaration of the planning scale (§5.3.5).
5. Statistical protocol (§5.4).
6. Parameter register (§5.5), which consumes all earlier values.
7. Message 2: verification matrix, which consumes the protocol and the register.

---

### §5.1 Ratified Statistical Inputs: Permitted Use

| Input | Ratified value and scope | Use in this design | Not used for |
|---|---|---|---|
| C20 | Deflated Sharpe ≈ 1.5e-2 at N = 100, unit-consistent; the unit is not stated in the record | Recorded only. | Any decision (R-062). The unit is unstated, so the figure cannot be checked against SP-6. |
| C21 | MinTRL corrected to 19.54 years | Reported per candidate by SP-7 from that candidate's own SR̂, sample lengths, skewness and kurtosis. | Gating. The SR input behind the 19.54 figure is not recorded (PD-08), so the figure is not transferred to any candidate. |
| C22 | N_max_effective = min(published, recomputed). The recomputed value governs if the two differ by more than 2× | Operative rule in §5.3.4. | Any value not passing the C22 check. |
| C23 | Admissible configurations ≈ 10–20 at 4h; thousands at 1d before sample-length correction; both PROVISIONAL pending recomputation | Recomputed in §5.3.2 and §5.3.3. The pair is found NOT_REPRODUCED (CR-27). | Operative use without the C22 check. |
| C24 | Full permutation grid inadmissible at every timeframe ≤ 12h | Applied as ratified. No program may enumerate a full grid at ≤ 12h (R-058). | Not applicable as a reason to reject any strategy. |
| CR-04 | 4.99-year figure retired (MinTRL/MinBTL conflation) | Not used anywhere in this design. | Any computation. |
| MinBTL | Minimum backtest length as a function of the number of configurations tested | A priori trial-budget function (§5.3.1). | Track-record significance. MinBTL is never reported as MinTRL. |
| CSCV arithmetic | Retired | Not reproduced. No CSCV-based overfitting probability is used (SP-11). | Any computation. |

---

### §5.2 Sample-Length Definitions

**Definitions.**
- **L_total(tf):** historical span retrievable for one symbol at timeframe tf. The Part 3 Step 4 values are the coverage of one request at the 3,500-candle cap. Because §4.11.4 retrieves longer windows by pagination, the true depth is the paginated depth, which is not yet measured. The Step 4 values are therefore cap-only lower bounds. Per-symbol depth is UNRESOLVED and is resolved by EXP-13 (§5.5.2). This corrects the implicit reading in Part 3 (CR-30).
- **f_h = 0.25 (PRM-40):** holdout fraction.
- **L_b = (1 − f_h) · L_total:** search and validation span. It is the basis of the trial budget.
- **L_hold = f_h · L_total:** holdout span.
- **L_req = 455 days (PRM-42):** required span for a program's data, made of at least 365 days of search and at least 90 days of holdout. This is a feasibility gate, not a statistical threshold. It does not claim that 365 days covers any particular market regime.

**Table 5.2: sample-length and feasibility by timeframe (cap-only depth unless stated).**

| TF | Bars per day | Bars at L_req | Pages at 3,500 per page | L_total (years) | L_b (years) | L_hold (years) | L_hold (days) | Holdout ≥ 90 days, cap-only | Span ≥ L_req, cap-only |
|---|---|---|---|---|---|---|---|---|---|
| 1m | 1,440 | 655,200 | 188 | 0.00666 | 0.00500 | 0.00167 | 0.6 | No | No |
| 3m | 480 | 218,400 | 63 | 0.01997 | 0.01498 | 0.00499 | 1.8 | No | No |
| 15m | 96 | 43,680 | 13 | 0.09988 | 0.07491 | 0.02497 | 9.1 | No | No |
| 30m | 48 | 21,840 | 7 | 0.19979 | 0.14984 | 0.04995 | 18.2 | No | No |
| 1h | 24 | 10,920 | 4 | 0.39954 | 0.29966 | 0.09988 | 36.5 | No | No |
| 2h | 12 | 5,460 | 2 | 0.79909 | 0.59932 | 0.19977 | 72.9 | No | No |
| 4h | 6 | 2,730 | 1 | 1.59817 | 1.19863 | 0.39954 | 145.8 | Yes | Yes |
| 6h | 4 | 1,820 | 1 | 2.39726 | 1.79795 | 0.59931 | 218.8 | Yes | Yes |
| 8h | 3 | 1,365 | 1 | 3.19634 | 2.39726 | 0.79909 | 291.7 | Yes | Yes |
| 12h | 2 | 910 | 1 | 4.79452 | 3.59589 | 1.19863 | 437.5 | Yes | Yes |
| 1d | 1 | 455 | 1 | 9.58904 | 7.19178 | 2.39726 | 875.0 | Yes | Yes |

Pages are ceil(bars at L_req / 3,500). The 1,774-bar 1d sample (4.86 years, C2) shows that depth varies by symbol, because not all series reached 3,500 bars.

**Reading of Table 5.2 (DERIVED).**
- At cap-only depth, no timeframe at or below 2h can host a protocol-compliant holdout, and none meets L_req.
- At 4h and longer, cap-only depth is sufficient for the holdout span and for L_req.
- Programs at 1m to 2h therefore require paginated depth, which EXP-13 measures. Until then, these timeframes can carry no protocol-compliant program. This is a feasibility result, not a rejection of any timeframe (D19).
- Part 3 Step 4 stated that L_req was UNRESOLVED. L_req is set here (PRM-42). The sufficiency result is the table above, with the depth to be measured.

---

### §5.3 Trial-Budget Function and Recomputation of C23

#### §5.3.1 Function

**Definition.**

N_rec(tf, E_T) = floor( exp( L_b · E_T² / 2 ) ), with N_rec ≥ 1.

**Basis (SOURCE_CHECK).** The MinBTL approximation MinBTL(N, E) ≈ 2 · ln N / E² (years) is inverted for N. Here E_T is the annualized Sharpe scale that a program commits to distinguish from the maximum null Sharpe across N configurations. E_T is not a return target. The record supplies no return target, no utility function and no loss tolerance (OD-03, R-072), so none is inferred.

**Interpretation.** N_rec is the largest number of configurations whose approximated expected maximum null Sharpe over L_b does not exceed E_T. Configurations beyond N_rec are inadmissible for that program at scale E_T.

**Properties (DERIVED).**
- **P-1.** N_rec is non-decreasing in L_b and in E_T.
- **P-2.** N_rec = 1 exactly when L_b · E_T² < 2 · ln 2 ≈ 1.386. A budget of 1 means one pre-specified configuration and no selection among configurations.
- **P-3.** Because E_T enters squared, a 50% increase in E_T multiplies the exponent by 2.25. The budget is therefore highly sensitive to the declared E_T. §5.3.5 governs that declaration.

#### §5.3.2 Recomputed Budget Table

| TF | L_b (years) | N_rec at E_T = 1.0 | N_rec at E_T = 1.5 | N_rec at E_T = 2.0 | Published (C23) |
|---|---|---|---|---|---|
| 1m | 0.00500 | 1 | 1 | 1 | none |
| 3m | 0.01498 | 1 | 1 | 1 | none |
| 15m | 0.07491 | 1 | 1 | 1 | none |
| 30m | 0.14984 | 1 | 1 | 1 | none |
| 1h | 0.29966 | 1 | 1 | 1 | none |
| 2h | 0.59932 | 1 | 1 | 3 | none |
| 4h | 1.19863 | 1 | 3 | 10 | 10 to 20 |
| 6h | 1.79795 | 2 | 7 | 36 | none |
| 8h | 2.39726 | 3 | 14 | 120 | none |
| 12h | 3.59589 | 6 | 57 | 1,328 | none |
| 1d, full span (9.589 years; L_b = 7.192) | 7.19178 | 36 | 3,265 | 1.77 × 10⁶ | thousands, before sample-length correction |
| 1d, 1,774-bar symbol (4.860 years; L_b = 3.645) | 3.645 | 6 | 60 | 1,466 | (same, before correction) |

#### §5.3.3 Reproduction of C23 and Finding NOT_REPRODUCED

**Implied E_T for the published 4h range (N ∈ [10, 20]).**
- On L_b: E_T ∈ [1.96, 2.24].
- On L_total: E_T ∈ [1.70, 1.94].

**Implied E_T for the published 1d "thousands" (N ∈ [1,000, 9,999]), pre-correction, full span.**
- On L_b: E_T ∈ [1.39, 1.60].
- On L_total: E_T ∈ [1.20, 1.39].

**Finding (DERIVED).** Under either convention, the 4h interval and the 1d interval do not overlap. No single E_T reproduces both published figures. The record contains neither the configuration grids nor the E_T, the sample lengths or the variance inputs behind the published figures, so the cause cannot be identified. The C23 pair is recorded as **NOT_REPRODUCED** (CR-27). Neither published figure is adopted as an operative value.

**Sample-length correction at 1d (DERIVED).** Moving from the full 9.59-year span to the 4.86-year span of the 1,774-bar symbol reduces the budget by a factor of 6 at E_T = 1.0 (36 to 6), by a factor of about 54 at E_T = 1.5 (3,265 to 60), and by a factor of about 1,200 at E_T = 2.0 (1.77 × 10⁶ to 1,466). The "thousands" figure therefore holds only for a full-span symbol at E_T between about 1.39 and 1.60, which the record does not support for all symbols.

**Partial reproduction (DERIVED).** The lower bound of the 4h published range (N = 10) is reproduced on L_b at E_T ≈ 1.96. This is the only point at which the published 4h figure is reproduced at all.

#### §5.3.4 Operative Values under C22

**Procedure (applied per timeframe and per declared E_T).**
1. Let R = N_rec(tf, E_T) from §5.3.2, computed on the symbol's own L_b.
2. If a comparable published value P exists, let P_low be its lower bound. For 4h, P_low = 10.
3. Compute ρ = max(P_low, R) / min(P_low, R).
4. If ρ > 2, N_max_eff = R (the recomputed value governs, per C22).
5. Otherwise, N_max_eff = min(P_low, R).
6. If no comparable published value exists, N_max_eff = R. The 1d published figure is pre-correction and has no corrected counterpart, so step 6 applies to 1d.

**Operative planning values at the planning scale E_T = 1.0 (PRM-46).**

| TF | R at E_T = 1.0 | Published P_low | ρ | N_max_eff |
|---|---|---|---|---|
| 1m | 1 | none | n/a | 1 |
| 3m | 1 | none | n/a | 1 |
| 15m | 1 | none | n/a | 1 |
| 30m | 1 | none | n/a | 1 |
| 1h | 1 | none | n/a | 1 |
| 2h | 1 | none | n/a | 1 |
| 4h | 1 | 10 | 10 > 2 | 1 (recomputed governs) |
| 6h | 2 | none | n/a | 2 |
| 8h | 3 | none | n/a | 3 |
| 12h | 6 | none | n/a | 6 |
| 1d context, full span | 36 | pre-correction only | n/a | 36 |
| 1d context, 1,774-bar symbol | 6 | pre-correction only | n/a | 6 |

For symbols of unknown depth, the 1d context value is 6, the lower value, until EXP-13 measures depth. A symbol's 1d value is its value at its own measured depth.

**Comparison scale (not adopted).** At E_T = 2.0 the 4h value is R = 10 and N_max_eff = 10, matching the published lower bound. This is shown only to make the sensitivity visible.

#### §5.3.5 Declaration of the Planning Scale E_T

- **Planning value.** E_T = 1.0 (PRM-45). Reason: it is the lowest tabulated scale and yields the smallest admissible budget. It is the conservative choice, because it constrains search most. It is not a return target. No owner return expectation exists in the record (OD-03 unresolved, R-072), so none is derived from one.
- **Declaration per program.** E_T is declared in each program's pre-registration (SP-3), before data access, and is fixed for the life of that program's trial ledger.
- **No raising within a ledger.** A program may not raise E_T after its ledger has started. A higher E_T may appear only in a new protocol version, which starts a new budget. Trials already recorded for the same symbol and timeframe continue to count (DR-21).
- **Justification standard.** Any raise must rest on a recorded methodological derivation inside the protocol. A desired return does not qualify.
- **Ownership.** The choice of E_T is a delegated methodological decision (A12). It is not an owner question, because it is internal to the verification method and none of the five §2.1.7 conditions holds for it.

#### §5.3.6 Budget Scope Rules

- **Rule-based admission is excluded from the count.** D14 Steps 1 to 9, EXP-08 filters, GT-09 checks and liquidity thresholds are applied before and independently of any performance result, so they do not consume budget (DR-22).
- **Performance-based choices are counted.** Any choice among symbols, timeframes, parameters, features or rule variants that depends on performance consumes budget. The count is the number of distinct (configuration, symbol, timeframe) evaluations that influenced the choice.
- **Discarded trials are counted.** The budget counts the ledger, not only the reported result (SP-1).
- **Pooled statistic.** When symbols are admitted by a pre-specified rule with no performance-based choice, the tested object is the pooled portfolio series under one cost model. Per-symbol statistics are descriptive and are not used for selection (SP-12).
- **Consequence at planning E_T = 1.0 (DERIVED).** A performance-based selection among symbols at 1m to 2h has no room (budget 1). A program that requires such selection at 2h or shorter needs EXP-13 depth and a declared higher E_T in a new protocol version. Otherwise it runs as one pre-specified configuration on all admitted symbols, with the pooled statistic as the single tested object.
- **C24 holds throughout.** Any program whose full grid exceeds its budget is inadmissible. At every timeframe ≤ 12h, the full grid is inadmissible regardless (C24).
- **Scope of the constraint.** The budget constrains the number of configurations evaluated. It does not constrain architecture, method or language choice, which are delegated to the model (A12).

---

### §5.4 Statistical Protocol

The protocol is design-specified and NOT EXECUTED. Its purpose is to produce evidence records. No protocol output is a verdict on a strategy at design time (D19, R-057).

**SP-1 Trial ledger.** Append-only table in the research store (DR-16). Each record holds: trial_id (unique, monotonic); program_id; protocol version; timeframe; symbol-set hash; configuration hash; feature-set identifier; cost-model version; sample window (UTC start and end, with inclusivity stated); SR unit; per-period SR; status (completed, failed or discarded); UTC time of record; monotonic duration. N_trials is the number of records for the program's timeframe family, counting every status. Edits and deletions are forbidden. Corrections are appended as new records.

**SP-2 Units and annualization.** The per-period SR is computed on the bar-return or trade-return series declared in the pre-registration. For bar series with 24/7 bars, periods per year = 365 × bars per day, and the annualization factor is the square root of that count. For trade series, the annualization uses the declared trade count per year. Each statistic record carries its unit: per-period or annualized (365-day). C20 carries no unit (PD-07) and is therefore not comparable with any protocol output.

**SP-3 Pre-registration.** Before any data is accessed for a program, the record fixes: timeframe; configuration family and its size, or the rule that bounds it; E_T and the N_max_eff from §5.3.4 at the program's measured depth; the cost-model version (fee f = 0.06% per side, stop slippage s = 0.5%, funding φ and k); partition boundaries in UTC; purge and embargo; evaluability thresholds (SP-8); the metrics reported; the DSR and MinTRL settings, including the MinTRL benchmark SR*, which is pre-registered per program and is not a register-level constant. The record is hashed and stored before data access. A change after data access creates a new protocol version (§5.3.5).

**SP-4 Partition, purge and embargo.**
- **Holdout.** The most recent contiguous span of length L_hold = f_h · L_total. It is excluded from the search segment.
- **Search segment.** Span L_b, divided into walk-forward folds. The purge length equals the maximum holding duration H_max, which is strictly less than 24 h (derived in §3.6 Step 2). The embargo is one bar of the program's timeframe at each fold boundary.
- **Selection.** Validation and selection among candidates occur only inside the search segment. Each validation selection consumes ledger budget.
- **Fold count.** Pre-registered. Each fold must contain at least N_tr_min trades (PRM-43). A fold below that minimum is excluded from the average, and the exclusion is recorded in the ledger. It is not silently dropped.

**SP-5 Costs and funding.** All reported statistics are net of the fee f = 0.06% per side (C6, conservative) and a stop slippage s = 0.5% (SCENARIO). Funding is applied per F5, using N_t · k · φ per interval, with k = floor(H / I_f) + 1. While I_f is UNRESOLVED (EXP-09), funding-dependent programs (class S5) cannot be evaluated for Live use. Class S1 programs report funding stress as a separate column. Gross statistics may appear only as a labelled secondary column.

**SP-6 Multiple-testing correction (Deflated Sharpe).** Computed on the holdout segment for the program's tested object (the pooled series under SP-12 or the single configuration):

DSR = Φ( (SR̂ − SR₀) · √(T − 1) / √(1 − γ₃ · SR̂ + ((γ₄ − 1) / 4) · SR̂²) )

where:
- SR₀ is the expected maximum null Sharpe over N_trials configurations, computed from the observed variance of the ledger's trial SRs (SOURCE_CHECK), with SR₀ = √V_obs · [ (1 − γ_E) · Z⁻¹(1 − 1/N) + γ_E · Z⁻¹(1 − 1/(N·e)) ], where γ_E is the Euler–Mascheroni constant and Z⁻¹ the inverse standard normal CDF;
- SR̂ is per-period; T is the number of holdout return observations; γ₃ and γ₄ are the skewness and kurtosis of the same series.

Output: DSR value, its unit, N_trials used, V_obs used and the SR₀ formula version. The annualized value is reported separately. At N_trials = 1, SR₀ is zero under this approximation (SOURCE_CHECK).

**SP-7 MinTRL report.** For each candidate and for each of the search and holdout segments, MinTRL is computed from that segment's SR̂, skewness, kurtosis, the pre-registered benchmark SR* and the confidence level 0.95 (PRM-44), and reported in years and in observations, with the SR unit stated. It is compared with L_b and L_hold as reported fields only. It is not a gate. The ratified 19.54-year figure (C21) is not reproduced and is not compared with any program.

**SP-8 Evaluability.** A program result is EVALUATED only if all of the following hold:
- (a) holdout span ≥ 90 days (PRM-41);
- (b) holdout trade count ≥ N_tr_min = 30 (PRM-43);
- (c) every holdout bar is VALID under the BV rules (§4.11.3);
- (d) the trial ledger is complete (SP-1);
- (e) the pre-registration hash matches and the benchmark SR* is recorded (SP-3);
- (f) cost inputs are confirmed, or funding-dependent parts are excluded under SP-5.

Otherwise the result is NOT_EVALUABLE, with the failed condition ID recorded. NOT_EVALUABLE is not a rejection and creates no veto.

**SP-9 Result vocabulary.** The only result labels are EVALUATED (statistics recorded) and NOT_EVALUABLE (conditions failed). No protocol output carries a verdict on a strategy such as accepted, rejected, approved or failed. Entry to Paper or Live is governed by the Part 4 gates and interlocks, not by a protocol statistic. Because the Paper/Live selector has no performance precondition (R-038), protocol results are evidence for the operator's review and are not an automatic gate. This implements D19.

**SP-10 Holdout discipline.** Each holdout is opened once per protocol version and is then consumed. Any further test on the same span is forbidden. Forward data recorded after a holdout end (for example, Paper-phase data) forms a new holdout for a new protocol version. It is never used for search (DR-23). Consumption is recorded in the ledger.

**SP-11 Diagnostics exclusion.** The retired CSCV arithmetic is not used, and no CSCV-based overfitting probability is computed. Any alternative overfitting diagnostic requires a SOURCE_CHECK, a unit declaration and a pre-registration entry before use. None is adopted in Part 5 (DR-24).

**SP-12 Pooled portfolio statistic.** When symbols are admitted by a pre-specified rule with no performance-based choice, the tested object is the pooled portfolio series under one cost model. Per-symbol statistics are descriptive, are labelled as such and are not used to select symbols.

---

### §5.5 Parameter Register

**Register rules.** Each row is one parameter. "Set by" distinguishes design judgment, owner decision, ratified input and derived value. "Final-value route" states how the value becomes final, or why it is fixed for design version 1. A row whose status is DESIGN_JUDGMENT and whose route reads "fixed v1" becomes a design revision if changed. No row is PASS. Owner-decision rows carry no default (D17).

| ID | Parameter | Symbol | Value | Status | Set by | Sensitivity or function | Final-value route |
|---|---|---|---|---|---|---|---|
| PRM-01 | Illustrative equity | E | 200 USDT | ILLUSTRATIVE | Owner brief (A11) | Linear. At E = 500 and r = 1%, N = 543.48 USDT | Replaced by the owner-stated capital before any Live use |
| PRM-02 | Per-trade risk fraction | r | Scenario grid 0.25, 0.5, 1, 2, 3% | OWNER_DECISION_PENDING | Owner (OD-02) | Drives N, F3, F6, F7, F9, GT-06 | Owner decision. No default |
| PRM-03 | Drawdown limit | D | Scenario grid 2, 4, 6, 8, 12% | OWNER_DECISION_PENDING | Owner (OD-01) | F6 n*, F7 | Owner decision. No default |
| PRM-04 | Aggregate exposure fraction | c_agg | None | OWNER_DECISION_PENDING | Owner (OD-01, OD-02) | E_agg = c_agg · E in GT-06(c) | Owner decision. No default |
| PRM-05 | Maximum leverage | ℓ_max | None | UNRESOLVED | Owner (OD-07) | GT-07 and the N/E gate (Step 7) | Owner-set cap with EXP-10 tier table |
| PRM-06 | Stop slippage | s | 0.5% | SCENARIO | Design | F1 and F3 | Paper fills under EXP-05; Live value from realized fills |
| PRM-07 | Taker fee per side | f | 0.06% | PROVISIONAL | OD-08; C6 | F1 and SP-5. 0.05% as sensitivity | EXP-12 |
| PRM-08 | Funding stress per interval | φ | 0.30% | SCENARIO | C7 (observed −30 bp; ±24 bp refuted) | F5 and GT-08 | EXP-09 and observed funding history |
| PRM-09 | Funding multiplier | k | 1 | SCENARIO | Design | F1 and F5: k = floor(H / I_f) + 1 | EXP-09 (I_f) |
| PRM-10 | Adverse entry slippage | ε | 0 | UNRESOLVED | Design (lower bound) | F1 | EXP-05 |
| PRM-11 | Overhead factor | δ | 0 | UNRESOLVED | Design (lower bound) | F6: r_eff = r · (1 + δ) | EXP-05 and Paper fill record |
| PRM-12 | Liquidity-availability fraction | β | 1% of 24h notional per window | SCENARIO | Design (CR-22) | V_min ∝ 1/β | EXP-05, as a distribution |
| PRM-13 | Execution window fraction | w | 1/24 | DERIVED | One hour (§3.7) | V_min ∝ 1/w | Fixed by definition |
| PRM-14 | Safety multiplier | X | 2 | PROVISIONAL | Design. Sensitivity X ∈ {1, 2, 4} | V_min linear in X | EXP-05, upper bound of β |
| PRM-15 | Cost-per-volatility boundary | θ | 1.0 | PROVISIONAL | Design | Step 3 admission. 5m eliminated at 1.42 | EXP-04 |
| PRM-16 | Liquidity count reference | V_cut | 10,000,000 USDT | PROVISIONAL | Count reference only (C9) | Step 5 count. r_crit = 9.58% | EXP-11, as a distribution |
| PRM-17 | Daily loss ratio | q | 1 | PROVISIONAL | G-1 | F8: K_day = q · D · E_start | Paper-phase measurement of daily realized loss (EXP-05 extension). Re-derived if the measured trade-count distribution changes |
| PRM-18 | Maximum venue filter age | — | 24 h | PROVISIONAL | Design (GT-09) | Refusal when older | EXP-08 measurement of filter change frequency |
| PRM-19 | Clock sample interval | T_clk | 60 s | DESIGN_JUDGMENT | §4.11.1 | Age limit = 3 · T_clk = 180 s | Fixed v1. EXP-03 may revise |
| PRM-20 | Clock tolerance | τ_OK | 30 s | DESIGN_JUDGMENT | §4.11.1 (half the 1m bar) | CL-OK boundary | Fixed v1. EXP-03 may replace it with a derived value (design revision) |
| PRM-21 | Clock release count | N_c | 3 | DESIGN_JUDGMENT | §4.5.2 | Release latency 3 · T_clk | Fixed v1 |
| PRM-22 | Offset-jump rejection | — | 1 s | DESIGN_JUDGMENT | §4.11.1 | Sample rejection | Fixed v1 |
| PRM-23 | Knowability allowance | A_k | max(5 s, u_clk) | DERIVED | §4.11.2; CR-29; DR-28 | BV-5 and BV-7. u_clk = half the round-trip delay of the accepted sample, plus drift over T_clk | u_clk from EXP-03. Floor of 5 s is PROVISIONAL |
| PRM-24 | Symbol release count | N_v | 2 | DESIGN_JUDGMENT | §4.5.2 | VC-1 release latency of at least 2 bars | Fixed v1 |
| PRM-25 | Reconciliation cycle | T_rec | 60 s | DESIGN_JUDGMENT | §4.11.5 | Escalation latency R_bound · T_rec = 3 min | Fixed v1 |
| PRM-26 | Reconciliation escalation count | R_bound | 3 | DESIGN_JUDGMENT | §4.7.3 | VC-3 latency | Fixed v1 |
| PRM-27 | Query attempts | Q_max | 3, with backoff 2 s then 4 s | DESIGN_JUDGMENT | §4.6.2 TX-07 | TX-08 bound | Fixed v1. SOURCE_CHECK of query semantics |
| PRM-28 | Exit re-issue cap | — | 3 | DESIGN_JUDGMENT | §4.6.2 | Bounded re-issue | Fixed v1 |
| PRM-29 | Exchange REST staleness | CH-EX | 60 s | DESIGN_JUDGMENT | §4.10.1 | VC-2 set when exceeded | Fixed v1 |
| PRM-30 | WebSocket staleness | CH-WS | 2 × shortest active entry bar (30 min at 15m) | DERIVED | §4.10.1 | VC-2 set when exceeded | Recomputed when a shorter timeframe is activated |
| PRM-31 | Degraded-channel sample count | — | 3 | DESIGN_JUDGMENT | §4.10.1 | VC-2 set on degraded state | Fixed v1 |
| PRM-32 | Reconnect backoff | — | Base 2 s, cap 300 s | DESIGN_JUDGMENT | §4.10.3 RC-1 | Reconnect timing | Fixed v1 |
| PRM-33 | OC-1 / OC-2 boundary | — | 1 h | DESIGN_JUDGMENT | §4.10.2 | Reconciliation scope | Fixed v1. Ratification under OD-05 |
| PRM-34 | OC-3 window | — | 3 days | PROVISIONAL | C12; OD-05 | Reconciliation deferral only | OD-05 ratification |
| PRM-35 | Breaker breach count | K_b | 3 | DESIGN_JUDGMENT | §4.10.4 | VC-3 by breaker | Fixed v1. SOURCE_CHECK of venue limits |
| PRM-36 | Breaker monitoring window | W_b | 60 min | DESIGN_JUDGMENT | §4.10.4; GAP-P4-06 | Breaker close condition | Replaced when the venue rate-limit window is verified (SOURCE_CHECK) |
| PRM-37 | Cooldown after −1003 | — | 60 s initial, doubling per consecutive −1003, cap 900 s | DESIGN_JUDGMENT | §4.10.1; R-022 | VC-2 duration | SOURCE_CHECK of venue penalty behavior |
| PRM-38 | Restart budget | — | 3 restarts per 60 min | PROVISIONAL | DR-18 | §4.9 row 11 | Fixed v1. Crash record in Paper phase |
| PRM-39 | Command reason length | — | 200 characters | PROVISIONAL | §4.8.2 CMD-05 | Input validation | Fixed v1 |
| PRM-40 | Holdout fraction | f_h | 0.25 | DESIGN_JUDGMENT | §5.2 | Split of L_total into L_b and L_hold | Fixed v1. Change is a protocol version |
| PRM-41 | Minimum holdout span | — | 90 days | DESIGN_JUDGMENT | SP-8 | Evaluability | Fixed v1 |
| PRM-42 | Required program span | L_req | 455 days | DESIGN_JUDGMENT | §5.2 | Feasibility gate for 2h and shorter | Fixed v1 |
| PRM-43 | Minimum holdout trades | N_tr_min | 30 | DESIGN_JUDGMENT | SP-4; SP-8 | Evaluability | Fixed v1 |
| PRM-44 | MinTRL confidence level | — | 0.95 | DESIGN_JUDGMENT | SP-7 | Reported field only | Fixed v1 |
| PRM-45 | Planning target scale | E_T | 1.0 | DESIGN_JUDGMENT | §5.3.5; DR-20 | N_rec per §5.3.2 | Declared per program. Not a return target |
| PRM-46 | Trial budget per timeframe | N_max_eff | 1 (1m to 2h), 1 (4h), 2 (6h), 3 (8h), 6 (12h); 1d context 6 or 36 by depth | DERIVED | §5.3.4 with DESIGN_JUDGMENT E_T | Budget ceiling per program | Recomputed per program depth and declared E_T |
| PRM-47 | Backfill page bound | P_max | ceil(1.1 × pages at L_req); 1m: 207 | DERIVED | §4.11.4 | Bound on paginated backfill | Recomputed when L_req changes |
| PRM-48 | Per-request candle cap | — | 3,500 candles | RATIFIED_FINDING | C2 (perpetual symbols) | Page size | Census extension only |
| PRM-49 | Storage per bar | b | 48 bytes | DESIGN_JUDGMENT | §3.3 | S_data floor and M_live | EXP-06 |
| PRM-50 | Storage model constants | M_0, g | None | UNRESOLVED | §3.3 | M_live | EXP-01 |
| PRM-51 | Entry timer expiry | — | Earlier of next entry-bar close and next 00:00 UTC | DERIVED | §4.9 row 4; TX-11 | Resting-order lifetime | None (definition) |
| PRM-52 | Time-stop boundary | — | Next 00:00 UTC after entry | DERIVED | §3.6 Step 2 (A6); §4.9 row 3 | Maximum holding (below 24 h) | None (definition) |
| PRM-53 | Weight estimate for unknown endpoints | — | None | UNRESOLVED | GAP-P4-06; R-024 | Internal weight ledger | SOURCE_CHECK of venue weights |

**Register status count (arithmetic).**

| Status | Rows | IDs |
|---|---|---|
| ILLUSTRATIVE | 1 | PRM-01 |
| OWNER_DECISION_PENDING | 3 | PRM-02, PRM-03, PRM-04 |
| UNRESOLVED | 5 | PRM-05, PRM-10, PRM-11, PRM-50, PRM-53 |
| SCENARIO | 4 | PRM-06, PRM-08, PRM-09, PRM-12 |
| PROVISIONAL | 9 | PRM-07, PRM-14, PRM-15, PRM-16, PRM-17, PRM-18, PRM-34, PRM-38, PRM-39 |
| DERIVED | 7 | PRM-13, PRM-23, PRM-30, PRM-46, PRM-47, PRM-51, PRM-52 |
| RATIFIED_FINDING | 1 | PRM-48 |
| DESIGN_JUDGMENT | 23 | PRM-19 to PRM-22, PRM-24 to PRM-29, PRM-31 to PRM-33, PRM-35 to PRM-37, PRM-40 to PRM-45, PRM-49 |
| **Total** | **53** | 1 + 3 + 5 + 4 + 9 + 7 + 1 + 23 = 53 |

The register contains 53 rows (PRM-01 to PRM-53), all with unique identifiers.

#### §5.5.1 Decision Records Added in Part 5

| ID | Decision | Derivation (D13) | Rejected alternative |
|---|---|---|---|
| DR-20 | Planning scale E_T = 1.0, the lowest tabulated scale. It is not a return target. | It yields the smallest admissible budget and is the conservative reading under C22. | E_T = 2.0 reproduces the 4h lower bound. It enlarges the budget without a derivation in the record. Rejected. E_T inferred from an owner return expectation: no such expectation exists. Rejected. |
| DR-21 | E_T is fixed per program ledger. A raise requires a new protocol version. Earlier trials for the same symbol and timeframe keep counting. | Prevents selective re-testing after results are known. | Resetting the ledger on protocol change. Rejected, because it allows discarded trials to vanish from the count. |
| DR-22 | The budget counts performance-based choices. Rule-based admission is excluded. | Rule-based admission precedes any performance result, so it is not a selection. | Counting all candidate pairs, including rule-admitted ones. Rejected, because it would make the D14 universe inadmissible by definition. Counting no choices. Rejected, because it permits unbounded search. |
| DR-23 | Holdouts are opened once. Forward Paper data forms new holdouts. | Keeps the holdout independent of selection. | Reusing a holdout after results. Rejected (contamination). Using Paper data for search. Rejected, because it converts the holdout into search data. |
| DR-24 | Retired CSCV arithmetic and CSCV-based overfitting probability are not used. | The brief retires the arithmetic. Any replacement needs its own SOURCE_CHECK. | Reintroducing the retired arithmetic. Rejected. |
| DR-25 | MinBTL and MinTRL are reported separately. Neither gates. | R-061 keeps them distinct. The 19.54-year input has no recorded SR. | A MinTRL gate using the 19.54 figure. Rejected. MinBTL as track-record significance. Rejected (conflation). |
| DR-26 | The budget uses L_b. Coverage uses L_total. | Using L_total overstates admissible configurations by a factor of 1/(1 − f_h) = 1.33 in span. It also uses the holdout in selection. | Budget on L_total. Rejected. |
| DR-27 | Programs at 2h or shorter require measured paginated depth (EXP-13) before any protocol run. | Cap-only depth cannot satisfy the 90-day holdout span at 2h or shorter. | Relaxing the 90-day minimum for short timeframes. Rejected, because it weakens evaluability. |
| DR-28 | A_k = max(5 s, u_clk). | Knowability depends on the residual error of the accepted offset, not on the tolerance τ_OK (CR-29). | A fixed 5 s. Rejected, because it ignores measured error. τ_OK as A_k. Rejected, because it conflates tolerance with error. |

#### §5.5.2 New Experiment

**EXP-13 Historical depth census (public endpoints only).**
- **Scope.** The symbol pool (134 lower bound, C9) and each candidate entry timeframe (1m to 12h, 10 timeframes), plus 1d.
- **Method.** Paginated public kline requests, backward from the most recent bar, bounded by P_max (PRM-47). No authentication (A4).
- **Record per (symbol, timeframe).** Earliest and latest open time (UTC), page count, gap count, and the UTC time of the census.
- **Pass criterion for a (symbol, timeframe) pair to host a protocol program.** Depth ≥ L_req (455 days) and no unresolved gaps under BV-1 to BV-3.
- **Status.** Not run in this engagement. Endpoint parameters are SOURCE_CHECK.
- **Closes.** L_total for every entry timeframe; the depth dependency of Table 5.2; CR-30.

#### §5.5.3 New Contradictions Identified in Part 5

| ID | Contradiction | Resolution |
|---|---|---|
| CR-27 | C23 pair not reproducible. The 4h range (10–20) implies E_T ∈ [1.96, 2.24] on L_b (or [1.70, 1.94] on L_total). The 1d "thousands" implies E_T ∈ [1.39, 1.60] on L_b (or [1.20, 1.39] on L_total). The intervals are disjoint. | Recorded NOT_REPRODUCED. Neither figure is adopted as operative. The budget is recomputed by §5.3.1 and §5.3.4. The missing inputs are recorded in §5.8 (message 2). |
| CR-28 | C23 published 4h value (10–20) versus operative value under C22 at planning scale (1). | The published value is retained as a record. It is reproduced only at E_T ≈ 1.96 on L_b. The operative value is N_max_eff per §5.3.4. The declaration rules in DR-20 and DR-21 govern any change. |
| CR-29 | A_k = 5 s (Part 4 §4.11.2) appears smaller than τ_OK = 30 s (§4.11.1). | Apparent conflict, because the two quantities differ. τ_OK bounds the magnitude of the accepted offset, while A_k covers residual estimation error. A_k = max(5 s, u_clk) (PRM-23, DR-28). |
| CR-30 | Part 3 Step 4 coverage at cap treats the 3,500-candle cap as a history limit. §4.11.4 treats it as a per-request limit. | The Step 4 values are cap-only lower bounds (§5.2). Depth is measured by EXP-13. |

---

**پیام بعدی (پارت ۵، پیام ۲ از ۲):** §۵.۶ ماتریس الزام به تأیید با دقیقاً ۷۸ ردیف (R-001 تا R-078)، §۵.۷ خودبازبینی انتقادی طبق §۱۳ بریف، §۵.۸ سجل انتشار (PL-P5)، شکاف‌های بخش ۵ (GAP-P5) و §۵.۹ اعلامیه تکمیل پارت ۵ با محاسبه حسابی. پارت ۶ پس از ارسال کامل پارت ۵ آغاز می‌شود.


# بخش ۵ از ۶: روش‌شناسی آماری، بودجه آزمون و سجل پارامترها (پیام ۲ از ۲)
## Part 5/6: Statistical Methodology, Trial Budget and Parameter Register (Message 2 of 2)

این پیام ادامه و پایان بخش ۵ است. ماتریس تطبیق ۷۸ ردیفی، بردارهای مرزی R-008، خوداَرزیابی، سجل انتشار، سجل شکاف‌ها و اعلان تکمیل بخش ۵ در این پیام آمده است. هیچ وضعیت PASS جدیدی ثبت نشده است. بخش ۶ پس از این پیام تولید می‌شود.

---

## §5.6 Requirement-to-verification matrix

**Scope.** This matrix maps every register row R-001 to R-078 to its Part 5 disposition. The register status column is copied from Part 2 and is not changed by Part 5. No row is promoted to PASS by Part 5.

**Disposition key.**
- **RETAINED:** the requirement is owned by Part 1 to Part 4 and Part 5 adds no rule for it. Its verification is carried forward.
- **SPECIFIED:** Part 5 states a verification rule or protocol rule for the requirement. The rule is not executed.
- **ARITHMETIC_CHECKED:** Part 5 derives or checks the relevant numbers by hand in this design. No fixture or run was executed.
- **NOT_EVALUABLE:** verification depends on a named experiment, measurement or source check that has not been executed. The dependency is named in the row.
- **BLOCKED:** the requirement is blocked by an owner decision or an absent input, unchanged from Part 2.

| # | R-ID | Register status | Disposition | Part 5 content | Dependency |
|---|---|---|---|---|---|
| 1 | R-001 | NOT TESTED | RETAINED | No Part 5 statistic depends on venue scope. Toobit cost and funding inputs are carried in SP-5. Verification mapping is Part 6. | Part 6 |
| 2 | R-002 | NOT TESTED | SPECIFIED | SP-9 defines no verdict command. Any Part 5 report reaches the operator only through the Part 4 §4.8 message envelope. | None |
| 3 | R-003 | PASS | RETAINED | Retained PASS from Part 2. All Part 5 inputs are public or ratified. No account data is used. | None |
| 4 | R-004 | BLOCKED | BLOCKED | BV-8 and SP-5 exclude cross-venue series from every SP-4 partition and every protocol run. | OD-04 |
| 5 | R-005 | PASS | RETAINED | Retained PASS from Part 2. | None |
| 6 | R-006 | NOT TESTED | SPECIFIED | Every Part 5 value carries a label from §5.5. No value is labelled HARD. E_T is a DESIGN_JUDGMENT and not an owner target (DR-20). Inspection recorded as SR-6. | None |
| 7 | R-007 | NOT TESTED | SPECIFIED | UTC is used for record time (SP-1), partition boundaries (SP-3, SP-4) and day keys (§5.6.1). | BVT-01 to BVT-12 |
| 8 | R-008 | NOT TESTED | ARITHMETIC_CHECKED | Daily boundary, ISO-8601 week boundary and DST-free cases are delivered as BVT-01 to BVT-12 in §5.6.1. Calendar values were hand-checked. The fixture was not executed. | Fixture in Part 6; EXP-07 for runtime |
| 9 | R-009 | NOT TESTED | SPECIFIED | Protocol time uses bar timestamps. Purge, embargo and holdout use bar counts and UTC instants. Monotonic elapsed time applies only to runtime deadlines (Part 4 §4.11). | EXP-03 for runtime clock |
| 10 | R-010 | UNRESOLVED | NOT_EVALUABLE | The clock-class verdict depends on τ_OK (PRM-20) and u_clk (PRM-23). Neither has been measured. | EXP-03 |
| 11 | R-011 | NOT TESTED | SPECIFIED | SP-4 uses bar open and close. BV-7 uses knowability time. SP-1 uses UTC record time. The device wall clock is not used as event time. | None |
| 12 | R-012 | NOT TESTED | RETAINED | Part 5 adds no RS field. The trial ledger (SP-1) is a separate append-only record family in the research store (DR-16). Propagation is logged as PL-P5-12. | Part 4 §4.5.1 |
| 13 | R-013 | NOT TESTED | SPECIFIED | A missing or corrupt trial ledger is never rebuilt from market data. SP-8(d) returns NOT_EVALUABLE for the affected program. | None |
| 14 | R-014 | NOT TESTED | RETAINED | Veto release and /ack are Part 4 §4.4 rules. Part 5 introduces no veto. | Part 4 §4.4 |
| 15 | R-015 | BLOCKED | BLOCKED | Part 5 grants no Live permission (SP-9). Live entry remains conditional on OD-01 and OD-02 through Part 4. | OD-01, OD-02 |
| 16 | R-016 | NOT TESTED | SPECIFIED | SP-5 reports nominal stop risk, funding stress and realized loss as separate columns. No statistic treats a loss cap as guaranteed. Propagation is logged as PL-P5-13. | Part 4 §4.5.1 |
| 17 | R-017 | BLOCKED | BLOCKED | Part 5 sets no leverage cap. PRM-05 has no default. SP-8(f) requires verified tier input. | OD-07, EXP-10 |
| 18 | R-018 | NOT TESTED | NOT_EVALUABLE | φ = 0.30% per interval (SP-5, PRM-08) represents −30 bp. I_f is unknown, so funding-dependent S5 is NOT_EVALUABLE for Live. | EXP-09 |
| 19 | R-019 | UNRESOLVED | BLOCKED | Part 5 does not set exposure or position caps. c_agg, D and r are owner decisions. | OD-01, OD-02 |
| 20 | R-020 | NOT TESTED | RETAINED | Order states are Part 4 §4.6. Protocol fills are simulated under SP-3 and do not exercise the order state machine. | Part 4 §4.6 |
| 21 | R-021 | NOT TESTED | RETAINED | Venue error mapping is Part 4 §4.6 (TX-06). Part 5 does not classify venue errors. | SOURCE_CHECK |
| 22 | R-022 | NOT TESTED | RETAINED | Cooldown and breaker are Part 4 §4.10.4 with PRM-35 to PRM-37. | SOURCE_CHECK |
| 23 | R-023 | UNRESOLVED | NOT_EVALUABLE | Query bound Q_max = 3 (PRM-27) and exit re-issue cap 3 (PRM-28) are design values. Venue-side retry semantics need SOURCE_CHECK. | SOURCE_CHECK |
| 24 | R-024 | NOT TESTED | NOT_EVALUABLE | Weight estimates for unknown endpoints (PRM-53) are UNRESOLVED. No weight budget can be verified yet. | SOURCE_CHECK |
| 25 | R-025 | NOT TESTED | RETAINED | The clientOrderId length limit is GAP-P4-10. Charset is enforced by Part 4. | SOURCE_CHECK |
| 26 | R-026 | BLOCKED | BLOCKED | Startup reconciliation is Part 4 §4.7. Part 5 makes no change. | Part 4 §4.7 |
| 27 | R-027 | UNRESOLVED | RETAINED | The 3-day value (PRM-34, PROVISIONAL, C12) applies only to reconciliation deferral. No Part 5 statistic uses it. | OD-05 |
| 28 | R-028 | NOT TESTED | SPECIFIED | SP-5 uses f = 0.06% per side as the conservative value and 0.05% as sensitivity. | EXP-12 |
| 29 | R-029 | NOT TESTED | SPECIFIED | BV-1 to BV-6 define SP-8(c) holdout validity. Any non-VALID holdout bar makes the program NOT_EVALUABLE. | None |
| 30 | R-030 | NOT TESTED | SPECIFIED | SP-3 pre-registration hash must match (SP-8(e)). SP-1 records the configuration hash. | None |
| 31 | R-031 | BLOCKED | BLOCKED | Credential and permission checks are Part 4 IP-5. Part 5 does not access credentials. | Owner-supplied credentials are outside this engagement (A4) |
| 32 | R-032 | NOT TESTED | RETAINED | Telegram transport is Part 4 §4.8. | Part 4 §4.8 |
| 33 | R-033 | NOT TESTED | RETAINED | Protocol results do not depend on Telegram delivery. Operator silence changes no protocol state. | Part 4 RA-4 |
| 34 | R-034 | UNRESOLVED | RETAINED | The operator-unreachable policy is Part 4 §4.9. Conditional-order support requires SOURCE_CHECK (GAP-P4-01). | GAP-P4-01 |
| 35 | R-035 | NOT TESTED | RETAINED | Command preconditions are Part 4 §4.8. | Part 4 §4.8 |
| 36 | R-036 | NOT TESTED | RETAINED | The command set CMD-01 to CMD-07 contains no protocol verdict command. | Part 4 §4.8 |
| 37 | R-037 | NOT TESTED | SPECIFIED | Any protocol report uses the Part 4 §4.8 envelope. Its data timestamp is the last knowable bar close of the cited symbols. | None |
| 38 | R-038 | NOT TESTED | SPECIFIED | SP-9 and SP-10 ensure no statistic gates Paper or Live selection. No waiting period is introduced. | None |
| 39 | R-039 | NOT TESTED | RETAINED | Refusal naming is Part 4 §4.8.3. | Part 4 §4.8.3 |
| 40 | R-040 | NOT TESTED | RETAINED | The phase deviation table is Part 3 §3.5. | Part 3 §3.5 |
| 41 | R-041 | NOT TESTED | RETAINED | The D14 chain is Part 3 §3.6. Part 5 uses Step 4 values as cap-only lower bounds (CR-30). | EXP-13 |
| 42 | R-042 | NOT TESTED | RETAINED | The liquidity chain is Part 3 §3.7. Part 5 does not use it. | EXP-05 |
| 43 | R-043 | UNRESOLVED | NOT_EVALUABLE | Snapshot dating and refresh (EXP-11) are pending. SP-3 hashes the symbol pool used. | EXP-11 |
| 44 | R-044 | UNRESOLVED | RETAINED | Capacity uses 24h notional (Part 3 §3.7). Part 5 has no capacity statistic. | OD-11 |
| 45 | R-045 | NOT TESTED | ARITHMETIC_CHECKED | Table 5.2 covers 11 timeframes. The 14-item ceiling is accounted in §5.6.2. | EXP-04 for cost |
| 46 | R-046 | NOT TESTED | ARITHMETIC_CHECKED | Page counts in Table 5.2 equal ceil(bars at L_req / 3,500). P_max = ceil(1.1 × pages) (PRM-47). | None |
| 47 | R-047 | NOT TESTED | NOT_EVALUABLE | The shape-matched storage ratio has not been measured. C19 is not shape-matched. PRM-49 (48 bytes per bar) is a DESIGN_JUDGMENT. | EXP-06 |
| 48 | R-048 | NOT TESTED | SPECIFIED | BV-8 prohibits markPrice in any feature or fill. SP-5 uses the close of mark-free series. | OD-10 |
| 49 | R-049 | NOT TESTED | SPECIFIED | BV-8 excludes historical OI features from every protocol run. | OD-09 |
| 50 | R-050 | NOT TESTED | RETAINED | Envelope-first derivation is Part 3 §3.3. | Part 3 §3.3 |
| 51 | R-051 | NOT TESTED | RETAINED | Topology enumeration is Part 3 §3.4. | Part 3 §3.4 |
| 52 | R-052 | UNRESOLVED | NOT_EVALUABLE | Sustained device capacity requires EXP-01. | EXP-01 |
| 53 | R-053 | UNRESOLVED | NOT_EVALUABLE | Background operation under App Standby Bucket requires EXP-02. | EXP-02 |
| 54 | R-054 | NOT TESTED | NOT_EVALUABLE | The build-record requirement is a SHOULD. EXP-07 is required before any record exists. | EXP-07 |
| 55 | R-055 | UNRESOLVED | NOT_EVALUABLE | The phone-as-host decision depends on EXP-01 and EXP-02 passing. | EXP-01, EXP-02 |
| 56 | R-056 | BLOCKED | BLOCKED | Remote hosting cost is an owner decision. | OD-13 |
| 57 | R-057 | NOT TESTED | SPECIFIED | SP-7 and SP-9 prohibit acceptance or rejection on statistical grounds. Inspection recorded as SR-2. | None |
| 58 | R-058 | NOT TESTED | ARITHMETIC_CHECKED | At the planning scale, N_max_eff is at most 1 for 1m to 4h, 2 for 6h, 3 for 8h and 6 for 12h (§5.3.4). No grid is formed at any timeframe ≤ 12h. | C24 |
| 59 | R-059 | NOT TESTED | ARITHMETIC_CHECKED | Rule applied at 4h: R = 1, P_low = 10, ρ = 10 > 2, so N_max_eff = 1. Rule applied at 1d: no comparable published value, so R governs. | None |
| 60 | R-060 | UNRESOLVED | SPECIFIED | Every budget figure carries a PROVISIONAL or C23 label (§5.3.2, §5.3.4). Recomputation status is CR-27. | EXP-13 |
| 61 | R-061 | BLOCKED | BLOCKED | MinTRL is reported as a field (SP-7) and cannot be computed because per-candidate inputs are absent. The 19.54-year figure is not used (CR-04, DR-25). | Per-candidate inputs |
| 62 | R-062 | UNRESOLVED | SPECIFIED | DSR unit is declared per period (SP-2, SP-6). The C20 unit is unknown and C20 is not reused. | GAP-P5-04 |
| 63 | R-063 | NOT TESTED | NOT_EVALUABLE | Cost-per-volatility at 1m, 3m, 30m, 1h, 2h, 4h, 6h, 8h and 12h requires EXP-04. Part 5 uses θ = 1.0 only. | EXP-04 |
| 64 | R-064 | BLOCKED | BLOCKED | Cross-venue basis is research-only at 1h and 4h. Part 5 excludes it from protocol runs. | OD-04 |
| 65 | R-065 | NOT TESTED | SPECIFIED | Every formula in §5.3.1 and §5.4 is labelled SOURCE_CHECK. No research result is claimed as retrieved. | GAP-P5-05 |
| 66 | R-066 | NOT TESTED | SPECIFIED | The monetary quantities in Part 5 are E (PRM-01) and V_cut (PRM-16), both in USDT. All other Part 5 quantities are dimensionless. | None |
| 67 | R-067 | NOT TESTED | SPECIFIED | E is parametric. Budget and N_max_eff depend only on E_T and L_b, not on E. | None |
| 68 | R-068 | NOT TESTED | SPECIFIED | Scenario grids PRM-02 and PRM-03 are not used as defaults. PRM-17 (q = 1) is a PROVISIONAL ratio, not an illustrative risk value. | OD-01, OD-02 |
| 69 | R-069 | NOT TESTED | SPECIFIED | Sensitivity is shown for E_T ∈ {1.0, 1.5, 2.0} (§5.3.2), for L_total versus L_b (§5.3.3), and for X and β as ranges (Part 3). | None |
| 70 | R-070 | NOT TESTED | SPECIFIED | The E_T derivation is recorded in DR-20 and §5.3.5. No owner preference is inferred. | None |
| 71 | R-071 | NOT TESTED | SPECIFIED | Part 5 raises no owner question. Inspection recorded as SR-6. | None |
| 72 | R-072 | BLOCKED | BLOCKED | Utility is not inferred. DR-20 forbids return-based E_T. | OD-03 |
| 73 | R-073 | NOT TESTED | SPECIFIED | Part N/M numbering and bilingual headers are used. Inspection recorded in §5.9. | None |
| 74 | R-074 | NOT TESTED | SPECIFIED | Forbidden-phrase check was applied by manual inspection (SR-8). The executed scan across all six parts is Part 6. | Part 6 |
| 75 | R-075 | NOT TESTED | ARITHMETIC_CHECKED | The matrix contains 78 rows equal to the register's 78 rows (§5.9). | None |
| 76 | R-076 | NOT TESTED | ARITHMETIC_CHECKED | Part 5 identifier namespaces contain no duplicates (§5.9). The full catalog check is Part 6. | Part 6 |
| 77 | R-077 | NOT TESTED | SPECIFIED | No readiness or profitability claim is made. Inspection recorded as SR-7. | None |
| 78 | R-078 | NOT TESTED | NOT_EVALUABLE | GT-09 filter inputs require EXP-08. Part 5 adds the filter snapshot hash to SP-3 (PL-P5-04). | EXP-08 |

**Disposition counts:** RETAINED 22; SPECIFIED 27; ARITHMETIC_CHECKED 7; NOT_EVALUABLE 12; BLOCKED 10. Sum 22 + 27 + 7 + 12 + 10 = 78.

### §5.6.1 Boundary vector set (R-008)

**Conventions.**
- A UTC day key is the calendar date of the instant in UTC. A bar belongs to the UTC day of its open time (DESIGN_JUDGMENT, derived from BV-5 and PRM-52).
- An ISO-8601 week starts on Monday 00:00:00 UTC. Its week-numbering year may differ from the calendar year.
- UTC has no daylight-saving transitions. The DST-free vectors confirm that local-zone transitions do not alter UTC keys.
- Day-of-week values were derived from the anchor 2024-01-01 (Monday, week 2024-W01).

| Vector | UTC instant | Expected day key | Expected ISO week | Purpose |
|---|---|---|---|---|
| BVT-01 | 2024-01-01T00:00:00.000Z | 2024-01-01 | 2024-W01 | Day start and week start (Monday) |
| BVT-02 | 2023-12-31T23:59:59.999Z | 2023-12-31 | 2023-W52 | Last instant of a day and of a Sunday |
| BVT-03 | 2024-01-07T23:59:59.999Z | 2024-01-07 | 2024-W01 | Last instant of an ISO week |
| BVT-04 | 2024-01-08T00:00:00.000Z | 2024-01-08 | 2024-W02 | First instant of the next week |
| BVT-05 | 2024-02-29T00:00:00.000Z | 2024-02-29 | 2024-W09 | Leap day, no exception |
| BVT-06 | 2024-12-29T23:59:59.999Z | 2024-12-29 | 2024-W52 | Last instant before ISO week-year change |
| BVT-07 | 2024-12-30T00:00:00.000Z | 2024-12-30 | 2025-W01 | Week-year differs from calendar year |
| BVT-08 | 2021-01-01T00:00:00.000Z | 2021-01-01 | 2020-W53 | ISO week 53 of 2020 extends into 2021 |
| BVT-09 | 2024-03-10T06:30:00.000Z | 2024-03-10 | 2024-W10 | DST-free: one half-hour before the US transition at 07:00 UTC |
| BVT-10 | 2024-03-31T00:59:59.999Z | 2024-03-31 | 2024-W13 | DST-free: one millisecond before the EU transition at 01:00 UTC |
| BVT-11 | Bar open 2024-05-06T23:45:00.000Z, close 2024-05-07T00:00:00.000Z | 2024-05-06 (bar belongs to open day) | 2024-W19 | Intraday bar crossing the UTC day boundary; time-stop boundary at 2024-05-07T00:00:00.000Z |
| BVT-12 | Bar open 2024-05-07T00:00:00.000Z, close 2024-05-07T00:15:00.000Z | 2024-05-07 | 2024-W19 | Knowability at 00:15:05.000Z using the 5 s floor for A_k (full value after EXP-03) |

**Pass criterion.** A fixture evaluates utc_day_key and iso_week for each vector and compares them with the expected values. Any mismatch is a FAIL for R-008 and blocks every protocol run.

**Status.** SPECIFIED and ARITHMETIC_CHECKED. The fixture is not executed, so R-008 remains NOT TESTED.

### §5.6.2 Timeframe accounting for the protocol

| Timeframe | Part 5 treatment | Reason |
|---|---|---|
| 1m | Table 5.2 row, entry | Admitted provisionally (Part 3 Step 3) |
| 3m | Table 5.2 row, entry | Admitted provisionally |
| 5m | Not in Table 5.2 | Eliminated by cost ratio 1.42 > θ |
| 15m | Table 5.2 row, entry | Admitted (cost ratio 0.82) |
| 30m | Table 5.2 row, entry | Provisional |
| 1h | Table 5.2 row, entry | Provisional |
| 2h | Table 5.2 row, entry | Provisional |
| 4h | Table 5.2 row, entry | Provisional |
| 6h | Table 5.2 row, entry | Provisional |
| 8h | Table 5.2 row, entry | Provisional |
| 12h | Table 5.2 row, entry | Provisional |
| 1d | Table 5.2 row, context only | Context-only (Part 3 Step 2; SR-4) |
| 1w | Not in Table 5.2 | Context-only |
| 1M | Not in Table 5.2 | Context-only |

**Arithmetic.** Table 5.2 rows: 11. Excluded at Step 3: 1 (5m). Context-only not in table: 2 (1w, 1M). Sum 11 + 1 + 2 = 14. The 3d value is not in the C1 list and is excluded (UNSUPPORTED_CONFIRMED).

---

## §5.7 Adversarial self-review

**Basis.** These checks apply the self-audit requirements of §13 of the brief to the Part 5 content. A check is an inspection of the text and its arithmetic. No tool was run.

| Check | Question | Finding | Result |
|---|---|---|---|
| SR-1 | Does any Part 5 item overclaim? | No register row is set to PASS. Dispositions are RETAINED, SPECIFIED, ARITHMETIC_CHECKED, NOT_EVALUABLE or BLOCKED. | PASS |
| SR-2 | Does any statistic gate Paper or Live? | MinBTL, MinTRL, DSR and E_T gate nothing. SP-7 is reporting only. SP-9 forbids accept or reject vocabulary. | PASS |
| SR-3 | Can search or selection touch the holdout? | The holdout is the final L_hold span (SP-4). Selection uses L_b only. The holdout is opened once (SP-10). Purge is H_max < 24 h for intraday entries. | PASS |
| SR-4 | Can a 1d-based feature be purged by the 24 h rule? | A single 1d bar spans 24 h, so the intraday purge rule cannot isolate it. 1d appears only as context. | AMENDED (PL-P5-16). A 1d context feature is lagged by one completed UTC day, purge equals one 1d bar, and the 1d budget row counts its trials. |
| SR-5 | Are per-period and annualized Sharpe-type values compared directly? | §5.3 compares E_T (annualized) with the MinBTL approximation. SP-6 uses per-period SR̂. No conversion rule was stated. | AMENDED (PL-P5-17). SP-2 requires SR_ann = SR_period × √(periods per year) before any comparison with E_T. |
| SR-6 | Does Part 5 raise an owner question? | None. OD items remain in Part 4 and Part 6 where they belong. | PASS |
| SR-7 | Does Part 5 claim readiness or profitability? | None. | PASS |
| SR-8 | Does the text contain forbidden phrases? | Manual inspection against the forbidden list. The executed scan across all six parts is Part 6. | PASS (manual) |
| SR-9 | Is every number traced? | Calendar values are fixed facts. PRM-47 (207) is derived. V_cut is a count reference from C9. Each PRM carries a label. | PASS |
| SR-10 | Is there look-ahead? | BV-7, A_k and the SP-5 funding convention (funding applied at settlement) prevent use of unknowable values. | PASS |
| SR-11 | Is the cost model consistent with Part 3? | L = s + 2f + ε + kφ counts both sides through 2f. SP-5 uses f per side. | PASS |
| SR-12 | Does the planning scale suppress legitimate search? | At E_T = 1.0, performance-based selection among configurations has budget 1 at 1m to 4h and at most 6 at 12h. This is the least search-permissive scale. A critic could argue it hides strategies. Response: A12 and D19 separate architecture and method from the budget. Budget counts only performance-based choices. A single pre-registered configuration remains admissible. A higher E_T requires a new protocol version after EXP-13 (DR-21). | RESIDUAL (GAP-P5-09; PL-P5-26) |
| SR-13 | Does pooling hide weak symbols? | SP-12 tests the pooled portfolio series. Per-symbol statistics are descriptive. A pooled statistic can mask symbol-level weakness. | RESIDUAL, disclosed |
| SR-14 | Are holdout feasibility results sensitive to depth? | Table 5.2 uses cap-only spans. If true depth is shorter, the 4h and 6h holdout results change. | RESIDUAL (GAP-P5-01, EXP-13) |
| SR-15 | Does every NOT_EVALUABLE row name its dependency? | Yes. Twelve rows, each with a named EXP, source check or input. | PASS |

**Result.** 10 PASS, 2 AMENDED, 3 RESIDUAL. Total 15 = 10 + 2 + 3.

### §5.7.1 Amendments applied by this section

- **Amendment A1 (SP-2, from SR-5).** Before any comparison of a per-period statistic with E_T, annualize: SR_ann = SR_period × √(periods per year). Periods per year = 365 × bars per day for 24/7 bar series (PD-09 convention). Trade series use the declared trade count per year.
- **Amendment A2 (SP-4, from SR-4).** 1d context features are lagged by one completed UTC day. The purge equals one 1d bar. 1d features are never entry inputs. Their trials count against the 1d budget row.
- **Amendment A3 (SP-3, from R-078).** Add field: venue filter snapshot hash with retrieval timestamp and source. Simulated fills apply GT-09, rounding quantity down to the lot step and refusing any order below the minimum executable notional.

---

## §5.8 Propagation log PL-P5 and gap register GAP-P5

### §5.8.1 Propagation log PL-P5

| ID | Source (Part 5 item) | Propagated to | Action | Status |
|---|---|---|---|---|
| PL-P5-01 | §5.2 L_total as cap-only lower bound | R-041, R-046 | Recorded as CR-30; depth verification via EXP-13 | APPLIED (depth OPEN under GAP-P5-01) |
| PL-P5-02 | §5.3.1 budget on L_b | R-060, R-069 | DR-26 applied | APPLIED |
| PL-P5-03 | §5.3.2 to §5.3.4 budget values and labels | R-058, R-059, R-060 | Labels PROVISIONAL and C23 applied | APPLIED |
| PL-P5-04 | SP-3 field: venue filter snapshot hash (A3) | R-078, R-030 | Field added | APPLIED |
| PL-P5-05 | SP-5 funding and cost columns | R-016, R-018, R-028 | Separate columns; gross as labelled secondary | APPLIED |
| PL-P5-06 | SP-8 evaluability conditions (a) to (f) | R-013, R-029, R-030, R-057 | NOT_EVALUABLE with failed condition ID | APPLIED |
| PL-P5-07 | SP-9 result vocabulary | R-002, R-038, R-057 | Only EVALUATED and NOT_EVALUABLE | APPLIED |
| PL-P5-08 | SP-10 holdout opened once | R-057 | DR-23 applied | APPLIED |
| PL-P5-09 | SP-6 DSR formula and unit | R-062, R-065 | Formula labelled SOURCE_CHECK | APPLIED (SOURCE_CHECK OPEN, GAP-P5-05) |
| PL-P5-10 | SP-7 MinTRL report-only | R-057, R-061 | Field only; inputs absent | APPLIED (BLOCKED) |
| PL-P5-11 | SP-12 pooled statistic | R-057 | Pooled series is the tested object | APPLIED |
| PL-P5-12 | R-012 not logged in PL-P4 (§4.5.1, F3) | R-012 | Omission corrected in this log | APPLIED |
| PL-P5-13 | R-016 not logged in PL-P4 (§4.5.1, F3) | R-016 | Omission corrected in this log | APPLIED |
| PL-P5-14 | PL-P4 row count stated as 27 (§4.14.5); §4.14.4 lists 32 | Part 4 §4.14.5 | Count to be corrected in Part 6 | CARRIED to Part 6 |
| PL-P5-15 | §5.6.1 boundary vector set | R-007, R-008 | BVT-01 to BVT-12 delivered | APPLIED (fixture OPEN) |
| PL-P5-16 | SR-4 amendment A2 | SP-4 | 1d context lag and purge | APPLIED |
| PL-P5-17 | SR-5 amendment A1 | SP-2 | Unit conversion before comparison | APPLIED |
| PL-P5-18 | CR-29 (A_k versus τ_OK) | R-010, R-011 | Different quantities; A_k = max(5 s, u_clk) | APPLIED |
| PL-P5-19 | BV-8 exclusions | R-004, R-048, R-049 | Cross-venue, markPrice and OI excluded | APPLIED (R-004 BLOCKED) |
| PL-P5-20 | PRM-02 and PRM-03 scenario grids | R-068, R-069 | Not defaults | APPLIED |
| PL-P5-21 | DR-20 derivation of E_T | R-070, R-072 | No return-based inference | APPLIED (R-072 BLOCKED) |
| PL-P5-22 | CR-27 non-reproduction of C23 pair | R-060 | NOT_REPRODUCED recorded | APPLIED |
| PL-P5-23 | C24 applied as ratified | R-058 | No grid ≤ 12h | APPLIED |
| PL-P5-24 | Trial ledger as separate record family | R-012, R-013 | Research store, append-only | APPLIED |
| PL-P5-25 | Protocol report envelope | R-037 | Part 4 §4.8 envelope | APPLIED |
| PL-P5-26 | SR-12 search restriction under E_T = 1.0 | Part 6 residual list | Candidate residual R-RISK-3 for owner information | CARRIED to Part 6 |

**Count.** 26 entries. APPLIED 24. CARRIED to Part 6 2 (PL-P5-14, PL-P5-26).

### §5.8.2 Gap register GAP-P5

| ID | Gap | Affected rows | Resolution route | Status |
|---|---|---|---|---|
| GAP-P5-01 | Per-symbol historical depth not measured. L_total is cap-only. Holdout feasibility at 2h and shorter is not established (DR-27). | R-041, R-046, R-060 | EXP-13 | UNRESOLVED |
| GAP-P5-02 | C23 pair not reproduced. Published inputs missing (§5.8.3). | R-060, R-062 | Recomputation at measured depth; SOURCE_CHECK of the publication basis | UNRESOLVED |
| GAP-P5-03 | Per-candidate MinTRL inputs (SR*, skewness, kurtosis) absent. | R-061 | Produced per candidate at protocol run | BLOCKED |
| GAP-P5-04 | C20 unit unknown (CR-18). C20 cannot be compared with any Part 5 statistic. | R-062 | None; C20 not used | UNRESOLVED |
| GAP-P5-05 | MinBTL approximation and DSR formula labelled SOURCE_CHECK; not retrieved in this engagement. | R-065, R-062 | SOURCE_CHECK before any protocol run | OPEN |
| GAP-P5-06 | Boundary-vector fixture not executed. | R-007, R-008 | Fixture in Part 6 and EXP-07 for runtime | OPEN |
| GAP-P5-07 | Artifact identifier for Part 5 is ART-11 by sequence. Part 1 assignments for ART-11 are not recoverable from the engagement record. | R-076 | Collision check in Part 6 | OPEN |
| GAP-P5-08 | PL-P4 row count stated as 27; listed rows are 32. | Part 4 §4.14.5 | Correction in Part 6 | OPEN |
| GAP-P5-09 | E_T = 1.0 leaves performance-based search budget 1 at 1m to 4h. | R-058, R-069 | Owner information in Part 6 as candidate R-RISK-3; higher E_T only through a new protocol version | RESIDUAL |
| GAP-P5-10 | Trade count per year needed for trade-series annualization (SP-2). | R-062 | Declared at pre-registration | OPEN |
| GAP-P5-11 | Funding interval I_f unconfirmed. S5 cannot be evaluated for Live. | R-018 | EXP-09 | UNRESOLVED |
| GAP-P5-12 | Self-review is inspection only. It does not prove absence of defects. | R-074, R-075, R-076 | Executed checks in Part 6 and fixture tests | OPEN |

**Count.** 12 entries, GAP-P5-01 to GAP-P5-12.

### §5.8.3 CR-27 inputs missing from the published record

The following inputs for the published 4h value (10 to 20) and the published 1d value (1,000 to 9,999) are not recorded in the engagement record. Each is required to reproduce the pair. None is an owner question.

1. Published E_T value used by the publisher.
2. Published budget convention: L_b, L_total or another span.
3. Published sample length per symbol (for example 1,774 bars versus 3,500 bars).
4. Published Sharpe unit: per period, annualized or per trade.
5. Published MinBTL approximation variant and rounding rule.
6. Whether published counts are before or after sample-length correction.
7. Published symbol and timeframe pairing.

**Result.** The published 4h interval [1.96, 2.24] on L_b and the 1d interval [1.39, 1.60] on L_b are disjoint. The pair is NOT_REPRODUCED (CR-27). Neither published figure is adopted as operative.

---

## §5.9 Part 5 completeness declaration

**Sections present.**
- Message 1: §5.0 to §5.5, with §5.5.1 (DR-20 to DR-28), §5.5.2 (EXP-13) and §5.5.3 (CR-27 to CR-30).
- Message 2: §5.6 (matrix), §5.6.1 (boundary vectors), §5.6.2 (timeframe accounting), §5.7 (self-review, with §5.7.1 amendments), §5.8 (PL-P5 and GAP-P5, with §5.8.2 and §5.8.3), §5.9 (this declaration).

**Arithmetic.**
- Matrix rows: 78. Register rows: 78. 78 = 78 ✓ (R-075).
- Matrix dispositions: RETAINED 22 + SPECIFIED 27 + ARITHMETIC_CHECKED 7 + NOT_EVALUABLE 12 + BLOCKED 10 = 78 ✓.
- Register status, unchanged by Part 5: PASS 2 + FAIL 0 + BLOCKED 9 + UNRESOLVED 12 + NOT TESTED 55 = 78 ✓.
- BLOCKED rows in the matrix: 10 = 9 register BLOCKED plus R-019 (UNRESOLVED, owner-blocked) ✓.
- Boundary vectors: 12 (BVT-01 to BVT-12) ✓.
- Timeframe accounting: 11 + 1 + 2 = 14 ✓.
- Self-review rows: 15. PASS 10 + AMENDED 2 + RESIDUAL 3 = 15 ✓.
- Propagation rows: 26. APPLIED 24 + CARRIED 2 = 26 ✓.
- Gap rows: 12 (GAP-P5-01 to GAP-P5-12) ✓.
- Parameter register: 53 rows (PRM-01 to PRM-53), unique and contiguous. Status counts: ILLUSTRATIVE 1 + OWNER_DECISION_PENDING 3 + UNRESOLVED 5 + SCENARIO 4 + PROVISIONAL 9 + DERIVED 7 + RATIFIED_FINDING 1 + DESIGN_JUDGMENT 23 = 53 ✓.
- Decision records: DR-20 to DR-28 = 9 ✓.
- Conflict records: CR-27 to CR-30 = 4 ✓.
- Protocol clauses: SP-1 to SP-12 = 12 ✓.
- Experiments: EXP-01 to EXP-13 = 13 ✓.
- Identifier namespaces within Part 5 (PRM, DR, CR, SP, BVT, SR, PL-P5, GAP-P5) contain no duplicates (R-076, Part 5 scope).

**Verification status.**
- Verified by execution: none. No experiment, fixture or source check was executed in this engagement.
- Verified by hand arithmetic in this design: Table 5.2, §5.3.2 budget values, §5.3.3 implied intervals, §5.6.1 calendar values, and the matrix counts above.
- Pending: EXP-01, EXP-02, EXP-03, EXP-04, EXP-05, EXP-06, EXP-07, EXP-08, EXP-09, EXP-10, EXP-11, EXP-12, EXP-13; SOURCE_CHECK items GAP-P5-05 and GAP-P5-06; fixture for BVT-01 to BVT-12.

**Part 5 status.** Complete as design. Verification pending as listed above. No Part 5 item is PASS. No Part 5 item promotes any register status.

**Carried to Part 6.**
- Completeness declaration (§2.2.5) with arithmetic.
- V-1 to V-12, individually enumerated. V-1 to V-7 are the Part 1 scope; V-8 to V-12 are defined in Part 6.
- Final artifact registry and the ART-11 collision check (GAP-P5-07).
- Identifier catalogs, with no duplicates (R-076).
- Priority audit.
- OD-06 raised at the next natural phase transition (automated exits are the default; confirmation gate optional).
- Residual risks R-RISK-1 and R-RISK-2 for owner information (GAP-P4-11), and candidate R-RISK-3 from GAP-P5-09.
- Correction of the PL-P4 count (PL-P5-14, GAP-P5-08).
- Executed forbidden-phrase scan across all six parts (R-074).
- Final summary in Persian.


این پیام بخش ۶ از ۶ و پایان مجموعه شش‌بخشی است. هیچ آزمایشی اجرا نشده، هیچ منبع خارجی بازیابی نشده و هیچ الزامی به PASS نرسیده است. در این بخش دو اصلاح از بخش‌های قبلی ثبت می‌شود: شمارش سجل انتشار PL-P4 و هم‌پوشانی برخی شناسه‌ها. موارد ناقص که متن عملیاتی آن‌ها در سجل این گفتار نیست، به‌صورت شکاف ثبت شده‌اند و بازنویسی نشده‌اند.

---

# بخش ۶ از ۶: کامل‌بودن، کاتالوگ‌ها، سجل نهایی و جمع‌بندی
## Part 6/6: Completeness, Catalogs, Final Registry and Closing Summary

---

## §6.0 Scope, conventions and limits

**Scope.** This part delivers:
- corrections to earlier parts (§6.1);
- the verification catalog V-1 to V-12 (§6.2);
- the final artifact registry and the ART collision check (§6.3);
- identifier catalogs and the duplicate check under R-076 (§6.4);
- the propagation log PL-P6 and gap register GAP-P6 (§6.5);
- the experiment and decision maps (§6.6 and §6.7);
- residual risks and owner-information items (§6.8);
- the priority audit (§6.9);
- the forbidden-phrase and label scan (§6.10);
- the completeness declaration with arithmetic (§6.11);
- the final status statement (§6.12);
- the closing summary, in Persian (§6.13).

**Limits.**
- No tool was run in this engagement. Every scan and check in this part is a manual inspection of the text and its arithmetic. Each is labelled NOT_EXECUTED where an executed run is required.
- Where the operative text of an earlier item is not reproduced in the session record, this part refers to the item by identifier and does not restate its wording. Such items are logged in GAP-P6.
- No register row changes status in this part.

**Labels used in this part.** Labels from Parts 1 to 5, plus CORRECTED (CORR-P6), ALIASED (ID-COL), TRANSFERRED (residual moved to a Part 6 item), CLOSED_IN_PART_6, NOT_EXECUTED and NOT_RECOVERABLE.

---

## §6.1 Corrections applied in Part 6

### CORR-P6-01: PL-P4 row count

- **Earlier statement.** Part 4 §4.14.5 states "PL-P4 rows: 27". The breakdown in the working record also gives "R-010 to R-039 is 28 rows".
- **Finding.** The PL-P4 listing in §4.14.4 contains 32 entries. The statement of 27 is wrong. The breakdown is also wrong: the identifier range R-010 to R-039 contains 30 identifiers, not 28. The count is therefore taken from the listing, not from the breakdown.
- **Omitted rows.** R-012 and R-016 are affected by §4.5.1 and F3 but are not in the listing (CORR-P6-02).
- **Corrected required count.** 32 listed + 2 omitted = **34**.
- **Residual.** A recount against the Part 4 log is required because the log is not reproduced in this record (GAP-P6-03).
- **Status.** CORRECTED. Closes PL-P5-14 and GAP-P5-08.

### CORR-P6-02: Omitted PL-P4 rows

R-012 (persisted, versioned risk-state records; §4.5.1) and R-016 (monetary terms; §4.5.1 and F3) are added to PL-P4. Status: APPLIED. This is the same correction recorded in PL-P5-12 and PL-P5-13.

### CORR-P6-03: Identifier token collisions

Three token collisions were found in the record. Each is resolved by an alias in §6.4.
- **ID-COL-01.** P1, P2, P3 denote persistence options (Part 3 §3.9) and also execution phases (Part 3 §3.5). Persistence options are aliased PERS-P1 to PERS-P3.
- **ID-COL-02.** C-1, C-2 and C-3 denote Part 1 cycle breaks and also Part 5 conventions (C-1 to C-4). Cycle breaks are aliased CYC-1 to CYC-3. Conventions keep C-1 to C-4.
- **ID-COL-03.** A-1 is the Part 4 adopted proposal (now R-078). The brief's scope elements are A1 to A13. These are distinct tokens but a near-collision. The proposal is aliased PROP-A-1.

Status: APPLIED through the catalog aliases.

### CORR-P6-04: Token variance

- IP-7 writes "IP_PASS journaled", while the audit catalog uses AUD-IP-PASS. Both refer to the same event. The canonical audit name is AUD-IP-PASS, and IP_PASS is an alias.
- Channel states are written CH_UP, CH_DEGRADED, CH_DOWN and CH_UNKNOWN (underscore), while channel identifiers use a hyphen (CH-EX, CH-WS, CH-TG, CH-CLK). The underscore form is the state name and is not a duplicate.

Status: APPLIED.

### CORR-P6-05: Closure of earlier carried items

- PL-P5-14 and GAP-P5-08 are CLOSED_IN_PART_6 by CORR-P6-01.
- PL-P5-26 and GAP-P5-09 are TRANSFERRED to R-RISK-3 (§6.8).

---

## §6.2 Verification catalog V-1 to V-12

### §6.2.1 Summary table

| ID | Subject | Defined in | Executed in this engagement | Status |
|---|---|---|---|---|
| V-1 | Part 1 verification item 1 | Part 1 verification list | No | NOT_EVALUATED (GAP-P6-01) |
| V-2 | Part 1 verification item 2 | Part 1 verification list | No | NOT_EVALUATED (GAP-P6-01) |
| V-3 | Part 1 verification item 3 | Part 1 verification list | No | NOT_EVALUATED (GAP-P6-01) |
| V-4 | Part 1 verification item 4 | Part 1 verification list | No | NOT_EVALUATED (GAP-P6-01) |
| V-5 | Part 1 verification item 5 | Part 1 verification list | No | NOT_EVALUATED (GAP-P6-01) |
| V-6 | Part 1 verification item 6 | Part 1 verification list | No | NOT_EVALUATED (GAP-P6-01) |
| V-7 | Part 1 verification item 7 | Part 1 verification list | No | NOT_EVALUATED (GAP-P6-01) |
| V-8 | UTC calendar and boundary fixture | Part 5 §5.6.1 (BVT-01 to BVT-12) | No | NOT_EXECUTED (GAP-P6-07) |
| V-9 | Register structure and status separation | Part 2; §6.11 arithmetic | Arithmetic by hand only | NOT_EXECUTED (schema check) |
| V-10 | Experiment evidence gate | §6.6 | No experiment run (0 of 13) | NOT_EXECUTED |
| V-11 | Source-check verification | §6.2.5 (13 items) | No retrieval performed | NOT_EXECUTED (0 of 13) |
| V-12 | Language, label and forbidden-phrase scan | Part 6 §6.10 and all parts | Manual reading only | NOT_EXECUTED (executed scan) |

### §6.2.2 V-1 to V-7: why no wording is restated

V-1 to V-7 are the Part 1 verification scope. The session record retains their identifiers and their membership in Part 1 scope, but not their operative wording. Restating them from memory would risk changing their meaning. Each is therefore enumerated by identifier and referred to Part 1. The owner or Part 1 text governs their content. Closing this gap requires the Part 1 V-list text (GAP-P6-01).

### §6.2.3 V-8: UTC calendar and boundary fixture

- **Scope.** R-007, R-008, R-011 (time roles).
- **Method.** A deterministic fixture evaluates utc_day_key and iso_week for BVT-01 to BVT-12, using the expected values in Part 5 §5.6.1.
- **Acceptance.** 12 of 12 vectors match. Any mismatch is a FAIL for R-008 and blocks every protocol run.
- **Evidence required.** Fixture output with build identifier, UTC run stamp and library version (EXP-07 for runtime libraries).
- **Status.** NOT_EXECUTED. The expected values were checked by hand (§6.11).

### §6.2.4 V-9: Register structure and status separation

- **Scope.** R-001 to R-078; R-075 and R-076 checks.
- **Method.** Schema check on the register file (ART-08): 11 fields per row; no status-only row; status values in the allowed set (PASS, FAIL, BLOCKED, UNRESOLVED, NOT TESTED); priority in {HARD, SHOULD, MAY}; evidence labels from the Part 1 to Part 5 vocabulary.
- **Acceptance.** 78 rows; 11 fields each; zero status-only rows; counts equal §6.11.
- **Status.** Counts verified by hand. Schema check NOT_EXECUTED.

### §6.2.5 V-11: Source-check inventory

The following 13 SOURCE_CHECK items are identified in the record. The list may not be exhaustive (GAP-P6-08).

| # | Item | Source of item | Rows affected |
|---|---|---|---|
| 1 | Venue conditional-order support | GAP-P4-01 | R-034, DR-12 |
| 2 | Public server-time endpoint and format | GAP-P4-03 | R-010, §4.11 |
| 3 | Per-endpoint weight estimates | GAP-P4-06, PRM-53 | R-024 |
| 4 | Whether −1003 non-execution can be confirmed | GAP-P4-07 | R-021, TX-06 |
| 5 | Duplicate clientOrderId semantics | GAP-P4-08 | TX-07, §4.6 |
| 6 | Documented rejection-code list | GAP-P4-09 | TX-05 |
| 7 | clientOrderId maximum length | GAP-P4-10 | R-025 |
| 8 | MinBTL approximation and DSR formula | GAP-P5-05 | R-062, R-065 |
| 9 | SQLite backup interface | PC-06 | Backup procedure |
| 10 | Python version | LIB-01 | LIB rows |
| 11 | Cooldown behaviour after −1003 | PRM-37 | R-022 |
| 12 | SR₀ formula version (DSR) | SP-6 | R-062 |
| 13 | Venue closed flag as evidence (not sole) | BV-5 | R-029 |

Status: 0 of 13 executed. No retrieval was performed in this engagement.

### §6.2.6 V-10: Experiment evidence gate

- **Scope.** EXP-01 to EXP-13, mapped in §6.6.
- **Method.** Each experiment produces a dated record with its inputs, device or build identifiers (C14 strings where applicable), and the outcome against the acceptance text in §3.10 or §5.5.2.
- **Rule.** A row moves from NOT TESTED or UNRESOLVED to PASS only when its experiment record meets the acceptance text. A FAIL record moves the row to FAIL.
- **Status.** 0 of 13 experiments executed.

### §6.2.7 V-12: Language, label and forbidden-phrase scan

- **Scope.** R-073, R-074, R-077 across all six parts.
- **Method.** Executed scan for the forbidden phrases in the brief, label-presence check on every material claim, and header-language check (Persian and English).
- **Status.** Manual reading only, applied to Part 6 (§6.10). Executed scan across all six parts NOT_EXECUTED.

---

## §6.3 Final artifact registry and ART collision check

| Registry ID | Artifact | Delivered in | Status |
|---|---|---|---|
| ART-01 to ART-07 | Artifacts in the Part 1 block | Part 1 | NOT_RECOVERABLE (individual assignments not in the record) |
| ART-08 | Requirements register R-001 to R-078 | Part 2 | DELIVERED |
| ART-09 | Analytic record (workload, topologies, phases, universe, liquidity, risk functions, options, experiments) | Part 3 | DELIVERED |
| ART-10 | Design synthesis (§4.0 to §4.14) | Part 4, two messages | DELIVERED (CORR-P4-02) |
| ART-11 | Statistics, trial budget, parameter register, verification matrix, self-review, logs (§5.0 to §5.9) | Part 5, two messages | DELIVERED |
| ART-12 | Member of the Part 1 block | Part 1 | NOT_RECOVERABLE |
| ART-13 | Completeness, catalogs, residuals, final summary | Part 6 | DELIVERED |

### §6.3.1 Collision check result

- ART-01 to ART-12 are all recorded as assigned in Part 1.
- ART-08 to ART-11 were then assigned in Parts 2 to 5. Those numbers lie inside the Part 1 block. Their Part 1 assignments are not recoverable, so the collision check for ART-08 to ART-11 is **NOT_EVALUABLE** (GAP-P6-02).
- Part 6 is assigned ART-13. This identifier is outside the Part 1 block and cannot collide with any Part 1 assignment in the record.

### §6.3.2 Canonical rule for the registry

The **Part number is the primary key**. The ART identifier is a secondary reference. No ART identifier is reassigned in Part 6. Any cross-reference in the parts must use the Part number first.

---

## §6.4 Identifier catalogs and duplicate check (R-076)

### §6.4.1 Catalog counts

| Namespace | Range | Count | Unique and contiguous | Origin |
|---|---|---|---|---|
| R | R-001 to R-078 | 78 | Yes | Part 2 |
| R-RISK | R-RISK-1 to R-RISK-3 | 3 | Yes | Parts 4 to 6 |
| C (ratified) | C1 to C26 | 26 | Yes | Part 1 input |
| CR | CR-01 to CR-30 | 30 | Yes | Parts 2, 3, 5 |
| PD | PD-01 to PD-12 | 12 | Yes | Part 1 |
| OD | OD-01 to OD-14 | 14 | Yes | Parts 1 to 3 |
| EXP | EXP-01 to EXP-13 | 13 | Yes | Parts 3, 5 |
| CMP | CMP-01 to CMP-17 | 17 | Yes | Part 4 |
| PC | PC-01 to PC-16 | 16 | Yes | Part 4 |
| RA | RA-1 to RA-7 | 7 | Yes | Part 4 |
| VC | VC-1 to VC-4 | 4 | Yes | Part 4 |
| HOLD origins | H1 to H5 | 5 | Yes | Part 4 |
| GT | GT-01 to GT-09 | 9 | Yes | Part 4 |
| RST | RST-1 to RST-8 | 8 | Yes | Part 4 |
| IP | IP-1 to IP-8 | 8 | Yes | Part 4 |
| TX | TX-01, TX-02, TX-02R, TX-03 to TX-11 | 12 | Yes | Part 4 |
| OS | OS-INTENT to OS-EXPIRED | 12 | Yes | Part 4 |
| POS | POS-FLAT to POS-UNKNOWN | 5 | Yes | Part 4 |
| CMD | CMD-01 to CMD-07 | 7 | Yes | Part 4 |
| AUD | AUD-UNAUTHORIZED to AUD-IP-FAIL | 16 | Yes | Part 4 |
| CH | CH-EX, CH-WS, CH-TG, CH-CLK | 4 | Yes | Part 4 |
| CH states | CH_UP, CH_DEGRADED, CH_DOWN, CH_UNKNOWN | 4 | Yes | Part 4 |
| CL | CL-OK, CL-STALE, CL-UNKNOWN, CL-EXCESSIVE | 4 | Yes | Part 4 |
| OC | OC-1 to OC-3 | 3 | Yes | Part 4 |
| RC | RC-1 to RC-6 | 6 | Yes | Part 4 |
| BV | BV-1 to BV-8 | 8 | Yes | Part 4 |
| BVT | BVT-01 to BVT-12 | 12 | Yes | Part 5 |
| LIB | LIB-01 to LIB-11 | 11 | Yes | Part 4 |
| DR | DR-01 to DR-28 | 28 | Yes | Parts 4, 5 |
| GAP-P4 | GAP-P4-01 to GAP-P4-11 | 11 | Yes | Part 4 |
| GAP-P5 | GAP-P5-01 to GAP-P5-12 | 12 | Yes | Part 5 |
| GAP-P6 | GAP-P6-01 to GAP-P6-08 | 8 | Yes | Part 6 |
| CORR-P4 | CORR-P4-01 to CORR-P4-04 | 4 | Yes | Part 4 |
| CORR-P6 | CORR-P6-01 to CORR-P6-05 | 5 | Yes | Part 6 |
| PL-P4 | Corrected required set | 34 | See CORR-P6-01 | Part 4 |
| PL-P5 | PL-P5-01 to PL-P5-26 | 26 | Yes | Part 5 |
| PL-P6 | PL-P6-01 to PL-P6-08 | 8 | Yes | Part 6 |
| SR | SR-1 to SR-15 | 15 | Yes | Part 5 |
| SP | SP-1 to SP-12 | 12 | Yes | Part 5 |
| PRM | PRM-01 to PRM-53 | 53 | Yes | Part 5 |
| V | V-1 to V-12 | 12 | Yes | Parts 1, 6 |
| ART | ART-01 to ART-13 | 13 | Partly NOT_RECOVERABLE | Parts 1 to 6 |
| PERS (alias) | PERS-P1 to PERS-P3 | 3 | Yes | ID-COL-01 |
| CYC (alias) | CYC-1 to CYC-3 | 3 | Yes | ID-COL-02 |
| PROP (alias) | PROP-A-1 | 1 | Yes | ID-COL-03 |

### §6.4.2 Collision findings

| ID | Tokens | Nature | Resolution | Post-resolution status |
|---|---|---|---|---|
| ID-COL-01 | P1, P2, P3 | Persistence options and phases share tokens | Aliases PERS-P1 to PERS-P3; phases keep P1 to P3 | Resolved |
| ID-COL-02 | C-1, C-2, C-3 | Part 1 cycle breaks and Part 5 conventions share tokens | Aliases CYC-1 to CYC-3; conventions keep C-1 to C-4 | Resolved |
| ID-COL-03 | A-1 and A1 | Near-collision (proposal versus brief scope) | Alias PROP-A-1; brief keeps A1 to A13 | Resolved |

**Non-duplicate near-forms, recorded for clarity.**
- K1 to K7 (evaluation criteria) and the K register group (R-070 to R-077) share a letter but differ in form.
- F1 to F10 (risk functions) and the F register group (R-038 to R-040) share a letter.
- VC-1 to VC-4 (veto classes) and V-1 to V-12 (verification items) use different prefixes.
- BV-1 to BV-8 (bar validity) and BVT-01 to BVT-12 (boundary vectors) use different prefixes.
- G-1 (Part 3 gap) and GAP-P4 / GAP-P5 / GAP-P6 use different prefixes. G-1 is retained as written.
- S1 to S5 (strategy classes), W1 to W4 (workloads), T1 to T9 (topologies), O1 to O3 (Telegram options) and L1 to L3 (languages) are unique within their families.

### §6.4.3 Declared prefixes with no enumerated items in this record

The Part 4 prefix list includes TR, SU, IL, B and TM. No items under these prefixes are enumerated in the session record. They are recorded as declared and not enumerated (GAP-P6-04). No duplicate is asserted for them.

### §6.4.4 Duplicate result

- Duplicates in the strict sense, after the aliases in §6.4.2 are applied: **0**.
- Token collisions resolved by alias: **3** (ID-COL-01 to ID-COL-03).
- Declared prefixes not enumerated: **5** (TR, SU, IL, B, TM).
- ART identifiers whose collision check is NOT_EVALUABLE: **4** (ART-08 to ART-11), plus the NOT_RECOVERABLE identifiers ART-01 to ART-07 and ART-12.

---

## §6.5 Propagation log PL-P6 and gap register GAP-P6

### §6.5.1 Propagation log PL-P6

| ID | Source | Propagated to | Action | Status |
|---|---|---|---|---|
| PL-P6-01 | CORR-P6-01 (PL-P4 count 27 corrected to 34) | Part 4 §4.14.5; PL-P5-14; GAP-P5-08 | Count corrected | APPLIED |
| PL-P6-02 | CORR-P6-02 (R-012 and R-016 added) | Part 4 §4.5.1; PL-P5-12; PL-P5-13 | Rows added to PL-P4 | APPLIED |
| PL-P6-03 | CORR-P6-03 (aliases) | Parts 1, 3, 4, 5 cross-references | Catalog alias rule | APPLIED |
| PL-P6-04 | R-RISK-1 and R-RISK-2 | Part 4 §4.9 rows 8 and 11; GAP-P4-11 | Information items | APPLIED (for owner information) |
| PL-P6-05 | R-RISK-3 (from GAP-P5-09) | Part 5 §5.3.5; SR-12; PL-P5-26 | Information item | APPLIED (for owner information) |
| PL-P6-06 | OD-06 raised | Part 4 §4.8 CMD-06; DR-11; §4.14.2 | Default retained; non-blocking | APPLIED |
| PL-P6-07 | V-8 to V-12 | R-007, R-008, R-073, R-074, R-075, R-076 | Verification rules | APPLIED |
| PL-P6-08 | Source-check inventory (§6.2.5) | GAP-P4-01, 03, 06 to 10; GAP-P5-05; PC-06; LIB-01; PRM-37; SP-6; BV-5 | Single inventory | APPLIED |

**Count.** 8 entries. APPLIED 8.

### §6.5.2 Gap register GAP-P6

| ID | Gap | Affected rows and items | Resolution route | Status |
|---|---|---|---|---|
| GAP-P6-01 | Operative wording of V-1 to V-7 not in the session record | V-1 to V-7; R-074 | Owner or Part 1 text restored | OPEN |
| GAP-P6-02 | Part 1 assignments for ART-01 to ART-12 not recoverable; collision check for ART-08 to ART-11 NOT_EVALUABLE | R-076 | Part number as primary key (§6.3.2); owner check against Part 1 | OPEN |
| GAP-P6-03 | PL-P4 listing not reproduced in this record; corrected count 34 not re-counted | Part 4 §4.14.4 and §4.14.5 | Recount against the Part 4 log | OPEN |
| GAP-P6-04 | Prefixes TR, SU, IL, B and TM declared but not enumerated | R-076 | Enumerate or retire the prefixes | OPEN |
| GAP-P6-05 | Priority audit limited to counts and short-form statements | R-073; §6.9 | Full-text audit against ART-08 | OPEN |
| GAP-P6-06 | Forbidden-phrase and label scan not executed | R-074; V-12 | Executed scan across all parts | OPEN |
| GAP-P6-07 | Boundary fixture (V-8) not executed | R-007, R-008 | Fixture run; EXP-07 for runtime libraries | OPEN |
| GAP-P6-08 | SOURCE_CHECK inventory of 13 items may be incomplete | V-11 | Full inventory during the source-check batch | OPEN |

**Count.** 8 entries, all OPEN. No closure in this part.

---

## §6.6 Experiment and decision map

| Experiment | Rows and items resolved or constrained | Owner decisions affected | Protocol or design effect |
|---|---|---|---|
| EXP-01 | R-052, R-055, R-050; PRM-50 | OD-12 | Decides whether the phone can host Live (T1) |
| EXP-02 | R-053, R-055 | OD-12 | Background operation under restricted standby |
| EXP-03 | R-010, R-009 (runtime deadlines); PRM-20, PRM-21, PRM-23; DR-19, DR-28 | None | Sets τ_OK and u_clk; clock verdicts |
| EXP-04 | R-063, R-045; PRM-15 | None | Confirms the Step 3 timeframe set |
| EXP-05 | R-042; PRM-10, PRM-11, PRM-12; CR-22 | None | Replaces the β scenario with a distribution |
| EXP-06 | R-047; PRM-49; CR-25 | None | Storage ratio for the 134-symbol shape |
| EXP-07 | R-054, R-008 (runtime); GAP-P4-02 | None | Library and runtime verification |
| EXP-08 | R-078; Part 3 Step 6; PRM-18; GT-09 | None | Venue filter inputs |
| EXP-09 | R-018; PRM-09; GAP-P5-11; class S5 | None | Funding interval I_f for S5 |
| EXP-10 | R-017; PRM-05; GT-07 | OD-07 | Leverage tier table |
| EXP-11 | R-043; Part 3 Step 5; OD-14 | OD-14 | Liquidity snapshot distribution |
| EXP-12 | R-028; PRM-07 | OD-08 | Fee confirmation (account-specific check would need authorization outside this engagement) |
| EXP-13 | R-041, R-046; DR-27; GAP-P5-01; Table 5.2; SR-14 | None | Historical depth for protocol runs |

### §6.6.1 Mapping check for NOT_EVALUABLE rows

Part 5 §5.6 lists 12 NOT_EVALUABLE rows. Each maps to an experiment or source check:

| Row | Dependency |
|---|---|
| R-010 | EXP-03 |
| R-018 | EXP-09 |
| R-023 | SOURCE_CHECK (items 4, 5, 11) |
| R-024 | SOURCE_CHECK (item 3) |
| R-043 | EXP-11 |
| R-047 | EXP-06 |
| R-052 | EXP-01 |
| R-053 | EXP-02 |
| R-054 | EXP-07 |
| R-055 | EXP-01 and EXP-02 |
| R-063 | EXP-04 |
| R-078 | EXP-08 |

Result: 12 of 12 mapped.

### §6.6.2 Recommended execution order (dependency-first, D11)

1. **EXP-07.** The environment and library record is a prerequisite for every runtime measurement.
2. **EXP-13.** Historical depth is a prerequisite for any protocol run (DR-27).
3. **Source-check batch (V-11, 13 items).** Required before TX-05, TX-06, TX-07, SP-6 and PC-06 are implemented.
4. **EXP-03.** Clock tolerance sets the values used by VC-2 and GT-03.
5. **EXP-08 and EXP-10.** Venue filters and leverage tiers are prerequisites for GT-07 and GT-09.
6. **EXP-09.** The funding interval is a prerequisite for class S5 and for the F5 stress.
7. **EXP-04.** The cost-per-volatility test confirms the universe frontier.
8. **EXP-05, EXP-06, EXP-11, EXP-12.** Liquidity, storage, snapshot and fee confirmations.
9. **EXP-02, then EXP-01.** Device background and sustained tests, after the environment is verified.

None of these experiments requires access to the owner's account. EXP-12 may require an account-specific check, which lies outside this engagement.

---

## §6.7 Owner decision closure map and OD-06 raise

| OD | Subject | Status at Part 6 | Blocks | Design default or treatment |
|---|---|---|---|---|
| OD-01 | Maximum drawdown D | OWNER_DECISION_PENDING | Live (R-013, R-015, R-019, R-069) | None. Scenario grid 2% to 12% is not a default |
| OD-02 | Per-trade risk r | OWNER_DECISION_PENDING | Live (R-015, R-019, R-041, R-069) | None. Scenario grid 0.25% to 3% is not a default |
| OD-03 | Risk appetite and utility | OWNER_DECISION_PENDING | Selection only (R-069, R-072) | Utility is not inferred |
| OD-04 | Cross-venue legal conditions | OWNER_DECISION_PENDING (owner or counsel) | Any use beyond research (R-004, R-064) | Cross-venue excluded from Paper and Live (C18, CR-26) |
| OD-05 | Outage classes and Class-A definition | Default proposed (DESIGN_JUDGMENT); ratification pending | Non-blocking (R-027) | OC-3 mapped to Class-A (GAP-P4-04) |
| OD-06 | Exit confirmation style | Default in force; raised here (non-blocking) | None | Automated exits; FLATTEN_CONFIRM default OFF |
| OD-07 | Leverage cap and tier | OWNER_DECISION_PENDING (owner-set cap) | Live (R-017) | Orders refused without verified tier (EXP-10) |
| OD-08 | Taker fee | Used at 0.06%; confirmation EXP-12 | None | 0.05% reported as sensitivity |
| OD-09 | Historical open interest | Excluded | None | Features using it excluded (R-049) |
| OD-10 | markPrice reliability | Unresolved; no dependency | None | Close of mark-free candles (R-048) |
| OD-11 | Order-book depth | Not used as capacity fact | None | Capacity bounded by 24h notional (R-044) |
| OD-12 | Device capacity | PROVISIONAL until EXP-01 | Phone-hosted Live (R-052, R-055) | Target placement is T3 |
| OD-13 | Remote host cost | OWNER_DECISION_PENDING | Live host choice (R-056) | Phone-hosted Live only after EXP-01 and EXP-02 |
| OD-14 | Universe snapshot refresh | Pending EXP-11 | R-043 | Snapshot treated as dated and refreshed before use |

### §6.7.1 Status totals

- OWNER_DECISION_PENDING: 6 (OD-01, OD-02, OD-03, OD-04, OD-07, OD-13).
- Default applied, awaiting ratification: 2 (OD-05, OD-06).
- Resolved by design rule, no owner action required: 4 (OD-08, OD-09, OD-10, OD-11).
- Evidence-pending: 2 (OD-12, OD-14).
- Total: 6 + 2 + 4 + 2 = 14.

### §6.7.2 OD-06 raise

This is the natural transition point for the design: the design is complete and implementation has not started. The question is raised once, for the owner, and it is not blocking.

- **Question.** Should an operator flatten command ask for confirmation?
- **Current design.** Automated exits are the default. /flatten needs no confirmation (DR-11). FLATTEN_CONFIRM is OFF by default and can be enabled by the owner.
- **Blocking test (§2.1.7 condition 4).** Not met. The design proceeds without an answer.
- **Owner action.** Optional. Silence keeps the default.

### §6.7.3 Pending owner input for the Live path

Live cannot be selected until the following are supplied by the owner, or the relevant gate remains closed: OD-01, OD-02, the aggregate exposure fraction c_agg (PRM-04, owner-set under OD-01 and OD-02), OD-07, and the Part 4 interlock inputs. OD-13 is required only for the target placement T3. OD-04 is required only for any cross-venue use beyond research.

---

## §6.8 Residual risks and owner-information items

These items are design-accepted residuals or information items. They are listed so that the owner can see them. They are not gates in the design unless the owner chooses to make them gates.

### R-RISK-1: Outage with open positions

- **Source.** Part 4 §4.9 row 8; GAP-P4-11.
- **Description.** While the exchange connection is down (VC-2), no exit can be sent. Gap risk accrues on open positions until the connection returns.
- **Design mitigations.** Reconnect backoff (RC-1); exit and flatten requests before entries on reconnect (RC-3); reconciliation before risk-increasing orders (RC-4); exposure caps (GT-06, F7, F8); stop-rule and time-stop evaluation on reconnect.
- **Residual.** A design alone cannot remove this residual. Removal requires venue-side protective mechanisms (GAP-P4-01). Status: RESIDUAL, information.

### R-RISK-2: Orphaned position after restart budget exhaustion

- **Source.** Part 4 §4.9 row 11; GAP-P4-11; DR-18.
- **Description.** If the Runtime crashes repeatedly, the Supervisor allows at most three restarts within 60 minutes (PRM-38). After that it stays STOPPED. Positions then have no stop-rule evaluation until the operator issues /start or a console action is taken.
- **Design mitigations.** CRIT alert; H5 set (DR-09); Supervisor remains reachable for /status and /start; positions are reported in every envelope.
- **Residual.** Remains until venue-side conditional protection is confirmed (GAP-P4-01 and DR-12). If SOURCE_CHECK confirms support, DR-12 is revisited. Status: RESIDUAL, information. Acceptance by the owner is a choice the owner may record. The design does not gate Live on it automatically.

### R-RISK-3: Performance-based search budget at the planning scale

- **Source.** Part 5 §5.3.5 and §5.3.6; SR-12; GAP-P5-09.
- **Description.** At E_T = 1.0, the performance-based configuration budget is 1 for 1m to 4h, 2 for 6h, 3 for 8h and 6 for 12h. The 1d context budget is 6 at the measured 1,774-bar depth or 36 at full span before correction. This limits how many performance-based configurations can be compared. It does not reject any strategy.
- **Design mitigations.** A single pre-registered configuration remains admissible. Architecture, method and language are not budgeted (A12). A higher E_T is available only through a new protocol version after EXP-13 (DR-21).
- **Residual.** A critic can argue that the scale hides some candidates. Status: RESIDUAL, information.

### Items carried from Part 5 (no new identifier)

- **SR-13.** Pooling can hide symbol-level weakness. Mitigation: SP-12 tests the pooled portfolio series; per-symbol statistics are descriptive. Status: RESIDUAL, disclosed.
- **SR-14 and GAP-P5-01.** Holdout feasibility at 2h and shorter depends on measured depth. Status: RESIDUAL until EXP-13.

---

## §6.9 Priority audit

### §6.9.1 Counts

| Priority | Count | Share |
|---|---|---|
| HARD | 77 | 98.7% |
| SHOULD | 1 (R-054) | 1.3% |
| MAY | 0 | 0% |
| Total | 78 | 100% |

Arithmetic: 77 + 1 + 0 = 78.

### §6.9.2 Audit findings

| ID | Test | Finding | Result |
|---|---|---|---|
| PA-1 | Count consistency | 77 + 1 + 0 = 78 | PASS |
| PA-2 | SHOULD rows are recommendations, not binding constraints | R-054 is the build-record requirement. Its acceptance does not depend on mandatory status, and its evidence depends on EXP-07. SHOULD is correct | RETAINED |
| PA-3 | MAY rows used for optional alternatives | No MAY rows. Optional alternatives (OD-06 confirmation gate, the T6 relay, the O3 relay) are options, not register rows | No change |
| PA-4 | HARD rows with a DESIGN_JUDGMENT basis | R-078 (A-1 adoption). HARD is the binding form of a derived constraint: an order sized above the risk cap is a risk violation (F10, GT-09). The basis is recorded in CORR-P4-03 and §4.2 | RETAINED, flagged for owner visibility |
| PA-5 | Numerical defaults promoted to HARD | None. PRM values carry labels and are not register rows | PASS |
| PA-6 | Owner preferences promoted to HARD | None. OD-06 default and FLATTEN_CONFIRM are not HARD | PASS |
| PA-7 | Priority and status separated | HARD rows with NOT TESTED status are correct; priority is not status | PASS |
| PA-8 | Hard-requirement rule (no HARD from examples or brainstorm) | R-006 enforces this rule. No example-derived row is HARD in the short forms | PASS (short forms) |

**Scope limit.** The full-text audit of 78 statements needs the Part 2 register text (ART-08). This part audits counts and short-form statements only (GAP-P6-05).

**Result.** 0 reclassifications. 8 tests, 7 PASS or RETAINED, 1 flagged for owner visibility.

---

## §6.10 Forbidden-phrase and label scan (manual, not executed)

**Phrases checked.** "for brevity", "in summary", "to be detailed later", "TBD", "placeholder" without a plan, "draft" as a final deliverable, "at a high level" as a substitute for detail. Also "in short" and "etc." used as a substitute for content.

**Method.** Manual reading of the text of Part 6. No executed scan was run.

**Result of manual reading.** No forbidden phrase is used as a substitute for content in Part 6. The word "summary" appears only in the section title §6.13, which is a required closing summary, not a disguised abbreviation.

**Label check.** Each material claim in Part 6 carries a label, a status or a reference to an identifier. Claims about verification are labelled NOT_EXECUTED.

**Status.** Manual only. Executed scan across all six parts: GAP-P6-06, NOT_EXECUTED.

---

## §6.11 Completeness declaration (§2.2.5)

### §6.11.1 Sections present

- Part 1: delivery and boundary framework; PD-01 to PD-12; C1 to C26 used as RATIFIED_FINDING; comparison criteria and cycle breaks.
- Part 2: register R-001 to R-078 with 11 fields per row; CR-01 to CR-21; OD-01 to OD-14; classification of C1 to C26.
- Part 3: analytic record; topologies T1 to T9; phases; universe Steps 1 to 9; liquidity chain Elements 1 to 5; risk functions F1 to F10; options; experiments EXP-01 to EXP-12; CR-22 to CR-26; G-1.
- Part 4: §4.0 to §4.14; corrections CORR-P4-01 to CORR-P4-04; A-1 adopted as R-078; decision records DR-01 to DR-19; GAP-P4-01 to GAP-P4-11; PL-P4; completeness declaration.
- Part 5: §5.0 to §5.9; DR-20 to DR-28; EXP-13; CR-27 to CR-30; BVT-01 to BVT-12; SR-1 to SR-15; PL-P5-01 to PL-P5-26; GAP-P5-01 to GAP-P5-12; PRM-01 to PRM-53; SP-1 to SP-12.
- Part 6: this part, §6.0 to §6.13.

### §6.11.2 Arithmetic

**Register.**
- Rows: 78.
- Group counts: A 6 + B 5 + C 8 + D 13 + E 6 + F 3 + G 9 + H 7 + I 9 + J 4 + K 8 = 78.
- Status: PASS 2 + FAIL 0 + BLOCKED 9 + UNRESOLVED 12 + NOT TESTED 55 = 78.
- Priority: HARD 77 + SHOULD 1 + MAY 0 = 78.

**Verification matrix (§5.6).**
- Rows: 78. Equal to register rows: 78 = 78 (R-075).
- Dispositions: RETAINED 22 + SPECIFIED 27 + ARITHMETIC_CHECKED 7 + NOT_EVALUABLE 12 + BLOCKED 10 = 78.
- NOT_EVALUABLE rows each mapped (§6.6.1): 12 of 12.
- BLOCKED rows: 10 = 9 register BLOCKED + R-019.

**Boundary vectors.** BVT-01 to BVT-12 = 12.

**Timeframe accounting.** 11 table rows + 1 eliminated (5m) + 2 context-only not in table (1w, 1M) = 14.

**Self-review (§5.7).** PASS 10 + AMENDED 2 + RESIDUAL 3 = 15.

**Propagation logs.**
- PL-P5: 26 entries = APPLIED 24 + CLOSED_IN_PART_6 2 (PL-P5-14, PL-P5-26 transferred to R-RISK-3 and closed). Sum 26.
- PL-P4: corrected required set 34 = 32 listed + 2 omitted.
- PL-P6: 8 entries, all APPLIED.

**Gap registers.**
- GAP-P5: 12 = OPEN or UNRESOLVED or BLOCKED 10 + CLOSED 1 (GAP-P5-08) + TRANSFERRED 1 (GAP-P5-09). Sum 12.
- GAP-P4: 11 = OPEN 10 (GAP-P4-01 to GAP-P4-10) + DISPOSITIONED as R-RISK 1 (GAP-P4-11). Sum 11.
- GAP-P6: 8, all OPEN.

**Owner decisions.** OD = 14 = pending 6 + default awaiting ratification 2 + resolved by design 4 + evidence-pending 2.

**Parameter register.** PRM = 53. Status counts from Part 5: ILLUSTRATIVE 1 + OWNER_DECISION_PENDING 3 + UNRESOLVED 5 + SCENARIO 4 + PROVISIONAL 9 + DERIVED 7 + RATIFIED_FINDING 1 + DESIGN_JUDGMENT 23 = 53.

**Decision and conflict records.** DR-01 to DR-28 = 28. CR-01 to CR-30 = 30.

**Protocol and self-review.** SP-1 to SP-12 = 12. SR-1 to SR-15 = 15.

**Experiments.** EXP-01 to EXP-13 = 13. Executed: 0.

**Verification items.** V-1 to V-12 = 12. Executed: 0.

**Source checks.** 13 identified. Executed: 0.

**Part 4 counts (carried).** CMP 17; placement 10 rows × 3 topologies = 30 cells; VC 4; HOLD origins 5; RA 7; GT 9; RST 8; IP 8; TX 12; OS 12; POS 5; CMD 7; AUD 16; CH 4 channels × 4 states = 16 cells; CL 4; OC 3; RC 6; BV 8; PC 16; LIB 11.

**Part 3 counts (carried).** Topologies 9 × criteria 7 = 63 cells; timeframes 14; entry accounting 1 + 1 + 9 = 11; pairs 134 × 10 = 1,340; split 134 + 1,206 = 1,340.

### §6.11.3 Status statement

- **Design status.** Complete as design across six parts.
- **Verification status.** Nothing executed. Register status is unchanged from Part 2: PASS 2, FAIL 0, BLOCKED 9, UNRESOLVED 12, NOT TESTED 55.
- **Live.** Not authorized. No Live permission is granted by this design. Live depends on the gates in Part 4, the experiments in §6.6, and the owner decisions in §6.7.3.
- **Profitability.** No claim is made. No backtest result, statistic or simulation output exists in this engagement.

**Completeness declaration.** All sections required by the brief for Part 6 are present. The arithmetic above is consistent. The items marked NOT_EXECUTED, NOT_EVALUATED, NOT_RECOVERABLE or OPEN are the explicit residual scope and are not PASS.

---

## §6.12 Final status by part

| Part | Content | Messages | Design status | Verification status |
|---|---|---|---|---|
| 1 | Delivery and boundary framework | 1 | Complete | Part 1 V-1 to V-7 not restated (GAP-P6-01) |
| 2 | Requirements register | 1 | Complete | Register structure NOT_EXECUTED (V-9) |
| 3 | Analytic record | 1 | Complete | Experiments NOT_EXECUTED |
| 4 | Design synthesis | 2 | Complete | PL-P4 recount pending (GAP-P6-03) |
| 5 | Statistics, budget, parameters | 2 | Complete | Fixture NOT_EXECUTED (V-8) |
| 6 | Completeness, catalogs, summary | 1 | Complete | Executed scan NOT_EXECUTED (V-12) |

Total messages: 1 + 1 + 1 + 2 + 2 + 1 = 8.

---

## §6.13 Closing summary (فارسی)

### خلاصه نهایی

**هدف و محدوده.** این مجموعه طراحی یک سیستم معاملاتی کمّی برای قراردادهای آتی و دائمی Toobit است که Telegram تنها رابط اپراتور آن است. این مجموعه یک طراحی است، نه پیاده‌سازی و نه تضمین سودآوری. هیچ کدی نوشته یا اجرا نشده، به هیچ حساب صرافی متصل نشده، کلیدی درخواست یا ارسال نشده و هیچ سفارشی ثبت، لغو یا اصلاح نشده است.

**آنچه تحویل شد.** شش بخش، در مجموع هشت پیام: چارچوب تحویل و مرزها؛ سجل ۷۸ الزام با یازده فیلد برای هر ردیف؛ سجل تحلیلی شامل حجم کار، توپولوژی‌ها، فازها، جهان نمادها، نقدینگی، توابع ریسک، گزینه‌ها و آزمایش‌ها؛ ترکیب طراحی شامل فرآیندها، وتوها، دروازه‌های ریسک، چرخه سفارش، تطبیق، فرمان‌های تلگرام، سیاست بی‌پاسخی اپراتور، ساعت و داده، عملیات، کتابخانه‌ها و ۲۸ رکورد تصمیم؛ روش‌شناسی آماری با بودجه آزمون و سجل ۵۳ پارامتر؛ و این بخش تکمیل.

**تصمیم‌های کلیدی طراحی.**
- **دو فرآیند.** یک Supervisor همیشه فعال برای تلگرام و فرمان‌های ایمنی، و یک Runtime برای معامله. فرمان‌های ایمنی حتی وقتی Runtime متوقف است در دسترس می‌مانند.
- **تلگرام.** دریافت پیام با polling خروجی. بدون webhook، چون webhook به یک نقطه ورودی بیرونی نیاز دارد و با الزام A9 در تضاد است.
- **ذخیره‌سازی.** یک فایل SQLite در حالت WAL، با یک نویسنده برای هر جدول.
- **جایگذاری.** امروز: گوشی فقط برای تحقیق و paper (T5). هدف Live: میزبان راه‌دور (T3)، مشروط به تصمیم هزینه مالک (OD-13). Live روی گوشی (T1) فقط پس از موفقیت EXP-01 و EXP-02.
- **حالت‌ها.** PAPER، LIVE و EXIT_ONLY. انتخاب Live بدون زمان انتظار است، اما فقط با شش قفل صحت.
- **خروج.** خروج خودکار پیش‌فرض است. /flatten بدون تأیید اجرا می‌شود.
- **سکوت اپراتور.** هیچ وتویی را تغییر نمی‌دهد. هشدار CRIT نیز H5 را تنظیم می‌کند.

**ارقام کلیدی.** همه ارقام زیر دارای برچسب هستند و به ورودی‌های مالک وابسته‌اند.
- **سرمایه مثال.** ۲۰۰ USDT (ILLUSTRATIVE). تحلیل در بازه برنامه‌ریزی زیر ۵۰۰ USDT خطی است.
- **هزینه و اصطکاک.** کارمزد ۰٫۰۶٪ هر طرف (محافظه‌کارانه، با ۰٫۰۵٪ به‌عنوان حساسیت)، لغزش توقف ۰٫۵٪ (سناریو)، و تأمین مالی ۰٫۳۰٪ در هر بازه (سناریو، با −۳۰ bp مشاهده‌شده).
- **اندازه معامله مثال با r = ۱٪.** L = 0.0092؛ N_t ≈ 217.39 USDT؛ R_nom ≈ 1.35 USDT؛ هزینه تأمین مالی ≈ 0.65 USDT در هر بازه؛ R_st = 2.00 USDT. این ارقام مثال هستند، نه پیش‌فرض.
- **جهان نمادها.** ۱۳۴ نماد (کران پایین بر پایه نقدینگی ۲۴ ساعته، تصویر دارای تاریخ)، و ده تایم‌فریم کاندید. ۵ دقیقه به‌دلیل نسبت هزینه ۱٫۴۲ حذف شد. ۱ دقیقه تا ۱۲ ساعت به‌صورت موقت (PROVISIONAL) پذیرفته شده‌اند تا EXP-04 تکمیل شود؛ ۱۵ دقیقه با نسبت ۰٫۸۲ پذیرفته شده است.
- **بودجه آزمون در مقیاس برنامه‌ریزی E_T = ۱٫۰.** ۱ پیکربندی برای ۱ دقیقه تا ۴ ساعت، ۲ برای ۶ ساعت، ۳ برای ۸ ساعت و ۶ برای ۱۲ ساعت. این یک محدودیت جستجو است، نه رد استراتژی.
- **ضریب منتشرشده ۴ ساعته (۱۰ تا ۲۰).** بازتولید نشد (CR-27). بازه‌های به‌دست‌آمده برای ۴ ساعته و یک روزه از هم جدا هستند. هیچ‌کدام به‌عنوان مقدار عملیاتی پذیرفته نشده است.
- **آستانه نقدینگی.** V_min = 2,400 × X × N USDT. با X = ۲ و r = ۱٪، حدود ۱٫۰۴ میلیون USDT است.
- **زمان.** τ_OK = ۳۰ ثانیه، N_c = ۳ (PROVISIONAL، مشروط به EXP-03). وقفه داده و قطع ارتباط با قوانین مشخص مدیریت می‌شود.

**آنچه تأیید نشده است.**
- هیچ آزمایشی اجرا نشده است (۰ از ۱۳).
- هیچ منبع خارجی بازیابی نشده است. ۱۳ مورد بررسی منبع شناسایی شده، که ممکن است کامل نباشد.
- هیچ الزامی به PASS نرسیده است. دو ردیف PASS از بخش ۲ بدون تغییر باقی‌مانده‌اند.
- بررسی‌های V-8 تا V-12 اجرا نشده‌اند. اسکن خودکار عبارات ممنوعه انجام نشده و فقط خوانش دستی صورت گرفته است.
- متن عملیاتی V-1 تا V-7 در این سجل بازتولید نشده است.

**تصمیم‌های در انتظار مالک.**
- **OD-01:** حداکثر افت سرمایه (D). مسدودکننده Live.
- **OD-02:** ریسک هر معامله (r). مسدودکننده Live.
- **c_agg:** سقف مواجهه کل. مسدودکننده Live، زیر OD-01 و OD-02.
- **OD-07:** سقف اهرم. مسدودکننده Live.
- **OD-13:** هزینه میزبان راه‌دور. مسدودکننده انتخاب میزبان Live.
- **OD-04:** شرایط حقوقی داده متقاطع. فقط مانع استفاده فراتر از تحقیق.
- **OD-03:** ترجیح ریسک و مطلوبیت. فقط مانع انتخاب.
- **OD-06:** سبک تأیید خروج. پیش‌فرض خروج خودکار است و تصمیم آن غیرمسدودکننده است. در این بخش یک بار مطرح شد.

**باقی‌مانده‌های شناخته‌شده.**
- **R-RISK-1.** قطع اتصال در حالی که موقعیت باز است. تا برگشت اتصال خروجی ممکن نیست.
- **R-RISK-2.** پس از خارج‌شدن بودجه راه‌اندازی مجدد، موقعیت بی‌سرپرست می‌ماند. تا تأیید حفاظت سمت صرافی (GAP-P4-01) باقی است.
- **R-RISK-3.** محدودیت جستجوی پیکربندی در مقیاس برنامه‌ریزی.
- **SR-13 و SR-14.** تجمیع نمادها می‌تواند ضعف یک نماد را پنهان کند. حساسیت به عمق تاریخی تا EXP-13 باقی است.

این باقی‌مانده‌ها با طراحی به‌تنهایی حذف نمی‌شوند. برخی فقط با حفاظت سمت صرافی یا تصمیم آگاهانه مالک قابل کاهش‌اند.

**اصلاحات این بخش.**
- **تعداد سجل PL-P4.** از ۲۷ به ۳۴ اصلاح شد: ۳۲ مورد فهرست‌شده به‌علاوه R-012 و R-016 که جا افتاده بودند. تفکیک ۲۸ ردیفی قبلی نادرست بود، چون بازه R-010 تا R-039 سی شناسه دارد.
- **هم‌پوشانی شناسه‌ها.** P1 تا P3 (گزینه‌های ذخیره‌سازی و فازها)، C-1 تا C-3 (سازوکارهای چرخه و قراردادهای آماری) و A-1 (پیشنهاد مرحله ۴ در برابر A1 تا A13 بریف) با نام‌های مستعار حل شدند.

**گام‌های بعدی (ترتیب وابستگی).**
۱. EXP-07 برای محیط و کتابخانه‌ها.
۲. EXP-13 برای عمق تاریخی، پیش از هر اجرای پروتکل.
۳. دسته بررسی منبع (۱۳ مورد).
۴. EXP-03 برای مرزهای زمان.
۵. EXP-08 و EXP-10 برای فیلترهای صرافی و جدول اهرم.
۶. EXP-09 برای بازه تأمین مالی.
۷. EXP-04 برای تأیید مجموعه تایم‌فریم.
۸. EXP-05، EXP-06، EXP-11 و EXP-12.
۹. EXP-02 و سپس EXP-01 برای رفتار گوشی.

**محدودیت‌های صداقت.** این مجموعه طراحی است و هیچ‌یک از نتایج آن شواهد سودآوری نیست. هیچ آماره‌ای حکم پذیرش یا رد یک استراتژی نیست. تا پایان آزمایش‌های بخش ۶ و تأیید مالک، سیستم برای Live آماده شمرده نمی‌شود.