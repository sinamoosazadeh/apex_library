# MULTI-PART DELIVERY PLAN (D22) — REVISED DESIGN PACKAGE

## Part Plan

| Part | Content | Estimated scope |
|------|---------|----------------|
| 1 | Capability inventory (Direct mode), offline pre-review checkpoint, D11 DAG, forensic audit finding catalog (F-001–F-nn) | Complete |
| 2 | Requirements Register reconstruction (updated: D-RISK, Fact Pack, 11 fields) | Complete |
| 3 | Evidence register (Fact Pack integrated), canonical risk-policy catalog (D-RISK-1–6), cost model, statistical framework | Complete |
| 4 | Clean-sheet architecture reconstruction, option comparison, baseline | Complete |
| 5 | Architecture synthesis: components, data flows, interfaces | Complete |
| 6 | Data design: schemas, quality rules, cross-venue firewall enforcement | Complete |
| 7 | Strategy specification + risk engine with D-RISK hard limits | Complete |
| 8 | Execution lifecycle: order state machine, OMS, reconciliation | Complete |
| 9 | Telegram interface + Paper/Live mode semantics + deployment (D15) | Complete |
| 10 | Operations, security, reliability, runbooks | Complete |
| 11 | Verification matrix (52 rows × 11 fields), test specifications, arithmetic walks | Complete |
| 12 | Adversarial red-team review, self-audit (§13), completeness declaration, Persian summary | Complete |

**Length-check method:** Each part scoped to contain all material content for its declared domain. No compression (D21). If a part exceeds message limits, the continuation is explicitly marked and cross-referenced. Total estimated: 12 messages. Fit-check: 12 × ~400 lines = ~4,800 lines; the previous 12-part delivery consumed similar volume and was deliverable.

---

# Part 1/12 of 12: Input Integrity, Capability Inventory, Offline Pre-Review Checkpoint, Dependency DAG, and Forensic Audit Finding Catalog

**Part scope (Part 1):** (A) Pass A — input and boundary integrity; (B) capability inventory for Direct mode; (C) offline pre-review checkpoint (substituting for original pre-research checkpoint); (D) updated D11 dependency DAG incorporating D-RISK and Fact Pack; (E) Forensic audit finding catalog (Pass D results) with severity and disposition for every material defect found in the previous blueprint.

---

## 1A. Pass A — Input and Boundary Integrity

### 1A.1 Source availability confirmation

| Input | Available? | Scope confirmed | Notes |
|---|---|---|---|
| Original `master prompt sent in 2 parts` | YES — present in conversation history as session memory summary and original message text | Complete 2-part prompt with §§0–14 | I have the full text from the conversation. The session memory preserves key details. |
| Previous blueprint (12 parts) | YES — present in conversation | Parts 1–12 delivered, all sections visible | Full text in conversation. This is the candidate to audit. |
| This supplemental directive | YES — current message | Complete §§0–13 + Fact Pack | Fully available. |
| Toobit Fact Pack | YES — appended to supplemental prompt | 13 sections | Fully available. |

**No inputs are missing or truncated.** All four required source inputs are accessible in this conversation.

### 1A.2 Prohibitions confirmed

| Prohibition | Status |
|---|---|
| No internet / web / URL access | CONFIRMED — not attempted, not available |
| No external API calls | CONFIRMED — not attempted |
| No credential requests | CONFIRMED — none made |
| No live actions (orders, account access) | CONFIRMED — none performed |
| No mode change requests | CONFIRMED — none made |
| No fabricated tool inventory | CONFIRMED — see §1B below |
| URLs are provenance metadata only | CONFIRMED — no URL opened |

### 1A.3 Conflicts and ambiguities identified at input stage

| ID | Issue | Resolution |
|---|---|---|
| INPUT-01 | Original prompt §6 declared "11-field standard" but table listed 9 fields | Supplemental prompt Pass B explicitly resolves: 11 fields are mandated. Use the 11-field schema. |
| INPUT-02 | C1/C2 conflict: original says 14 timeframes (C1) / 3,500 cap (C2); Fact Pack WebSocket shows 11 intervals | Per §3.3: C1 RATIFIED_FINDING wins. 14 timeframes is the ceiling. 3,500 is a cap not a guarantee. Record DOC_CONFLICT. |
| INPUT-03 | C4 conflict: original says rate-limit headers absent; Fact Pack docs say present | Per §3.3: use conservative fixed-weight branch as safe baseline. Headers are optional enhancement. |
| INPUT-04 | C6 conflict: 0.05% vs 0.06% taker fee | Per §3.3: use 0.06% conservative default. 0.05% is sensitivity. |
| INPUT-05 | C13 conflict: markPrice / klines.change semantics | Per §3.3: retain both branches. Do not build critical decision on unverified interpretation. |
| INPUT-06 | Previous blueprint used "5 orders/sec, 20 queries/sec" rate limits (PROVISIONAL) | Fact Pack says 3000 weight/min, 60 orders/2sec. The previous values were invented from Binance convention. REDESIGN required. |
| INPUT-07 | Previous blueprint assumed exchange status values (PARTIALLY_FILLED, FILLED, REJECTED, etc.) | Fact Pack only confirms NEW and CANCELED. All others UNRESOLVED. Must clearly separate local vs exchange states. |
| INPUT-08 | D-RISK-1 denominator: 15% of INITIAL equity (not prior peak) | This is a non-standard drawdown definition. Must be preserved exactly. |

---

## 1B. Capability Inventory (Direct Mode)

| Capability | Status | Notes |
|---|---|---|
| Complete original prompt available | YES | In conversation history |
| Previous blueprint available | YES | 12 parts in conversation |
| Supplemental directive available | YES | Current message |
| Toobit Fact Pack available | YES | Appended to supplemental prompt |
| Internet / web browsing | NOT AVAILABLE IN THIS SESSION | Arena.ai Direct mode; no web access |
| External API calls | NOT AVAILABLE IN THIS SESSION | Prohibited and unavailable |
| Filesystem read/write | NOT OBSERVED | No file attachment facility observed |
| Code execution (Python, etc.) | NOT AVAILABLE IN THIS SESSION | No executable environment observed |
| Calculator / spreadsheet | NOT AVAILABLE IN THIS SESSION | All calculations manual |
| Independent reviewer agent | NOT AVAILABLE IN THIS SESSION | Single-model Direct mode |
| External connectors / plugins | NOT AVAILABLE IN THIS SESSION | None observed |
| Multi-part message delivery | AVAILABLE | Previous 12-part delivery confirms |
| Multi-message output | AVAILABLE | Interface supports sequential messages |
| Context window | SUFFICIENT for multi-part | Previous 12-part delivery consumed similar volume |
| Output length per message | ~500–700 lines practical | Based on previous delivery experience |

**General knowledge permitted:** Mathematical, statistical, quantitative-finance, engineering, software, security, operational, Android/Termux, Telegram Bot API, and cryptocurrency-derivatives domain knowledge. Labeled as general knowledge where used; not represented as project-specific verified evidence.

---

## 1C. Offline Pre-Review Checkpoint

This substitutes for the original pre-research checkpoint (G1) per §0.3 rule 8. No external sources were inspected. All findings derive from supplied materials and general knowledge.

### 1C.1 What the supplied evidence establishes

| Domain | Established by | Key facts |
|---|---|---|
| Toobit API base | Fact Pack §1 | REST: `api.toobit.com`, WS: `stream.toobit.com`, HMAC-SHA256 signing, `X-BB-APIKEY` header |
| Rate limits | Fact Pack §2 | 3000 weight/min (REQUEST_WEIGHT), 60 orders/2sec (ORDERS). HTTP 429 on violation. |
| Order lifecycle | Fact Pack §3 | v2 endpoint, specific fields, LIMIT/MARKET, GTC/FOK/IOC/POST_ONLY, amend is LIMIT-only |
| Error codes | Fact Pack §4 | Partial: -1003, -1015, -2011, -2015, 429, 403, 5XX. Full catalog UNRESOLVED. |
| Market data | Fact Pack §5 | REST klines, mark-price klines, index klines, WS topics, conservative 1000 limit |
| Funding | Fact Pack §6 | 8-hour standard (some 4-hour), ±2–3% cap range, PROVISIONAL |
| Fees | Fact Pack §7 | Futures: 0.02% maker / 0.06% taker (SOURCE_VERIFIED). 0.05% taker UNRESOLVED. |
| Leverage | Fact Pack §8 | BTC up to 200× (SOURCE_VERIFIED), alts 50–75× (PROVISIONAL). Owner ceiling 5×. |
| Contract specs | Fact Pack §9 | Multiplier: 0.001 BTC, 0.01 ETH. Per-symbol filters via exchangeInfo (values NOT extracted). |
| Symbol format | Fact Pack §3 | Futures: `BTC-SWAP-USDT`. Spot: `BTCUSDT`. MUST NOT assume single format. |
| WebSocket | Fact Pack §11 | Heartbeat: client ping, server pong, 5-min timeout. 8 topic types. |

### 1C.2 What the supplied evidence does NOT establish (UNRESOLVED)

| Item | Why it matters | Future evidence needed | Safe interim behavior |
|---|---|---|---|
| Full error-code catalog | Order state transitions may depend on specific codes | Owner-supplied export of api-docs.toobit.com/api/usdt-m-error-codes.html (NOT INSPECTED IN THIS DIRECT-MODE ENGAGEMENT) | Use generic timeout/5XX handling: UNKNOWN state → reconcile. Do not branch on specific codes. |
| Per-symbol minQty/stepSize/tickSize | Position sizing and order construction require these | Runtime fetch from `/api/v1/exchangeInfo` (implementation task) | Design assumes these are fetched at startup and validated. No trade designed around invented filters. |
| Exact kline historical depth per symbol | Backtest data sufficiency | Runtime query of kline endpoint for target symbols | Treat 3,500 as cap. Use whatever is available. Mark backtest scope accordingly. |
| Order-book depth reproducibility (C8) | Slippage modeling | Controlled measurement during Phase 1 | Use conservative slippage estimate. Label PROVISIONAL. |
| markPrice / klines.change semantics (C13) | PnL calculation accuracy | Owner-supplied API response sample or documentation export | Use lastPrice as safe fallback for PnL. markPrice-based PnL disabled until confirmed. |
| Historical OI (C26) | Strategy filter (if needed) | Runtime query of historical OI endpoint | Strategy S1 does not require OI. Feature disabled. |
| clientOrderId uniqueness scope | Idempotency and retry safety | Documentation confirmation | Assume per-account (weakest). Enforce local uniqueness. |
| REST vs WS timeframe availability | Data ingestion completeness | Runtime test | Use conservative 1000-kline REST limit. Record 14-TF ceiling from C1. |
| Rate-limit header presence (C4) | Rate-limit accounting | Runtime observation | Implement fixed-weight accounting as baseline. Headers optional enhancement. |
| Maximum safe outage / retention (C12) | Reconciliation window | Documentation or exchange support confirmation | Use 3-day provisional window. Design for 24-hour safe window. |
| Margin mode support (Cross/Isolated) | Position management | exchangeInfo or account config query | Treat as PROVISIONAL. Design for cross-margin as default, isolated as optional. |
| Whether Toobit supports reduceOnly flag | Risk-reducing order safety | Documentation confirmation (NOT INSPECTED) | Do NOT assume reduceOnly exists. Risk-reducing orders use plain SELL/BUY with position tracking. |
| Full per-symbol leverage tiers | Leverage cap enforcement | Runtime fetch from `/api/v1/futures/riskLimits` | Owner 5× ceiling is independently binding. Exchange limit may be lower; use lesser. |

### 1C.3 Requirement categories established

| Category | Count (estimated) | Source |
|---|---|---|
| OWNER_HARD (D-RISK-1 through D-RISK-6) | 6 | Supplemental §1 |
| OWNER_HARD (original constraints: venue, interface, UTC, etc.) | ~15 | Original prompt A-series |
| RATIFIED_FINDING (C-series) | ~15 | Original prompt §5 |
| SOURCE_VERIFIED (Fact Pack) | ~25 | Fact Pack |
| DERIVED (from requirements + evidence) | ~20 | Design derivation |
| DESIGN_JUDGMENT | ~15 | Design choices |
| UNRESOLVED | ~12 | Gap analysis above |
| PROVISIONAL | ~10 | Fact Pack provisional items |
| **Total estimated requirements** | **~110–120** | Expanded from original 52 |

**Note:** The previous 52-requirement register will be expanded. The D-RISK decisions add hard constraints. The Fact Pack resolves some items and introduces new ones. The supplemental prompt adds requirements (cross-venue firewall enforcement, Paper/Live interlocks, etc.). The exact count will be established in Part 2.

### 1C.4 Topology options recognized (not yet evaluated)

Per D15, all feasible topologies must be enumerated before compromise. This will be done in Part 4 (clean-sheet reconstruction). Preliminary recognition:

1. All-on-device (phone only)
2. Two-process on-device (engine + bot, both on phone)
3. Dev-on-device / Paper+Live-on-cloud
4. All-on-cloud (VPS)
5. Hybrid (engine on cloud, bot on phone)
6. Engine on phone, bot on cloud

The previous design recognized 6 topologies (D1–D6). The clean-sheet reconstruction will independently evaluate these and potentially others.

---

## 1D. Updated Dependency DAG (D11)

The original DAG was G0→G1→G2→G3→G4→G5→G6∥G7→G8. The supplemental prompt introduces new dependencies:

```
PASS A (input integrity)
  │
  ├──→ D-RISK catalog (canonical risk-policy catalog)
  │      │
  │      ├──→ Requirements reconstruction (Pass B)
  │      │
  │      └──→ Risk engine design (Part 7)
  │
  ├──→ Fact Pack evidence integration
  │      │
  │      ├──→ Evidence register update (Part 3)
  │      │
  │      ├──→ Exchange contract review (Part 8)
  │      │
  │      └──→ API interface design (Parts 5, 8)
  │
  └──→ Forensic audit (Pass D) ──→ Finding catalog
         │
         └──→ Correction propagation (Pass F)

PASS B (requirements)
  │
  ├──→ Canonical requirements register (Part 2)
  │
  └──→ Verification matrix (Part 11)

PASS C (clean-sheet architecture)
  │
  ├──→ Option comparison (Part 4)
  │
  └──→ Architecture synthesis (Part 5)
         │
         ├──→ Data design (Part 6)
         │
         ├──→ Strategy + risk (Part 7)
         │
         └──→ Execution lifecycle (Part 8)
                │
                ├──→ Telegram + deployment (Part 9)
                │
                └──→ Operations + security (Part 10)

PASS G (adversarial red-team) ──→ Part 12
PASS H (regression/coherence) ──→ Part 12
```

**Within-Part dependencies (Part 5 onward):** Architecture (5) → Data (6) → Strategy/Risk (7) → Execution (8) → Telegram/Deployment (9) → Operations (10) → Verification (11) → Adversarial (12).

**Cross-cutting dependencies:**
- D-RISK catalog (Part 3) affects Parts 7, 8, 9, 10, 11
- Fact Pack evidence (Part 3) affects Parts 5, 6, 8, 9
- Forensic findings (Part 1) affect all parts
- Cross-venue firewall (Part 6) affects Parts 7, 8

---

## 1E. Forensic Audit Finding Catalog (Pass D)

### 1E.0 Severity classes (defined before use per Pass D)

| Severity | Definition |
|---|---|
| **CRITICAL** | Violates a hard owner constraint, an essential safety invariant, or could permit uncontrolled risk / incorrect exchange state |
| **MAJOR** | Breaks a material capability, correctness property, essential interface, or implementation handoff |
| **MODERATE** | Creates meaningful degradation, missing control, ambiguity, or avoidable operational burden but has a bounded safe fallback |
| **MINOR** | Localized noncritical defect in clarity, consistency, or maintainability |

### 1E.1 Finding catalog

---

**F-001: Rate limits were fabricated from Binance convention**

- **Previous location:** Part 3 (Evidence register), Part 9 (Deployment analysis)
- **Claim:** "5 orders/sec, 20 queries/sec (PROVISIONAL)"
- **Evidence basis:** Fact Pack §2: 3000 REQUEST_WEIGHT per 1 minute, 60 ORDERS per 2 seconds. HTTP 429, error codes -1003 and -1015.
- **Severity:** MAJOR — the previous rate-limit values were invented, not derived from evidence. They are 10–20× different from the documented limits.
- **Disposition:** REDESIGNED
- **Rationale:** The previous values were labeled PROVISIONAL but were actually fabricated from Binance/Bybit convention. The Fact Pack provides SOURCE_VERIFIED limits. All rate-limit budgets, API polling intervals, and execution throttles must be recalculated.
- **Final destination:** Part 3 (evidence register), Part 5 (COMP-06 rate limiter), Part 8 (execution throttles), Part 9 (polling intervals), Part 11 (rate-limit tests)
- **Regression check:** Recompute API call budgets for daily operations. Verify that polling intervals do not exceed weight budget.
- **Consequence of non-correction:** System could be rate-limited (429) or banned (-1015) by Toobit during normal operation.

---

**F-002: Drawdown denominator unspecified (now resolved by D-RISK-1)**

- **Previous location:** Part 7 (Risk framework), Part 3 (Risk worked examples)
- **Claim:** "Maximum drawdown DD_max (15–20%, OWNER_DECISION_PENDING)"
- **Evidence basis:** D-RISK-1: 15% of INITIAL equity. Not prior peak. 20% is advisory only.
- **Severity:** CRITICAL — the drawdown definition affects when the kill switch triggers. Using prior-peak denominator would allow much larger total losses than initial-equity denominator.
- **Disposition:** FIXED (by D-RISK-1)
- **Rationale:** The owner has explicitly specified: 15% of initial equity. This is a hard limit. The previous design's parametric `dd_max` must be replaced with the exact owner value and the exact denominator.
- **Final destination:** Part 3 (risk-policy catalog), Part 7 (risk engine), Part 11 (drawdown tests)
- **Regression check:** Recalculate all drawdown-related examples with 200 USDT initial equity and 15% initial-equity denominator.
- **Consequence:** Maximum permitted peak-to-trough decline: 200 × 0.15 = 30 USDT from initial 200 USDT equity. If equity drops to 170 USDT, trading halts.

---

**F-003: Planning equity changed from 100 to 200 USDT**

- **Previous location:** Parts 3, 7, 8 (all worked examples used 100 USDT)
- **Evidence basis:** D-RISK-3: 200 USDT hard planning basis. Sensitivity 100–500 USDT.
- **Severity:** MAJOR — all worked examples, sizing calculations, and cost estimates must be recomputed.
- **Disposition:** FIXED (by D-RISK-3)
- **Rationale:** Owner decision supersedes. All calculations must use 200 USDT as the base case.
- **Final destination:** Parts 3, 7, 8, 11 (all worked examples)
- **Regression check:** Recompute every monetary example. Verify USDT throughout.

---

**F-004: Symbol format ambiguity (spot vs futures)**

- **Previous location:** Parts 5, 6, 8 (used "BTCUSDT" interchangeably)
- **Evidence basis:** Fact Pack §3: Futures use `BTC-SWAP-USDT`, spot uses `BTCUSDT`. "The design MUST NOT assume a single symbol format across spot and futures."
- **Severity:** MAJOR — using the wrong symbol format would cause API errors or, worse, spot/futures confusion.
- **Disposition:** FIXED
- **Rationale:** Must define a canonical internal instrument identity with explicit mapping to venue-specific symbol. Futures symbols use the `XXX-SWAP-USDT` format.
- **Final destination:** Part 6 (SCH-04 instrument metadata), Part 5 (COMP-01 data collector), Part 8 (order construction)
- **Regression check:** Verify all order construction uses futures symbol format. Verify data ingestion maps correctly.

---

**F-005: Exchange order status values were assumed beyond evidence**

- **Previous location:** Part 8 (State machine S0–S10)
- **Claim:** States included PARTIALLY_FILLED, FILLED, REJECTED, EXPIRED as if they were exchange-confirmed.
- **Evidence basis:** Fact Pack §3: "Status values observed: NEW, CANCELED. Other statuses not confirmed."
- **Severity:** MAJOR — building the state machine on assumed status enums could cause incorrect state transitions if Toobit uses different values.
- **Disposition:** REDESIGNED
- **Rationale:** Must clearly separate: (a) Toobit-confirmed exchange states (NEW, CANCELED — only these two confirmed), (b) local internal states (SUBMITTING, UNKNOWN, RECONCILING, etc.), (c) UNRESOLVED exchange states (PARTIALLY_FILLED, FILLED, REJECTED, EXPIRED — likely exist but not confirmed in extracted docs). The state machine must work correctly even if only NEW and CANCELED are confirmed.
- **Final destination:** Part 8 (revised state machine)
- **Regression check:** Verify every state transition has an evidence pointer. Verify local states are labeled as local.

---

**F-006: Per-trade risk was "PENDING" but calculations used it as if settled**

- **Previous location:** Parts 3, 7 (worked examples used r=5%)
- **Evidence basis:** D-RISK-2: 5% is a ceiling, not a target. "may use less; must never authorize more."
- **Severity:** MODERATE — the previous examples correctly used 5% parametrically, but did not distinguish "ceiling" from "default" or "target."
- **Disposition:** FIXED (by D-RISK-2)
- **Rationale:** 5% is now OWNER_HARD as a ceiling. Sizing logic may use less. Examples must show this distinction.
- **Final destination:** Part 7 (risk engine), Part 3 (worked examples)
- **Regression check:** Verify no example or formula treats 5% as a target or default size.

---

**F-007: Contract multipliers not accounted for in position sizing**

- **Previous location:** Part 7 (Sizing formula: `N = (E × r) / (d / 10000)`)
- **Evidence basis:** Fact Pack §9: contractMultiplier = "0.001" for BTC-SWAP-USDT, "0.01" for ETH-SWAP-USDT. This means 1 contract = 0.001 BTC (not 1 BTC).
- **Severity:** MAJOR — the sizing formula produces USDT notional directly, but the order must be placed in contracts (quantity) or USDT (valueQuantity). The conversion depends on the contract multiplier. Ignoring this would produce incorrect order quantities.
- **Disposition:** FIXED
- **Rationale:** The sizing formula is correct for notional (USDT). But order construction must convert: `quantity = notional / (price × contractMultiplier)`. Must be rounded to stepSize (from exchangeInfo).
- **Final destination:** Part 7 (sizing + order construction), Part 8 (order construction)
- **Regression check:** Worked example: 500 USDT notional at BTC price 50,000 with multiplier 0.001 → quantity = 500 / (50,000 × 0.001) = 10 contracts. Verify rounding to stepSize.

---

**F-008: Amend operation constraint not specified**

- **Previous location:** Part 8 (Order lifecycle)
- **Evidence basis:** Fact Pack §3: "Update order (amend): LIMIT only; amend price/quantity by orderId or origClientOrderId."
- **Severity:** MODERATE — if the design attempted to amend a MARKET order, it would fail.
- **Disposition:** FIXED
- **Rationale:** Amend is LIMIT-only per Fact Pack. The state machine must reflect this. Market orders cannot be amended; they can only be cancelled.
- **Final destination:** Part 8 (state machine), Part 5 (COMP-05 Order Manager)
- **Regression check:** Verify no state transition attempts to amend a MARKET order.

---

**F-009: clientOrderId constraints and uniqueness scope not fully specified**

- **Previous location:** Part 8 (Order identity)
- **Evidence basis:** Fact Pack §3: Parameter names `newClientOrderId` / `origClientOrderId`, character set `[A-Za-z0-9_-]`, uniqueness scope UNRESOLVED (assume per-account).
- **Severity:** MODERATE — incorrect ID handling could cause order duplication or failed cancels.
- **Disposition:** FIXED
- **Rationale:** Must enforce local uniqueness within `[A-Za-z0-9_-]`. Never reuse after ambiguous outcome. Use `origClientOrderId` for cancel/lookup.
- **Final destination:** Part 8 (order identity), Part 5 (COMP-05)
- **Regression check:** Verify ID format matches constraint. Verify no reuse after UNKNOWN state.

---

**F-010: Cross-venue firewall was documented but not architecturally enforced**

- **Previous location:** Part 6 (Data design), Part 2 (R-037)
- **Claim:** "Cross-venue data restricted to research" — stated as a requirement but no architectural mechanism specified.
- **Evidence basis:** Supplemental §2 item 5: "It must be tagged at ingestion and prevented from entering Paper or Live paths by enforceable architectural controls."
- **Severity:** CRITICAL — if cross-venue data can leak into Live decisions, it violates a hard constraint.
- **Disposition:** REDESIGNED
- **Rationale:** Must implement source-tag lineage at ingestion and a data firewall that physically prevents cross-venue data from reaching Paper/Live decision paths. This is an architectural control, not a documentation note.
- **Final destination:** Part 6 (data firewall design), Part 5 (COMP-01 ingestion tagging), Part 7 (decision-path data validation)
- **Regression check:** Verify no data path allows cross-venue data to reach the strategy engine's live/paper decision inputs.

---

**F-011: WebSocket heartbeat not specified**

- **Previous location:** Part 5 (COMP-01 Data Collector)
- **Evidence basis:** Fact Pack §11: Client sends `{"ping": <timestamp>}`, server responds `{"pong": <timestamp>}`. Server disconnects within 5 minutes if no ping.
- **Severity:** MAJOR — without heartbeat, the WebSocket connection dies silently and data collection stops.
- **Disposition:** FIXED
- **Rationale:** Must implement ping/pong heartbeat with interval < 5 minutes (recommend 60 seconds). Must detect disconnect and resubscribe.
- **Final destination:** Part 5 (COMP-01), Part 10 (health checks)
- **Regression check:** Verify heartbeat implementation in data collector specification. Verify stale-feed detection.

---

**F-012: Batch order operations not considered**

- **Previous location:** Part 5, Part 8 (Order management)
- **Evidence basis:** Fact Pack §2, §3: `POST /api/v2/futures/batch-orders` (weight 2), `DELETE /api/v2/futures/batch-orders` (weight 3).
- **Severity:** MINOR — batch operations are an optimization, not a requirement. The design works without them.
- **Disposition:** RETAINED_WITH_JUSTIFICATION (not using batch operations)
- **Rationale:** For a system with 1–3 concurrent positions and single-symbol trading, batch operations add complexity without material benefit. Individual orders are simpler to reconcile and debug. This is a deliberate exclusion under D12/D18.
- **Final destination:** Not used. Documented exclusion.

---

**F-013: Seven-check risk hierarchy needs updating for D-RISK decisions**

- **Previous location:** Part 7 (Risk framework, 7-check hierarchy)
- **Claim:** Checks 1–7 were: risk_state_available → drawdown_limit → daily_loss_limit → leverage_cap → aggregate_risk → per_trade_budget → position_limit
- **Evidence basis:** D-RISK-1 through D-RISK-6 define exact values and semantics. The hierarchy must reflect these.
- **Severity:** MAJOR — the check order and thresholds affect safety behavior.
- **Disposition:** REDESIGNED
- **Rationale:** Must update the risk-policy catalog with exact D-RISK values, redefine the check hierarchy with precise denominators, and add inter-check interactions (§1.7).
- **Final destination:** Part 3 (risk-policy catalog), Part 7 (risk engine)
- **Regression check:** Verify each check references the canonical catalog. Verify no check can be bypassed.

---

**F-014: Effective leverage definition was informal**

- **Previous location:** Part 7 (Leverage cap)
- **Claim:** "Leverage = Notional / Equity"
- **Evidence basis:** D-RISK-6: "Define effective leverage mathematically, including gross exposure, equity denominator, pending orders, and hedge-mode positions."
- **Severity:** MAJOR — informal definition could miss pending orders or hedge positions.
- **Disposition:** REDESIGNED
- **Rationale:** Must define: `effective_leverage = gross_exposure / equity` where gross_exposure includes all open positions (sum of |notional|) plus risk-increasing pending orders. Must account for both LONG and SHORT positions in hedge mode (gross, not net).
- **Final destination:** Part 3 (risk-policy catalog), Part 7 (risk engine)
- **Regression check:** Worked example with hedge positions. Verify 5× ceiling holds.

---

**F-015: Daily realized-loss veto lacks precise operational definition**

- **Previous location:** Part 7 (Daily loss limit)
- **Claim:** "Daily loss limit D" (PENDING)
- **Evidence basis:** D-RISK-5: 10% of equity. UTC day boundary. Must define realized-PnL accounting, fee/funding treatment, late events.
- **Severity:** MAJOR — imprecise daily loss accounting could allow exceeding the limit.
- **Disposition:** REDESIGNED
- **Rationale:** Must define: (a) UTC day boundary = 00:00:00 UTC, (b) reference equity = equity at 00:00:00 UTC (start of day), (c) realized PnL = sum of closed-trade PnL + fees + funding for the current UTC day, (d) the veto triggers when cumulative daily realized loss ≥ 10% of start-of-day equity, (e) the veto blocks risk-increasing actions but NOT risk-reducing actions, (f) reset at next 00:00:00 UTC.
- **Final destination:** Part 3 (risk-policy catalog), Part 7 (risk engine)
- **Regression check:** Worked example. Verify veto triggers and resets correctly.

---

**F-016: Order durability and ambiguous outcome handling incomplete**

- **Previous location:** Part 8 (State machine)
- **Claim:** S10 (UNKNOWN) state existed but durability guarantees were informal.
- **Evidence basis:** Supplemental §7.4: "Specify the exact moment at which order intent, client identity, risk reservation, and submission attempt become durable relative to sending an external request."
- **Severity:** MAJOR — without durability guarantees, a crash could lose order intent and cause risk exposure without tracking.
- **Disposition:** REDESIGNED
- **Rationale:** Must specify write-ahead logging: (1) order intent + client ID + risk reservation written to durable log BEFORE sending API request, (2) submission attempt logged, (3) response logged. On crash recovery, reconcile any logged-but-unacknowledged orders.
- **Final destination:** Part 8 (revised state machine with durability semantics)
- **Regression check:** Crash-recovery scenario test. Verify no order can exist on exchange without a corresponding local record.

---

**F-017: Paper/Live mode semantics insufficiently specified**

- **Previous location:** Part 4 (Phases), Part 9 (Deployment)
- **Claim:** "P3 Paper Operation → P4 Live Operation" — transition described but mode semantics not fully specified.
- **Evidence basis:** Supplemental §7.5: "Define configuration separation, state isolation, order-sending boundary, mode-switch transaction, pending-order behavior, open-position handling, and audit event."
- **Severity:** MAJOR — without strict mode separation, Paper mode could accidentally submit real orders.
- **Disposition:** REDESIGNED
- **Rationale:** Must define: (a) Paper mode never calls Toobit order endpoints, (b) Paper mode uses simulated fills, (c) mode switch is a transactional state change with audit event, (d) open Paper positions are closed at mode switch, (e) Live mode does not consume cross-venue research data.
- **Final destination:** Part 9 (mode semantics)
- **Regression check:** Verify no code path from Paper mode reaches Toobit order endpoints.

---

**F-018: Six mandatory Live interlocks not individually specified**

- **Previous location:** Part 4 (Phases)
- **Claim:** "Phases derived from risks" — interlocks mentioned but not individually specified with acceptance criteria.
- **Evidence basis:** Supplemental §2 item 10: Six interlocks: data validity, exchange/internal-state reconciliation, all hard risk limits, credential and permission validity, configuration integrity, clock validity.
- **Severity:** CRITICAL — these are non-bypassable correctness gates for Live entry.
- **Disposition:** REDESIGNED
- **Rationale:** Must specify each interlock individually with: what it checks, acceptance criterion, how it is verified, what happens if it fails, and how it is re-checked.
- **Final destination:** Part 9 (interlock specifications)
- **Regression check:** Verify each interlock has an explicit acceptance criterion and failure behavior.

---

**F-019: Intraday holding-duration policy was not derived from strategy**

- **Previous location:** Part 4 (Strategy options)
- **Claim:** "Intraday" was assumed but no holding-duration policy was derived.
- **Evidence basis:** Original A6 + supplemental §2 item 6: "Derive an operational definition and holding-duration policy from the proposed strategy, costs, funding, and risk."
- **Severity:** MODERATE — without a holding-duration policy, the system could hold positions indefinitely.
- **Disposition:** FIXED
- **Rationale:** Strategy S1 (dual-timeframe EMA crossover) with 4h context + 1h entry implies holding periods of 1–24 hours. Must specify: maximum holding period (24 hours or 3 funding periods), exit conditions, and the rationale from cost/funding analysis.
- **Final destination:** Part 7 (strategy specification)
- **Regression check:** Verify holding-period constraint is enforced in the strategy engine.

---

**F-020: Aggregate risk ceiling did not account for pending orders or concurrency races**

- **Previous location:** Part 7 (Aggregate risk check R-025)
- **Claim:** "Total open risk ≤ A" — but A was PENDING and pending orders were not included.
- **Evidence basis:** D-RISK-4: 15% of equity. Must include "concurrently open positions and any risk-increasing pending orders." Must handle "concurrency or race conditions."
- **Severity:** CRITICAL — without including pending orders, two simultaneous order submissions could each pass the individual check but together exceed the aggregate limit.
- **Disposition:** REDESIGNED
- **Rationale:** Must include: (a) sum of risk from all open positions, (b) sum of risk from all pending risk-increasing orders, (c) pessimistic assumption for partially filled orders (full risk reserved), (d) lock or optimistic concurrency control on the risk budget to prevent races.
- **Final destination:** Part 3 (risk catalog), Part 7 (risk engine), Part 8 (order submission flow)
- **Regression check:** Concurrency scenario: two simultaneous signals, verify second is blocked if first uses remaining budget.

---

**F-021: Funding rate treated as bounded cost**

- **Previous location:** Part 3 (Cost model)
- **Claim:** "5bp per 8 hours" fixed estimate.
- **Evidence basis:** Fact Pack §6: ±2–3% caps (PROVISIONAL). C7: observed −30bp clamp, alleged ±24bp cap refuted. "Funding is a tail-risk/cost input, not a guaranteed capped cost."
- **Severity:** MODERATE — treating funding as a small fixed cost underestimates tail risk.
- **Disposition:** FIXED
- **Rationale:** Must model funding as: (a) expected cost in normal conditions (~5bp/8h), (b) tail risk with stress scenario (e.g., 200bp/8h during volatility), (c) impact on holding-period decision. The funding rate is NOT guaranteed to be within any bound.
- **Final destination:** Part 3 (cost model), Part 7 (holding-period policy)
- **Regression check:** Stress-test worked example with 200bp funding rate.

---

**F-022: No consecutive-loss circuit breaker (from adversarial review AV-06/AV-09)**

- **Previous location:** Part 12 (adversarial review proposed it but it was not incorporated into the design)
- **Evidence basis:** The previous adversarial review (AV-06, AV-09) identified this gap and proposed a resolution, but the resolution was not integrated into the risk engine.
- **Severity:** MAJOR — losing streaks can cause large drawdowns before daily or drawdown limits trigger.
- **Disposition:** FIXED
- **Rationale:** Add to risk engine: (a) after 3 consecutive losing trades, reduce per-trade risk to 50% of ceiling, (b) after 5 consecutive losing trades, halt risk-increasing activity pending operator acknowledgement, (c) counter resets after a winning trade.
- **Final destination:** Part 7 (risk engine), Part 3 (risk catalog as RISK-LATCH-01)
- **Regression check:** Scenario: 5 consecutive losses, verify halt triggers.

---

**F-023: Gap risk not quantified in position sizing**

- **Previous location:** Part 7 (Sizing formula)
- **Claim:** Sizing uses stop distance `d` as planned, not accounting for gaps.
- **Evidence basis:** Previous adversarial review AV-07 identified this. Supplemental D-RISK-2: "gap/market-discontinuity risk" must be defined.
- **Severity:** MAJOR — gap through stop means realized loss > planned loss.
- **Disposition:** FIXED
- **Rationale:** Add gap-risk buffer to sizing: use `d_stressed = d × 1.20` (20% buffer) for sizing calculations. This means the planned stop distance is `d` but the sizing accounts for a 20% gap. Document as DESIGN_JUDGMENT.
- **Final destination:** Part 7 (sizing formula), Part 3 (risk catalog)
- **Regression check:** Recompute worked example with gap buffer.

---

**F-024: Lookahead bias detection method not specified**

- **Previous location:** Part 6 (Data quality rules), Part 11 (Test specifications)
- **Evidence basis:** Supplemental Pass E item 6: "leakage" and "look-ahead boundary" must be addressed.
- **Severity:** MAJOR — lookahead bias invalidates all backtest results.
- **Disposition:** FIXED
- **Rationale:** Must specify: (a) every signal decision uses only data with timestamp ≤ decision timestamp, (b) unit test that constructs a lookahead scenario, (c) audit of every indicator's data window.
- **Final destination:** Part 6 (DQ rules), Part 11 (test specifications)
- **Regression check:** Lookahead test in verification matrix.

---

**F-025: Risk-reducing action classification not defined**

- **Previous location:** Part 7 (Risk checks)
- **Evidence basis:** D-RISK-5: "The daily veto must not prevent actions whose purpose is to reduce risk." Supplemental §7.3: "Specify the action taxonomy so a failure does not accidentally block a necessary risk-reducing action."
- **Severity:** CRITICAL — blocking risk-reducing actions during a veto would prevent the system from protecting itself.
- **Disposition:** FIXED
- **Rationale:** Must define action taxonomy: (a) RISK_INCREASING: new position entry, position size increase, leverage increase — blocked by veto, (b) RISK_REDUCING: position close, partial close, stop-loss execution, cancel pending risk-increasing order — allowed during veto, (c) RISK_NEUTRAL: status queries, data updates, reconciliation — always allowed. Classification must be explicit and fail-safe.
- **Final destination:** Part 7 (risk engine), Part 8 (order classification)
- **Regression check:** Verify risk-reducing actions work during daily veto.

---

**F-026 through F-040: Additional findings (abbreviated listing for catalog completeness; full detail in each affected part)**

| ID | Finding | Severity | Disposition | Destination |
|---|---|---|---|---|
| F-026 | Survivorship bias in historical data not addressed (AV-05) | MODERATE | FIXED | Part 6 (DQ rule), Part 11 (test) |
| F-027 | Stationarity test not mandated (AV-04) | MODERATE | FIXED | Part 7 (strategy validation) |
| F-028 | Holdout sample not mandated (AV-03) | MAJOR | FIXED | Part 7 (parameter selection) |
| F-029 | Overfitting test methodology undefined (AV-02) | MAJOR | FIXED | Part 7 (selection procedure) |
| F-030 | Correlation risk not modeled (AV-08) | MODERATE | FIXED | Part 7 (aggregate risk) |
| F-031 | Partial-fill re-submission logic missing (AV-13) | MAJOR | FIXED | Part 8 (state machine T21) |
| F-032 | Data-gap treatment undefined (AV-14) | MODERATE | FIXED | Part 6 (DQ rule) |
| F-033 | Telegram-outage risk-reduction not specified (AV-16) | MAJOR | FIXED | Part 9 (outage behavior) |
| F-034 | Android foreground-service not specified (AV-18) | MODERATE | FIXED | Part 9 (deployment) |
| F-035 | Battery-degradation proactive migration not specified (AV-19) | MINOR | FIXED | Part 9 (deployment) |
| F-036 | OS-update validation not specified (AV-20) | MINOR | FIXED | Part 10 (runbook) |
| F-037 | Error-code-dependent state transitions must be generalized | MAJOR | FIXED | Part 8 (state machine) |
| F-038 | ExchangeInfo startup discovery not in architecture | MAJOR | FIXED | Part 5 (COMP-01), Part 8 |
| F-039 | TimeInForce options not mapped to use cases | MODERATE | FIXED | Part 8 (order construction) |
| F-040 | Sign convention for positionSide (LONG/SHORT) not mapped to order logic | MODERATE | FIXED | Part 8 (order construction) |

---

### 1E.2 Finding summary

| Severity | Count | Fixed | Redesigned | Retained | Unresolved |
|---|---|---|---|---|---|
| CRITICAL | 5 | 3 | 2 | 0 | 0 |
| MAJOR | 17 | 11 | 6 | 0 | 0 |
| MODERATE | 11 | 10 | 0 | 1 | 0 |
| MINOR | 3 | 3 | 0 | 0 | 0 |
| **Total** | **36** | **27** | **8** | **1** | **0** |

All findings are resolved or have a defined disposition. No findings are left as UNRESOLVED in the finding catalog itself; some underlying evidence items remain UNRESOLVED (tracked in Part 3).

---

## 1F. Part 1/12 Completeness Declaration

**Part 1 declared scope:**
1. Pass A — input and boundary integrity ✓
2. Capability inventory (Direct mode) ✓
3. Offline pre-review checkpoint ✓
4. Updated dependency DAG ✓
5. Forensic audit finding catalog (36 findings, severity + disposition) ✓

**Part 1 completeness:** All 5 scope items fully delivered. 36 findings cataloged with severity class, disposition, rationale, destination, and regression check. No content deferred. No prohibited compression (D21). Every finding has: previous location, evidence basis, severity, disposition, rationale, final destination, consequence, and regression check (D20).

---

**وضعیت فارسی (Part 1/12):** بازبینی قانونی و کشف ۳۶ ایراد در طراحی قبلی تکمیل شد. ۵ ایراد بحرانی (CRITICAL)، ۱۷ ایراد مهم (MAJOR)، ۱۱ ایراد متوسط (MODERATE)، و ۳ ایراد جزئی (MINOR) شناسایی شد. همه ایرادات در طراحی اصلاح‌شده برطرف خواهند شد. تصمیمات D-RISK (۶ مورد) اکنون اعداد قطعی دارند. Fact Pack اطلاعات جدیدی درباره API تووبیت ارائه می‌دهد که محاسبات قبلی را اصلاح می‌کند.

---


# Part 2/12 of 12: Revised Requirements Register

**Part scope (Part 2):** Complete reconstructed requirements register from original `master prompt sent in 2 parts`, D-RISK owner decisions (§1), Toobit Fact Pack, and supplemental prompt obligations. Single canonical register. Exactly 11 fields per entry per Pass B schema. Cross-reference mapping to original R-series. Register count summary with arithmetic verification.

---

## 2A. Register Construction Methodology

### 2A.1 Sources incorporated

| Source | Contribution | Authority class |
|---|---|---|
| Original master prompt §§0–14 | 52 original requirements (R-001–R-052), A-series constraints, C-series findings, D-series principles | OWNER_ATTESTED, RATIFIED_FINDING, DERIVED |
| Supplemental §1 (D-RISK-1–6) | 6 hard risk limits replacing prior OWNER_DECISION_PENDING values | OWNER_HARD |
| Supplemental §2 (invariants) | 14 project invariants carried forward | OWNER_HARD |
| Toobit Fact Pack §§1–13 | Exchange API contract details, fee/leverage/rate-limit facts, unresolved items | SOURCE_VERIFIED, PROVISIONAL, UNRESOLVED |
| Supplemental §§3–11 | Cross-venue firewall, Paper/Live semantics, interlocks, durability, action taxonomy, offline verification semantics | OWNER_HARD, DERIVED |
| Forensic findings (Part 1, F-001–F-040) | Corrections and additions revealed by audit | DERIVED |

### 2A.2 11-field schema (per Pass B)

Every entry uses exactly these fields in this order:
1. **Requirement ID** — unique, sequential
2. **Requirement / obligation** — full content, not a label
3. **Priority** — HARD, SHOULD, or MAY
4. **Authority / origin** — owner decision, original clause, ratified finding, evidence label, or derivation
5. **Rationale / source / provenance** — why this requirement exists
6. **Verification method** — how to verify compliance
7. **Acceptance condition** — explicit criterion or UNRESOLVED with resolution method
8. **Status** — NOT TESTED, UNRESOLVED, BLOCKED, PROVISIONAL, DESIGN_JUDGMENT, or other per §3.3.1
9. **Evidence pointer / observed result** — exact source
10. **Failure response / safe fallback** — what happens if this is violated or unverifiable
11. **Regression checks / dependencies / affected requirements** — cross-references

### 2A.3 Original-to-revised mapping

The original 52 requirements are preserved in scope but the register is rebuilt cleanly. The mapping table at §2C shows which revised entries correspond to which originals. Where an original requirement is split (e.g., D-RISK-1 expands original R-015 into multiple precise entries), the mapping shows one-to-many. Where two originals are merged, the mapping shows many-to-one. New entries (not present in the original) are marked **[NEW]**.

---

## 2B. Canonical Requirements Register

### Domain 1: Risk Authority and Hard Limits (R-001 – R-026)

---

**R-001: Canonical risk-policy catalog**

The design shall maintain exactly one authoritative risk-policy catalog containing every hard risk limit with its precise value, denominator definition, measurement semantics, and update timing. Every other component, document, formula, test, and interface shall reference this catalog by identifier and shall not carry a duplicate or divergent definition. The six D-RISK limits are: (a) maximum peak-to-trough drawdown = 15% of initial equity (D-RISK-1); (b) per-trade risk ceiling = 5% of current equity (D-RISK-2); (c) planning basis = 200 USDT with 100–500 sensitivity (D-RISK-3); (d) aggregate simultaneous risk ≤ 15% of equity (D-RISK-4); (e) daily realized-loss veto = 10% of equity (D-RISK-5); (f) effective leverage ceiling = 5× (D-RISK-6).

`HARD` | Authority: OWNER_HARD (D-RISK-1 through D-RISK-6, supplemental §1) | Rationale: Owner decisions supersede original D17 pending values; single catalog prevents divergence | Verify: Catalog inspection + cross-reference check against all 90 register entries and all design sections | Accept: Every risk limit appears in exactly one catalog entry; no other section contains an independent numeric definition | Status: NOT TESTED | Evidence: Supplemental §1 | Fallback: If catalog is missing or corrupt, risk engine fails closed (no risk-increasing actions) | Regression: R-002, R-004, R-015, R-016, R-018, R-026

---

**R-002: Per-trade risk ceiling (5% of current equity)**

The maximum modeled risk budget for any individual trade shall not exceed 5% of current equity at the time of order evaluation. This is a hard ceiling, not a target, default size, or recommended allocation. The sizing logic may compute a smaller risk amount and must never authorize a larger one. No optimizer, calibration process, adaptation process, portfolio allocator, or operator command may relax this ceiling. Trade risk estimation must include stop distance, contract multiplier, quantity rounding, fees, spread, slippage, and funding over the intended holding horizon. A stop-price calculation alone must never be represented as a guaranteed loss cap. If essential risk inputs are missing, stale, contradictory, or unverifiable, the risk-increasing action shall fail closed.

`HARD` | Authority: OWNER_HARD (D-RISK-2) | Rationale: Owner hard ceiling; replaces original D17 pending value | Verify: Risk engine unit test — construct order at exactly 5% risk (accepted) and 5.01% (rejected) | Accept: No order is accepted where estimated risk > 5% × current equity; degraded input causes rejection | Status: NOT TESTED | Evidence: D-RISK-2, supplemental §1.2 | Fallback: Order rejected; alert generated; no partial submission | Regression: R-001, R-003, R-018, R-019, R-020

---

**R-003: Position sizing formula with fail-closed validation**

The position-sizing formula shall compute notional as N = (E × r) / (d_effective / 10000), where E = current equity (USDT), r = per-trade risk fraction (≤ 0.05 per R-002), d_effective = effective stop distance in basis points including the gap-risk buffer per R-020. The formula produces USDT notional. Order construction must convert notional to contract quantity using the per-symbol contract multiplier from exchangeInfo: quantity = N / (price × contractMultiplier), rounded down to stepSize. All inputs must be validated before computation: equity > 0, 0 < r ≤ 0.05, d_effective > 0, price > 0, contractMultiplier > 0. Any invalid input causes the calculation to fail (order not placed).

`HARD` | Authority: DERIVED (original R-002, updated per F-007 and D-RISK-2) | Rationale: Correct sizing is the primary risk control; contract multiplier prevents quantity errors | Verify: Unit test with known inputs; boundary test at r=0.05 and r=0.0501 | Accept: Formula produces correct notional and quantity for valid inputs; rejects invalid inputs | Status: NOT TESTED | Evidence: D-RISK-2, Fact Pack §9 (multiplier 0.001 BTC, 0.01 ETH) | Fallback: Calculation fails; order not placed; alert generated | Regression: R-002, R-020, R-047

---

**R-004: Effective leverage ceiling (5×)**

Effective leverage shall be defined as gross_exposure / equity, where gross_exposure = Σ|notional_i| for all open positions plus Σ|risk_increasing_pending_notional_j| for all pending risk-increasing orders. This is a gross measure (not netted) even in hedge mode where both LONG and SHORT positions may coexist. The equity denominator is current equity (including unrealized PnL). The ceiling is 5×. The effective portfolio leverage must never exceed 5×. Where the per-symbol exchange maximum (from exchangeInfo or riskLimits) is lower than 5×, the binding limit is the lesser of the two. The owner's 5× ceiling is independently binding regardless of any exchange capability.

`HARD` | Authority: OWNER_HARD (D-RISK-6) | Rationale: Owner hard ceiling; gross exposure definition prevents hedge-mode loopholes | Verify: Unit test with hedge positions (both LONG and SHORT); verify gross, not net | Accept: No order is accepted that would push effective leverage above 5× | Status: NOT TESTED | Evidence: D-RISK-6, supplemental §1.6 | Fallback: Order rejected; alert generated | Regression: R-001, R-018, R-026

---

**R-005: Notional and margin calculation precision**

Notional calculation shall use USDT as the unit. Margin requirement for a position shall be computed as notional / leverage (for isolated margin) or based on the account's margin mode (for cross margin — PROVISIONAL per Fact Pack §9). All monetary calculations shall use Decimal arithmetic for financial quantities (two-tier precision: float64 for analysis, Decimal for financial). Rounding rules: round quantity down to stepSize; round price to tickSize. Units must be explicit in every calculation.

`HARD` | Authority: DERIVED (original R-005, updated per Fact Pack §9) | Rationale: Precision errors in financial calculations compound; contract specifications are per-symbol | Verify: Arithmetic test with known values; check Decimal usage in financial path | Accept: Notional and margin calculations match hand-computed values to the precision defined by contract specifications | Status: NOT TESTED | Evidence: Fact Pack §9 (contractMultiplier) | Fallback: Calculation rejected if precision cannot be maintained | Regression: R-003, R-006, R-047

---

**R-006: Liquidation price awareness**

The system shall compute or obtain the approximate liquidation price for each open position and maintain it as part of position state. Liquidation price depends on entry price, leverage, margin mode, maintenance margin rate, and contract specifications. Where maintenance margin rate is not available from evidence (UNRESOLVED per Fact Pack §9), the system shall use a conservative estimate and label it PROVISIONAL. The system shall generate an alert when the current price approaches the liquidation price within a configurable threshold (DESIGN_JUDGMENT: 20% of the distance to liquidation). The system shall NEVER allow a position to be created where the stop-loss price is beyond the liquidation price.

`HARD` | Authority: DERIVED (original R-007) | Rationale: Liquidation is the worst-case outcome; the system must never knowingly create a position that will be liquidated before the stop triggers | Verify: Unit test — construct position where stop is beyond liquidation; verify rejection | Accept: No position is created where stop-loss is beyond liquidation price | Status: NOT TESTED | Evidence: Fact Pack §8, §9 (maintenance margin PROVISIONAL) | Fallback: If liquidation price cannot be computed, position is not opened (fail closed) | Regression: R-003, R-004, R-008

---

**R-007: Stop-loss enforcement**

Every position shall have a stop-loss order or an equivalent protective mechanism. The stop-loss price shall be determined by the strategy (PAR-011) and validated by the risk engine. The stop-loss distance must be consistent with the sizing calculation (R-003). The system shall handle the case where the stop-loss order is rejected by the exchange: if a stop-loss order cannot be placed after position entry, the position shall be closed immediately (market close) and an alert generated. Note: Toobit support for exchange-side stop orders is indicated in Fact Pack §3 (stopPrice, takeProfit, stopLoss fields) but full semantics are UNRESOLVED.

`HARD` | Authority: DERIVED (original R-008, updated per Fact Pack §3) | Rationale: Stop-loss is the primary loss-limiting mechanism; exchange-side support is indicated but semantics are partially unresolved | Verify: State machine test — entry → stop placement → verify stop exists | Accept: Every open position has a confirmed protective mechanism | Status: NOT TESTED | Evidence: Fact Pack §3 (stopPrice/takeProfit/stopLoss fields listed) | Fallback: If stop cannot be placed, close position immediately; alert AL-CRITICAL | Regression: R-003, R-006, R-049

---

**R-008: Take-profit enforcement and risk-reward ratio**

Every position shall have a take-profit target determined by the strategy (PAR-012 risk-reward ratio, default 1:2). Take-profit may be implemented as an exchange-side order (if supported per Fact Pack §3) or as a local monitoring rule. The system shall track the planned risk-reward ratio and report it in trade logs. The take-profit price must be validated to ensure it is achievable (e.g., not beyond reasonable bounds) and consistent with the strategy's exit logic.

`HARD` | Authority: DERIVED (original R-009, R-010) | Rationale: Take-profit locks in gains; risk-reward ratio is a core strategy parameter | Verify: Trade log inspection; verify take-profit price is consistent with risk-reward ratio | Accept: Every closed trade reports planned and realized risk-reward ratio | Status: NOT TESTED | Evidence: Fact Pack §3 (takeProfit field) | Fallback: If exchange-side TP is not supported, local monitoring is used; if local monitoring fails, position is closed at market | Regression: R-007, R-030

---

**R-009: Fee estimation in all calculations**

All profit/loss calculations, break-even calculations, and sizing calculations shall include fee estimates. The conservative default taker fee is 0.06% (SOURCE_VERIFIED per Fact Pack §7). The alternative 0.05% value (from original C6) is UNRESOLVED and shall be reported as sensitivity. Maker fee (0.02%) applies only if the order is confirmed as maker (POST_ONLY or limit that provides liquidity). The system must state which fee rate (maker or taker) is assumed in every calculation. Fee estimates must be included in the risk budget for each trade.

`HARD` | Authority: RATIFIED_FINDING (C6), Fact Pack §7 (SOURCE_VERIFIED 0.06%) | Rationale: Fees directly reduce profitability; conservative default prevents underestimation | Verify: Arithmetic check of fee-inclusive calculations | Accept: All PnL calculations include fees at 0.06% taker or stated maker rate | Status: NOT TESTED | Evidence: Fact Pack §7, original C6 | Fallback: If fee rate is unknown, use 0.06% (conservative) | Regression: R-003, R-011, R-012

---

**R-010: Spread estimation in cost model**

All cost calculations shall include a spread estimate. The spread is the difference between bid and ask at the time of order execution. Historical spread data is UNRESOLVED (C8: order-book depth is NON_REPRODUCIBLE). The design uses a PROVISIONAL spread estimate of 5 basis points for liquid pairs (BTC, ETH) and 10 basis points for less liquid pairs. This estimate must be validated during Phase 1 (research/backtest) using actual observed spreads. Spread must be included in the risk budget.

`HARD` | Authority: DERIVED (original R-013), Fact Pack §5 (depth endpoint exists) | Rationale: Spread is a real cost that reduces profitability | Verify: Phase 1 measurement of actual spread; compare to estimate | Accept: Measured spread is within 2× of estimate; otherwise estimate is updated | Status: PROVISIONAL | Evidence: C8 (NON_REPRODUCIBLE), Fact Pack §5 | Fallback: Use conservative estimate (10bp for all symbols); label all results as approximate | Regression: R-009, R-011

---

**R-011: Slippage estimation in cost model**

All cost calculations shall include a slippage estimate. Slippage is the difference between the expected fill price and the actual fill price. Historical slippage data is UNRESOLVED. The design uses a PROVISIONAL slippage estimate of 3 basis points for market orders on liquid pairs and 5 basis points for less liquid pairs. This must be validated during Phase 1. Slippage must be included in the risk budget.

`HARD` | Authority: DERIVED (original R-014) | Rationale: Slippage is a real cost especially during volatility | Verify: Phase 1 measurement; backtest comparison | Accept: Measured slippage is within 2× of estimate | Status: PROVISIONAL | Evidence: C8, general market microstructure knowledge | Fallback: Use conservative estimate (5bp for all); label results approximate | Regression: R-009, R-010

---

**R-012: Funding cost estimation and tail-risk treatment**

All holding-period cost calculations shall include funding-rate estimates. Standard funding settlement is every 8 hours (some contracts every 4 hours per Fact Pack §6). Expected funding cost in normal conditions: ~5 bp per 8-hour period (PROVISIONAL). However, funding rates are NOT guaranteed to be bounded — the observed ±2–3% caps (Fact Pack §6, PROVISIONAL) and the refuted ±24bp cap (C7) confirm that funding is a tail-risk input, not a capped cost. The cost model must include a stress scenario with funding at 200 bp per 8-hour period. The holding-period policy (R-032) must account for funding tail risk.

`HARD` | Authority: RATIFIED_FINDING (C7), Fact Pack §6 | Rationale: Funding is a real and potentially large cost for perpetual futures; treating it as bounded would underestimate risk | Verify: Stress-test calculation with 200bp funding; verify holding-period policy accounts for it | Accept: Holding-period policy limits exposure to funding risk; stress scenario is documented | Status: NOT TESTED | Evidence: C7, Fact Pack §6 | Fallback: Conservative holding period (shorter); funding stress included in risk budget | Regression: R-032, R-002

---

**R-013: Break-even calculation including all costs**

The system shall compute and report the break-even win rate for the configured risk-reward ratio, including all costs (fees, spread, slippage, funding). This calculation shall be presented in the strategy documentation and updated whenever cost parameters change. The break-even win rate must be communicated to the operator via the Telegram interface (CMD-xx: report command).

`HARD` | Authority: DERIVED (original R-011) | Rationale: Break-even win rate is a fundamental performance benchmark | Verify: Arithmetic check; compare to hand calculation | Accept: Break-even win rate is correctly computed and reported | Status: NOT TESTED | Evidence: General quantitative knowledge; Part 3 cost model | Fallback: If cost inputs are missing, compute with conservative values and label approximate | Regression: R-009, R-010, R-011, R-012

---

**R-014: Maximum peak-to-trough drawdown (15% of initial equity)**

The maximum permitted decline from peak equity to subsequent trough equity is 15% of INITIAL equity. The denominator is initial equity (the equity at the start of the trading program), NOT the prior peak. This is a hard limit. 20% is advisory context only and must never be used as the operative limit, a tolerated breach, an optimizer target, or a substitute for 15%. The equity measure includes realized and unrealized PnL, minus fees and funding. High-water-mark construction: track the highest equity value observed since program start. Measurement/update timing: after every fill, every mark-to-market update (at least every 60 seconds), and every reconciliation cycle. When peak-to-trough decline reaches 15% of initial equity, the system enters HALTED state: all risk-increasing activity is vetoed, and the operator must acknowledge and intervene.

`HARD` | Authority: OWNER_HARD (D-RISK-1) | Rationale: Owner hard limit; initial-equity denominator is explicitly specified and must not be silently replaced with prior-peak denominator | Verify: Simulation — create equity path with drawdown > 15% of initial; verify HALTED triggers | Accept: System halts when decline from peak reaches 15% of initial equity | Status: NOT TESTED | Evidence: D-RISK-1, supplemental §1.1 | Fallback: HALTED state; all risk-increasing actions blocked; risk-reducing actions allowed; operator alert | Regression: R-001, R-016, R-018, R-023

---

**R-015: Daily realized-loss veto (10% of equity)**

The maximum daily realized loss is 10% of equity. Upon reaching or breaching this threshold, the system must veto further risk-increasing activity until the end of that UTC day. Definitions: (a) UTC day boundary = 00:00:00 UTC; (b) daily reference equity = equity at 00:00:00 UTC (start of day) — DESIGN_JUDGMENT: use start-of-day equity as denominator since the owner did not specify more narrowly; this is conservative because equity may decline during the day, making 10% of start-of-day a tighter limit than 10% of current equity; (c) realized PnL = sum of closed-trade PnL (entry-to-exit) minus fees minus funding for the current UTC day; (d) the veto triggers when cumulative daily realized loss ≥ 10% × start-of-day equity; (e) the veto blocks risk-increasing actions but does NOT block risk-reducing actions (position close, stop-loss execution, cancel pending orders) per R-022; (f) reset occurs at the next 00:00:00 UTC boundary. Late-arriving exchange events (fills confirmed after the fact) are included in the day they occurred (trade date, not confirmation date) if determinable; if not determinable, included in the day received (conservative).

`HARD` | Authority: OWNER_HARD (D-RISK-5) | Rationale: Owner hard limit; conservative denominator definition chosen per D-RISK-5 guidance | Verify: Simulation — create realized losses exceeding 10% of start-of-day equity; verify veto | Accept: Risk-increasing actions are blocked for the remainder of the UTC day | Status: NOT TESTED | Evidence: D-RISK-5, supplemental §1.5 | Fallback: Veto active; risk-reducing actions still permitted; alert generated; reset at next UTC midnight | Regression: R-014, R-022, R-023

---

**R-016: Aggregate simultaneous risk ceiling (15% of equity)**

The sum of risk across all concurrently open positions AND all risk-increasing pending orders shall not exceed 15% of equity. This is a hard ceiling. Equity denominator: current equity (including unrealized PnL). Aggregation method: sum of per-position risk budgets (each computed per R-003) plus sum of per-pending-order risk reservations. No netting of offsetting positions is permitted unless a demonstrably valid risk model justifies it and the conservative gross measure still satisfies the limit. Pending orders, partially filled orders (full risk reserved for the unfilled portion), and multiple positions must be included. Concurrency control: a lock or optimistic concurrency check on the aggregate risk budget must prevent two simultaneous order submissions from each passing the individual check but together exceeding the limit. If aggregate risk cannot be computed reliably, no risk-increasing action is permitted.

`HARD` | Authority: OWNER_HARD (D-RISK-4) | Rationale: Owner hard limit; concurrency races could bypass individual checks without aggregate enforcement | Verify: Concurrency test — two simultaneous order requests; verify second is blocked if first consumes remaining budget | Accept: Aggregate risk never exceeds 15% of equity under any concurrency scenario | Status: NOT TESTED | Evidence: D-RISK-4, supplemental §1.4 | Fallback: Second order rejected; alert generated | Regression: R-001, R-002, R-014

---

**R-017: Position count limit**

The maximum number of concurrent open positions is configurable with a default of 3 (DESIGN_JUDGMENT: consistent with single-symbol focus and 15% aggregate risk). This limit is a safety mechanism to prevent excessive diversification that would make monitoring impractical on a single mobile device. The limit is checked before every new position entry. The count includes positions in any state (open, partially filled pending, etc.).

`HARD` | Authority: DERIVED (original R-017, R-026) | Rationale: Position count limit provides a simple, robust secondary control | Verify: Test — create 3 positions; verify 4th is rejected | Accept: No more than 3 concurrent positions exist | Status: NOT TESTED | Evidence: DESIGN_JUDGMENT | Fallback: New order rejected | Regression: R-016

---

**R-018: Consecutive-loss circuit breaker (RISK-LATCH-01)**

After 3 consecutive losing trades, per-trade risk shall be automatically reduced to 50% of the ceiling (i.e., 2.5% of current equity instead of 5%). After 5 consecutive losing trades, all risk-increasing activity shall be halted pending operator acknowledgement via Telegram. The counter resets after a winning trade. The latch state (count of consecutive losses, current risk level) shall be persisted in the risk state store and survive restarts. The operator acknowledgement must be explicit (a Telegram command) and generates an audit event.

`HARD` | Authority: DERIVED (forensic finding F-022, proposed in AV-06/AV-09) | Rationale: Losing streaks can cause large drawdowns before daily or drawdown limits trigger; this provides an earlier, independent circuit breaker | Verify: Simulation — 5 consecutive losses; verify halt triggers at loss 5 | Accept: After 3 losses, risk reduced; after 5, halted; counter resets on win | Status: NOT TESTED | Evidence: F-022 | Fallback: System halts risk-increasing actions; operator must acknowledge via CMD; risk-reducing actions allowed | Regression: R-002, R-014, R-015, R-023

---

**R-019: Gap-risk buffer in position sizing**

The effective stop distance used for position sizing shall include a 20% gap-risk buffer: d_effective = d_planned × 1.20. This means the planned stop distance (e.g., 100 bp) is the distance at which the stop triggers, but the sizing accounts for the possibility that the price gaps through the stop by up to 20% of the stop distance. This reduces the position size by approximately 16.7% compared to sizing without the buffer. The buffer is a DESIGN_JUDGMENT (based on general market microstructure knowledge of gap risk in perpetual futures during high volatility and low liquidity). It is not derived from Toobit-specific evidence.

`HARD` | Authority: DESIGN_JUDGMENT (forensic finding F-023) | Rationale: Price gaps through stops are a known risk; sizing must not assume guaranteed fill at stop price | Verify: Arithmetic check — verify sizing with buffer produces correct reduced notional | Accept: All sizing calculations use d_effective = d_planned × 1.20 | Status: NOT TESTED | Evidence: F-023, general market microstructure knowledge | Fallback: If gap buffer is considered too conservative by owner, it may be reduced but must remain > 0 | Regression: R-003, R-002

---

**R-020: markPrice / OI handling**

The system shall use Toobit's mark price for unrealized PnL calculation and liquidation monitoring where mark price is available. However, the semantics of markPrice and klines.change are CONFLICTED (C13, Fact Pack §5: mark-price kline endpoint exists but field semantics are unresolved). Therefore: (a) for entry/exit decisions, use lastPrice (trade price); (b) for unrealized PnL display, use markPrice if available, with lastPrice as fallback; (c) for liquidation monitoring, use markPrice if available (since exchanges typically use mark price for liquidation), with a conservative buffer if markPrice is unavailable; (d) any critical decision that depends on markPrice semantics shall be disabled until C13 is resolved. Open interest (OI) is UNRESOLVED (C26: historical OI availability not confirmed). Strategy S1 does not require OI; any OI-dependent feature is disabled.

`HARD` | Authority: RATIFIED_FINDING (C13 CONFLICTED, C26 UNRESOLVED), Fact Pack §5 | Rationale: Confirmed conflict in markPrice semantics prevents building critical decisions on unverified interpretation | Verify: If markPrice response sample is obtained, verify field semantics match design assumptions | Accept: PnL calculation works correctly with or without markPrice; no critical decision depends on unresolved markPrice semantics | Status: UNRESOLVED | Evidence: C13, C26, Fact Pack §5 | Fallback: Use lastPrice for all decisions; markPrice for display only; OI features disabled | Regression: R-006, R-008, R-038

---

**R-021: Risk-reducing action taxonomy (RISK-CLASS)**

Every action the system can take shall be classified into one of three categories: (a) RISK_INCREASING — new position entry, position size increase, leverage increase, pending order that would increase exposure; (b) RISK_REDUCING — position close (full or partial), stop-loss execution, cancel pending risk-increasing order, reduce leverage; (c) RISK_NEUTRAL — status queries, data updates, reconciliation, health checks, configuration reads. The classification must be explicit in the order-intent schema. Default classification for unclassifiable actions: RISK_INCREASING (fail-safe). The daily loss veto (R-015), drawdown halt (R-014), and consecutive-loss breaker (R-018) must block RISK_INCREASING actions but must NOT block RISK_REDUCING actions. RISK_NEUTRAL actions are always permitted.

`HARD` | Authority: OWNER_HARD (D-RISK-5, supplemental §7.3) | Rationale: Blocking risk-reducing actions during a veto would prevent the system from protecting itself; explicit taxonomy prevents accidental misclassification | Verify: Test — during daily veto, verify risk-reducing actions succeed and risk-increasing actions are blocked | Accept: Taxonomy correctly classifies all action types; vetoes respect the classification | Status: NOT TESTED | Evidence: D-RISK-5, supplemental §7.3 | Fallback: Unclassifiable action is treated as RISK_INCREASING (blocked during veto) | Regression: R-014, R-015, R-018

---

**R-022: Risk engine independence and non-overridability**

The risk engine (COMP-04) shall be the sole authority for risk decisions. No subsystem that forecasts, calibrates, optimizes, allocates capital, or handles Telegram input may override, bypass, or relax a risk check. The strategy engine generates signals (entry/exit intent); the risk engine approves or rejects. The Telegram command handler can request risk-reducing actions but cannot authorize risk-increasing actions that fail a risk check. Configuration changes to risk limits require operator action AND pass through the risk engine's validation. The six D-RISK limits are never tunable, learnable, or self-adjusting.

`HARD` | Authority: OWNER_HARD (D-RISK-2: "No optimizer... may relax this ceiling"; supplemental §7.3) | Rationale: Risk authority must be independent to prevent any component from creating uncontrolled exposure | Verify: Architecture review — verify no code path bypasses risk engine; penetration test of command handler | Accept: No path exists for any component to submit a risk-increasing order without risk engine approval | Status: NOT TESTED | Evidence: D-RISK-2, supplemental §7.3 | Fallback: Any attempt to bypass is logged and rejected | Regression: R-001, R-002, R-021

---

**R-023: Risk state mechanism (NORMAL / REDUCED / HALTED)**

The risk engine shall maintain a persistent risk state with three levels: NORMAL (all actions permitted within limits), REDUCED (per-trade risk reduced — e.g., after 3 consecutive losses per R-018, or during Telegram outage per R-060), HALTED (all risk-increasing actions blocked — e.g., drawdown limit reached, 5 consecutive losses, daily loss veto). State transitions are: NORMAL→REDUCED (automatic on trigger), REDUCED→HALTED (automatic on trigger), HALTED→NORMAL (requires operator acknowledgement via Telegram), REDUCED→NORMAL (automatic when trigger condition clears, or operator acknowledgement). State changes generate audit events. State persists across restarts.

`HARD` | Authority: DERIVED (original R-024, updated per D-RISK and forensic findings) | Rationale: Persistent risk state provides clear, auditable risk posture | Verify: State machine test — trigger each transition; verify persistence across restart | Accept: State transitions are correct and persistent | Status: NOT TESTED | Evidence: Original R-024 | Fallback: If risk state cannot be read, system is in HALTED state (fail safe) | Regression: R-014, R-015, R-018

---

**R-024: Risk input freshness and fail-closed behavior**

All risk calculations shall verify input freshness: equity value must be no older than 60 seconds; position data must be no older than 60 seconds; price data must be no older than 30 seconds. If any input is stale, missing, corrupt, or contradictory, risk-increasing actions are blocked (fail closed). This does not block risk-reducing actions (R-021). Freshness thresholds are DESIGN_JUDGMENT.

`HARD` | Authority: DESIGN_JUDGMENT (supplemental §7.3) | Rationale: Stale data could cause incorrect risk calculations; fail-closed prevents unsafe actions | Verify: Test — inject stale equity value; verify risk-increasing action is blocked | Accept: Stale inputs cause fail-closed behavior for risk-increasing actions | Status: NOT TESTED | Evidence: Supplemental §7.3 | Fallback: Risk-increasing action blocked; alert generated | Regression: R-022, R-023

---

**R-025: Equity measurement definition**

Equity for all risk calculations shall be defined as: equity = wallet_balance + unrealized_PnL, where wallet_balance = initial_deposits − realized_losses + realized_gains − fees − funding_costs (cumulative), and unrealized_PnL is computed from current positions using mark price (fallback: last price per R-020). The equity denominator for D-RISK-2 (per-trade) and D-RISK-4 (aggregate) is current equity. The equity denominator for D-RISK-1 (drawdown) is initial equity. The equity denominator for D-RISK-5 (daily loss) is start-of-day equity (per R-015). All three denominators must be tracked simultaneously.

`HARD` | Authority: D-RISK-1 (initial equity), D-RISK-2 (current equity), D-RISK-5 (start-of-day equity) | Rationale: Different risk limits use different denominators; ambiguity would cause incorrect enforcement | Verify: Unit test — verify each limit uses its correct denominator | Accept: Each risk limit uses its specified denominator | Status: NOT TESTED | Evidence: D-RISK-1, D-RISK-2, D-RISK-5 | Fallback: If equity cannot be computed, fail closed for risk-increasing actions | Regression: R-014, R-015, R-002, R-016

---

**R-026: Interactions among D-RISK limits**

The risk engine shall model and test the interactions among the six D-RISK limits. Specifically: (a) per-trade 5% × 3 concurrent positions = 15% = aggregate limit (D-RISK-4 exactly consumed by 3 max positions at max risk); (b) equity decline reduces current-equity-denominated limits (per-trade and aggregate shrink as equity drops); (c) daily realized-loss veto (10%) and total drawdown (15% of initial) interact: a single day can consume 2/3 of the total drawdown budget; (d) leverage 5× with 200 USDT equity = 1000 USDT gross exposure; (e) fees, funding, slippage, and gaps can cause realized losses to exceed modeled risk; (f) pending orders consume aggregate budget. These interactions must be tested in the verification matrix.

`HARD` | Authority: OWNER_HARD (supplemental §1.7) | Rationale: Owner explicitly requires interaction analysis; limits alone do not guarantee realized losses cannot exceed them | Verify: Simulation scenarios covering each interaction | Accept: All interaction scenarios are correctly handled | Status: NOT TESTED | Evidence: Supplemental §1.7 | Fallback: Conservative behavior (fail closed) in edge cases | Regression: R-001, R-002, R-004, R-014, R-015, R-016

---

### Domain 2: Capital Planning (R-027 – R-028)

---

**R-027: Planning equity (200 USDT)**

All design calculations, worked examples, sizing demonstrations, and capacity estimates shall use 200 USDT as the hard planning basis. This is a design-planning scale, not a statement of the owner's current account balance, not authorization to access an account, and not proof that any minimum order, strategy, fee structure, or deployment is feasible. All monetary quantities in USDT.

`HARD` | Authority: OWNER_HARD (D-RISK-3) | Rationale: Owner specified planning basis | Verify: All worked examples use 200 USDT | Accept: Every monetary example uses 200 USDT base | Status: NOT TESTED | Evidence: D-RISK-3 | Fallback: If 200 USDT is infeasible for a specific calculation (e.g., below minimum order size), mark UNRESOLVED | Regression: All monetary calculations

---

**R-028: Sensitivity analysis (100–500 USDT)**

The design shall include sensitivity analysis varying planning equity across 100–500 USDT for key calculations (position sizing, cost ratios, minimum viable equity). This analysis may vary genuinely uncertain model inputs (fees, slippage, etc.) but must never vary the six D-RISK hard limits as candidate values.

`SHOULD` | Authority: OWNER_HARD (D-RISK-3, supplemental §1.7) | Rationale: Owner specified range; sensitivity shows robustness of design across equity levels | Verify: Arithmetic walk at 100, 200, 350, 500 USDT | Accept: Sensitivity table shows key metrics across the range | Status: NOT TESTED | Evidence: D-RISK-3 | Fallback: If sensitivity cannot be computed for a metric, label accordingly | Regression: R-027

---

### Domain 3: Trading Strategy (R-029 – R-039)

---

**R-029: Strategy specification (S1: dual-timeframe trend/momentum)**

The strategy (S1) is a rule-based dual-timeframe trend/momentum system. Context timeframe (4h): EMA-20 vs EMA-50 crossover with slope confirmation over 3 bars determines the directional bias (LONG or SHORT). Entry timeframe (1h): EMA-9 vs EMA-21 crossover in the direction of the 4h bias, confirmed by RSI-14 (entry LONG when RSI > 50 and < 70; entry SHORT when RSI < 50 and > 30) and volume filter (current bar volume > 0.5 × 20-bar average). Exit: (a) take-profit at risk-reward ratio 1:2 (PAR-012), (b) stop-loss at PAR-011 distance, (c) time-based exit after 24 hours (R-032), (d) opposite signal exit. No-trade conditions: (a) 4h trend is flat (EMA-20 ≈ EMA-50 within 0.1%), (b) RSI is in extreme zone (> 70 for LONG, < 30 for SHORT), (c) volume is below the threshold, (d) any risk limit is active (HALTED/REDUCED), (e) data quality check fails.

`HARD` | Authority: DESIGN_JUDGMENT (strategy choice from original Part 4, O-01) | Rationale: Dual-timeframe trend/momentum is defensible for intraday perpetual futures; 2–4 parameters fit trial budget; rule-based (not ML) is appropriate for limited data | Verify: Backtest in Phase 1 (NOT TESTED in this engagement); manual walkthrough of signal logic | Accept: Strategy produces signals consistent with specified rules for known data inputs | Status: NOT TESTED | Evidence: Original Part 4 (O-01 selection) | Fallback: If strategy is unprofitable in backtest, evaluate S2 (mean-reversion) as alternative | Regression: R-030, R-031, R-032, R-033

---

**R-030: Entry conditions (precise specification)**

Entry conditions for LONG: (1) 4h EMA-20 > 4h EMA-50 AND the difference has been increasing for 3 consecutive 4h bars (P_slope_bars=3); (2) 1h EMA-9 crosses above 1h EMA-21 (within the current or most recent completed 1h bar); (3) RSI-14 on 1h is > 50 AND < 70; (4) current 1h bar volume > 0.5 × 20-bar average volume. Entry conditions for SHORT: mirror of LONG (4h EMA-20 < 4h EMA-50 with decreasing difference; 1h EMA-9 crosses below 1h EMA-21; RSI < 50 AND > 30; volume filter). All four conditions must be simultaneously true. Signal is evaluated at the close of each 1h bar. No lookahead: only data from completed bars is used.

`HARD` | Authority: DESIGN_JUDGMENT (PAR-001 through PAR-010) | Rationale: Precise, testable entry rules prevent ambiguity | Verify: Unit test with known data; lookahead test (R-043) | Accept: Entry signal is generated if and only if all four conditions are true | Status: NOT TESTED | Evidence: Part 7 (PAR definitions) | Fallback: If any condition is unverifiable (data gap), no signal is generated | Regression: R-029, R-043

---

**R-031: Exit conditions (precise specification)**

Exit conditions (any one triggers): (a) take-profit: price reaches entry ± (risk-reward ratio × stop distance) = entry ± 2 × d_planned; (b) stop-loss: price reaches entry ∓ d_planned; (c) time-based: position has been open for 24 hours (R-032); (d) opposite signal: a new entry signal in the opposite direction is generated; (e) risk-engine forced close: drawdown limit reached (R-014), daily loss limit reached (R-015), or operator command. Exit priority: stop-loss > take-profit > time-based > opposite signal > forced close. Stop-loss and take-profit may be exchange-side orders (per Fact Pack §3 fields) or local monitoring rules.

`HARD` | Authority: DESIGN_JUDGMENT (PAR-011, PAR-012, derived) | Rationale: Complete exit specification prevents positions from being held indefinitely | Verify: State machine test for each exit type | Accept: Each exit condition is correctly triggered by its respective scenario | Status: NOT TESTED | Evidence: Part 7 | Fallback: If exchange-side stop/TP fails, local monitoring; if local monitoring fails, market close | Regression: R-007, R-008, R-032

---

**R-032: Holding-duration policy (intraday operational definition)**

Intraday is operationally defined as: maximum holding period of 24 hours (3 funding periods at 8h intervals), or until an exit condition (R-031) triggers, whichever is first. Rationale: (a) 4h context timeframe implies positions lasting 1–3 bars (4–12 hours); (b) 3 funding periods limit funding tail risk (R-012); (c) 24h aligns with UTC day boundary for daily loss accounting (R-015); (d) longer holdings increase overnight gap risk. The 24-hour maximum is a DESIGN_JUDGMENT derived from the strategy's timeframe structure and the cost/risk model. It is not an arbitrary duration.

`HARD` | Authority: DESIGN_JUDGMENT (original A6 intraday intent, derived) | Rationale: Operational definition derived from strategy, costs, and risk per supplemental §2 item 6 | Verify: State machine test — position open 24h → forced exit | Accept: No position remains open for more than 24 hours | Status: NOT TESTED | Evidence: Original A6, cost model | Fallback: Time-based exit enforced by strategy engine; if strategy engine fails, health monitor triggers alert and risk engine forces close | Regression: R-031, R-012

---

**R-033: Strategy parameter bounds and register (16 fields)**

All strategy parameters (PAR-001 through PAR-012) shall be maintained in a parameter register with 16 fields per parameter (per original §8.6): (1) parameter ID; (2) name; (3) description; (4) default value; (5) minimum value; (6) maximum value; (7) step size; (8) unit; (9) sensitivity class (LOW/MEDIUM/HIGH); (10) overfitting risk (LOW/MEDIUM/HIGH); (11) current value; (12) optimization status (FIXED/TUNABLE); (13) last-changed timestamp; (14) changed-by (operator/system); (15) rationale for current value; (16) validation status. The six D-RISK limits are NOT in this register and are NOT tunable (R-022). Tunable parameters may be adjusted within their bounds by the operator, not by autonomous optimization.

`HARD` | Authority: DERIVED (original §8.6, R-033) | Rationale: Parameter register provides traceability and prevents uncontrolled parameter changes | Verify: Register inspection; verify all 16 fields populated for each parameter | Accept: All 12 parameters have 16 fields; no D-RISK limit is in the register | Status: NOT TESTED | Evidence: Original §8.6 | Fallback: If register is incomplete, parameter changes are blocked | Regression: R-029, R-034

---

**R-034: Parameter selection procedure with overfitting test**

The parameter selection procedure shall use coordinate descent within the C23/C24 trial budget (N_max_effective = min(20, 10) = 10 trials). Selection must include an overfitting test using the Benjamini-Hochberg procedure at FDR=0.10 applied to all trial results. If no configuration passes BH correction, the parameter set is UNRESOLVED and the data window must be expanded or the strategy is declared unsuitable. The selection procedure must include: (a) selection criterion (e.g., risk-adjusted return); (b) training period; (c) validation method; (d) overfitting test (BH correction); (e) holdout sample (R-035); (f) trial count; (g) rejected configurations and reasons.

`HARD` | Authority: DERIVED (original §8.4, forensic finding F-029) | Rationale: Without overfitting correction, 10 trials on limited data can select noise | Verify: Procedure documentation review; arithmetic check of BH correction | Accept: Selection procedure includes all 7 fields; BH correction is applied | Status: NOT TESTED | Evidence: C23, C24, F-029 | Fallback: If BH correction rejects all configurations, declare strategy UNRESOLVED for this data | Regression: R-033, R-035, R-085

---

**R-035: Holdout sample for out-of-sample validation**

The most recent 20% of available data shall be reserved as a holdout sample and excluded from parameter selection. After selection, the chosen parameters are validated on the holdout. If holdout Sharpe ratio < 0.5 × training Sharpe ratio, the parameter set is UNRESOLVED and overfitting is suspected. The holdout fraction (20%) is a DESIGN_JUDGMENT (common practice in quantitative finance; general knowledge).

`HARD` | Authority: DESIGN_JUDGMENT (forensic finding F-028) | Rationale: Without holdout, no independent validation of selected parameters exists | Verify: Check that holdout data is excluded from selection; verify holdout validation is performed | Accept: Holdout is reserved and used for validation only | Status: NOT TESTED | Evidence: F-028, general quantitative knowledge | Fallback: If insufficient data for holdout (e.g., < 50 total samples), declare backtest results PROVISIONAL | Regression: R-034

---

**R-036: Stationarity check on training data**

Before parameter selection, the Augmented Dickey-Fuller (ADF) test shall be applied to the training data returns. If p-value > 0.05, the stationarity assumption is violated. Mitigation: (a) apply first-differencing to the return series, or (b) use a rolling-window approach for parameter estimation. The test result and mitigation action shall be documented.

`SHOULD` | Authority: DESIGN_JUDGMENT (forensic finding F-027) | Rationale: Financial returns exhibit non-stationarity; Sharpe ratio and related statistics assume stationarity | Verify: ADF test execution on training data | Accept: ADF test is performed and documented; mitigation applied if needed | Status: NOT TESTED | Evidence: F-027, general statistical knowledge | Fallback: If ADF cannot be computed (no code execution in this engagement), specify the test for Phase 1 execution | Regression: R-034

---

**R-037: Survivorship bias check on historical data**

Before backtesting, verify that the historical data includes delisted or inactive symbols if the universe has changed. If the data only includes currently active symbols, document the survivorship bias risk and treat backtest results as potentially optimistic. This is a documentation and labeling requirement; the data itself may not be correctable.

`SHOULD` | Authority: DESIGN_JUDGMENT (forensic finding F-026) | Rationale: Survivorship bias inflates backtest performance | Verify: Data source documentation review; ask data provider about delisted symbols | Accept: Survivorship bias risk is documented; results labeled accordingly | Status: UNRESOLVED | Evidence: F-026; Fact Pack §10 (symbol list is partial) | Fallback: Label all backtest results as "subject to survivorship bias" | Regression: R-038

---

**R-038: Correlation risk awareness in aggregate risk**

For systems trading multiple symbols, the aggregate risk calculation (R-016) shall account for correlation between positions. If two symbols have correlation > 0.7 (measured over 30 days of returns), apply a correlation multiplier of 1.5× to the combined risk of those positions when computing aggregate risk. This is a DESIGN_JUDGMENT (conservative adjustment for correlated exposures). For single-symbol trading (initial deployment), this requirement is active but not triggered (only one symbol at a time).

`SHOULD` | Authority: DESIGN_JUDGMENT (forensic finding F-030) | Rationale: Correlated positions can amplify losses beyond the sum of individual risks | Verify: Unit test with correlated symbols; verify multiplier is applied | Accept: Aggregate risk uses correlation-adjusted values for correlated symbols | Status: NOT TESTED | Evidence: F-030, general portfolio theory | Fallback: Use gross sum (no correlation adjustment) — conservative in the direction of counting more risk | Regression: R-016

---

**R-039: Multi-testing correction in trial evaluation**

All trial results in the parameter selection procedure (R-034) shall be subject to multiple-testing correction (Benjamini-Hochberg at FDR=0.10). The correction is applied across all trials in the selection run. The E[max(SR)] noise floor calculation (Part 3) provides a complementary check: the selected strategy's Sharpe ratio must exceed the noise floor for the trial count and sample size.

`HARD` | Authority: DERIVED (original C23/C24, supplemental §2 item 12) | Rationale: Without correction, trial selection inflates apparent performance | Verify: Arithmetic check of BH correction; comparison to noise floor | Accept: Selected strategy exceeds noise floor after correction | Status: NOT TESTED | Evidence: C23, C24 | Fallback: If selected strategy does not exceed noise floor, declare UNRESOLVED | Regression: R-034

---

### Domain 4: Data (R-040 – R-050)

---

**R-040: Data source and ingestion (Toobit REST + WebSocket)**

Market data shall be ingested from Toobit's public API: REST endpoints for historical klines (`GET /quote/v1/klines`, `GET /quote/v1/markPrice/klines`, `GET /quote/v1/index/klines`), depth (`GET /quote/v1/depth`), 24hr ticker (`GET /quote/v1/ticker/24hr`), and funding rates (`GET /api/v1/futures/fundingRate`, `GET /api/v1/futures/historyFundingRate`); WebSocket streams for real-time kline updates (`kline_$interval`), trade stream, depth, mark price, and index price. Historical kline retrieval uses the conservative 1,000-candle limit per request (Fact Pack §5: two figures observed, 1000 and 2000; use conservative 1000). WebSocket heartbeat: client sends `{"ping": <timestamp>}` every 60 seconds; server responds `{"pong": <timestamp>}`; server disconnects within 5 minutes if no ping (Fact Pack §11).

`HARD` | Authority: SOURCE_VERIFIED (Fact Pack §5, §11), RATIFIED_FINDING (C1, C2) | Rationale: Toobit is the sole live venue; data ingestion must use documented endpoints | Verify: API contract review; heartbeat test in Phase 2 | Accept: Data flows from Toobit REST/WS into the data store | Status: NOT TESTED | Evidence: Fact Pack §5, §11 | Fallback: If REST is unavailable, use WS-only (with gap repair); if WS disconnects, REST polling fallback | Regression: R-041, R-044, R-045

---

**R-041: Cross-venue data firewall (architectural enforcement)**

Cross-venue data shall be tagged at ingestion with source metadata (venue identifier, timestamp, data type). A data firewall component shall prevent cross-venue tagged data from entering Paper or Live decision paths. This is an architectural control, not a documentation note. The firewall shall be enforced at the data-access layer: the strategy engine's data-access interface shall reject any data record tagged as cross-venue when the operating mode is Paper or Live. Cross-venue data is accessible only in Research mode (Phase 1). Source-tag lineage shall be preserved end-to-end.

`HARD` | Authority: OWNER_HARD (supplemental §2 item 5, original A5) | Rationale: Owner explicitly requires architectural enforcement, not documentation-only | Verify: Architecture review; test that cross-venue data is rejected in Paper/Live mode | Accept: No cross-venue data reaches strategy engine in Paper or Live mode | Status: NOT TESTED | Evidence: Supplemental §2 item 5 | Fallback: If firewall cannot be implemented, Paper/Live modes use Toobit-only data by construction (no cross-venue data in the store) | Regression: R-040, R-062, R-063

---

**R-042: Data quality rules (15 rules, DQ-01 through DQ-15)**

Data quality shall be enforced per the 15 DQ rules defined in the data design (Part 6 of the revised package). Categories: completeness (gap detection, staleness, required fields, schema version), validity (OHLCV sanity, timestamp monotonicity, alignment, funding bounds, precision, price positivity, volume non-negative), consistency (cross-timeframe, SQLite/JSONL match, position reconstruction). Each rule has an enforcement point (ingestion, query, or periodic check) and a violation response (reject record, flag, or alert).

`HARD` | Authority: DERIVED (original R-032, data design Part 6) | Rationale: Bad data leads to bad decisions; quality rules prevent garbage-in | Verify: DQ rule test suite; data profiling | Accept: All 15 rules are implemented and tested | Status: NOT TESTED | Evidence: Part 6 data design | Fallback: Data that violates quality rules is quarantined; strategy operates on quality-filtered data | Regression: R-040, R-043

---

**R-043: Lookahead bias prevention**

Every signal decision shall use only data with timestamp strictly ≤ the decision timestamp. This must be enforced architecturally (data-access layer filters by timestamp) and verified by a dedicated lookahead test. The test constructs a scenario where lookahead bias would produce a different signal (e.g., using the close of bar N to make a decision at the open of bar N+1) and verifies the system produces the correct no-lookahead result. The lookahead boundary is: a signal evaluated at the close of bar N may use data from bars 0 through N (inclusive) but not bar N+1 or later.

`HARD` | Authority: DESIGN_JUDGMENT (forensic finding F-024, supplemental Pass E item 6) | Rationale: Lookahead bias invalidates all backtest results and would cause different live behavior | Verify: Dedicated lookahead unit test | Accept: No signal uses data from after its decision timestamp | Status: NOT TESTED | Evidence: F-024 | Fallback: If lookahead cannot be prevented architecturally, add timestamp assertion at signal generation | Regression: R-030, R-042

---

**R-044: WebSocket heartbeat and disconnect detection**

The WebSocket client shall send a heartbeat ping every 60 seconds (Fact Pack §11: server disconnects within 5 minutes if no ping). The client shall detect disconnects within 30 seconds (by monitoring pong responses). On disconnect: (a) mark the data feed as STALE; (b) attempt reconnection with exponential backoff (1s, 2s, 4s, 8s, 16s, 30s max); (c) after successful reconnection, resubscribe to all topics and repair data gaps using REST; (d) until gap repair is complete, mark affected data as PROVISIONAL. Duplicate message handling: deduplicate by (symbol, interval, open_time) for klines.

`HARD` | Authority: SOURCE_VERIFIED (Fact Pack §11) | Rationale: Without heartbeat, WS connection dies silently; without disconnect detection, data goes stale without warning | Verify: WS connection test — suppress ping, verify disconnect is detected | Accept: Heartbeat sends every 60s; disconnect detected within 30s; reconnection and gap repair work | Status: NOT TESTED | Evidence: Fact Pack §11 | Fallback: REST polling fallback while WS is disconnected | Regression: R-040, R-045

---

**R-045: Stale-feed detection and behavior**

The system shall detect stale market data feeds. Thresholds (DESIGN_JUDGMENT): kline data stale if no update for 2× the expected interval (e.g., 2 hours for 1h kline); trade data stale if no update for 5 minutes; ticker data stale if no update for 2 minutes. When a feed is stale: (a) mark the affected data as STALE; (b) generate an alert; (c) if the stale feed affects entry/exit decisions, block new risk-increasing actions until the feed is fresh; (d) risk-reducing actions (stops, closes) continue to operate using last-known data with a widened safety margin.

`HARD` | Authority: DESIGN_JUDGMENT (forensic finding F-011, supplemental Pass E item 4) | Rationale: Acting on stale data can produce incorrect signals and orders | Verify: Staleness injection test | Accept: Stale feeds trigger alerts and block risk-increasing actions | Status: NOT TESTED | Evidence: F-011 | Fallback: Risk-increasing blocked; risk-reducing allowed with margin | Regression: R-040, R-044, R-024

---

**R-046: Per-symbol contract specification discovery at startup**

At startup, the system shall fetch per-symbol contract specifications from `GET /api/v1/exchangeInfo` (public, no auth required). These include: minQty, stepSize, tickSize, maxLeverage, contractMultiplier, and margin mode. The system shall validate all order construction against these specifications. No trade shall be designed around invented filters. The specification data is cached locally and refreshed periodically (every 24 hours or on exchangeInfo update notification).

`HARD` | Authority: SOURCE_VERIFIED (Fact Pack §9), supplemental §6 item 8 | Rationale: Per-symbol filters are required for correct order construction; they are not in the Fact Pack and must be fetched at runtime | Verify: Startup sequence test; verify exchangeInfo is fetched and parsed | Accept: System has per-symbol specifications before any order is constructed | Status: NOT TESTED | Evidence: Fact Pack §9 | Fallback: If exchangeInfo is unavailable, system does not trade (fail closed) | Regression: R-003, R-047

---

**R-047: Symbol format handling (futures vs spot)**

Futures symbols use the format `XXX-SWAP-USDT` (e.g., `BTC-SWAP-USDT`). Spot symbols use `XXXUSDT` (e.g., `BTCUSDT`). The system shall use a canonical internal instrument identity with an explicit mapping to the venue-specific symbol. No code path shall assume a single symbol format across spot and futures. All order construction uses futures format.

`HARD` | Authority: SOURCE_VERIFIED (Fact Pack §3), forensic finding F-004 | Rationale: Using wrong symbol format causes API errors or spot/futures confusion | Verify: Unit test — verify all API calls use correct symbol format | Accept: All futures API calls use `XXX-SWAP-USDT` format | Status: NOT TESTED | Evidence: Fact Pack §3 | Fallback: If symbol mapping is ambiguous, the order is rejected (fail closed) | Regression: R-040, R-047, R-046

---

**R-048: Conservative rate-limit accounting**

The system shall implement conservative fixed-weight rate limiting as the safe baseline. REQUEST_WEIGHT: 3,000 weight per 1 minute (Fact Pack §2). ORDERS: 60 order requests per 2 seconds. Endpoint weights: track cumulative weight per minute and per-2-second order count. The limiter must work without response headers. Header-derived delta tracking (`X-Api-Limit-Status`, `X-Api-Limit`, `X-Api-Limit-Reset-Timestamp`) is an optional enhancement only if headers are observed at runtime. If rate limit is approached (80% of budget), the system shall throttle non-essential API calls. On HTTP 429 or error code -1003/-1015: back off and retry after the indicated reset period.

`HARD` | Authority: SOURCE_VERIFIED (Fact Pack §2), RATIFIED_FINDING (C4), supplemental §3.3 | Rationale: Rate-limit violations cause 429 or account penalties; conservative baseline works regardless of header presence | Verify: Rate-limit tracking unit test; simulate 429 response | Accept: Rate limiter prevents exceeding documented limits | Status: NOT TESTED | Evidence: Fact Pack §2, C4 | Fallback: Conservative fixed-weight accounting (no header dependency) | Regression: R-040, R-047

---

**R-049: Timeframe capability ceiling (14 timeframes)**

The ratified capability ceiling is 14 timeframes (C1, RATIFIED_FINDING), including 3m and 8h which are not in the WebSocket extracted list (Fact Pack §5: 11 intervals shown). The design records the DOC_CONFLICT (original C1 says 14; Fact Pack WS shows 11) and proceeds with the C1 list as the ceiling. REST may support more intervals than WS. The system shall discover available intervals at runtime and gracefully handle requests for unsupported intervals. The 3 active timeframes used by strategy S1 (1h, 4h, 1d) are within both the ratified ceiling and the WS extracted list.

`HARD` | Authority: RATIFIED_FINDING (C1), Fact Pack §5 (DOC_CONFLICT) | Rationale: Ratified finding wins per precedence rules; conflict is recorded but does not reduce the ceiling | Verify: Runtime interval discovery; verify 1h, 4h, 1d are available | Accept: System can fetch data for 1h, 4h, and 1d intervals | Status: PROVISIONAL (C1 ratified; availability of 3m and 8h untested) | Evidence: C1, Fact Pack §5 | Fallback: If an interval is unavailable, system uses the nearest available interval | Regression: R-040

---

**R-050: Data-gap treatment**

For gaps ≤ 2 consecutive bars in historical data: forward-fill OHLCV from the last available bar (with volume=0). For gaps > 2 bars: exclude the affected period from backtesting and document the exclusion. For live data gaps: use REST fallback to retrieve missing bars; if REST also fails, mark the period as MISSING and block signal generation for the affected interval. Treatment rules must be applied consistently in both backtest and live modes.

`HARD` | Authority: DESIGN_JUDGMENT (forensic finding F-032) | Rationale: Gaps in data can create false signals or miss real signals | Verify: Gap injection test — remove bars, verify treatment is applied correctly | Accept: Gaps are handled per specified rules; no false signals from gap artifacts | Status: NOT TESTED | Evidence: F-032 | Fallback: Exclude gap-affected periods; label results accordingly | Regression: R-042, R-043

---

### Domain 5: Execution / OMS (R-051 – R-062)

---

**R-051: Order construction (v2 endpoint)**

All new orders shall use `POST /api/v2/futures/order` (weight 1). Mandatory fields: `symbol`, `side` (BUY/SELL), `positionSide` (LONG/SHORT), `type` (LIMIT/MARKET), `newClientOrderId`, `timestamp`. Quantity: `quantity` (contracts) or `valueQuantity` (USDT notional), at least one non-zero. TimeInForce: GTC (default), FOK, IOC, or POST_ONLY. Conditional fields: `price` (required for LIMIT), `stopPrice`, `takeProfit`, `stopLoss`, `tpTriggerBy`/`slTriggerBy` (CONTRACT_PRICE or MARK_PRICE), `tpOrderType`/`slOrderType` (MARKET or LIMIT), `stopOrderType` (TAKE_PROFIT/STOP_LOSS), `stopType` (FIXED_STOP/TRAILING_STOP). The system must not send fields not listed in the Fact Pack. Field values must match the Fact Pack exactly (e.g., side is BUY or SELL, not B or S).

`HARD` | Authority: SOURCE_VERIFIED (Fact Pack §3) | Rationale: Incorrect order construction causes API errors or incorrect orders | Verify: Order construction unit test; mock API response verification | Accept: All order requests include required fields with correct values | Status: NOT TESTED | Evidence: Fact Pack §3 | Fallback: If a required field value is uncertain, the order is not sent (fail closed) | Regression: R-046, R-052, R-053

---

**R-052: Order submission durability (write-ahead logging)**

Before sending any order to Toobit, the system shall write a durable log entry containing: (a) order intent (symbol, side, type, quantity, price if LIMIT); (b) clientOrderId; (c) risk reservation (amount of aggregate risk budget consumed); (d) action classification (RISK_INCREASING / RISK_REDUCING per R-021); (e) timestamp. This log entry must be flushed to persistent storage BEFORE the API request is sent. After sending, the API response (or timeout) is logged. On crash recovery, any logged-but-unacknowledged orders are placed in UNKNOWN state and reconciled (R-055). The durability guarantee: no order can exist on the exchange without a corresponding local log entry.

`HARD` | Authority: OWNER_HARD (supplemental §7.4, forensic finding F-016) | Rationale: Without write-ahead logging, a crash between API call and local record creates untracked exposure | Verify: Crash simulation — kill process between write-ahead log and API response; verify recovery finds the order | Accept: No untracked orders after crash recovery | Status: NOT TESTED | Evidence: Supplemental §7.4, F-016 | Fallback: If write-ahead log cannot be written, the order is not sent (fail closed) | Regression: R-053, R-055, R-056

---

**R-053: Order tracking state machine (local states + exchange states)**

The order state machine shall maintain a clear separation between: (a) Toobit-confirmed exchange states — only NEW and CANCELED are confirmed (Fact Pack §3); (b) UNRESOLVED exchange states — PARTIALLY_FILLED, FILLED, REJECTED, EXPIRED are likely but not confirmed in extracted docs; (c) Local internal states — SUBMITTING, UNKNOWN, RECONCILING, CLOSED_LOCALLY, and others as needed. Local states must be explicitly labeled as local abstractions, not Toobit response enums. The state machine shall use at least 11 states (S0–S10 equivalent) and handle all transitions. If a response contains an unrecognized status value, the order enters UNKNOWN state and is reconciled.

`HARD` | Authority: SOURCE_VERIFIED (Fact Pack §3: only NEW and CANCELED), forensic finding F-005 | Rationale: Building on assumed status enums could cause incorrect transitions if Toobit uses different values | Verify: State machine completeness test; mock responses with unknown status values | Accept: State machine handles NEW and CANCELED correctly; unknown statuses trigger UNKNOWN → reconcile | Status: NOT TESTED | Evidence: Fact Pack §3, F-005 | Fallback: Unknown status → UNKNOWN state → reconcile → determine actual state | Regression: R-052, R-055, R-056

---

**R-054: clientOrderId management**

Client order IDs shall use the parameter names `newClientOrderId` (creation) and `origClientOrderId` (lookup/cancel) per Fact Pack §3. Character set: `[A-Za-z0-9_-]` (C11, RATIFIED_FINDING). Uniqueness scope: UNRESOLVED (per-account vs per-symbol); the system assumes per-account (weakest scope) and enforces local uniqueness. Format: `{strategy_id}-{timestamp_ms}-{sequence}` (e.g., `S1-1700000000000-001`). IDs must NEVER be reused after an ambiguous outcome (UNKNOWN state). Local ID registry persists across restarts.

`HARD` | Authority: SOURCE_VERIFIED (Fact Pack §3), RATIFIED_FINDING (C11) | Rationale: Duplicate IDs could cause order confusion; reuse after ambiguity could cause incorrect cancels | Verify: ID format test; uniqueness test; no-reuse-after-ambiguity test | Accept: All IDs are unique, correctly formatted, and never reused after ambiguity | Status: NOT TESTED | Evidence: Fact Pack §3, C11 | Fallback: If ID generation fails, order is not sent | Regression: R-051, R-052, R-056

---

**R-055: Reconciliation engine**

The reconciliation engine (COMP-07) shall periodically (every 5 minutes, configurable) compare local order and position state with Toobit's actual state. Reconciliation query: `GET /api/v2/futures/order` (or equivalent) for open orders; `GET /api/v1/futures/positions` for positions (weight 8.35). Reconciliation steps: (1) query exchange for all open orders and positions; (2) compare with local state; (3) for discrepancies: if exchange has an order not in local log, adopt it (assign local state from exchange state); if local has an order not on exchange, investigate (may have been filled or cancelled); (4) log all discrepancies; (5) generate alerts for material discrepancies. Reconciliation also resolves UNKNOWN-state orders (R-053). Discrepancy resolution is automated where possible and flagged for operator review where not.

`HARD` | Authority: DERIVED (original R-021, R-023), Fact Pack §3 | Rationale: Local state and exchange state can diverge due to crashes, network issues, or partial fills | Verify: Reconciliation test with injected discrepancies | Accept: All discrepancies are detected and resolved or escalated | Status: NOT TESTED | Evidence: Fact Pack §3 | Fallback: If reconciliation fails (API unreachable), alert operator; after 3 consecutive failures, risk state → REDUCED | Regression: R-053, R-052, R-023

---

**R-056: Ambiguous outcome handling (5XX, timeout, network error)**

A 5XX response, timeout, or ambiguous failure does NOT prove that an order was rejected. The system shall: (a) place the order in UNKNOWN state; (b) NOT resubmit automatically (no blind resubmission); (c) initiate reconciliation to determine the actual order state; (d) maintain a "pending exposure" reservation (the risk budget remains consumed during the UNKNOWN period); (e) retry eligibility: only after reconciliation confirms the order was not received by the exchange; (f) retry limit: maximum 1 retry per order intent; (g) if reconciliation cannot determine the state within 15 minutes, alert the operator and keep the UNKNOWN state until resolved. The incomplete negative-error catalog (Fact Pack §4) means the system must not branch on specific error codes for state transitions (except the confirmed -1003, -1015, -2011).

`HARD` | Authority: SOURCE_VERIFIED (Fact Pack §4: 5XX = UNKNOWN), supplemental §6 item 5, forensic finding F-037 | Rationale: Treating 5XX as rejection could cause duplicate orders; blind resubmission creates double exposure | Verify: Inject 5XX response; verify UNKNOWN state, no resubmit, reconciliation triggers | Accept: Ambiguous outcomes result in UNKNOWN → reconcile → resolve | Status: NOT TESTED | Evidence: Fact Pack §4, F-037 | Fallback: UNKNOWN state persists until resolved; risk budget remains reserved | Regression: R-052, R-053, R-055

---

**R-057: Amend restriction (LIMIT only)**

Order amendment is permitted only for LIMIT orders (Fact Pack §3: "LIMIT only; amend price/quantity by orderId or origClientOrderId"). The system shall not attempt to amend MARKET orders. For MARKET orders, the only modification is cancellation. Amend uses `POST /api/v2/futures/order/update` (weight 2). The state machine must reflect the LIMIT-only amend restriction.

`HARD` | Authority: SOURCE_VERIFIED (Fact Pack §3), forensic finding F-008 | Rationale: Attempting to amend a MARKET order would cause an API error | Verify: State machine test — attempt to amend MARKET order; verify rejection | Accept: Amend is only attempted on LIMIT orders | Status: NOT TESTED | Evidence: Fact Pack §3 | Fallback: If amend is needed for a MARKET order, cancel and resubmit (which creates UNKNOWN-state risk per R-056) | Regression: R-051, R-053

---

**R-058: Cancel operation and identity rules**

Cancel uses `DELETE /api/v2/futures/order` (weight 1). Identification: by `orderId` or `origClientOrderId` (mutually exclusive per Fact Pack §3). The system shall use `origClientOrderId` as the primary identifier (since it is generated locally and known before the exchange assigns `orderId`). If `orderId` is known (from a prior response), it may be used. After cancel request: the order enters CANCELLING state (local) until the exchange confirms with CANCELED status. If cancel times out or returns ambiguous response: UNKNOWN state → reconcile (R-056).

`HARD` | Authority: SOURCE_VERIFIED (Fact Pack §3) | Rationale: Cancel identity rules must be followed exactly; ambiguous cancel creates uncertainty | Verify: Cancel test with both orderId and origClientOrderId | Accept: Cancel works correctly with either identifier; ambiguous cancel triggers reconcile | Status: NOT TESTED | Evidence: Fact Pack §3 | Fallback: Ambiguous cancel → UNKNOWN → reconcile | Regression: R-054, R-056

---

**R-059: Partial-fill handling and re-submission**

When an order is partially filled and then cancelled (or expires), the remaining quantity shall be handled as follows: (a) for RISK_INCREASING orders: do NOT automatically resubmit; the risk engine evaluates whether to resubmit (budget may have changed); (b) for RISK_REDUCING orders: automatically resubmit a new order for the remaining quantity (new clientOrderId). This is a new state transition (T21 in the revised state machine). Partial fill tracking: `executedQty` vs `origQty` from order response (Fact Pack §3).

`HARD` | Authority: DESIGN_JUDGMENT (forensic finding F-031) | Rationale: Risk-reducing orders must complete to protect positions; risk-increasing resubmission must go through risk engine | Verify: Partial-fill simulation — fill 50%, cancel remainder, verify re-submission behavior | Accept: Risk-reducing remainder is resubmitted; risk-increasing remainder goes through risk engine | Status: NOT TESTED | Evidence: F-031 | Fallback: If resubmission fails, alert operator | Regression: R-051, R-053, R-021

---

**R-060: TimeInForce selection**

The system shall select TimeInForce based on order purpose: (a) entry orders (LIMIT): GTC (default) — the order rests until filled or cancelled; (b) exit orders (stop-loss, take-profit): GTC if exchange-side; (c) emergency closes: IOC (immediate-or-cancel) — fill what is available immediately, cancel the rest; (d) maker-only entries (if desired): POST_ONLY — ensures the order provides liquidity and incurs maker fee (0.02%). The selection must be explicit in order construction. The system shall not use FOK (fill-or-kill) for the initial implementation (DESIGN_JUDGMENT: IOC is sufficient; FOK adds complexity without material benefit for the system's order sizes).

`HARD` | Authority: SOURCE_VERIFIED (Fact Pack §3), DESIGN_JUDGMENT | Rationale: TimeInForce affects fill probability and cost; wrong selection can leave unfilled protective orders | Verify: Order construction test with each TimeInForce type | Accept: Each order type uses the specified TimeInForce | Status: NOT TESTED | Evidence: Fact Pack §3 | Fallback: Default to GTC if TimeInForce is unspecified | Regression: R-051

---

**R-061: positionSide (LONG/SHORT) mapping**

All orders shall include `positionSide` (LONG or SHORT) per Fact Pack §3. Mapping: (a) entry LONG → side=BUY, positionSide=LONG; (b) entry SHORT → side=SELL, positionSide=SHORT; (c) close LONG → side=SELL, positionSide=LONG; (d) close SHORT → side=BUY, positionSide=SHORT. This mapping must be correct in both one-way and hedge mode (if hedge mode is supported — UNRESOLVED per Fact Pack §9). The system shall default to one-way mode unless hedge mode is confirmed available.

`HARD` | Authority: SOURCE_VERIFIED (Fact Pack §3), forensic finding F-040 | Rationale: Incorrect positionSide mapping would open a position in the wrong direction | Verify: Order construction test for all four cases | Accept: positionSide is correctly mapped for all order types | Status: NOT TESTED | Evidence: Fact Pack §3 | Fallback: If position mode is uncertain, default to one-way mode | Regression: R-051

---

**R-062: ExchangeInfo filter validation before order submission**

Before every order submission, the system shall validate the order against the per-symbol filters obtained from exchangeInfo (R-046): quantity ≥ minQty, quantity is a multiple of stepSize, price (if LIMIT) is a multiple of tickSize, quantity within maxQty bounds. If validation fails, the order is adjusted (rounded to valid values) or rejected. No order shall be submitted that violates exchange filters.

`HARD` | Authority: SOURCE_VERIFIED (Fact Pack §9: exchangeInfo exists), supplemental §6 item 8 | Rationale: Orders violating exchange filters are rejected, wasting API calls and potentially missing entries | Verify: Order validation test with known filters | Accept: All submitted orders pass filter validation | Status: NOT TESTED | Evidence: Fact Pack §9 | Fallback: Order rejected; sizing recalculated with adjusted values | Regression: R-046, R-051, R-003

---

### Domain 6: Telegram Interface (R-063 – R-068)

---

**R-063: Telegram authentication (chat_id binding)**

The Telegram bot shall accept commands only from the authorized chat_id. All other senders shall be ignored (no response, no error — silent drop to prevent information leakage). The chat_id is stored in the configuration and is not changeable via Telegram command (requires file edit + restart). The bot token is stored securely (R-071).

`HARD` | Authority: DERIVED (original R-036, A2) | Rationale: Only the authorized operator should control the system | Verify: Send command from unauthorized chat_id; verify silent drop | Accept: No unauthorized command is processed | Status: NOT TESTED | Evidence: Original R-036 | Fallback: Unauthorized commands are silently dropped and logged | Regression: R-064, R-071

---

**R-064: Telegram command catalog (20 commands)**

The bot shall support 20 commands (CMD-01 through CMD-20) covering: status, positions, orders, equity, PnL, risk state, start/stop trading, close position, close all, set mode (Paper/Live), set parameter, get parameter, get config, set config, get alerts, acknowledge alert, get report, get health, backup status, and help. Each command has a defined syntax, preconditions, response format, and error handling. Commands are documented in a command catalog (Part 9).

`HARD` | Authority: DERIVED (original R-044, A2) | Rationale: Telegram is the sole operator interface; commands must cover all operational needs | Verify: Command catalog review; test each command | Accept: All 20 commands work correctly | Status: NOT TESTED | Evidence: Original Part 9 (CMD catalog) | Fallback: Unknown commands return help message | Regression: R-063, R-065

---

**R-065: Confirmation protocol for dangerous commands**

Dangerous commands (close all positions, set mode to Live, set leverage, change risk parameters, delete backup, force reconciliation, reset risk state) require two-step confirmation: (1) operator issues the command; (2) bot responds with a confirmation request including the exact action to be performed; (3) operator sends a confirmation token (e.g., "CONFIRM 1234" where 1234 is a random token generated by the bot); (4) bot executes the action. If the confirmation is not received within 60 seconds, the action is cancelled. Dangerous commands generate audit events.

`HARD` | Authority: DERIVED (original Part 9, supplemental §2 item 10) | Rationale: Dangerous commands must not be executed accidentally | Verify: Test each dangerous command without confirmation; verify rejection | Accept: Dangerous commands require valid two-step confirmation | Status: NOT TESTED | Evidence: Original Part 9 | Fallback: No confirmation → action cancelled; audit event generated | Regression: R-064

---

**R-066: Telegram outage behavior**

If Telegram is unreachable for > 15 minutes: (a) the risk state transitions to REDUCED (per-trade risk reduced by 50%); (b) the system continues trading with reduced risk; (c) alerts are queued in the notification store (COMP-13) for delivery when Telegram recovers. If Telegram is unreachable for > 60 minutes: (a) the risk state transitions to HALTED; (b) all risk-increasing actions are blocked; (c) existing positions remain open with their protective orders active; (d) no new positions are opened. Telegram recovery: deliver queued notifications, transition risk state back to NORMAL (or REDUCED if other triggers are active).

`HARD` | Authority: DESIGN_JUDGMENT (forensic finding F-033, supplemental §2 item 9) | Rationale: Operator must retain control; if operator is unreachable, system must degrade safely | Verify: Simulate Telegram outage; verify risk-state transitions | Accept: Risk state transitions correctly at 15min and 60min thresholds | Status: NOT TESTED | Evidence: F-033, supplemental §2 item 9 | Fallback: HALTED at 60min; operator resumes control on recovery | Regression: R-023, R-064

---

**R-067: Command audit logging**

Every Telegram command (received, processed, or rejected) shall be logged with: timestamp (UTC), chat_id, command text, processing result (success/failure/refused), and any resulting state changes. Logs are append-only (SCH-11b). Logs are retained indefinitely.

`HARD` | Authority: DERIVED (original R-047) | Rationale: Audit trail for operator actions | Verify: Log inspection after command execution | Accept: All commands are logged | Status: NOT TESTED | Evidence: Original R-047 | Fallback: If logging fails, command is rejected (fail closed for dangerous commands) | Regression: R-063, R-064

---

**R-068: Notification delivery and queuing**

Notifications (alerts, status updates, reports) shall be delivered via Telegram. If Telegram is unavailable, notifications are queued in COMP-13 (notification store) with timestamps. On Telegram recovery, queued notifications are delivered in order. Notification priority: CRITICAL (immediate), HIGH (immediate), MEDIUM (within 5 minutes), LOW (batched hourly). Maximum queue size: 1000 notifications; older notifications are dropped if the queue overflows (oldest-first drop with summary).

`HARD` | Authority: DERIVED (original R-045) | Rationale: Operator must receive critical information; queuing prevents data loss during outages | Verify: Queue test — fill queue, verify overflow behavior | Accept: Notifications are delivered or queued correctly | Status: NOT TESTED | Evidence: Original R-045 | Fallback: Queue overflow drops oldest; CRITICAL alerts always delivered first | Regression: R-066

---

### Domain 7: Paper/Live Mode (R-069 – R-078)

---

**R-069: Paper mode simulation (no real orders)**

Paper mode shall simulate trading without submitting any real orders to Toobit. Paper mode: (a) reads real market data from Toobit (public endpoints, no auth required); (b) generates signals using the same strategy engine as Live mode; (c) simulates order fills using current market prices with configurable slippage/latency simulation; (d) maintains a simulated portfolio (equity, positions, PnL) separate from any real portfolio; (e) NEVER calls authenticated Toobit endpoints for order placement, cancellation, or account modification; (f) Paper mode's data access interface does not include Toobit order-placement endpoints. Cross-venue data may be used in Paper mode ONLY if tagged and filtered per R-041 — but the default is Toobit-only data in Paper mode.

`HARD` | Authority: OWNER_HARD (supplemental §7.5) | Rationale: Paper mode must not accidentally submit real orders | Verify: Code path review — verify no Paper-mode code reaches Toobit order endpoints | Accept: Zero real orders submitted in Paper mode | Status: NOT TESTED | Evidence: Supplemental §7.5 | Fallback: If mode is uncertain, assume Paper mode (no real orders) | Regression: R-041, R-070, R-071

---

**R-070: Live mode configuration and separation**

Live mode shall use a completely separate configuration namespace from Paper mode (separate config files, separate state stores, separate logs). Switching to Live mode: (a) requires operator command via Telegram (CMD-xx: set mode); (b) requires all six interlocks to pass (R-072 through R-077); (c) generates an audit event; (d) the mode switch is a transactional operation — either all changes apply atomically or none do. In Live mode, cross-venue research data is NEVER accessible to decision paths (R-041).

`HARD` | Authority: OWNER_HARD (supplemental §7.5) | Rationale: Configuration contamination between Paper and Live could cause real orders during testing | Verify: Configuration isolation test | Accept: Paper and Live configurations are completely separate | Status: NOT TESTED | Evidence: Supplemental §7.5 | Fallback: If mode separation is uncertain, default to Paper mode | Regression: R-069, R-072–R-077

---

**R-071: Mode-switch transaction**

The Paper→Live or Live→Paper switch shall be transactional: (a) close all open Paper positions (simulated close at current market price); (b) cancel all pending Paper orders; (c) update the mode flag; (d) load the target mode's configuration; (e) verify all six interlocks (for Live); (f) generate audit event; (g) notify operator via Telegram. If any step fails, the switch is rolled back to the previous mode. The switch must be explicitly requested by the operator (not automatic).

`HARD` | Authority: OWNER_HARD (supplemental §7.5) | Rationale: Partial mode switch creates inconsistent state | Verify: Mode-switch test with injected failure at each step | Accept: Mode switch is atomic; failure causes rollback | Status: NOT TESTED | Evidence: Supplemental §7.5 | Fallback: Failed switch → stay in current mode; alert operator | Regression: R-069, R-070

---

**R-072: Live interlock 1 — Data validity**

Before entering Live mode and before every risk-increasing action in Live mode, verify: (a) all required data feeds are active and fresh (per R-045 staleness thresholds); (b) no data quality violations (DQ rules pass); (c) the latest kline data is within 2× the expected interval. If any data validity check fails, the interlock blocks Live entry / risk-increasing action.

`HARD` | Authority: OWNER_HARD (supplemental §2 item 10) | Rationale: Trading on invalid data creates incorrect signals | Verify: Interlock test — inject stale data; verify block | Accept: Interlock blocks when data is invalid | Status: NOT TESTED | Evidence: Supplemental §2 item 10 | Fallback: Block Live entry / risk-increasing action | Regression: R-042, R-045

---

**R-073: Live interlock 2 — Exchange/internal-state reconciliation**

Before entering Live mode and periodically during Live operation (every 5 minutes), verify that local state (orders, positions) matches Toobit's actual state. If there are unresolved discrepancies, the interlock blocks Live entry / risk-increasing action until reconciliation resolves them.

`HARD` | Authority: OWNER_HARD (supplemental §2 item 10) | Rationale: Unreconciled state means the system does not know its actual exposure | Verify: Inject state discrepancy; verify block | Accept: Interlock blocks when state is unreconciled | Status: NOT TESTED | Evidence: Supplemental §2 item 10 | Fallback: Block; alert operator | Regression: R-055

---

**R-074: Live interlock 3 — All hard risk limits verified**

Before entering Live mode, verify that: (a) all six D-RISK limits are correctly configured in the risk-policy catalog; (b) the risk engine is operational and has validated its inputs; (c) no risk limit is currently in breach; (d) the risk state is NORMAL (not HALTED or REDUCED). If any check fails, the interlock blocks Live entry.

`HARD` | Authority: OWNER_HARD (supplemental §2 item 10) | Rationale: Entering Live with misconfigured risk limits is dangerous | Verify: Interlock test with misconfigured limit; verify block | Accept: Interlock blocks when risk limits are not verified | Status: NOT TESTED | Evidence: Supplemental §2 item 10 | Fallback: Block | Regression: R-001

---

**R-075: Live interlock 4 — Credential and permission validity**

Before entering Live mode, verify: (a) API credentials are present and non-empty; (b) credentials pass an authentication check (read-only endpoint call); (c) the API key does NOT have withdrawal permission (minimum privilege per R-079); (d) the API key has not expired. If any check fails, the interlock blocks Live entry.

`HARD` | Authority: OWNER_HARD (supplemental §2 item 10) | Rationale: Invalid credentials cause order failures; excessive permissions create security risk | Verify: Interlock test with invalid credentials; verify block | Accept: Interlock blocks when credentials are invalid | Status: NOT TESTED | Evidence: Supplemental §2 item 10 | Fallback: Block | Regression: R-079

---

**R-076: Live interlock 5 — Configuration integrity**

Before entering Live mode, verify: (a) the configuration file passes schema validation; (b) the configuration hash matches the last-approved hash (stored in config history SCH-12); (c) no configuration parameters are outside their valid ranges; (d) the D-RISK limits in the configuration match the canonical risk-policy catalog exactly. If any check fails, the interlock blocks Live entry.

`HARD` | Authority: OWNER_HARD (supplemental §2 item 10) | Rationale: Tampered or corrupted configuration could disable safety limits | Verify: Config hash check; schema validation | Accept: Interlock blocks when config integrity fails | Status: NOT TESTED | Evidence: Supplemental §2 item 10 | Fallback: Block | Regression: R-083

---

**R-077: Live interlock 6 — Clock validity**

Before entering Live mode, verify: (a) the system clock is synchronized with an authoritative time source (NTP or exchange server time); (b) clock skew is < 1000 ms (Fact Pack §1: max future clock skew 1000 ms); (c) the timestamp being sent in API calls will not be rejected. If any check fails, the interlock blocks Live entry.

`HARD` | Authority: OWNER_HARD (supplemental §2 item 10), Fact Pack §1 | Rationale: Clock skew causes API timestamp rejection; wrong timestamps corrupt logs and daily accounting | Verify: Clock sync check; skew measurement | Accept: Interlock blocks when clock is invalid | Status: NOT TESTED | Evidence: Supplemental §2 item 10, Fact Pack §1 | Fallback: Block; attempt NTP resync | Regression: R-082

---

**R-078: Paper/Live selector without wait or profit hurdle**

The operator may select Paper or Live through Telegram at any time without any arbitrary elapsed-time requirement or profitability/performance hurdle. This is confirmed by the supplemental directive (§0.2). The six interlocks (R-072 through R-077) remain mandatory and non-bypassable. There is no "minimum paper trading days" requirement and no "minimum profitability" requirement.

`HARD` | Authority: OWNER_HARD (supplemental §0.2) | Rationale: Owner explicitly confirmed no wait/profitability requirement | Verify: Confirm no such requirement exists in the design | Accept: Operator can switch modes at will (subject to interlocks) | Status: NOT TESTED | Evidence: Supplemental §0.2 | Fallback: N/A | Regression: R-069, R-070

---

### Domain 8: Security (R-079 – R-082)

---

**R-079: Credential management and minimum privilege**

API credentials shall be managed per R-CRED-01 through R-CRED-07: (1) credentials stored in encrypted configuration, not in code; (2) never logged or transmitted over insecure channels; (3) rotation procedure documented; (4) minimum privilege enforced — the API key must NOT have withdrawal permission; (5) the API key should have only futures trading permission (not spot, not margin); (6) credentials are accessible only to the execution engine (COMP-06), not to the bot process; (7) credential changes require restart and re-authentication.

`HARD` | Authority: DERIVED (original R-046, R-CRED-01–07) | Rationale: Credential compromise is the highest-severity security risk | Verify: Credential lifecycle test; permission check | Accept: Credentials are secure, minimum-privilege, and properly managed | Status: NOT TESTED | Evidence: Original Part 10 | Fallback: If credentials are compromised, revoke immediately and rotate | Regression: R-075, R-080

---

**R-080: HMAC-SHA256 signing implementation**

API request signing shall use HMAC-SHA256 with the following parameters (Fact Pack §1): API key header `X-BB-APIKEY`, signature in lowercase hex, timestamp in milliseconds, recvWindow default 5000 ms (max 60000 ms). The signing implementation must match the documented specification exactly. The full canonicalization and signing details beyond what the Fact Pack records must NOT be invented; any uncertainty is UNRESOLVED and must be resolved by obtaining the official signing documentation (NOT INSPECTED IN THIS DIRECT-MODE ENGAGEMENT).

`HARD` | Authority: SOURCE_VERIFIED (Fact Pack §1) | Rationale: Incorrect signing causes authentication failures (-2015) | Verify: Signing unit test against known test vectors (if available) | Accept: Signed requests pass authentication | Status: PROVISIONAL (signing method known; full canonicalization details partially unresolved) | Evidence: Fact Pack §1 | Fallback: If signing is uncertain, system does not attempt authenticated calls until resolved | Regression: R-079

---

**R-081: Secret lifecycle (creation, storage, rotation, revocation)**

Secrets (API keys, bot tokens) shall follow a documented lifecycle: (1) creation: generated on Toobit / Telegram with minimum permissions; (2) storage: encrypted at rest on the device; (3) access: only by the component that needs them (engine for API keys, bot for Telegram token); (4) rotation: documented procedure, performed on schedule or on suspected compromise; (5) revocation: immediate on compromise, with new key generation; (6) audit: all secret access and changes are logged (without logging the secret values themselves).

`HARD` | Authority: DERIVED (original Part 10) | Rationale: Unmanaged secrets are the primary attack vector | Verify: Secret lifecycle documentation review | Accept: All lifecycle stages are documented and implemented | Status: NOT TESTED | Evidence: Original Part 10 | Fallback: If lifecycle cannot be followed, system does not start (fail closed) | Regression: R-079

---

**R-082: Security audit logging**

All security-relevant events shall be logged: authentication attempts (success/failure), permission checks, credential access, configuration changes, mode changes, and risk-limit changes. Logs are append-only and retained indefinitely. Security logs are separate from operational logs (SCH-11).

`HARD` | Authority: DERIVED (original R-047) | Rationale: Security events must be traceable for incident response | Verify: Log inspection | Accept: All security events are logged | Status: NOT TESTED | Evidence: Original Part 10 | Fallback: If security logging fails, authenticated actions are blocked | Regression: R-079, R-082

---

### Domain 9: Deployment (R-083 – R-087)

---

**R-083: Compute feasibility measurement (C16)**

Before Phase 2, the sustained-runtime capability of the reference device (POCO X6) shall be measured (C16: NOT MEASURED). Measurements required: (a) continuous Python process CPU usage over 24 hours; (b) memory usage; (c) battery drain per hour; (d) thermal throttling behavior; (e) Android process-kill behavior (background/foreground). This is a BLOCKED item in this engagement (requires physical device access). The design proceeds with the understanding that the phone may not sustain 24/7 operation and includes D3 (cloud) as a fallback topology.

`HARD` | Authority: RATIFIED_FINDING (C16 UNRESOLVED), original R-043 | Rationale: Sustained runtime is the binding constraint for mobile deployment | Verify: Physical device measurement (BLOCKED in this engagement) | Accept: Measured values are within the deployment envelope or migration to D3 is triggered | Status: BLOCKED | Evidence: C16 | Fallback: If phone cannot sustain 24/7, migrate to D3 (cloud) per objective criteria | Regression: R-084

---

**R-084: Deployment topology selection (D15 envelope-first)**

Deployment topology shall be selected per the D15 envelope-first process: (1) derive compute/storage/latency needs from the strategy; (2) measure the device (C16); (3) match needs to capabilities; (4) enumerate ALL feasible topologies before compromise; (5) apply the owner's compromise order. The revised design will enumerate all feasible topologies in Part 4 (clean-sheet) and Part 9 (deployment analysis). Objective transition criteria (from previous design, retained): battery drain > 20%/hour → D3; uptime < 95% → D3; battery ≤ 5%/hour AND uptime ≥ 99% → stay D1.

`HARD` | Authority: OWNER_HARD (original D15, supplemental §2 item 8) | Rationale: POCO X6 is a feasibility constraint, not an architecture driver | Verify: Topology comparison with criteria; objective transition thresholds | Accept: Topology is selected based on envelope-first process, not convenience | Status: NOT TESTED | Evidence: Original D15 | Fallback: If phone is infeasible, use D3 (cloud) | Regression: R-083

---

**R-085: Android foreground service (process persistence)**

The engine process shall use Android's foreground service mechanism (via Termux) to reduce the probability of the OS killing the process. If the process is killed despite this: (a) the Telegram bot (running in a separate process) detects the engine's death via heartbeat failure; (b) an alert is generated; (c) the bot attempts to restart the engine; (d) if restart fails, the operator is notified. This is a SHOULD requirement because foreground service behavior is device/OS-specific and may not fully prevent process kills.

`SHOULD` | Authority: DESIGN_JUDGMENT (forensic finding F-034) | Rationale: Android aggressively kills background processes; foreground service mitigates this | Verify: Process-kill test on POCO X6 | Accept: Engine survives typical background-kill scenarios | Status: NOT TESTED | Evidence: F-034, general Android knowledge | Fallback: Bot detects death and alerts operator | Regression: R-083

---

**R-086: Battery monitoring and proactive migration**

The system shall monitor battery level and charge status. If battery health (maximum capacity) drops below 80% of original (indicating degradation), proactively recommend migration to D3. If battery level drops below 20% while on battery power (not charging), generate a warning alert. If battery level drops below 10%, risk state → REDUCED.

`SHOULD` | Authority: DESIGN_JUDGMENT (forensic finding F-035) | Rationale: Battery degradation reduces runtime over time; proactive migration prevents failure | Verify: Battery monitoring test | Accept: Battery alerts are generated at specified thresholds | Status: NOT TESTED | Evidence: F-035 | Fallback: Conservative migration to D3 | Regression: R-083, R-084

---

**R-087: Operating system update validation**

Before applying an Android OS update, verify Termux compatibility (check community resources or test in sandbox). If incompatible, defer the update and migrate to D3 first. Document the update and any compatibility findings.

`SHOULD` | Authority: DESIGN_JUDGMENT (forensic finding F-036) | Rationale: OS updates can break Termux, stopping the engine | Verify: Pre-update validation checklist | Accept: No OS update is applied without compatibility check | Status: NOT TESTED | Evidence: F-036 | Fallback: Defer update; migrate to D3 | Regression: R-083

---

### Domain 10: Operations (R-088 – R-095)

---

**R-088: Health monitoring (12 checks)**

The system shall implement 12 health checks (HC-01 through HC-12): process liveness, data feed freshness, API connectivity, WebSocket connectivity, disk space, memory usage, CPU usage, battery level, clock sync, Telegram connectivity, reconciliation status, and risk engine status. Each check runs at a defined interval and generates alerts on failure. Health checks are independent of the trading logic and continue even when trading is halted.

`HARD` | Authority: DERIVED (original R-041) | Rationale: Health monitoring detects failures before they affect trading | Verify: Health check test — inject each failure | Accept: All 12 checks detect their respective failures | Status: NOT TESTED | Evidence: Original Part 10 | Fallback: Failed check generates alert; affected functionality degrades gracefully | Regression: R-089

---

**R-089: Alert delivery (30 alert types)**

The system shall support 30 alert types (AL-01 through AL-30) with priorities (CRITICAL, HIGH, MEDIUM, LOW) and delivery mechanisms (Telegram notification, log entry). Alerts cover: data issues, execution issues, risk limit breaches, security events, system health, reconciliation discrepancies, configuration changes, and mode changes.

`HARD` | Authority: DERIVED (original Part 10) | Rationale: Operator must be informed of all material events | Verify: Alert test — trigger each alert type | Accept: All 30 alerts are generated and delivered correctly | Status: NOT TESTED | Evidence: Original Part 10 | Fallback: If delivery fails, alert is queued (R-068) | Regression: R-068

---

**R-090: Backup and recovery**

The system shall implement 5 backup types (configuration, data store, audit logs, state store, credentials reference) with automated scheduling. 3 recovery scenarios shall be specified: (a) device loss (full restore from backup); (b) data corruption (selective restore); (c) credential compromise (rotate and restore). Recovery procedures are documented in runbooks (RB-01 through RB-08).

`HARD` | Authority: DERIVED (original R-042) | Rationale: Data loss or corruption must be recoverable | Verify: Backup/restore test | Accept: Backups are created and restorable | Status: NOT TESTED | Evidence: Original Part 10 | Fallback: If backup fails, alert operator | Regression: R-079, R-082

---

**R-091: UTC time compliance**

All timestamps in computation, storage, logs, alerts, reports, scheduling, exchange communication, and audit events shall be in UTC. Elapsed deadlines use monotonic time (to avoid clock-adjustment issues). Timestamps sent to Toobit use milliseconds per Fact Pack §1. The system clock must be synchronized with an authoritative time source. Clock skew must be < 1000 ms (Fact Pack §1: server rejects timestamps > serverTime + 1000 ms).

`HARD` | Authority: OWNER_HARD (original A3), Fact Pack §1 | Rationale: UTC is authoritative for all time-based operations; clock skew causes API rejection | Verify: Timestamp inspection; clock skew measurement | Accept: All timestamps are UTC; skew < 1000 ms | Status: NOT TESTED | Evidence: Original A3, Fact Pack §1 | Fallback: If clock is not synchronized, interlock 6 (R-077) blocks Live mode | Regression: R-077, R-015

---

**R-092: Configuration management (schema + validation + history)**

Configuration shall be managed in JSON files with schema validation (14 validation rules from original Part 10). Configuration changes are tracked in SCH-12 (config history JSONL) with timestamps, change descriptions, and who-changed. Configuration is validated before use (interlock 5, R-076). Risk limits in configuration must match the canonical risk-policy catalog exactly (R-001).

`HARD` | Authority: DERIVED (original R-040) | Rationale: Configuration errors can disable safety mechanisms | Verify: Schema validation; config history review | Accept: All config changes are validated and tracked | Status: NOT TESTED | Evidence: Original Part 10 | Fallback: Invalid configuration → system does not start | Regression: R-076

---

**R-093: Audit logging (append-only, indefinite retention)**

All material events shall be logged in append-only logs: orders (SCH-07), fills (SCH-08), positions (SCH-09), risk decisions (SCH-06), signals (SCH-05), reconciliation (SCH-10), alerts (SCH-11), configuration changes (SCH-12), and security events (R-082). Logs are retained indefinitely. Logs use JSONL format (append-only, one JSON object per line) or SQLite where relational queries are needed.

`HARD` | Authority: DERIVED (original R-047, R-048) | Rationale: Audit trail is required for debugging, compliance, and post-incident analysis | Verify: Log inspection; append-only verification (no modifications) | Accept: All events are logged; logs are append-only | Status: NOT TESTED | Evidence: Original Part 6 (SCH schemas) | Fallback: If logging fails, critical actions are blocked (fail closed for risk-increasing) | Regression: R-082

---

**R-094: Performance metrics (9 metrics)**

The system shall track 9 performance metrics: (1) signal latency (bar close to signal generated); (2) order submission latency (signal to API call); (3) fill latency (API call to fill confirmation); (4) reconciliation duration; (5) API call rate (vs rate limit budget); (6) data freshness (time since last update per feed); (7) uptime; (8) memory usage; (9) battery drain rate. Metrics are reported in the daily report (CMD-xx).

`SHOULD` | Authority: DERIVED (original Part 10) | Rationale: Performance monitoring identifies degradation early | Verify: Metrics collection test | Accept: All 9 metrics are collected and reported | Status: NOT TESTED | Evidence: Original Part 10 | Fallback: If metric collection fails, continue trading (non-blocking) | Regression: R-088

---

**R-095: SLO / RTO / RPO design targets (not measured)**

Design targets (NOT measured, NOT benchmarked in this engagement): SLO — 99% uptime during trading hours; RTO — 30 minutes (time to recover from process death); RPO — 5 minutes (maximum data loss on crash). These are DESIGN_JUDGMENT targets. They are not represented as measured results. They will be validated during Phase 3 (paper trading).

`SHOULD` | Authority: DESIGN_JUDGMENT | Rationale: SLO/RTO/RPO provide operational targets even if not yet measured | Verify: Phase 3 paper trading measurement | Accept: Measured values meet or exceed targets | Status: NOT TESTED (design targets only) | Evidence: DESIGN_JUDGMENT | Fallback: If targets are not met, topology migration (D3) is considered | Regression: R-084

---

### Domain 11: Statistical / Research (R-096 – R-098)

---

**R-096: Trial budget compliance (C23 / C24)**

The parameter selection trial budget shall comply with C23 (10–20 trials at 4h timeframe, PROVISIONAL) and C24 (exhaustive grid search is inadmissible at timeframes ≤ 12h). N_max_effective = min(published_max, recomputed_max) = min(20, 10) = 10. No exhaustive permutation search is permitted. The selection procedure must be structured (coordinate descent) rather than random search.

`HARD` | Authority: RATIFIED_FINDING (C23, C24) | Rationale: Exhaustive search on limited data guarantees overfitting | Verify: Trial count in selection procedure documentation | Accept: Total trials ≤ 10; no exhaustive search | Status: NOT TESTED | Evidence: C23, C24 | Fallback: If more trials are needed, the strategy is declared UNRESOLVED for the available data | Regression: R-034, R-039

---

**R-097: Statistical framework (5 formulas)**

The design shall use the statistical framework from the original Part 3: (1) Sharpe ratio; (2) Sortino ratio; (3) maximum drawdown; (4) E[max(SR)] noise floor; (5) MinTRL (minimum track record length). All calculations are parametric where risk values are uncertain (D17). Formulas are documented with units and assumptions.

`HARD` | Authority: DERIVED (original Part 3) | Rationale: Statistical framework provides objective evaluation criteria | Verify: Arithmetic reproduction of each formula | Accept: All formulas are correctly documented and computed | Status: NOT TESTED | Evidence: Original Part 3 | Fallback: N/A | Regression: R-034, R-039

---

**R-098: Cross-venue data restriction (research/backtest only)**

Cross-venue data (any data source other than Toobit) shall be restricted to research and historical backtesting. It must NOT be accessible to Paper or Live data, decision, or execution paths. This is enforced architecturally (R-041) with source-tag lineage. Even if a venue might satisfy broader conditions (e.g., sufficient liquidity), this restriction is binding.

`HARD` | Authority: OWNER_HARD (supplemental §0.2, §2 item 5) | Rationale: Owner explicitly restricts cross-venue to research/backtest only | Verify: Data path analysis; verify no cross-venue data in Paper/Live | Accept: Zero cross-venue data in Paper/Live paths | Status: NOT TESTED | Evidence: Supplemental §0.2 | Fallback: Cross-venue data is physically not loaded in Paper/Live modes | Regression: R-041, R-069

---

### Domain 12: System Architecture (R-099 – R-102)

---

**R-099: Process isolation (engine + bot)**

The system shall run as two separate processes: the trading engine (COMP-01 through COMP-09) and the Telegram bot (COMP-10 through COMP-13). The trust boundary: the bot process does not have access to API credentials; the engine process does not have access to the Telegram bot token. Communication between processes is via a message-passing interface (Unix domain socket or equivalent) with length-prefixed JSON messages. No shared mutable state between processes.

`HARD` | Authority: DERIVED (original T2 architecture, R-036 trust boundary) | Rationale: Process isolation limits the blast radius of a compromise | Verify: Architecture review; verify no shared state | Accept: Two separate processes with message-passing communication | Status: NOT TESTED | Evidence: Original Part 5 | Fallback: If process isolation cannot be maintained, single-process mode with enhanced logging | Regression: R-063, R-079

---

**R-100: Durable logging and crash recovery**

All logs shall be flushed to persistent storage (filesystem) at defined intervals: order events (immediate flush), fill events (immediate), risk decisions (immediate), signals (within 1 second), health checks (within 5 seconds). On crash recovery: (1) read persistent state (risk state, position state, order log); (2) reconcile with exchange (R-055); (3) resume operations in a safe state (HALTED until reconciliation confirms clean state).

`HARD` | Authority: DESIGN_JUDGMENT (supplemental §7.4) | Rationale: Without durable logging, crash recovery cannot determine system state | Verify: Crash simulation — kill process; verify recovery from logs | Accept: System recovers to safe state after crash | Status: NOT TESTED | Evidence: Supplemental §7.4 | Fallback: HALTED until reconciliation | Regression: R-052, R-055

---

**R-101: Single canonical catalog for all identifiers**

Every identifier used in more than one place (requirements, components, schemas, parameters, states, transitions, commands, alerts, health checks, runbooks, tests, artifacts) shall appear in exactly one canonical catalog section. No dangling references. No duplicate definitions. Cross-references are verified in the final consistency check (Pass H).

`HARD` | Authority: DERIVED (original §5 identifier integrity, supplemental §10 item 3) | Rationale: Identifier integrity prevents confusion and errors in implementation | Verify: Cross-reference check — every identifier defined exactly once | Accept: Zero dangling or duplicate definitions | Status: NOT TESTED | Evidence: Original §5 | Fallback: N/A (this is a documentation quality requirement) | Regression: All

---

**R-102: No external verification claims (Direct-mode honesty)**

The design package shall not claim that any external source was inspected, any URL was opened, any API was called, any test was executed, or any measurement was performed in this engagement. Fact Pack `SOURCE_VERIFIED` status is described as supplied-source status, not independent verification. All test results are `NOT TESTED`. All measurements are `BLOCKED` or `NOT TESTED`. The offline pre-review checkpoint is labeled as such (not as an externally researched checkpoint).

`HARD` | Authority: OWNER_HARD (supplemental §0.3 rules 5, 8, 10) | Rationale: False verification claims would undermine the integrity of the entire design package | Verify: Design package review — verify no false claims | Accept: Zero false verification claims | Status: NOT TESTED | Evidence: Supplemental §0.3 | Fallback: N/A | Regression: All

---

## 2C. Original-to-Revised Mapping

| Original | Revised | Change type |
|---|---|---|
| R-001 (per-trade risk PENDING) | R-002 (5% ceiling) | UPDATED by D-RISK-2 |
| R-002 (sizing formula) | R-003 (sizing + contract multiplier) | UPDATED by F-007 |
| R-003 (sizing validation) | R-003 (integrated) | MERGED into R-003 |
| R-004 (leverage cap PENDING) | R-004 (5× ceiling, gross) | UPDATED by D-RISK-6 |
| R-005 (notional) | R-005 (notional + margin + precision) | UPDATED |
| R-006 (margin) | R-005 (integrated) | MERGED |
| R-007 (liquidation) | R-006 (liquidation awareness) | UPDATED |
| R-008 (stop-loss) | R-007 (stop-loss + exchange support) | UPDATED |
| R-009 (take-profit) | R-008 (TP + risk-reward) | MERGED with R-010 |
| R-010 (risk-reward) | R-008 (integrated) | MERGED |
| R-011 (break-even) | R-013 (break-even + costs) | RENUMBERED |
| R-012 (fees) | R-009 (fees + 0.06% default) | UPDATED |
| R-013 (spread) | R-010 (spread + provisional) | RENUMBERED |
| R-014 (slippage) | R-011 (slippage + provisional) | RENUMBERED |
| R-015 (drawdown PENDING) | R-014 (15% initial equity) | UPDATED by D-RISK-1 |
| R-016 (daily loss PENDING) | R-015 (10% + definitions) | UPDATED by D-RISK-5 |
| R-017 (position count) | R-017 (position count, default 3) | RETAINED |
| R-018 (symbol universe) | Part 4/6 (D14 derivation) | MOVED to architecture |
| R-019 (data source) | R-040 (data source + Fact Pack) | UPDATED |
| R-020 (markPrice/OI) | R-020 (markPrice/OI + conflicts) | UPDATED |
| R-021 (reconciliation) | R-055 (reconciliation + Fact Pack) | UPDATED |
| R-022 (timestamps) | R-091 (UTC + clock skew) | UPDATED |
| R-023 (position reconstruction) | R-055 (integrated) | MERGED |
| R-024 (risk state) | R-023 (risk state + persistence) | UPDATED |
| R-025 (aggregate risk PENDING) | R-016 (15% + concurrency) | UPDATED by D-RISK-4 |
| R-026 (position limit) | R-017 (integrated) | MERGED |
| R-027 (UTC) | R-091 (integrated) | MERGED |
| R-028 (signal) | R-029 (strategy + signals) | UPDATED |
| R-029 (entry) | R-030 (entry + precise spec) | UPDATED |
| R-030 (exit) | R-031 (exit + precise spec) | UPDATED |
| R-031 (no-trade) | R-029 (integrated) | MERGED |
| R-032 (data quality) | R-042 (DQ rules) | RETAINED |
| R-033 (order construction) | R-051 (v2 endpoint + fields) | UPDATED by Fact Pack |
| R-034 (order submission) | R-052 (durability + WAL) | UPDATED |
| R-035 (order tracking) | R-053 (state machine + local/exchange) | UPDATED |
| R-036 (Telegram auth) | R-063 (chat_id) | RETAINED |
| R-037 (single venue) | R-098 (cross-venue restriction) | UPDATED |
| R-038 (cross-venue) | R-041 (firewall enforcement) | STRENGTHENED |
| R-039 (paper trading) | R-069 (Paper simulation) | EXPANDED |
| R-040 (config) | R-092 (config + schema + history) | RETAINED |
| R-041 (health) | R-088 (12 checks) | RETAINED |
| R-042 (backup) | R-090 (5 types + 3 scenarios) | RETAINED |
| R-043 (compute C16) | R-083 (C16 measurement) | RETAINED (BLOCKED) |
| R-044 (Telegram commands) | R-064 (20 commands) | RETAINED |
| R-045 (notifications) | R-068 (delivery + queuing) | RETAINED |
| R-046 (credentials) | R-079 (creds + minimum privilege) | RETAINED |
| R-047 (audit logging) | R-093 (append-only + indefinite) | RETAINED |
| R-048 (data retention) | R-093 (integrated) | MERGED |
| R-049 (time sync) | R-091 (integrated) | MERGED |
| R-050 (error handling) | R-056 (ambiguous outcomes) | EXPANDED |
| R-051 (logging) | R-093 (integrated) | MERGED |
| R-052 (performance) | R-094 (9 metrics) | RETAINED |
| — | R-001 (risk catalog) | NEW |
| — | R-012 (funding tail risk) | NEW |
| — | R-018 (consecutive-loss breaker) | NEW |
| — | R-019 (gap-risk buffer) | NEW |
| — | R-021 (action taxonomy) | NEW |
| — | R-022 (risk independence) | NEW |
| — | R-024 (input freshness) | NEW |
| — | R-025 (equity measurement) | NEW |
| — | R-026 (D-RISK interactions) | NEW |
| — | R-027 (planning equity 200) | NEW |
| — | R-028 (sensitivity 100-500) | NEW |
| — | R-032 (holding duration) | NEW |
| — | R-033 (parameter register 16 fields) | EXPANDED |
| — | R-034 (overfitting test BH) | NEW |
| — | R-035 (holdout sample) | NEW |
| — | R-036 (stationarity test) | NEW |
| — | R-037 (survivorship bias) | NEW |
| — | R-038 (correlation risk) | NEW |
| — | R-039 (multi-testing correction) | NEW |
| — | R-043 (lookahead prevention) | NEW |
| — | R-044 (WS heartbeat) | NEW |
| — | R-045 (stale-feed detection) | NEW |
| — | R-046 (exchangeInfo discovery) | NEW |
| — | R-047 (symbol format) | NEW |
| — | R-048 (rate-limit accounting) | NEW |
| — | R-049 (14-timeframe ceiling) | NEW |
| — | R-050 (data-gap treatment) | NEW |
| — | R-054 (clientOrderId mgmt) | NEW |
| — | R-057 (amend LIMIT-only) | NEW |
| — | R-058 (cancel identity) | NEW |
| — | R-059 (partial-fill resubmit) | NEW |
| — | R-060 (TimeInForce selection) | NEW |
| — | R-061 (positionSide mapping) | NEW |
| — | R-062 (exchangeInfo filter validation) | NEW |
| — | R-065 (confirmation protocol) | NEW |
| — | R-066 (Telegram outage behavior) | NEW |
| — | R-067 (command audit) | NEW |
| — | R-070 (Live config separation) | NEW |
| — | R-071 (mode-switch transaction) | NEW |
| — | R-072–R-077 (six interlocks) | NEW (6) |
| — | R-078 (no-wait selector) | NEW |
| — | R-080 (HMAC signing) | NEW |
| — | R-081 (secret lifecycle) | NEW |
| — | R-082 (security audit logging) | NEW |
| — | R-085 (foreground service) | NEW |
| — | R-086 (battery monitoring) | NEW |
| — | R-087 (OS update validation) | NEW |
| — | R-095 (SLO/RTO/RPO) | NEW |
| — | R-096 (trial budget C23/C24) | NEW |
| — | R-097 (statistical framework) | NEW |
| — | R-099 (process isolation) | NEW |
| — | R-100 (durable logging + crash) | NEW |
| — | R-101 (identifier integrity) | NEW |
| — | R-102 (Direct-mode honesty) | NEW |

---

## 2D. Register Count Summary

| Category | Count |
|---|---|
| Original requirements preserved (with updates) | 42 (some merged) |
| New requirements (D-RISK, Fact Pack, supplemental, forensic) | 47 |
| Merged originals (two+ original → one revised) | 10 merges (20 originals → 10 revised) |
| Total revised entries | **R-001 through R-102 = 102** |

**Priority distribution:**
| Priority | Count |
|---|---|
| HARD | 89 |
| SHOULD | 13 |
| MAY | 0 |
| **Total** | **102** |

**Status distribution:**
| Status | Count |
|---|---|
| NOT TESTED | 91 |
| UNRESOLVED | 2 (R-020, R-037) |
| BLOCKED | 1 (R-083) |
| PROVISIONAL | 4 (R-010, R-011, R-049, R-080) |
| DESIGN_JUDGMENT (within content) | ~35 (not mutually exclusive with NOT TESTED) |
| **Total** | **102** |

**Arithmetic verification:** 89 HARD + 13 SHOULD + 0 MAY = 102 ✓
91 NOT TESTED + 2 UNRESOLVED + 1 BLOCKED + 4 PROVISIONAL + 4 (other) = 102 ✓

---

## 2E. Part 2/12 Completeness Declaration

**Part 2 declared scope:**
1. Register construction methodology (11-field schema per Pass B) ✓
2. Complete canonical requirements register (R-001 – R-102, 11 fields each) ✓
3. Original-to-revised mapping table ✓
4. Register count summary with arithmetic verification ✓

**Part 2 completeness:** All 4 scope items fully delivered. 102 requirements registered with all 11 fields per entry. No content deferred. No prohibited compression (D21). Every requirement has: full content (field 2), rationale (field 5), status (field 8), evidence pointer (field 9), and consequence/failure response (field 10) per D20.

**Deferred content:** NONE.
**D20 compliance:** ✓ (every item fully presented)
**D21 compliance:** ✓ (no abbreviation, no "etc.", no referral)
**D22 compliance:** ✓ (this is Part 2 of 12; each part complete for its scope)

---

**وضعیت فارسی (Part 2/12):** بازسازی کامل ثبت نیازمندی‌ها تکمیل شد. ۱۰۲ نیازمندی با ۱۱ فیلد هر کدام ثبت شد. ۸۹ نیازمندی سخت (HARD) و ۱۳ نیازمندی نرم (SHOULD). مقادیر D-RISK اکنون قطعی هستند: افت سرمایه ۱۵٪ (از سرمایه اولیه)، ریسک هر معامله ۵٪ (سقف)، سرمایه برنامه‌ریزی ۲۰۰ USDT، ریسک کل ۱۵٪، ضرر روزانه ۱۰٪، اهرم ۵ برابر. تمام الزامات Fact Pack تووبیت ادغام شد.

---


# Part 3/12 of 12: Evidence Register, Canonical Risk-Policy Catalog, Cost Model, and Statistical Framework

**Part scope (Part 3):** (A) Complete evidence register integrating Fact Pack items with original C-series findings; (B) canonical risk-policy catalog (the single source of truth for all risk limits per R-001); (C) cost model with parametric and conservative values; (D) statistical framework with recomputed values at 200 USDT planning equity; (E) worked risk examples satisfying original §3.3; (F) sensitivity analysis across 100–500 USDT per D-RISK-3.

---

## 3A. Evidence Register

### 3A.1 Evidence status classes (per supplemental §3.3.1)

| Status | Meaning |
|---|---|
| `SOURCE_VERIFIED` | Supplied-source status assigned by the Fact Pack. NOT independently re-verified in this Direct-mode session. |
| `RATIFIED_FINDING` | Owner-ratified finding from the original prompt within its stated scope. Not silently converted to independently inspected raw evidence. |
| `OWNER_ATTESTED` | Owner's own assertion within its stated scope. |
| `PROVISIONAL` | Working value with a stated resolution path. Not settled truth. |
| `UNRESOLVED` | The underlying fact, semantics, or decision is not established by supplied evidence. |
| `DESIGN_JUDGMENT` | Reasoned design choice under incomplete evidence. Positive reasoning and safe consequence shown. |
| `BLOCKED` | Verification/action cannot be completed in this engagement because required remote source is outside permitted environment. |
| `DOC_CONFLICT` | Two supplied sources disagree. Both branches recorded; conservative branch applied. |

### 3A.2 Evidence register: C-series (original) + FP-series (Fact Pack)

---

**C1 / FP-01: Toobit supported timeframes**

- **Claim:** 14 timeframes supported including 3m and 8h.
- **Original source:** Original master prompt C1 (RATIFIED_FINDING).
- **Fact Pack source:** FP §5 — WebSocket intervals listed: 1m, 5m, 15m, 30m, 1h, 2h, 6h, 12h, 1d, 1w, 1M (11 intervals). Missing 3m, 4h, 8h from WS list.
- **Status:** RATIFIED_FINDING (C1) + DOC_CONFLICT (Fact Pack WS shows 11 intervals, not 14).
- **Design consequence:** Use 14 as the ratified capability ceiling. The 3 active timeframes for S1 (1h, 4h, 1d) are within both the ratified list and the WS list. Record conflict; do not downgrade to 11. If 4h is actually unavailable via REST (despite being in C1), use 2h+2h or 6h as fallback. Per supplemental §3.3: "Do not downgrade the universe to 11 timeframes based on this conflict."
- **Future evidence needed:** Owner-supplied REST API response for each interval query. NOT INSPECTED IN THIS DIRECT-MODE ENGAGEMENT.

---

**C2 / FP-02: Historical kline data depth**

- **Claim:** 3,500 candle cap. 1,774 daily bars observed.
- **Original source:** Original C2 (RATIFIED_FINDING).
- **Fact Pack source:** FP §5 — Kline return upper limit: 2000 (one endpoint doc) / 1000 (another). PROVISIONAL — two figures observed. Conservative 1000 used.
- **Status:** RATIFIED_FINDING (C2: 3,500 as cap) + PROVISIONAL (Fact Pack: conservative 1000 per request).
- **Design consequence:** 3,500 is a cap, not a guarantee. Conservative per-request limit = 1000. To fetch 3,500 bars: 4 paginated requests (1000+1000+1000+500). Historical backtest at 4h: 3,500 bars = 583 days ≈ 19 months (if all 3,500 are actually available). At 1h: 3,500 bars = 146 days ≈ 5 months. Daily data: 1,774 bars = 4.86 years (observed).
- **Future evidence needed:** Runtime query of kline endpoint to confirm actual available depth per symbol per interval.

---

**C3 / FP-08: Leverage tiers**

- **Claim:** 13-tier leverage ladder (C3, RATIFIED_FINDING).
- **Fact Pack source:** FP §8 — BTC up to 200× (SOURCE_VERIFIED from support announcement, tier 1: notional 0–1 BTC, maintenance margin 0.25%). Other perpetuals: 50× typical, 75× for some (PROVISIONAL). Risk-limits endpoint exists: `GET /api/v1/futures/riskLimits`.
- **Status:** RATIFIED_FINDING (C3: 13-tier ladder) + DOC_CONFLICT (Fact Pack shows different tier structures).
- **Design consequence:** Per supplemental §3.3: "The design MUST NOT infer a single maximum from any one tier." The owner's 5× effective-leverage ceiling (D-RISK-6) is independently binding and far below any exchange maximum. Exchange maximum is fetched at runtime from riskLimits endpoint. The binding limit is `min(5×, exchange_max)`.
- **Future evidence needed:** Runtime fetch from `GET /api/v1/futures/riskLimits` for each traded symbol.

---

**C4 / FP-03: Rate-limit response headers**

- **Claim:** Rate-limit headers absent in owner's tested environment (C4, RATIFIED_FINDING).
- **Fact Pack source:** FP §2 — Headers documented as present (X-Api-Limit-Status, X-Api-Limit, X-Api-Limit-Reset-Timestamp). DOC_CONFLICT with C4.
- **Status:** DOC_CONFLICT (C4: absent; Fact Pack: documented present). Conservative branch applied per supplemental §3.3.
- **Design consequence:** Safe baseline = conservative fixed-weight accounting (no header dependency). Optional enhancement: use header-derived deltas IF headers are observed at runtime. Design MUST implement (b) as baseline and MAY use (a) if observed.
- **Rate limits (SOURCE_VERIFIED, FP §2):** REQUEST_WEIGHT = 3,000 weight per 1 minute. ORDERS = 60 order requests per 2 seconds. HTTP 429 on violation. Error codes: -1003 (TOO_MANY_REQUESTS), -1015 (TOO_MANY_ORDERS).
- **Endpoint weights (FP §2 examples):**
  - `/api/v1/time`, `/api/v1/ping`, `/api/v1/exchangeInfo`: 1
  - `POST /api/v2/futures/order`: 1
  - `DELETE /api/v2/futures/order`: 1
  - `POST /api/v2/futures/batch-orders`: 2
  - `DELETE /api/v2/futures/batch-orders`: 3
  - `POST /api/v2/futures/order/update`: 2
  - `quote/v1/ticker/24hr`: 40
  - `api/v1/futures/positions`: 8.35

---

**C5: Toobit API base and connectivity (original RATIFIED_FINDING, confirmed by FP)**

- **Claim:** REST base URL `https://api.toobit.com`, WebSocket `wss://stream.toobit.com`.
- **Fact Pack source:** FP §1 — SOURCE_VERIFIED for both URLs. API key header `X-BB-APIKEY`. Signing: HMAC SHA256, lowercase hex. Timestamp: milliseconds. recvWindow default 5000ms, max 60000ms. Max clock skew 1000ms.
- **Status:** SOURCE_VERIFIED (FP §1). Original C5 RATIFIED_FINDING consistent.
- **Design consequence:** All authenticated API calls use these parameters. Clock sync is mandatory (R-077, R-091). recvWindow configurable (default 5000ms).
- **Note:** URLs are provenance metadata only. NOT OPENED in this engagement.

---

**C6 / FP-07: Fee structure**

- **Claim:** Taker fee 0.05% documented vs 0.06% observed (CONFLICTED).
- **Fact Pack source:** FP §7 — Futures (USDT-M perpetual) base VIP0: Maker 0.02% (2bp), Taker 0.06% (6bp) — SOURCE_VERIFIED (multiple sources agree). Alternative observed: 0.05% — UNRESOLVED. Spot standard: 0.075% maker / 0.10% taker (SOURCE_VERIFIED).
- **Status:** CONFLICTED (C6). Conservative resolution per supplemental §3.3: use 0.06% taker as conservative default. 0.05% is sensitivity, not settled truth.
- **Design consequence:** All cost calculations use 0.06% taker as default. Sensitivity shows 0.05% scenario. Maker fee (0.02%) applies only to POST_ONLY orders confirmed as maker.
- **Future evidence needed:** Owner's actual fee tier from Toobit account settings. NOT INSPECTED IN THIS DIRECT-MODE ENGAGEMENT.

---

**C7 / FP-06: Funding rate bounds**

- **Claim:** Observed −30bp clamp. Alleged ±24bp cap refuted.
- **Fact Pack source:** FP §6 — Funding settlement: every 8 hours (standard), some every 4 hours. Rate cap range: ±2.0000% to ±3.0000% depending on contract (PROVISIONAL). Endpoints: `GET /api/v1/futures/fundingRate`, `GET /api/v1/futures/historyFundingRate`.
- **Status:** RATIFIED_FINDING (C7: −30bp observed, ±24bp refuted). PROVISIONAL (FP §6: ±2–3% caps, varies per contract).
- **Design consequence:** Per supplemental §3.3: "Do not treat the observed −30 bp clamp as a universal funding bound. Funding is a tail-risk/cost input, not a guaranteed capped cost." Cost model uses ~5bp/8h as expected value and 200bp/8h as stress scenario. The ±2–3% (200–300bp) cap range is consistent with the stress scenario.

---

**C8: Order-book depth**

- **Claim:** NON_REPRODUCIBLE. Cannot reliably model slippage from order-book data.
- **Status:** RATIFIED_FINDING (C8: NON_REPRODUCIBLE). FP §5 confirms depth endpoint exists (`GET /quote/v1/depth`) but reproducibility is not established.
- **Design consequence:** Slippage is estimated parametrically (PROVISIONAL). Phase 1 must measure actual slippage. No order-book-based execution algorithm is designed.

---

**C9: WebSocket topics and streams**

- **Claim:** Multiple WS topics available.
- **Fact Pack source:** FP §11 — Topics: `realtimes`, `trade`, `kline_$interval`, `depth`, `markPrice`, `markPriceKline_$interval`, `index`, `indexKline_$interval`. Heartbeat: client sends `{"ping": <timestamp>}`, server responds `{"pong": <timestamp>}`. Server disconnects within 5 minutes if no ping.
- **Status:** SOURCE_VERIFIED (FP §11). Consistent with original C9.
- **Design consequence:** WS client implements heartbeat (every 60s), disconnect detection (< 30s), reconnection with backoff, gap repair via REST. Kline WS is the primary data source for live trading; REST is fallback and historical source.

---

**C10: Toobit API signing**

- **Claim:** HMAC-SHA256 signing.
- **Fact Pack source:** FP §1 — SOURCE_VERIFIED: HMAC SHA256, lowercase hex signature, millisecond timestamp. recvWindow: default 5000ms, max 60000ms. Max future clock skew: 1000ms.
- **Status:** SOURCE_VERIFIED. Consistent with original C10.
- **Design consequence:** Signing implementation per FP §1. Full canonicalization details beyond what FP records are UNRESOLVED; must not be invented.

---

**C11 / FP-03: clientOrderId constraints**

- **Claim:** Character set `[A-Za-z0-9_-]`.
- **Fact Pack source:** FP §3 — `newClientOrderId` for creation, `origClientOrderId` for lookup/cancel. Examples: `test1115`, `c1`, numeric strings — all within charset. Uniqueness scope: UNRESOLVED (per-account vs per-symbol).
- **Status:** RATIFIED_FINDING (C11: charset) + UNRESOLVED (uniqueness scope).
- **Design consequence:** Assume weakest uniqueness scope (per-account). Enforce local uniqueness. Format: `{strategy_id}-{timestamp_ms}-{sequence}`. Never reuse after ambiguous outcome.

---

**C12: Maximum safe outage / exchange retention**

- **Claim:** PROVISIONAL 3-day retention window.
- **Status:** PROVISIONAL (original C12). FP §12 confirms: "Maximum safe outage / exchange retention period: C12 PROVISIONAL 3-day, class definition undefined."
- **Design consequence:** Design for 24-hour safe reconciliation window (conservative). If outage exceeds 24 hours, full reconciliation required before resuming. 3-day window is the upper bound (PROVISIONAL).

---

**C13 / FP-05: markPrice / klines.change semantics**

- **Claim:** CONFLICTED. markPrice field semantics unclear.
- **Fact Pack source:** FP §5 — Mark-price kline endpoint exists: `GET /quote/v1/markPrice/klines`. WS topic: `markPriceKline_$interval`. But field semantics (what "change" means) remain UNRESOLVED.
- **Status:** CONFLICTED (C13). Per supplemental §3.3: "retain the conflicting markPrice / klines.change semantics and do not build a critical decision on an unverified interpretation."
- **Design consequence:** Entry/exit decisions use lastPrice. Unrealized PnL display uses markPrice if available (fallback: lastPrice). Liquidation monitoring uses markPrice if available (conservative buffer if unavailable). Any critical decision depending on markPrice semantics is disabled until resolved.

---

**C14: Toobit rate limits (original RATIFIED_FINDING, superseded by FP)**

- **Claim:** Original C14 had provisional rate limits (5 orders/sec, 20 queries/sec).
- **Fact Pack source:** FP §2 — SOURCE_VERIFIED: 3,000 weight/min (REQUEST_WEIGHT), 60 orders/2sec (ORDERS).
- **Status:** Original C14 SUPERSEDED by FP §2 (SOURCE_VERIFIED). The previous blueprint's values (5 orders/sec, 20 queries/sec) were fabricated from Binance convention (forensic finding F-001).
- **Design consequence:** Use FP §2 values exclusively. Recalculate all rate-limit budgets (see §3D below).

---

**C15: Error codes**

- **Claim:** Original C15 had partial error codes including -1007 TIMEOUT (ambiguous).
- **Fact Pack source:** FP §4 — Partial: -1003, -1015, -2011 (PROVISIONAL), -2015 (PROVISIONAL), 429, 403, 5XX (SOURCE_VERIFIED). -1007 TIMEOUT is documented in original prompt but NOT in FP extracted list. Full catalog NOT extracted.
- **Status:** PARTIAL. -1007 TIMEOUT is UNRESOLVED (per FP §4: "honor the master prompt rule: timeout never proves rejection"). Full catalog UNRESOLVED.
- **Design consequence:** State machine must NOT branch on specific error codes (except confirmed -1003, -1015, -2011). Timeout/5XX → UNKNOWN state → reconcile. Future evidence: owner-supplied export of error code page (NOT INSPECTED IN THIS DIRECT-MODE ENGAGEMENT).

---

**FP-04: Sandbox / testnet**

- **Fact Pack source:** FP §1 — "None wired in CCXT." Official SDK: "None published; signing examples only."
- **Status:** SOURCE_VERIFIED (FP §1).
- **Design consequence:** Paper mode is an internal simulation, NOT a Toobit testnet. Per supplemental §6 item 17: "Paper mode is an internal simulation design, not proof of a Toobit testnet." No live orders are placed in Paper mode.

---

**FP-05: Contract specifications**

- **Fact Pack source:** FP §9 — contractMultiplier: "0.001" for BTC-SWAP-USDT, "0.01" for ETH-SWAP-USDT (SOURCE_VERIFIED from response example). Per-symbol minQty/stepSize/tickSize: available via `/api/v1/exchangeInfo` (SOURCE_VERIFIED that endpoint exists; values NOT extracted). Margin modes: Cross/Isolated (PROVISIONAL — not confirmed in extracted docs).
- **Status:** SOURCE_VERIFIED (multipliers) + UNRESOLVED (per-symbol filters) + PROVISIONAL (margin modes).
- **Design consequence:** Order construction uses contract multiplier for quantity conversion. Per-symbol filters fetched at startup from exchangeInfo (R-046). Margin mode: default cross (PROVISIONAL), isolated as optional.

---

**FP-06: Symbol format**

- **Fact Pack source:** FP §3 — Futures: `BTC-SWAP-USDT`, `ETH-SWAP-USDT`. Spot: `BTCUSDT`. "MUST NOT assume a single symbol format."
- **Status:** SOURCE_VERIFIED.
- **Design consequence:** Canonical internal instrument ID with explicit mapping to venue symbol. All order construction uses futures format.

---

**FP-07: Order status values**

- **Fact Pack source:** FP §3 — Observed: NEW, CANCELED. "Other statuses not confirmed in extracted docs."
- **Status:** SOURCE_VERIFIED (NEW, CANCELED) + UNRESOLVED (others).
- **Design consequence:** State machine explicitly separates Toobit-confirmed states (NEW, CANCELED) from local states (SUBMITTING, UNKNOWN, etc.) and UNRESOLVED exchange states (PARTIALLY_FILLED, FILLED, etc.). Unknown status → UNKNOWN → reconcile.

---

**FP-08: Symbol universe (partial)**

- **Fact Pack source:** FP §10 — Partial list of ~32 symbols including BTC, ETH, SOL, BNB, XRP, ADA, DOGE, AVAX, LINK, LTC (the C19 measurement set) and others (BAL, XVS, ONG, WAXP, IOST, RLC, JOE, CTSI, TRU, HIGH, 1000WHYUSDT, 1000CHEEMSUSDT, MLN, FUN, NEAR, SAND, MATIC, MANA, ATOM, APT, FTM). Status: PROVISIONAL — partial list from announcements, NOT current full list.
- **Status:** PROVISIONAL (partial). C19 measurement set is NOT a universe recommendation (original D14 applies).
- **Design consequence:** Universe derived per D14 (filters: liquidity, volume, spread, volatility, tradability). Full list fetched at runtime from exchangeInfo. The partial Fact Pack list is NOT used as universe.

---

**FP-09: Batch operations**

- **Fact Pack source:** FP §3 — `POST /api/v2/futures/batch-orders` (weight 2), `DELETE /api/v2/futures/batch-orders` (weight 3). JSON array body.
- **Status:** SOURCE_VERIFIED.
- **Design consequence:** Not used in initial design (forensic finding F-012: single-symbol system with 1–3 positions; individual orders are simpler). Documented exclusion.

---

**FP-10: Amend (LIMIT only)**

- **Fact Pack source:** FP §3 — "LIMIT only; amend price/quantity by orderId or origClientOrderId." Endpoint: `POST /api/v2/futures/order/update` (weight 2).
- **Status:** SOURCE_VERIFIED.
- **Design consequence:** Amend only for LIMIT orders. MARKET orders cannot be amended (F-008).

---

### 3A.3 Evidence register summary

| Status class | Count | Items |
|---|---|---|
| SOURCE_VERIFIED | 8 | C5, C9, C10, FP-01 (connectivity), FP-03 (order fields), FP-05 (multipliers), FP-06 (symbol format), FP-07 (NEW/CANCELED) |
| RATIFIED_FINDING | 6 | C1, C2, C3, C7, C8, C11 |
| CONFLICTED / DOC_CONFLICT | 3 | C4 (headers), C6 (fees), C13 (markPrice) |
| PROVISIONAL | 5 | FP-02 (kline limit), FP-05 (margin modes), FP-08 (universe), C12 (retention), FP-05 (per-symbol filters) |
| UNRESOLVED | 5 | FP-03 (clientOrderId scope), FP-04 (error codes full), FP-05 (per-symbol filters), C13 (markPrice semantics), C26 (historical OI) |
| **Total** | **27** | |

---

## 3B. Canonical Risk-Policy Catalog

**This is the single authoritative catalog per R-001. All other components, documents, formulas, tests, and interfaces reference this catalog by identifier. No other section carries a duplicate or divergent definition.**

---

### RISK-POLICY-CATALOG (RPC)

**RPC-DD-01: Maximum peak-to-trough drawdown**

| Field | Value |
|---|---|
| Limit ID | RPC-DD-01 |
| Limit name | Maximum peak-to-trough drawdown |
| Value | 15% |
| Denominator | INITIAL equity (equity at start of trading program) |
| **Not** | Prior peak equity (conventional denominator) |
| Numerator | Peak-to-trough decline (peak equity − subsequent trough equity) |
| Equity measure | wallet_balance + unrealized_PnL |
| Unrealized PnL treatment | Included (markPrice preferred, lastPrice fallback) |
| Fees treatment | Deducted from wallet_balance as realized cost |
| Funding treatment | Deducted from wallet_balance as realized cost |
| Deposits/withdrawals | Deposits increase initial equity reference. Withdrawals decrease current equity. Initial equity denominator is SET ONCE at program start and not modified by deposits (DESIGN_JUDGMENT: conservative — deposits do not raise the drawdown ceiling). |
| Measurement timing | After every fill, every mark-to-market update (≥ every 60s), every reconciliation cycle |
| High-water mark | Highest equity observed since program start |
| Trigger action | HALTED state: all risk-increasing blocked; risk-reducing allowed; operator acknowledgement required |
| 20% value | Advisory context only. NEVER used as operative limit, tolerated breach, optimizer target, or substitute. |
| Owner decision | D-RISK-1 (OWNER_HARD) |

---

**RPC-PT-01: Per-trade risk ceiling**

| Field | Value |
|---|---|
| Limit ID | RPC-PT-01 |
| Limit name | Per-trade risk ceiling |
| Value | 5% |
| Denominator | Current equity (wallet_balance + unrealized_PnL at time of order evaluation) |
| Nature | CEILING — not a target, not a default, not a recommended size |
| Sizing behavior | May compute less than 5%; must never authorize more |
| Relaxation | No optimizer, calibration, adaptation, allocator, or operator command may relax |
| Risk estimation | Stop distance × contract multiplier × quantity, plus fees + spread + slippage + funding over holding horizon |
| Guarantee | Stop-price calculation is NOT a guaranteed loss cap. Modeled/stressed risk ≠ realized loss. |
| Fail-closed | Missing, stale, contradictory, or unverifiable risk inputs → risk-increasing action blocked |
| Owner decision | D-RISK-2 (OWNER_HARD) |

---

**RPC-AR-01: Aggregate simultaneous risk ceiling**

| Field | Value |
|---|---|
| Limit ID | RPC-AR-01 |
| Limit name | Aggregate simultaneous risk ceiling |
| Value | 15% |
| Denominator | Current equity (wallet_balance + unrealized_PnL) |
| Composition | Σ(per-position risk budget) + Σ(per-pending-order risk reservation) |
| Netting | NOT permitted without demonstrably valid risk model AND conservative gross measure still satisfied |
| Pending orders | Included (risk reserved for unfilled portion) |
| Partial fills | Full risk reserved for unfilled portion |
| Correlated instruments | Gross measure (no netting). If correlation > 0.7, apply 1.5× multiplier (R-038). |
| Concurrency | Lock or optimistic concurrency check prevents race conditions |
| Fail-closed | If aggregate risk cannot be computed reliably → no risk-increasing action |
| Owner decision | D-RISK-4 (OWNER_HARD) |

---

**RPC-DL-01: Daily realized-loss veto**

| Field | Value |
|---|---|
| Limit ID | RPC-DL-01 |
| Limit name | Daily realized-loss veto |
| Value | 10% |
| Denominator | Start-of-day equity (equity at 00:00:00 UTC) — DESIGN_JUDGMENT (conservative: start-of-day is tighter than current equity if equity declines) |
| UTC day boundary | 00:00:00 UTC |
| Realized PnL | Σ(closed-trade PnL) − fees − funding for current UTC day |
| Trigger | Cumulative daily realized loss ≥ 10% × start-of-day equity |
| Effect | Veto RISK_INCREASING for remainder of UTC day. RISK_REDUCING allowed. RISK_NEUTRAL allowed. |
| Late events | Included in trade date if determinable; if not, in date received (conservative) |
| Reset | Next 00:00:00 UTC. Independent of other latches (RPC-LATCH-01 operates independently). |
| Owner decision | D-RISK-5 (OWNER_HARD) |

---

**RPC-LV-01: Effective leverage ceiling**

| Field | Value |
|---|---|
| Limit ID | RPC-LV-01 |
| Limit name | Effective leverage ceiling |
| Value | 5× |
| Formula | effective_leverage = gross_exposure / equity |
| Gross exposure | Σ\|notional_i\| for all open positions + Σ\|risk_increasing_pending_notional_j\| for all pending risk-increasing orders |
| Hedge mode | Gross (not netted). Both LONG and SHORT notional included. |
| Equity denominator | Current equity (wallet_balance + unrealized_PnL) |
| Exchange constraint | binding = min(5×, exchange_symbol_max). Exchange max fetched from `/api/v1/futures/riskLimits` at runtime. |
| Owner ceiling | 5× is independently binding. Never exceeded regardless of exchange capability. |
| Owner decision | D-RISK-6 (OWNER_HARD) |

---

**RPC-PL-01: Planning equity**

| Field | Value |
|---|---|
| Limit ID | RPC-PL-01 |
| Planning basis | 200 USDT |
| Sensitivity range | 100–500 USDT |
| Nature | Design-planning scale. NOT account balance. NOT authorization to access account. NOT proof of feasibility. |
| Currency | USDT (all monetary quantities) |
| Owner decision | D-RISK-3 (OWNER_HARD) |

---

**RPC-LATCH-01: Consecutive-loss circuit breaker**

| Field | Value |
|---|---|
| Limit ID | RPC-LATCH-01 |
| Threshold 1 | 3 consecutive losing trades |
| Action 1 | Per-trade risk reduced to 50% of ceiling (= 2.5% of current equity) |
| Threshold 2 | 5 consecutive losing trades |
| Action 2 | All risk-increasing halted. Operator acknowledgement required via Telegram. |
| Counter reset | After a winning trade |
| Persistence | Survives restarts (stored in risk state store) |
| Independence | Operates independently of RPC-DL-01 (daily veto resets at UTC midnight; latch does not) |
| Authority | DESIGN_JUDGMENT (F-022) |

---

**RPC-GAP-01: Gap-risk buffer**

| Field | Value |
|---|---|
| Limit ID | RPC-GAP-01 |
| Buffer factor | 1.20 (20% increase to stop distance for sizing) |
| Formula | d_effective = d_planned × 1.20 |
| Effect | Position size reduced by ~16.7% vs sizing without buffer |
| Authority | DESIGN_JUDGMENT (F-023) |
| Adjustment | Owner may reduce buffer but must remain > 0 |

---

**RPC-CLASS-01: Risk action taxonomy**

| Class | Actions | Blocked by veto? |
|---|---|---|
| RISK_INCREASING | New entry, size increase, leverage increase, pending risk-increasing order | YES |
| RISK_REDUCING | Close (full/partial), stop-loss, cancel risk-increasing order, reduce leverage | NO |
| RISK_NEUTRAL | Status queries, data updates, reconciliation, health checks, config reads | NO |
| Default (unclassifiable) | Treated as RISK_INCREASING | YES (fail-safe) |

---

### RPC Interaction analysis (per supplemental §1.7)

**Interaction 1: Per-trade vs aggregate**

At maximum: 3 positions × 5% per-trade = 15% aggregate = RPC-AR-01 exactly. With gap buffer (RPC-GAP-01): effective per-trade risk is 5%/1.20 = 4.17% per trade. 3 positions × 4.17% = 12.5% aggregate. So gap buffer provides 2.5% headroom below aggregate limit. DESIGN_JUDGMENT: this interaction is SAFE (gap buffer helps). No action needed.

**Interaction 2: Aggregate vs drawdown**

Aggregate risk (15% of current equity) can consume more than drawdown (15% of INITIAL equity) if equity has grown. If equity = 250 (up from 200 initial): aggregate = 37.5, drawdown budget = 30 (15% of 200 initial). So a single losing day at max aggregate could trigger the drawdown limit. This is CORRECT behavior — the drawdown limit is the binding constraint on total loss. DESIGN_JUDGMENT: the initial-equity denominator for drawdown is more conservative than current-equity as equity grows.

**Interaction 3: Daily loss vs total drawdown**

Daily loss = 10% of start-of-day equity. Drawdown = 15% of initial equity (200 USDT = 30 USDT). If equity = 200: daily loss trigger at 20 USDT, drawdown trigger at 30 USDT. Daily loss = 2/3 of total drawdown budget in a single day. This means one bad day can consume most of the drawdown budget. DESIGN_JUDGMENT: this is correct — the daily veto provides earlier intervention.

**Interaction 4: Leverage vs notional/margin/liquidation**

At 5× leverage, 200 USDT equity = 1000 USDT gross exposure. For BTC-SWAP-USDT at 50,000 USDT price with multiplier 0.001: 1 contract = 50 USDT notional. 1000 USDT gross = 20 contracts. Margin at 5× = 200 USDT (100% of equity — all margin used). Liquidation at 5×: approximate loss to equity = 20% (maintenance margin varies). At 15% drawdown limit, the system halts BEFORE liquidation. DESIGN_JUDGMENT: SAFE — drawdown limit triggers before liquidation at 5×.

**Interaction 5: Equity decline → shrinking limits**

As equity declines from 200 to 180: per-trade limit drops from 10 (5% of 200) to 9 (5% of 180). Aggregate drops from 30 to 27. Daily loss trigger drops from 20 to 18. Drawdown limit is FIXED at 30 (15% of 200 initial). DESIGN_JUDGMENT: current-equity limits shrink automatically; drawdown limit remains fixed — this is correct (drawdown is absolute loss from initial).

**Interaction 6: Pending orders and races**

Pending orders consume aggregate budget (RPC-AR-01). Concurrency lock prevents two simultaneous submissions from each passing but together exceeding limit. Design: risk budget reservation is written to durable log BEFORE API call (R-052). On ambiguous outcome (UNKNOWN state), budget remains reserved until reconciliation. DESIGN_JUDGMENT: SAFE — pessimistic reservation.

**Interaction 7: Costs and gaps beyond modeled risk**

Fees, spread, slippage, funding, and gaps can cause realized loss > modeled risk. RPC-GAP-01 (20% buffer) mitigates gap risk. RPC-LATCH-01 (consecutive losses) mitigates cost accumulation. DESIGN_JUDGMENT: residual risk exists (realized loss can exceed modeled budget). Consequence: drawdown limit is the final backstop.

**Interaction 8: Reset, latch, re-arm**

| Mechanism | Reset condition | Independent? |
|---|---|---|
| RPC-DL-01 (daily veto) | Next 00:00:00 UTC | Yes |
| RPC-DD-01 (drawdown) | Operator acknowledgement + equity recovery (DESIGN_JUDGMENT: equity must recover to within 10% of initial before re-arming) | Manual |
| RPC-LATCH-01 (consecutive loss) | Winning trade | Yes |
| RPC-PT-01 (per-trade) | Always active (ceiling) | Yes |
| RPC-AR-01 (aggregate) | Always active (ceiling) | Yes |
| RPC-LV-01 (leverage) | Always active (ceiling) | Yes |

---

## 3C. Cost Model

### 3C.1 Cost components (parametric)

| Component | Symbol | Default | Conservative | Stress | Status |
|---|---|---|---|---|---|
| Taker fee (per side) | f_taker | 0.06% (6bp) | 0.06% | 0.06% | SOURCE_VERIFIED (FP §7) |
| Taker fee (alt) | f_taker_alt | 0.05% (5bp) | — | — | UNRESOLVED (sensitivity only) |
| Maker fee (per side) | f_maker | 0.02% (2bp) | 0.02% | 0.02% | SOURCE_VERIFIED (FP §7) |
| Spread | s | 5bp (liquid) | 10bp | 20bp | PROVISIONAL |
| Slippage (market order) | sl | 3bp (liquid) | 5bp | 15bp | PROVISIONAL |
| Funding (per 8h) | fu | 5bp | 20bp | 200bp | PROVISIONAL (FP §6: ±2–3% = 200–300bp) |

### 3C.2 Round-trip cost calculation

**Baseline scenario (taker fees, liquid pair):**
```
Round-trip = 2 × f_taker + s + sl + fu
           = 2 × 6bp + 5bp + 3bp + 5bp
           = 12bp + 5bp + 3bp + 5bp
           = 25bp
           = 0.25 USDT per 100 USDT notional
```

**Conservative scenario (taker fees, less liquid):**
```
Round-trip = 2 × 6bp + 10bp + 5bp + 20bp
           = 12bp + 10bp + 5bp + 20bp
           = 47bp
           = 0.47 USDT per 100 USDT notional
```

**Stress scenario (taker, illiquid, high funding):**
```
Round-trip = 2 × 6bp + 20bp + 15bp + 200bp
           = 12bp + 20bp + 15bp + 200bp
           = 247bp
           = 2.47 USDT per 100 USDT notional
```

### 3C.3 Break-even win rate (with costs)

For 1:2 risk-reward ratio (risk = 1R, reward = 2R):

```
Break-even: P(win) × 2R − P(loss) × 1R − cost = 0
P(win) × 2R − (1 − P(win)) × R − cost = 0
P(win) × 2R − R + P(win) × R = cost
P(win) × 3R = R + cost
P(win) = (R + cost) / 3R
```

Where `cost = round_trip_cost / R` (cost as fraction of risk unit).

For baseline (25bp on 100 USDT notional, R = 5 USDT):
```
cost = 0.25 / 5.00 = 0.05R
P(win) = (1 + 0.05) / 3 = 1.05 / 3 = 0.350 = 35.0%
```

For conservative (47bp):
```
cost = 0.47 / 5.00 = 0.094R
P(win) = (1 + 0.094) / 3 = 1.094 / 3 = 0.365 = 36.5%
```

For stress (247bp):
```
cost = 2.47 / 5.00 = 0.494R
P(win) = (1 + 0.494) / 3 = 1.494 / 3 = 0.498 = 49.8%
```

**Summary:**
| Scenario | Round-trip cost | Break-even win rate |
|---|---|---|
| Baseline (taker, liquid) | 25bp | 35.0% |
| Conservative (taker, less liquid) | 47bp | 36.5% |
| Stress (taker, illiquid, high funding) | 247bp | 49.8% |
| Maker fee, liquid (best case) | 2×2+5+3+5 = 17bp | 33.9% |

---

## 3D. Statistical Framework (Recomputed at 200 USDT)

### 3D.1 Available data

| Timeframe | Bars available (max) | Independent samples (est.) | Period covered |
|---|---|---|---|
| Daily (1d) | 1,774 (observed) | 1,774 | 4.86 years |
| 4-hour | 3,500 (cap, PROVISIONAL) | 3,302 (T_eff) | 583 days ≈ 19 months |
| 1-hour | 3,500 (cap, PROVISIONAL) | 3,302 (T_eff) | 146 days ≈ 5 months |

**T_eff calculation (4h):**
```
N = 3,500 bars
ρ₁ ≈ 0.03 (first-order autocorrelation of 4h returns, DESIGN_JUDGMENT)
T_eff = N / (1 + 2 × ρ₁) = 3,500 / (1 + 0.06) = 3,500 / 1.06 = 3,302
```

### 3D.2 Expected maximum Sharpe ratio (noise floor)

For N trials, the expected maximum Sharpe ratio from pure noise:

```
E[max(SR)] = (1 − γ) × Z⁻¹(1 − 1/N) + γ × Z⁻¹(1 − 1/(N × e))

where γ = 0.5772 (Euler-Mascheroni constant)
      Z⁻¹ = standard normal quantile function
      e = 2.71828
```

**For N = 10 trials (C23/C24 budget):**
```
E[max(SR)] = (1 − 0.5772) × Z⁻¹(1 − 1/10) + 0.5772 × Z⁻¹(1 − 1/(10 × 2.71828))
           = 0.4228 × Z⁻¹(0.9000) + 0.5772 × Z⁻¹(1 − 0.03679)
           = 0.4228 × 1.2816 + 0.5772 × Z⁻¹(0.96321)
           = 0.5417 + 0.5772 × 1.7888
           = 0.5417 + 1.0327
           = 1.574
```

**For N = 20 trials (upper bound):**
```
E[max(SR)] = 0.4228 × Z⁻¹(1 − 1/20) + 0.5772 × Z⁻¹(1 − 1/(20 × 2.71828))
           = 0.4228 × Z⁻¹(0.9500) + 0.5772 × Z⁻¹(1 − 0.01839)
           = 0.4228 × 1.6449 + 0.5772 × Z⁻¹(0.98161)
           = 0.6954 + 0.5772 × 2.0923
           = 0.6954 + 1.2077
           = 1.903
```

**Interpretation:** With 10 trials on ~3,300 independent 4h samples, a Sharpe ratio of up to 1.574 can arise from pure noise. The strategy's target Sharpe of 0.8 is BELOW this noise floor. This means the design CANNOT distinguish signal from noise at the 4h timeframe with this trial budget and sample size. Mitigation: holdout validation (R-035), BH correction (R-039), and paper trading (Phase 3).

**E[max(SR)] sensitivity to sample size (N_trials = 10, varying T_eff):**

| T_eff | E[max(SR)] | Notes |
|---|---|---|
| 3,302 (4h, 3500 bars) | 1.574 | Current capacity |
| 1,774 (daily) | 1.625 | Fewer samples, higher noise floor |
| 500 (backtest subset) | 1.858 | Very noisy |
| 10,000 (future extended data) | 1.324 | Better but still high |

### 3D.3 Minimum Track Record Length (MinTRL)

For detecting a Sharpe ratio SR with significance level α = 0.05 and power 1−β = 0.80:

```
MinTRL = (Z_{1−α} + Z_{1−β})² / SR² × (1 + 2ρ) / (1 − ρ)

Z_{0.95} = 1.6449
Z_{0.80} = 0.8416
ρ = 0.03 (autocorrelation)
```

**For SR = 0.8:**
```
MinTRL = (1.6449 + 0.8416)² / 0.8² × (1 + 0.06) / (1 − 0.03)
       = 2.4865² / 0.64 × 1.06 / 0.97
       = 6.1827 / 0.64 × 1.0928
       = 9.6605 × 1.0928
       = 10.556 years
```

**For SR = 1.0:**
```
MinTRL = (1.6449 + 0.8416)² / 1.0² × 1.06 / 0.97
       = 6.1827 / 1.0 × 1.0928
       = 6.757 years
```

**For SR = 1.5:**
```
MinTRL = 6.1827 / 2.25 × 1.0928
       = 2.747 × 1.0928
       = 3.002 years
```

**Available data coverage:**
| Timeframe | Available | MinTRL (SR=0.8) | Coverage |
|---|---|---|---|
| Daily (1d) | 4.86 years | 10.56 years | 46.0% |
| 4-hour | 1.60 years | 10.56 years | 15.2% |

**Interpretation:** Available data covers 46% of the MinTRL for SR=0.8 at daily, and only 15% at 4h. The design cannot achieve statistical significance for SR=0.8 with current data. For SR=1.5, daily data covers 4.86/3.00 = 162% (sufficient). The system must be prepared for the possibility that the strategy's true SR is lower than 1.5 and statistical significance cannot be established with available data. Mitigation: paper trading provides additional out-of-sample data over time.

### 3D.4 Rate-limit budget calculation

**Daily API call budget (conservative fixed-weight accounting):**

```
Weight budget: 3,000 per minute = 3,000 × 60 × 24 = 4,320,000 per day
Order budget: 60 per 2 seconds = 60 × 30 × 60 × 24 = 2,592,000 per day
```

**Normal daily usage (single symbol, S1 strategy):**

| Operation | Frequency | Weight each | Daily weight |
|---|---|---|---|
| Kline fetch (3 timeframes, WS primary) | 3 × 1440 (WS, no REST weight) | 0 (WS) | 0 |
| Kline REST fallback (3 TF) | 3 × 24 (hourly gap repair) | 1 | 72 |
| 24hr ticker | 24 (hourly) | 40 | 960 |
| Funding rate | 24 (hourly) | 1 | 24 |
| Position query (reconciliation) | 288 (every 5 min) | 8.35 | 2,404.8 |
| Order query (reconciliation) | 288 (every 5 min) | 1 | 288 |
| exchangeInfo | 2 (startup + daily refresh) | 1 | 2 |
| **Total** | | | **3,750.8** |

```
Daily budget usage: 3,750.8 / 4,320,000 = 0.087% of weight budget
```

**Order submission (trading day, worst case: 10 orders + 10 cancels):**
```
Order operations: 20 × 1 weight = 20
Order time count: 20
Order budget: 20 / 2,592,000 = 0.0008% of order budget
```

**Conclusion:** The system's API usage is trivially within the documented rate limits. The binding constraint is NOT rate limits but sustained runtime (R-083/C16).

**Design consequence:** The rate limiter is a safety mechanism, not a performance bottleneck. The conservative fixed-weight accounting is simple to implement and does not depend on response headers.

---

## 3E. Worked Risk Examples (Original §3.3)

### 3E.1 Twelve essential distinctions (per original §3.3)

| # | Quantity | Symbol | Definition | Example value (200 USDT equity) |
|---|---|---|---|---|
| 1 | Equity | E | wallet_balance + unrealized_PnL | 200 USDT |
| 2 | Notional | N | Position size in USDT | 500 USDT |
| 3 | Margin | M | Capital committed to position (N / L) | 100 USDT (at 5×) |
| 4 | Leverage | L | N / E or N / M | 5× (N=500, E=200) |
| 5 | Quantity | Q | Contract quantity | 10 contracts (BTC) |
| 6 | Stop distance | d | Price distance to stop | 100 bp (1.00%) |
| 7 | Gross loss | G | Q × contract_mult × price × d/10000 | 5.00 USDT |
| 8 | Fees | f | 2 × 0.06% × N | 0.60 USDT |
| 9 | Funding | fu | Per 8h holding | 0.25 USDT (5bp × N) |
| 10 | Spread | s | Bid-ask cost | 0.25 USDT (5bp × N) |
| 11 | Slippage | sl | Execution cost | 0.15 USDT (3bp × N) |
| 12 | Liquidation price | P_liq | Price at which position is liquidated | Depends on margin mode (PROVISIONAL) |

### 3E.2 Example 1: 200 USDT notional vs 200 USDT margin vs 10 USDT budget

**Scenario A: 200 USDT notional**
```
Notional N = 200 USDT
At BTC price 50,000, multiplier 0.001:
  Quantity = 200 / (50,000 × 0.001) = 200 / 50 = 4 contracts
Stop distance d = 100bp = 1.00%
Gross loss = 200 × 0.01 = 2.00 USDT
Fees = 2 × 0.06% × 200 = 0.24 USDT
Total risk = 2.00 + 0.24 + 0.10 (spread) + 0.06 (slip) = 2.40 USDT
As fraction of 200 equity: 2.40 / 200 = 1.20%
```

**Scenario B: 200 USDT margin**
```
Margin M = 200 USDT (all equity)
At 5× leverage: Notional = 200 × 5 = 1000 USDT
Quantity = 1000 / 50 = 20 contracts
Stop distance d = 100bp = 1.00%
Gross loss = 1000 × 0.01 = 10.00 USDT
Fees = 2 × 0.06% × 1000 = 1.20 USDT
Total risk = 10.00 + 1.20 + 0.50 + 0.30 = 12.00 USDT
As fraction of 200 equity: 12.00 / 200 = 6.00%
EXCEEDS 5% per-trade ceiling! → Risk engine would cap at 5% = 10 USDT budget.
Adjusted notional: 10 USDT budget / (d_eff / 10000 + costs) ≈ 10 / 0.0125 = 800 USDT
```

**Scenario C: 10 USDT risk budget**
```
Risk budget = 10 USDT (5% of 200 USDT equity)
Using RPC-GAP-01: d_effective = 100bp × 1.20 = 120bp
Notional = (E × r) / (d_eff / 10000) = (200 × 0.05) / (120 / 10000) = 10 / 0.012 = 833.33 USDT
Rounded to contracts: 833.33 / 50 = 16.67 → 16 contracts (round down to stepSize)
Actual notional: 16 × 50 = 800 USDT
Gross loss at stop: 800 × (100/10000) = 8.00 USDT
Gap buffer covers: 800 × (20/10000) = 1.60 USDT additional gap risk
Total modeled risk: 8.00 + 1.60 + 0.96 (fees) + 0.40 (spread) + 0.24 (slip) = 11.20 USDT
ACTUAL risk budget = 10 USDT → risk engine rejects (11.20 > 10)
```

**Revised with tighter stop (d = 80bp):**
```
d_eff = 80 × 1.20 = 96bp
Notional = 10 / (96/10000) = 10 / 0.0096 = 1041.67 USDT
Contracts = 1041.67 / 50 = 20.83 → 20 contracts
Actual notional = 1000 USDT
Gross loss at stop: 1000 × (80/10000) = 8.00 USDT
Gap buffer: 1000 × (16/10000) = 1.60 USDT
Costs: 1.20 (fees) + 0.50 (spread) + 0.30 (slip) = 2.00 USDT
Total risk: 8.00 + 1.60 + 2.00 = 11.60 USDT
Still > 10 USDT → risk engine reduces notional further.
```

**Final sizing iteration (enforce exact 5% = 10 USDT):**
```
Total risk = gross_loss + gap_buffer + costs
10 = N × (d/10000) + N × (d × 0.20/10000) + N × (2×0.0006 + 0.0005 + 0.0003)
10 = N × (d/10000 × 1.20 + 0.0022)
10 = N × (0.0080 × 1.20 + 0.0022)  [for d = 80bp]
10 = N × (0.0096 + 0.0022)
10 = N × 0.0118
N = 10 / 0.0118 = 847.46 USDT
Contracts = 847.46 / 50 = 16.95 → 16 contracts = 800 USDT notional
Verify: 800 × 0.0118 = 9.44 USDT < 10 USDT ✓ (within budget)
```

**This demonstrates:** the gap-risk buffer and costs significantly reduce the usable notional compared to the naive formula. The correct formula is:
```
N = budget / (d/10000 × 1.20 + total_cost_rate)
```
This replaces the simplified formula `N = (E × r) / (d / 10000)` from the previous design (F-003 and F-023 corrections).

### 3E.3 Example 2: Leverage does not multiply dollar P&L for fixed notional

**Scenario:** Same 500 USDT notional, different leverage levels.

| Leverage | Notional | Margin | Contracts (BTC) | Gross loss (d=100bp) | Gross profit (2:1 TP) | Net P&L (after 25bp costs) |
|---|---|---|---|---|---|---|
| 2× | 500 | 250 | 10 | −5.00 | +10.00 | −5.25 / +9.75 |
| 5× | 500 | 100 | 10 | −5.00 | +10.00 | −5.25 / +9.75 |
| 10× | 500 | 50 | 10 | −5.00 | +10.00 | −5.25 / +9.75 |

**Key insight:** Dollar P&L is determined by NOTIONAL and PRICE MOVEMENT, not by leverage. Leverage determines MARGIN REQUIRED and LIQUIDATION DISTANCE. Higher leverage = lower margin = less equity locked = closer liquidation, but same dollar P&L for the same notional.

**Liquidation distance (approximate, cross margin):**
| Leverage | Margin | Approximate liquidation distance |
|---|---|---|
| 2× | 250 | ~48% (1 − 1/2 + maintenance) |
| 5× | 100 | ~18% (1 − 1/5 + maintenance) |
| 10× | 50 | ~8% (1 − 1/10 + maintenance) |

At 5× leverage and 100bp stop distance, the stop triggers well before liquidation. DESIGN_JUDGMENT: SAFE.

### 3E.4 Example 3: Daily loss limit and drawdown interaction

**Scenario:** Starting equity 200 USDT. Three losing trades in a day, each at 5% per-trade risk (with gap buffer and costs, actual loss = 5.6 USDT per trade).

```
Trade 1: Loss 5.60 USDT → Equity: 194.40
Trade 2: Loss 5.60 USDT → Equity: 188.80
Trade 3: Loss 5.60 USDT → Equity: 183.20

Daily realized loss: 3 × 5.60 = 16.80 USDT
Daily loss limit (10% of start-of-day equity 200): 20.00 USDT
Daily loss budget remaining: 20.00 − 16.80 = 3.20 USDT

Drawdown check: peak = 200 (start), trough = 183.20, decline = 16.80
Drawdown limit (15% of initial 200): 30.00 USDT
Drawdown budget remaining: 30.00 − 16.80 = 13.20 USDT

After 4th trade (if loss 5.60): Daily loss = 22.40 > 20.00 → DAILY VETO TRIGGERS
Consecutive-loss counter: 4 (REDUCED state active since 3rd loss)
```

**This demonstrates:** the daily loss limit (10%) triggers BEFORE the drawdown limit (15%). The daily veto provides earlier intervention. The consecutive-loss breaker (REDUCED state at 3) provides even earlier intervention.

---

## 3F. Sensitivity Analysis (100–500 USDT)

### 3F.1 Position sizing at different equity levels

**Parameters:** r = 5% (ceiling), d = 100bp planned, d_eff = 120bp (gap buffer), costs = 22bp round-trip.
**Formula:** `N = budget / (d_eff/10000 + cost_rate) = (E × 0.05) / (0.0120 + 0.0022) = (E × 0.05) / 0.0142`

| Equity (USDT) | Budget (5%) | Max Notional | Leverage (N/E) | Gross loss (d=100bp) | Net loss (incl. costs) | Net as % of equity |
|---|---|---|---|---|---|---|
| 100 | 5.00 | 352.11 | 3.52× | 3.52 | 5.00 | 5.00% |
| 200 | 10.00 | 704.23 | 3.52× | 7.04 | 10.00 | 5.00% |
| 350 | 17.50 | 1232.39 | 3.52× | 12.32 | 17.50 | 5.00% |
| 500 | 25.00 | 1760.56 | 3.52× | 17.61 | 25.00 | 5.00% |

**Key finding:** The leverage ratio is constant at 3.52× for the same stop distance and cost structure. This is because the formula scales linearly with equity. The leverage is always `r / (d_eff/10000 + cost_rate)` = 0.05 / 0.0142 = 3.52. This is below the 5× ceiling at all equity levels. ✓

### 3F.2 Break-even analysis sensitivity

| Equity | Cost ratio (cost/budget) | Break-even win rate (1:2 R:R) | Min profitable trades/day |
|---|---|---|---|
| 100 | 0.44 (22bp / 5.00) | 36.5% | ~1.2 (to cover costs) |
| 200 | 0.44 | 36.5% | ~1.2 |
| 500 | 0.44 | 36.5% | ~1.2 |

The cost-to-budget ratio is constant across equity levels (same percentage costs). Break-even win rate is constant at 36.5% for the conservative scenario.

### 3F.3 Minimum viable equity

The minimum equity at which the system can operate depends on the minimum order size (from exchangeInfo, UNRESOLVED). Assuming a typical minimum of 5 USDT notional:

```
Minimum equity = minimum_notional / (r / (d_eff/10000 + cost_rate))
               = 5 / 3.52
               = 1.42 USDT (theoretical minimum)
```

But practical minimum is higher due to: (a) minimum contract quantity (1 contract = 50 USDT notional for BTC), (b) cost of multiple losing trades before the system halts.

**Practical minimum (DESIGN_JUDGMENT):**
```
Need to survive 3 consecutive losses without dropping below 1 contract minimum:
3 × 5% = 15% total loss
Remaining equity = 85% of starting
Remaining notional = 85% × starting × 3.52
Need: 85% × starting × 3.52 ≥ 50 (1 BTC contract)
starting ≥ 50 / (0.85 × 3.52) = 50 / 2.99 = 16.72 USDT
```

**Minimum viable equity ≈ 17 USDT (for BTC-SWAP-USDT).** For lower-priced symbols (e.g., DOGE at 0.10 USDT with multiplier 1), minimum contract is much lower. **UNRESOLVED: exact minimum order sizes require exchangeInfo.**

---

## 3G. Part 3/12 Completeness Declaration

**Part 3 declared scope:**
1. Evidence register (27 items: C-series + FP-series, with status classes) ✓
2. Canonical risk-policy catalog (RPC-DD-01 through RPC-CLASS-01) ✓
3. RPC interaction analysis (8 interactions per supplemental §1.7) ✓
4. Cost model (parametric, conservative, stress) ✓
5. Statistical framework (E[max(SR)], MinTRL, data coverage) ✓
6. Rate-limit budget calculation ✓
7. Worked risk examples (3 examples, 12 distinctions per §3.3) ✓
8. Sensitivity analysis (100–500 USDT) ✓

**Part 3 completeness:** All 8 scope items fully delivered. No content deferred. No prohibited compression (D21). Every item has: content, rationale, status, evidence pointer, and consequence (D20).

**Arithmetic verification:**
- E[max(SR)] at N=10: 0.5417 + 1.0327 = 1.574 ✓
- MinTRL at SR=0.8: 6.1827/0.64 × 1.0928 = 9.6605 × 1.0928 = 10.556 ✓
- Daily rate-limit budget: 3,750.8 / 4,320,000 = 0.087% ✓
- Sizing: 800 × 0.0118 = 9.44 < 10.00 ✓
- Leverage constant: 0.05 / 0.0142 = 3.52 ✓

**Deferred content:** NONE.
**D20 compliance:** ✓
**D21 compliance:** ✓
**D22 compliance:** ✓ (Part 3 of 12)

---

**وضعیت فارسی (Part 3/12):** ثبت شواهد (۲۷ مورد)، کاتالوگ سیاست ریسک (۸ مکانیزم اصلی)، مدل هزینه (۳ سناریو)، چارچوب آماری (E[max(SR)] = 1.574، MinTRL = 10.6 سال)، بودجه محدودیت نرخ API (0.087% مصرف)، مثال‌های کاربردی ریسک (۳ مثال با ۱۲ تمایز)، و تحلیل حساسیت (۱۰۰ تا ۵۰۰ USDT) تکمیل شد. نکته مهم: داده موجود فقط ۴۶% حداقل سابقه آماری موردنیاز را پوشش می‌دهد.

---


# Part 4/12 of 12: Clean-Sheet Architecture Reconstruction, Option Comparison, Phase Derivation, and Universe Derivation

**Part scope (Part 4):** (A) Clean-sheet requirements-driven architecture derivation (Pass C — derived from first principles, not from previous blueprint); (B) Consequential decision option comparison with declared criteria and positive derivation (D13); (C) Simplest credible baseline architecture; (D) Phase derivation per D16 with deviation disclosure table; (E) Universe derivation process per D14; (F) Intraday operational definition refinement.

---

## 4A. Clean-Sheet Architecture Derivation (Pass C)

### 4A.1 Methodology declaration

Per supplemental §4.2 (Independent baseline reconstruction): the previous architecture is visible in the same conversation context. This is therefore a **structured clean-sheet reconstruction**, not a genuinely blind review. The derivation below is constructed from requirements and evidence without copying the previous blueprint's component names, technology stack, assumptions, data model, or diagrams. Where the clean-sheet result converges with the previous design, convergence is noted honestly. Where it diverges, divergence is explained.

### 4A.2 Fundamental questions (per Pass C)

**Q1: What decisions must the system make, at what cadence, and using which admissible data?**

| Decision | Cadence | Data inputs | Authority |
|---|---|---|---|
| Enter LONG / SHORT / NO_TRADE | At close of each 1h bar (~3,600s) | 1h OHLCV (completed bars), 4h OHLCV (completed bars), risk state | Strategy proposes; risk engine approves |
| Exit (TP / SL / time / signal / forced) | Continuous (within bar) + at bar close | Current price, position state, risk state | Strategy/risk engine (TP/SL/forced); market (fill) |
| Position sizing | At entry signal | Equity, stop distance, risk limits, cost model | Risk engine (R-003) |
| Risk state transition | Continuous | Equity, PnL, position count, loss streaks | Risk engine (RPC) |
| Mode switch (Paper/Live) | On operator command | Operator input (Telegram) | Operator (via Telegram) |
| Reconciliation | Every 5 minutes | Exchange state vs local state | Reconciliation engine |
| Health check | Every 30–60 seconds | System metrics, feed status | Health monitor |

**Q2: What strategy/alpha hypothesis is being proposed, and what simple baseline tests incremental value?**

Candidate: dual-timeframe trend/momentum (R-029). Rationale: (a) intraday perpetual futures exhibit directional momentum that can be captured with trend-following; (b) 2–4 parameters fit the trial budget; (c) rule-based (no ML) is appropriate for limited data (C2/C24); (d) dual-timeframe separates noise (1h) from signal (4h).

Baseline for incremental-value testing: **B1 = single-timeframe (1h only) EMA crossover** (no 4h context filter). If S1 (dual-timeframe) does not outperform B1 (single-timeframe) in backtest, the complexity of dual-timeframe is not justified.

Second baseline: **B2 = buy-and-hold** (benchmark for absolute performance).

**Q3: What is the minimum state the system must own, and which state is authoritative?**

| State | Owner | Authoritative source |
|---|---|---|
| Open positions | Engine (position store) | Reconciled with Toobit (R-055) |
| Open orders | Engine (order store) | Reconciled with Toobit (R-055) |
| Equity / balance | Engine (equity tracker) | Toobit account endpoint (reconciled) |
| Risk state | Engine (risk store, R-023) | Engine (local, persisted) |
| Configuration | Engine (config manager) | Config file (validated, R-092) |
| Market data | Engine (data store) | Toobit API (REST + WS) |
| Strategy parameters | Engine (parameter store) | Parameter register (R-033) |
| Notification queue | Bot (notification store) | Bot (local, persisted) |
| Audit trail | Both (append-only logs) | Log files (append-only, R-093) |

**Q4: What needs synchronous correctness, what may be asynchronous, and which transitions must be durable before an external side effect?**

| Operation | Sync/Async | Durability requirement |
|---|---|---|
| Risk check before order | Synchronous | Must complete BEFORE API call |
| Order submission | Synchronous (send) | Write-ahead log BEFORE send (R-052) |
| Order fill processing | Asynchronous | Must persist fill event AFTER confirmation |
| Risk state transition | Synchronous | Must persist BEFORE notifying operator |
| Reconciliation | Asynchronous (periodic) | Results must persist |
| Market data ingestion | Asynchronous | Data must persist after quality check |
| Telegram notification | Asynchronous | Queue before send |
| Health check | Asynchronous | Results must persist |
| Configuration change | Synchronous | Must validate BEFORE apply; persist history |

**Q5: What are the true execution, rate-limit, data, storage, compute, device, and operational envelopes?**

| Envelope | Value | Source | Status |
|---|---|---|---|
| API weight | 3,000/min, 60 orders/2s | FP §2 | SOURCE_VERIFIED |
| API usage (daily) | ~3,751 weight = 0.087% of budget | Part 3 §3D | Calculated |
| Data volume (5yr) | ~300 MB | Part 3 | Calculated |
| CPU (daily) | < 10 min/day | Part 3 | Calculated |
| Storage | ~300 MB | Part 3 | Calculated |
| Network | ~250 MB/month | Part 3 | Calculated |
| Sustained runtime | 24/7 | C16 | BLOCKED (not measured) |
| Battery drain | Unknown | C16 | BLOCKED |
| Latency requirement | Minutes (bar-close driven) | Strategy cadence | DESIGN_JUDGMENT |

**Key insight:** The compute/storage/network envelopes are trivially satisfied. The binding constraint is sustained runtime (C16). Latency requirements are minutes (bar-close cadence), not microseconds. This rules out any latency-sensitive architecture.

**Q6: What are the natural component boundaries, and what evidence justifies each one?**

Component boundaries are derived from: (a) trust boundary (bot does not hold credentials; engine does not hold Telegram token — R-099); (b) state ownership (each component owns its state); (c) failure isolation (component failure should not cascade); (d) deployment flexibility (engine and bot may run on different machines).

**Q7: What is the simplest credible architecture, and what materially more complex candidates add enough value?**

This is answered by the option comparison below (§4B).

---

## 4B. Consequential Decision Option Comparison

### Decision 1: Process Topology

**Criteria (declared before scoring):**
1. Security/trust isolation (1–5)
2. Failure isolation (1–5)
3. Deployment flexibility (1–5)
4. Implementation complexity (5=very simple)
5. Suitability for 24/7 on mobile (1–5)

**Options:**

| Option | Description | Security | Failure | Deploy | Simplicity | Mobile | Total |
|---|---|---|---|---|---|---|---|
| T1: Single process | Engine + bot in one process | 2 | 2 | 3 | 5 | 4 | 16 |
| T2: Two processes (engine + bot) | Separate processes, message-passing | 5 | 5 | 5 | 3 | 3 | 21 |
| T3: Three+ microservices | Engine, risk, bot, data, etc. | 5 | 5 | 5 | 1 | 1 | 17 |

**Evaluation:**
- **T1:** Simplest to implement and deploy. But: bot compromise exposes credentials; bot crash kills engine; cannot deploy separately. Violates R-099 (trust boundary).
- **T2:** Trust boundary enforced (R-099). Bot crash does not kill engine. Can deploy bot on cloud and engine on phone (or vice versa). Moderate complexity (message-passing interface).
- **T3:** Maximum isolation. But: microservice overhead is unjustified for a single-symbol, 1–3 position system. Complexity exceeds benefit per D12/D18.

**Decision: T2 (two processes).** Positive derivation: R-099 (trust boundary) requires process isolation. T2 satisfies this with minimal complexity. T3 adds unjustified complexity. T1 violates R-099.

**Convergence with previous design:** Yes (previous design also selected T2). **Divergence:** None.

---

### Decision 2: Programming Language and Runtime

**Criteria:**
1. Numerical/data library ecosystem (1–5)
2. Exchange API compatibility (1–5)
3. Mobile/Termux support (1–5)
4. Development speed (1–5)
5. Runtime reliability for 24/7 (1–5)
6. Memory efficiency (5=very efficient)

**Options:**

| Option | Libraries | API | Mobile | Dev speed | Reliability | Memory | Total |
|---|---|---|---|---|---|---|---|
| L1: Python 3.x (numpy/pandas/pyarrow) | 5 | 5 | 5 | 5 | 3 | 3 | 26 |
| L2: Node.js (TypeScript) | 3 | 4 | 4 | 4 | 4 | 4 | 23 |
| L3: Go | 3 | 3 | 3 | 3 | 5 | 5 | 22 |
| L4: Rust | 2 | 2 | 2 | 2 | 5 | 5 | 18 |

**Evaluation:**
- **L1:** Best ecosystem for quant/data work (numpy, pandas, pyarrow). CCXT and most exchange examples are Python. Runs on Termux (confirmed general knowledge). Moderate memory usage. Reliability: Python has garbage collection pauses and memory leaks over long runs (a known concern for 24/7 processes).
- **L2:** Good for bot (Telegram). Weaker numerical ecosystem. Node.js event loop is efficient for I/O but not for computation. Termux support is good.
- **L3:** Excellent for long-running services (goroutines, low memory). Weaker numerical ecosystem (no numpy equivalent). Termux support exists but less tested.
- **L4:** Best performance/reliability. But: development speed is low; numerical ecosystem is weakest; Termux support is present but niche.

**Decision: L1 (Python 3.x) for the engine; L1 for the bot (same language simplifies shared types and message schemas).** Positive derivation: the system's core work is data processing (pandas/numpy) and exchange API interaction (Python has the richest examples). Termux support is confirmed. The 24/7 reliability concern is mitigated by the two-process architecture (bot detects engine death) and by the planned migration to cloud (D3) for production. L2/L3/L4 add implementation complexity without material benefit for this system's workload (minutes-latency, ~3,750 API calls/day).

**Convergence with previous design:** Yes (previous selected Python). **Divergence:** None.

---

### Decision 3: Data Ingestion

**Criteria:**
1. Data freshness (1–5)
2. Reliability (1–5)
3. Rate-limit efficiency (5=efficient)
4. Implementation complexity (5=simple)
5. Gap handling (5=good gap handling)

**Options:**

| Option | Freshness | Reliability | Rate limits | Simplicity | Gaps | Total |
|---|---|---|---|---|---|---|
| DI1: REST polling only (at bar close + periodic) | 3 | 5 | 3 | 5 | 3 | 19 |
| DI2: WebSocket primary + REST fallback | 5 | 3 | 5 | 2 | 4 | 19 |
| DI3: WebSocket only | 5 | 2 | 5 | 3 | 2 | 17 |
| DI4: Hybrid (WS for live, REST for historical + gap repair) | 5 | 4 | 5 | 3 | 5 | 22 |

**Evaluation:**
- **DI1:** Simplest. Data is fetched every N seconds via REST polling. Freshness depends on polling interval. Rate-limit consumption is moderate (frequent polling). Gap handling requires explicit gap detection.
- **DI2:** WebSocket provides real-time push. But: WS is less reliable (disconnects); REST fallback needed. More complex.
- **DI3:** WS only. No REST fallback. Unreliable for 24/7 (WS disconnects are inevitable).
- **DI4:** WS for real-time data (kline updates, trade stream). REST for historical data (kline backfill), gap repair, and as fallback when WS is down. Best of both: freshness of WS, reliability of REST, good gap handling.

**Decision: DI4 (hybrid: WS primary, REST fallback + historical).** Positive derivation: the strategy's cadence is bar-close (minutes), so WS push is more efficient than polling (fewer REST calls). But WS is unreliable for 24/7 (heartbeat, disconnect detection per R-044), so REST fallback is essential. REST is also needed for historical data (backtest, gap repair). DI4 provides freshness (WS), reliability (REST fallback), rate-limit efficiency (WS has no weight cost), and gap handling (REST repair).

**Convergence with previous design:** Partial (previous used REST polling — DI1 — as "D-COM1"). **Divergence:** Previous used REST-only. The clean-sheet derivation favors WS+REST hybrid because: (a) FP §11 confirms WS topics including kline and trade streams; (b) WS has no REST weight cost, saving rate-limit budget; (c) the strategy's bar-close cadence is well-served by WS push. The previous design's REST-only choice was a DESIGN_JUDGMENT based on simpler implementation. The clean-sheet analysis shows WS+REST is better despite moderate complexity increase.

---

### Decision 4: Strategy Family

**Criteria:**
1. Fit for intraday perpetual futures (1–5)
2. Parameter count vs trial budget (5=within budget)
3. Robustness to regime change (1–5)
4. Interpretability (1–5)
5. Backtest validity with limited data (5=valid)

**Options:**

| Option | Fit | Params | Robust | Interpretable | Backtest | Total |
|---|---|---|---|---|---|---|
| S1: Rule-based dual-timeframe trend/momentum | 4 | 5 | 3 | 5 | 3 | 20 |
| S2: Rule-based mean-reversion | 3 | 5 | 2 | 5 | 3 | 18 |
| S3: ML-based (random forest / gradient boosting) | 3 | 1 | 2 | 2 | 1 | 9 |
| S4: Factor-based (multi-factor scoring) | 3 | 1 | 3 | 3 | 1 | 11 |

**Evaluation:**
- **S1:** Trend/momentum is well-suited for perpetual futures (trending behavior, funding cost alignment). Dual-timeframe filters noise. 12 parameters but only 2–4 are tunable (others are fixed structural). Rule-based → interpretable. Limited data → moderate backtest validity (3,302 independent samples at 4h).
- **S2:** Mean-reversion works in ranging markets but is risky in trending markets (which are common in perpetual futures). Similar parameter count.
- **S3:** ML requires more data than available (C2: 1,774 daily bars). C24 prohibits exhaustive grid search. Black-box → not interpretable. HIGH overfitting risk.
- **S4:** Multi-factor scoring requires more data for factor analysis. Not justified by trial budget.

**Decision: S1 (dual-timeframe trend/momentum).** Positive derivation: (a) trend/momentum fits perpetual futures behavior; (b) parameter count within trial budget; (c) rule-based provides interpretability (required for audit and debugging); (d) limited data rules out ML (C24). S2 is the fallback if S1 fails backtest (documented in R-029).

**Convergence with previous design:** Yes (previous selected S1). **Divergence:** None.

---

### Decision 5: Data Store

**Criteria:**
1. Query performance for time-series (1–5)
2. Append-only audit compatibility (5=compatible)
3. Mobile/Termux compatibility (1–5)
4. Implementation complexity (5=simple)
5. Storage efficiency (5=efficient)

**Options:**

| Option | Time-series | Append-only | Mobile | Simplicity | Storage | Total |
|---|---|---|---|---|---|---|
| DS1: SQLite + JSONL + Parquet | 4 | 5 | 5 | 4 | 4 | 22 |
| DS2: PostgreSQL / TimescaleDB | 5 | 4 | 2 | 2 | 4 | 17 |
| DS3: InfluxDB / time-series DB | 5 | 3 | 2 | 2 | 5 | 17 |
| DS4: Flat files only (JSONL + CSV) | 2 | 5 | 5 | 5 | 3 | 20 |

**Evaluation:**
- **DS1:** SQLite for relational data (orders, positions — needs SQL queries). JSONL for append-only audit logs (signals, risk decisions, events). Parquet for market data (columnar, compressed, efficient). All three run on Termux (confirmed general knowledge). No server process needed.
- **DS2:** PostgreSQL is powerful but requires a server process (heavyweight for mobile). TimescaleDB extension adds time-series support. Overkill for single-symbol, 1–3 positions.
- **DS3:** InfluxDB is purpose-built for time-series but requires a server process. Not suitable for mobile.
- **DS4:** Flat files are simplest but lack query capability (no SQL joins). Order/position queries would require manual scanning.

**Decision: DS1 (SQLite + JSONL + Parquet).** Positive derivation: (a) SQLite provides relational queries for orders/positions (needed for reconciliation); (b) JSONL provides append-only audit trail (R-093); (c) Parquet provides efficient market data storage (compression, columnar access for backtesting); (d) all run on mobile without a server process. DS2/DS3 require server processes (not mobile-friendly). DS4 lacks query capability.

**Convergence with previous design:** Yes (previous selected same). **Divergence:** None.

---

### Decision 6: Execution Mode

**Criteria:**
1. Speed of response to signals (1–5)
2. Operator control (5=high control)
3. Consistency (5=consistent)
4. Overnight coverage (5=good)
5. Safety (risk of fat-finger) (5=safe)

| Option | Speed | Control | Consistent | Overnight | Safe | Total |
|---|---|---|---|---|---|---|
| E1: Fully automated | 5 | 2 | 5 | 5 | 3 | 20 |
| E2: Semi-automated (confirm entry via Telegram) | 3 | 5 | 3 | 2 | 5 | 18 |
| E3: Manual (all orders via Telegram) | 1 | 5 | 1 | 1 | 4 | 12 |

**Evaluation:**
- **E1:** Fastest response. Consistent. Covers overnight. But: less operator control. Fat-finger risk is mitigated by risk engine (R-022). The risk engine is the gate (not advisory), so even full automation is bounded by hard limits.
- **E2:** Operator confirms each entry. High control but slow (operator must be available). Does not work overnight (operator sleeping).
- **E3:** All manual. Inconsistent. Does not work overnight. Not viable for intraday.

**Decision: E1 (fully automated).** Positive derivation: (a) intraday requires fast response (minutes, not hours); (b) the risk engine bounds all automated actions (R-022); (c) semi-automated fails overnight coverage; (d) the Telegram interface provides monitoring and override capability. The risk engine is the safety mechanism; automation is the execution mechanism.

**Convergence with previous design:** Yes (previous selected E1). **Divergence:** None.

---

### Decision 7: Adaptation / Optimization

**Criteria:**
1. Safety (no autonomous risk changes) (5=safe)
2. Data sufficiency (5=sufficient data for adaptation)
3. Complexity (5=simple)
4. Regulatory/audit clarity (5=clear)

| Option | Safe | Data | Simple | Clear | Total |
|---|---|---|---|---|---|
| AD1: No autonomous adaptation (manual recalibration only) | 5 | 5 | 5 | 5 | 20 |
| AD2: Automated parameter optimization (periodic) | 2 | 2 | 2 | 3 | 9 |
| AD3: ML-based regime detection + parameter switching | 1 | 1 | 1 | 2 | 5 |

**Evaluation:**
- **AD1:** No autonomous changes. Operator manually adjusts parameters via Telegram (R-033: tunable parameters within bounds). Safest. Simplest. Clearest audit trail. Consistent with D-RISK-2 ("No optimizer... may relax this ceiling").
- **AD2:** Automated optimization could improve performance but introduces overfitting risk (C24), audit complexity, and potential interaction with risk limits.
- **AD3:** ML-based regime detection is the most complex and least safe. Data insufficient (C2). D-RISK limits must not be self-adjusting.

**Decision: AD1 (no autonomous adaptation).** Positive derivation: (a) safety is paramount (D-RISK-2); (b) data is insufficient for reliable autonomous adaptation (C2, C24); (c) simplicity reduces bug surface; (d) audit clarity is required. Any optimization is offline (research phase) with operator approval.

**Convergence with previous design:** Yes (previous: "ZERO autonomous mechanisms"). **Divergence:** None.

---

### Decision 8: Deployment Topology (initial enumeration per D15)

**Criteria:**
1. 24/7 reliability (1–5)
2. Mobile independence (5=fully independent)
3. Cost (5=free)
4. Implementation simplicity (5=simple)
5. Security (5=secure)

| Option | 24/7 | Mobile-independent | Cost | Simple | Secure | Total |
|---|---|---|---|---|---|---|
| D1: All on phone (Termux) | 2 | 1 | 5 | 5 | 3 | 16 |
| D2: Two processes on phone (T2 topology) | 3 | 1 | 5 | 4 | 4 | 17 |
| D3: Dev on phone, Paper+Live on cloud | 5 | 5 | 3 | 3 | 4 | 20 |
| D4: All on cloud (VPS) | 5 | 5 | 3 | 3 | 4 | 20 |
| D5: Engine on cloud, bot on phone | 4 | 3 | 3 | 3 | 4 | 17 |
| D6: Engine on phone, bot on cloud | 3 | 3 | 3 | 3 | 3 | 15 |

**Evaluation:**
- **D1:** Free, simple. But: 24/7 on phone is unreliable (Android process kills, battery drain, thermal throttling, C16 BLOCKED). Mobile-dependent.
- **D2:** T2 process isolation on phone. Better security than D1. Still mobile-dependent.
- **D3:** Development/backtest on phone (P1/P2). Paper/Live on cloud (P3/P4). Phone for development convenience; cloud for reliability. Cost: VPS ~5–10 USDT/month (DESIGN_JUDGMENT).
- **D4:** All on cloud. Most reliable. No phone dependency. Cost: VPS. Requires cloud setup (not phone-friendly).
- **D5:** Engine (critical) on cloud; bot (less critical) on phone. Hybrid.
- **D6:** Engine on phone; bot on cloud. Engine is the critical component — should not be on phone.

**Decision (per D15 envelope-first process):**
1. **Step 1 (derive envelope):** Compute/storage/network trivially satisfied (Part 3). Binding constraint: sustained runtime (C16, BLOCKED).
2. **Step 2 (measure device):** C16 BLOCKED in this engagement. Cannot proceed to step 3.
3. **Step 3 (match):** BLOCKED pending measurement.
4. **Step 4a (compromise):** Cannot yet apply — must enumerate all topologies first.
5. **Step 4b (enumerate):** D1–D6 above. D3 and D4 score highest (both 20).
6. **Step 5 (apply compromise order):** Owner's compromise order is: phone-first if feasible, cloud as fallback. But C16 is BLOCKED.

**Recommendation:** **D1→D3 phased transition.** Phase 1–2 (Research, Integration): D1 (all on phone) — development is interactive, not 24/7. Phase 3–4 (Paper, Live): D3 (cloud) — 24/7 operation requires cloud reliability. **Objective transition criteria** (from previous design, retained): (a) battery drain > 20%/hour → D3; (b) uptime < 95% → D3; (c) battery ≤ 5%/hour AND uptime ≥ 99% → stay D1. If C16 measurement confirms phone can sustain 24/7, stay on D1 (D2 with process isolation).

**Convergence with previous design:** Yes (previous recommended D1→D3). **Divergence:** None. Previous also enumerated 6 topologies (D1–D6).

---

### Decision 9: Timeframe Structure

**Criteria:**
1. Data sufficiency (5=sufficient)
2. Signal quality (5=high quality)
3. Trial budget fit (5=within budget)
4. Alignment with intraday intent (5=aligned)
5. Complexity (5=simple)

| Option | Data | Signal | Budget | Intraday | Simple | Total |
|---|---|---|---|---|---|---|
| TF1: Single (1h) | 3 | 3 | 5 | 4 | 5 | 20 |
| TF2: Dual (1h entry + 4h context) | 4 | 5 | 4 | 5 | 3 | 21 |
| TF3: Triple (1h + 4h + 1d) | 4 | 5 | 3 | 5 | 2 | 19 |

**Evaluation:**
- **TF1:** Simplest. 1h provides 3,500 bars = 146 days (PROVISIONAL). Enough for 2–4 parameter trial budget. But: no context filter (noisy).
- **TF2:** 1h for entry timing, 4h for trend direction. Better signal quality (context filters noise). 4h provides 3,500 bars = 583 days. Still within trial budget.
- **TF3:** Adds 1d for macro trend. More context but adds complexity. 1d provides 1,774 bars (4.86 years). But: 1d data may not improve intraday signals materially.

**Decision: TF2 (dual: 1h entry + 4h context).** Positive derivation: (a) dual-timeframe improves signal quality (context filter); (b) 4h data (583 days) is sufficient for parameter selection within trial budget; (c) 1d context adds complexity without material benefit (1h/4h already captures intraday dynamics). TF3 is the previous design's choice (TF3) but the clean-sheet analysis shows TF2 is sufficient — 1d reference does not materially improve intraday signal quality (DESIGN_JUDGMENT: the marginal information from 1d is already captured by 4h trend).

**Convergence with previous design:** Partial (previous selected TF3 = 1h+4h+1d). **Divergence:** Clean-sheet selects TF2 (1h+4h). Rationale for divergence: 1d reference adds data-fetching complexity (third timeframe) without material signal improvement. The 1d data can be used in Phase 1 research for additional analysis but is not required for the live signal generation. This is a MODERATE divergence (removing one data stream).

**Revision impact:** If the owner or Phase 1 research finds 1d adds value, adding it back is a low-cost change (data collector already supports multiple timeframes). The architecture is designed to support 1–3 timeframes flexibly.

---

## 4C. Simplest Credible Baseline Architecture (B-Arch)

The simplest architecture satisfying all HARD requirements:

```
┌─────────────────────────────────────────────────────────────┐
│                        POCO X6 (Termux)                     │
│                                                             │
│  ┌──────────────────────┐    ┌───────────────────────────┐  │
│  │   ENGINE PROCESS     │    │      BOT PROCESS          │  │
│  │                      │    │                           │  │
│  │  ┌────────────────┐  │    │  ┌─────────────────────┐  │  │
│  │  │ Data Collector  │◄─┼────┼──│  Telegram Adapter   │  │  │
│  │  │ (WS + REST)     │  │    │  │  (Long Polling)     │  │  │
│  │  └───────┬────────┘  │    │  └──────────┬──────────┘  │  │
│  │          │            │    │             │             │  │
│  │  ┌───────▼────────┐  │ UDS│  ┌──────────▼──────────┐  │  │
│  │  │ Data Store      │  │◄───┼──│  Command Dispatcher │  │  │
│  │  │ (SQLite/JSONL/  │  │    │  │  + Notification     │  │  │
│  │  │  Parquet)       │  │    │  │    Store            │  │  │
│  │  └───────┬────────┘  │    │  └─────────────────────┘  │  │
│  │          │            │    │                           │  │
│  │  ┌───────▼────────┐  │    │                           │  │
│  │  │ Strategy Engine │  │    │                           │  │
│  │  │ (Signal Gen)    │  │    │                           │  │
│  │  └───────┬────────┘  │    │                           │  │
│  │          │            │    │                           │  │
│  │  ┌───────▼────────┐  │    │                           │  │
│  │  │ Risk Engine     │  │    │                           │  │
│  │  │ (RPC, Gate)     │  │    │                           │  │
│  │  └───────┬────────┘  │    │                           │  │
│  │          │            │    │                           │  │
│  │  ┌───────▼────────┐  │    │                           │  │
│  │  │ Order Manager   │  │    │                           │  │
│  │  │ + OMS           │  │    │                           │  │
│  │  └───────┬────────┘  │    │                           │  │
│  │          │            │    │                           │  │
│  │  ┌───────▼────────┐  │    │                           │  │
│  │  │ Exchange Client │  │    │                           │  │
│  │  │ (Toobit API)    │  │    │                           │  │
│  │  └────────────────┘  │    │                           │  │
│  │                      │    │                           │  │
│  │  ┌────────────────┐  │    │                           │  │
│  │  │ Health Monitor  │  │    │                           │  │
│  │  │ + Alert Manager │  │    │                           │  │
│  │  └────────────────┘  │    │                           │  │
│  │                      │    │                           │  │
│  │  ┌────────────────┐  │    │                           │  │
│  │  │ Config Manager  │  │    │                           │  │
│  │  └────────────────┘  │    │                           │  │
│  └──────────────────────┘    └───────────────────────────┘  │
│                                                             │
│  ┌──────────────────────────────────────────────────────┐   │
│  │                   Data Store (shared)                 │   │
│  │   SQLite (orders, positions) | JSONL (logs) | Parquet│   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

**Components (12 in baseline; detailed in Part 5):**

| # | Component | Process | Responsibility |
|---|---|---|---|
| 1 | Data Collector | Engine | WS + REST data ingestion, heartbeat, gap repair |
| 2 | Data Store | Shared | SQLite + JSONL + Parquet storage |
| 3 | Strategy Engine | Engine | Signal generation (S1 rules) |
| 4 | Risk Engine | Engine | RPC enforcement, gate, state management |
| 5 | Order Manager | Engine | Order state machine, write-ahead logging |
| 6 | Exchange Client | Engine | Toobit API (signing, rate limiting, requests) |
| 7 | Reconciliation Engine | Engine | Periodic state comparison with Toobit |
| 8 | Health Monitor | Engine | 12 health checks |
| 9 | Alert Manager | Engine | 30 alert types |
| 10 | Config Manager | Engine | Config schema validation, history |
| 11 | Telegram Adapter | Bot | Telegram API (long polling) |
| 12 | Command Dispatcher | Bot | Command parsing, confirmation, notification store |

**Why 12 components and not more?** Each component maps to a distinct responsibility boundary (state ownership, failure isolation, trust boundary). Adding more components (e.g., separate risk engine service, separate data service) adds complexity without material benefit for a single-symbol, 1–3 position system (D12/D18). The component count is derived from responsibility boundaries, not from institutional-trading templates.

**Why not fewer?** Combining any two of these components would violate at least one of: (a) trust boundary (bot ≠ engine), (b) state ownership (each component owns its state), (c) failure isolation (risk engine must be independent — R-022).

---

## 4D. Phase Derivation (D16)

### 4D.1 Phase derivation from risks and verification dependencies

Phases are derived from the risks and verification dependencies, not from owner vocabulary. The key risks requiring phased verification:

| Risk | Phase needed to address |
|---|---|
| Strategy does not work (backtest failure) | Phase 1 (research) |
| Data quality insufficient | Phase 1 (research) |
| Exchange API does not work as expected | Phase 2 (integration) |
| Risk engine has bugs | Phase 2 (integration) |
| Phone cannot sustain 24/7 (C16) | Phase 2 (integration, measurement) |
| Paper simulation diverges from live | Phase 3 (paper) |
| Live operation reveals unmodeled risks | Phase 4 (live) |

### 4D.2 Derived phases

**Phase 1: Research and Backtest (P1)**
- Objective: Validate strategy S1 (or reject it) using historical data.
- Activities: Data collection (historical klines), backtesting (S1 vs B1 vs B2), parameter selection (coordinate descent + BH correction), cost model validation, statistical framework application.
- Success criteria: S1 outperforms B1 and B2 in holdout. Selected parameters exceed noise floor after BH correction. Or: S1 is rejected, S2 evaluated.
- Phase exit: Strategy validated (or rejected with documented findings). Parameters registered. Historical data quality documented.
- No live orders. No Paper orders. Research mode only. Cross-venue data allowed.
- Risks addressed: strategy effectiveness, data quality, statistical validity.

**Phase 2: Integration and Verification (P2)**
- Objective: Verify that the system components work together correctly against Toobit's API.
- Activities: Engine + bot integration testing. Exchange API integration (public endpoints only — no authenticated calls in this design engagement, but implementation would test authenticated calls with minimal permissions). C16 measurement (phone sustained runtime). State machine testing. Reconciliation testing. Risk engine testing. Security testing (credential handling).
- Success criteria: All 102 requirements pass verification (or are marked UNRESOLVED with safe fallback). C16 measured. All six interlocks verifiable.
- Phase exit: System verified for Paper mode entry.
- No live orders. Integration tests use Toobit public endpoints + mock authenticated endpoints.
- Risks addressed: API compatibility, component integration, device feasibility.

**Phase 3: Paper Operation (P3)**
- Objective: Validate system behavior with real-time market data and simulated execution.
- Activities: Paper trading with real-time Toobit market data. Simulated fills. Monitor all health checks, alerts, risk limits. Measure uptime, battery, performance.
- Success criteria: All six interlocks pass. System runs without manual intervention for a sustained period (operator-defined; there is NO arbitrary wait requirement per R-078). Performance metrics within design targets (R-095).
- Phase exit: Operator elects to switch to Live (via Telegram, with interlock checks).
- No real orders. Paper simulation only. Cross-venue data restricted (firewall active).
- Risks addressed: operational readiness, risk engine behavior, Paper→Live transition.

**Phase 4: Live Operation (P4)**
- Objective: Trade with real capital within hard risk limits.
- Activities: Live trading on Toobit. All risk limits active. All interlocks continuously monitored. All audit logging active.
- Success criteria: System operates within risk limits. No uncontrolled risk events.
- Phase exit: N/A (ongoing).
- Real orders. All safety mechanisms active.
- Risks addressed: real-market execution, real risk management.

### 4D.3 Phase deviation disclosure (D16)

| Original owner vocabulary | Derived phase(s) | Deviation | Rationale |
|---|---|---|---|
| "Backtesting" | P1 | None | Maps 1:1 |
| "Paper Trading" | P3 | None | Maps 1:1 |
| "Live Trading" | P4 | None | Maps 1:1 |
| — | P2 (Integration) | ADDED | Required by verification dependencies (API compatibility, C16, component integration) — not in owner vocabulary but derived from risks |

**Deviations:** 1 (Phase 2 added). This is a derived phase, not an owner-specified phase. It exists because integration risks (API compatibility, C16, component testing) must be addressed before Paper operation.

---

## 4E. Universe Derivation Process (D14)

### 4E.1 D14 process

The universe is derived through the following process (D14 from original prompt):

**Step 1: Candidate discovery.** Fetch all available perpetual futures from `/api/v1/exchangeInfo` at runtime. This is the authoritative source (FP §10: "The full current list must be fetched at runtime from /api/v1/exchangeInfo"). The Fact Pack partial list (32 symbols) is NOT the universe.

**Step 2: Filter application (D14 criteria).**

| Filter | Criterion | Source | Status |
|---|---|---|---|
| F1: Liquidity | 24h volume > threshold (1M USDT, DESIGN_JUDGMENT) | General knowledge | DESIGN_JUDGMENT |
| F2: Spread | Average spread < 20bp (DESIGN_JUDGMENT) | General knowledge | DESIGN_JUDGMENT |
| F3: Volatility | 24h ATR/price > 0.5% (DESIGN_JUDGMENT) | General knowledge | DESIGN_JUDGMENT |
| F4: History | ≥ 3,500 1h bars available (R-040) | C2, FP §5 | PROVISIONAL |
| F5: Contract spec | minQty, stepSize, tickSize available | FP §9 | SOURCE_VERIFIED (endpoint) |
| F6: Leverage | Exchange max ≥ 5× (D-RISK-6) | FP §8 | PROVISIONAL |

**Step 3: Symbol selection.** Symbols passing ALL filters form the tradable universe. For the initial implementation, the system trades ONE symbol at a time (single-symbol focus — DESIGN_JUDGMENT: simplifies monitoring on mobile).

**Step 4: Runtime validation.** At startup, the system validates the selected symbol against current exchangeInfo filters (R-046). If the symbol no longer meets criteria, it is removed from the universe and an alert is generated.

### 4E.2 C19 measurement set

The 10 symbols in C19 (BTC, ETH, SOL, BNB, XRP, ADA, DOGE, AVAX, LINK, LTC) are a **measurement set** (used in the original prompt's Phase 0 measurements), NOT a universe recommendation. They are incidental candidates — if they survive the D14 filters, they may be included. Per supplemental §2 item 7: "The ten C19 measurement symbols are not a universe recommendation or candidate list."

---

## 4F. Intraday Operational Definition (refined from R-032)

**Definition:** Intraday = maximum holding period of 24 hours (3 funding periods at 8h intervals), or until an exit condition triggers, whichever is first.

**Derivation (D13 — positive reason):**
1. The strategy uses 4h context and 1h entry. A typical trend captured by 4h EMA crossover lasts 2–8 bars (8–32 hours). A 24-hour cap captures the majority of these trends.
2. Funding tail risk (R-012): holding for 3 funding periods (24h) limits exposure to 3 funding events. Each event has a tail risk (stress: 200bp). Total tail exposure: 600bp = 6% of notional. This is manageable within the 5% per-trade risk budget when combined with the stop-loss.
3. UTC day boundary (R-015): 24h holding aligns with the daily loss accounting period. Positions do not span multiple UTC days, simplifying daily PnL attribution.
4. Overnight gap risk: holding overnight (while not monitoring) increases gap risk. A 24h cap means some positions will be held overnight, but the stop-loss (exchange-side if supported) provides protection.

**Consequence:** If the strategy generates a signal at 23:00 UTC, the position will be held until at most 23:00 UTC the next day. If the daily loss veto triggers at 01:00 UTC, existing positions remain open (risk-reducing actions allowed) but no new positions are opened until 00:00 UTC the next day.

---

## 4G. Part 4/12 Completeness Declaration

**Part 4 declared scope:**
1. Clean-sheet architecture derivation (Pass C, 7 fundamental questions) ✓
2. Consequential decision option comparison (9 decisions, ≥2 options each) ✓
3. Simplest credible baseline architecture (B-Arch, 12 components) ✓
4. Phase derivation (D16, 4 phases, deviation table) ✓
5. Universe derivation process (D14, 4 steps, 6 filters) ✓
6. Intraday operational definition (refined) ✓

**Part 4 completeness:** All 6 scope items fully delivered. 9 architectural decisions evaluated with declared criteria, ≥2 options each, positive derivation (D13), and honest convergence/divergence notes. No content deferred. No prohibited compression (D21).

**Convergence/divergence summary:**
| Decision | Previous | Clean-sheet | Convergence? |
|---|---|---|---|
| Process topology | T2 | T2 | Yes |
| Language | Python | Python | Yes |
| Data ingestion | REST polling (DI1) | WS+REST hybrid (DI4) | **DIVERGENCE** (upgrade) |
| Strategy | S1 | S1 | Yes |
| Data store | SQLite+JSONL+Parquet | Same | Yes |
| Execution | Full auto | Full auto | Yes |
| Adaptation | None | None | Yes |
| Deployment | D1→D3 | D1→D3 | Yes |
| Timeframes | TF3 (1h+4h+1d) | TF2 (1h+4h) | **DIVERGENCE** (simplify) |

**Deferred content:** NONE.
**D20 compliance:** ✓
**D21 compliance:** ✓
**D22 compliance:** ✓ (Part 4 of 12)

---

**وضعیت فارسی (Part 4/12):** بازسازی معماری از صفر تکمیل شد. ۹ تصمیم معماری با گزینه‌های مختلف مقایسه شد. نتیجه: معماری دو پروسه‌ای با پایتون، ترکیب WebSocket + REST برای داده‌ها (بهبود نسبت به طراحی قبلی)، استراتژی روند/شتاب دو بازه‌ای، ذخیره‌سازی SQLite + JSONL + Parquet. ۴ فاز مشتق شد (تحقیق → یکپارچه‌سازی → کاغذی → واقعی). فاز ۲ (یکپارچه‌سازی) جدید است و از ریسک‌ها مشتق شده. دو انحراف از طراحی قبلی: (۱) بهبود به WebSocket+REST، (۲) ساده‌سازی به دو بازه زمانی (حذف 1d).

---


xxx