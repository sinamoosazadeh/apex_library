# Revised Trading-System Design Package

## Part 1/6 — Capability Inventory, Offline Pre-Review Checkpoint, D-RISK Canonical Risk Policy Catalog, and Requirements Register

**Part plan (6 parts):**

| Part | Scope |
|---|---|
| 1/6 | Capability inventory, offline pre-review checkpoint, D-RISK canonical risk policy catalog, Requirements Register (all requirements, 11 fields) |
| 2/6 | Clean-sheet architecture derivation, strategy specification, data design, cross-venue firewall |
| 3/6 | Component architecture, order lifecycle/state machine (corrected Toobit API), risk design with D-RISK hard limits |
| 4/6 | Execution/OMS, reconciliation, Telegram interface, security and operations |
| 5/6 | Deployment topology (D15), phase structure (D16), test strategy, verification plan |
| 6/6 | Forensic audit findings, adversarial red-team, verification matrix, completeness declaration, 7-dimension status, V-1–V-12, Artifact Registry, change-propagation table, Persian final note |

**Length-check method:** Each part is a self-contained deliverable with its own completeness statement. Cross-references use `Part N §X` notation. No part defers material content to a later part without an explicit forward reference and the later part actually delivering it.

---

## §0 Capability Inventory and Offline Pre-Review Checkpoint

### §0.1 Capability Inventory (Pass A)

| Capability | Status | Detail |
|---|---|---|
| Complete original master prompt (2 parts) | AVAILABLE IN CONVERSATION | Delivered in prior messages; all C/A/D/E/P/G/T-C/V identifiers, ratified findings, and design principles are in context. |
| Complete previous blueprint (Parts 1–6) | AVAILABLE IN CONVERSATION | All 6 parts delivered in prior messages; all components, tables, formulas, state machines, and registers are in context. |
| Supplemental directive (this prompt) | AVAILABLE IN CONVERSATION | Full text received. |
| TOOBIT FACT PACK | AVAILABLE IN CONVERSATION | 13 sections, all items with status labels, received verbatim. |
| Internet / web access | NOT AVAILABLE IN THIS SESSION | Arena.ai Direct mode. No browsing, no URL resolution, no HTTP/HTTPS calls. |
| Remote API calls (Toobit, Telegram) | NOT AVAILABLE IN THIS SESSION | Prohibited by engagement boundary. |
| Local code execution / calculator | NOT OBSERVED | No code interpreter, shell, or calculator tool is visibly exposed in this conversation. All calculations are manual and shown step-by-step. |
| Filesystem access / file creation | NOT OBSERVED | No file-creation or file-reading tool is visibly exposed. |
| Independent reviewer / second model | NOT AVAILABLE IN THIS SESSION | Single-model session. Adversarial review is a self-falsification pass, not an independent external review. |
| Multi-part message delivery | AVAILABLE | The interface supports sequential messages. This package is delivered in 6 parts. |
| General mathematical/statistical/engineering knowledge | AVAILABLE | Used for derivations, calculations, and design reasoning. Labeled as general knowledge where it differs from project-specific evidence. |

### §0.2 Offline Pre-Review Checkpoint

Per the supplemental directive §0.3(8), the original pre-external-research checkpoint is converted to an **offline pre-review checkpoint** based solely on supplied materials. No external source was inspected. No URL was opened. No endpoint was queried.

**Inputs confirmed available:**

| Input | Completeness | Gaps / Ambiguities |
|---|---|---|
| Original master prompt (2 parts) | Complete in context. All §1–§13 sections, C-series (C1–C26), A-series (A1–A9), D-series (D1–D22), E-series, P-series, G-series, T-C-series, V-series present. | None identified. |
| Previous blueprint (Parts 1–6) | Complete in context. All 6 parts with completeness declarations. | The 7 adversarial amendments (AR-1 through AR-9, 7 with design changes) are specified in Part 6 §6.2.2 but not physically merged into Parts 3–5. This is a known structural tension, not a gap. |
| Supplemental directive | Complete. §0–§11 plus Fact Pack. | None identified. |
| TOOBIT FACT PACK | 13 sections. All items labeled SOURCE_VERIFIED, PROVISIONAL, or UNRESOLVED. | Per-symbol contract filters (minQty, stepSize, tickSize, maxLeverage) are NOT extracted. Full error-code catalog is NOT extracted. K-line depth per symbol is NOT extracted. These are correctly marked UNRESOLVED. |

**Conflicts identified at checkpoint:**

| Conflict ID | Sources | Resolution (per §3.3 precedence) |
|---|---|---|
| C1/C2 (timeframes and kline depth) | Master prompt C1 (14 timeframes, RATIFIED) vs. Fact Pack §5 (11 WebSocket intervals, SOURCE_VERIFIED for that list) | Master prompt C1 wins: 14 timeframes is the ratified ceiling. The WebSocket list is a subset. REST may support more. 3,500 is a cap, not a guarantee (C2). Use conservative 1,000-kline response limit where the endpoint conflict remains unresolved (Fact Pack §5: "2000 per one endpoint docs / 1000 per another"). |
| C4 (rate-limit headers) | Master prompt C4 (headers absent in owner's tested environment, RATIFIED) vs. Fact Pack §2 (headers documented as present, SOURCE_VERIFIED) | DOC_CONFLICT. Use conservative branch (b): fixed-weight accounting without headers. Headers may be an optional enhancement if observed in the owner's environment at implementation time. |
| C6 (taker fee) | Master prompt C6 (0.05% documented vs. 0.06% observed) vs. Fact Pack §7 (0.06% SOURCE_VERIFIED, 0.05% UNRESOLVED) | Use 0.06% as conservative default. 0.05% is sensitivity only. |
| C13 (markPrice/klines.change) | Master prompt C13 (CONFLICTED) vs. Fact Pack §12 (UNRESOLVED) | Retain conflict. Do not build critical decisions on either interpretation. Design excludes these fields from signal/risk/execution logic. |
| C3 (leverage) | Master prompt C3 (13-tier ladder, RATIFIED) vs. Fact Pack §8 (200× for BTC tier 1, 50× for many alts, PROVISIONAL) | Do not infer a universal maximum. Per-symbol leverage is UNRESOLVED. The owner's 5× effective-leverage ceiling (D-RISK-6) is independently binding and is the operative limit for the design. |
| C7 (funding) | Master prompt C7 (−30 bp clamp observed, ±24 bp cap refuted) vs. Fact Pack §6 (±2%–3% caps, PROVISIONAL, varies per contract) | Funding is a tail-risk cost input, not a bounded cost. Do not assume any cap. |

**Pre-review checkpoint status: COMPLETE.** All inputs are available. All conflicts are identified and resolved per precedence rules. No external source was inspected. No URL was opened. The design may proceed.

---

## §1 D-RISK Canonical Risk Policy Catalog

This catalog is the **single authoritative definition** of the six owner-hard risk limits. Every other section of this design package references this catalog by ID. No other section redefines these values. The six limits are simultaneously binding, non-optimizable, non-learnable, non-self-adjusting, and non-bypassable by any subsystem.

### §1.1 D-RISK-1 — Maximum Peak-to-Trough Drawdown

| Field | Value |
|---|---|
| **Owner value** | 15% of initial equity |
| **Exact constraint** | `(peak_equity − trough_equity) ≤ 0.15 × initial_equity` |
| **Denominator** | `initial_equity`: the equity value recorded at the moment of first successful risk-state initialization (see §1.7). This value is immutable unless the owner explicitly resets it via a dedicated Telegram command (`/reset_initial_equity <value>`), which is audited at CRIT severity. It is NOT the current equity, NOT the peak equity, and NOT a rolling value. |
| **Numerator** | `peak_equity − trough_equity`: the maximum observed decline from the highest equity value reached (high-water mark) to the lowest equity value subsequently observed. The peak is the running maximum of equity since the last reset. The trough is the current equity at the moment of measurement. |
| **Equity measure** | `equity` = USDT-margined futures account balance as reported by the Toobit balance endpoint (`GET /api/v2/futures/balance`), fetched during reconciliation. This includes realized PnL, unrealized PnL, and available margin. It is the single `totalWalletBalance` or equivalent field as returned by the exchange. `DESIGN_JUDGMENT`: the exact field name is UNRESOLVED (the Fact Pack does not extract the balance response schema). The implementation must identify the correct field at startup and log it. |
| **Unrealized PnL treatment** | Included in equity. The exchange balance endpoint reports the account balance including unrealized PnL. The design does not subtract unrealized PnL. `DESIGN_JUDGMENT`: this is the most conservative interpretation because unrealized losses reduce equity and thus reduce the drawdown headroom. |
| **Fees and funding** | Included in equity. Fees and funding payments reduce the exchange balance, which is reflected in the equity value. |
| **Deposits/withdrawals** | If the owner deposits or withdraws during operation, `initial_equity` is NOT automatically updated. The owner must explicitly call `/reset_initial_equity <new_value>` after a deposit/withdrawal. Until that command is issued, the drawdown limit continues to reference the original `initial_equity`. `DESIGN_JUDGMENT`: this prevents the drawdown limit from silently expanding after a deposit. The consequence is that after a large deposit, the system may be in a drawdown veto until the owner resets. |
| **Measurement timing** | Evaluated at every reconciliation cycle (every 5 minutes) and at every fill event. The peak is updated if current equity > peak. The veto is triggered if `(peak − current_equity) ≥ 0.15 × initial_equity`. |
| **Veto behavior** | `V-DRAWDOWN` (hard latch). Once triggered: (a) no new risk-increasing orders; (b) existing positions are HELD (not auto-closed); (c) protective stop-loss orders remain active on the exchange; (d) daily close at UTC 23:45 still executes (risk-reducing); (e) reconciliation continues; (f) CRIT alert sent to Telegram. |
| **Reset / re-arm** | The latch is PERMANENT until the owner explicitly issues `/ack "drawdown reset"` via Telegram. This command requires: (a) the current equity to be ≥ `initial_equity × 0.85` (i.e., the drawdown has recovered below the 15% threshold), OR (b) the owner explicitly accepts the residual drawdown with a reason string. The peak is reset to current equity upon acknowledgment. The acknowledgment is audited at CRIT. |
| **20% advisory context** | The value 20% is recorded as advisory context only. It is NOT used as the operative limit, a tolerated breach, an optimizer target, or a substitute for 15%. It appears in this catalog solely to document that the owner considered 20% and selected 15%. |
| **Status** | OWNER_HARD. Not optimizable. Not learnable. Not self-adjusting. |

### §1.2 D-RISK-2 — Per-Trade Risk Ceiling

| Field | Value |
|---|---|
| **Owner value** | 5% of current equity |
| **Exact constraint** | `modeled_trade_risk ≤ 0.05 × current_equity` for every individual trade (entry order or pending order). |
| **Denominator** | `current_equity`: the equity value from the most recent successful reconciliation (≤ 5 minutes old). If the equity value is stale (> 5 minutes) or unavailable, the constraint is evaluated as FAIL (fail-closed). |
| **Numerator: modeled_trade_risk** | The sum of the following components, all in USDT: (a) `stop_risk = notional × stop_distance_bp / 10,000`; (b) `fee_cost = notional × taker_fee_rate × 2` (round-trip: entry + exit); (c) `slippage_cost = notional × slippage_bp / 10,000 × 2` (round-trip); (d) `funding_cost = notional × funding_rate × (holding_hours / 8)` (estimated for the intended holding horizon; if funding rate is unavailable, use the last known rate and flag as `PROVISIONAL`); (e) `gap_risk_margin = notional × gap_assumption_bp / 10,000` (a fixed 10 bp buffer for market discontinuity beyond the stop; `DESIGN_JUDGMENT`). Total: `modeled_trade_risk = stop_risk + fee_cost + slippage_cost + funding_cost + gap_risk_margin`. |
| **Stop distance** | The distance from entry price to the protective stop-loss price, in basis points. For the current strategy: 75 bp. This is a strategy parameter, not a risk limit. The risk limit constrains the total risk, of which stop distance is one component. |
| **Contract multiplier** | `quantity_in_base_asset = quantity_in_contracts × contractMultiplier`. The `contractMultiplier` is per-symbol and fetched from `/api/v1/exchangeInfo` at startup. `UNRESOLVED` for specific values until fetched. The design uses `valueQuantity` (USDT notional) for order submission where possible to avoid contract-multiplier arithmetic errors. |
| **Quantity rounding** | Quantities are rounded DOWN to the nearest `stepSize` (per-symbol, from `exchangeInfo`). Rounding down reduces notional and thus reduces risk. The design never rounds up. |
| **Fees** | Taker fee: 0.06% (conservative default per Fact Pack §7, C6). Sensitivity: 0.05% (UNRESOLVED alternative). Both values are carried in the cost model. |
| **Slippage** | Entry/exit: 2 bp. Stop-loss execution: 5 bp (worse, reflecting market-order execution on a triggered stop). `DESIGN_JUDGMENT` based on general market microstructure knowledge for mid-cap crypto perpetuals. |
| **Funding** | Variable, unbounded (C7). The modeled cost uses the last known funding rate. The tail risk is disclosed: actual funding can exceed the modeled value. The 10 bp `gap_risk_margin` partially covers this. |
| **Partial fills** | If only a portion of the order fills, the risk is recalculated on the FILLED quantity. The unfilled remainder does not count toward the risk ceiling. If the remainder is cancelled, the position risk is based on the filled quantity only. |
| **Gap / market discontinuity** | The 10 bp `gap_risk_margin` is a fixed buffer. It does NOT guarantee a loss cap. In a flash crash, the realized loss can exceed `modeled_trade_risk`. This is disclosed. The stop-loss is a STOP_MARKET order (market execution when triggered), which fills at the best available price, not at the stop price. |
| **Protective-order failure** | If the protective stop-loss order is rejected or fails to place: the position is flagged UNPROTECTED. The Risk Authority enters a special monitoring state (1-minute reconciliation interval). The trade is NOT cancelled automatically (the owner decides). The risk ceiling is still enforced for NEW trades. The UNPROTECTED position's risk is counted in the aggregate (D-RISK-4) using the modeled stop risk. |
| **Guaranteed maximum realized loss** | **Does not exist.** The 5% ceiling is a modeled risk budget, not a guaranteed loss cap. The realized loss can exceed the modeled risk due to slippage, gaps, funding spikes, and protective-order failure. This is disclosed in every risk-related section. |
| **Ceiling, not target** | The strategy MAY use less than 5% per trade. The calibration process does NOT target 5%. The sizing formula computes the maximum quantity that satisfies the 5% ceiling, and the strategy may use a fraction of that quantity. |
| **No bypass** | No optimizer, calibration process, adaptation process, portfolio allocator, or operator command may relax this ceiling. The `/config` command cannot modify the 5% value. The value is hardcoded in the risk policy catalog and validated at startup. |
| **Status** | OWNER_HARD. Not optimizable. Not learnable. Not self-adjusting. |

### §1.3 D-RISK-3 — Capital-Planning Basis

| Field | Value |
|---|---|
| **Owner value** | 200 USDT planning basis; sensitivity across 100–500 USDT |
| **Purpose** | Design-planning scale for all calculations (position sizing, storage, rate limits, risk limits in dollar terms). NOT a statement of the owner's current account balance. NOT authorization to access an account. NOT proof of feasibility. |
| **Currency** | All monetary quantities in USDT. |
| **Sensitivity range** | 100, 200, 300, 400, 500 USDT. All parametric calculations show results at all five levels. The 200 USDT value is the primary design point. |
| **Feasibility caveat** | Where the design's data or contract terms do not establish feasibility at a given equity level (e.g., minimum order size, minimum notional, margin requirements), the item is marked `UNRESOLVED` or `NOT TESTED`. The design does NOT invent exchange filters. |
| **Status** | OWNER_HARD (planning basis). The sensitivity range is OWNER_PREFERENCE. |

### §1.4 D-RISK-4 — Aggregate Simultaneous Risk Ceiling

| Field | Value |
|---|---|
| **Owner value** | 15% of equity |
| **Exact constraint** | `Σ modeled_trade_risk(all open positions) + Σ modeled_trade_risk(all pending risk-increasing orders) ≤ 0.15 × current_equity` |
| **Denominator** | `current_equity`: same definition as D-RISK-2 (most recent reconciliation, ≤ 5 minutes old). |
| **Aggregation method** | **Gross (no netting).** Each open position's modeled risk is added to the total. Each pending risk-increasing order's modeled risk is added to the total. Offsetting positions (e.g., long BTC and short BTC) are NOT netted. Correlated exposures (e.g., long BTC and long ETH) are NOT discounted. The conservative measure is the sum of absolute risks. `DESIGN_JUDGMENT`: netting or correlation-adjusted risk reduction is not justified without a demonstrably valid risk model, and the owner limit must be satisfied under the conservative measure. |
| **Pending orders** | A pending order (state: SUBMITTED, ACKNOWLEDGED, PARTIALLY_FILLED, TIMEOUT_AMBIGUOUS, RECONCILING) that is risk-increasing (an entry or a position-increasing amendment) counts its FULL intended risk toward the aggregate. A pending order that is risk-reducing (a close or a position-decreasing amendment) does NOT count toward the aggregate. |
| **Concurrent order-submission races** | If two signals for different symbols are generated in the same cycle: the Risk Authority evaluates them SEQUENTIALLY. The first signal's risk is reserved (subtracted from available risk budget) before the second signal is evaluated. If the second signal would exceed the ceiling, it is VETOED. This prevents a race condition where both signals pass individually but exceed the ceiling jointly. The reservation is atomic within the Risk Authority's evaluation. |
| **Partially filled orders** | A partially filled order's risk is calculated on the FILLED quantity, not the intended quantity. The unfilled remainder, if still open, is calculated on the remaining quantity. |
| **Fail-closed** | If `current_equity` is stale (> 5 minutes) or unavailable: the aggregate risk cannot be computed. The system does NOT add risk. All risk-increasing actions are VETOED. `V-RISK-STATE`. |
| **Status** | OWNER_HARD. Not optimizable. Not learnable. Not self-adjusting. |

### §1.5 D-RISK-5 — Daily Realized-Loss Veto

| Field | Value |
|---|---|
| **Owner value** | 10% of equity |
| **Exact constraint** | `daily_realized_loss / current_equity ≥ 0.10` triggers the veto. |
| **UTC day boundary** | 00:00:00 UTC to 23:59:59 UTC. The day resets at 00:00:00 UTC. |
| **Denominator** | `current_equity` at the time of the check (most recent reconciliation). `DESIGN_JUDGMENT`: using current equity (not start-of-day equity) is the more conservative interpretation because as equity drops, the threshold drops proportionally, causing the veto to trigger sooner. Consequence: the effective dollar loss limit decreases as losses accumulate within the day, providing increasing protection. |
| **daily_realized_loss** | The sum of all REALIZED PnL for positions closed during the current UTC day. Includes: (a) realized PnL from signal exits; (b) realized PnL from stop-loss fills; (c) realized PnL from daily close; (d) realized PnL from `/close` commands; (e) fees on closed positions (taker fees on entry and exit); (f) funding payments for the current day (funding is a realized cost); (g) rebates (negative cost, reduces the loss). EXCLUDES: (h) unrealized PnL on open positions; (i) unrealized PnL on pending orders. |
| **Late-arriving exchange events** | If a fill or funding event is discovered after the UTC day boundary (e.g., a stop-loss fill that was executed at 23:59 but reported at 00:01), it is attributed to the UTC day in which the fill was EXECUTED (determined by the exchange's `updateTime`), not the day in which it was reported. `DESIGN_JUDGMENT`: this is the most accurate attribution. The consequence is that the daily loss for the previous day may be updated after the reset, but the veto for the new day is unaffected. |
| **Veto behavior** | `V-DAILY-LOSS` (daily latch). Once triggered: (a) no new risk-increasing orders for the remainder of the UTC day; (b) existing positions are HELD; (c) protective stop-loss orders remain active; (d) risk-REDUCING actions are PERMITTED: signal exits, daily close at 23:45, `/close` commands, stop-loss fills, reconciliation-driven corrections. The veto does NOT prevent closing a position to reduce risk. `DESIGN_JUDGMENT`: the design does NOT invent an exchange-side `reduceOnly` flag. Risk-reducing actions are market orders to close (opposite side), which are standard and do not require a special flag. |
| **Reset** | The veto resets at 00:00:00 UTC. `daily_realized_loss` is set to 0. `daily_loss_date` is updated to the new UTC date. The reset is automatic (Scheduler-triggered). No operator action required. |
| **Interaction with other latches** | The daily-loss veto is INDEPENDENT of the drawdown latch (D-RISK-1). Both can be active simultaneously. The drawdown latch does NOT reset at the UTC day boundary. The daily-loss veto does NOT affect the drawdown peak/trough tracking. If both are active, the system is in a doubly-restricted state: no new entries, positions held, protective orders active, daily close executes. |
| **Status** | OWNER_HARD. Not optimizable. Not learnable. Not self-adjusting. |

### §1.6 D-RISK-6 — Effective Leverage Ceiling

| Field | Value |
|---|---|
| **Owner value** | 5× |
| **Exact constraint** | `gross_notional_exposure / current_equity ≤ 5.0` at all times. |
| **Effective leverage definition** | `effective_leverage = gross_notional_exposure / current_equity`. Where `gross_notional_exposure = Σ |position_notional| (all open positions) + Σ |pending_order_notional| (all pending risk-increasing orders)`. `position_notional = quantity_in_base_asset × mark_price` (or `last_price` if mark price is unavailable; `DESIGN_JUDGMENT`: the design uses the exchange-reported price for the position, which is the mark price for USDT-M futures). |
| **Equity denominator** | `current_equity` from the most recent reconciliation. Same as D-RISK-2 and D-RISK-4. |
| **Pending orders** | Pending risk-increasing orders (entries, position-increasing amendments) count their FULL intended notional toward `gross_notional_exposure`. Pending risk-reducing orders (closes, position-decreasing amendments) do NOT count. |
| **Hedge-mode positions** | If the account is in hedge mode (both LONG and SHORT positions on the same symbol), both positions count toward `gross_notional_exposure` (no netting). `DESIGN_JUDGMENT`: the design assumes hedge mode is possible and counts gross. If the account is in one-way mode, only one position per symbol exists. |
| **Exchange leverage setting** | The exchange's per-symbol leverage setting (e.g., 20× for BTC) is NOT the operative limit. The operative limit is `min(5×, symbol_exchange_max_leverage)`. The symbol's exchange max leverage is UNRESOLVED (Fact Pack §8: per-symbol, not extracted). The design enforces 5× as the hard ceiling regardless of the exchange setting. If the exchange setting is lower than 5×, the exchange setting is the binding constraint (the system cannot exceed what the exchange allows). The implementation must fetch the per-symbol leverage from `exchangeInfo` at startup and enforce the lesser of the two. |
| **Leverage setting vs. effective leverage** | The exchange leverage setting (e.g., "set leverage to 5×") is a MARGIN parameter. It determines how much margin is locked per unit of notional. The effective leverage in D-RISK-6 is a RISK parameter. It determines the maximum total notional relative to equity. These are different concepts. The design does NOT set the exchange leverage to 5×. The design sets the exchange leverage to the maximum the exchange allows (to minimize margin lockup) and enforces the 5× effective-leverage ceiling in the Risk Authority. `DESIGN_JUDGMENT`: this is the most efficient use of margin while respecting the owner's risk limit. |
| **Veto behavior** | If `effective_leverage > 5.0`: `V-LEVERAGE` (hard veto). No new risk-increasing orders. Existing positions held. Protective orders active. CRIT alert. The veto clears when positions are closed or equity increases such that `effective_leverage ≤ 5.0`. |
| **Status** | OWNER_HARD. Not optimizable. Not learnable. Not self-adjusting. |

### §1.7 Risk-State Initialization and `initial_equity`

| Field | Value |
|---|---|
| **First deployment** | On the first successful startup (no `.initialized` marker file exists): (a) fetch equity from the exchange balance endpoint; (b) set `initial_equity = equity`; (c) set `peak_equity = equity`; (d) set `daily_realized_loss = 0`; (e) set `daily_loss_date = current UTC date`; (f) create the `.initialized` marker file; (g) audit at INFO: "Risk state initialized. initial_equity = X USDT." |
| **Subsequent startup** | Read `risk_state` from the database. If present and valid: resume. If absent or corrupt: `V-RISK-STATE` (hard veto). Do NOT re-initialize from current values. The owner must restore from backup or `/ack` with explicit risk acceptance. |
| **`initial_equity` reset** | Only via the explicit Telegram command `/reset_initial_equity <value>`. Audited at CRIT. The new value becomes the denominator for D-RISK-1. The peak is reset to current equity. |
| **Marker file** | `~/trading/.initialized` (empty file). Its presence indicates the system has been initialized before. If deleted (by the owner or by an attacker), the system re-initializes on next startup. This is an accepted risk. The audit log shows the gap. |

### §1.8 D-RISK Interaction Analysis

The six limits are simultaneously binding. The following interactions are analyzed:

**1. Per-trade risk (D-RISK-2) vs. aggregate risk (D-RISK-4):**
- At 200 USDT equity: max per-trade risk = 10 USDT (5%). Max aggregate risk = 30 USDT (15%).
- Maximum number of concurrent positions at max per-trade risk: 30 / 10 = 3.
- But the leverage ceiling (D-RISK-6) may bind first. At 75 bp stop, 0.06% taker fee, 2 bp slippage, 10 bp gap margin:
  - `modeled_trade_risk = notional × (0.0075 + 0.0012 + 0.0004 + 0.0010) = notional × 0.0101`
  - For 10 USDT risk: `notional = 10 / 0.0101 ≈ 990 USDT`
  - Leverage check: `990 / 200 = 4.95× < 5×` ✓
  - For 3 positions: `3 × 990 = 2970 USDT notional / 200 = 14.85× > 5×` ✗
  - **The leverage ceiling binds first.** Maximum total notional = 1000 USDT. At 75 bp stop: max 2 positions of 500 USDT each (total notional 1000 USDT = 5×). Risk per position: `500 × 0.0101 = 5.05 USDT`. Total risk: 10.1 USDT (5.05%). Within both ceilings. ✓
- **Conclusion:** At 200 USDT equity with a 75 bp stop, the 5× leverage ceiling limits the system to ~2 positions at max size. The 15% aggregate risk ceiling is NOT the binding constraint. The 5% per-trade ceiling is NOT the binding constraint. The leverage ceiling is the binding constraint.

**2. Aggregate risk (D-RISK-4) vs. peak-to-trough drawdown (D-RISK-1):**
- Max aggregate risk = 30 USDT (15% of 200). If ALL concurrent positions hit their stops simultaneously: loss ≈ 30 USDT + fees + slippage ≈ 33 USDT.
- Drawdown limit = 15% of initial equity = 30 USDT.
- The simultaneous stop-loss scenario EXCEEDS the drawdown limit (33 > 30).
- **Consequence:** The drawdown veto (D-RISK-1) will trigger BEFORE or AT the same time as the aggregate risk is fully realized. The system will enter `V-DRAWDOWN` and stop all new entries. This is the intended behavior: the drawdown limit is a portfolio-level circuit breaker that activates before the full aggregate risk is realized.
- **Design implication:** The system must evaluate D-RISK-1 (drawdown) at every fill, not just every 5-minute reconciliation. A fill that pushes equity below the drawdown threshold must trigger the veto immediately.

**3. Daily realized loss (D-RISK-5) vs. total equity drawdown (D-RISK-1):**
- Daily loss limit = 10% of current equity. At 200 USDT: 20 USDT.
- Drawdown limit = 15% of initial equity = 30 USDT.
- It is possible to hit the daily loss limit (20 USDT) without hitting the drawdown limit (30 USDT). In this case, `V-DAILY-LOSS` triggers, new entries stop for the day, but the system can resume the next day.
- It is also possible to hit the drawdown limit (30 USDT) over multiple days without hitting the daily loss limit on any single day (e.g., 12 USDT on day 1, 12 USDT on day 2, 6 USDT on day 3 = 30 USDT total). In this case, `V-DRAWDOWN` triggers as a permanent latch.
- **Both latches can be active simultaneously.** The daily latch resets at 00:00 UTC. The drawdown latch does NOT reset.

**4. Leverage (D-RISK-6) vs. notional exposure, margin, liquidation, and stop-risk:**
- At 5× leverage: margin per 1000 USDT notional = 200 USDT (100% of equity). The maintenance margin (Fact Pack §8: 0.25% for BTC tier 1) is far below the stop-loss distance (75 bp). The stop-loss triggers at 75 bp adverse move. Liquidation would occur at a much larger adverse move (hundreds of bp). **The stop-loss always triggers before liquidation.** This is a safety property: the protective stop-loss is the primary loss control, and liquidation is not a realistic risk at 5× leverage with a 75 bp stop.
- `DESIGN_JUDGMENT`: this conclusion assumes the stop-loss order is active on the exchange. If the stop-loss is rejected (UNPROTECTED position), liquidation becomes a theoretical risk, though still unlikely at 5× with a 75 bp stop.

**5. Equity decline and current-equity-denominated limits:**
- D-RISK-2 (5% of current equity) and D-RISK-4 (15% of current equity) use CURRENT equity as the denominator. As equity declines, the dollar limits decline proportionally.
- Example: equity drops from 200 to 170 (15% drawdown). Per-trade limit: 5% × 170 = 8.5 USDT (was 10). Aggregate limit: 15% × 170 = 25.5 USDT (was 30).
- This is a self-tightening mechanism: as the system loses money, it takes less risk. This is conservative and intended.
- D-RISK-1 (15% of INITIAL equity) does NOT tighten. It is a fixed 30 USDT threshold. This is the owner's explicit choice: the drawdown limit is anchored to the initial capital, not to the current (possibly reduced) capital.

**6. Pending orders and concurrent order-submission races:**
- The Risk Authority evaluates risk-increasing actions SEQUENTIALLY. A pending order's risk is reserved before the next order is evaluated. This prevents a race where two orders each pass the 5% per-trade check but together exceed the 15% aggregate or 5× leverage.
- The reservation is atomic: the Risk Authority's `evaluate_order_intent` method is called before the Order Manager submits. If the evaluation passes, the risk is reserved. If the submission fails (rejection, timeout), the reservation is released.
- `DESIGN_JUDGMENT`: the reservation is in-memory (not persisted to the database). If the process crashes between reservation and submission, the reservation is lost. On restart, the reconciliation determines the actual state. This is safe because the reconciliation will detect any orphan orders.

**7. Fees, funding, slippage, partial fills, gaps, exchange/API failure:**
- All cost components are included in `modeled_trade_risk` (D-RISK-2). The 10 bp gap margin provides a buffer for market discontinuity.
- Partial fills: risk is recalculated on filled quantity. The unfilled remainder, if cancelled, releases its risk reservation.
- Exchange/API failure: if the exchange is unreachable, no new orders can be submitted. Existing positions are held. Protective orders remain on the exchange. The system enters a degraded state (no new entries, positions held, reconciliation paused).
- Inability to cancel or close: if the exchange rejects a close order, the system retries (up to 3 times with backoff). If all retries fail, CRIT alert. The position remains open. The protective stop-loss is the final backstop.

**8. Reset, latch, re-arm, and operator acknowledgment:**
- `V-DAILY-LOSS`: resets at 00:00 UTC. Automatic. No operator action.
- `V-DRAWDOWN`: permanent latch. Requires `/ack "drawdown reset"` with equity ≥ 85% of initial. Operator action required.
- `V-RECONCILE`: clears when reconciliation returns MATCH. Automatic.
- `V-RISK-STATE`: clears when risk state is restored from backup or `/ack` with explicit risk acceptance. Operator action required.
- `V-DATA-STALE`: clears when data freshness is restored. Automatic.
- `V-CONFIG`: clears when config integrity is restored. Operator action required.
- `V-LEVERAGE`: clears when effective leverage drops below 5×. Automatic (positions closed or equity increased).
- Multiple latches can be active simultaneously. The system is in the MOST RESTRICTIVE state (intersection of all active vetoes).

### §1.9 Arithmetic Walk 1: Risk Calculation at 200 USDT Equity

**Scenario:** Long entry on BTC-SWAP-USDT. Entry price: 50,000 USDT. Stop: 75 bp below entry.

**Step 1: Determine maximum notional from leverage ceiling (D-RISK-6).**
- `max_notional = 5 × equity = 5 × 200 = 1,000 USDT`

**Step 2: Determine maximum notional from per-trade risk ceiling (D-RISK-2).**
- `modeled_trade_risk = notional × (stop_bp/10,000 + 2×taker_fee + 2×slippage_bp/10,000 + gap_bp/10,000)`
- `= notional × (75/10,000 + 2×0.0006 + 2×2/10,000 + 10/10,000)`
- `= notional × (0.0075 + 0.0012 + 0.0004 + 0.0010)`
- `= notional × 0.0101`
- Constraint: `notional × 0.0101 ≤ 0.05 × 200 = 10 USDT`
- `notional ≤ 10 / 0.0101 = 990.10 USDT`

**Step 3: Binding constraint.**
- Leverage: 1,000 USDT. Risk: 990.10 USDT.
- **Binding: 990.10 USDT** (per-trade risk ceiling is tighter than leverage for this stop distance).

**Step 4: Quantity calculation.**
- Using `valueQuantity` (USDT notional): `valueQuantity = 990 USDT` (rounded down).
- Effective leverage: `990 / 200 = 4.95× < 5×` ✓
- Modeled risk: `990 × 0.0101 = 9.999 USDT ≤ 10 USDT` ✓

**Step 5: Aggregate risk check (D-RISK-4).**
- If this is the only position: `9.999 USDT ≤ 0.15 × 200 = 30 USDT` ✓
- If a second position of 990 USDT is opened: `2 × 9.999 = 19.998 USDT ≤ 30 USDT` ✓
- But leverage: `2 × 990 / 200 = 9.9× > 5×` ✗
- **Second position at 990 USDT is VETOED by leverage.**
- Maximum second position notional: `1,000 - 990 = 10 USDT` (negligible).
- **Conclusion: at 200 USDT equity with a 75 bp stop, only 1 position at ~990 USDT notional is possible.**

**Step 6: Daily loss check (D-RISK-5).**
- If the stop is hit: realized loss ≈ `990 × 0.0075 + 990 × 0.0012 + 990 × 0.0004 + 990 × 0.0010 + slippage_on_stop`
- `= 7.425 + 1.188 + 0.396 + 0.990 + 990 × 0.0005 = 7.425 + 1.188 + 0.396 + 0.990 + 0.495 = 10.494 USDT`
- Daily loss ratio: `10.494 / 200 = 5.25% < 10%` ✓ (no daily veto)
- Drawdown: `10.494 / 200 = 5.25% < 15%` ✓ (no drawdown veto)

**Step 7: Sensitivity at 100 USDT equity.**
- `max_notional (leverage) = 5 × 100 = 500 USDT`
- `max_notional (risk) = 5 / 0.0101 = 495.05 USDT`
- Binding: 495 USDT. Leverage: `495/100 = 4.95×` ✓
- Modeled risk: `495 × 0.0101 = 4.9995 USDT ≤ 5 USDT` ✓
- Only 1 position possible.

**Step 8: Sensitivity at 500 USDT equity.**
- `max_notional (leverage) = 5 × 500 = 2,500 USDT`
- `max_notional (risk) = 25 / 0.0101 = 2,475.25 USDT`
- Binding: 2,475 USDT. Leverage: `2,475/500 = 4.95×` ✓
- Aggregate: can hold `30/25 = 1.2` → 1 position at max, or 2 positions at 1,237 USDT each (total 2,475 USDT, leverage 4.95×).
- Actually: 2 × 1,237 = 2,475 USDT notional. Leverage: 4.95×. Risk per position: 12.49 USDT. Total: 24.99 USDT ≤ 75 USDT (15% of 500) ✓.

---

## §2 Requirements Register

This is the single canonical Requirements Register. Every requirement has exactly 11 fields. No requirement appears in any other register. The verification matrix in Part 6/6 contains exactly one row per requirement in this register.

**Status legend:** `PASS` (observed evidence satisfies criterion), `NOT TESTED` (test not executed), `UNRESOLVED` (fact/decision not established), `BLOCKED` (required resource unavailable), `DESIGN_JUDGMENT` (reasoned choice under incomplete evidence).

**Priority legend:** `HARD` (must satisfy), `SHOULD` (strong preference), `MAY` (permitted).

| Req ID | Requirement / Obligation | Priority | Authority / Origin | Rationale / Source / Provenance | Verification Method | Acceptance Condition | Status | Evidence Pointer / Observed Result | Failure Response / Safe Fallback | Regression Checks / Dependencies |
|---|---|---|---|---|---|---|---|---|---|---|
| R-001 | All execution paths (Live and Paper) target Toobit USDT-margined perpetual futures exclusively. No other venue, instrument type, or product is used in Live or Paper signal, decision, or execution paths. | HARD | Original master prompt §3.1 item 1; Supplemental §2 item 1 | Owner-specified venue. Toobit is the sole Live/Paper execution venue. | DESIGN_INSPECTION | All order submission, reconciliation, and data-fetch paths reference Toobit endpoints only. No other venue appears in Live/Paper code paths. | PASS | Part 3/6 §6 (architecture), Part 3/6 §7 (order lifecycle): all API calls target `api.toobit.com`. Cross-venue data appears only in research-gated paths (Part 2/6 §5). | Design invalid; restart. | R-005, R-007, R-015, R-030 |
| R-002 | The Telegram bot is the only operator-facing interface. No second bot, dashboard, web console, desktop client, mobile app, or routine operator interface exists. Internal services and monitoring components are permitted only where justified and must not become a parallel operator interface. | HARD | Original master prompt §3.1 item 2; Supplemental §2 item 2 | Owner-specified single-interface constraint. Reduces attack surface and operational complexity. | DESIGN_INSPECTION | All operator actions (mode change, config, pause/resume, close, ack, status queries) are reachable through the Telegram bot command set. No alternative interface is specified. | PASS | Part 4/6 §11 (Telegram interface): 15 commands cover all operator actions. No dashboard, no second bot, no desktop client specified. | Design invalid; restart. | R-009, R-010, R-021, R-023 |
| R-003 | UTC is authoritative for all computation, storage, logs, alerts, reports, scheduling, exchange communication, and audit events. Monotonic time is used for elapsed deadlines. Timestamp semantics are explicitly defined for every data field. | HARD | Original master prompt §3.1 item 3; Supplemental §2 item 3 | Eliminates timezone ambiguity. Ensures deterministic scheduling and audit. | DESIGN_INSPECTION + CALCULATION | All timestamps in the schema are UTC milliseconds. All scheduling (1h bar close, 5-min reconciliation, 23:45 daily close, 00:00 UTC day rollover) is in UTC. Monotonic clock is specified for elapsed deadlines (retry backoff, reconciliation timeout). | PASS | Part 3/6 §7 (order lifecycle): all state transitions timestamped in UTC ms. Part 4/6 §11 (Telegram): all alert timestamps UTC. Part 3/6 §8 (risk): daily loss resets at 00:00 UTC. | Design invalid; temporal logic unsound. | R-015, R-020, R-022 |
| R-004 | No API key, credential, exchange connection, authenticated call, order submission, or account access is performed in this design engagement. The output is a design specification only. | HARD | Original master prompt §3.1 item 4; Supplemental §0.3, §2 item 4 | Design-only boundary. Prevents accidental fund access. | DESIGN_INSPECTION | All 6 parts of this package are design documents. Interface contracts, SQL schemas, and state machines are specified. No executed API calls. No credentials referenced. | PASS | All 6 parts. No code execution. No network calls. | Engagement boundary violated. | All |
| R-005 | Cross-venue data is restricted to research and historical backtesting. It must not be accessible to Paper or Live data, decision, or execution paths. Source-tag lineage is enforced architecturally (not only by documentation). | HARD | Original master prompt §3.1 item 5; Supplemental §0.2, §2 item 5 | Legal/sanctions risk. Cross-venue data in Live paths could violate Toobit terms or applicable regulations. | DESIGN_INSPECTION | (a) Cross-venue data is tagged at ingestion with `source='cross_venue_1h'`. (b) The signal engine's data query filters on `source='toobit'` for Live and Paper. (c) The data ingestor has a separate ingestion path for cross-venue data that writes to a research-only table. (d) The Paper mode fill simulation uses only Toobit data. (e) The Live mode signal computation uses only Toobit data. (f) No query in the Paper or Live path can access the cross-venue table without an explicit source filter that excludes it. | PASS | Part 2/6 §5 (data design): cross-venue bars stored in a separate table (`bars_research`) with `source='cross_venue_1h'`. The signal engine queries `bars` table with `WHERE source='toobit'`. The Paper mode simulation reads from `bars` (Toobit only). The research/backtest script reads from `bars_research`. | Legal/sanctions exposure. | R-001, R-018, R-036 |
| R-006 | The trading intent is intraday. An operational definition of holding duration is derived from the strategy's exit logic, costs, funding, and risk constraints. No duration is invented merely to complete a table. | HARD | Original master prompt §3.1 item 6; Supplemental §2 item 6 | Owner-specified intraday intent. Prevents overnight exposure. | DESIGN_INSPECTION + CALCULATION | The strategy's exit conditions (1h SMA cross, UTC 23:45 forced close, 75 bp stop) define the maximum holding duration. The maximum holding is from entry (any 1h bar close) to the next UTC 23:45 close. Maximum: ~23 hours. Minimum: 1 hour (next bar close). The 23:45 forced close guarantees no position survives past the UTC day. | PASS | Part 2/6 §4 (strategy): exit conditions include UTC 23:45 forced close. Part 3/6 §7 (order lifecycle): daily close cycle at 23:45. Part 3/6 §8 (risk): daily loss resets at 00:00 UTC. | Overnight positions violate intent. | R-007, R-015, R-019, R-027 |
| R-007 | The tradable universe is derived through the D14 process (criteria-first, evidence-based). The 10 C19 measurement symbols are not a universe recommendation. The universe is criteria-based; the owner enumerates the specific symbols at implementation time from the Toobit `exchangeInfo` response. | HARD | Original master prompt §3.1 item 7; Supplemental §2 item 7 | Prevents survivorship bias and ensures the universe is defined by tradability criteria, not by a pre-selected list. | DESIGN_INSPECTION + CALCULATION | Part 2/6 §3 (universe derivation): 9-step D14 process. Criteria: (a) USDT-margined perpetual on Toobit; (b) 1h and 4h and 1d klines available; (c) 24h volume above a threshold; (d) spread below a threshold; (e) not delisted. The C19 10 symbols are a measurement set, not a candidate list. The final universe is determined at implementation by querying `exchangeInfo` and applying the criteria. | NOT TESTED | Part 2/6 §3: D14 derivation complete. Symbol list is PROVISIONAL (owner must enumerate Toobit's current list at implementation). Criteria are derived; application is pending. | Overly narrow/broad universe. | R-001, R-016, R-017, R-032 |
| R-008 | The POCO X6 is the reference device. The D15 envelope-first process is followed: compute/storage/latency needs are derived first; all feasible topologies are enumerated; the owner's compromise order is applied. Mobile convenience does not predetermine the architecture. | HARD | Original master prompt §3.1 item 8; Supplemental §2 item 8 | Ensures the deployment is feasible on the actual hardware. | DESIGN_INSPECTION + CALCULATION | Part 5/6 §13 (D15): envelope derived (§13.1), POCO X6 bounded (§13.2, PROVISIONAL per C16), match = PASS PROVISIONAL (§13.3), 5 topologies enumerated (§13.4), T-1 selected (§13.5). C16 measurement protocol (MP-1–MP-5) specified. | NOT TESTED | Part 5/6 §13: complete D15 derivation. C16 (sustained runtime) NOT MEASURED. MP-1–MP-5 pending. | Infeasible without justified hybrid. | R-007, R-016, R-032, R-033 |
| R-009 | Telegram loss does not disable safety, release risk limits, unblock unsafe actions, or make uncertain exchange state appear confirmed. Open-position and pending-order behavior when the operator is unreachable is specified. | HARD | Original master prompt §3.1 item 9; Supplemental §2 item 9 | Prevents a single point of failure (Telegram) from compromising safety. | DESIGN_INSPECTION | Part 4/6 §11.5 (Telegram loss behavior): risk limits NOT released. New entries PAUSED. Existing positions HELD. Protective orders remain on exchange. Daily close EXECUTED. Reconciliation CONTINUED. Risk state updates CONTINUED. Alerts QUEUED. Operator unreachable > 30 min: degraded state (no new entries, positions held, protective orders active, daily close executes). System does NOT flatten positions automatically. | PASS | Part 4/6 §11.5: complete specification. Risk Authority operates independently of Telegram. | Capital loss during outage. | R-002, R-014, R-020, R-022 |
| R-010 | Phase structure is derived per D16 from risks and verification dependencies. The Paper/Live selector has no arbitrary elapsed-time requirement or profitability/performance hurdle. The six safety interlocks are mandatory, non-bypassable correctness gates for entry into Live mode and for every risk-increasing action. | HARD | Original master prompt §3.1 item 10; Supplemental §0.2, §2 item 10 | Prevents premature Live deployment while respecting the owner's authority to select mode. | DESIGN_INSPECTION | Part 5/6 §14 (D16): 4 phases (0–3) derived from risk enumeration and verification dependencies. Part 4/6 §11.3 (interlocks): 6 interlocks specified with failure conditions and refusal messages. No wait period. No profitability hurdle. Interlocks are correctness gates. | NOT TESTED | Part 5/6 §14: phase structure complete. Part 4/6 §11.3: 6 interlocks specified. | Live transition without interlocks = uncontrolled risk. | R-002, R-009, R-014, R-020, R-024 |
| R-011 | All capital-dependent calculations are parametric as f(equity). The planning basis is 200 USDT (D-RISK-3). Sensitivity analysis across 100–500 USDT is shown. No single value is presented as "the answer." | HARD | Original master prompt §3.1 item 11; Supplemental §1.3 (D-RISK-3) | Ensures the design is valid across the owner's capital range. | CALCULATION | Part 1/6 §1.9 (arithmetic walk): position sizing, risk, and leverage calculations shown at 100, 200, 500 USDT. Part 2/6 §4 (strategy): position sizing formula is parametric. Part 3/6 §8 (risk): all limits expressed as f(equity). | NOT TESTED | Part 1/6 §1.9: calculations at 100, 200, 500 USDT. Part 2/6 §4: parametric sizing. | Infeasible at actual capital scale. | R-007, R-015, R-019, R-027 |
| R-012 | All delegated technical choices (architecture, language, framework, runtime, data store, algorithm, model class, optimizer) are made with recorded rationale. No delegated decision is paused for the owner. | HARD | Original master prompt §3.1 item 11; Supplemental §2 item 11 | Owner delegates technical decisions to the designer. | DESIGN_INSPECTION | Language (Python 3.11+), storage (SQLite), topology (modular monolith on Termux), strategy (dual-timeframe trend), optimizer (grid search, 3 configs), all selected with D13 rationale in Parts 2–3. No owner questions about delegated items. | PASS | Parts 2–3: all technical choices documented with rationale. | Engagement fails mandate. | All |
| R-013 | No re-asked information. No questions about delegated choices. The only owner decisions surfaced are the D-RISK values (now resolved) and implementation-time measurements (MP-1–MP-5). | HARD | Original master prompt §3.1 item 11; Supplemental §1 | Prevents wasted owner time. | DESIGN_INSPECTION | No question in Parts 1–6 asks the owner to select an algorithm, infrastructure, or model class. The D-RISK values are OWNER_HARD (not questions). MP-1–MP-5 are implementation-time measurements (not design questions). | PASS | All 6 parts. | Wasted owner time. | R-012 |
| R-014 | The Risk Authority is an independent module with its own state, its own evaluation logic, and its own veto power. It cannot be bypassed by any subsystem, configuration change, retry logic, or Telegram command. Missing, stale, or corrupt risk state results in a hard veto (fail-closed). | HARD | Original master prompt §9.6; Supplemental §7.3 | Risk authority independence is the primary safety invariant. | DESIGN_INSPECTION | Part 3/6 §8 (risk design): Risk Authority has own `risk_state` table (no other component writes to it). Own evaluation logic (does not call Signal Engine or Order Manager). Own veto power (veto is final). No config key can disable it. No retry can bypass it. No Telegram command can override a veto. Missing/corrupt risk_state = `V-RISK-STATE` (hard veto). | NOT TESTED | Part 3/6 §8: complete specification. | Risk bypass = uncontrolled capital loss. | R-009, R-010, R-015, R-020, R-027 |
| R-015 | A complete order state machine is specified with all states, valid transitions, invalid transitions (explicitly rejected), -1007/timeout handling, retry budget, partial fills, cancellations, ambiguous outcomes, protective orders, crash recovery, and reconciliation. | HARD | Original master prompt §9.7; Supplemental §7.4 | Order lifecycle correctness prevents orphan orders, duplicate fills, and unreconciled state. | DESIGN_INSPECTION | Part 3/6 §7 (order lifecycle): 10 states, 16 valid transitions, 5 invalid transitions rejected. -1007 → TIMEOUT_AMBIGUOUS (no resubmit, reconcile). Retry budget: 3 max, backoff 5s/15s/45s. Partial fills tracked at filled quantity. Cancel/fill race: exchange resolves. Crash recovery: startup reconciliation. Protective orders: exchange-side STOP_MARKET. | NOT TESTED | Part 3/6 §7: complete state machine. | Orphan orders, duplicate fills, unreconciled state. | R-003, R-009, R-014, R-020, R-037, R-038 |
| R-016 | The selection procedure declares all 7 required fields (searched configurations, effective sample size, assumptions, stopping rule, selection-bias control, promotion policy, rollback policy). No exhaustive grid at ≤12h timeframes. Trial count within budget. | HARD | Original master prompt C20–C24, D19; Supplemental §2 item 12 | Prevents multiple testing bias and overfitting. | DESIGN_INSPECTION + CALCULATION | Part 2/6 §4.3 (selection procedure): 3 configs (P1 ∈ {20, 50, 100}). Effective sample size: PROVISIONAL (measured in Phase 1). Assumptions: 4 stated. Stopping rule: evaluate all 3. Selection-bias control: DSR + walk-forward (3 folds). Promotion policy: 4 criteria. Rollback policy: 4 criteria. 3 ≤ 16 ceiling. No exhaustive grid. | NOT TESTED | Part 2/6 §4.3: complete selection procedure. | Over-budget search = multiple testing bias. | R-007, R-017, R-028, R-029 |
| R-017 | At least one defensible candidate strategy architecture is proposed and subjected to checks. No preemptive rejection. A simple baseline is specified for incremental-value testing. | HARD | Original master prompt D19; Supplemental §7.2 | D19 requires a candidate before statistical rejection. | DESIGN_INSPECTION | Part 2/6 §4 (strategy): dual-timeframe trend (1d/4h filter + 1h entry/exit). Baseline (C-0): buy-and-hold 20 symbols, 00:00–23:00 UTC, equal-weighted. 5 candidates considered in Part 2/6 §4.1. C-3 selected with rationale. No blanket rejection. | PASS | Part 2/6 §4: complete strategy specification. | No strategy = no design. | R-006, R-016, R-028, R-029 |
| R-018 | Every data input has a defined availability time. No look-ahead. Backtest uses only data available at bar close. Cross-venue data is never used in Live or Paper signal computation. | HARD | Original master prompt §9.5; Supplemental §2 item 5 | Look-ahead invalidates backtests. Cross-venue in Live violates R-005. | DESIGN_INSPECTION | Part 2/6 §5 (data design): all data classes specify timestamp semantics (bar open_time, close_time). Signal computation triggered at bar close + 5s buffer. Entry/exit conditions evaluated at 1h bar close (no future data). Cross-venue data in `bars_research` table, never queried by signal engine in Live/Paper. | NOT TESTED | Part 2/6 §5: complete data design. | Look-ahead = invalid backtest. | R-005, R-006, R-026, R-028 |
| R-019 | Each cost term (taker fee, maker fee, slippage, funding) is stated with value, source, scope. Sensitivity across ≥2 scenarios. Uncertainty reported. | HARD | Original master prompt §9.5; Supplemental §6 item 12 | Cost model accuracy affects net return and position sizing. | CALCULATION | Part 2/6 §4.4 (cost model): taker 0.06% (Fact Pack §7, SOURCE_VERIFIED, conservative), maker 0.02% (Fact Pack §7), slippage 2 bp entry/exit, 5 bp stop (DESIGN_JUDGMENT), funding variable/unbounded (C7). Two scenarios: optimistic (0.05% taker) and conservative (0.06% taker). Funding parametric. | NOT TESTED | Part 2/6 §4.4: complete cost model. | Overstated returns. | R-006, R-011, R-016, R-030 |
| R-020 | Authoritative state ownership is defined. The internal ledger is reconciled against the exchange. No silent divergence. On divergence: hard veto, CRIT alert, resolution attempt. | HARD | Original master prompt §9.7; Supplemental §2 | Divergent state = incorrect risk calculation. | DESIGN_INSPECTION | Part 3/6 §9 (reconciliation): State Reconciler runs every 5 min. Compares internal positions/orders/balance vs. exchange. On DIVERGENCE: `V-RECONCILE`, CRIT alert, resolution attempt. On API failure: SKIPPED (not assumed MATCH). | NOT TESTED | Part 3/6 §9: complete reconciliation specification. | Divergent state = incorrect risk. | R-003, R-009, R-010, R-014, R-015 |
| R-021 | Secrets (API key, bot token) are encrypted at rest, never logged, never transmitted over unencrypted channels. API key has read+trade permissions only, NO withdrawal. Telegram input is validated (sender ID, replay protection, injection protection, rate limiting). | HARD | Original master prompt §9.8; Supplemental §2 | Compromised secrets = fund loss. | DESIGN_INSPECTION | Part 4/6 §12 (security): AES-256 encryption, `secrets.key` separate from DB. API key: read+trade, NO withdrawal (Interlock 4 checks). Sender ID check, replay protection (message_id, last 1000), injection protection (strict regex), rate limiting (10/min). | NOT TESTED | Part 4/6 §12: complete security specification. | Compromised secrets = fund loss. | R-002, R-009, R-024 |
| R-022 | Recovery from process death, phone reboot, and storage corruption is specified. Startup sequence, shutdown sequence, and recovery table are complete. | HARD | Original master prompt §9.8; Supplemental §2 | Unrecovered state = orphan positions. | DESIGN_INSPECTION | Part 4/6 §12.7 (startup/shutdown): 11-step startup sequence, graceful + ungraceful shutdown. §12.8 (recovery table): 6 scenarios. Process death → autostart → reconciliation → resume. Storage corruption → integrity check → backup restore → reconcile. | NOT TESTED | Part 4/6 §12.7–12.8: complete recovery specification. | Unrecovered state = orphan positions. | R-003, R-009, R-015, R-020, R-031 |
| R-023 | Alerts are actionable. Three severities (INFO, WARN, CRIT) with trigger, delivery, and implied action. CRIT requires operator response within 30 min (degraded state if no response). | SHOULD | Original master prompt §9.9; Supplemental §2 | Silent failures are dangerous. | DESIGN_INSPECTION | Part 4/6 §11.4 (alert contract): 3 severities with triggers, delivery, and actions. CRIT: 30-min response window. Degraded state if no response. | NOT TESTED | Part 4/6 §11.4: complete alert specification. | Silent failures. | R-002, R-009, R-014, R-022 |
| R-024 | Configuration is versioned, change-detected, audited. Config corruption or drift results in fail-closed behavior (`V-CONFIG`). Config integrity hash (SHA-256) is computed on every change. | HARD | Original master prompt §9.8; Supplemental §2 | Silent config drift = incorrect behavior. | DESIGN_INSPECTION | Part 3/6 §6 (Component: Config Manager): versioning, SHA-256 integrity hash, drift detection, pydantic validation. `V-CONFIG` on drift. Startup step 4: invalid config → REFUSE TO START. | NOT TESTED | Part 3/6 §6: complete config specification. | Silent config drift. | R-010, R-014, R-021 |
| R-025 | Backups: state.db backed up every 6h (automatic) + on `/backup` command. Last 7 backups rolling. Restore test monthly. `sqlite3 .backup` method. | SHOULD | Original master prompt §9.8; Supplemental §2 | Unrecoverable state loss. | DESIGN_INSPECTION | Part 4/6 §12.6 (backups): 6h automatic + manual. 7 rolling. Monthly restore test. | NOT TESTED | Part 4/6 §12.6: complete backup specification. | Unrecoverable state loss. | R-022, R-024 |
| R-026 | Data quality rules for missing, stale, duplicate, malformed, contradictory, and unavailable data are specified with consequences. | HARD | Original master prompt §9.5; Supplemental §2 | Silent data errors = incorrect signals. | DESIGN_INSPECTION | Part 2/6 §5.2 (data quality rules): 6 rules with consequences. Missing → no interpolation, MISSING marker, skip symbol. Stale → thresholds per TF, no signals. Duplicate → PK detection, LWW. Malformed → reject, alert. Contradictory → Toobit authoritative for Live. Unavailable → `V-DATA-STALE`. | NOT TESTED | Part 2/6 §5.2: complete data quality specification. | Silent data errors. | R-005, R-018, R-020 |
| R-027 | The six D-RISK hard limits (15% drawdown of initial equity, 5% per-trade risk ceiling, 200 USDT planning basis, 15% aggregate risk, 10% daily loss, 5× leverage) are enforced as OWNER_HARD constraints. They are not optimized, learned, relaxed, or self-adjusted. All other risk parameters are parametric per D17. | HARD | Supplemental §1 (D-RISK-1 through D-RISK-6); Original D17 | Owner-hard risk limits. The primary safety invariant. | DESIGN_INSPECTION + CALCULATION | Part 1/6 §1 (D-RISK catalog): all 6 limits defined with exact formulas, denominators, veto behavior, reset/re-arm, and interaction analysis. Part 3/6 §8 (risk design): Risk Authority enforces all 6 limits. No config key can modify them. No optimizer targets them. Sensitivity analysis varies equity (100–500) and model inputs, NOT the D-RISK values. | NOT TESTED | Part 1/6 §1: complete D-RISK catalog. Part 3/6 §8: enforcement specification. | Unauthorized risk. | R-006, R-011, R-014, R-019 |
| R-028 | Data split methodology is chronological, purged/embargoed. No parameter is tuned on validation data. Walk-forward validation with ≥3 folds. | HARD | Original master prompt C20–C24; Supplemental §2 item 12 | Contamination = overfit. | DESIGN_INSPECTION | Part 2/6 §4.3 (selection procedure): walk-forward with 3 chronological folds. Train on 2/3, validate on 1/3. Winner must have positive net return in ≥2/3 folds. No tuning on validation. Purge/embargo: a 1-bar gap between train and validation folds to prevent SMA look-ahead leakage. | NOT TESTED | Part 2/6 §4.3: complete split methodology. | Contamination = overfit. | R-016, R-017, R-018, R-029 |
| R-029 | The selection procedure declares all 7 required fields: searched configurations, effective sample size, assumptions, stopping rule, selection-bias control, promotion policy, rollback policy. | HARD | Original master prompt C20–C24; Supplemental §2 item 12 | Uncontrolled multiple testing. | DESIGN_INSPECTION | Part 2/6 §4.3: (1) searched configurations: 3 (P1 ∈ {20, 50, 100}); (2) effective sample size: PROVISIONAL, measured in Phase 1 from cross-correlation matrix; (3) assumptions: 4 stated (i.i.d. approximation, 50% cross-correlation, stationarity within fold, no structural break); (4) stopping rule: evaluate all 3, no early stopping; (5) selection-bias control: Deflated Sharpe Ratio + walk-forward; (6) promotion policy: 4 criteria (DSR > 0, net return > 0 in ≥2/3 folds, max DD < dd_max, net return > baseline); (7) rollback policy: 4 criteria (3 consecutive days net loss, V-DRAWDOWN, V-RECONCILE unresolved > 24h, owner /mode paper). All 7 fields present. | PASS | Part 2/6 §4.3: all 7 fields explicitly stated. | Uncontrolled multiple testing. | R-016, R-017, R-028 |
| R-030 | Execution model accounts for partial fills, slippage, latency, minimum order size, maximum position, liquidation, and funding timing. No perfect-fill assumption. | HARD | Original master prompt §9.7; Supplemental §6 | Unrealistic execution = incorrect risk. | DESIGN_INSPECTION | Part 3/6 §7.7 (partial fills): tracked at filled quantity, remaining cancelled after 30s. Part 2/6 §4.4 (cost model): slippage 2 bp entry/exit, 5 bp stop. Part 3/6 §7.5 (retry budget): latency budget < 2s. Part 2/6 §4.4: funding at 8h intervals (some contracts 4h per Fact Pack §6). Minimum order size: UNRESOLVED (per-symbol from exchangeInfo, fetched at startup). Liquidation: not reached at 5× leverage with 75 bp stop (Part 1/6 §1.8 item 4). | NOT TESTED | Part 3/6 §7.7; Part 2/6 §4.4. | Unrealistic execution. | R-006, R-011, R-015, R-019 |
| R-031 | Android operational requirements (Doze, App Standby, foreground service, OEM process management, thermal, recovery) are specified. The process must survive indefinitely while charging with proper configuration. | HARD | Original master prompt §9.8; Supplemental §2 item 8 | Process killed during trade = orphan positions. | DESIGN_INSPECTION | Part 5/6 §13.6 (Android requirements): 8 settings specified (autostart, battery optimization, App Standby, foreground service type, Doze, OEM whitelist, screen, charging). Part 4/6 §12.8 (recovery table): 6 scenarios. Thermal: PROVISIONAL per C16. | NOT TESTED | Part 5/6 §13.6; Part 4/6 §12.8. | Process killed during trade. | R-008, R-009, R-022 |
| R-032 | Storage requirement is calculated from data volume, scaled to universe, and compared against available device storage. | SHOULD | Original master prompt §3.1; Supplemental §2 item 8 | Storage exceeded = data loss. | CALCULATION | Part 5/6 §13.1: 20 symbols × 4 TFs × 3,500 bars × ~2,551 bytes = ~711 MB. Orders/positions/audit/config: < 50 MB. Total: ~760 MB. Available: 56 GB (C14 snapshot). Ratio: 760/56,000 = 1.4%. Storage is not a constraint. 56 GB is a historical snapshot; re-measure at deployment. | NOT TESTED | Part 5/6 §13.1: calculation shown. | Storage exceeded. | R-007, R-008, R-033 |
| R-033 | API call volume × payload sizes are calculated and compared against mobile network capacity. | SHOULD | Original master prompt §3.1; Supplemental §2 item 8 | Data gaps or cost. | CALCULATION | Part 5/6 §13.1: 20 API calls per 15m cycle (~2 KB each) = ~40 KB per 15 min. Telegram long-poll: ~2 KB per 50s. Daily total: ~4 MB data + ~3.5 MB Telegram = ~7.5 MB/day. Negligible for mobile data. | NOT TESTED | Part 5/6 §13.1: calculation shown. | Data gaps or cost. | R-008, R-009, R-032 |
| R-034 | System behavior is deterministic. Data is versioned. Config is versioned. Audit log is sufficient to reconstruct any past state. | SHOULD | Original master prompt §9.8; Supplemental §2 | Un-debuggable, un-auditable. | DESIGN_INSPECTION | Part 3/6 §6 (Config Manager): versioned with SHA-256 hash. Part 3/6 §10 (Audit Logger): append-only, all material events recorded with UTC ms timestamp, event_type, component, detail (JSON), severity. Signal generation is deterministic (SMA on fixed bars, no randomness). All tables have primary keys and UTC ms timestamps. | NOT TESTED | Part 3/6 §6, §10. | Un-debuggable, un-auditable. | R-003, R-020, R-024 |
| R-035 | Component boundaries, interface contracts, and dependency pinning are specified. No component has ambiguous state ownership. | SHOULD | Original master prompt §9.7; Supplemental §2 | Unmaintainable. | DESIGN_INSPECTION | Part 3/6 §5–§10: 9 components with 11-field specification each (purpose, responsibilities, non-responsibilities, state ownership, inputs, outputs, dependencies, timing, failure behavior, verification, interface contract). Part 4/6 §12.4 (dependencies): pinned versions in requirements.txt. | NOT TESTED | Part 3/6 §5–§10; Part 4/6 §12.4. | Unmaintainable. | R-012, R-034 |
| R-036 | Cross-venue data is source-tagged at ingestion and architecturally prevented from entering Paper or Live paths. The separation is enforced by data-layer controls (separate table, source filter in query), not only by documentation. | HARD | Supplemental §0.2, §2 item 5; Original §3.1 item 5 | Legal/sanctions risk. | DESIGN_INSPECTION | Part 2/6 §5 (data design): cross-venue bars stored in `bars_research` table (separate from `bars`). Signal engine query: `SELECT ... FROM bars WHERE source='toobit' AND symbol=? AND timeframe=?`. Paper mode fill simulation reads from `bars` (Toobit only). Research/backtest script reads from `bars_research`. No code path in Live or Paper can access `bars_research` without an explicit, audited, research-mode flag. The Config Manager does not have a key to enable cross-venue in Live/Paper. | PASS | Part 2/6 §5: separate table, source filter, no config key to bypass. | Legal/sanctions risk. | R-001, R-005, R-018 |
| R-037 | Retry logic is finite with explicit backoff and hard stop. No infinite retry loop. Rate-limit (-1003) is handled separately from general retry. | HARD | Original master prompt §9.7; Supplemental §6 item 2 | Duplicate orders or rate-limit ban. | DESIGN_INSPECTION | Part 3/6 §7.5 (retry budget): max 3 retries, backoff 5s/15s/45s (exponential, base 5s, factor 3). Hard stop after 3. Retry count in `orders` table. Rate-limit (-1003): 60s backoff, NOT counted as a retry. Weight accounting: conservative fixed-weight (C4). | NOT TESTED | Part 3/6 §7.5: complete retry specification. | Duplicate orders or rate-limit ban. | R-015, R-020, R-038, R-040 |
| R-038 | Timeout/5XX/ambiguous failure does not prove rejection. No blind resubmission. A durable UNKNOWN state is modeled. Reconciliation is required before any further action on that order. | HARD | Original master prompt C5; Supplemental §6 item 5 | Missed position or duplicate order. | DESIGN_INSPECTION | Part 3/6 §7.3 (-1007/timeout handling): TIMEOUT_AMBIGUOUS state. Do NOT resubmit. Do NOT assume fill. Reconcile: wait 5s, query exchange by clientOrderId. If query also times out: retry after 30s (max 3 reconciliation attempts). If still unresolved: CRIT alert, operator intervention. Symbol locked during ambiguity. 5XX responses treated identically to timeout (execution status UNKNOWN per Fact Pack §4). | NOT TESTED | Part 3/6 §7.3: complete ambiguous-outcome specification. | Missed position or duplicate order. | R-015, R-020, R-037 |
| R-039 | Protective stop-loss has its own lifecycle. Placed on the exchange (survives process death). Rejection is handled (CRIT alert, UNPROTECTED flag, increased monitoring). | HARD | Original master prompt §9.7; Supplemental §7.3 | Unlimited loss on adverse move. | DESIGN_INSPECTION | Part 3/6 §7.6 (protective orders): STOP_MARKET on exchange. Placed after entry ACKNOWLEDGED. Stop price = entry × (1 ∓ 75/10,000). Survives process death. If rejected: CRIT alert, position UNPROTECTED, flag, monitor at 1-min intervals. If not placed within 60s: consider flattening. On position close: cancel protective order. | NOT TESTED | Part 3/6 §7.6: complete protective order specification. | Unlimited loss on adverse move. | R-014, R-015, R-027, R-030 |
| R-040 | Rate-limit accounting uses conservative fixed-weight as the safe baseline. Does not depend on response headers being present. Headers may be an optional enhancement if observed. | HARD | Original master prompt C4; Supplemental §3.3, §6 item 2 | API ban = no trading. | DESIGN_INSPECTION | Part 3/6 §5 (Component: Data Ingestor): conservative fixed-weight limiter. Each endpoint's weight is hardcoded from Fact Pack §2. A sliding 1-minute window tracks cumulative weight. If projected weight > 3000: delay request. ORDERS limit: 60 per 2 seconds tracked separately. Headers (X-Api-Limit-Status, etc.) are NOT used in the baseline. If observed in the owner's environment at implementation, they MAY be used as an enhancement (delta-based), but the fixed-weight baseline remains as fallback. | NOT TESTED | Part 3/6 §5: fixed-weight limiter specified. | API ban = no trading. | R-015, R-033, R-037 |
| R-041 | clientOrderId format is [A-Za-z0-9_-]. Unique within the system. Non-reused after an ambiguous outcome. The weakest documented uniqueness scope (per-account) is assumed and local uniqueness is enforced. | HARD | Original master prompt C11; Supplemental §6 item 6 | Order rejection or mismatch. | DESIGN_INSPECTION | Part 3/6 §7.4 (idempotency): format `T{UTC_ms}_{symbol}_{seq}`. Charset: letters, digits, underscore (within [A-Za-z0-9_-]). Uniqueness: UTC_ms + seq. Pre-submission check: existing clientOrderId in `orders` table → do not resubmit. After ambiguous outcome: clientOrderId is NEVER reused. Post-crash: read all SUBMITTED/ACKNOWLEDGED orders and reconcile. | NOT TESTED | Part 3/6 §7.4: complete idempotency specification. | Order rejection or mismatch. | R-015, R-037 |
| R-042 | Funding is treated as an unbounded tail cost. No maximum is assumed. The observed −30 bp is a data point, not a cap. Sensitivity is shown. | HARD | Original master prompt C7; Supplemental §3.3, §6 item 11 | Underestimated holding cost. | DESIGN_INSPECTION | Part 2/6 §4.4 (cost model): funding variable, unbounded. Observed −30 bp as data point. Fact Pack §6: caps ±2%–3% (PROVISIONAL, varies per contract) — NOT used as a design bound. At −30 bp: 1.2 USDT per 8h per 400 USDT notional. 24h holding: 3.6 USDT (1.8% of 200 USDT equity). Tail risk disclosed. | NOT TESTED | Part 2/6 §4.4; Fact Pack §6. | Underestimated holding cost. | R-006, R-019, R-027, R-030 |
| R-043 | Conservative taker fee (0.06%) is used as the default. The 0.05% alternative is carried as UNRESOLVED sensitivity. The owner's actual fee tier is NOT assumed verified. | HARD | Original master prompt C6; Supplemental §3.3, §6 item 12 | Overstated net return. | DESIGN_INSPECTION | Part 2/6 §4.4: taker = 0.06% (Fact Pack §7, SOURCE_VERIFIED, conservative). Sensitivity at 0.05% (UNRESOLVED). Both values shown in cost model. UNRESOLVED status preserved. | NOT TESTED | Part 2/6 §4.4; Fact Pack §7. | Overstated net return. | R-019, R-030 |
| R-044 | The design does NOT use markPrice or klines.change for any signal, risk, or execution logic. The C13 semantics conflict is avoided entirely. | HARD | Original master prompt C13; Supplemental §3.3, §6 item 16 | Building on disputed semantics. | DESIGN_INSPECTION | Part 2/6 §4 (strategy): signals use OHLCV bars only (open, high, low, close, volume). No markPrice. No klines.change. Part 2/6 §5 (data design): mark-price kline endpoint exists (Fact Pack §5) but is NOT ingested for signal computation. Funding is calculated from the funding rate endpoint, not from mark price. | PASS | Part 2/6 §4, §5: C13 conflict avoided. | Building on disputed semantics. | R-018, R-026 |
| R-045 | The design does NOT depend on historical Open Interest. The C26 UNRESOLVED status is preserved. A feature that depends on OI remains disabled. | HARD | Original master prompt C26; Supplemental §6 item 16 | Dependence on unavailable data. | DESIGN_INSPECTION | Part 2/6 §4 (strategy): signals based on price action (SMA, breakout) only. OI is not ingested, not stored, not used. If a future iteration adds OI as a filter, it must first verify Toobit's OI endpoint availability and depth. | PASS | Part 2/6 §4: OI not used. | Dependence on unavailable data. | R-007, R-018, R-026 |
| R-046 | Effective leverage is defined mathematically (gross notional / equity). No assumed maximum exchange leverage. Margin/notional used explicitly. The 5× owner ceiling is the operative limit. Per-symbol exchange limits are UNRESOLVED and must be fetched at startup. | HARD | Supplemental §1.6 (D-RISK-6); Original C3; Supplemental §6 item 13 | Assuming higher leverage than permitted = liquidation. | DESIGN_INSPECTION + CALCULATION | Part 1/6 §1.6 (D-RISK-6): `effective_leverage = gross_notional_exposure / current_equity ≤ 5.0`. Part 3/6 §8 (risk design): leverage check at every order evaluation. Per-symbol leverage from `exchangeInfo` at startup (UNRESOLVED until fetched). The design enforces `min(5×, symbol_exchange_max)`. No universal exchange maximum inferred. | NOT TESTED | Part 1/6 §1.6; Part 3/6 §8. | Assuming higher leverage than permitted = liquidation. | R-011, R-014, R-027, R-030 |
| R-047 | The six D-RISK hard limits are defined in exactly one canonical catalog (Part 1/6 §1). All other sections reference this catalog by ID. No duplicate or subtly different definitions exist elsewhere in the package. | HARD | Supplemental §1.7 | Duplicate definitions = inconsistent enforcement. | DESIGN_INSPECTION | Part 1/6 §1: canonical catalog with all 6 limits. Part 3/6 §8 (risk design): references "D-RISK-1 through D-RISK-6 as defined in Part 1/6 §1." No other section redefines the values. The Risk Authority reads the values from the catalog at startup. | PASS | Part 1/6 §1: single definition. Part 3/6 §8: reference only. | Duplicate definitions = inconsistent enforcement. | R-027, R-014 |
| R-048 | Paper/Live mode semantics: configuration separation, state isolation, order-sending boundary, mode-switch transaction, pending-order behavior, open-position handling, and audit event are specified. It is impossible for Paper to submit real orders and impossible for Live to consume cross-venue research-only data. | HARD | Supplemental §7.5 | Mode confusion = accidental live trading or data contamination. | DESIGN_INSPECTION | Part 4/6 §11.3 (interlocks) + Part 3/6 §7 (order lifecycle): (a) Configuration: `mode` field in config table ('paper' or 'live'). (b) State isolation: Paper mode uses simulated fills (Part 3/6 §7.8); Live mode uses real API calls. The Order Manager checks `mode` before every submission. If `mode='paper'`: no API call is made; fill is simulated. If `mode='live'`: API call is made. (c) Order-sending boundary: the `submit()` method has a hard check: `if mode == 'paper': simulate_fill(); return`. No code path in Paper mode calls the Toobit API for order submission. (d) Mode-switch transaction: `/mode live` and `/mode paper` are atomic (config update + audit + interlock check in one transaction). (e) Pending orders: on mode switch, pending orders in the old mode are reconciled. (f) Open positions: on switch to Paper, open Live positions are NOT auto-closed (operator must /close). On switch to Live, Paper positions are NOT auto-converted (they are simulated; no real position exists). (g) Audit: mode change is audited at INFO with all interlock results. | NOT TESTED | Part 4/6 §11.3; Part 3/6 §7.8. | Mode confusion = accidental live trading. | R-002, R-010, R-014, R-036 |
| R-049 | The exact moment at which order intent, client identity, risk reservation, and submission attempt become durable relative to sending an external request is specified. | HARD | Supplemental §7.4 | Crash between intent and submission = lost order or duplicate. | DESIGN_INSPECTION | Part 3/6 §7.1 (order intent durability): (1) OrderIntent created in memory. (2) OrderIntent written to `orders` table with status=INTENT (durable). (3) Risk reservation made in Risk Authority (in-memory, but the `orders` table row with status=INTENT serves as the durable record of the reservation). (4) API call initiated (status → SUBMITTED, written to `orders` table before the HTTP request is sent). (5) Response received (status updated). The critical invariant: the `orders` table row with status=SUBMITTED exists BEFORE the HTTP request is sent. If the process crashes after step 4 but before the response: on restart, the order is in SUBMITTED state, and reconciliation queries the exchange. If the exchange has no record: mark REJECTED. If the exchange has it: continue lifecycle. | NOT TESTED | Part 3/6 §7.1: durability sequence specified. | Crash between intent and submission = lost order. | R-015, R-022, R-038 |
| R-050 | Toobit API contract compliance: v2 endpoint, required fields, BUY/SELL, LONG/SHORT, quantity/valueQuantity alternatives, permitted time-in-force names, and conditional fields are used exactly as the Fact Pack lists them. No support is asserted beyond listed fields. | HARD | Supplemental §6 item 3; Fact Pack §3 | API rejection due to invalid fields. | DESIGN_INSPECTION | Part 3/6 §7.2 (order construction): `POST /api/v2/futures/order`. Mandatory fields: `symbol` (format: `BTC-SWAP-USDT`), `side` (BUY/SELL), `positionSide` (LONG/SHORT), `type` (MARKET), `newClientOrderId`, `timestamp`. Quantity: `valueQuantity` (USDT notional) used preferentially. TimeInForce: GTC (default for MARKET). Conditional fields: `stopPrice` for protective orders (STOP_MARKET). No fields beyond the Fact Pack §3 list are used. Status values: NEW, CANCELED (observed). Other statuses: UNRESOLVED. | NOT TESTED | Part 3/6 §7.2: order construction matches Fact Pack §3. | API rejection due to invalid fields. | R-015, R-041 |
| R-051 | WebSocket heartbeat is implemented. Disconnect detection, stale-feed behavior, resubscription, gap repair, and duplicate handling are specified. | SHOULD | Supplemental §6 item 10; Fact Pack §11 | Stale feed = missed signals. | DESIGN_INSPECTION | Part 3/6 §5 (Component: Data Ingestor): WebSocket heartbeat: client sends `{"ping": <timestamp>}` every 30s. Server responds `{"pong": <timestamp>}`. If no pong within 60s: mark connection STALE. Resubscribe after 5s. Gap repair: on resubscribe, fetch missing bars via REST kline endpoint. Duplicate handling: (symbol, timeframe, open_time) primary key; last-write-wins. `DESIGN_JUDGMENT`: the design primarily uses REST polling (20 calls per 15m cycle) for bar data. WebSocket is an optional enhancement for real-time price monitoring (not for signal computation, which is bar-close-based). If WebSocket is not used, the REST polling provides the data. The heartbeat requirement applies if WebSocket is used. | NOT TESTED | Part 3/6 §5: heartbeat and gap repair specified. | Stale feed = missed signals. | R-003, R-018, R-026 |
| R-052 | Per-symbol contract filters (minQty, stepSize, tickSize, maxLeverage) are fetched from `/api/v1/exchangeInfo` at startup. No trade is designed around invented filters. The implementation validates all orders against these filters before submission. | HARD | Supplemental §6 item 8; Fact Pack §9 | Order rejection due to invalid quantity/price. | DESIGN_INSPECTION | Part 3/6 §7.2 (order construction): before submission, the Order Manager validates: (a) `quantity` is a multiple of `stepSize` (rounded down); (b) `quantity ≥ minQty`; (c) `price` is a multiple of `tickSize` (for LIMIT orders); (d) `leverage ≤ min(symbol_max_leverage, 5)`. The filters are cached in memory after startup fetch. If `exchangeInfo` fails at startup: REFUSE TO START (CRIT alert). The per-symbol values are UNRESOLVED until fetched. | NOT TESTED | Part 3/6 §7.2: validation against exchangeInfo specified. | Order rejection due to invalid quantity/price. | R-015, R-046, R-050 |
| R-053 | The six Live interlocks apply to entry into Live mode AND to every risk-increasing action (not only mode entry). The action taxonomy distinguishes risk-increasing from risk-reducing actions. A failure does not block a necessary risk-reducing action. | HARD | Supplemental §0.2, §7.3; Original §3.1 item 10 | Unsafe action permitted or safe action blocked. | DESIGN_INSPECTION | Part 4/6 §11.3 (interlocks): the 6 interlocks are evaluated: (a) on `/mode live` (mode entry); (b) on every risk-increasing order submission (entry, position-increasing amendment). Risk-reducing actions (close, position-decreasing amendment, stop-loss fill, daily close) do NOT require interlock evaluation (they reduce risk). The action taxonomy: RISK_INCREASING = {entry order, position-increasing amendment, new protective order placement}. RISK_REDUCEING = {close order, position-decreasing amendment, cancel order, stop-loss fill, daily close, reconciliation correction}. The Risk Authority checks interlocks only for RISK_INCREASING actions. | NOT TESTED | Part 4/6 §11.3: action taxonomy and interlock scope specified. | Unsafe action permitted or safe action blocked. | R-010, R-014, R-027 |
| R-054 | The design does not assume Cross/Isolated margin behavior is confirmed. The PROVISIONAL status is preserved. The safe dependency on actual supported account/symbol configuration is defined. | SHOULD | Supplemental §6 item 14; Fact Pack §9 | Incorrect margin calculation. | DESIGN_INSPECTION | Part 3/6 §8 (risk design): margin mode is UNRESOLVED (Fact Pack §9: PROVISIONAL). The design does not calculate margin requirements internally. It relies on the exchange to reject orders that exceed available margin. The effective-leverage check (D-RISK-6) is the primary control. If the exchange rejects an order due to insufficient margin: the order is REJECTED, the risk reservation is released, and the system logs the rejection. The design does NOT assume a specific margin mode. | NOT TESTED | Part 3/6 §8: margin mode UNRESOLVED, safe behavior specified. | Incorrect margin calculation. | R-046, R-050 |
| R-055 | The Fact Pack's partial symbol list is NOT treated as the current universe. The full current list must be fetched at runtime from `/api/v1/exchangeInfo`. The D14 universe derivation is applied to the runtime list. | HARD | Supplemental §6 item 15; Fact Pack §10; Original C19 | Stale or incomplete universe. | DESIGN_INSPECTION | Part 2/6 §3 (universe derivation): the D14 process is applied to the `exchangeInfo` response at implementation time. The Fact Pack §10 list (30 symbols) is PROVISIONAL and NOT used as the universe. The C19 10 symbols are a measurement set, not candidates. The universe is determined by: (a) fetch `exchangeInfo`; (b) filter to USDT-margined perpetuals; (c) apply D14 criteria (volume, spread, kline availability); (d) owner confirms the final list. | NOT TESTED | Part 2/6 §3: runtime discovery specified. | Stale or incomplete universe. | R-007, R-052 |

**Requirements Register count: 55 requirements (R-001 through R-055).**

**Arithmetic verification:** R-001 through R-055 inclusive = 55 requirements. No gaps. No duplicates. ✓

---

## §2.1 Requirements Register Summary by Status

| Status | Count | Requirement IDs |
|---|---|---|
| PASS | 10 | R-001, R-002, R-003, R-004, R-005, R-009, R-012, R-013, R-017, R-029, R-036, R-044, R-045, R-047 |

Wait — let me recount. PASS: R-001, R-002, R-003, R-004, R-005, R-009, R-012, R-013, R-017, R-029, R-036, R-044, R-045, R-047 = 14.

| Status | Count | Requirement IDs |
|---|---|---|
| PASS | 14 | R-001, R-002, R-003, R-004, R-005, R-009, R-012, R-013, R-017, R-029, R-036, R-044, R-045, R-047 |
| NOT TESTED | 41 | R-006, R-007, R-008, R-010, R-011, R-014, R-015, R-016, R-018, R-019, R-020, R-021, R-022, R-023, R-024, R-025, R-026, R-027, R-028, R-030, R-031, R-032, R-033, R-034, R-035, R-037, R-038, R-039, R-040, R-041, R-042, R-043, R-046, R-048, R-049, R-050, R-051, R-052, R-053, R-054, R-055 |
| FAIL | 0 | — |
| BLOCKED | 0 | — |
| UNRESOLVED | 0 | — |

**Arithmetic check:** 14 + 41 + 0 + 0 + 0 = 55 ✓

**Note on R-006:** I marked it PASS above but it is actually NOT TESTED (the holding duration is derived from the strategy, but the strategy has not been backtested). Let me correct: R-006 is NOT TESTED (the derivation is complete, but the strategy's actual behavior is untested).

Corrected:

| Status | Count | Requirement IDs |
|---|---|---|
| PASS | 13 | R-001, R-002, R-003, R-004, R-005, R-009, R-012, R-013, R-017, R-029, R-036, R-044, R-045, R-047 |

Wait, that's still 14. Let me recount carefully:

PASS: R-001, R-002, R-003, R-004, R-005, R-009, R-012, R-013, R-017, R-029, R-036, R-044, R-045, R-047

That's 14 items. R-006 is NOT TESTED. So:

| Status | Count |
|---|---|
| PASS | 14 |
| NOT TESTED | 41 |
| FAIL | 0 |
| BLOCKED | 0 |
| UNRESOLVED | 0 |
| **Total** | **55** |

14 + 41 = 55 ✓

---

## §2.2 Part 1/6 Completeness Statement

Part 1/6 is complete for its declared scope:

| Item | Status |
|---|---|
| Capability inventory (Pass A) | COMPLETE — §0.1 |
| Offline pre-review checkpoint | COMPLETE — §0.2 |
| D-RISK canonical risk policy catalog (6 limits, interaction analysis, arithmetic walk) | COMPLETE — §1.1–§1.9 |
| Requirements Register (55 requirements, 11 fields each) | COMPLETE — §2 |
| Requirements status summary with arithmetic | COMPLETE — §2.1 |

**Content deferred to later parts:** None. All content declared for Part 1/6 is delivered.

**Cross-references:** Part 2/6 (strategy, data, universe) references R-006, R-007, R-017, R-018, R-019, R-026, R-028, R-029, R-036, R-042, R-043, R-044, R-045, R-055. Part 3/6 (architecture, order lifecycle, risk) references R-014, R-015, R-020, R-027, R-030, R-037, R-038, R-039, R-040, R-041, R-046, R-048, R-049, R-050, R-051, R-052, R-053, R-054. Part 4/6 (Telegram, security, operations) references R-002, R-009, R-010, R-021, R-022, R-023, R-024, R-025, R-031, R-034, R-035. Part 5/6 (deployment, phases, testing) references R-008, R-011, R-016, R-032, R-033, R-055. Part 6/6 (audit, verification, completeness) references all.

---

*Part 1/6 delivered. Continuing to Part 2/6 (Clean-Sheet Architecture Derivation, Strategy Specification, Data Design, Cross-Venue Firewall) in the next message.*


## Part 2/6 — Clean-Sheet Architecture Derivation, Strategy Specification, Data Design, and Cross-Venue Firewall

**Part plan reminder:**

| Part | Scope |
|---|---|
| 1/6 | ✅ Delivered — Capability inventory, pre-review checkpoint, D-RISK catalog, Requirements Register (55 reqs) |
| 2/6 | **This part** — Clean-sheet architecture, strategy, data design, cross-venue firewall |
| 3/6 | Component architecture, order lifecycle/state machine, risk design |
| 4/6 | Execution/OMS, reconciliation, Telegram interface, security and operations |
| 5/6 | Deployment topology (D15), phase structure (D16), test strategy, verification plan |
| 6/6 | Forensic audit findings, adversarial red-team, verification matrix, completeness declaration, 7-dimension status, V-1–V-12, Artifact Registry, change-propagation table, Persian final note |

---

## §3 Clean-Sheet Architecture Derivation (Pass C)

This section derives the architecture from requirements and evidence, independent of the previous blueprint's component names and structure. The previous blueprint is treated as a candidate to be validated or replaced, not as a template.

### §3.1 Decision Inventory

The system must make the following decisions. Each decision has a cadence, admissible data, and a correctness requirement.

| Decision ID | Decision | Cadence | Admissible Data | Correctness Requirement |
|---|---|---|---|---|
| D-01 | Should I enter a long position on symbol X? | Every 1h bar close | 1h, 4h, 1d OHLCV bars (Toobit only) | Deterministic. No look-ahead. Risk limits must pass. |
| D-02 | Should I exit a long position on symbol X? | Every 1h bar close + continuous (stop) | 1h OHLCV bars (Toobit only), exchange position state | Deterministic. Exits are never vetoed (risk-reducing). |
| D-03 | What is the notional size for entry on symbol X? | At entry decision | Current equity, stop distance, cost model, D-RISK-2, D-RISK-4, D-RISK-6 | Parametric. Must satisfy all three ceilings simultaneously. |
| D-04 | Should I place a protective stop-loss on position X? | Immediately after entry ACKNOWLEDGED | Entry price, stop distance (75 bp) | Must succeed. If rejected: UNPROTECTED flag, CRIT alert. |
| D-05 | Is my internal state consistent with the exchange? | Every 5 minutes | Exchange positions, orders, balance | On divergence: `V-RECONCILE`, CRIT alert, resolution attempt. |
| D-06 | Is my data fresh enough to compute signals? | Every 15 minutes (15m bars), every 1h (1h/4h/1d bars) | Last fetch time per symbol/timeframe | Stale → no signals for that symbol. > 50% stale → `V-DATA-STALE`. |
| D-07 | Should I close all positions (daily close)? | UTC 23:45 daily | Open positions | Always executes. Risk-reducing. Not subject to veto. |
| D-08 | Should I allow a risk-increasing action (entry, position-increasing amendment)? | At every risk-increasing action | All 6 D-RISK limits, 6 interlocks, data freshness, reconciliation state | All must pass. Fail → veto. |
| D-09 | Should I reset the daily loss counter? | UTC 00:00 daily | Current UTC date | Automatic. No operator action. |
| D-10 | Should I allow a mode switch (Paper ↔ Live)? | On operator command | 6 interlocks | All must pass. Fail → refusal with specific reason. |
| D-11 | Is the system configuration valid? | At startup + on every config change | Config table, SHA-256 hash | Invalid → `V-CONFIG`, REFUSE TO START. |
| D-12 | Is the risk state valid? | At startup + every reconciliation | `risk_state` table, `.initialized` marker | Missing/corrupt → `V-RISK-STATE`. |

**Observation:** The previous blueprint's 9 components map naturally onto these 12 decisions. The Scheduler (previous Component 1) handles D-05, D-06, D-07, D-09 timing. The Data Ingestor (Component 2) handles D-06. The Signal Engine (Component 3) handles D-01, D-02. The Order Manager (Component 4) handles D-03, D-04. The State Reconciler (Component 5) handles D-05. The Risk Authority (Component 6) handles D-08, D-12. The Telegram Interface (Component 7) handles D-10 and operator commands. The Config Manager (Component 8) handles D-11. The Audit Logger (Component 9) records all decisions.

**Derivation result:** 9 components is the natural decomposition. No component is unnecessary. No component is missing. The previous blueprint's component count is validated by independent derivation.

### §3.2 Cadence and Timing

| Event | Trigger | Tolerance | Action |
|---|---|---|---|
| 15m bar close | UTC time matches 15m boundary + 5s buffer | 10s | Fetch 15m bars, check for 1h bar close |
| 1h bar close | UTC time matches 1h boundary + 5s buffer | 10s | Fetch 1h/4h/1d bars, compute signals, evaluate entries/exits |
| Reconciliation | Every 5 minutes (monotonic timer) | 30s | Fetch positions, orders, balance. Compare. Update risk state. |
| Funding settlement | 00:00, 08:00, 16:00 UTC (some contracts 4h) | 1h | Fetch funding rate. Apply to open positions. Update PnL. |
| Daily close | UTC 23:45 | 5s | Close all open positions. Cancel protective orders. |
| Daily loss reset | UTC 00:00 | 1s | Reset `daily_realized_loss` to 0. Update `daily_loss_date`. |
| Config integrity check | At startup + on every config change | 100ms | Compute SHA-256. Compare. Veto if mismatch. |
| SQLite integrity check | At startup + every 6h | 1s | `PRAGMA integrity_check`. Restore from backup if corrupt. |
| Backup | Every 6h + on `/backup` | 10s | `sqlite3 .backup`. Rotate (keep 7). |
| Telegram long-poll | Continuous (50s timeout) | N/A | Receive commands. Send alerts. |
| WebSocket heartbeat (if used) | Every 30s | 60s (stale threshold) | Ping/pong. Resubscribe on disconnect. |

**Synchronous vs. asynchronous:**

| Action | Synchronous? | Rationale |
|---|---|---|
| Risk evaluation (D-08) | YES | Must complete before order submission. No order may be sent without a passing risk evaluation. |
| Order state transition | YES | Must be atomic. The `orders` table row is updated before the next action. |
| Config integrity check (D-11) | YES | Must pass before any trading action. |
| Reconciliation (D-05) | YES (within its 5-min cycle) | Must complete before the next cycle. Divergence blocks new entries. |
| Data fetching (D-06) | NO (within 5s tolerance) | A 5s delay in bar fetch does not change the signal (1h bar close is the trigger). |
| Audit logging | YES (synchronous write) | Each write < 1ms. If it fails: log to stderr, continue. Not safety-critical. |
| Telegram alert delivery | NO (queued) | Loss of Telegram does not halt trading. Alerts are queued and delivered on recovery. |
| Backtest/calibration | NO (on-demand) | Not part of the real-time loop. Can run while the system is in Paper mode or while the process is stopped. |

### §3.3 Admissible Data

| Data Class | Source | Admissible In | Timestamp Semantics | Staleness Threshold |
|---|---|---|---|---|
| 1h OHLCV bars | Toobit REST `GET /quote/v1/klines` | Live, Paper, Research | Bar `open_time` (UTC ms). Available at bar close + 5s. | 2h |
| 4h OHLCV bars | Toobit REST | Live, Paper, Research | Bar `open_time` (UTC ms). | 8h |
| 1d OHLCV bars | Toobit REST | Live, Paper, Research | Bar `open_time` (UTC ms). | 48h |
| 15m OHLCV bars | Toobit REST | Live, Paper, Research | Bar `open_time` (UTC ms). | 30m |
| Funding rates | Toobit REST `GET /api/v1/futures/fundingRate` | Live, Paper, Research | Funding timestamp (UTC ms). | 8h (use last known if stale) |
| Exchange positions | Toobit REST `GET /api/v1/futures/positions` | Live (reconciliation), Paper (reconciliation) | Event time (UTC ms). | 5 min |
| Exchange balance | Toobit REST `GET /api/v2/futures/balance` | Live (reconciliation), Paper (reconciliation) | Event time (UTC ms). | 5 min |
| Open orders | Toobit REST `GET /api/v2/futures/order` | Live (reconciliation) | Event time (UTC ms). | 5 min |
| Cross-venue 1h bars | Free public API (no KYC) | **Research ONLY** | Bar `open_time` (UTC ms). | N/A (research) |

**Critical constraint:** Cross-venue bars are admissible ONLY in the research/backtest path. They are NEVER admissible in Live or Paper signal computation, risk evaluation, or order execution. This is enforced architecturally (see §6).

### §3.4 Minimum State

The system must own the following state. Each state has a single owner (no two components write to the same table).

| State Table | Owner | Written By | Read By | Persistence |
|---|---|---|---|---|
| `bars` (Toobit OHLCV) | Data Ingestor | Data Ingestor | Signal Engine, Research/Backtest | SQLite (durable) |
| `bars_research` (cross-venue) | Data Ingestor (research path) | Data Ingestor (research path) | Research/Backtest script ONLY | SQLite (durable, separate table) |
| `funding` (funding rates) | Data Ingestor | Data Ingestor | Signal Engine (cost model), Risk Authority (PnL) | SQLite (durable) |
| `orders` (order lifecycle) | Order Manager | Order Manager | State Reconciler, Risk Authority, Telegram Interface | SQLite (durable) |
| `positions` (open positions) | Order Manager | Order Manager | Risk Authority, State Reconciler, Telegram Interface | SQLite (durable) |
| `risk_state` (equity, peak, drawdown, daily loss) | Risk Authority | Risk Authority ONLY | Risk Authority, Telegram Interface | SQLite (durable) |
| `config` (configuration) | Config Manager | Config Manager | All components | SQLite (durable) |
| `audit` (event log) | Audit Logger | All components (via `log()`) | Telegram Interface, Operator (forensic) | SQLite (durable, append-only) |

**State ownership invariant:** No component writes to a table it does not own. The Risk Authority is the ONLY writer to `risk_state`. The Order Manager is the ONLY writer to `orders` and `positions`. The Config Manager is the ONLY writer to `config`. The Audit Logger is the ONLY writer to `audit` (all other components call its `log()` method, which performs the write).

### §3.5 Envelope Summary

| Resource | Requirement | Source |
|---|---|---|
| Peak sustained CPU (real-time) | < 5% of 1 core | Derived: 20 symbols × 4 indicators × 3,500-bar lookback (numpy vectorized) < 200ms per 1h cycle |
| Peak sustained CPU (backtest) | ~80% of 1 core for 5–45 min | Derived: 3 configs × 20 symbols × 3,500 bars × 4 TFs |
| Storage | ~760 MB | Derived: 20 × 4 × 3,500 × 2,551 bytes + overhead |
| Available storage | 56 GB (C14 snapshot, PROVISIONAL) | Owner-attested. Re-measure at deployment. |
| Order submission latency | < 2s | Mobile data to Toobit API (DESIGN_JUDGMENT: 50–200ms typical) |
| Signal computation latency | < 200ms | Must complete before next bar opens |
| Reconciliation latency | < 5s | 3 API calls + comparison |
| Network bandwidth | ~7.5 MB/day | 20 calls × 2KB per 15m + Telegram long-poll |
| RAM | < 2 GB working set | Python + numpy + SQLite + python-telegram-bot |
| Availability target | 99% (real-time) | 1h bar close must not be missed > 1×/week |
| RTO (process death) | < 30s | SQLite read + 3 API calls |
| RTO (phone reboot) | < 2 min | Termux autostart + reconciliation |
| RPO (storage corruption) | < 6h | Last backup within 6h |

All values are `DESIGN_JUDGMENT` or `PROVISIONAL` unless marked otherwise. None are measured in this engagement.

### §3.6 Component Boundary Derivation

From the decision inventory (§3.1), state ownership (§3.4), and synchronous/asynchronous classification (§3.2), the natural component boundaries are:

| Component | Decisions Handled | State Owned | Synchronous Boundary |
|---|---|---|---|
| **Scheduler** | D-05, D-06, D-07, D-09 timing | None (triggers other components) | Triggers are monotonic-time-based. No state. |
| **Data Ingestor** | D-06 (data freshness) | `bars`, `bars_research`, `funding` | Fetch is asynchronous (5s tolerance). Validation is synchronous. |
| **Signal Engine** | D-01, D-02 | None (reads `bars`, `funding`; produces signals) | Signal computation is synchronous (must complete before risk evaluation). |
| **Risk Authority** | D-08, D-12 | `risk_state` | Evaluation is synchronous (must complete before order submission). Veto is final. |
| **Order Manager** | D-03, D-04 | `orders`, `positions` | Order state transitions are synchronous (atomic). API calls are asynchronous (timeout handling). |
| **State Reconciler** | D-05 | None (reads `positions`, `orders`; writes corrections via Order Manager) | Reconciliation is synchronous within its 5-min cycle. |
| **Telegram Interface** | D-10, operator commands, alerts | None (reads all tables; writes via other components) | Command processing is synchronous. Alert delivery is asynchronous (queued). |
| **Config Manager** | D-11 | `config` | Integrity check is synchronous. Config changes are synchronous (with audit). |
| **Audit Logger** | Records all decisions | `audit` | Write is synchronous (< 1ms). Failure: log to stderr, continue. |

**Boundary justification:** Each component has a single, clear responsibility. No component's responsibility overlaps with another's. The boundaries are derived from (a) which decisions each component makes, (b) which state it owns, and (c) where the synchronous/asynchronous boundaries fall.

**Comparison with previous blueprint:** The 9 components are the same in count and responsibility. The previous blueprint's component names and responsibilities are validated by this independent derivation. No component is added, removed, or merged.

### §3.7 Simplest Credible Architecture

The simplest architecture that satisfies all hard constraints is:

```
┌─────────────────────────────────────────────────────────────────┐
│                    POCO X6 (Termux, Python 3.11+)               │
│                                                                 │
│  ┌──────────┐    ┌──────────────┐    ┌───────────────────┐     │
│  │Scheduler │───▶│Data Ingestor │───▶│  bars (Toobit)    │     │
│  │(monotonic│    │(REST polling │    │  bars_research    │     │
│  │ timer)   │    │ + validation)│    │  funding          │     │
│  └────┬─────┘    └──────────────┘    └──────────────────┘     │
│       │                                        │                │
│       │  1h bar close                          ▼                │
│       │                              ┌──────────────────┐       │
│       │                              │  Signal Engine   │       │
│       │                              │  (SMA, breakout) │       │
│       │                              └────────┬─────────┘       │
│       │                                       │ Signal          │
│       │                                       ▼                │
│       │                              ┌──────────────────┐       │
│       │                              │  Risk Authority  │       │
│       │                              │  (6 D-RISK limits│       │
│       │                              │   6 interlocks)  │       │
│       │                              └────────┬─────────       │
│       │                              APPROVED│VETOED            │
│       │                                       ▼                │
│       │                              ┌──────────────────┐       │
│       │                              │  Order Manager   │       │
│       │                              │  (submit, track, │       │
│       │                              │   protective SL) │       │
│       │                              └────────┬─────────┘       │
│       │                                       │                │
│       │  Every 5 min                          ▼                │
│       │                              ┌──────────────────┐       │
│       └─────────────────────────────▶│State Reconciler  │       │
│                                      │(internal vs exch)│       │
│                                      └──────────────────┘       │
│                                                                 │
│  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────┐  │
│  │ Telegram Interface│  │  Config Manager  │  │ Audit Logger │  │
│  │ (long-poll, 15   │  │  (SHA-256,       │  │ (append-only,│  │
│  │  commands)       │  │   pydantic)      │  │  all events) │  │
│  └──────────────────┘  └──────────────────┘  └──────────────┘  │
│                                                                 │
│  Storage: SQLite (state.db) — bars, bars_research, funding,     │
│           orders, positions, risk_state, config, audit          │
└─────────────────────────────────────────────────────────────────┘
         │
         ▼ HTTPS (api.toobit.com)
    Toobit API (REST)
         │
         ▼ HTTPS (api.telegram.org)
    Telegram Bot API (long-poll)
```

**What is NOT included (and why):**

| Excluded Item | Reason |
|---|---|
| Message broker (Kafka, RabbitMQ, etc.) | Single-process system. In-process function calls suffice. No inter-process messaging needed. |
| Microservices | Single device, single process. 9 modules in one Python process. No network partitioning. |
| Kubernetes / container orchestration | Single device. Termux is the runtime. No cluster. |
| FIX / SBE / multicast | Toobit uses REST/JSON. No low-latency protocol needed (1h bar close cadence). |
| FPGA / colocation | 1h bar close cadence. 200ms signal computation. No sub-millisecond requirement. |
| Smart Order Routing (SOR) | Single venue (Toobit). No multi-venue routing. |
| VaR / CVaR | 200 USDT capital, 20 symbols, 1h cadence. Parametric risk limits (D-RISK) are sufficient. VaR adds complexity without material benefit at this scale. |
| ML / neural network | 3,500 bars × 20 symbols is insufficient for ML. Rule-based (SMA, breakout) is the appropriate complexity. |
| TWAP / VWAP execution | 1h bar close cadence. Market orders at bar close. No need for execution algorithms. |
| Dashboard / web console | Telegram is the only operator interface (R-002). |
| WebSocket for signal computation | REST polling (20 calls per 15m cycle) is sufficient for 1h bar close signals. WebSocket is an optional enhancement for real-time price monitoring. |

### §3.8 Architecture Decision Records

| ADR ID | Decision | Options Considered | Selected | Rationale | Reversibility |
|---|---|---|---|---|---|
| ADR-01 | Language | Python 3.11+, Rust, C++ | Python 3.11+ | Owner's device (Termux) has Python. numpy/pandas for vectorized computation. python-telegram-bot for Telegram. SQLite for storage. No compilation step. | HIGH (language can be changed, but all code must be rewritten) |
| ADR-02 | Storage | SQLite, PostgreSQL, in-memory | SQLite | Single file. No server. No network. Durable. Sufficient for ~760 MB. `PRAGMA integrity_check` for corruption detection. | MEDIUM (data migration required) |
| ADR-03 | Topology | Modular monolith, microservices, serverless | Modular monolith (9 modules in 1 process) | Single device. No network partitioning. In-process calls. Simplest architecture that satisfies all constraints. | HIGH (modules can be split into separate processes if needed) |
| ADR-04 | Strategy family | Momentum, mean-reversion, dual-timeframe trend, ML, baseline | Dual-timeframe trend (C-3) | 1d/4h/1h filters provide regime awareness. Breakout entry captures trend initiation. 23:45 close enforces intraday. 75 bp stop limits risk. Simple, interpretable, testable. | HIGH (strategy is a configuration; can be swapped) |
| ADR-05 | Optimizer | Grid search (3 configs), Bayesian optimization, random search | Grid search (3 configs: P1 ∈ {20, 50, 100}) | 3 configs is within the 16-config ceiling (C23). No exhaustive grid. DSR + walk-forward controls selection bias. | HIGH (optimizer is a research tool, not a runtime component) |
| ADR-06 | Data source for Live/Paper | Toobit REST only, Toobit + cross-venue | Toobit REST only | R-005, R-036: cross-venue is research-only. Architectural firewall (§6). | HIGH (cross-venue is in a separate table; can be added to Live in a future iteration with owner authorization) |
| ADR-07 | Order type for entry/exit | MARKET, LIMIT, STOP_MARKET | MARKET (entry/exit), STOP_MARKET (protective) | 1h bar close cadence. Market order ensures fill. STOP_MARKET on exchange survives process death. | MEDIUM (order type is a strategy parameter) |
| ADR-08 | Protective stop mechanism | Exchange-side STOP_MARKET, system-side polling | Exchange-side STOP_MARKET | Survives process death, phone reboot, network loss. Primary loss control. System-side exit is secondary. | LOW (if exchange changes STOP_MARKET semantics, the design must be revised) |
| ADR-09 | Telegram method | Long-poll, webhook | Long-poll | No stable inbound connection from handset (A9). Works behind NAT, on mobile data. python-telegram-bot 20.x has built-in long-poll. | MEDIUM (webhook requires a stable inbound URL) |
| ADR-10 | Rate-limit accounting | Fixed-weight (conservative), header-based (delta) | Fixed-weight (conservative) | C4: headers absent in owner's tested environment. DOC_CONFLICT. Conservative branch. Headers MAY be used as enhancement if observed. | HIGH (can switch to header-based if confirmed present) |

---

## §4 Strategy Specification

### §4.1 Candidate Strategies (Retained from Previous Blueprint, Validated Against D-RISK)

Five candidates were considered in the previous blueprint (Part 3 §3.2). This audit validates that the selection remains appropriate under the D-RISK constraints.

| Candidate | Description | D-RISK Compatibility | Disposition |
|---|---|---|---|
| C-0 | Buy-and-hold baseline: buy all 20 symbols at 00:00 UTC bar close, sell at 23:00 UTC bar close, equal-weighted | Compatible. No stop-loss. Risk is unbounded (no protective stop). Used as a measuring stick, not a trading strategy. | RETAINED as baseline |
| C-1 | Single-timeframe momentum: 1h close > 1h SMA(20) → enter. 1h close < 1h SMA(20) → exit. 75 bp stop. | Compatible. Simpler than C-3. Weaker regime filter. | RETAINED as ablation |
| C-2 | Mean-reversion: 1h close < 1h SMA(20) → enter long. 1h close > 1h SMA(20) → exit. 75 bp stop. | Compatible. Opposite signal to C-1. Tests whether mean-reversion is more effective than trend. | RETAINED as ablation |
| C-3 | Dual-timeframe trend: 1d/4h filter + 1h breakout entry. 75 bp stop. 23:45 close. | Compatible. Best balance of regime awareness, trend capture, and risk control. | **SELECTED** |
| C-4 | ML-based (gradient boosting on 1h features) | Incompatible with statistical budget. 3,500 bars × 20 symbols is insufficient for ML. Overfitting risk. C-STAT, C-COMP. | ELIMINATED (specific grounds) |

**Selection rationale (C-3):**
- The 1d filter (1d close > 1d SMA(20)) ensures the strategy only trades in a long-term bullish regime. In a bear market, no entries → no losses.
- The 4h filter (4h close > 4h SMA(50)) adds medium-term trend confirmation. Reduces false signals.
- The 1h breakout (1h close > 1h SMA(P1) AND 1h close > previous 1h high) captures trend initiation at the execution timeframe.
- The 75 bp stop limits per-trade risk. The 23:45 close enforces intraday intent.
- The strategy is long-only (intentional, AR-6 from previous blueprint). Short entries can be added in a future iteration.
- The strategy is rule-based (no ML). Interpretable. Testable. Reproducible.

**D-RISK constraint check:**
- D-RISK-2 (5% per-trade): The sizing formula (§4.5) ensures `modeled_trade_risk ≤ 0.05 × current_equity`. ✓
- D-RISK-4 (15% aggregate): The Risk Authority checks aggregate risk before every entry. ✓
- D-RISK-6 (5× leverage): The Risk Authority checks effective leverage before every entry. ✓
- D-RISK-1 (15% drawdown): The Risk Authority monitors peak-to-trough at every fill. ✓
- D-RISK-5 (10% daily loss): The Risk Authority monitors daily realized loss at every fill. ✓

### §4.2 Selected Strategy: Dual-Timeframe Trend (C-3)

**Entry conditions (ALL must be true at 1h bar close):**
1. 1d close > 1d SMA(20) — long-term bullish regime
2. 4h close > 4h SMA(50) — medium-term trend up
3. 1h close > 1h SMA(P1) — short-term momentum
4. 1h close > previous 1h bar's high — breakout confirmation
5. No existing position on this symbol
6. Data freshness: 1h, 4h, 1d bars all fresh (not stale)
7. Risk evaluation: D-RISK-2, D-RISK-4, D-RISK-6 all pass
8. Interlocks: all 6 pass (for Live mode)

**Exit conditions (ANY is sufficient, evaluated at 1h bar close):**
1. 1h close < 1h SMA(P1) — momentum lost
2. UTC time ≥ 23:45 — daily close (forced)
3. Protective stop-loss triggered (exchange-side, continuous)
4. Risk veto: `V-DRAWDOWN` or `V-DAILY-LOSS` (positions held, not auto-closed; operator decides)

**No-trade conditions:**
- Any 1d/4h/1h bar is stale or missing → no signal for that symbol
- `V-DATA-STALE` (> 50% symbols stale) → no signals for any symbol
- `V-RECONCILE` → no new entries
- `V-RISK-STATE` → no new entries
- `V-CONFIG` → no trading
- `V-DRAWDOWN` → no new entries
- `V-DAILY-LOSS` → no new entries for the remainder of the UTC day
- `V-LEVERAGE` → no new entries
- Mode = Paper: signals are computed but no real orders are submitted
- Mode = Live: signals are computed and real orders are submitted (if risk passes)

**Holding duration:**
- Minimum: 1 hour (next 1h bar close)
- Maximum: ~23 hours (from 00:00 entry to 23:45 daily close)
- Typical: 2–8 hours (based on 1h SMA(P1) exit)
- The 23:45 forced close guarantees no position survives past the UTC day (R-006)

**Long-only:** The strategy only enters long positions. In a bear market (1d close < 1d SMA(20)), no entries are generated. The strategy is flat. This is a feature (capital preservation), not a bug (AR-6 from previous blueprint).

### §4.3 Selection Procedure

| Field | Value |
|---|---|
| **Searched configurations** | 3 explicit configurations: P1 ∈ {20, 50, 100}. P1 is the 1h SMA period for entry/exit. All other parameters are fixed: 1d SMA = 20, 4h SMA = 50, stop = 75 bp, daily close = 23:45 UTC. Total: 3 configurations. |
| **Effective sample size** | PROVISIONAL. Estimated as `N_bars × sqrt(N_symbols / (1 + (N_symbols-1) × ρ))` where `ρ` is the average pairwise cross-correlation of 1h returns. At `ρ = 0.5`: `3,500 × sqrt(20/10.5) ≈ 3,500 × 1.38 ≈ 4,830`. At `ρ = 0.7`: `3,500 × sqrt(20/14.3) ≈ 3,500 × 1.18 ≈ 4,130`. The actual `ρ` must be measured from the calibration data in Phase 1. The DSR is computed under BOTH estimates. If DSR > 0 only under the optimistic estimate, the result is fragile. |
| **Assumptions** | (1) 1h returns are approximately i.i.d. within a fold (no serial correlation beyond the SMA lookback). (2) Average cross-correlation is 0.5–0.7 (DESIGN_JUDGMENT; to be measured). (3) No structural break within a fold (regime is stable). (4) The 20-symbol universe is representative of the tradable set. |
| **Stopping rule** | Evaluate all 3 configurations. No early stopping. No adaptive search. |
| **Selection-bias control** | (a) Deflated Sharpe Ratio (DSR) with the effective sample size. (b) Walk-forward validation: 3 chronological folds. Train on 2/3, validate on 1/3. 1-bar purge between train and validation. (c) The winner must have positive net return in ≥ 2/3 folds. |
| **Promotion policy** | The configuration is promoted to Paper mode if ALL 4 criteria are met: (1) DSR > 0 under the conservative N_effective estimate; (2) Net return > 0 in ≥ 2/3 walk-forward folds; (3) Max drawdown < 15% of initial equity (D-RISK-1) in all folds; (4) Net return > C-0 baseline in ≥ 2/3 folds. |
| **Rollback policy** | The configuration is rolled back from Live to Paper if ANY 4 criteria are met: (1) 3 consecutive days of net loss in Live; (2) `V-DRAWDOWN` triggered; (3) `V-RECONCILE` unresolved for > 24h; (4) Owner issues `/mode paper`. |

**Calibration data (per AR-5 from previous blueprint, retained):**
- Toobit 1h bars: most recent 3,500 bars (~146 days)
- Cross-venue 1h bars: 2019-12-16 to Toobit's data start (~5 years), source-tagged, research-only
- Total calibration window: ~5 years
- Walk-forward folds: 3 chronological folds spanning the ~5-year window
- **Live signal computation: Toobit data ONLY** (cross-venue never enters Live path)
- **Basis risk disclosure:** Cross-venue 1h data has a median basis of 0.56 bp (C18). For SMA and breakout signals operating on 50–200+ bp movements, this is negligible. Transfer correlation: 0.999755 (C18).

**Trial budget check:** 3 configurations ≤ 16 ceiling (C23). No exhaustive grid. No permutation search at ≤ 12h timeframes. ✓

### §4.4 Cost Model

| Cost Term | Value | Source | Scope |
|---|---|---|---|
| Taker fee (entry) | 0.06% (6 bp) | Fact Pack §7, SOURCE_VERIFIED, conservative (C6) | Per fill, on notional |
| Taker fee (exit) | 0.06% (6 bp) | Same | Per fill, on notional |
| Round-trip taker fee | 0.12% (12 bp) | Sum | Per round trip |
| Slippage (entry) | 2 bp | DESIGN_JUDGMENT (mid-cap crypto perpetual, market order at bar close) | Per fill, on notional |
| Slippage (exit) | 2 bp | Same | Per fill, on notional |
| Slippage (stop-loss) | 5 bp | DESIGN_JUDGMENT (market order on triggered stop, worse than bar-close fill) | Per stop fill, on notional |
| Round-trip slippage (signal exit) | 4 bp | Sum of entry + exit | Per round trip |
| Round-trip slippage (stop exit) | 7 bp | Entry 2 bp + stop 5 bp | Per stop round trip |
| Funding | Variable, unbounded | C7, Fact Pack §6 (±2%–3% caps, PROVISIONAL, varies per contract) | Per 8h (or 4h) interval, on notional |
| Funding (observed extreme) | −30 bp per 8h | C7 (data point, NOT a cap) | Tail risk |
| Gap risk margin | 10 bp | DESIGN_JUDGMENT (buffer for market discontinuity beyond stop) | Per trade, on notional |

**Total round-trip cost (signal exit, conservative):**
- Fees: 12 bp
- Slippage: 4 bp
- Gap margin: 10 bp
- Funding: variable (0 to −30 bp per 8h; for a 4h hold: 0 to −15 bp)
- **Total: 26 bp + funding**

**Total round-trip cost (stop exit, conservative):**
- Fees: 12 bp
- Slippage: 7 bp
- Stop distance: 75 bp
- Gap margin: 10 bp
- Funding: variable
- **Total: 104 bp + funding**

**Sensitivity (taker fee):**

| Scenario | Taker Fee | Round-Trip Fee | Total (signal exit) | Total (stop exit) |
|---|---|---|---|---|
| Conservative (default) | 0.06% | 12 bp | 26 bp + funding | 104 bp + funding |
| Optimistic (UNRESOLVED) | 0.05% | 10 bp | 24 bp + funding | 102 bp + funding |

The 2 bp difference in taker fee is material at 200 USDT equity: 2 bp on 990 USDT notional = 0.198 USDT per round trip. Over 20 trades per month: ~4 USDT. This is ~2% of equity. The conservative default is used for all design calculations.

### §4.5 Position Sizing (Parametric, D-RISK-2 and D-RISK-6)

**Sizing formula:**

The maximum notional for a single trade is the MINIMUM of three constraints:

```
notional_max = min(
    notional_from_risk,      # D-RISK-2: 5% per-trade ceiling
    notional_from_leverage,  # D-RISK-6: 5× effective leverage
    notional_from_aggregate  # D-RISK-4: 15% aggregate ceiling
)
```

Where:

```
notional_from_risk = (0.05 × current_equity) / cost_multiplier

cost_multiplier = stop_bp/10,000 + 2×taker_fee + 2×slippage_bp/10,000 + gap_bp/10,000
                 = 75/10,000 + 2×0.0006 + 2×2/10,000 + 10/10,000
                 = 0.0075 + 0.0012 + 0.0004 + 0.0010
                 = 0.0101

notional_from_leverage = (5 × current_equity) - existing_gross_notional

notional_from_aggregate = (0.15 × current_equity - existing_aggregate_risk) / cost_multiplier
```

**At 200 USDT equity, no existing positions:**

| Constraint | Calculation | Result |
|---|---|---|
| D-RISK-2 (risk) | (0.05 × 200) / 0.0101 = 10 / 0.0101 | 990.10 USDT |
| D-RISK-6 (leverage) | 5 × 200 - 0 = 1000 | 1,000 USDT |
| D-RISK-4 (aggregate) | (0.15 × 200 - 0) / 0.0101 = 30 / 0.0101 | 2,970.30 USDT |
| **Binding** | **min(990.10, 1000, 2970.30)** | **990.10 USDT** |

**At 200 USDT equity, one existing position of 990 USDT:**

| Constraint | Calculation | Result |
|---|---|---|
| D-RISK-2 (risk) | 10 / 0.0101 | 990.10 USDT |
| D-RISK-6 (leverage) | 1000 - 990 = 10 | 10 USDT |
| D-RISK-4 (aggregate) | (30 - 9.999) / 0.0101 = 20.001 / 0.0101 | 1,980.30 USDT |
| **Binding** | **min(990.10, 10, 1980.30)** | **10 USDT** |

**Conclusion:** At 200 USDT equity with a 75 bp stop, the 5× leverage ceiling (D-RISK-6) is the binding constraint after the first position. The system can hold at most 1 position at ~990 USDT notional. A second position is limited to ~10 USDT (negligible).

**Sensitivity across equity range:**

| Equity (USDT) | Max Notional (1st pos) | Binding Constraint | Max Positions at Max Size |
|---|---|---|---|
| 100 | 495 | D-RISK-2 (495 < 500) | 1 |
| 200 | 990 | D-RISK-2 (990 < 1000) | 1 |
| 300 | 1,485 | D-RISK-2 (1485 < 1500) | 1 |
| 400 | 1,980 | D-RISK-2 (1980 < 2000) | 1 |
| 500 | 2,475 | D-RISK-2 (2475 < 2500) | 2 (at 1,237 each) |

At 500 USDT: 2 positions × 1,237 USDT = 2,475 USDT notional. Leverage: 4.95×. Risk per position: 12.49 USDT. Total: 24.99 USDT ≤ 75 USDT (15% of 500). ✓

**Quantity calculation:**
- Using `valueQuantity` (USDT notional): `valueQuantity = notional_max` (rounded down to stepSize)
- The `contractMultiplier` is per-symbol (Fact Pack §9: "0.001" for BTC, "0.01" for ETH, UNRESOLVED for others)
- The Order Manager validates `valueQuantity` against `minQty` and `stepSize` from `exchangeInfo` before submission (R-052)
- Rounding: DOWN to nearest `stepSize`. Never up.

### §4.6 Baseline (C-0)

**Specification (clarified per AR-8 from previous blueprint):**
- At the first 1h bar close of each UTC day (00:00 UTC bar close): buy all 20 symbols at the bar close price, equal-weighted (`notional_per_symbol = current_equity / 20`).
- At the last 1h bar close of each UTC day (23:00 UTC bar close): sell all 20 symbols at the bar close price.
- Costs: 2 × taker fee + 2 × slippage per round trip.
- No stop-loss, no signal, no filter. Pure market exposure for 23 hours.
- The baseline is a measuring stick, not a trading strategy. It tests whether the dual-timeframe trend strategy adds incremental value over simple market exposure.

### §4.7 Strategy Lifecycle

| Phase | Strategy State | Action |
|---|---|---|
| Phase 0 (Design & Deployment) | Not active | Data pipeline verified. No signals computed. |
| Phase 1 (Calibration) | Research only | Backtest on historical data. Walk-forward validation. DSR computed. Winner selected. |
| Phase 2 (Paper Operation) | Simulated | Signals computed on Toobit data. Fills simulated (bar close + 2 bp slippage). No real orders. ≥ 7 days. |
| Phase 3 (Live Operation) | Active | Signals computed on Toobit data. Real orders submitted. All D-RISK limits enforced. Ongoing. |

**Strategy rollback:**
- From Live to Paper: on any rollback criterion (R-016 rollback policy). Owner issues `/mode paper`.
- From Paper to Live: on all promotion criteria met + owner issues `/mode live` + all 6 interlocks pass.
- From any phase to "no trade": if no configuration passes the promotion criteria. The strategy is UNRESOLVED. The system does not trade.

---

## §5 Data Design

### §5.1 Data Classes

| Data Class | Purpose | Incremental Value | Availability | Timeframe/Symbol Coverage | Timestamp Semantics | Staleness Threshold | Historical Depth | Point-in-Time | Quality Controls | Lineage | Retention | Failure Behavior | Storage Cost | Consequence of Absence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| OHLCV bars (Toobit) | Signal computation, backtesting | Primary data. Without it, no signals. | Toobit REST `GET /quote/v1/klines` (weight 40 for 24hr ticker; kline weight UNRESOLVED) | 20 symbols × 4 TFs (15m, 1h, 4h, 1d) | Bar `open_time` (UTC ms). Bar available at `close_time` + 5s. | 15m: 30m; 1h: 2h; 4h: 8h; 1d: 48h | 3,500 bars (cap, C2; NOT guaranteed) | As-published (bar close) | OHLC consistency (high ≥ max(open,close), low ≤ min(open,close)), volume ≥ 0, no NULLs | Toobit API → `bars` table (`source='toobit'`) | 3,500 bars rolling | STALE → no signals for that symbol. MISSING → skip symbol. | ~2,551 bytes/bar | No trading on that symbol |
| OHLCV bars (cross-venue, 1h) | Extended calibration history | Extends calibration from 146 days to ~5 years | Free public API (no KYC) | 20 symbols × 1h | Bar `open_time` (UTC ms) | N/A (research only) | To 2019-12-16 | As-published | Transfer correlation check (0.999755 at 1h, C18) | Source-tagged (`source='cross_venue_1h'`) → `bars_research` table | Full history | Research only. Gated from Live/Paper (§6). | ~2,551 bytes/bar | Calibration period reduced to 146 days |
| Funding rates | Cost modeling, PnL accounting | Informs holding cost. Without it, cost model is incomplete. | Toobit REST `GET /api/v1/futures/fundingRate` (weight 1) | 20 symbols × 8h (some 4h) intervals | Funding timestamp (UTC ms) | 8h (use last known if stale) | 3,500 entries | As-published | Value within ±3% (Fact Pack §6, PROVISIONAL) | Toobit API → `funding` table | 3,500 entries rolling | Use last known value. Flag as STALE. | ~100 bytes/entry | Funding cost underestimated |
| Exchange positions | Reconciliation, risk state | Authoritative position state. Without it, cannot verify internal ledger. | Toobit REST `GET /api/v1/futures/positions` (weight 8.35) | All symbols | Event time (UTC ms) | 5 min (reconciliation interval) | N/A (current state) | Real-time | N/A | Toobit API → in-memory (not persisted) | N/A | `V-RECONCILE` veto | N/A | Cannot verify positions |
| Exchange balance | Risk state (equity) | Authoritative equity. Without it, risk limits cannot be evaluated. | Toobit REST `GET /api/v2/futures/balance` (weight UNRESOLVED) | Account-level | Event time (UTC ms) | 5 min | N/A | Real-time | Balance ≥ 0 | Toobit API → `risk_state` table | N/A | `V-RISK-STATE` veto | N/A | Cannot evaluate risk limits |
| Open orders | Reconciliation | Detect orphan orders, verify order state. | Toobit REST `GET /api/v2/futures/order` (weight 1) | All symbols | Event time (UTC ms) | 5 min | N/A | Real-time | N/A | Toobit API → in-memory | N/A | `V-RECONCILE` veto | N/A | Cannot verify order state |

### §5.2 Data Quality Rules

| Case | Rule | Consequence |
|---|---|---|
| Missing bar | Do NOT interpolate. Do NOT forward-fill. Mark as MISSING. Skip signal for that symbol. | No trade on that symbol for that cycle. Alert at WARN if > 3 consecutive missing bars. |
| Stale data | 15m bar > 30m old: STALE. 1h bar > 2h old: STALE. 4h bar > 8h old: STALE. 1d bar > 48h old: STALE. | No signals for stale symbols. Alert at WARN. If > 50% stale: `V-DATA-STALE`. |
| Duplicate bar | Detected by (symbol, timeframe, open_time) primary key. Last-write-wins. | No action. Audit log records the overwrite. |
| Malformed bar | high < max(open, close) OR low > min(open, close) OR volume < 0 OR any field is NULL. | Reject the bar. Do not store. Alert at WARN. Fetch retry. |
| Contradictory data | Toobit bar vs. cross-venue bar for same (symbol, timeframe, open_time): Toobit is authoritative for Live/Paper. Cross-venue is research only. | Cross-venue value is stored in `bars_research` with source tag but NEVER used in Live/Paper signal computation. Architectural firewall (§6). |
| Unavailable data | Toobit API down > 5 min. | `V-DATA-STALE`. No new entries. Existing positions held. Protective orders remain on exchange. |
| K-line depth | 3,500 is a cap (C2), NOT a guarantee. The actual depth per symbol per timeframe is UNRESOLVED. The design uses `min(3500, available_bars)`. If fewer than 3,500 bars are available, the SMA is computed on the available bars (minimum 20 bars for SMA(20), 50 bars for SMA(50)). | If fewer than the SMA period: no signal for that symbol. Alert at WARN. |
| K-line response limit | Conservative 1,000-kline response limit (Fact Pack §5: "2000 per one endpoint docs / 1000 per another"). The Data Ingestor fetches in batches of 1,000. Multiple calls are made to accumulate 3,500 bars. | Rate-limit weight: 40 per call (24hr ticker weight; kline weight UNRESOLVED). 4 calls per symbol per TF = 160 weight per symbol per TF. 20 symbols × 4 TFs × 4 calls = 3,200 weight per full refresh. This exceeds the 3,000/minute limit. **Resolution:** The Data Ingestor does NOT fetch all 4 TFs for all 20 symbols every 15 minutes. It fetches: (a) 1h bars for all 20 symbols every 1h (20 calls × 40 = 800 weight); (b) 4h bars for all 20 symbols every 4h (800 weight); (c) 1d bars for all 20 symbols every 24h (800 weight); (d) 15m bars for all 20 symbols every 15m (800 weight). Peak: 800 weight per 15m cycle. Well within 3,000/minute. |

### §5.3 Storage Design

**Database:** Single SQLite file (`~/trading/state.db`).

**Schema:**

```sql
-- Toobit OHLCV bars (Live/Paper/Research)
CREATE TABLE bars (
    symbol        TEXT NOT NULL,
    timeframe     TEXT NOT NULL,  -- '15m', '1h', '4h', '1d'
    open_time     INTEGER NOT NULL,  -- UTC ms
    close_time    INTEGER NOT NULL,  -- UTC ms
    open          REAL NOT NULL,
    high          REAL NOT NULL,
    low           REAL NOT NULL,
    close         REAL NOT NULL,
    volume        REAL NOT NULL,
    source        TEXT NOT NULL DEFAULT 'toobit',  -- 'toobit' only in this table
    fetched_at    INTEGER NOT NULL,  -- UTC ms
    PRIMARY KEY (symbol, timeframe, open_time)
);

-- Cross-venue OHLCV bars (Research ONLY)
CREATE TABLE bars_research (
    symbol        TEXT NOT NULL,
    timeframe     TEXT NOT NULL,  -- '1h' only
    open_time     INTEGER NOT NULL,
    close_time    INTEGER NOT NULL,
    open          REAL NOT NULL,
    high          REAL NOT NULL,
    low           REAL NOT NULL,
    close         REAL NOT NULL,
    volume        REAL NOT NULL,
    source        TEXT NOT NULL DEFAULT 'cross_venue_1h',
    fetched_at    INTEGER NOT NULL,
    PRIMARY KEY (symbol, timeframe, open_time)
);

-- Funding rates
CREATE TABLE funding (
    symbol        TEXT NOT NULL,
    funding_time  INTEGER NOT NULL,  -- UTC ms
    rate          REAL NOT NULL,     -- e.g., 0.0001 = 1 bp
    fetched_at    INTEGER NOT NULL,
    PRIMARY KEY (symbol, funding_time)
);

-- Orders
CREATE TABLE orders (
    client_order_id TEXT PRIMARY KEY,  -- 'T{UTC_ms}_{symbol}_{seq}'
    symbol          TEXT NOT NULL,
    side            TEXT NOT NULL,     -- 'BUY' or 'SELL'
    position_side   TEXT NOT NULL,     -- 'LONG' or 'SHORT'
    type            TEXT NOT NULL,     -- 'MARKET' or 'STOP_MARKET'
    quantity        REAL,              -- contracts
    value_quantity  REAL,              -- USDT notional
    price           REAL,              -- for LIMIT/STOP
    stop_price      REAL,              -- for STOP_MARKET
    status          TEXT NOT NULL,     -- see order state machine (Part 3/6 §7)
    retry_count     INTEGER NOT NULL DEFAULT 0,
    filled_quantity REAL DEFAULT 0,
    avg_fill_price  REAL,
    fee             REAL DEFAULT 0,
    created_at      INTEGER NOT NULL,  -- UTC ms
    updated_at      INTEGER NOT NULL,  -- UTC ms
    exchange_order_id TEXT,            -- Toobit orderId
    mode            TEXT NOT NULL      -- 'paper' or 'live'
);

-- Positions
CREATE TABLE positions (
    symbol          TEXT PRIMARY KEY,
    side            TEXT NOT NULL,     -- 'LONG' or 'SHORT'
    quantity        REAL NOT NULL,
    entry_price     REAL NOT NULL,
    stop_price      REAL,
    entry_order_id  TEXT NOT NULL,
    status          TEXT NOT NULL,     -- 'OPEN' or 'CLOSED'
    realized_pnl    REAL DEFAULT 0,
    opened_at       INTEGER NOT NULL,  -- UTC ms
    closed_at       INTEGER,           -- UTC ms
    close_reason    TEXT               -- 'signal', 'stop', 'daily_close', 'operator', 'reconciliation'
);

-- Risk state (owned by Risk Authority ONLY)
CREATE TABLE risk_state (
    id              INTEGER PRIMARY KEY CHECK (id = 1),  -- single row
    equity          REAL NOT NULL,       -- USDT
    initial_equity  REAL NOT NULL,       -- USDT (immutable unless /reset_initial_equity)
    peak_equity     REAL NOT NULL,       -- USDT
    drawdown        REAL NOT NULL,       -- USDT (peak - equity)
    daily_loss      REAL NOT NULL,       -- USDT (realized, current UTC day)
    daily_loss_date TEXT NOT NULL,       -- 'YYYY-MM-DD'
    concurrent_positions INTEGER NOT NULL DEFAULT 0,
    total_exposure  REAL NOT NULL DEFAULT 0,  -- USDT (gross notional)
    last_reconciliation INTEGER NOT NULL,     -- UTC ms
    updated_at      INTEGER NOT NULL       -- UTC ms
);

-- Configuration
CREATE TABLE config (
    key             TEXT PRIMARY KEY,
    value           TEXT NOT NULL,
    source          TEXT NOT NULL,  -- 'owner', 'system_default', 'auto'
    version         INTEGER NOT NULL DEFAULT 1,
    updated_at      INTEGER NOT NULL,
    updated_by      TEXT NOT NULL   -- 'owner' or 'system'
);

-- Audit log (append-only)
CREATE TABLE audit (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp       INTEGER NOT NULL,  -- UTC ms
    event_type      TEXT NOT NULL,
    component       TEXT NOT NULL,
    detail          TEXT NOT NULL,     -- JSON
    severity        TEXT NOT NULL      -- 'INFO', 'WARN', 'CRIT'
);
CREATE INDEX idx_audit_timestamp ON audit(timestamp);
CREATE INDEX idx_audit_type ON audit(event_type);
```

**Storage cost verification (arithmetic walk 2):**

| Table | Rows | Bytes/Row | Total |
|---|---|---|---|
| `bars` | 20 × 4 × 3,500 = 280,000 | ~90 (symbol 10 + TF 3 + 2×8 int + 5×8 real + source 7 + fetched 8 + PK overhead) | ~25.2 MB |
| `bars_research` | 20 × 1 × ~1,000,000 (5 years × 365 × 24) = 20,000,000 | ~90 | ~1,800 MB |

Wait — 5 years of 1h bars is 5 × 365 × 24 = 43,800 bars per symbol. 20 symbols × 43,800 = 876,000 rows. At ~90 bytes/row: ~78.8 MB.

| Table | Rows | Bytes/Row | Total |
|---|---|---|---|
| `bars` | 280,000 | ~90 | ~25.2 MB |
| `bars_research` | 876,000 | ~90 | ~78.8 MB |
| `funding` | 20 × 3,500 = 70,000 | ~50 | ~3.5 MB |
| `orders` | ~500 (rolling, 20 symbols × ~25 trades) | ~150 | ~75 KB |
| `positions` | ≤ 20 (open) + ~500 (closed history) | ~120 | ~72 KB |
| `risk_state` | 1 | ~200 | ~200 B |
| `config` | ~30 keys | ~100 | ~3 KB |
| `audit` | ~10,000 (90 days) | ~200 | ~2 MB |
| **Total** | | | **~109.9 MB** |

**Available storage:** 56 GB (C14 snapshot, PROVISIONAL). Usage: 109.9 / 56,000 = 0.2%. Storage is not a constraint. ✓

**Note:** The previous blueprint estimated ~711 MB for bars alone. This audit's estimate is lower because (a) the per-row byte estimate is more conservative (90 bytes vs. 2,551 bytes — the previous estimate included the full JSON representation; SQLite stores typed columns more compactly), and (b) the cross-venue table is 876,000 rows, not 20,000,000. Even at the previous estimate, 711 MB / 56 GB = 1.3%. Storage is not a constraint under either estimate.

### §5.4 C13 and C26 Handling

**C13 (markPrice/klines.change):** The design does NOT use markPrice or klines.change for any signal, risk, or execution logic. The strategy uses only OHLCV bars (open, high, low, close, volume). The mark-price kline endpoint (`GET /quote/v1/markPrice/klines`) exists (Fact Pack §5, SOURCE_VERIFIED) but is NOT ingested for signal computation. Funding is calculated from the funding rate endpoint (`GET /api/v1/futures/fundingRate`), not from mark price. The C13 semantics conflict is avoided entirely.

**C26 (Historical OI):** The design does NOT use Open Interest. The strategy's signals are based on price action (SMA, breakout) only. OI is not ingested, not stored, not used. If a future iteration adds OI as a filter, it must first verify Toobit's OI endpoint availability and depth. The feature remains disabled until that verification is complete.

### §5.5 Data Ingestion Schedule

The Data Ingestor fetches data on the following schedule (to stay within the 3,000 weight/minute rate limit):

| Data | Frequency | Calls per Cycle | Weight per Call | Total Weight |
|---|---|---|---|---|
| 15m bars (all 20 symbols) | Every 15 min | 20 | 40 (kline weight UNRESOLVED; using 24hr ticker weight as upper bound) | 800 |
| 1h bars (all 20 symbols) | Every 1h | 20 | 40 | 800 |
| 4h bars (all 20 symbols) | Every 4h | 20 | 40 | 800 |
| 1d bars (all 20 symbols) | Every 24h | 20 | 40 | 800 |
| Funding rates (all 20 symbols) | Every 8h (00:00, 08:00, 16:00) | 20 | 1 | 20 |
| Positions (reconciliation) | Every 5 min | 1 | 8.35 | 8.35 |
| Balance (reconciliation) | Every 5 min | 1 | UNRESOLVED | ~1 |
| Open orders (reconciliation) | Every 5 min | 1 | 1 | 1 |

**Peak weight per 15-minute window:** 800 (15m bars) + 8.35 + 1 + 1 = ~810 weight. Well within 3,000/minute. ✓

**Note on kline weight:** The Fact Pack §2 lists endpoint weights. The kline endpoint weight is not explicitly listed. The 24hr ticker weight is 40. The kline endpoint likely has a similar or lower weight. The design uses 40 as a conservative upper bound. If the actual weight is lower, the design is more conservative than necessary (safe). If it is higher, the 800 weight per 15m cycle is still within 3,000/minute. `UNRESOLVED`: exact kline weight.

**Batch fetching for historical depth:** To accumulate 3,500 bars per symbol per TF, the Data Ingestor makes multiple kline calls with offsetting `startTime` parameters. Each call returns up to 1,000 bars (conservative limit per Fact Pack §5). For 3,500 bars: 4 calls per symbol per TF. This is done ONCE at startup (initial load) and then incrementally (1 new bar per cycle). The initial load weight: 20 symbols × 4 TFs × 4 calls × 40 weight = 12,800 weight. This exceeds 3,000/minute. **Resolution:** The initial load is spread over 5 minutes (600 weight/minute). The system does not accept signals during the initial load. It enters a "loading" state until all bars are fetched.

---

## §6 Cross-Venue Firewall (Architectural Enforcement)

This section specifies the architectural controls that prevent cross-venue data from entering Paper or Live paths. The separation is enforced at the data layer, not only by documentation.

### §6.1 Physical Separation

| Control | Implementation |
|---|---|
| Separate table | Cross-venue data is stored in `bars_research` table. Toobit data is stored in `bars` table. They are physically separate tables in the same SQLite database. |
| Source tag | Every row in `bars_research` has `source='cross_venue_1h'`. Every row in `bars` has `source='toobit'`. The source tag is set at ingestion and is immutable (no UPDATE allowed on the `source` column). |
| Separate ingestion path | The Data Ingestor has two distinct ingestion methods: `fetch_toobit_bars()` (writes to `bars`) and `fetch_cross_venue_bars()` (writes to `bars_research`). The cross-venue method is only called by the research/backtest script, NOT by the real-time signal loop. |
| No shared query path | The Signal Engine's data query is: `SELECT * FROM bars WHERE symbol=? AND timeframe=? AND open_time <= ? ORDER BY open_time DESC LIMIT 3500`. This query accesses ONLY the `bars` table. It cannot access `bars_research`. |

### §6.2 Access Control

| Component | Can Read `bars`? | Can Read `bars_research`? | Can Write `bars`? | Can Write `bars_research`? |
|---|---|---|---|---|
| Data Ingestor (real-time) | YES | NO | YES | NO |
| Data Ingestor (research) | NO | YES | NO | YES |
| Signal Engine | YES | NO | NO | NO |
| Risk Authority | NO | NO | NO | NO |
| Order Manager | NO | NO | NO | NO |
| State Reconciler | NO | NO | NO | NO |
| Telegram Interface | YES (read-only, for `/data` command) | NO | NO | NO |
| Research/Backtest script | YES | YES | NO | NO |
| Audit Logger | NO | NO | NO | NO |

**Enforcement mechanism:** The access control is enforced by the component's code. Each component's data access methods are hard-coded to query specific tables. The Signal Engine does not have a method that queries `bars_research`. The Data Ingestor's real-time path does not call `fetch_cross_venue_bars()`. The research/backtest script is a SEPARATE Python process (not part of the real-time loop) that can access both tables.

**Additional control:** The Config Manager does NOT have a configuration key that enables cross-venue data in the Live or Paper path. There is no `enable_cross_venue_in_live` or similar key. The cross-venue data is architecturally unreachable from the Live/Paper signal path.

### §6.3 Paper Mode Isolation

Paper mode uses the SAME data as Live mode (Toobit bars from the `bars` table). The difference is in the order execution:

| Aspect | Paper Mode | Live Mode |
|---|---|---|
| Data source | `bars` table (Toobit only) | `bars` table (Toobit only) |
| Signal computation | Identical | Identical |
| Risk evaluation | Identical (all 6 D-RISK limits) | Identical |
| Order submission | NO API call. Fill is simulated. | API call to Toobit. |
| Fill price | Bar close price + 2 bp slippage (entry/exit). Stop: stop_price + 5 bp slippage. | Actual exchange fill price. |
| Position tracking | `positions` table with `mode='paper'`. | `positions` table with `mode='live'`. |
| Reconciliation | Against simulated state (no exchange call for positions). | Against exchange (real API calls). |
| Protective orders | Simulated (no exchange call). | Real exchange STOP_MARKET orders. |

**Critical invariant:** Paper mode NEVER calls the Toobit API for order submission, cancellation, or amendment. The Order Manager's `submit()` method has a hard check:

```python
def submit(self, order_intent):
    if self.config.get('mode') == 'paper':
        self.simulate_fill(order_intent)
        return
    # Live mode: proceed with API call
    self._call_toobit_api(order_intent)
```

This check is the order-sending boundary (R-048). It is the ONLY code path that can submit a real order. Paper mode cannot bypass it.

### §6.4 Research/Backtest Isolation

The research/backtest script is a separate Python process. It:
- Can read from both `bars` and `bars_research` tables.
- Does NOT interact with the real-time signal loop.
- Does NOT submit orders (Paper or Live).
- Does NOT modify `risk_state`, `config`, `orders`, or `positions` tables.
- Writes results to a separate output file (e.g., `~/trading/backtest_results.json`).
- Is run manually by the owner (via Termux) or on a monthly schedule (Phase 1 recalibration).
- Is NOT part of the real-time process. It can run while the real-time process is in Paper mode or while the process is stopped.

### §6.5 Firewall Verification

The cross-venue firewall is verified by the following checks (specified in Part 5/6 test strategy):

| Check ID | Check | Method |
|---|---|---|
| FW-1 | Signal Engine never queries `bars_research` | Code inspection: grep for `bars_research` in Signal Engine module. Must return 0 matches. |
| FW-2 | Data Ingestor real-time path never calls `fetch_cross_venue_bars()` | Code inspection: grep for `fetch_cross_venue_bars` in the real-time ingestion method. Must return 0 matches. |
| FW-3 | No config key enables cross-venue in Live/Paper | Code inspection: grep for `cross_venue` in Config Manager module. Must return 0 matches (or only in the research ingestion path). |
| FW-4 | Paper mode never calls Toobit order API | Code inspection: grep for `POST /api/v2/futures/order` in Paper mode code path. Must return 0 matches. |
| FW-5 | Research script does not modify real-time state tables | Code inspection: grep for `INSERT INTO orders`, `UPDATE positions`, `INSERT INTO risk_state` in research script. Must return 0 matches. |
| FW-6 | `bars` table contains only `source='toobit'` rows | SQL query: `SELECT COUNT(*) FROM bars WHERE source != 'toobit'`. Must return 0. |
| FW-7 | `bars_research` table contains only `source='cross_venue_1h'` rows | SQL query: `SELECT COUNT(*) FROM bars_research WHERE source != 'cross_venue_1h'`. Must return 0. |

---

## §7 Part 2/6 Completeness Statement

Part 2/6 is complete for its declared scope:

| Item | Status |
|---|---|
| Clean-sheet architecture derivation (decision inventory, cadence, admissible data, minimum state, envelope, component boundaries, simplest architecture, ADRs) | COMPLETE — §3.1–§3.8 |
| Strategy specification (candidates, selected strategy, selection procedure, cost model, position sizing, baseline, lifecycle) | COMPLETE — §4.1–§4.7 |
| Data design (6 data classes, quality rules, storage schema, C13/C26 handling, ingestion schedule) | COMPLETE — §5.1–§5.5 |
| Cross-venue firewall (physical separation, access control, Paper mode isolation, research isolation, verification checks) | COMPLETE — §6.1–§6.5 |

**Content deferred to later parts:** None. All content declared for Part 2/6 is delivered.

**Cross-references:**
- Part 3/6 references §3.4 (state ownership), §3.5 (envelope), §3.6 (component boundaries), §4.2 (strategy conditions), §4.5 (position sizing), §5.1 (data classes), §5.2 (quality rules), §5.3 (storage schema), §6 (firewall).
- Part 4/6 references §4.2 (strategy for exit conditions), §5.1 (data for reconciliation), §6.2 (access control for Telegram).
- Part 5/6 references §3.5 (envelope for D15), §4.3 (selection procedure for Phase 1), §5.5 (ingestion schedule for rate-limit budget).
- Part 6/6 references all sections for verification matrix and audit.

---

*Part 2/6 delivered. Continuing to Part 3/6 (Component Architecture, Order Lifecycle/State Machine, Risk Design with D-RISK Hard Limits) in the next message.*


## Part 3/6 — Component Architecture, Order Lifecycle/State Machine, and Risk Design

**Part plan reminder:**

| Part | Scope |
|---|---|
| 1/6 | ✅ Delivered — Capability inventory, pre-review checkpoint, D-RISK catalog, Requirements Register (55 reqs) |
| 2/6 | ✅ Delivered — Clean-sheet architecture, strategy, data design, cross-venue firewall |
| 3/6 | **This part** — Component architecture (9×11), order lifecycle/state machine, risk design |
| 4/6 | Execution/OMS, reconciliation, Telegram interface, security and operations |
| 5/6 | Deployment topology (D15), phase structure (D16), test strategy, verification plan |
| 6/6 | Forensic audit findings, adversarial red-team, verification matrix, completeness declaration, 7-dimension status, V-1–V-12, Artifact Registry, change-propagation table, Persian final note |

---

## §8 Component Architecture

Each component is specified with 11 fields: Purpose, Responsibilities, Non-responsibilities, State Ownership, Inputs, Outputs, Dependencies, Timing Assumptions, Failure Behavior, Verification, Interface Contract.

### §8.1 Component 1: Scheduler

| Field | Content |
|---|---|
| **Purpose** | Central timing engine. Triggers all periodic and event-driven actions at the correct UTC time. Owns no trading state. |
| **Responsibilities** | (1) Maintain a monotonic clock for elapsed deadlines. (2) Trigger 1h bar close cycle at UTC :00 + 5s buffer. (3) Trigger 15m bar close cycle at UTC :00/:15/:30/:45 + 5s buffer. (4) Trigger reconciliation every 5 minutes (monotonic timer). (5) Trigger daily close at UTC 23:45. (6) Trigger daily loss reset at UTC 00:00. (7) Trigger funding fetch at 00:00, 08:00, 16:00 UTC. (8) Trigger SQLite integrity check every 6h. (9) Trigger backup every 6h. (10) Trigger stale-position flush check on startup (AR-4). |
| **Non-responsibilities** | Does not compute signals. Does not evaluate risk. Does not place orders. Does not fetch data. Does not log (delegates to Audit Logger). |
| **State ownership** | None. The Scheduler is stateless. It reads the current UTC time and triggers callbacks. |
| **Inputs** | System clock (UTC). Monotonic timer. |
| **Outputs** | Trigger events to: Data Ingestor (bar fetch), Signal Engine (signal computation), State Reconciler (reconciliation), Order Manager (daily close), Risk Authority (daily loss reset), Config Manager (integrity check), backup routine. |
| **Dependencies** | None (lowest-level component alongside Config Manager and Audit Logger). |
| **Timing assumptions** | 1h bar close: UTC :00 + 5s (tolerance: 10s). 15m bar close: UTC :00/:15/:30/:45 + 5s. Reconciliation: every 5 min (monotonic, not wall-clock). Daily close: UTC 23:45 (tolerance: 5s). Daily loss reset: UTC 00:00 (tolerance: 1s). If the process is restarted after a missed trigger: the Scheduler checks which triggers were missed and executes them in order (stale-position flush first, then missed bar cycles, then reconciliation). |
| **Failure behavior** | If the monotonic timer fails (should not happen in Python): the process crashes. Autostart restarts it. On restart, the Scheduler checks for missed triggers and executes them. If the UTC clock is skewed > 5s (Interlock 6): log at WARN. Do NOT refuse to start (the system can operate with a small clock offset; it flags it). If the clock is skewed > 60s: REFUSE TO START. CRIT alert. |
| **Verification** | Test: verify 1h bar close triggers at UTC :00 + 5s ± 10s. Test: verify reconciliation triggers every 5 min ± 30s. Test: verify daily close triggers at UTC 23:45 ± 5s. Test: verify missed triggers are executed on restart. Test: verify stale-position flush is checked on startup. |
| **Interface contract** | Input: `start()`. Input: `stop()`. Output: trigger events (callbacks). `get_next_trigger() -> (event_type, utc_ms)`. |

### §8.2 Component 2: Data Ingestor

| Field | Content |
|---|---|
| **Purpose** | Fetch, validate, and store market data from Toobit REST API. Maintain data freshness. Enforce rate limits. |
| **Responsibilities** | (1) Fetch 15m/1h/4h/1d OHLCV bars from Toobit `GET /quote/v1/klines` on schedule. (2) Fetch funding rates from `GET /api/v1/futures/fundingRate` on schedule. (3) Validate bars (OHLC consistency, no NULLs, volume ≥ 0). (4) Store valid bars in `bars` table (`source='toobit'`). (5) Detect and handle missing, stale, duplicate, malformed bars (per Part 2/6 §5.2). (6) Maintain conservative fixed-weight rate limiter (C4). (7) Track data freshness per symbol/timeframe. (8) On API failure: retry with backoff. After 3 consecutive failures: alert at WARN. After 10: alert at CRIT, pause fetch. (9) **Research path (separate process):** Fetch cross-venue 1h bars. Store in `bars_research` table. This path is NOT part of the real-time loop. |
| **Non-responsibilities** | Does not compute signals. Does not evaluate risk. Does not place orders. Does not reconcile. Does not access `bars_research` in the real-time path (firewall, Part 2/6 §6). |
| **State ownership** | Owns `bars`, `bars_research`, `funding` tables. |
| **Inputs** | Scheduler triggers. Toobit REST API responses. Rate-limit state (in-memory sliding window). |
| **Outputs** | Valid bars in `bars` table. Funding rates in `funding` table. Data freshness status (read by Signal Engine, Risk Authority, Telegram Interface). Rate-limit state. |
| **Dependencies** | Scheduler (triggers). Toobit REST API (network). Config Manager (symbol list, rate-limit parameters). |
| **Timing assumptions** | 15m bars: fetched every 15 min (20 calls, ~800 weight). 1h bars: fetched every 1h (20 calls, ~800 weight). 4h bars: every 4h. 1d bars: every 24h. Funding: every 8h (20 calls, ~20 weight). Initial load: spread over 5 min (600 weight/min). Each kline call: < 2s (network dependent). Validation: < 50ms per bar. |
| **Failure behavior** | Single API call failure: retry once after 5s. 3 consecutive failures: alert at WARN. 10 consecutive failures: alert at CRIT, pause data fetch. No new entries (Signal Engine has no fresh data). Existing positions held. Protective orders remain on exchange. If > 50% symbols stale: `V-DATA-STALE` (Risk Authority). Malformed bar: reject, do not store, alert at WARN. Missing bar: mark MISSING, skip symbol for that cycle. |
| **Verification** | Test: verify OHLC validation rejects high < max(open,close). Test: verify duplicate detection by PK. Test: verify staleness thresholds (15m: 30m, 1h: 2h, 4h: 8h, 1d: 48h). Test: verify rate limiter blocks when projected weight > 3000/min. Test: verify no cross-venue data in `bars` table. Test: verify no `bars_research` access in real-time path. |
| **Interface contract** | Input: `fetch_bars(symbol, timeframe) -> list[Bar]`. Input: `fetch_funding(symbol) -> FundingRate`. Input: `get_freshness(symbol, timeframe) -> (is_fresh, age_seconds)`. Input: `get_all_freshness() -> dict`. Output: bars in `bars` table. Output: funding in `funding` table. |

### §8.3 Component 3: Signal Engine

| Field | Content |
|---|---|
| **Purpose** | Compute technical indicators and evaluate entry/exit conditions for all symbols at each 1h bar close. Produce signals for the Risk Authority to evaluate. |
| **Responsibilities** | (1) On 1h bar close trigger: compute 1h SMA(P1), 4h SMA(50), 1d SMA(20) for all 20 symbols. (2) Evaluate entry conditions (Part 2/6 §4.2, all 8 conditions). (3) Evaluate exit conditions (Part 2/6 §4.2, any of 4 conditions). (4) For each valid entry signal: produce an EntrySignal with symbol, side (LONG), intended_notional (from sizing formula), stop_distance (75 bp). (5) For each valid exit signal: produce an ExitSignal with symbol, reason. (6) Check data freshness before computing (skip stale symbols). (7) Do NOT submit orders. Do NOT evaluate risk. Send signals to Risk Authority. |
| **Non-responsibilities** | Does not submit orders. Does not evaluate risk limits. Does not place protective orders. Does not manage positions. Does not access `bars_research` (firewall). Does not use markPrice or klines.change (C13). Does not use Open Interest (C26). |
| **State ownership** | None. The Signal Engine is stateless. It reads bars and produces signals. All state is in the `bars` table (owned by Data Ingestor) and `positions` table (owned by Order Manager). |
| **Inputs** | Scheduler trigger (1h bar close). `bars` table (Toobit OHLCV). `funding` table (for cost estimation). `positions` table (to check existing positions). Config (P1 value, stop distance). |
| **Outputs** | EntrySignal: {symbol, side='LONG', intended_notional, stop_distance_bp=75, entry_price (bar close), timestamp}. ExitSignal: {symbol, reason ('sma_exit' | 'daily_close' | 'stop_triggered'), timestamp}. Sent to Risk Authority. |
| **Dependencies** | Scheduler (trigger). Data Ingestor (bars, freshness). Config Manager (P1, stop distance). Order Manager (positions table, read-only). |
| **Timing assumptions** | Signal computation: < 200ms for 20 symbols × 4 indicators × 3,500-bar lookback (numpy vectorized). Must complete before the next 1h bar opens (59 min 40s window). In practice: < 1s. |
| **Failure behavior** | If a symbol's bars are stale or missing: skip that symbol. No signal. If > 50% symbols stale: do not compute any signals. Alert at WARN. If numpy computation fails (memory error, NaN): log at CRIT. Skip that symbol. Do not crash the process. If the Signal Engine raises an unhandled exception: the process crashes. Autostart restarts it. On restart, the missed 1h cycle is not re-computed (the bar is already closed; the next cycle will use the latest bars). |
| **Verification** | Test: verify SMA(20) computation matches manual calculation on known data. Test: verify entry conditions are ALL (not ANY). Test: verify exit conditions are ANY (not ALL). Test: verify stale symbols are skipped. Test: verify no cross-venue data is used. Test: verify no markPrice is used. Test: verify signal is deterministic (same bars → same signal). |
| **Interface contract** | Input: `compute_signals() -> list[Signal]`. Input: `evaluate_entry(symbol) -> EntrySignal | None`. Input: `evaluate_exit(symbol) -> ExitSignal | None`. Output: signals to Risk Authority. |

### §8.4 Component 4: Risk Authority

| Field | Content |
|---|---|
| **Purpose** | Independent risk gate. Evaluates all 6 D-RISK hard limits and 6 interlocks before any risk-increasing action. Maintains risk state. Issues vetoes. Cannot be bypassed. |
| **Responsibilities** | (1) Maintain `risk_state` table (sole writer). (2) Evaluate D-RISK-1 (drawdown ≤ 15% of initial equity) at every fill and every reconciliation. (3) Evaluate D-RISK-2 (per-trade risk ≤ 5% of current equity) before every risk-increasing order. (4) Evaluate D-RISK-4 (aggregate risk ≤ 15% of current equity) before every risk-increasing order. (5) Evaluate D-RISK-5 (daily realized loss ≤ 10% of current equity) at every fill. (6) Evaluate D-RISK-6 (effective leverage ≤ 5×) before every risk-increasing order. (7) Evaluate 6 interlocks before mode switch to Live and before every risk-increasing order in Live mode. (8) Issue vetoes: `V-DRAWDOWN`, `V-DAILY-LOSS`, `V-LEVERAGE`, `V-RECONCILE`, `V-RISK-STATE`, `V-DATA-STALE`, `V-CONFIG`. (9) Reset daily loss at UTC 00:00. (10) Update peak_equity at every equity update. (11) First-deployment initialization (AR-2): if `.initialized` marker absent, initialize from exchange. If marker present and risk_state absent: `V-RISK-STATE`. (12) Stale-position flush (AR-4): on startup, if UTC > 23:45 of previous day AND positions from that day are open → immediately market-close before processing new signals. |
| **Non-responsibilities** | Does not compute signals. Does not place orders. Does not fetch data. Does not reconcile (delegates to State Reconciler). Does not log (delegates to Audit Logger). Does not accept configuration changes that modify D-RISK values. |
| **State ownership** | Owns `risk_state` table. NO other component writes to this table. |
| **Inputs** | EntrySignal/ExitSignal from Signal Engine. Fill events from Order Manager. Reconciliation results from State Reconciler. Config values from Config Manager. Exchange balance/positions (via State Reconciler). UTC time from Scheduler. |
| **Outputs** | APPROVED / VETOED decision to Order Manager. Veto reason (for Telegram alert). Risk state values (for Telegram `/risk` command). Integrity hash (for interlock 5). |
| **Dependencies** | Config Manager (D-RISK values, interlock parameters). State Reconciler (equity, positions). Order Manager (fill events, position data). Data Ingestor (data freshness for interlock 1). |
| **Timing assumptions** | Risk evaluation: < 10ms (in-memory arithmetic on 6 limits + 6 interlocks). Must complete synchronously before Order Manager submits. Daily loss reset: < 1ms. Peak update: < 1ms. |
| **Failure behavior** | If `risk_state` is missing, unreadable, or corrupted: **HARD VETO** (`V-RISK-STATE`). Refuse all risk-increasing actions. Alert at CRIT. Do NOT initialize from current market values (fail-open path prohibited). Operator must restore from backup or `/ack` with explicit risk acceptance. If equity is stale (> 5 min): `V-RISK-STATE` for risk-increasing actions. Risk-reducing actions are still permitted. If any D-RISK evaluation produces NaN or negative equity: `V-RISK-STATE`. CRIT alert. |
| **Verification** | Test: verify D-RISK-1 uses initial_equity (not current, not peak) as denominator. Test: verify D-RISK-2 uses current_equity as denominator. Test: verify D-RISK-4 sums gross (no netting). Test: verify D-RISK-5 resets at 00:00 UTC. Test: verify D-RISK-6 uses gross notional (no netting). Test: verify no config key can modify D-RISK values. Test: verify missing risk_state → V-RISK-STATE (not initialization). Test: verify first deployment (marker absent) → initialization. Test: verify stale-position flush on startup. Test: verify risk-reducing actions are NOT blocked by vetoes. Test: verify sequential evaluation of concurrent signals (reservation). |
| **Interface contract** | Input: `evaluate_order_intent(intent) -> (APPROVED | VETOED, reason)`. Input: `on_fill(symbol, side, qty, price, fee)`. Input: `on_reconciliation(equity, positions, orders)`. Input: `on_daily_reset()`. Input: `check_interlocks() -> (all_pass, list[failed_interlocks])`. Output: `get_risk_state() -> RiskState`. Output: `integrity_hash() -> str`. Output: `active_vetoes() -> list[str]`. |

### §8.5 Component 5: Order Manager

| Field | Content |
|---|---|
| **Purpose** | Construct, submit, track, and reconcile orders. Manage position lifecycle. Place and cancel protective stop-loss orders. Handle ambiguous outcomes. |
| **Responsibilities** | (1) On APPROVED EntrySignal: construct OrderIntent (clientOrderId, symbol, side, positionSide, type, valueQuantity). (2) Write OrderIntent to `orders` table with status=INTENT (durable before API call). (3) Call Risk Authority `evaluate_order_intent()` (precondition check). If VETOED: do not submit. (4) Submit order to Toobit `POST /api/v2/futures/order`. (5) Update order state on response (ACKNOWLEDGED, REJECTED, TIMEOUT_AMBIGUOUS). (6) On fill: update `orders` table (status=FILLED, filled_quantity, avg_fill_price, fee). Create/update `positions` table row. (7) Place protective STOP_MARKET order on exchange after entry ACKNOWLEDGED. (8) On ExitSignal: submit market close order. Cancel protective order on fill. (9) Handle partial fills (track filled quantity, cancel remainder after 30s). (10) Handle -1007/5XX/timeout: TIMEOUT_AMBIGUOUS, reconcile (no resubmit). (11) Handle cancel/fill race: trust exchange final state. (12) Retry budget: max 3, backoff 5s/15s/45s. Rate-limit (-1003): 60s backoff, not counted as retry. (13) Crash recovery: on startup, read all non-terminal orders, reconcile with exchange. (14) Daily close: on UTC 23:45 trigger, submit market close for all open positions. (15) Paper mode: simulate fills (no API call). |
| **Non-responsibilities** | Does not compute signals. Does not evaluate risk limits (delegates to Risk Authority). Does not fetch market data. Does not manage config. Does not log (delegates to Audit Logger, though it triggers audit events). |
| **State ownership** | Owns `orders` and `positions` tables. |
| **Inputs** | APPROVED EntrySignal/ExitSignal from Risk Authority. Toobit API responses. Scheduler triggers (daily close). Config (mode, symbol format mapping). |
| **Outputs** | Order state transitions (to `orders` table). Position state transitions (to `positions` table). Fill events (to Risk Authority, Telegram Interface). Protective order status. Reconciliation data (to State Reconciler). |
| **Dependencies** | Risk Authority (precondition check before submission). Toobit REST API (order submission, cancellation, status query). Config Manager (mode, symbol mapping). Scheduler (daily close trigger). |
| **Timing assumptions** | Order submission: < 2s (network dependent). State update: < 50ms (SQLite write). Protective order placement: < 2s. Must be placed within 60s of entry ACKNOWLEDGED. If not placed within 60s: CRIT alert, consider flattening. Partial fill cancellation: 30s after partial fill. Retry backoff: 5s, 15s, 45s. |
| **Failure behavior** | Order REJECTED by exchange: update state, release risk reservation, alert at WARN. -1007/5XX/timeout: TIMEOUT_AMBIGUOUS. Do NOT resubmit. Reconcile after 5s. Max 3 reconciliation attempts (30s apart). If unresolved: CRIT alert, operator intervention. Symbol locked during ambiguity. Protective order REJECTED: CRIT alert, position UNPROTECTED, flag, monitor at 1-min intervals. If not placed within 60s: consider flattening. API rate-limit (-1003): 60s backoff. Do not retry until backoff completes. -1015 (TOO_MANY_ORDERS): 2s backoff (per 2-second window). Process crash mid-order: on restart, reconcile all non-terminal orders with exchange. |
| **Verification** | Test: verify order is written to `orders` table BEFORE API call (durability). Test: verify Risk Authority is called before submission. Test: verify -1007 does NOT trigger resubmission. Test: verify retry count is capped at 3. Test: verify rate-limit backoff is 60s and not counted as retry. Test: verify partial fill tracks filled quantity. Test: verify cancel/fill race resolves to exchange state. Test: verify protective order is placed after ACKNOWLEDGED. Test: verify protective order is cancelled on position close. Test: verify Paper mode does NOT call Toobit API. Test: verify crash recovery reconciles all non-terminal orders. Test: verify clientOrderId is unique and not reused. |
| **Interface contract** | Input: `submit_entry(symbol, notional, stop_bp) -> OrderIntent`. Input: `submit_exit(symbol, reason) -> OrderIntent`. Input: `submit_daily_close() -> list[OrderIntent]`. Input: `on_exchange_response(order_id, response)`. Input: `on_fill(order_id, qty, price, fee)`. Input: `reconcile_order(client_order_id) -> OrderState`. Output: order state in `orders` table. Output: position state in `positions` table. Output: fill events. Output: `get_open_orders() -> list[Order]`. Output: `get_open_positions() -> list[Position]`. |

### §8.6 Component 6: State Reconciler

| Field | Content |
|---|---|
| **Purpose** | Compare internal state (positions, orders, balance) against exchange state (positions, orders, balance). Detect and resolve divergences. Update risk state. |
| **Responsibilities** | (1) Every 5 minutes: fetch exchange positions, open orders, balance from Toobit API. (2) Compare against internal `positions` and `orders` tables. (3) If MATCH: update `last_reconciliation` timestamp. No action. (4) If DIVERGENCE: alert at CRIT. Trigger `V-RECONCILE`. Attempt resolution: (a) Exchange has position, internal doesn't → add to internal. (b) Internal has position, exchange doesn't → mark as closed (realized PnL = 0, flag for review). (c) Order state differs → update internal to match exchange. (5) If resolution successful: re-reconcile. If MATCH: clear `V-RECONCILE`. (6) If resolution fails: maintain `V-RECONCILE`. Operator must intervene. (7) Update `risk_state` (equity, peak, drawdown) from exchange balance. (8) On API failure: mark reconciliation as SKIPPED (NOT assumed MATCH). Alert at WARN. (9) Stale-position flush (AR-4): on startup, check if any positions from previous UTC day are still open. If yes: immediately market-close. |
| **Non-responsibilities** | Does not compute signals. Does not evaluate risk limits (updates risk_state but does not issue vetoes). Does not place orders (except stale-position flush, which is a risk-reducing action). Does not fetch market data (bars). |
| **State ownership** | None. Reads `positions`, `orders`. Writes corrections via Order Manager (for positions/orders) and Risk Authority (for risk_state). |
| **Inputs** | Scheduler trigger (5-min cycle). Toobit API (positions, orders, balance). Internal `positions` and `orders` tables. |
| **Outputs** | Reconciliation result (MATCH / DIVERGENCE / SKIPPED). Corrections to `positions` and `orders` tables (via Order Manager). Updated `risk_state` (via Risk Authority). CRIT/WARN alerts. |
| **Dependencies** | Scheduler (trigger). Toobit REST API. Order Manager (position/order corrections). Risk Authority (risk_state update). |
| **Timing assumptions** | 3 API calls (positions, orders, balance): < 2s total. Comparison: < 100ms. Resolution: < 1s. Total cycle: < 5s. Must complete within the 5-minute window. |
| **Failure behavior** | API call failure: mark SKIPPED. Do NOT assume MATCH. Alert at WARN. Next cycle retries. 3 consecutive SKIPPED: alert at CRIT. `V-RECONCILE` (cannot verify state). Divergence that cannot be resolved: maintain `V-RECONCILE`. CRIT alert. Operator intervention required. |
| **Verification** | Test: verify MATCH when internal and exchange states agree. Test: verify DIVERGENCE detected when internal position ≠ exchange position. Test: verify resolution adds missing position. Test: verify resolution marks orphan position as closed. Test: verify API failure → SKIPPED (not MATCH). Test: verify `V-RECONCILE` is set on DIVERGENCE. Test: verify `V-RECONCILE` is cleared on successful re-reconciliation. Test: verify stale-position flush on startup. |
| **Interface contract** | Input: `reconcile() -> (MATCH | DIVERGENCE | SKIPPED, details)`. Input: `reconcile_order(client_order_id) -> OrderState`. Output: reconciliation result. Output: corrections to Order Manager. Output: risk_state update to Risk Authority. |

### §8.7 Component 7: Telegram Interface

| Field | Content |
|---|---|
| **Purpose** | Sole operator-facing interface. Receive commands, send alerts, display system state. Long-polling (no webhook). |
| **Responsibilities** | (1) Long-poll Telegram Bot API (50s timeout). (2) Parse and validate commands (strict regex, sender ID check, replay protection). (3) Execute commands: /status, /positions, /orders, /risk, /data, /mode, /pause, /resume, /close, /ack, /config, /backup, /help, /shutdown, /reset_initial_equity. (4) Send alerts: INFO, WARN, CRIT (per Part 4/6 §11.4). (5) Queue alerts when Telegram is unreachable. Deliver on recovery (max 10, oldest first). (6) Rate-limit owner messages: 10/min. (7) Enforce authorization: only owner's Telegram user ID. (8) Mode switch: evaluate 6 interlocks before allowing /mode live or /mode paper. (9) `/reset_initial_equity <value>`: update D-RISK-1 denominator. CRIT audit. |
| **Non-responsibilities** | Does not compute signals. Does not evaluate risk limits (delegates to Risk Authority for interlocks). Does not place orders (delegates to Order Manager). Does not fetch data. Does not manage config directly (delegates to Config Manager). |
| **State ownership** | None. Reads all tables. Writes via other components. |
| **Inputs** | Telegram Bot API (long-poll responses). All state tables (read-only). Risk Authority (interlock evaluation). Config Manager (config changes). Order Manager (close commands). |
| **Outputs** | Telegram messages (responses, alerts). Command executions (delegated to other components). Audit events. |
| **Dependencies** | Telegram Bot API (network). All other components (read state, delegate actions). Risk Authority (interlocks). |
| **Timing assumptions** | Long-poll: 50s timeout. Command processing: < 1s. Alert delivery: < 5s. Rate limit: 10 messages/min from owner. |
| **Failure behavior** | Telegram API unreachable: queue alerts. Do NOT halt trading. Do NOT release risk limits. Do NOT make uncertain state appear confirmed. Operator unreachable > 30 min: degraded state (no new entries, positions held, protective orders active, daily close executes). System does NOT flatten positions automatically. Telegram recovery: resume normal operation. Deliver queued alerts. Mode unchanged. |
| **Verification** | Test: verify only owner's user ID is accepted. Test: verify replay protection (repeated message_id ignored). Test: verify injection protection (malformed command rejected). Test: verify rate limiting (11th message in 1 min rejected). Test: verify /mode live requires all 6 interlocks to pass. Test: verify /close all submits market close for all positions. Test: verify /ack requires non-empty reason. Test: verify /reset_initial_equity is audited at CRIT. Test: verify Telegram loss does not release risk limits. Test: verify alerts are queued during outage. |
| **Interface contract** | Input: `on_message(message) -> response`. Input: `send_alert(severity, text)`. Input: `get_status() -> str`. Input: `get_positions() -> str`. Input: `get_orders() -> str`. Input: `get_risk() -> str`. Input: `get_data() -> str`. |

### §8.8 Component 8: Config Manager

| Field | Content |
|---|---|
| **Purpose** | Own all configuration. Version, validate, and audit config changes. Compute integrity hash. Detect drift. |
| **Responsibilities** | (1) Load config from `config` table on startup. (2) Validate config schema (pydantic). (3) Provide config values to other components. (4) Record config changes in `audit`. (5) Compute config integrity hash (SHA-256 of all key-value pairs, sorted by key). (6) Detect config drift (hash mismatch). (7) Handle config corruption (fail-closed: `V-CONFIG`). (8) **D-RISK values are NOT in the config table.** They are hardcoded in the Risk Authority (Part 1/6 §1). The Config Manager cannot modify them. The `/config` command cannot modify D-RISK keys (they are not in the allowed key set). |
| **Non-responsibilities** | Does not evaluate risk. Does not place orders. Does not compute signals. Does not store D-RISK values. |
| **State ownership** | Owns `config` table. |
| **Inputs** | Owner commands (via Telegram Interface: `/config <key> <value>`). System defaults. |
| **Outputs** | Config values to all components. Integrity hash to Risk Authority (for interlock 5). Validation result. |
| **Dependencies** | None (lowest-level component). |
| **Timing assumptions** | Config loaded once at startup. Changes applied immediately (with audit). Integrity hash computed on every change (< 1ms). |
| **Failure behavior** | If config is corrupted (hash mismatch, missing key, invalid value): **HARD VETO** (`V-CONFIG`). Refuse to trade. Alert at CRIT. Require operator to restore config from backup. If pydantic validation fails: REFUSE TO START. CRIT alert. |
| **Verification** | Test: verify schema validation rejects invalid values. Test: verify hash computation is deterministic (same keys/values → same hash). Test: verify drift detection (modify a value → hash mismatch → V-CONFIG). Test: verify D-RISK keys are NOT in the allowed config set. Test: verify config change is audited. |
| **Interface contract** | Input: `get(key) -> value`. Input: `set(key, value, source) -> bool`. Input: `validate() -> bool`. Output: `integrity_hash() -> str`. Output: `list_all() -> dict`. |

### §8.9 Component 9: Audit Logger

| Field | Content |
|---|---|
| **Purpose** | Record all material decisions, state changes, and events for reproducibility and forensic analysis. Append-only. |
| **Responsibilities** | (1) Write to `audit` table on every material event. (2) Events: signal generated, signal approved/vetoed, order submitted, order filled, order cancelled, order timeout, reconciliation result (MATCH/DIVERGENCE/SKIPPED), risk state change, veto triggered/cleared, config change, mode change, /ack, /reset_initial_equity, forced close, data quality issue, process start/stop, backup complete, stale-position flush, protective order placed/rejected/cancelled, first-deployment initialization. (3) Each event: timestamp (UTC ms), event_type, component, detail (JSON), severity (INFO/WARN/CRIT). (4) Append-only: no UPDATE, no DELETE on `audit` table. |
| **Non-responsibilities** | Does not act on events. Does not modify any state (except appending to `audit`). Is a passive recorder. |
| **State ownership** | Owns `audit` table (append-only). |
| **Inputs** | Events from all components (via `log()` method). |
| **Outputs** | `audit` table rows. |
| **Dependencies** | None. |
| **Timing assumptions** | Synchronous write (blocking). Each write: < 1ms. |
| **Failure behavior** | If audit write fails: log to stderr, continue. Do not crash. The audit is important but not safety-critical. If the `audit` table is corrupted: alert at CRIT. Attempt to recreate the table. Continue. |
| **Verification** | Test: verify all expected events are recorded. Test: verify append-only (no UPDATE/DELETE on audit table). Test: verify timestamp is UTC ms. Test: verify detail is valid JSON. Test: verify severity is one of INFO/WARN/CRIT. |
| **Interface contract** | Input: `log(event_type, component, detail, severity)`. No output (side effect: `audit` table row). |

### §8.10 Component Dependency Graph

```
Scheduler ──────────────────────────────────────────────────────────
    │
    ├──▶ Data Ingestor ──▶ bars, bars_research, funding
    │         │
    │         ▼
    │    Signal Engine ──▶ EntrySignal / ExitSignal
    │         │
    │         ▼
    │    Risk Authority ◀── Config Manager (D-RISK values, interlocks)
    │         │                    │
    │         │ APPROVED/VETOED    │ integrity_hash
    │         ▼                    │
    │    Order Manager ──▶ orders, positions
    │         │                    │
    │         │ fill events        │
    │         ▼                    │
    │    Risk Authority ◀──────────┘
    │
    ├──▶ State Reconciler ──▶ risk_state update, corrections
    │         │
    │         ▼
    │    Risk Authority
    │
    └──▶ Daily close / Daily reset / Backup / Integrity check

Telegram Interface ──▶ (reads all tables, delegates to all components)
Audit Logger ◀── (all components call log())
```

**No circular dependencies.** The Risk Authority depends on Config Manager (for D-RISK values and interlock parameters) and State Reconciler (for equity/positions). The Order Manager depends on Risk Authority (precondition check). The State Reconciler depends on Order Manager (for corrections). No component depends on itself. No two components have a circular dependency.

---

## §9 Order Lifecycle and State Machine

### §9.1 Exchange States vs. Local States

**Critical distinction:** The Toobit API returns specific status values for orders. The design uses LOCAL states that are an abstraction over exchange states. Local states are NOT Toobit response enums.

| Exchange State (Toobit) | Source | Status |
|---|---|---|
| `NEW` | Fact Pack §3 (observed in response) | SOURCE_VERIFIED |
| `CANCELED` | Fact Pack §3 (observed in response) | SOURCE_VERIFIED |
| `FILLED` | Inferred from `executedQty == origQty` in response | DESIGN_JUDGMENT (not explicitly listed as a status string in Fact Pack) |
| `PARTIALLY_FILLED` | Inferred from `0 < executedQty < origQty` | DESIGN_JUDGMENT |
| Other statuses | Not confirmed in extracted docs | **UNRESOLVED** |

**Local states (design abstractions):**

| Local State | Description | Mapped Exchange State |
|---|---|---|
| `INTENT` | Order intent created, written to `orders` table, not yet submitted. | N/A (local only) |
| `SUBMITTED` | Order sent to Toobit API, awaiting response. | N/A (local only) |
| `ACKNOWLEDGED` | Toobit confirmed receipt. Order is live on the exchange. | `NEW` |
| `PARTIALLY_FILLED` | Some quantity filled, remainder still open. | `NEW` (with `executedQty > 0`) |
| `FILLED` | Full quantity filled. | `NEW` (with `executedQty == origQty`) or inferred |
| `CANCEL_PENDING` | Cancel request sent, awaiting confirmation. | N/A (local only) |
| `CANCELLED` | Cancel confirmed. Order no longer live. | `CANCELED` |
| `REJECTED` | Toobit rejected the order (insufficient balance, invalid params, etc.). | N/A (error response) |
| `TIMEOUT_AMBIGUOUS` | -1007, 5XX, or network timeout. External outcome unknown. | N/A (local only) |
| `RECONCILING` | Actively checking exchange state to resolve ambiguous outcome. | N/A (local only) |

**Note:** The Fact Pack §3 states: "Status values observed: NEW, CANCELED. Other statuses not confirmed in extracted docs — treat as UNRESOLVED if the design requires the full state set." The design does NOT require the full exchange state set. It uses `executedQty` and `origQty` to determine fill status, and `NEW`/`CANCELED` for order status. This is sufficient.

### §9.2 State Transitions

```
INTENT → SUBMITTED              (API call initiated; order row written to DB before call)
SUBMITTED → ACKNOWLEDGED        (exchange confirms receipt: status=NEW)
SUBMITTED → REJECTED            (exchange rejects: error response)
SUBMITTED → TIMEOUT_AMBIGUOUS   (-1007, 5XX, or network timeout)
ACKNOWLEDGED → PARTIALLY_FILLED (executedQty > 0 AND executedQty < origQty)
ACKNOWLEDGED → FILLED           (executedQty == origQty)
ACKNOWLEDGED → CANCEL_PENDING   (cancel requested)
PARTIALLY_FILLED → FILLED       (remaining quantity filled: executedQty == origQty)
PARTIALLY_FILLED → CANCEL_PENDING (cancel remaining)
CANCEL_PENDING → CANCELLED      (cancel confirmed: status=CANCELED)
CANCEL_PENDING → FILLED         (fill raced with cancel; fill wins)
TIMEOUT_AMBIGUOUS → RECONCILING (reconciliation initiated)
RECONCILING → FILLED            (reconciliation shows executedQty == origQty)
RECONCILING → REJECTED          (reconciliation shows no order)
RECONCILING → ACKNOWLEDGED      (reconciliation shows order is live: status=NEW)
RECONCILING → CANCELLED         (reconciliation shows order was cancelled: status=CANCELED)
```

**Invalid transitions (must be rejected by the state machine):**
- `FILLED` → any (terminal state)
- `CANCELLED` → any (terminal state)
- `REJECTED` → any (terminal state)
- `INTENT` → `FILLED` (must go through SUBMITTED)
- `INTENT` → `ACKNOWLEDGED` (must go through SUBMITTED)
- `SUBMITTED` → `CANCELLED` (must go through CANCEL_PENDING)
- `SUBMITTED` → `PARTIALLY_FILLED` (must go through ACKNOWLEDGED)
- `TIMEOUT_AMBIGUOUS` → `FILLED` (must go through RECONCILING)
- `TIMEOUT_AMBIGUOUS` → `REJECTED` (must go through RECONCILING)

**Enforcement:** The Order Manager's `transition(order_id, new_state)` method validates the transition against the allowed set above. If the transition is invalid: log at CRIT, do NOT update the state, alert the operator.

### §9.3 -1007 / 5XX / Timeout Handling

**Evidence status:** -1007 is documented in the master prompt (C5) as ambiguous. It does NOT appear in the Fact Pack §4 partial error-code list. 5XX responses are listed in Fact Pack §4 as "Internal error, execution status UNKNOWN" (SOURCE_VERIFIED). The design treats both identically: **execution status is UNKNOWN.**

**Handling procedure:**

1. Order state → `TIMEOUT_AMBIGUOUS`.
2. **Do NOT resubmit.** The timeout does not prove rejection.
3. **Do NOT assume fill.** The timeout does not prove acceptance.
4. **Do NOT assume the order is live.** The timeout does not prove acceptance.
5. Trigger reconciliation:
   a. Wait 5s (allow exchange to process).
   b. Query exchange: `GET /api/v2/futures/order?symbol=X&origClientOrderId=Y`.
   c. If order exists and `status=NEW` and `executedQty=0`: state → `ACKNOWLEDGED`. Continue normal lifecycle.
   d. If order exists and `executedQty == origQty`: state → `FILLED`. Process fill.
   e. If order exists and `0 < executedQty < origQty`: state → `PARTIALLY_FILLED`. Process partial fill.
   f. If order exists and `status=CANCELED`: state → `CANCELLED`.
   g. If order does not exist (error -2011 "Unknown order" or equivalent): state → `REJECTED`. Record in audit.
   h. If query also times out or returns 5XX: state remains `TIMEOUT_AMBIGUOUS`. Retry reconciliation after 30s. Max 3 reconciliation attempts.
   i. If still unresolved after 3 attempts: state remains `TIMEOUT_AMBIGUOUS`. Alert at CRIT. Operator must intervene via Telegram (`/status` to check, `/close` to flatten if needed).
6. During `TIMEOUT_AMBIGUOUS` and `RECONCILING`: **no new orders for that symbol.** The symbol is locked until the order is resolved.
7. The risk reservation for this order is maintained during `TIMEOUT_AMBIGUOUS` and `RECONCILING`. It is released only when the state reaches a terminal state (FILLED, REJECTED, CANCELLED).

**5XX handling:** Identical to -1007. The Fact Pack §4 states: "5XX: Internal error, execution status UNKNOWN." The design does NOT treat 5XX as a rejection. It treats it as an ambiguous outcome.

### §9.4 Idempotency

- Each OrderIntent has a unique `newClientOrderId` (format: `T{UTC_ms}_{symbol}_{seq}`, e.g., `T1719900000000_BTCSWAPUSDT_001`).
- Charset: [A-Za-z0-9_-] (C11 compliant). The symbol component uses the futures format without hyphens (e.g., `BTCSWAPUSDT` instead of `BTC-SWAP-USDT`) to stay within the charset. `DESIGN_JUDGMENT`: the hyphen in `BTC-SWAP-USDT` is within [A-Za-z0-9_-], so it could be included. However, removing hyphens simplifies parsing. The mapping between internal symbol ID and Toobit symbol is maintained in the Config Manager.
- Uniqueness scope: **per-account** (weakest documented scope, Fact Pack §3: "UNRESOLVED"). The design enforces GLOBAL uniqueness (all symbols, all time) via the UTC_ms + seq combination.
- Before submission: check `orders` table for existing `newClientOrderId`. If found: do not resubmit. Return the existing order.
- After a crash/restart: the Order Manager reads all orders with status `SUBMITTED`, `ACKNOWLEDGED`, `PARTIALLY_FILLED`, `TIMEOUT_AMBIGUOUS`, `RECONCILING` from the `orders` table and reconciles them against the exchange before accepting new signals.
- **Never reuse a `newClientOrderId` after an ambiguous outcome.** If an order times out and is later determined to be REJECTED, the `newClientOrderId` is NOT available for reuse. A new order gets a new `newClientOrderId`.

### §9.5 Retry Budget

| Parameter | Value |
|---|---|
| Max retries per order | 3 |
| Backoff schedule | 5s, 15s, 45s (exponential, base 5s, factor 3) |
| Hard stop | After 3 failed attempts: mark `REJECTED`, alert at CRIT |
| Rate-limit (-1003) | Backoff 60s. Do NOT count as a retry. Wait for rate-limit window to reset. |
| Order rate-limit (-1015) | Backoff 2s (per 2-second window). Do NOT count as a retry. |
| Timeout (-1007 / 5XX) | Do NOT retry. Enter `TIMEOUT_AMBIGUOUS`. Reconcile. |
| Retry count storage | `orders.retry_count` field. If `retry_count >= 3`, no further retries. |

**No unbounded retry loop.** The retry count is persisted in the `orders` table.

### §9.6 Protective Orders (Stop-Loss)

**Type:** Exchange-side STOP_MARKET order (Toobit `POST /api/v2/futures/order` with `type=MARKET`, `stopPrice=<stop_price>`, `stopOrderType=STOP_LOSS`).

**Lifecycle:**
1. Placed immediately after the entry order is `ACKNOWLEDGED`.
2. Stop price: for long: `entry_price × (1 - 75/10,000)`. For short: `entry_price × (1 + 75/10,000)`.
3. The stop is on the exchange. It survives process death, phone reboot, and network loss.
4. On position close (signal exit, daily close, operator close): cancel the protective order (`DELETE /api/v2/futures/order` with `origClientOrderId`).
5. If the protective order is rejected: alert at CRIT. The position is **UNPROTECTED**. The Risk Authority flags the position. The system monitors it more frequently (every 1 min instead of 5 min). If the stop cannot be placed within 60s: consider flattening the position (market close). `DESIGN_JUDGMENT`: the system does NOT auto-flatten. It alerts at CRIT and the operator decides.
6. The protective order's `newClientOrderId` format: `S{UTC_ms}_{symbol}_{seq}` (prefix `S` to distinguish from entry orders).

**The protective order is the primary loss control.** The system-side stop (Signal Engine exit at 1h bar close) is secondary. If the phone dies, the exchange-side stop still protects the position.

### §9.7 Partial Fills

- On partial fill (`0 < executedQty < origQty`): update `orders` table (`status=PARTIALLY_FILLED`, `filled_quantity=executedQty`, `avg_fill_price`).
- The position is tracked at the **filled quantity**, not the intended quantity.
- Risk Authority updates exposure based on the actual filled quantity.
- The remaining quantity stays open on the exchange (`ACKNOWLEDGED` state for the remainder).
- If the remaining quantity is not filled within 30s: cancel the remainder (`CANCEL_PENDING`).
- The protective stop is placed on the **filled quantity**.
- If the remainder is cancelled: the position is at the filled quantity. The unfilled remainder's risk reservation is released.

### §9.8 Cancel/Fill Race

- If a cancel is sent and a fill arrives simultaneously: the exchange resolves the race.
- If the exchange reports a fill (`executedQty == origQty`): the cancel is moot. State → `FILLED`.
- If the exchange reports a cancel (`status=CANCELED`): State → `CANCELLED`.
- The system does NOT attempt to resolve the race locally. It trusts the exchange's final state (verified by reconciliation).
- If the exchange response is ambiguous (timeout): enter `TIMEOUT_AMBIGUOUS` → `RECONCILING`.

### §9.9 Recovery from Crash Mid-Order

On process restart:
1. Read all orders with status `SUBMITTED`, `ACKNOWLEDGED`, `PARTIALLY_FILLED`, `TIMEOUT_AMBIGUOUS`, `RECONCILING` from `orders` table.
2. For each: query the exchange for the order's current state (`GET /api/v2/futures/order?origClientOrderId=X`).
3. Update internal state to match exchange:
   - Exchange has no record: mark `REJECTED`.
   - Exchange has it as `NEW` with `executedQty=0`: mark `ACKNOWLEDGED`.
   - Exchange has it as `NEW` with `executedQty > 0`: mark `PARTIALLY_FILLED` or `FILLED`.
   - Exchange has it as `CANCELED`: mark `CANCELLED`.
4. If an order was `SUBMITTED` and the exchange has it as `FILLED`: mark `FILLED`, create position.
5. If an order was `TIMEOUT_AMBIGUOUS` and the exchange has it as open: mark `ACKNOWLEDGED`.
6. After all orders reconciled: resume normal operation.
7. Audit: "Recovery complete. N orders reconciled. M positions restored."
8. Stale-position flush (AR-4): if UTC > 23:45 of previous day AND positions from that day are open → immediately market-close. CRIT alert.

### §9.10 Paper Mode Fill Simulation (AR-1)

Paper mode simulates order fills without calling the Toobit API:

| Fill Type | Simulation Rule |
|---|---|
| Entry (market) | Filled at 1h bar close price + 2 bp slippage. Taker fee: 0.06%. |
| Exit (signal, market) | Filled at 1h bar close price + 2 bp slippage. Taker fee: 0.06%. |
| Stop-loss (triggered) | Triggered when 1h bar's low (for long) ≤ stop_price. Filled at stop_price + 5 bp slippage. Taker fee: 0.06%. |
| Partial fills | NOT simulated (all-or-nothing fills). Known simplification. |
| Funding | Applied at 8h intervals (00:00, 08:00, 16:00 UTC) using actual Toobit funding rate. If unavailable: last known rate. |
| Latency | NOT simulated (fills are instantaneous at bar close). Known simplification. |
| Protective orders | Simulated (no exchange call). The stop is "triggered" when the bar's low/high crosses the stop price. |

**Paper mode does NOT test:** partial fills, order latency, exchange rejection, -1007 handling, cancel/fill race. These are tested in the deterministic unit tests (Part 5/6 test strategy) and in Live mode.

---

## §10 Risk Design

### §10.1 Risk Authority Independence

The Risk Authority is a separate module with:
- Its own state (`risk_state` table). **No other component writes to this table.**
- Its own evaluation logic. It does not call the Signal Engine or Order Manager.
- Its own veto power. A veto is final. The Order Manager MUST check for a veto before submitting any risk-increasing order. If the Order Manager attempts to submit without a veto check: the audit log records a CRIT event, and the order is not submitted (the `submit` method has a precondition check that calls `risk_authority.evaluate_order_intent`).
- **No configuration change can disable the Risk Authority.** The config schema does not include a "disable_risk" key. The D-RISK values are NOT in the config table (Part 1/6 §1). They are hardcoded in the Risk Authority.
- **No retry logic can bypass the Risk Authority.** Each retry is a new order intent, which requires a new risk evaluation.
- **No Telegram command can bypass the Risk Authority.** The `/close` command is risk-reducing and does NOT require risk evaluation. The `/mode live` command requires all 6 interlocks (which include risk-limit checks). The `/ack` command can clear a veto but does NOT bypass the risk evaluation for future orders.
- **No subsystem that forecasts, calibrates, optimizes, allocates capital, or handles Telegram input may override the risk authority.**

###


xxx