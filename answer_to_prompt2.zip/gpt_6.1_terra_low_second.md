این پاسخ یک واحد مستقل از بازسازی است: ابتدا شواهد و نقص‌های مؤثر معماری اولیه را ثبت می‌کند، سپس قرارداد اصلاح‌شدهٔ پذیرش ریسک، رزرو، سفارش و تغییر حالت را ارائه می‌دهد. بستهٔ نهایی، ماتریس کامل جدید و تأیید آمادگی عملیاتی هنوز ارائه نشده‌اند.

# Revised Architecture — Evidence-Bounded Safety Core

## 1. Input integrity and offline review checkpoint

### 1.1 What is available and what was actually inspected

| Input or capability | Status in this engagement |
|---|---|
| Original master prompt | Parsed pages 1–54 are present in the conversation. They define the governing requirements and owner-ratified findings. |
| Primary architecture | Parsed pages 1–42 are present, covering its eight delivered parts. The document itself says the design was incomplete. |
| Supplemental prompt and Fact Pack | Parsed pages 1–26 are present. The Fact Pack is an owner-supplied static extract, not a source independently opened here. |
| PDF binaries | Not inspected. Parsing artifacts appear in the supplied text; the earlier ungarbled supplemental text in the conversation is also available for comparison. |
| External sources, account, Telegram and network | Prohibited by the supplemental directive. No calls or access occurred. |
| Local code execution, filesystem and file creation | Not exposed in this session. |
| Separate reviewer | Not available. The following is an internal adversarial review, not a blind independent review. |
| Delivery | User-requested continuation is possible based on this conversation. Autonomous successive messages and an exact output limit are not observable. |

The Fact Pack uses `SOURCE_VERIFIED` for some entries. In this package that means **the supplied extract labels the item source-verified**; it does not mean the underlying documentation was opened or reverified here.

### 1.2 Governing amendments

The supplemental directive narrowly changes the original framework:

- Its six owner-hard risk decisions replace the original pending values.
- Cross-venue data is restricted to research and historical backtesting, with architectural exclusion from both Paper and Live.
- Telegram selection of Paper or Live has no arbitrary waiting or profitability hurdle. The six Live correctness interlocks remain mandatory.
- External research and remote source inspection are prohibited in this engagement.
- Implementation, exchange access, backtesting, Paper execution and Live operation remain outside the engagement.

All other original obligations remain operative. In particular, a supplied status, a design proposal and an executed test are different things.

### 1.3 Dependency graph

```text
Requirements and source statuses
    ├──> risk-policy definitions ──> atomic admission and reservations
    │                               └──> execution and reconciliation
    ├──> admissible data and timestamps ──> strategy and research
    ├──> runtime isolation ──> Paper/Live transition contract
    └──> derived workload ──> device envelope ──> deployment comparison

All branches ──> integrated requirement/verification records
             ──> adversarial regression review
             ──> final completeness and acceptance record
```

Risk reservation is specified in this unit because it determines whether concurrent signals, partial fills and ambiguous outcomes can violate the owner’s limits. Resource placement cannot be decided before workload and device evidence exist.

---

## 2. Forensic findings from the supplied primary architecture

Severity is defined as follows:

- **Critical:** a hard safety invariant could be bypassed or uncontrolled/incorrect exchange state could result.
- **Major:** a material correctness property or engineering handoff is incomplete.
- **Moderate:** a meaningful limitation exists but a bounded safe fallback is available.
- **Minor:** a localized noncritical defect of clarity or consistency.

The previous architecture is assessed as a candidate, not treated as proof of its own claims.

| Finding | Primary architecture location and basis | Severity | Disposition in this unit |
|---|---|---:|---|
| Owner limits were marked pending | Parts 1–3 and 8; the later supplemental owner decisions now define six hard policies. | Critical if carried forward into an implementation | **REDESIGNED:** the canonical catalog and admission contract are specified below. Historical text remains historical; it is not the current policy. |
| Research promotion was linked to Paper selection | Part 8 §5 says a candidate advances to Paper only after evaluation and tests pass. The supplement confirms mode selection without an arbitrary wait or performance hurdle. | Major | **CORRECTED:** selecting the Paper simulator is distinct from promoting a candidate as validated or allowing a particular simulation run to claim trustworthy results. Paper selection remains possible without a performance hurdle; invalid inputs prevent dependent decisions. |
| Pending risk was included conceptually but not given a transaction-level concurrency contract | Part 2 §2 and Part 8 sizing; simultaneous approvals could otherwise consume the same remaining headroom. | Critical | **REDESIGNED:** §4 specifies serialized reservations, conservative accounting and state-version invalidation. |
| Timeout was correctly identified as ambiguous | Part 2 §3; original finding C5 and Fact Pack §4. | Critical boundary | **RETAINED WITH JUSTIFICATION:** §5 strengthens the durable send and reconciliation contract. No venue idempotency is assumed. |
| Protection and risk reduction were not established | Parts 2 and 6; Fact Pack §3 lists conditional fields but does not establish all lifecycle and non-reversal semantics. | Major | **CONTAINED, NOT RESOLVED:** the dependent automatic action remains disabled unless its semantics and preconditions are established. |
| Telegram confirmation is not independent authentication | Part 6 §2 and Part 7 cross-review. | Moderate | **RETAINED:** same-account confirmation is an accident/replay control, not proof against account compromise. Authentication sufficiency remains unresolved. |
| Offline restore conflicts with a stopped sole runtime interface unless a maintenance boundary is defined | Parts 2 and 6; original §9.8 requires stopped-process restore consistency. | Major for operational handoff | **UNRESOLVED:** no second routine interface is introduced. Recovery readiness is not claimed. |
| Status count in Part 5 was wrong | Primary Part 7 enumerates the correction. | Minor | **RETAINED CORRECTION:** the 18-row historical matrix has 1 PASS, 11 BLOCKED, 6 NOT TESTED and 0 FAIL. Those are historical statuses, not the status of this new design. |
| Breakout behavior existed but was not a frozen executable configuration | Primary Part 8 explicitly leaves parameters, duration, execution and trial budget unresolved. | Major | **RETAINED WITH LIMITATION:** it is a research hypothesis, not a production configuration or validated strategy. |

### Static count check

The corrected historical matrix count is reproducible:

```text
1 PASS + 11 BLOCKED + 6 NOT TESTED + 0 FAIL = 18 rows
```

This verifies the arithmetic reported in the primary document. It does not establish that its 18-row register completely covers every original and supplemental requirement.

---

## 3. Canonical owner-hard risk-policy catalog

This table is the single authoritative catalog for the six owner decisions in this unit. Values are ceilings or planning constraints, not targets and not optimization parameters.

| Policy | Owner-hard value | Operational interpretation |
|---|---|---|
| **D-RISK-1** | Peak-to-trough decline: **15% of initial equity**. The 20% figure is advisory context only. | Compare flow-adjusted peak and current equity against the initial-equity denominator. Latch risk increase off when the threshold is reached or exceeded. |
| **D-RISK-2** | Individual trade risk: **at most 5% of current equity**. | Compare the complete stressed risk reservation for one economic trade against the ceiling. |
| **D-RISK-3** | Planning basis **200 USDT**, sensitivity **100–500 USDT**. | Planning scale only; it is neither a reported balance nor proof of order feasibility. |
| **D-RISK-4** | Simultaneous open-position and risk-increasing pending-order risk: **at most 15% of equity**. | Sum conservative non-negative reservations without credit for offsets. |
| **D-RISK-5** | Daily realized-loss threshold: **10% of equity**; veto new risk for the remainder of the UTC day when reached. | Use the boundary reference-equity definition in §3.2 and preserve the latch until the next valid UTC day. |
| **D-RISK-6** | Effective leverage: **at most 5×**. | Gross open and potentially filling exposure divided by current equity; verified venue limits may be stricter. |

### 3.1 Equity and peak-to-trough accounting

`DESIGN_JUDGMENT`: define one durable risk-accounting epoch. Let:

- \(E_0\): reconciled initial equity at the epoch’s start, in USDT;
- \(E(t)\): reconciled current equity, including unrealized profit and loss, recognized fees and funding, in USDT;
- \(F(t)\): cumulative classified external deposits less withdrawals since epoch start, in USDT.

Then:

\[
A(t)=E(t)-F(t),\qquad
H(t)=\max\{E_0,A(s):s\le t\},\qquad
DD(t)=H(t)-A(t).
\]

The owner’s threshold is:

\[
DD(t)\ge 0.15E_0.
\]

The high-water mark is updated from valid observations and persisted before subsequent risk-increasing admission. An unclassified balance change makes the flow-adjusted history unevaluable and blocks new risk.

**Boundary example:** if \(E_0=200\) USDT and the adjusted peak is 240 USDT, the threshold is 30 USDT. Adjusted equity of 211 USDT gives \(240-211=29\) USDT; adjusted equity of 210 USDT gives 30 USDT and triggers the veto. The denominator is not the 240 USDT peak.

**Limitation:** sampled observations, market gaps, exchange failure and delayed fills can result in realized drawdown beyond the threshold. The policy is an admission and response control, not a guaranteed loss cap.

**Re-arm:** the treatment of a breached accounting epoch is `UNRESOLVED`. Acknowledgement does not reset the initial equity, erase the peak or repair missing history. Until a valid recovery and authorized accounting treatment exist, new Live risk remains disabled.

### 3.2 UTC daily realized-loss accounting

`DESIGN_JUDGMENT`: the day is `[00:00:00 UTC, next 00:00:00 UTC)`. Define daily reference equity as the reconstructed equity at the boundary, or a defensible conservative lower bound if only a bounded interval is available.

A post-midnight snapshot is **not automatically** the midnight value. Reconstruction requires a valid snapshot, complete intervening events and valid valuation inputs. If no defensible boundary value or lower bound is available, the daily risk check is unknown and new risk is refused.

\[
\text{DailyLoss}=\max(0,-\text{NetRealizedForUTCday})
\]

`NetRealizedForUTCday` includes realized trading profit and loss, fees, commissions, funding, rebates and corrections attributable to that day. Late events are recorded with both economic event time and receipt time. A late correction that reveals a prior breach creates an incident; it does not prove the system acted on information before receiving it.

On reaching the owner’s daily threshold, the daily latch remains active for the rest of that UTC day even if later realized gains improve the net figure. At the next boundary, it expires only after the new day’s reference and ledger are valid. Other independent vetoes do not reset with it.

### 3.3 Trade risk, aggregate risk and leverage

For a verified linear contract, a conservative modeled risk reservation is:

\[
R_{\text{trade}}
=
q\,m\,|P_{\text{entry}}-P_{\text{stress}}|
+C_{\text{entry}}+C_{\text{exit}}+C_{\text{spread}}
+C_{\text{slippage}}+C_{\text{funding}}+C_{\text{failure}}.
\]

Here \(q\) is contracts, \(m\) is verified underlying units per contract, prices are USDT per underlying unit, and every \(C\) term is in USDT. Costs already embedded in the stress prices must not be counted twice.

- A stop trigger is not automatically the stressed fill price.
- Quantity is rounded down to a verified increment, then risk is recomputed.
- Pending and partially filled quantities remain reserved until their outcomes are reconciled.
- Funding assumptions must cover the intended holding horizon; the observed clamp is not a universal bound.
- If contract terms, costs, price stress, protection behavior or other essential inputs are missing or contradictory, the new risk-increasing action is refused.

The aggregate calculation is the sum of conservative non-negative risk across open positions and pending risk-increasing orders. Opposing legs are not netted. For hedge-mode exposure, each leg is counted separately.

\[
L_{\text{effective}}
=
\frac{\text{gross open notional}+
      \text{conservative incremental pending notional}}
     {\text{current equity}}.
\]

A portfolio leverage check does not prove that exchange margin, maintenance margin or liquidation conditions are safe. Fact Pack §§8–9 leaves per-symbol constraints and margin behavior unresolved; no universal exchange limit is inferred.

### 3.4 Planning sensitivity

Assume only for this calculation that initial, current and daily reference equity are equal, and that there are no external flows.

| Equity, USDT | Individual risk ceiling, USDT | Aggregate risk ceiling, USDT | Daily realized-loss threshold, USDT | Initial-equity drawdown threshold, USDT | Gross exposure ceiling at owner leverage limit, USDT |
|---:|---:|---:|---:|---:|---:|
| 100 | 5 | 15 | 10 | 15 | 500 |
| 200 | 10 | 30 | 20 | 30 | 1,000 |
| 500 | 25 | 75 | 50 | 75 | 2,500 |

At the 200 USDT planning basis, the calculations are \(200\times0.05=10\) USDT, \(200\times0.15=30\) USDT, \(200\times0.10=20\) USDT and \(200\times5=1{,}000\) USDT. These are not recommended position sizes. Actual admissible exposure can be lower or unevaluable.

---

## 4. Atomic admission and risk-reservation contract

### 4.1 Authority and inputs

The signal or operator command may propose an action. Only the independent risk authority may authorize a risk-increasing intent. Telegram, an optimizer and retry logic cannot alter the policy catalog.

The admission record contains:

```text
intent identity
account and canonical instrument identity
side, position side, quantity and order parameters
strategy/configuration version and data provenance
equity, positions, pending orders and reservation snapshot versions
individual stressed-risk reservation
incremental gross-notional reservation
applicable interlock results and observation times
authorization result, reason and expiry condition
```

This is an internal schema, not a claim that Toobit exposes fields with these names.

### 4.2 Transaction and concurrency invariant

**Safety invariant:** two concurrent intents cannot both spend the same available risk or gross-exposure headroom.

For each proposed risk-increasing intent:

1. Obtain a consistent version of the policy, equity, open positions, known orders, unresolved outcomes and existing reservations.
2. Confirm that applicable data, reconciliation, credentials/permissions, configuration and clock checks are passing and sufficiently fresh.
3. Compute the trade’s full stressed risk, aggregate risk after reservation, effective leverage after reservation and remaining drawdown headroom.
4. If a required value is unknown, stale, contradictory or not safely bounded, refuse.
5. In one durable serialized transaction, allocate a non-reused client identity, record the immutable intent and policy versions, and add worst-case risk and exposure reservations.
6. If another transaction changed the relevant state version, abort and recompute rather than accepting a stale approval.
7. Immediately before a possible external send, re-evaluate invalidation conditions and durably record the submission attempt.
8. If durable recording fails before send, do not send. If a send may already have occurred, retain the reservation and classify the outcome as unknown.

The risk authority must account for the entire maximum plausible pending fill, not only the quantity currently observed as filled.

### 4.3 Partial fills and reservation transfer

On a verified partial fill:

- transfer the filled portion from pending reservation into the position-risk representation;
- retain the unfilled remainder as pending risk until its cancellation or completion is established;
- recompute total risk using the actual fill price, actual position and a conservative stress for the remainder;
- avoid double counting only when a verified mapping proves that a fill and position observation represent the same exposure.

A cancellation request alone releases nothing. If a cancel races with a fill, the fill changes the actual position; the remaining quantity is released only after sufficient terminal evidence and reconciliation.

If equity falls after approval, existing exposure can exceed newly reduced ceilings. The system immediately vetoes additional risk and evaluates verified risk-reducing actions. It cannot guarantee instantaneous compliance when markets gap or the venue is unavailable.

### 4.4 Split-brain and external side effects

A local lock or lease is insufficient by itself if two processes can independently reach the exchange after a network partition. The design therefore requires:

- one authorized Live submission authority for an account;
- durable ownership and generation records for its local state;
- no concurrent Live execution identity enabled during recovery or failover until the prior sender is known to be fenced;
- reconciliation before a replacement sender can create new risk.

Whether a deployment can enforce that fencing is a **deployment acceptance dependency**, not an established fact. If it cannot, Live risk increase remains blocked. No exactly-once delivery guarantee is assumed.

---

## 5. Order and reconciliation contract

### 5.1 Supplied exchange facts and evidence boundaries

| Fact or dependency | Evidence/status | Design consequence |
|---|---|---|
| New regular futures order | Fact Pack §3 supplies `POST /api/v2/futures/order`, mandatory fields, quantity alternatives and listed order types. Supplied-source status; not independently checked here. | Map only the supplied contract. Do not infer missing semantics. |
| Cancel identity | Fact Pack §3 supplies `orderId` or `origClientOrderId`, mutually exclusive. | Use one verified identity form; a cancel request is not cancellation confirmation. |
| Amend | Fact Pack §3 says LIMIT only. | Do not assume amendments for other order types. |
| Response status | Fact Pack §3 reports `NEW` and `CANCELED` observed; the full vocabulary is unresolved. | All other states below are local abstractions, not asserted exchange enums. |
| Ambiguous failure | Original C5 identifies `-1007` timeout ambiguity; Fact Pack §4 labels 5XX execution status unknown. | No blind resubmission. Preserve the full plausible reservation and reconcile. |
| Client identity | Original C11 supplies the character intersection `[A-Za-z0-9_-]`; Fact Pack §3 leaves uniqueness scope unresolved. | Enforce account-wide local non-reuse. Length, lookup completeness and venue idempotency remain unresolved. |
| Rate accounting | Original C4 reports absent rate headers in tested scope; Fact Pack §2 lists documented limits and headers. | Use explicit fixed-weight accounting as the safe baseline; headers are optional only if their semantics are actually established. |
| Filters and contract terms | Fact Pack §9 says per-symbol values are not extracted. | Future startup discovery and validation are required; no quantity, tick or leverage filter is invented here. |

The Fact Pack’s URLs are provenance metadata and future locators only. None was opened in this engagement.

### 5.2 Local lifecycle

| Local state | Trigger | Required behavior |
|---|---|---|
| **Intent durable** | Intent and reservation committed before a possible send. | Revalidate or reject locally; no exchange side effect has yet been attempted. |
| **Send attempt durable** | A durable record indicates that a request may be sent. | A crash from this point is potentially ambiguous unless a definitive outcome is recorded. |
| **Acknowledgement observed** | A correlated response or observation establishes an order exists under verified semantics. | Continue tracking fills and remaining exposure; acknowledgement is not a fill. |
| **Partial execution observed** | A correlated execution is established. | Transfer reservation as described in §4.3 and track remaining quantity. |
| **Cancel requested** | A cancel attempt is durably recorded. | Keep the remaining reservation until confirmation and reconciliation. |
| **Amend requested** | A permitted amendment is attempted. | Reserve the conservative worst case across old and proposed terms until resolved. |
| **Terminal outcome observed** | Sufficient evidence establishes final fill, cancellation or rejection. | Release only the reconciled unused reservation. |
| **Unknown outcome** | Timeout, 5XX, crash around send, contradictory observations or incomplete evidence. | Do not resend blindly; retain worst-case reservation. |
| **Reconciling** | Evidence is being assembled and compared. | Block affected new risk until query completeness and consistency are established. |
| **Terminal unresolved** | Available evidence cannot establish a safe state. | Preserve records, alert and keep affected risk blocked. |

A provisional “unknown order” response is not by itself proof that a previously submitted order never existed. A replacement is eligible only after evidence establishes the original outcome and a fresh risk admission approves a new intent.

### 5.3 What remains unresolved

The supplied evidence does not establish complete order lookup, pagination, retention, client-identifier length and reuse behavior, full status mapping, protective-order coverage, reduce-only behavior or safe close semantics.

A later resolution requires dated documentation exports and sanitized controlled response or measurement records. Until then:

- affected Live execution and automated protection are disabled or fail closed;
- an operator request is not reported as a completed close;
- a three-day provisional outage value is not treated as verified exchange retention;
- the absence of remote access in this engagement is not treated as evidence that the capability exists or does not exist.

---

## 6. Paper and Live separation

### 6.1 Mode selection versus strategy validation

The Paper/Live selector is an operator control, not a profitability award.

- `/mode paper` may select the internal simulator without a waiting period or a profitability hurdle.
- Selecting Paper does **not** establish that the candidate, dataset, timestamps or fill model are valid. A particular simulated decision is refused if its required data or state cannot be evaluated.
- A research claim that a candidate is validated requires its preregistered evaluation and applicable tests. That research claim is separate from the operator’s ability to select Paper.
- `/mode live` requires all six correctness interlocks to pass and produces an explicit refusal if any is failed or unknown.

Paper has a separate state namespace and execution identity, with no capability to submit real orders. Both Paper and Live are denied access to cross-venue research datasets by access controls and data lineage, not merely by documentation.

### 6.2 Switching to Paper with real exposure

A mode switch cannot make existing Live positions disappear:

1. Stop admitting new Live risk.
2. Keep Live orders, reservations, positions and reconciliation under the Live safety boundary.
3. Treat cancellation or reduction as separate actions, permitted only under established semantics and safe preconditions.
4. Keep Paper simulated positions and balances separate.
5. Report selected mode and any real open position, pending order or unresolved outcome independently.

A crash during transition leaves the transition blocked until durable state is restored and applicable Live state is reconciled. No unverified `reduceOnly` or emergency-order capability is assumed.

---

## 7. Offline arithmetic and source-status checks

No executable calculation, software test, backtest or exchange call was run.

### 7.1 Fee sensitivity

For an illustrative 100 USDT entry notional:

\[
100\times0.0006=0.06\ \text{USDT},\qquad
100\times0.0005=0.05\ \text{USDT}.
\]

If the exit notional is also assumed to be 100 USDT, two taker fees total 0.12 USDT at 0.06%, or 0.10 USDT at 0.05%. Fact Pack §7 supplies 0.06% as the conservative default and keeps 0.05% unresolved as a sensitivity case. Actual exit notional, fee tier, spread, slippage and funding are not established.

### 7.2 Storage ratio

Original C19’s reported measurement is:

\[
3{,}500\times14\times10=490{,}000\ \text{candle records}.
\]

\[
1.25\ \text{GB}/490{,}000
\approx 2.551\times10^{-6}\ \text{GB per record}.
\]

This ratio applies only to the measured data shape and comparable storage overhead. It excludes any independently unmeasured audit, order-book, backup or recovery overhead. The ten measurement symbols are not a proposed universe.

### 7.3 Rate-budget example

Fact Pack §2 assigns example weights of 40 to the 24-hour ticker and 8.35 to positions. Hypothetically:

\[
10(40)+20(8.35)=400+167=567\ \text{weight units}.
\]

Against the supplied 3,000-unit one-minute limit, \(567/3{,}000=0.189\), or 18.9%. This is only arithmetic under the assumption that the requests share the same applicable window and counter. Counter scope, other clients, reset behavior and recovery reserves remain unresolved; this is not a recommended polling schedule.

### 7.4 Trial-budget conflict

Original C22 says both “take the minimum of published and recomputed” and “if the discrepancy exceeds 2×, the recomputed value governs.” If recomputed is more than twice and larger than published, those instructions yield different values.

The safe interim branch uses the smaller value and records the conflict. No numerical trial budget is calculated because the cell-specific inputs and reproducible panel calculation are not supplied. Full permutation grids at timeframes of 12 hours or less remain prohibited by original C24.

---

## 8. Verification specifications

These are proposed tests, all **NOT TESTED**.

| Test | Fixture and action | Required result | Limitation |
|---|---|---|---|
| Concurrent admission | Present two intents that individually fit but jointly exceed available aggregate headroom. | At most one is approved; the other sees the committed reservation and is refused or recomputed. | Does not validate real exchange behavior. |
| Crash around send | Persist a send attempt, simulate external acceptance and lose the response before local acknowledgement. | Outcome remains unknown, reservation remains and no blind replacement is sent. | Does not establish venue lookup retention. |
| Cancel/fill race | Request cancellation, then deliver a fill before terminal cancellation evidence. | Actual position includes the fill; pending reservation is not prematurely released. | Depends on a later verified event mapping. |
| Daily boundary reconstruction | Supply a valid pre-boundary snapshot, an intervening event and a later snapshot. | The reference is reconstructed at midnight or marked unknown; the later snapshot is not silently substituted. | Does not prove completeness of real account history. |
| Paper capability isolation | Give the Paper runtime a simulated intent and attempt to invoke Live submission. | The Paper identity has no Live submission capability; denial is auditable. | Does not prove a deployment’s actual permission configuration. |
| Research-data firewall | Attempt to provide a cross-venue dataset to Paper or Live under their runtime identities. | Access is denied and the attempted lineage violation is recorded. | Does not prove every deployment route is configured correctly. |
| Missing risk history | Remove or corrupt the risk ledger and issue acknowledgement and Live requests. | Neither action creates a valid history; Live risk increase remains refused. | Does not establish that a backup can be restored. |
| Split-brain failover | Simulate an old sender retaining connectivity while a replacement attempts activation. | Replacement cannot gain Live submission authority until fencing and reconciliation are established. | A simulation does not prove a real host or credential can be fenced. |

---

## 9. Artifact registry and partial completeness

| Artifact | Location | Status | Content |
|---|---|---|---|
| Source update and offline checkpoint | §1 | DELIVERED | Parsed-input availability, capability limits and dependency graph. |
| Forensic findings | §2 | DELIVERED | Findings tied to actual locations in the supplied primary architecture. |
| Canonical risk policy | §3 | DELIVERED | Six owner-hard policies and operational accounting judgments. |
| Admission and reservation contract | §4 | DELIVERED | Serialized risk admission, partial-fill handling and split-brain dependency. |
| Order/reconciliation contract | §5 | DELIVERED | Local lifecycle, supplied exchange facts and unresolved semantics. |
| Paper/Live separation | §6 | DELIVERED | Mode-selection correction and real-exposure preservation. |
| Arithmetic and test specifications | §§7–8 | DELIVERED | Manual checks and unexecuted fixtures. |
| Complete 11-field requirements register and matching new verification matrix | Not present | DEFERRED | The primary register must be reconstructed and amended; its historical 18-row count is not the new package’s completeness count. |
| Full resource, deployment, security, operations and final integrated audit | Not present | DEFERRED | Material design work remains; no final handoff or freeze is claimed. |

**Registry arithmetic:** 7 delivered + 0 blocked + 2 deferred = 9 listed artifacts. This is an artifact count for this response, not a requirement count.

### Seven independent acceptance dimensions

| Dimension | Status | Observed basis |
|---|---|---|
| Design completeness and consistency | **BLOCKED** | The integrated requirements register, matching matrix and several material design domains are not delivered in this response. |
| Source and evidence review | **PARTIAL** | The three parsed documents are available; PDF binaries, raw archive and external documentation were not inspected. |
| Research/backtest evidence | **NOT TESTED** | No dataset evaluation or backtest occurred. |
| Implementation correctness | **NOT TESTED** | No implementation was created or executed. |
| Paper behavior | **NOT TESTED** | Only a proposed isolation and mode contract is specified. |
| Operational readiness | **NOT TESTED** | No device, restore, failover or outage drill was performed. |
| Live authorization | **BLOCKED** | This is design-only; no account access, interlock verification or Live authorization occurred. |

**Completeness for this unit:** the stated safety-core content is delivered with unresolved exchange dependencies and unexecuted tests disclosed. The overall redesign is not complete or frozen. A fixed total number of future messages cannot be verified from the observable interface; no future part is represented as already delivered.

**یادداشت پایانی:** هر سه متن استخراج‌شده دریافت شد و بازبینی معماری اولیه اکنون بر سند ۴۲ صفحه‌ای استوار است. سیاست ریسک، رزرو هم‌زمان و وضعیت سفارش نامشخص بازسازی شدند؛ اما طرح هنوز به سطح تحویل کامل مهندسی، آزمون عملیاتی یا مجوز Live نرسیده است.