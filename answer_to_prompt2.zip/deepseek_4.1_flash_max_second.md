[N]

**یادداشت پیشرفت — Part 1/5:** چارچوب سند، وضعیت‌ها، پیش‌فرض‌های HARD، مشتق‌گیری دامنه، توپولوژی، فازبندی، معماری سطح بالا، طراحی تفصیلی، ماشین‌های حالت و ADRها.

---

# TOOBIT TRADING CLOUD SYSTEM — FROZEN DESIGN PACKAGE

**Document ID:** TRD-ARCH-FROZEN-001  
**Version:** 1.0-FROZEN  
**Status:** Frozen with disclosed labels. This is a design package, not an implementation, backtest, paper-trading, or live-trading result.  
**Fact Source:** `toobit_fact_pack`, extraction date 2026-11-02 UTC. No other exchange data is used.  
**Precedence:** `PROMPT.md` RATIFIED_FINDING > `toobit_fact_pack` > design judgment. For DOC_CONFLICT C4 and C13, the conservative branch is selected and labelled.  
**Currency:** All monetary amounts are in USDT unless explicitly marked as a non-monetary unit (bps, percentage, count). No USD amount is used as a primary value.

---

## 0. Document Control, Legends, and Identifier Catalog

### 0.1 Document Control

| Field | Content | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| Document owner | Architecture Owner | DESIGN_JUDGMENT | This section | Single accountable owner for freeze. |
| Approvers required before implementation funding | Product Owner, Risk Owner, Security Owner, Operations Owner | DESIGN_JUDGMENT | §1.3 | No implementation phase starts without these signatures. |
| Fact-pack dependency | `toobit_fact_pack` only | RATIFIED_FINDING | User instruction §0.1 | No exchange fact outside the fact pack is asserted. |
| Implementation readiness | Not established | NOT TESTED | §45 | No production-readiness claim is made. |
| Backtest readiness | Not established | NOT TESTED | §29 | No profitability or backtest-performance claim is made. |
| Paper readiness | Not established | NOT TESTED | §27, §45 | No paper-execution result is claimed. |
| Live readiness | Not established | NOT TESTED | §45 | No live-execution result is claimed. |

### 0.2 Status and Evidence Legend

| Label | Meaning | Permitted Use in This Package |
|---|---|---|
| SOURCE_VERIFIED | Directly supported by a `toobit_fact_pack` item marked SOURCE_VERIFIED. | Exchange fact. |
| RATIFIED_FINDING | Binding finding from `PROMPT.md`. | Owner-level or precedent-level constraint. |
| PROVISIONAL | Working design value with a stated resolution path. | Permitted only with resolution path and consequence. |
| UNRESOLVED | Not determined by the fact pack or binding decision. | Permitted with resolution path and consequence; not a NO-GO by itself. |
| DOC_CONFLICT | Sources conflict; conservative branch selected. | Used for C4 and C13. |
| DESIGN_JUDGMENT | Engineering decision made in this package. | Not an exchange fact and not a measured result. |
| NOT TESTED | No execution evidence exists in this engagement. | Used for implementation/backtest/paper/live readiness. |
| BLOCKED | Cannot proceed without an owner decision not present in the inputs. | No BLOCKED item is declared in this package; count is zero. |
| OUT_OF_SCOPE | Explicitly excluded by the owner instruction. | Used for cross-exchange regulatory compliance and execution readiness. |

Evidence categories used throughout:

| Category | Definition |
|---|---|
| E1 Direct evidence | A `toobit_fact_pack` item with SOURCE_VERIFIED status, or a RATIFIED_FINDING in `PROMPT.md`. |
| E2 Transparent derivation | A formula, arithmetic chain, or table whose inputs and operations are visible. |
| E3 Explicit reasoning | A stated design rationale with rejected alternatives. |
| E4 Explicit label | A status label with resolution path and consequence. |

### 0.3 Identifier Catalog

Every identifier used in more than one section is defined here before use.

| Prefix | Meaning | Example |
|---|---|---|
| REQ-### | Requirement register identifier | REQ-001 |
| ADR-### | Architecture Decision Record | ADR-001 |
| API-### | Internal or external API endpoint identifier | API-001 |
| DC-### | Data contract identifier | DC-001 |
| IC-### | Interface contract identifier | IC-001 |
| SM-### | State machine identifier | SM-001 |
| RISK-### | Pre-trade or runtime risk check | RISK-001 |
| KILL-### | Kill-switch level | KILL-L1 |
| RB-### | Runbook identifier | RB-01 |
| PH-### | Phase identifier | PH-01 |
| TOP-### | Deployment topology option | TOP-01 |
| FM-### | Failure mode identifier | FM-001 |
| DR-### | Disaster-recovery scenario | DR-01 |
| V-### | Verification checklist item | V-1 |
| ART-### | Artifact registry identifier | ART-001 |
| T-### | Test case identifier | T-001 |
| EV-### | Evidence pointer identifier | EV-001 |

### 0.4 D20 / D21 / D22 Compliance Statement

| Rule | Compliance Statement | Evidence Pointer |
|---|---|---|
| D20 | Every material item in this package has content, rationale, status, evidence pointer, and consequence. Tables that summarize design choices include those columns. | All tables in §1–§46; §47–§52. |
| D21 | No abbreviation, deferral, truncation, “for brevity”, “see above without content”, “will be covered later”, or unlabeled TBD is used. UNRESOLVED items carry resolution path and consequence. | §0.2, §46, §49. |
| D22 | This package is delivered as Part 1/5 through Part 5/5 with explicit cross-references. Completeness Declaration appears in Part 5/5. | Part labels and §49. |

---

## 1. Scope, Exclusions, and Binding Constraints

### 1.1 In-Scope System

| Scope Item | Content | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| S-01 | Toobit USDT-M perpetual futures trading system design | DESIGN_JUDGMENT | `toobit_fact_pack` §3, §9 | Live execution is restricted to Toobit only. |
| S-02 | Market data ingestion from Toobit REST and WebSocket | SOURCE_VERIFIED | `toobit_fact_pack` §1, §5, §11 | WebSocket heartbeat and REST fallback are mandatory. |
| S-03 | Order management and execution adapter for Toobit v2 futures API | SOURCE_VERIFIED | `toobit_fact_pack` §3 | All order paths must comply with documented fields and conservative error handling. |
| S-04 | Risk engine, kill switch, reconciliation, audit trail | RATIFIED_FINDING | Owner instruction §1; `PROMPT.md` C5 | Six interlocks are non-bypassable. |
| S-05 | Paper/Live selector via Telegram with no waiting period and no profit threshold | RATIFIED_FINDING | Owner instruction §1 | Selector is immediate after interlocks pass. |
| S-06 | Research/backtest data zone isolated from Paper/Live | RATIFIED_FINDING | Owner instruction §1 | No network path from research cross-venue data to Paper/Live. |
| S-07 | Internal audit trail and Toobit ToS compliance matrix | RATIFIED_FINDING | Owner instruction §1 | Regulatory compliance beyond this scope is out of scope. |

### 1.2 Out-of-Scope Items

| Out-of-Scope Item | Reason | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| Cross-exchange live routing | Live is Toobit-only | RATIFIED_FINDING | Owner instruction §1 | SOR is replaced by Toobit-internal execution strategy selection. |
| Regulatory compliance beyond Toobit ToS, general security, internal audit | Owner instruction | OUT_OF_SCOPE | Owner instruction §1 | No claim of regulatory compliance is made. |
| Profitability claims | Not permitted | OUT_OF_SCOPE | Owner instruction §1 | No expected-return, alpha, or profitability statement appears. |
| Implementation readiness | Not in scope | NOT TESTED | Owner instruction §1 | No code, binary, deployment, or production-readiness evidence exists. |
| Backtest results | Not in scope | NOT TESTED | Owner instruction §1 | No backtest performance is claimed. |
| Paper-trading results | Not in scope | NOT TESTED | Owner instruction §1 | No paper-execution result is claimed. |
| Live-trading results | Not in scope | NOT TESTED | Owner instruction §1 | No live-execution result is claimed. |
| Legal or sanctions determination for cross-venue data | Owner responsibility | OUT_OF_SCOPE | Owner instruction §1 | The system only enforces isolation and source-tag lineage. |

### 1.3 Binding Owner Decisions

| ID | Decision | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| D-RISK-1 | Maximum drawdown from peak to trough is 15% of initial equity HARD; 20% is advisory only. | RATIFIED_FINDING | Owner instruction §1 | Risk engine must veto at 15%; 20% is alert-only. |
| D-RISK-2 | Maximum risk per trade is 5% of current equity HARD. | RATIFIED_FINDING | Owner instruction §1 | Order sizing must reject any trade whose worst-case loss exceeds 5% current equity. |
| D-RISK-3 | Planning scale is 200 USDT HARD; sensitivity range is 100–500 USDT. | RATIFIED_FINDING | Owner instruction §1 | All capital calculations are shown at 200 USDT and sensitivity at 100/500 USDT. |
| D-RISK-4 | Sum of concurrent open risk is ≤15% of equity HARD. | RATIFIED_FINDING | Owner instruction §1 | New orders are vetoed if aggregate risk would exceed 15%. |
| D-RISK-5 | Daily realized loss limit is 10% of equity HARD; veto until next UTC day. | RATIFIED_FINDING | Owner instruction §1 | Daily stop state persists until 00:00 UTC. |
| D-RISK-6 | Maximum effective leverage is 5× as an enforceable cap, not a target. | RATIFIED_FINDING | Owner instruction §1 | Position notional is capped at 5× current equity regardless of exchange maximum. |
| D-SELECT-1 | Live/Paper selector via Telegram is approved with no waiting period and no profit threshold. | RATIFIED_FINDING | Owner instruction §1 | Selector command is immediate after six interlocks. |
| D-INTERLOCK-1 | Six interlocks are non-bypassable: data-validity, reconciliation, risk-limit, credential/permission, config-integrity, clock. | RATIFIED_FINDING | Owner instruction §1 | No Live order can bypass any interlock. |
| D-PHASE-1 | Phasing must derive from requirements; all deviations disclosed in one completeness table. | RATIFIED_FINDING | Owner instruction §1 | §6 contains the single phase completeness disclosure table. |
| D-TOPOLOGY-1 | Topology must be derived from D15 and Step 4b; all possible topologies listed before compromise; each sub-step deviation disclosed. | RATIFIED_FINDING | Owner instruction §1 | §5 lists TOP-01 through TOP-08 and the selected compromise. |
| D-UNIVERSE-1 | Market universe must derive from D14; the 10 C19 symbols are measurement candidates only, not the universe. | RATIFIED_FINDING | Owner instruction §1 | §4 defines runtime universe derivation. |
| D-CROSSVENUE-1 | Cross-venue data is research/backtest only; no Paper/Live access; source-tag lineage mandatory. | RATIFIED_FINDING | Owner instruction §1 | §14 defines physical and logical isolation. |
| D-COMPLIANCE-1 | Regulatory compliance beyond Toobit ToS + general security + internal audit is out of scope. | RATIFIED_FINDING | Owner instruction §1 | §42 limits the compliance matrix to that scope. |
| D-SLO-1 | SLO/RTO/RPO are design targets, not measured results. | RATIFIED_FINDING | Owner instruction §1 | §32 labels every target as DESIGN_JUDGMENT or PROVISIONAL. |
| D-READINESS-1 | Implementation/backtest/paper/live readiness is NOT TESTED / OUT OF SCOPE. | RATIFIED_FINDING | Owner instruction §1 | §45 and §49 preserve this status. |
| D-FROZEN-1 | Frozen means status + evidence pointer + consequence for material items; UNRESOLVED is permitted and not a NO-GO. | RATIFIED_FINDING | Owner instruction §1 | §46 and §49 disclose labels without declaring NO-GO. |
| D-D20-1 | D20, D21, D22 apply fully. | RATIFIED_FINDING | Owner instruction §4 | §0.4 and all tables comply. |

---

## 2. Capital, Risk Arithmetic, and Hard Limits

All amounts are USDT. The planning equity is 200 USDT. Sensitivity bounds are 100 USDT and 500 USDT.

### 2.1 Hard Limit Table

| Limit | Formula | At 100 USDT | At 200 USDT | At 500 USDT | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|---|
| Per-trade risk cap D-RISK-2 | 5% × current equity | 5.00 USDT | 10.00 USDT | 25.00 USDT | RATIFIED_FINDING | Owner instruction §1 | Any order with worst-case loss above the row value is rejected. |
| Aggregate concurrent risk D-RISK-4 | 15% × equity | 15.00 USDT | 30.00 USDT | 75.00 USDT | RATIFIED_FINDING | Owner instruction §1 | New order rejected if sum of open risk plus new risk exceeds row value. |
| Daily realized loss stop D-RISK-5 | 10% × equity | 10.00 USDT | 20.00 USDT | 50.00 USDT | RATIFIED_FINDING | Owner instruction §1 | Veto new entries until next UTC day after breach. |
| Maximum drawdown D-RISK-1 | 15% × initial equity | 15.00 USDT | 30.00 USDT | 75.00 USDT | RATIFIED_FINDING | Owner instruction §1 | Hard veto on new risk; liquidation/reduce-only mode. |
| Advisory drawdown | 20% × initial equity | 20.00 USDT | 40.00 USDT | 100.00 USDT | RATIFIED_FINDING | Owner instruction §1 | Alert only; does not override 15% hard veto. |
| Maximum effective leverage D-RISK-6 | 5× current equity | 500.00 USDT notional | 1,000.00 USDT notional | 2,500.00 USDT notional | RATIFIED_FINDING | Owner instruction §1 | Position notional above row value is rejected even if exchange permits more. |

### 2.2 Transparent Position-Sizing Derivation

Let:

- \(E\) = current equity in USDT.
- \(r\) = per-trade risk fraction = 5% HARD.
- \(R = r \times E\) = maximum worst-case loss per trade.
- \(d\) = stop distance as a fraction of entry price.
- \(N = R / d\) = risk-based notional.
- \(N_{\max} = 5 \times E\) = leverage cap notional.
- Actual notional \(N_{\text{actual}} = \min(N, N_{\max})\).

At \(E=200\) USDT, \(R=10\) USDT.

| Stop distance \(d\) | Risk-based notional \(N\) | Leverage-cap notional \(N_{\max}\) | Actual notional \(N_{\text{actual}}\) | Worst-case loss at actual notional | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|---|
| 0.50% | 2,000.00 USDT | 1,000.00 USDT | 1,000.00 USDT | 5.00 USDT | DESIGN_JUDGMENT | E2 derivation | Risk is below 5% because leverage cap binds. |
| 1.00% | 1,000.00 USDT | 1,000.00 USDT | 1,000.00 USDT | 10.00 USDT | DESIGN_JUDGMENT | E2 derivation | Both caps bind at equality. |
| 2.00% | 500.00 USDT | 1,000.00 USDT | 500.00 USDT | 10.00 USDT | DESIGN_JUDGMENT | E2 derivation | Risk cap binds; leverage cap does not. |
| 5.00% | 200.00 USDT | 1,000.00 USDT | 200.00 USDT | 10.00 USDT | DESIGN_JUDGMENT | E2 derivation | Risk cap binds. |

The risk engine must compute this chain per order and reject any order whose computed worst-case loss exceeds the applicable cap.

### 2.3 Daily Loss and Drawdown Accounting

| Item | Definition | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| Realized daily loss | Sum of closed-trade losses minus closed-trade gains since 00:00 UTC, including fees and funding. | RATIFIED_FINDING | D-RISK-5 | Breach sets DAILY_STOP until next UTC day. |
| Unrealized loss | Mark-to-market loss on open positions. | DESIGN_JUDGMENT | E3 | Feeds warning and drawdown, not the daily realized stop exclusively. |
| Peak equity | Highest equity observed since inception or after a manual reset approved by Risk Owner. | DESIGN_JUDGMENT | E3 | Manual reset requires 4-eye approval and audit entry. |
| Drawdown | \(1 - E / E_{\text{peak}}\). | RATIFIED_FINDING | D-RISK-1 | At 15% hard veto; at 20% advisory alert only. |
| Daily veto expiry | First instant of next UTC day. | RATIFIED_FINDING | D-RISK-5 | No timezone ambiguity is permitted. |

---

## 3. Market Universe Derivation (D14)

### 3.1 Derivation Rules

| Step | Rule | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| U-01 | Fetch the current contract list from `GET /api/v1/exchangeInfo` at runtime. | SOURCE_VERIFIED | `toobit_fact_pack` §9 | No static universe is frozen. |
| U-02 | Include only USDT-margined perpetual futures whose quote asset is USDT. | DESIGN_JUDGMENT | E3 | Spot symbols and non-USDT contracts are excluded. |
| U-03 | Exclude symbols with status not equal to active or with missing contract specification. | DESIGN_JUDGMENT | E3 | Missing specification cannot be traded. |
| U-04 | Fetch 30 days of 1-minute klines and repeated depth snapshots for liquidity measurement. | DESIGN_JUDGMENT | E3 | Actual historical availability is subject to fact-pack limits. |
| U-05 | Compute liquidity score \(L_s\) from median daily quote volume, median top-5 depth, and median spread. | DESIGN_JUDGMENT | E2 formula below | Score is a ranking input, not an exchange fact. |
| U-06 | Apply risk filters for funding-tail, contract multiplier, tick size, step size, and minimum notional. | DESIGN_JUDGMENT | E3 | Symbols outside enforceable risk limits are excluded. |
| U-07 | Select at most \(N_{\text{active}}\) symbols ranked by \(L_s\). | PROVISIONAL | Resolution path §3.4 | \(N_{\text{active}}\) is a design parameter; sensitivity is disclosed. |
| U-08 | The 10 C19 symbols are measurement candidates only and are not the universe. | RATIFIED_FINDING | Owner instruction §1 | No assumption that C19 equals the universe. |

### 3.2 Liquidity Score Formula

For symbol \(s\):

- \(Q_s\) = median daily quote volume over 30 days, in USDT.
- \(D_s\) = median of min(top-5 bid notional, top-5 ask notional) over sampled 1-minute snapshots, in USDT.
- \(S_s\) = median bid-ask spread in basis points.

\[
L_s = 0.5 \log_{10}(Q_s + 1) + 0.3 \log_{10}(D_s + 1) - 0.2 \log_{10}(S_s + 1)
\]

| Parameter | Value | Status | Rationale | Resolution Path | Consequence |
|---|---|---|---|---|---|
| Weight \(w_1\) for volume | 0.5 | DESIGN_JUDGMENT | Volume is the strongest liquidity proxy for 200 USDT scale. | Recalibrate after 30 days of runtime measurement. | If changed, universe ranking changes; audit entry required. |
| Weight \(w_2\) for depth | 0.3 | DESIGN_JUDGMENT | Depth reduces slippage for small orders. | Recalibrate with fill simulator. | If changed, ranking changes. |
| Weight \(w_3\) for spread | 0.2 | DESIGN_JUDGMENT | Spread is a direct transaction-cost proxy. | Recalibrate with fee model. | If changed, ranking changes. |
| Minimum score \(L_{\min}\) | 5.0 | PROVISIONAL | Initial conservative threshold; actual distribution is not in fact pack. | Measure runtime distribution and set to 20th percentile of eligible symbols. | If too high, universe may be empty; system enters PAPER_OBSERVE, not Live. |
| Maximum active symbols \(N_{\text{active}}\) | 10 | PROVISIONAL | Fits 200 USDT planning scale and operational capacity. | Sensitivity at 5 and 20 symbols. | Higher N increases monitoring load and aggregate risk. |

### 3.3 Universe Output Contract

The universe service must output a versioned record:

| Field | Type | Validation | Status |
|---|---|---|---|
| `universe_version` | string | Monotonic ID | DESIGN_JUDGMENT |
| `generated_at_utc` | timestamp | ISO-8601 UTC | DESIGN_JUDGMENT |
| `source_exchange` | literal `TOOBIT` | Exactly `TOOBIT` | RATIFIED_FINDING |
| `symbols` | array of objects | Each object contains `symbol`, `contractMultiplier`, `tickSize`, `stepSize`, `minQty`, `maxLeverageExchange`, `liquidityScore` | DESIGN_JUDGMENT |
| `excluded_symbols` | array of objects | Each object contains `symbol` and `exclusion_reason` | DESIGN_JUDGMENT |
| `data_status` | enum | `COMPLETE`, `PARTIAL`, `STALE` | DESIGN_JUDGMENT |

### 3.4 Universe-Related UNRESOLVED Items

| ID | Item | Status | Resolution Path | Consequence |
|---|---|---|---|---|
| U-UNR-01 | Actual per-symbol minQty, stepSize, tickSize, and maxLeverage values are not extracted. | UNRESOLVED | Fetch `/api/v1/exchangeInfo` at runtime and persist snapshot with hash. | Live order sizing cannot be validated until runtime fetch succeeds. |
| U-UNR-02 | Actual 30-day liquidity distribution is not in fact pack. | UNRESOLVED | Measure runtime klines and depth; produce distribution report. | \(L_{\min}\) remains PROVISIONAL; universe may be empty under strict threshold. |
| U-UNR-03 | Full current contract list is not in fact pack. | UNRESOLVED | Runtime `exchangeInfo` fetch is authoritative. | The partial list in fact pack §10 is not used as universe. |

---

## 4. Deployment Topology Derivation and Compromise (D15 / Step 4b)

### 4.1 Complete Topology Enumeration

| ID | Topology | Description | Advantages | Disadvantages | Status |
|---|---|---|---|---|---|
| TOP-01 | Single-region, single-AZ cloud | All components in one availability zone. | Lowest cost, simplest operations. | No AZ fault tolerance. | DESIGN_JUDGMENT |
| TOP-02 | Single-region, multi-AZ cloud | Active components across at least two AZs in one region. | AZ failure tolerance with moderate cost. | Region failure loses service. | DESIGN_JUDGMENT |
| TOP-03 | Multi-region active-passive cloud | One active region, one warm standby region. | Region failure recovery. | Higher cost and data replication complexity. | DESIGN_JUDGMENT |
| TOP-04 | Multi-region active-active cloud | Two or more active regions. | Highest availability. | Highest complexity; consistency and split-brain risk. | DESIGN_JUDGMENT |
| TOP-05 | On-premises only | Dedicated hardware in owner facility. | Full control. | High capital cost; no Toobit colocation benefit. | DESIGN_JUDGMENT |
| TOP-06 | Exchange-colocated | Hardware near Toobit infrastructure. | Lowest network latency if available. | Not established in fact pack; no colocation product is documented. | UNRESOLVED |
| TOP-07 | Hybrid: cloud control plane + dedicated execution VPC | Control plane in managed cloud; execution in isolated VPC. | Balances operations and isolation. | More network paths to secure. | DESIGN_JUDGMENT |
| TOP-08 | Edge + cloud | Edge ingestion and cloud processing. | Potential latency benefit. | Edge security and operations burden. | DESIGN_JUDGMENT |

### 4.2 Selected Compromise and Sub-Step Deviations

| Step | Required Consideration | Selected Compromise | Deviation | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|
| 4b.1 | List all topologies before compromise | TOP-01 through TOP-08 listed | None | DESIGN_JUDGMENT | §4.1 | Complete enumeration exists. |
| 4b.2 | Select topology | TOP-02 single-region multi-AZ cloud for v1; TOP-03 as DR target | No active-active; no on-prem; no colocation | DESIGN_JUDGMENT | This section | Region loss requires DR activation. |
| 4b.3 | Execution isolation | Execution components run in a dedicated VPC with private subnets and egress allow-list to `api.toobit.com` and `stream.toobit.com` | Shared Kubernetes cluster is not used for order execution | DESIGN_JUDGMENT | §37 | Reduces blast radius; increases operational complexity. |
| 4b.4 | Data residency | Primary region selected by owner before implementation | Region not specified in inputs | UNRESOLVED | Owner decision required before deployment | No deployment region is asserted. |
| 4b.5 | Cross-region replication | Asynchronous replication to warm standby | RPO target not measured | PROVISIONAL | §32 | DR target is design intent, not verified. |
| 4b.6 | Colocation | Not selected | No documented Toobit colocation product | UNRESOLVED | Fact pack §1 | Latency target is internet-based, not colocation-based. |

---

## 5. Phasing Derivation (D-PHASE-1)

### 5.1 Phase Table

| Phase | Scope | Requirements Covered | Exit Criteria | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|
| PH-01 | Governance, frozen design, decision register | REQ-001 to REQ-006 | Signed freeze and zero unlabeled owner decisions | DESIGN_JUDGMENT | §1, §46 | Implementation cannot start until accepted. |
| PH-02 | Core platform: identity, config, audit, observability | REQ-007 to REQ-014, REQ-051 to REQ-058 | Design review passed; no runtime test claimed | DESIGN_JUDGMENT | §7, §34, §35 | Foundation for all later phases. |
| PH-03 | Toobit market data and exchange-info adapter | REQ-015 to REQ-022 | Exchange-info fetch design and data contracts accepted | DESIGN_JUDGMENT | §13, §14 | Universe remains runtime-derived. |
| PH-04 | Risk engine, six interlocks, kill switch | REQ-023 to REQ-032 | Risk state machine and interlock veto paths accepted | DESIGN_JUDGMENT | §18–§21 | Live selector cannot enable without interlocks. |
| PH-05 | Paper/Live selector and execution simulation | REQ-033 to REQ-042 | Telegram command preconditions and simulated execution accepted | DESIGN_JUDGMENT | §22–§26 | Paper mode is designed; not executed in this engagement. |
| PH-06 | Research/backtest isolation | REQ-015, REQ-043 to REQ-050 | Research zone isolation design accepted | DESIGN_JUDGMENT | §14, §29 | Cross-venue data cannot reach Paper/Live. |
| PH-07 | Operational readiness design | REQ-059 to REQ-068 | Runbooks, monitoring, BCP/DR, procedural consistency accepted | DESIGN_JUDGMENT | §36–§42 | Operational design complete; execution NOT TESTED. |
| PH-08 | Production-readiness gate design | REQ-069 to REQ-072 | Gate definitions accepted; execution evidence absent | NOT TESTED | §45 | No production-readiness claim is made. |

### 5.2 Phase Completeness Disclosure

| Deviation ID | Phase | Deviation | Reason | Status | Consequence |
|---|---|---|---|---|---|
| PH-D-01 | PH-01 to PH-08 | Phase names differ from owner vocabulary. | D-PHASE-1 permits different names if disclosed. | DESIGN_JUDGMENT | Mapping is explicit in §5.1. |
| PH-D-02 | PH-05 | Paper execution not performed. | Out of scope. | NOT TESTED | No paper result exists. |
| PH-D-03 | PH-08 | Production gate not executed. | Out of scope. | NOT TESTED | No readiness certificate exists. |
| PH-D-04 | PH-03 | Full exchange-info snapshot not available in fact pack. | Fact pack lacks per-symbol values. | UNRESOLVED | Runtime fetch required; no static universe frozen. |

---

## 6. System Architecture

### 6.1 Layered Architecture

| Layer | Components | Responsibility | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|
| L0 External | Toobit REST, Toobit WebSocket, Telegram Bot API | Exchange and operator interface | SOURCE_VERIFIED for Toobit endpoints; Telegram is design choice | `toobit_fact_pack` §1, §11; §26 | All live order flow terminates at Toobit. |
| L1 Gateway | API Gateway, WebSocket Gateway, Telegram Command Gateway | Authentication, rate limiting, request validation | DESIGN_JUDGMENT | §10, §34 | No command reaches core without validation. |
| L2 Control Plane | Config Service, Credential Service, Interlock Service, Audit Service, Scheduler | Configuration, secrets, interlocks, time, audit | DESIGN_JUDGMENT | §18, §20, §42 | Non-bypassable interlocks live here. |
| L3 Market Data | Ingestor, Normalizer, Kline Store, Depth Store, Funding Store, Freshness Monitor | Toobit market data collection and validation | DESIGN_JUDGMENT | §14 | Stale data blocks Live. |
| L4 Strategy | Signal Engine, Decision Engine, Portfolio Allocator | Signal generation, confirmation, allocation | DESIGN_JUDGMENT | §22, §25 | No profitability claim. |
| L5 Risk | Pre-Trade Risk, Runtime Risk, Kill Switch, Reconciliation | All limit checks and vetoes | DESIGN_JUDGMENT | §18–§21 | Fail-closed on uncertainty. |
| L6 Execution | OMS, Toobit Order Adapter, Toobit Execution Strategy Selector, Position Manager | Order lifecycle and Toobit-only routing | DESIGN_JUDGMENT | §23, §24 | No cross-exchange live routing. |
| L7 Data | PostgreSQL, Object Store, Time-Series Store, Research Zone | Persistent state, audit, analytics | DESIGN_JUDGMENT | §15, §16 | Research zone is isolated from Paper/Live. |
| L8 Observability | Metrics, Logs, Traces, Alerts | Runtime visibility | DESIGN_JUDGMENT | §35 | No silent degradation. |

### 6.2 High-Level Architecture Diagram

```text
┌─────────────────────────────────────────────────────────────────────┐
│                         OPERATOR / TELEGRAM                         │
│  /paper, /live, /kill, /status, /ack  (signed, authorized user)     │
└───────────────────────────────┬─────────────────────────────────────┘
                                │
┌───────────────────────────────▼─────────────────────────────────────┐
│                         CONTROL PLANE                               │
│  Telegram Gateway → Command Validator → Interlock Service           │
│  Config Service · Credential Service · Clock Service · Audit Service│
└───────────────────────────────┬─────────────────────────────────────┘
                                │ signed config + mode
┌───────────────────────────────▼─────────────────────────────────────┐
│                         TRADING CORE                                │
│  Market Data → Signal Engine → Risk Engine → OMS → Toobit Adapter   │
│       │              │              │           │                   │
│       │              │              │           └──► Toobit REST    │
│       │              │              └──► Position/Reconciliation    │
│       │              └──► Portfolio Allocator                       │
│       └──► Freshness / Data Validity                                │
└───────────────────────────────┬─────────────────────────────────────┘
                                │
┌───────────────────────────────▼─────────────────────────────────────┐
│                         DATA PLANE                                  │
│  PostgreSQL · Object Store · Time-Series Store · Audit WORM         │
│  Research Zone (isolated): cross-venue data, source-tag lineage     │
└─────────────────────────────────────────────────────────────────────┘
```

### 6.3 Data Flow Diagram

```text
Toobit WebSocket ──► Market Data Ingestor ──► Normalizer ──► Freshness Monitor
                                                │
                                                ├──► Kline/Depth/Funding Store
                                                └──► Signal Engine
Signal Engine ──► Decision Engine ──► Portfolio Allocator ──► Risk Engine
Risk Engine ──► OMS ──► Toobit Order Adapter ──► Toobit REST
Toobit REST / WebSocket ──► Execution Report Ingestor ──► OMS
OMS ──► Position Manager ──► Reconciliation ──► Audit Service
Audit Service ──► PostgreSQL + Object Store + Audit WORM
Research Zone ──► Backtest/Research only; no network route to Trading Core
```

### 6.4 Module Responsibilities

| Module | Responsibility | Inputs | Outputs | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|
| Telegram Command Gateway | Accept signed operator commands | Telegram messages | Validated command events | DESIGN_JUDGMENT | §26 | Unauthorized commands are rejected. |
| Interlock Service | Evaluate six interlocks | Data freshness, reconciliation, risk, credential, config, clock | ALLOW/BLOCK | RATIFIED_FINDING | §18 | No Live order without all six ALLOW. |
| Market Data Ingestor | Connect to Toobit WebSocket and REST | Toobit streams, REST snapshots | Normalized ticks, klines, depth | SOURCE_VERIFIED | `toobit_fact_pack` §11 | Heartbeat is mandatory. |
| Freshness Monitor | Detect stale or missing data | Timestamps, sequence numbers | Freshness state | DESIGN_JUDGMENT | §18 | Stale state blocks Live. |
| Signal Engine | Produce candidate signals | Market data, reference data | Signal events | DESIGN_JUDGMENT | §22 | No profitability claim. |
| Decision Engine | Apply confirmations and thresholds | Signals, portfolio state | Order intents | DESIGN_JUDGMENT | §22 | Low-confidence signals are suppressed. |
| Portfolio Allocator | Allocate capital and size orders | Order intents, equity, risk state | Sized order requests | DESIGN_JUDGMENT | §25 | Sizing obeys D-RISK-2/4/6. |
| Risk Engine | Reject or approve orders | Order requests, limits, positions | ALLOW/REJECT with reason | RATIFIED_FINDING | §18 | Fail-closed on uncertainty. |
| OMS | Manage order lifecycle | Approved orders, execution reports | State transitions, events | DESIGN_JUDGMENT | §24 | Unknown states trigger reconciliation. |
| Toobit Order Adapter | Sign and send Toobit REST requests | OMS commands | Toobit responses | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Rate limits and auth rules apply. |
| Execution Strategy Selector | Choose Toobit order type and timing | Order intent, market state | Toobit order parameters | DESIGN_JUDGMENT | §23 | No cross-exchange routing. |
| Position Manager | Maintain positions and PnL | Fills, funding, fees | Position snapshots, PnL | DESIGN_JUDGMENT | §24, §25 | Reconciliation required. |
| Reconciliation Service | Compare internal and exchange state | Internal ledger, Toobit queries | CLEAN/DIVERGED | DESIGN_JUDGMENT | §18, §24 | Divergence blocks Live. |
| Audit Service | Immutable decision trail | All events | WORM audit records | DESIGN_JUDGMENT | §42 | No deletion without retention policy. |

---

## 7. Detailed Design and State Machines

### 7.1 Order Lifecycle State Machine SM-001

Internal states are authoritative. Exchange status values are mapped when observed. Full Toobit status set is UNRESOLVED in the fact pack.

| State | Meaning | Allowed Next States | Trigger | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|
| DRAFT | Order intent created | VALIDATED, REJECTED | Validation start | DESIGN_JUDGMENT | §24 | No exchange call yet. |
| VALIDATED | Passed schema and symbol validation | RISK_PENDING, REJECTED | Validation pass | DESIGN_JUDGMENT | §24 | Still no exchange call. |
| RISK_PENDING | Awaiting risk decision | APPROVED, REJECTED | Risk engine response | DESIGN_JUDGMENT | §18 | No order sent before approval. |
| APPROVED | Risk approved | SUBMITTING, CANCELED | Execution scheduling | DESIGN_JUDGMENT | §23 | Approval is time-bounded; expiry re-checks risk. |
| SUBMITTING | Request being sent to Toobit | OPEN, UNKNOWN, REJECTED | HTTP response or timeout | DESIGN_JUDGMENT | `toobit_fact_pack` §3 | Timeout never proves rejection. |
| OPEN | Exchange acknowledged and order is live | PARTIAL_FILLED, FILLED, CANCELED, UNKNOWN | Execution report | DESIGN_JUDGMENT | `toobit_fact_pack` §3 | Only NEW is confirmed; other statuses are UNRESOLVED. |
| PARTIAL_FILLED | Some quantity filled, remainder live | FILLED, CANCELED, UNKNOWN | Execution report | DESIGN_JUDGMENT | §24 | Position updates on each fill. |
| FILLED | Fully executed | CLOSED | Execution report | DESIGN_JUDGMENT | §24 | Terminal state. |
| CANCELED | Canceled by operator or system | CLOSED | Exchange response or local cancel | DESIGN_JUDGMENT | `toobit_fact_pack` §3 | Terminal after reconciliation. |
| REJECTED | Exchange or local rejection | CLOSED | Error response | DESIGN_JUDGMENT | §13 | Terminal after audit. |
| UNKNOWN | State not confirmed | OPEN, PARTIAL_FILLED, FILLED, CANCELED, REJECTED | Timeout, 5XX, missing status | RATIFIED_FINDING | `PROMPT.md` C5; fact pack §4 | No automatic resubmit; reconcile by query. |
| CLOSED | Terminal and audited | None | Audit completion | DESIGN_JUDGMENT | §42 | No further transitions. |

**SM-001 invariants:**

| Invariant | Rule | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| INV-001 | Cumulative filled quantity never exceeds order quantity. | DESIGN_JUDGMENT | E2 | Violation triggers DIVERGED and Live block. |
| INV-002 | Every transition writes an audit event with actor, timestamp, reason, and before/after state. | DESIGN_JUDGMENT | §42 | Missing audit event is a P1 incident. |
| INV-003 | UNKNOWN may not transition directly to CLOSED without reconciliation evidence. | RATIFIED_FINDING | `PROMPT.md` C5 | Prevents duplicate orders. |
| INV-004 | A terminal state cannot return to a non-terminal state. | DESIGN_JUDGMENT | E2 | Violation triggers kill switch. |
| INV-005 | clientOrderId is unique per internal account and order attempt. | DESIGN_JUDGMENT | `toobit_fact_pack` §3 UNRESOLVED uniqueness | Internal uniqueness is enforced regardless of exchange scope. |

### 7.2 Exchange Status Mapping

| Toobit status | Internal state | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| `NEW` | OPEN | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Recognized. |
| `CANCELED` | CANCELED | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Recognized. |
| Any other status | UNKNOWN | UNRESOLVED | `toobit_fact_pack` §3 | Triggers reconcile-by-query; no automatic resubmit. |
| Missing or malformed status | UNKNOWN | DESIGN_JUDGMENT | E3 | Triggers interlock block. |

### 7.3 Risk State Machine SM-002

| State | Meaning | Allowed Next States | Trigger | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|
| NORMAL | All limits within tolerance | WARNING, VETO, DAILY_STOP, KILL_SWITCH | Metric change | DESIGN_JUDGMENT | §18 | New risk allowed. |
| WARNING | One or more soft thresholds breached | NORMAL, VETO, DAILY_STOP, KILL_SWITCH | Metric recovery or deterioration | DESIGN_JUDGMENT | §19 | New risk allowed only with reduced size. |
| VETO | Hard risk limit breached | RECOVERY, KILL_SWITCH | Veto condition cleared or escalated | RATIFIED_FINDING | D-RISK-1, D-RISK-4 | No new risk; reduce-only permitted. |
| DAILY_STOP | Daily realized loss limit breached | RECOVERY | 00:00 UTC or manual 4-eye reset | RATIFIED_FINDING | D-RISK-5 | No new risk until next UTC day. |
| KILL_SWITCH | Operator or automatic kill | RECOVERY | Authorized recovery procedure | RATIFIED_FINDING | D-INTERLOCK-1 | All orders canceled; Live disabled. |
| RECOVERY | Controlled restoration | NORMAL, VETO, KILL_SWITCH | Recovery checks pass or fail | DESIGN_JUDGMENT | §20 | Live remains blocked until all interlocks pass. |

### 7.4 Interlock State Machine SM-003

| Interlock | Pass Condition | Fail Condition | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|
| Data validity | Last tick within freshness threshold; no sequence gap; exchange info snapshot valid. | Stale data, gap, missing snapshot. | RATIFIED_FINDING | D-INTERLOCK-1 | Live order blocked. |
| Reconciliation | Internal positions and open orders match Toobit queries. | Divergence or unknown order. | RATIFIED_FINDING | D-INTERLOCK-1 | Live order blocked. |
| Risk limit | All D-RISK limits satisfied. | Any hard limit breached. | RATIFIED_FINDING | D-RISK-1..6 | Live order blocked. |
| Credential/permission | API key valid, permissions include futures trading, IP allow-list satisfied. | Invalid key, missing permission, auth error. | RATIFIED_FINDING | D-INTERLOCK-1; fact pack §1 | Live order blocked. |
| Config integrity | Running config hash matches approved signed hash. | Hash mismatch or unsigned change. | RATIFIED_FINDING | D-INTERLOCK-1 | Live order blocked. |
| Clock | Local clock within 1,000 ms of Toobit server time. | Skew above 1,000 ms or clock service unavailable. | RATIFIED_FINDING | `toobit_fact_pack` §1 | Live order blocked. |

### 7.5 Telegram Command Preconditions and Veto/Ack State Machine SM-004

| Command | Preconditions | Effect | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|
| `/paper` | Authorized Telegram user; signed command; config integrity PASS; audit service available. | Set mode to PAPER. | RATIFIED_FINDING | D-SELECT-1 | No live order is sent. |
| `/live` | Authorized user; six interlocks PASS; no active KILL_SWITCH; mode currently PAPER or STOPPED. | Set mode to LIVE. | RATIFIED_FINDING | D-SELECT-1, D-INTERLOCK-1 | Live orders may be sent. |
| `/kill` | Authorized user; no additional confirmation required by owner decision. | Activate KILL-L3 or higher as configured. | RATIFIED_FINDING | §20 | All open orders canceled; Live disabled. |
| `/status` | Authorized user. | Return mode, risk state, interlock states, open positions summary. | DESIGN_JUDGMENT | §26 | No state change. |
| `/ack <incident_id>` | Authorized user; incident exists. | Record acknowledgement. | DESIGN_JUDGMENT | §39 | Does not clear incident by itself. |
| Any command from unauthorized user | None | Reject and audit. | DESIGN_JUDGMENT | §34 | No state change. |

Veto/ack rules:

| Rule | Content | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| VETO-01 | A risk veto is active until the underlying metric returns within limit and remains there for one full evaluation cycle. | DESIGN_JUDGMENT | E3 | Prevents flapping. |
| VETO-02 | Acknowledgement never overrides a HARD limit. | RATIFIED_FINDING | D-RISK-1..6 | Only metric recovery or 4-eye manual reset where allowed. |
| VETO-03 | Daily stop reset occurs only at 00:00 UTC or by 4-eye Risk Owner action. | RATIFIED_FINDING | D-RISK-5 | No timezone ambiguity. |
| VETO-04 | Kill-switch recovery requires all six interlocks PASS and explicit operator command. | RATIFIED_FINDING | D-INTERLOCK-1 | No automatic recovery to Live. |

### 7.6 Reconciliation State Machine SM-005

| State | Meaning | Allowed Next States | Trigger | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|
| CLEAN | Internal and exchange state match. | PENDING, DIVERGED | Scheduled check or event | DESIGN_JUDGMENT | §24 | Live allowed if other interlocks pass. |
| PENDING | Reconciliation in progress. | CLEAN, DIVERGED, BLOCKED | Query sent | DESIGN_JUDGMENT | §24 | Live blocked during PENDING. |
| DIVERGED | Mismatch detected. | BLOCKED, CLEAN | Manual or automatic correction | DESIGN_JUDGMENT | §24 | Live blocked. |
| BLOCKED | Unresolved mismatch. | CLEAN | 4-eye resolution | DESIGN_JUDGMENT | §20 | Live disabled. |

### 7.7 Rate-Limit State Machine SM-006

| State | Meaning | Allowed Next States | Trigger | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|
| NORMAL | Under conservative budget. | THROTTLED, BACKOFF | Weight or order count threshold | DESIGN_JUDGMENT | `toobit_fact_pack` §2 | Orders sent normally. |
| THROTTLED | Reducing request rate. | NORMAL, BACKOFF, HALT | Recovery or continued pressure | DESIGN_JUDGMENT | `toobit_fact_pack` §2 | Order rate reduced. |
| BACKOFF | Exponential backoff after 429. | THROTTLED, HALT | Backoff expiry or repeated 429 | SOURCE_VERIFIED | `toobit_fact_pack` §2 | No immediate retry storm. |
| HALT | Rate-limit safety stop. | RECOVERY | Manual or automatic recovery | DESIGN_JUDGMENT | §23 | New orders blocked. |

C4 handling: rate-limit response headers are DOC_CONFLICT. Baseline uses conservative fixed-weight accounting. If headers are observed at runtime, delta accounting may be enabled only after audit.

### 7.8 Failure Behavior Table

| Failure Mode | Detection | System Behavior | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|
| WebSocket disconnect | Heartbeat or socket close | Reconnect with backoff; freshness degrades. | SOURCE_VERIFIED | `toobit_fact_pack` §11 | Live blocked if freshness fails. |
| REST timeout | No response within timeout | Mark UNKNOWN; no resubmit; query order status. | RATIFIED_FINDING | `PROMPT.md` C5 | Prevents duplicate order. |
| 429 rate limit | HTTP 429 or error -1003/-1015 | Enter BACKOFF; reduce rate. | SOURCE_VERIFIED | `toobit_fact_pack` §2 | No retry storm. |
| 5XX internal error | HTTP 5XX | Mark execution status UNKNOWN; reconcile. | SOURCE_VERIFIED | `toobit_fact_pack` §4 | No rejection assumption. |
| Clock skew >1,000 ms | Time check | Clock interlock FAIL; Live blocked. | SOURCE_VERIFIED | `toobit_fact_pack` §1 | Prevents rejected signatures. |
| Config hash mismatch | Config check | Config interlock FAIL; Live blocked. | RATIFIED_FINDING | D-INTERLOCK-1 | Prevents unapproved behavior. |
| Reconciliation divergence | Position/order comparison | Risk state DIVERGED; Live blocked. | DESIGN_JUDGMENT | §24 | Prevents trading on wrong state. |
| Missing exchange-info snapshot | Startup check | Live blocked; Paper observe only. | DESIGN_JUDGMENT | §13 | Prevents invalid order sizing. |

---

## 8. Architecture Decision Records

| ADR | Decision | Rationale | Rejected Options | Consequences | Status | Evidence Pointer |
|---|---|---|---|---|---|---|
| ADR-001 | Use internal order state machine with UNKNOWN as first-class state. | Toobit full status set is UNRESOLVED and timeouts do not prove rejection. | Assume only NEW/CANCELED exist. | Adds reconciliation complexity but prevents duplicate orders. | DESIGN_JUDGMENT | `toobit_fact_pack` §3; `PROMPT.md` C5 |
| ADR-002 | Use conservative fixed-weight rate-limit accounting. | C4 says headers absent in tested environment; docs say present. | Trust response headers as primary. | Lower throughput but safer. | DOC_CONFLICT | `toobit_fact_pack` §2 |
| ADR-003 | Restrict Live execution to Toobit only. | Owner decision. | Multi-exchange live routing. | SOR becomes Toobit-internal execution strategy selection. | RATIFIED_FINDING | Owner instruction §1 |
| ADR-004 | Use single-region multi-AZ cloud with warm DR region. | Balances cost, resilience, and operational simplicity at 200 USDT scale. | Active-active multi-region; on-prem. | Region failure requires DR activation; no colocation latency. | DESIGN_JUDGMENT | §4 |
| ADR-005 | Keep research cross-venue data in a physically isolated zone. | Owner requires no Paper/Live access. | Shared database with row-level security. | Higher infrastructure cost but stronger isolation. | RATIFIED_FINDING | Owner instruction §1 |
| ADR-006 | Treat funding as tail risk, not bounded cost. | Observed caps vary up to ±2%–3%; C7 refutes alleged tight cap. | Model funding as fixed cost. | Risk engine must include funding stress. | PROVISIONAL | `toobit_fact_pack` §6 |
| ADR-007 | Use 0.06% taker fee as conservative default. | C6 conflict between 0.05% documented and 0.06% observed. | Use 0.05% as settled. | Fee sensitivity must include both. | DOC_CONFLICT | `toobit_fact_pack` §7 |
| ADR-008 | Use per-account internal clientOrderId uniqueness with ULID suffix. | Exchange uniqueness scope is UNRESOLVED. | Rely on exchange uniqueness. | Slightly longer IDs but no collision assumption. | DESIGN_JUDGMENT | `toobit_fact_pack` §3 |
| ADR-009 | Use 1,000 klines as conservative request cap. | Fact pack shows 2,000 vs 1,000 conflict. | Assume 2,000. | More requests but avoids rejection. | PROVISIONAL | `toobit_fact_pack` §5 |
| ADR-010 | Use 14 timeframes as C1 ceiling but validate at runtime. | C1 is RATIFIED; WebSocket docs show 11. | Freeze only 11. | Runtime may need REST fallback for missing intervals. | DOC_CONFLICT | `toobit_fact_pack` §5 |
| ADR-011 | Use no waiting period for `/live` after interlocks. | Owner decision. | Add cooling-off period. | Faster activation but requires strict interlock checks. | RATIFIED_FINDING | D-SELECT-1 |
| ADR-012 | Use fail-closed risk engine. | Any uncertainty can cause loss. | Fail-open with alert. | Live blocked on uncertainty; operational burden accepted. | DESIGN_JUDGMENT | §18 |

---

**یادداشت پیشرفت — پایان Part 1/5.** Part 1 شامل چارچوب، تصمیمات HARD، ریاضیات ریسک، مشتق‌گیری دامنه، توپولوژی، فازبندی، معماری و ماشین‌های حالت است. Part 2 قراردادهای API، داده، سازگاری Toobit و حکمرانی داده را پوشش می‌دهد.

---

# Part 2/5 — Contracts, Data, Toobit Compatibility, and Data Governance

**یادداشت پیشرفت — Part 2/5:** قراردادهای API داخلی و خارجی، قراردادهای داده، مشخصات سازگاری Toobit، خط لوله داده، شمای پایگاه داده، حکمرانی داده و مدل داده.

---

## 9. API Contracts

### 9.1 API Conventions

| Convention | Value | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| Transport | HTTPS for REST; WSS for streaming | DESIGN_JUDGMENT | E3 | TLS is mandatory. |
| Authentication | API key + HMAC SHA256 for Toobit; mTLS + signed command for internal control API | SOURCE_VERIFIED for Toobit signing; DESIGN_JUDGMENT internal | `toobit_fact_pack` §1 | No unsigned control command accepted. |
| Timestamp | Milliseconds for Toobit; ISO-8601 UTC for internal APIs | SOURCE_VERIFIED for Toobit | `toobit_fact_pack` §1 | Clock skew >1,000 ms blocks Live. |
| Versioning | URI version for internal API; Toobit path version as documented | DESIGN_JUDGMENT | E3 | Breaking changes require new internal version. |
| Idempotency | Internal command ID plus clientOrderId; Toobit clientOrderId | DESIGN_JUDGMENT | `toobit_fact_pack` §3 | Duplicate submissions are rejected. |
| Error format | JSON object with `code`, `message`, `retryable`, `correlation_id` | DESIGN_JUDGMENT | E3 | All errors are auditable. |
| Rate limiting | Conservative fixed-weight for Toobit; token bucket for internal API | DOC_CONFLICT | `toobit_fact_pack` §2 | Headers are not trusted by default. |

### 9.2 Internal Control API

| API ID | Method | Path | Purpose | Request Body | Response Body | Error Codes | Auth | Rate Limit | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|---|---|---|---|---|
| API-001 | POST | `/v1/mode/paper` | Set PAPER mode | `{command_id, operator_id, signature}` | `{mode, interlocks, audit_id}` | 400, 401, 409, 503 | mTLS + signature | 5/min | DESIGN_JUDGMENT | §26 | Mode change audited. |
| API-002 | POST | `/v1/mode/live` | Set LIVE mode | `{command_id, operator_id, signature}` | `{mode, interlocks, audit_id}` | 400, 401, 403, 409, 503 | mTLS + signature | 5/min | DESIGN_JUDGMENT | §26 | Requires six interlocks PASS. |
| API-003 | POST | `/v1/kill` | Activate kill switch | `{command_id, level, reason, operator_id, signature}` | `{kill_state, audit_id}` | 400, 401, 403, 409 | mTLS + signature | 5/min | DESIGN_JUDGMENT | §20 | Cancels open orders. |
| API-004 | GET | `/v1/status` | Read system status | None | `{mode, risk_state, interlocks, positions_count, pnl_summary}` | 401, 503 | mTLS | 60/min | DESIGN_JUDGMENT | §35 | Read-only. |
| API-005 | POST | `/v1/ack` | Acknowledge incident | `{incident_id, operator_id, note}` | `{acknowledged, audit_id}` | 400, 401, 404 | mTLS | 30/min | DESIGN_JUDGMENT | §39 | Does not clear hard limits. |
| API-006 | GET | `/v1/config/hash` | Read approved config hash | None | `{hash, version, signed_at}` | 401, 503 | mTLS | 60/min | DESIGN_JUDGMENT | §36 | Used by config interlock. |
| API-007 | POST | `/v1/config/propose` | Propose config change | `{diff, operator_id, signature}` | `{proposal_id, status}` | 400, 401, 403 | mTLS + 4-eye | 10/min | DESIGN_JUDGMENT | §36 | Change requires second approver. |
| API-008 | POST | `/v1/config/approve` | Approve config change | `{proposal_id, operator_id, signature}` | `{version, hash}` | 400, 401, 403, 404 | mTLS + 4-eye | 10/min | DESIGN_JUDGMENT | §36 | Two distinct approvers required. |

### 9.3 Internal Order and Risk API

| API ID | Method | Path | Purpose | Request Body | Response Body | Error Codes | Auth | Rate Limit | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|---|---|---|---|---|
| API-020 | POST | `/v1/orders/intent` | Submit order intent | `{intent_id, symbol, side, position_side, type, quantity, price?, stop_distance, strategy_id, client_order_id}` | `{order_id, status, risk_decision}` | 400, 422, 429, 503 | mTLS | 60/min | DESIGN_JUDGMENT | §24 | No exchange call until approved. |
| API-021 | GET | `/v1/orders/{order_id}` | Read order state | None | `{order_id, state, filled_qty, remaining_qty, exchange_status, audit_ref}` | 401, 404 | mTLS | 120/min | DESIGN_JUDGMENT | §24 | Read-only. |
| API-022 | POST | `/v1/orders/{order_id}/cancel` | Request cancel | `{command_id, reason}` | `{state, cancel_request_id}` | 400, 404, 409 | mTLS | 60/min | DESIGN_JUDGMENT | §23 | Cancel request audited. |
| API-023 | POST | `/v1/orders/{order_id}/amend` | Request amend | `{command_id, new_price?, new_quantity?}` | `{state, amend_request_id}` | 400, 404, 409 | mTLS | 30/min | DESIGN_JUDGMENT | §23 | LIMIT only. |
| API-024 | GET | `/v1/risk/state` | Read risk state | None | `{state, metrics, active_vetoes}` | 401 | mTLS | 60/min | DESIGN_JUDGMENT | §18 | Read-only. |
| API-025 | GET | `/v1/risk/limits` | Read limits | None | `{limits, version}` | 401 | mTLS | 60/min | DESIGN_JUDGMENT | §19 | Read-only. |
| API-026 | POST | `/v1/risk/reset-daily` | Manual daily reset | `{command_id, approver_1, approver_2, reason}` | `{state, audit_id}` | 400, 401, 403, 409 | 4-eye | 5/min | DESIGN_JUDGMENT | §19 | Only after UTC day or approved exception. |
| API-027 | POST | `/v1/reconcile/run` | Trigger reconciliation | `{command_id, scope}` | `{run_id, state}` | 400, 409, 503 | mTLS | 10/min | DESIGN_JUDGMENT | §24 | Live blocked during run. |

### 9.4 Toobit Adapter API Endpoints

| API ID | Toobit Endpoint | Method | Purpose | Auth | Weight | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|---|---|
| API-040 | `/api/v1/time` | GET | Server time | None | 1 | SOURCE_VERIFIED | `toobit_fact_pack` §1, §2 | Clock interlock. |
| API-041 | `/api/v1/ping` | GET | Connectivity test | None | 1 | SOURCE_VERIFIED | `toobit_fact_pack` §1, §2 | Health check. |
| API-042 | `/api/v1/exchangeInfo` | GET | Contract specifications | None | 1 | SOURCE_VERIFIED | `toobit_fact_pack` §2, §9 | Universe and filters. |
| API-043 | `/api/v2/futures/order` | POST | Place futures order | Signed | 1 | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Live order. |
| API-044 | `/api/v2/futures/order` | DELETE | Cancel futures order | Signed | 1 | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Cancel by orderId or origClientOrderId. |
| API-045 | `/api/v2/futures/order/update` | POST | Amend LIMIT order | Signed | 2 | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Price/quantity amend only. |
| API-046 | `/api/v2/futures/batch-orders` | POST | Batch place | Signed | 2 | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Batch risk limited. |
| API-047 | `/api/v2/futures/batch-orders` | DELETE | Batch cancel | Signed | 3 | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Batch cancel. |
| API-048 | `/api/v1/futures/positions` | GET | Read positions | Signed | 8.35 | SOURCE_VERIFIED | `toobit_fact_pack` §2 | Reconciliation. |
| API-049 | `/api/v1/futures/fundingRate` | GET | Current funding rate | Signed or public as documented | Not specified | SOURCE_VERIFIED | `toobit_fact_pack` §6 | Funding risk. |
| API-050 | `/api/v1/futures/historyFundingRate` | GET | Historical funding | Signed or public as documented | Not specified | SOURCE_VERIFIED | `toobit_fact_pack` §6 | Funding history. |
| API-051 | `/quote/v1/klines` | GET | Klines | Public | Not specified | SOURCE_VERIFIED | `toobit_fact_pack` §5 | Market data. |
| API-052 | `/quote/v1/depth` | GET | Order book depth | Public | Not specified | SOURCE_VERIFIED | `toobit_fact_pack` §5 | Liquidity and depth. |
| API-053 | `/quote/v1/ticker/24hr` | GET | 24-hour ticker | Public | 40 | SOURCE_VERIFIED | `toobit_fact_pack` §2, §5 | High weight; rate-limited. |

### 9.5 Error Code Contract

| Internal Code | Meaning | Toobit Code Mapping | Retryable | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|
| E-AUTH | Authentication failure | -2015 PROVISIONAL; 401/403 | No | PROVISIONAL | `toobit_fact_pack` §4 | Credential interlock FAIL. |
| E-RATE | Rate limit exceeded | -1003, -1015, 429 | Yes, with backoff | SOURCE_VERIFIED | `toobit_fact_pack` §2 | BACKOFF state. |
| E-UNKNOWN-ORDER | Unknown order | -2011 PROVISIONAL | No automatic resubmit | PROVISIONAL | `toobit_fact_pack` §4 | Reconcile by query. |
| E-TIMEOUT | Timeout | -1007 UNRESOLVED | No automatic resubmit | UNRESOLVED | `PROMPT.md` C5 | Mark UNKNOWN; reconcile. |
| E-SERVER | Internal/server error | 5XX | Yes, after reconcile | SOURCE_VERIFIED | `toobit_fact_pack` §4 | Execution status UNKNOWN. |
| E-VALIDATION | Invalid request | Full catalog UNRESOLVED | No | UNRESOLVED | `toobit_fact_pack` §4 | Reject locally; no exchange resubmit. |
| E-WAF | WAF block | 403 | No | SOURCE_VERIFIED | `toobit_fact_pack` §4 | Security alert. |

Full Toobit negative-code catalog is UNRESOLVED. Resolution path: query the documented error-code page at `api-docs.toobit.com/api/usdt-m-error-codes.html` before implementation. Consequence: any unknown code is mapped to E-UNKNOWN-ORDER with no automatic resubmit.

---

## 10. Data Contracts

### 10.1 DC-001 Market Tick

| Field | Type | Required | Validation | Source | Owner | Retention | Status |
|---|---|---|---|---|---|---|---|
| `symbol` | string | Yes | Must exist in current universe snapshot | Toobit WebSocket | Market Data Owner | 90 days hot, 2 years cold | DESIGN_JUDGMENT |
| `event_time_ms` | integer | Yes | Monotonic per symbol; not more than 1,000 ms future | Toobit | Market Data Owner | Same as above | SOURCE_VERIFIED for timestamp unit |
| `received_time_ms` | integer | Yes | Local receive time | Ingestor | Market Data Owner | Same | DESIGN_JUDGMENT |
| `price` | decimal string | Yes | > 0; tick-size valid | Toobit | Market Data Owner | Same | DESIGN_JUDGMENT |
| `quantity` | decimal string | Yes | ≥ 0 | Toobit | Market Data Owner | Same | DESIGN_JUDGMENT |
| `side` | enum | Conditional | BUY/SELL | Toobit | Market Data Owner | Same | DESIGN_JUDGMENT |
| `sequence` | integer | Conditional | Per-stream monotonic if provided | Toobit | Market Data Owner | Same | UNRESOLVED if absent |

### 10.2 DC-002 Kline

| Field | Type | Required | Validation | Source | Owner | Retention | Status |
|---|---|---|---|---|---|---|---|
| `symbol` | string | Yes | Universe member | Toobit REST/WS | Market Data Owner | 2 years | DESIGN_JUDGMENT |
| `interval` | enum | Yes | One of 14 C1 intervals; runtime availability validated | Toobit | Market Data Owner | 2 years | DOC_CONFLICT C1 vs WS list |
| `open_time_ms` | integer | Yes | Aligns to interval | Toobit | Market Data Owner | 2 years | SOURCE_VERIFIED |
| `open` | decimal string | Yes | > 0 | Toobit | Market Data Owner | 2 years | DESIGN_JUDGMENT |
| `high` | decimal string | Yes | ≥ open, close, low | Toobit | Market Data Owner | 2 years | DESIGN_JUDGMENT |
| `low` | decimal string | Yes | ≤ open, close, high | Toobit | Market Data Owner | 2 years | DESIGN_JUDGMENT |
| `close` | decimal string | Yes | > 0 | Toobit | Market Data Owner | 2 years | DESIGN_JUDGMENT |
| `volume` | decimal string | Yes | ≥ 0 | Toobit | Market Data Owner | 2 years | DESIGN_JUDGMENT |
| `closed` | boolean | Yes | True only after interval close | Ingestor | Market Data Owner | 2 years | DESIGN_JUDGMENT |

Kline request cap is conservatively 1,000 candles per request. 2,000 remains PROVISIONAL until verified.

### 10.3 DC-003 Order Intent

| Field | Type | Required | Validation | Source | Owner | Retention | Status |
|---|---|---|---|---|---|---|---|
| `intent_id` | string | Yes | UUID or ULID | Internal | OMS Owner | 7 years | DESIGN_JUDGMENT |
| `strategy_id` | string | Yes | Registered strategy | Internal | Strategy Owner | 7 years | DESIGN_JUDGMENT |
| `symbol` | string | Yes | Universe member | Internal | OMS Owner | 7 years | DESIGN_JUDGMENT |
| `side` | enum | Yes | BUY/SELL | Internal | OMS Owner | 7 years | DESIGN_JUDGMENT |
| `position_side` | enum | Yes | LONG/SHORT | Internal | OMS Owner | 7 years | SOURCE_VERIFIED field for Toobit |
| `type` | enum | Yes | LIMIT/MARKET | Internal | OMS Owner | 7 years | SOURCE_VERIFIED field for Toobit |
| `quantity` | decimal | Conditional | > 0; step-size valid | Internal | OMS Owner | 7 years | DESIGN_JUDGMENT |
| `value_quantity_usdt` | decimal | Conditional | > 0; mutually allowed with quantity | Internal | OMS Owner | 7 years | SOURCE_VERIFIED for Toobit `valueQuantity` |
| `price` | decimal | Conditional | Required for LIMIT; tick-size valid | Internal | OMS Owner | 7 years | DESIGN_JUDGMENT |
| `stop_distance` | decimal | Yes | > 0; used for risk sizing | Internal | Risk Owner | 7 years | DESIGN_JUDGMENT |
| `time_in_force` | enum | Yes | GTC, IOC, FOK, POST_ONLY | Internal | OMS Owner | 7 years | SOURCE_VERIFIED for Toobit |
| `client_order_id` | string | Yes | `[A-Za-z0-9_-]`; internal uniqueness | Internal | OMS Owner | 7 years | SOURCE_VERIFIED charset; uniqueness UNRESOLVED |
| `created_at_utc` | timestamp | Yes | ISO-8601 UTC | Internal | OMS Owner | 7 years | DESIGN_JUDGMENT |

### 10.4 DC-004 Execution Report

| Field | Type | Required | Validation | Source | Owner | Retention | Status |
|---|---|---|---|---|---|---|---|
| `exec_id` | string | Yes | Unique | Toobit or internal | OMS Owner | 7 years | DESIGN_JUDGMENT |
| `order_id` | string | Yes | Existing order | Internal | OMS Owner | 7 years | DESIGN_JUDGMENT |
| `exchange_order_id` | string | Conditional | Present when acknowledged | Toobit | OMS Owner | 7 years | SOURCE_VERIFIED field |
| `status` | enum | Yes | Mapped per §7.2 | Toobit | OMS Owner | 7 years | UNRESOLVED full set |
| `filled_qty` | decimal | Yes | ≥ 0 | Toobit | OMS Owner | 7 years | SOURCE_VERIFIED field `executedQty` |
| `avg_price` | decimal | Conditional | > 0 when filled | Toobit | OMS Owner | 7 years | SOURCE_VERIFIED field |
| `fee_amount` | decimal | Conditional | ≥ 0 | Toobit or computed | OMS Owner | 7 years | SOURCE_VERIFIED fee rates; actual fee status UNRESOLVED |
| `received_at_utc` | timestamp | Yes | ISO-8601 UTC | Ingestor | OMS Owner | 7 years | DESIGN_JUDGMENT |

### 10.5 DC-005 Position Snapshot

| Field | Type | Required | Validation | Source | Owner | Retention | Status |
|---|---|---|---|---|---|---|---|
| `account_id` | string | Yes | Constant for Live | Internal | Portfolio Owner | 7 years | DESIGN_JUDGMENT |
| `symbol` | string | Yes | Universe member | Internal | Portfolio Owner | 7 years | DESIGN_JUDGMENT |
| `net_qty` | decimal | Yes | Signed | Internal | Portfolio Owner | 7 years | DESIGN_JUDGMENT |
| `entry_price` | decimal | Conditional | > 0 if net_qty ≠ 0 | Internal | Portfolio Owner | 7 years | DESIGN_JUDGMENT |
| `realized_pnl_usdt` | decimal | Yes | Signed | Internal | Portfolio Owner | 7 years | DESIGN_JUDGMENT |
| `unrealized_pnl_usdt` | decimal | Yes | Signed | Internal mark price | Portfolio Owner | 7 years | DESIGN_JUDGMENT |
| `funding_accrued_usdt` | decimal | Yes | Signed | Toobit funding events | Portfolio Owner | 7 years | SOURCE_VERIFIED endpoint; actual accrual computed |
| `snapshot_at_utc` | timestamp | Yes | ISO-8601 UTC | Internal | Portfolio Owner | 7 years | DESIGN_JUDGMENT |

### 10.6 DC-006 Risk Decision

| Field | Type | Required | Validation | Source | Owner | Retention | Status |
|---|---|---|---|---|---|---|---|
| `decision_id` | string | Yes | Unique | Internal | Risk Owner | 7 years | DESIGN_JUDGMENT |
| `order_intent_id` | string | Yes | Existing intent | Internal | Risk Owner | 7 years | DESIGN_JUDGMENT |
| `decision` | enum | Yes | ALLOW/REJECT/REDUCE_ONLY | Internal | Risk Owner | 7 years | DESIGN_JUDGMENT |
| `reason_codes` | array | Yes | Non-empty if REJECT | Internal | Risk Owner | 7 years | DESIGN_JUDGMENT |
| `metrics_snapshot` | object | Yes | Includes equity, open risk, leverage, drawdown, daily loss | Internal | Risk Owner | 7 years | DESIGN_JUDGMENT |
| `decided_at_utc` | timestamp | Yes | ISO-8601 UTC | Internal | Risk Owner | 7 years | DESIGN_JUDGMENT |

### 10.7 DC-007 Audit Event

| Field | Type | Required | Validation | Source | Owner | Retention | Status |
|---|---|---|---|---|---|---|---|
| `audit_id` | string | Yes | Unique | Internal | Audit Owner | 7 years WORM | DESIGN_JUDGMENT |
| `actor_type` | enum | Yes | HUMAN, SERVICE, SYSTEM | Internal | Audit Owner | 7 years | DESIGN_JUDGMENT |
| `actor_id` | string | Yes | Identifies operator or service | Internal | Audit Owner | 7 years | DESIGN_JUDGMENT |
| `action` | string | Yes | Enumerated action | Internal | Audit Owner | 7 years | DESIGN_JUDGMENT |
| `intent` | string | Yes | Human-readable reason | Internal | Audit Owner | 7 years | DESIGN_JUDGMENT |
| `before_state` | object | Conditional | Required for state changes | Internal | Audit Owner | 7 years | DESIGN_JUDGMENT |
| `after_state` | object | Conditional | Required for state changes | Internal | Audit Owner | 7 years | DESIGN_JUDGMENT |
| `result` | enum | Yes | SUCCESS, FAILURE, BLOCKED | Internal | Audit Owner | 7 years | DESIGN_JUDGMENT |
| `correlation_id` | string | Yes | Links related events | Internal | Audit Owner | 7 years | DESIGN_JUDGMENT |

---

## 11. Interface Contracts

| IC ID | Interface | Protocol | Message Structure | Behavioral Guarantee | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|---|
| IC-001 | Internal control API | HTTPS + mTLS | JSON with command envelope | At-least-once command delivery; idempotent by command_id | DESIGN_JUDGMENT | §9.2 | Duplicate commands are ignored. |
| IC-002 | Toobit REST order | HTTPS | Query/body per Toobit v2 order contract | Signed with HMAC SHA256; timestamp ms; recvWindow 5000 ms default | SOURCE_VERIFIED | `toobit_fact_pack` §1, §3 | Signature failure blocks order. |
| IC-003 | Toobit WebSocket | WSS | JSON topics; `ping`/`pong` heartbeat | Client sends ping; server disconnects within 5 min without ping | SOURCE_VERIFIED | `toobit_fact_pack` §11 | Heartbeat is mandatory. |
| IC-004 | Telemetry export | OTLP over gRPC | Spans, metrics, logs | At-most-once acceptable for telemetry; audit is separate | DESIGN_JUDGMENT | §35 | Telemetry loss does not alter trading state. |
| IC-005 | Research export | Object store batch | Parquet/CSV with source tags | No direct network route to Paper/Live | RATIFIED_FINDING | D-CROSSVENUE-1 | Research data cannot enter live path. |
| IC-006 | Internal event bus | At-least-once log | Event envelope with event_id | Consumers idempotent by event_id | DESIGN_JUDGMENT | §14 | Duplicate events do not duplicate effects. |

---

## 12. Toobit Compatibility Specification

### 12.1 Connectivity and Authentication

| Property | Value | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| REST base URL | `https://api.toobit.com` | SOURCE_VERIFIED | `toobit_fact_pack` §1 | Fixed egress target. |
| WebSocket base URL | `wss://stream.toobit.com` | SOURCE_VERIFIED | `toobit_fact_pack` §1 | Fixed stream target. |
| API key header | `X-BB-APIKEY` | SOURCE_VERIFIED | `toobit_fact_pack` §1 | Adapter must use exact header. |
| Signing method | HMAC SHA256 | SOURCE_VERIFIED | `toobit_fact_pack` §1 | No other signing method. |
| Signature case | lowercase hex | SOURCE_VERIFIED | `toobit_fact_pack` §1 | Uppercase hex fails. |
| Timestamp unit | milliseconds | SOURCE_VERIFIED | `toobit_fact_pack` §1 | Seconds fail. |
| recvWindow default | 5,000 ms | SOURCE_VERIFIED | `toobit_fact_pack` §1 | Default unless config overrides. |
| recvWindow max | 60,000 ms | SOURCE_VERIFIED | `toobit_fact_pack` §1 | Values above max rejected. |
| Max future clock skew | 1,000 ms | SOURCE_VERIFIED | `toobit_fact_pack` §1 | Clock interlock threshold. |
| Sandbox/testnet | None wired in CCXT | SOURCE_VERIFIED | `toobit_fact_pack` §1 | Paper mode must simulate locally; no exchange testnet assumed. |
| Official SDK | None published | SOURCE_VERIFIED | `toobit_fact_pack` §1 | Adapter implemented in-house. |

### 12.2 Rate Limits and C4 Handling

| Type | Limit | HTTP on violation | Error Code | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|
| REQUEST_WEIGHT | 3,000 weight per 1 minute | 429 | -1003 | SOURCE_VERIFIED | `toobit_fact_pack` §2 | Conservative budget. |
| ORDERS | 60 order requests per 2 seconds | 429 | -1015 | SOURCE_VERIFIED | `toobit_fact_pack` §2 | Order burst limited. |
| Rate-limit headers | Documented as present; C4 says absent in tested environment | N/A | N/A | DOC_CONFLICT | `toobit_fact_pack` §2 | Baseline uses fixed-weight accounting; headers optional. |
| Conservative safety margin | Use 70% of documented limit | N/A | N/A | DESIGN_JUDGMENT | E3 | Avoids boundary rejection. |

### 12.3 Order Fields and Constraints

| Field | Toobit Requirement | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| `symbol` | Required | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Must be current universe member. |
| `side` | BUY/SELL | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Exact enum. |
| `positionSide` | LONG/SHORT | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Exact enum. |
| `type` | LIMIT/MARKET | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Other types not assumed. |
| `newClientOrderId` | Required for creation | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Charset `[A-Za-z0-9_-]`. |
| `origClientOrderId` | Used for lookup/cancel | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Mutually exclusive with orderId. |
| `quantity` or `valueQuantity` | At least one non-zero | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Value quantity is USDT notional. |
| `timeInForce` | GTC, FOK, IOC, POST_ONLY | SOURCE_VERIFIED | `toobit_fact_pack` §3 | No other values assumed. |
| `price` | Required for LIMIT | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Tick-size validation at runtime. |
| `stopPrice`, `takeProfit`, `stopLoss` | Conditional fields | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Used only when configured. |
| `tpTriggerBy`, `slTriggerBy` | CONTRACT_PRICE or MARK_PRICE | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Explicit selection required. |
| `tpOrderType`, `slOrderType` | MARKET or LIMIT | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Explicit selection required. |
| `stopOrderType` | TAKE_PROFIT/STOP_LOSS | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Conditional order behavior. |
| `stopType` | FIXED_STOP/TRAILING_STOP | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Conditional order behavior. |
| Contract multiplier | `0.001` BTC-SWAP-USDT; `0.01` ETH-SWAP-USDT observed | SOURCE_VERIFIED | `toobit_fact_pack` §9 | Must be fetched per symbol at runtime. |
| Min order/qty step/tick size | Per-symbol via `/api/v1/exchangeInfo` | UNRESOLVED values | `toobit_fact_pack` §9 | Live order validation blocked until fetch. |

### 12.4 Symbol Format

| Market | Format | Example | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|
| Futures v2 | `BASE-SWAP-USDT` | `BTC-SWAP-USDT` | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Adapter must not assume spot format. |
| Spot | `BASEQUOTE` | `BTCUSDT` | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Spot symbols excluded from futures universe. |

### 12.5 WebSocket Streams and Heartbeat

| Topic | Purpose | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| `realtimes` | Real-time price updates | SOURCE_VERIFIED | `toobit_fact_pack` §11 | Market data feed. |
| `trade` | Per-trade stream | SOURCE_VERIFIED | `toobit_fact_pack` §11 | Tick data. |
| `kline_$interval` | Candlestick updates | SOURCE_VERIFIED | `toobit_fact_pack` §11 | Kline updates. |
| `depth` | Order book depth | SOURCE_VERIFIED | `toobit_fact_pack` §11 | Depth and liquidity. |
| `markPrice` | Mark price | SOURCE_VERIFIED | `toobit_fact_pack` §11 | PnL and liquidation risk. |
| `markPriceKline_$interval` | Mark-price candlestick | SOURCE_VERIFIED | `toobit_fact_pack` §11 | Mark-price history. |
| `index` | Index price | SOURCE_VERIFIED | `toobit_fact_pack` §11 | Index reference. |
| `indexKline_$interval` | Index-price candlestick | SOURCE_VERIFIED | `toobit_fact_pack` §11 | Index history. |
| Heartbeat | Client sends `{"ping": timestamp}`; server responds `{"pong": timestamp}` | SOURCE_VERIFIED | `toobit_fact_pack` §11 | No ping for 5 minutes causes disconnect. |

### 12.6 Klines, Timeframes, and C1/C2 Handling

| Item | Value | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| REST kline endpoint | `GET /quote/v1/klines` | SOURCE_VERIFIED | `toobit_fact_pack` §5 | Historical data. |
| Mark-price kline | `GET /quote/v1/markPrice/klines` | SOURCE_VERIFIED | `toobit_fact_pack` §5 | Mark-price history. |
| Index kline | `GET /quote/v1/index/klines` | SOURCE_VERIFIED | `toobit_fact_pack` §5 | Index history. |
| WebSocket intervals observed | 11 intervals | SOURCE_VERIFIED | `toobit_fact_pack` §5 | Runtime may need REST fallback. |
| C1 14-timeframe list | Binding ceiling | RATIFIED_FINDING | `PROMPT.md` C1 | Do not downgrade to 11. |
| Kline return upper limit | 2,000 vs 1,000 | PROVISIONAL | `toobit_fact_pack` §5 | Use 1,000 per request conservatively. |
| C2 historical depth | 3,500 cap; 1,774 daily observed | PROVISIONAL | `PROMPT.md` C2 | Do not assume 3,500 is guaranteed. |

### 12.7 Funding, Fees, Leverage, and Contract Specs

| Item | Value | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| Funding frequency | Every 8 hours standard; some every 4 hours | SOURCE_VERIFIED | `toobit_fact_pack` §6 | Funding risk timing. |
| Funding cap | ±2.0000% to ±3.0000% observed range | PROVISIONAL | `toobit_fact_pack` §6 | Tail risk; not bounded cost. |
| Funding endpoints | `/api/v1/futures/fundingRate`, `/api/v1/futures/historyFundingRate` | SOURCE_VERIFIED | `toobit_fact_pack` §6 | Funding data source. |
| Futures maker fee | 0.02% (2 bps) base VIP0 | SOURCE_VERIFIED | `toobit_fact_pack` §7 | Fee model. |
| Futures taker fee | 0.06% (6 bps) base VIP0 | SOURCE_VERIFIED | `toobit_fact_pack` §7 | Conservative default. |
| Alternative taker fee | 0.05% | UNRESOLVED | `toobit_fact_pack` §7; C6 | Sensitivity required. |
| Spot fee | 0.075% maker, 0.10% taker | SOURCE_VERIFIED | `toobit_fact_pack` §7 | Spot excluded from live futures, but used for context only. |
| BTCUSDT max leverage | Up to 200× tier 1 | SOURCE_VERIFIED | `toobit_fact_pack` §8 | Not used as system leverage; D-RISK-6 caps 5×. |
| Other perpetual max leverage | 50× typical; 75× some | PROVISIONAL | `toobit_fact_pack` §8 | Per-symbol max UNRESOLVED. |
| Risk-limit tiers | `/api/v1/futures/riskLimits` | SOURCE_VERIFIED | `toobit_fact_pack` §8 | Runtime fetch. |
| C3 ladder | 13 tiers down to 1.0× | RATIFIED_FINDING | `PROMPT.md` C3 | Tier info, not system limit. |
| Margin modes | Cross/Isolated standard | PROVISIONAL | `toobit_fact_pack` §9 | Design uses isolated margin by default. |

### 12.8 C13 Mark Price / Klines Change Semantics

C13 is DOC_CONFLICT. The design selects the conservative branch:

| Item | Conservative Rule | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| Mark price use | Use mark price only for risk and liquidation distance; do not use as execution price. | DOC_CONFLICT | `PROMPT.md` C13 | Prevents optimistic PnL. |
| Klines `change` field | Do not rely on `change`; compute change from open and close. | DOC_CONFLICT | `PROMPT.md` C13 | Removes ambiguity. |
| Signal input | Use computed returns from open/close, not vendor change field. | DESIGN_JUDGMENT | E3 | Consistent with C13 conservative branch. |

### 12.9 Toobit Compatibility UNRESOLVED Items

| ID | Item | Status | Resolution Path | Consequence |
|---|---|---|---|---|
| TB-UNR-01 | Full error-code catalog | UNRESOLVED | Fetch documented error-code page before implementation. | Unknown codes map to UNKNOWN and trigger reconciliation. |
| TB-UNR-02 | Per-symbol minQty, stepSize, tickSize, maxLeverage | UNRESOLVED | Fetch `/api/v1/exchangeInfo` and persist hash. | Live order validation blocked until fetch succeeds. |
| TB-UNR-03 | Full order status set | UNRESOLVED | Query order status after any unknown; collect observed statuses. | Non-NEW/CANCELED statuses map to UNKNOWN. |
| TB-UNR-04 | clientOrderId uniqueness scope | UNRESOLVED | Test in paper/live sandbox unavailable; enforce internal uniqueness. | Internal ULID suffix prevents collision. |
| TB-UNR-05 | Rate-limit headers presence in owner environment | DOC_CONFLICT | Runtime probe; if present, optional delta accounting. | Fixed-weight baseline remains default. |
| TB-UNR-06 | Historical kline depth per symbol/timeframe | UNRESOLVED | Runtime query and record actual depth. | Backtest cannot assume 3,500. |
| TB-UNR-07 | Order-book depth reproducibility | UNRESOLVED | Mark depth snapshots with source and timestamp; no exact replay claim. | Depth-based backtest is approximation only. |
| TB-UNR-08 | Historical open interest | UNRESOLVED | No endpoint in fact pack; exclude from v1 risk model. | Open-interest signals are unavailable. |

---

## 13. Data Pipeline

| Stage | Function | Technology | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|
| Ingestion | Receive Toobit WebSocket and REST data | WebSocket client, REST poller | SOURCE_VERIFIED endpoints | `toobit_fact_pack` §1, §11 | Heartbeat and reconnect mandatory. |
| Validation | Check schema, timestamps, sequence, symbol membership | Stream processor | DESIGN_JUDGMENT | §10 | Invalid records quarantined. |
| Cleaning | Deduplicate, sort, fill gaps only by explicit snapshot | Stream processor | DESIGN_JUDGMENT | E3 | No silent gap filling. |
| Enrichment | Add universe version, source tag, receive time | Stream processor | DESIGN_JUDGMENT | E3 | Lineage preserved. |
| Storage hot | Recent ticks, klines, depth | Time-series store | DESIGN_JUDGMENT | §15 | 90-day hot retention design target. |
| Storage cold | Historical klines and ticks | Object store | DESIGN_JUDGMENT | §15 | 2-year cold retention design target. |
| Distribution real-time | Publish to signal engine and risk engine | Event bus | DESIGN_JUDGMENT | IC-006 | At-least-once with idempotent consumers. |
| Distribution historical | Research/backtest zone | Object store batch | RATIFIED_FINDING | D-CROSSVENUE-1 | No Paper/Live access. |

### 13.1 Cross-Venue Research Isolation

| Control | Requirement | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| Network isolation | Research zone has no route to Paper/Live VPC. | RATIFIED_FINDING | D-CROSSVENUE-1 | Prevents data leakage into live decisions. |
| Source tagging | Every research record carries `source_venue`, `source_dataset`, `ingest_time`. | RATIFIED_FINDING | D-CROSSVENUE-1 | Lineage required. |
| Access control | Only research roles can read research zone. | DESIGN_JUDGMENT | §34 | Trading service identities denied. |
| Export control | Any export to trading zone requires offline approval and new dataset ID. | DESIGN_JUDGMENT | E3 | No automated export. |
| Legal responsibility | Owner determines legal/sanctions use. | OUT_OF_SCOPE | Owner instruction §1 | System does not make legal determination. |

---

## 14. Database Schema

### 14.1 Core Tables

```sql
-- PostgreSQL-compatible schema; all timestamps UTC.

CREATE TABLE universe_snapshot (
    universe_version TEXT PRIMARY KEY,
    generated_at_utc TIMESTAMPTZ NOT NULL,
    source_exchange TEXT NOT NULL CHECK (source_exchange = 'TOOBIT'),
    exchange_info_hash TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('COMPLETE','PARTIAL','STALE')),
    payload_json JSONB NOT NULL
);

CREATE TABLE symbol_spec (
    universe_version TEXT REFERENCES universe_snapshot(universe_version),
    symbol TEXT NOT NULL,
    contract_multiplier NUMERIC NOT NULL,
    tick_size NUMERIC NOT NULL,
    step_size NUMERIC NOT NULL,
    min_qty NUMERIC NOT NULL,
    max_leverage_exchange NUMERIC NOT NULL,
    liquidity_score NUMERIC,
    status TEXT NOT NULL,
    PRIMARY KEY (universe_version, symbol)
);

CREATE TABLE order_intent (
    intent_id TEXT PRIMARY KEY,
    strategy_id TEXT NOT NULL,
    symbol TEXT NOT NULL,
    side TEXT NOT NULL CHECK (side IN ('BUY','SELL')),
    position_side TEXT NOT NULL CHECK (position_side IN ('LONG','SHORT')),
    order_type TEXT NOT NULL CHECK (order_type IN ('LIMIT','MARKET')),
    quantity NUMERIC,
    value_quantity_usdt NUMERIC,
    price NUMERIC,
    stop_distance NUMERIC NOT NULL,
    time_in_force TEXT NOT NULL CHECK (time_in_force IN ('GTC','IOC','FOK','POST_ONLY')),
    client_order_id TEXT NOT NULL UNIQUE,
    created_at_utc TIMESTAMPTZ NOT NULL,
    CHECK (quantity IS NOT NULL OR value_quantity_usdt IS NOT NULL)
);

CREATE TABLE risk_decision (
    decision_id TEXT PRIMARY KEY,
    intent_id TEXT REFERENCES order_intent(intent_id),
    decision TEXT NOT NULL CHECK (decision IN ('ALLOW','REJECT','REDUCE_ONLY')),
    reason_codes JSONB NOT NULL,
    metrics_snapshot JSONB NOT NULL,
    decided_at_utc TIMESTAMPTZ NOT NULL
);

CREATE TABLE order_state (
    order_id TEXT PRIMARY KEY,
    intent_id TEXT REFERENCES order_intent(intent_id),
    exchange_order_id TEXT,
    state TEXT NOT NULL,
    exchange_status TEXT,
    filled_qty NUMERIC NOT NULL DEFAULT 0,
    remaining_qty NUMERIC NOT NULL,
    avg_price NUMERIC,
    updated_at_utc TIMESTAMPTZ NOT NULL,
    version INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE execution_report (
    exec_id TEXT PRIMARY KEY,
    order_id TEXT REFERENCES order_state(order_id),
    exchange_order_id TEXT,
    status TEXT NOT NULL,
    last_qty NUMERIC,
    last_price NUMERIC,
    cum_qty NUMERIC,
    fee_amount NUMERIC,
    fee_currency TEXT,
    received_at_utc TIMESTAMPTZ NOT NULL,
    raw_payload JSONB NOT NULL
);

CREATE TABLE position_snapshot (
    snapshot_id BIGSERIAL PRIMARY KEY,
    account_id TEXT NOT NULL,
    symbol TEXT NOT NULL,
    net_qty NUMERIC NOT NULL,
    entry_price NUMERIC,
    realized_pnl_usdt NUMERIC NOT NULL,
    unrealized_pnl_usdt NUMERIC NOT NULL,
    funding_accrued_usdt NUMERIC NOT NULL,
    snapshot_at_utc TIMESTAMPTZ NOT NULL
);

CREATE TABLE risk_limit (
    limit_id TEXT PRIMARY KEY,
    scope TEXT NOT NULL,
    scope_ref TEXT NOT NULL,
    metric TEXT NOT NULL,
    threshold NUMERIC NOT NULL,
    window_name TEXT NOT NULL,
    action TEXT NOT NULL,
    version INTEGER NOT NULL,
    approved_by JSONB NOT NULL,
    effective_from_utc TIMESTAMPTZ NOT NULL
);

CREATE TABLE audit_event (
    audit_id TEXT PRIMARY KEY,
    actor_type TEXT NOT NULL CHECK (actor_type IN ('HUMAN','SERVICE','SYSTEM')),
    actor_id TEXT NOT NULL,
    action TEXT NOT NULL,
    intent TEXT NOT NULL,
    before_state JSONB,
    after_state JSONB,
    result TEXT NOT NULL CHECK (result IN ('SUCCESS','FAILURE','BLOCKED')),
    correlation_id TEXT NOT NULL,
    created_at_utc TIMESTAMPTZ NOT NULL
);

CREATE TABLE research_dataset (
    dataset_id TEXT PRIMARY KEY,
    source_venue TEXT NOT NULL,
    source_dataset TEXT NOT NULL,
    ingest_time_utc TIMESTAMPTZ NOT NULL,
    lineage_hash TEXT NOT NULL,
    storage_uri TEXT NOT NULL
);
```

### 14.2 Indexes and Partitioning

| Table | Index / Partition | Rationale | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|
| `order_state` | Primary key `order_id`; index `(state, updated_at_utc)` | Fast active order lookup | DESIGN_JUDGMENT | E3 | Supports OMS queries. |
| `execution_report` | Index `(order_id, received_at_utc)` | Execution history per order | DESIGN_JUDGMENT | E3 | Reconciliation. |
| `position_snapshot` | Monthly range partition on `snapshot_at_utc` | Retention and query pruning | DESIGN_JUDGMENT | E3 | 7-year retention feasible. |
| `audit_event` | Monthly range partition; WORM export | Audit retention | DESIGN_JUDGMENT | §42 | Immutable trail. |
| `risk_decision` | Index `(intent_id, decided_at_utc)` | Trace decision to order | DESIGN_JUDGMENT | E3 | Auditability. |
| `universe_snapshot` | Primary key and `generated_at_utc` | Versioned universe | DESIGN_JUDGMENT | E3 | Reproducibility. |

### 14.3 Retention Policy

| Data Class | Hot Retention | Cold Retention | WORM | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|
| Orders and executions | 90 days | 7 years | Yes for audit subset | DESIGN_JUDGMENT | §42 | Cannot delete evidence early. |
| Audit events | 30 days queryable | 7 years | Yes | DESIGN_JUDGMENT | §42 | Immutable. |
| Market ticks | 90 days | 2 years | No | DESIGN_JUDGMENT | §13 | Replay limited. |
| Klines | 2 years queryable | 5 years | No | DESIGN_JUDGMENT | §13 | Backtest history. |
| Research data | 1 year | 3 years | No | DESIGN_JUDGMENT | §13 | Isolated. |
| Risk decisions | 90 days | 7 years | Yes | DESIGN_JUDGMENT | §42 | Audit. |

---

## 15. Data Governance

| Governance Area | Rule | Owner | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|
| Ownership | Each data contract has exactly one owner. | Data Owner | DESIGN_JUDGMENT | §10 | No shared ownership ambiguity. |
| Quality | Every dataset has completeness, freshness, and validity metrics. | Data Quality Owner | DESIGN_JUDGMENT | §30 | Stale data blocks Live. |
| Lineage | Every record carries source tag, ingest timestamp, and transformation version. | Data Owner | RATIFIED_FINDING | D-CROSSVENUE-1 | Audit can trace origin. |
| Incomplete data | Missing required field causes quarantine, not silent fill. | Data Owner | DESIGN_JUDGMENT | E3 | No invented values. |
| Conflicting data | Prefer SOURCE_VERIFIED; if unresolved, mark record CONFLICT and exclude from Live decision. | Data Owner | DESIGN_JUDGMENT | E3 | Live blocks on conflict. |
| Cross-venue data | Research only; source-tag lineage mandatory. | Research Owner | RATIFIED_FINDING | D-CROSSVENUE-1 | No Paper/Live access. |
| Deletion | Deletion only per retention policy; audit records WORM. | Compliance Owner | DESIGN_JUDGMENT | §42 | Evidence preserved. |
| Legal/sanctions | Owner responsibility. | Owner | OUT_OF_SCOPE | Owner instruction §1 | System does not determine legality. |

---

## 16. Data Model Entities and Validation Rules

| Entity | Attributes | Validation Rules | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|
| UniverseSnapshot | `universe_version`, `generated_at_utc`, `source_exchange`, `exchange_info_hash`, `status` | Must be TOOBIT; status in COMPLETE/PARTIAL/STALE; hash non-empty. | DESIGN_JUDGMENT | §14.1 | Invalid snapshot blocks Live. |
| SymbolSpec | `symbol`, `contract_multiplier`, `tick_size`, `step_size`, `min_qty`, `max_leverage_exchange` | All numeric > 0; fetched from exchangeInfo. | UNRESOLVED values | `toobit_fact_pack` §9 | Runtime fetch required. |
| OrderIntent | `intent_id`, `strategy_id`, `symbol`, `side`, `position_side`, `type`, `quantity`/`value_quantity_usdt`, `price`, `stop_distance`, `time_in_force`, `client_order_id` | At least one quantity; LIMIT requires price; clientOrderId charset and uniqueness. | DESIGN_JUDGMENT | §10.3 | Invalid intent rejected before risk. |
| RiskDecision | `decision_id`, `intent_id`, `decision`, `reason_codes`, `metrics_snapshot` | REJECT requires non-empty reason codes. | DESIGN_JUDGMENT | §10.6 | Audit complete. |
| OrderState | `order_id`, `intent_id`, `state`, `exchange_status`, `filled_qty`, `remaining_qty`, `version` | State in SM-001; filled_qty + remaining_qty ≤ original quantity. | DESIGN_JUDGMENT | §7.1 | Invariant violation triggers kill. |
| ExecutionReport | `exec_id`, `order_id`, `status`, `last_qty`, `last_price`, `cum_qty` | cum_qty monotonic; last_qty ≥ 0. | DESIGN_JUDGMENT | §10.4 | Reconciliation. |
| PositionSnapshot | `account_id`, `symbol`, `net_qty`, `entry_price`, `realized_pnl_usdt`, `unrealized_pnl_usdt` | net_qty signed; entry_price > 0 if nonzero. | DESIGN_JUDGMENT | §10.5 | PnL source. |
| AuditEvent | `audit_id`, `actor_type`, `actor_id`, `action`, `result` | actor_type in HUMAN/SERVICE/SYSTEM; result in SUCCESS/FAILURE/BLOCKED. | DESIGN_JUDGMENT | §10.7 | Immutable. |

---

**یادداشت پیشرفت — پایان Part 2/5.** Part 2 قراردادهای API، داده، سازگاری Toobit، خط لوله داده، شمای پایگاه داده و حکمرانی داده را پوشش داد. Part 3 ریسک، اجرا، OMS، پرتفوی و عملیات معاملاتی را پوشش می‌دهد.

---

# Part 3/5 — Risk, Execution, OMS, Portfolio, and Trading Operations

**یادداشت پیشرفت — Part 3/5:** موتور ریسک، سیاست‌ها، Kill Switch، مدل‌سازی ریسک، موتور سیگنال، لایه اجرا، OMS، مدیریت پرتفوی و رویه‌های عملیاتی معاملات.

---

## 17. Risk Engine

### 17.1 Risk Check Order

The risk engine evaluates checks in the order below. The first hard failure rejects the order. All checks are executed for audit unless a fail-fast flag is configured; fail-fast still records the first failure and the skipped check list.

| Check ID | Check | Threshold / Rule | Action on Failure | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|
| RISK-001 | Kill-switch state | Any KILL-L1..L5 active | REJECT | RATIFIED_FINDING | §20 | No new risk. |
| RISK-002 | Mode state | Mode must be LIVE or PAPER; live only with six interlocks | REJECT Live | RATIFIED_FINDING | D-INTERLOCK-1 | Paper may still simulate. |
| RISK-003 | Credential/permission interlock | API key valid; futures permission present | REJECT Live | RATIFIED_FINDING | D-INTERLOCK-1 | Live blocked. |
| RISK-004 | Clock interlock | Skew ≤1,000 ms | REJECT Live | SOURCE_VERIFIED | `toobit_fact_pack` §1 | Live blocked. |
| RISK-005 | Data validity interlock | Freshness and sequence valid | REJECT Live | RATIFIED_FINDING | D-INTERLOCK-1 | Live blocked. |
| RISK-006 | Config integrity interlock | Running hash equals approved hash | REJECT Live | RATIFIED_FINDING | D-INTERLOCK-1 | Live blocked. |
| RISK-007 | Reconciliation interlock | State CLEAN | REJECT Live | RATIFIED_FINDING | D-INTERLOCK-1 | Live blocked. |
| RISK-008 | Symbol eligibility | Symbol in current universe snapshot and status active | REJECT | DESIGN_JUDGMENT | §3 | No trade on excluded symbol. |
| RISK-009 | Contract specification present | tickSize, stepSize, minQty valid | REJECT | UNRESOLVED | `toobit_fact_pack` §9 | Live blocked until fetched. |
| RISK-010 | Order field validation | side, positionSide, type, TIF, quantity/price valid | REJECT | DESIGN_JUDGMENT | §12.3 | Invalid request. |
| RISK-011 | Per-trade risk D-RISK-2 | Worst-case loss ≤ 5% current equity | REJECT | RATIFIED_FINDING | D-RISK-2 | No oversized order. |
| RISK-012 | Aggregate concurrent risk D-RISK-4 | Existing open risk + new risk ≤ 15% equity | REJECT | RATIFIED_FINDING | D-RISK-4 | No over-concentration. |
| RISK-013 | Leverage cap D-RISK-6 | Notional ≤ 5× current equity | REJECT | RATIFIED_FINDING | D-RISK-6 | No leverage above cap. |
| RISK-014 | Daily realized loss D-RISK-5 | Realized loss since UTC midnight ≤ 10% equity | VETO until next UTC day | RATIFIED_FINDING | D-RISK-5 | Daily stop. |
| RISK-015 | Maximum drawdown D-RISK-1 | Drawdown ≤ 15% initial equity | VETO | RATIFIED_FINDING | D-RISK-1 | Hard risk stop. |
| RISK-016 | Position limit per symbol | Notional and quantity within configured symbol limit | REJECT | DESIGN_JUDGMENT | §18.2 | Prevents concentration. |
| RISK-017 | Concentration limit | Single symbol notional ≤ 30% of equity (PROVISIONAL) | REJECT | PROVISIONAL | Resolution path §18.2 | Prevents single-symbol dependence. |
| RISK-018 | Funding stress | Estimated funding over holding period within risk budget | REJECT or REDUCE | PROVISIONAL | `toobit_fact_pack` §6 | Funding tail risk. |
| RISK-019 | Liquidity / slippage | Estimated slippage at intended size ≤ configured bps | REJECT or REDUCE | PROVISIONAL | §3.2 | Avoid illiquid symbols. |
| RISK-020 | Rate-limit budget | Remaining conservative budget sufficient | THROTTLE or REJECT | DOC_CONFLICT | `toobit_fact_pack` §2 | Avoid 429. |
| RISK-021 | Self-trade / duplicate | clientOrderId not used; no conflicting open order with same intent | REJECT | DESIGN_JUDGMENT | §7.1 | Prevents duplicate. |
| RISK-022 | Manual veto | Operator veto active | REJECT | DESIGN_JUDGMENT | §26 | Manual control. |

### 17.2 Risk Thresholds and Sensitivity

| Limit | Hard Value | Sensitivity | Status | Rationale | Consequence |
|---|---|---|---|---|---|
| Per-trade risk | 5% current equity | 3%, 5%, 7% for analysis only; 5% is binding | RATIFIED_FINDING | D-RISK-2 | 3% and 7% are not configurable for Live. |
| Aggregate risk | 15% equity | 10%, 15%, 20% for analysis only; 15% binding | RATIFIED_FINDING | D-RISK-4 | 20% not allowed. |
| Daily realized loss | 10% equity | 7%, 10%, 12% analysis only; 10% binding | RATIFIED_FINDING | D-RISK-5 | No override. |
| Maximum drawdown | 15% initial equity | 10%, 15%, 20% analysis; 15% binding | RATIFIED_FINDING | D-RISK-1 | 20% advisory only. |
| Maximum leverage | 5× equity | 2×, 3×, 5× analysis; 5× binding | RATIFIED_FINDING | D-RISK-6 | Exchange max ignored. |
| Single-symbol concentration | 30% equity | 20%, 30%, 40% analysis | PROVISIONAL | E3 | Can be tightened, not loosened above 30% without owner decision. |
| Minimum liquidity score | \(L_{\min}=5.0\) | 4.0, 5.0, 6.0 analysis | PROVISIONAL | §3.2 | Higher threshold may empty universe. |
| Funding stress horizon | 3 funding periods | 1, 3, 7 periods analysis | PROVISIONAL | `toobit_fact_pack` §6 | Longer horizon increases required margin. |

### 17.3 Risk Decision Output

| Output | Meaning | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| ALLOW | All checks pass | DESIGN_JUDGMENT | §17.1 | Order proceeds. |
| REJECT | Hard check failed | DESIGN_JUDGMENT | §17.1 | No order sent. |
| REDUCE_ONLY | New risk forbidden; reduce-only permitted | DESIGN_JUDGMENT | §17.1 | Only closing orders allowed. |
| VETO | Persistent risk state | RATIFIED_FINDING | D-RISK-1, D-RISK-5 | Live blocked until cleared. |

---

## 18. Risk Policies

| Policy ID | Policy | Content | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|
| RP-01 | Position limit | Per-symbol notional ≤ min(30% equity, 5× equity aggregate share) | PROVISIONAL | E3 | Enforced by RISK-016/017. |
| RP-02 | Leverage limit | Effective leverage ≤5× equity | RATIFIED_FINDING | D-RISK-6 | Enforced by RISK-013. |
| RP-03 | Concentration limit | Single-symbol notional ≤30% equity; top-3 symbols ≤60% equity | PROVISIONAL | E3 | Prevents concentration. |
| RP-04 | Daily drawdown alert | At 10% drawdown: WARNING; at 15%: VETO | RATIFIED_FINDING | D-RISK-1 | Alert then hard stop. |
| RP-05 | Daily realized loss | At 10%: DAILY_STOP | RATIFIED_FINDING | D-RISK-5 | No new risk until next UTC day. |
| RP-06 | Funding risk | Apply funding stress over 3 periods; reject if stress loss >2% equity | PROVISIONAL | `toobit_fact_pack` §6 | Tail risk control. |
| RP-07 | Liquidity risk | Reject if estimated slippage for intended size >50 bps | PROVISIONAL | E3 | Avoid illiquid execution. |
| RP-08 | Stale data | Reject Live if last tick older than 2 seconds or kline not closed | DESIGN_JUDGMENT | E3 | Data-validity interlock. |
| RP-09 | Reconciliation | Reject Live if any open order or position mismatch | RATIFIED_FINDING | D-INTERLOCK-1 | Reconciliation interlock. |
| RP-10 | Manual veto | Operator can set reduce-only without kill switch | DESIGN_JUDGMENT | §26 | Allows cautious operation. |

---

## 19. Kill Switch

| Level | Scope | Trigger | Effect | Recovery | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|---|
| KILL-L1 | Strategy | Strategy loss or anomaly | Cancel strategy orders; disable strategy | 4-eye approval | DESIGN_JUDGMENT | §20 | Strategy stops. |
| KILL-L2 | Account | Account loss or repeated rejects | Cancel account orders; disable account Live | 4-eye approval | DESIGN_JUDGMENT | §20 | Account stops. |
| KILL-L3 | Symbol | Symbol anomaly or stale data | Cancel symbol orders; block symbol | Automatic after freshness restore or operator | DESIGN_JUDGMENT | §20 | Symbol blocks. |
| KILL-L4 | Venue/Adapter | Toobit adapter failure | Stop new orders; cancel all open via best effort | 4-eye approval | DESIGN_JUDGMENT | §20 | Live stops. |
| KILL-L5 | Global | Risk breach or operator command | Cancel all; disable Live; reduce-only | 4-eye approval plus operator command | RATIFIED_FINDING | D-INTERLOCK-1 | Full stop. |

Kill-switch testing requirements are design requirements; execution is NOT TESTED in this engagement.

---

## 20. Risk Modeling

| Model | Purpose | Method | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|
| VaR | Estimate potential loss | Historical simulation over lookback window | DESIGN_JUDGMENT | E3 | Not validated; used as warning only. |
| CVaR | Estimate tail loss | Average of losses beyond VaR percentile | DESIGN_JUDGMENT | E3 | Not validated; used as warning. |
| Stress test | Scenario loss | Apply price shocks, funding shocks, liquidity shocks | DESIGN_JUDGMENT | E3 | Hard limits still apply. |
| Scenario analysis | Named scenarios | Flash crash, exchange outage, funding spike | DESIGN_JUDGMENT | E3 | Operational readiness. |
| Liquidity limit | Slippage estimate | Depth-based estimate at intended size | PROVISIONAL | §3.2 | Reject if above threshold. |

No VaR/CVaR model is claimed to be validated or predictive. All model outputs are advisory except the HARD limits in §2.

---

## 21. Signal and Decision Engine

### 21.1 Signal Framework

The system does not assert a profitable strategy. It provides a deterministic framework where strategy parameters are registered, versioned, and tested outside Live. The following components are required:

| Component | Function | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| Feature builder | Compute returns, volatility, volume, spread, funding, depth | DESIGN_JUDGMENT | E3 | Features are reproducible. |
| Signal generator | Apply registered strategy rules to features | DESIGN_JUDGMENT | E3 | Signals are deterministic. |
| Confirmation layer | Require at least two independent confirmations before order intent | DESIGN_JUDGMENT | E3 | Reduces false positives. |
| Regime filter | Block signals in stale, illiquid, or high-funding regimes | DESIGN_JUDGMENT | E3 | Risk-aware. |
| Decision engine | Convert signal plus portfolio state into order intent | DESIGN_JUDGMENT | E3 | Sizing passed to risk engine. |

### 21.2 Entry and Exit Thresholds

| Parameter | Description | Status | Resolution Path | Consequence |
|---|---|---|---|---|
| `entry_threshold` | Minimum signal strength | PROVISIONAL | Calibrate in research; no Live use until frozen | No Live order without accepted value. |
| `exit_threshold` | Signal decay or stop condition | PROVISIONAL | Calibrate in research | No Live exit without accepted value. |
| `confirmation_count` | Minimum independent confirmations | DESIGN_JUDGMENT | E3 | Default 2; lower requires owner approval. |
| `max_holding_period` | Maximum time in position | PROVISIONAL | Research calibration | Prevents indefinite exposure. |

Strategy parameters are stored in a parameter register. No parameter may be changed in Live without a signed config change and 4-eye approval.

---

## 22. Execution Layer

### 22.1 Toobit-Only Execution Strategy Selector

Because Live is Toobit-only, the Smart Order Router is replaced by a **Toobit Execution Strategy Selector**. It chooses among Toobit order types and timing tactics; it does not choose another exchange.

| Strategy | Use Case | Toobit Order Type | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|
| LIMIT_POST_ONLY | Passive entry; maker fee | LIMIT + POST_ONLY | SOURCE_VERIFIED | `toobit_fact_pack` §3 | May not fill. |
| LIMIT_GTC | Normal limit order | LIMIT + GTC | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Standard. |
| LIMIT_IOC | Immediate partial fill | LIMIT + IOC | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Cancels remainder. |
| LIMIT_FOK | All-or-nothing | LIMIT + FOK | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Rejects if not full. |
| MARKET | Urgent exit | MARKET | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Taker fee. |
| STOP_MARKET | Stop-loss | STOP_MARKET conditional | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Conditional order. |
| STOP_LIMIT | Stop with limit | STOP + LIMIT | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Conditional order. |

### 22.2 Cancel, Amend, Retry, and Backoff

| Procedure | Rule | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| Cancel | Cancel by `orderId` or `origClientOrderId`; never both. | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Avoid ambiguity. |
| Amend | LIMIT only; amend price/quantity; not MARKET. | SOURCE_VERIFIED | `toobit_fact_pack` §3 | Market amend rejected. |
| Retry on 429 | Backoff with jitter; no immediate retry. | SOURCE_VERIFIED | `toobit_fact_pack` §2 | Avoid ban. |
| Retry on 5XX | Mark UNKNOWN; reconcile before resubmit. | SOURCE_VERIFIED | `toobit_fact_pack` §4 | Avoid duplicate. |
| Retry on timeout | Mark UNKNOWN; no automatic resubmit. | RATIFIED_FINDING | `PROMPT.md` C5 | Reconciliation required. |
| Batch orders | Use only when independent and risk-approved as batch. | DESIGN_JUDGMENT | E3 | Batch weight 2/3 counted. |

### 22.3 Failure Behavior

| Failure | Behavior | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| Invalid symbol | Reject before API call | DESIGN_JUDGMENT | §17.1 | No wasted weight. |
| Missing contract spec | Block Live | UNRESOLVED | `toobit_fact_pack` §9 | Prevents invalid order. |
| Exchange rejects order | Record reject; no retry unless reason retryable | DESIGN_JUDGMENT | E3 | Audit. |
| Unknown order state | Reconcile by query; Live blocked if unresolved | RATIFIED_FINDING | `PROMPT.md` C5 | Prevents duplicate. |
| Rate limit | BACKOFF; reduce order rate | SOURCE_VERIFIED | `toobit_fact_pack` §2 | Protect API key. |

---

## 23. OMS and Position Management

### 23.1 Order Lifecycle Summary

The detailed state machine is SM-001 in §7.1. The OMS must implement every state and invariant. This section defines operational behavior.

| OMS Function | Rule | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| Order creation | Assign internal `order_id`; require approved risk decision | DESIGN_JUDGMENT | §17 | No unapproved order. |
| Order submission | Persist SUBMITTING before HTTP call | DESIGN_JUDGMENT | E3 | Crash recovery can detect unknown. |
| Execution report ingestion | Idempotent by `exec_id` | DESIGN_JUDGMENT | E3 | No duplicate fill. |
| Position update | Atomic with execution report | DESIGN_JUDGMENT | E3 | No partial state. |
| Cancel | Persist PENDING_CANCEL before API call | DESIGN_JUDGMENT | E3 | Crash recovery can reconcile. |
| Amend | Persist PENDING_AMEND before API call | DESIGN_JUDGMENT | E3 | Crash recovery can reconcile. |
| Reconciliation | Mandatory on startup, after disconnect, and every 60 seconds | RATIFIED_FINDING | D-INTERLOCK-1 | Divergence blocks Live. |
| Unknown handling | Query order status; do not resubmit | RATIFIED_FINDING | `PROMPT.md` C5 | Prevents duplicate. |

### 23.2 Position Calculation

| Component | Formula / Rule | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| Net quantity | Sum of signed fills per symbol | DESIGN_JUDGMENT | E2 | Position source. |
| Entry price | Weighted average of opening fills | DESIGN_JUDGMENT | E2 | PnL. |
| Realized PnL | Sum of closing fills minus fees and funding | DESIGN_JUDGMENT | E2 | Daily loss. |
| Unrealized PnL | (mark price − entry price) × net qty × multiplier | DESIGN_JUDGMENT | E2 | Risk metrics. |
| Fee treatment | Taker 6 bps default; maker 2 bps default | DOC_CONFLICT | `toobit_fact_pack` §7 | Sensitivity required. |
| Funding treatment | Apply funding events at settlement times | SOURCE_VERIFIED | `toobit_fact_pack` §6 | PnL includes funding. |

---

## 24. Portfolio Management

| Function | Rule | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| Capital allocation | Total allocated risk ≤15% equity; per-strategy allocation configurable | RATIFIED_FINDING | D-RISK-4 | No over-allocation. |
| Rebalancing | Only via approved orders; no automatic transfer | DESIGN_JUDGMENT | E3 | Audit. |
| PnL reporting | Realized, unrealized, fees, funding, net | DESIGN_JUDGMENT | E2 | Transparent. |
| Equity calculation | Cash + unrealized PnL | DESIGN_JUDGMENT | E2 | Used for all percentage limits. |
| Drawdown calculation | \(1 - E/E_{\text{peak}}\) | RATIFIED_FINDING | D-RISK-1 | Hard stop. |

All portfolio values are in USDT.

---

## 25. Trading Operations

| Operation | Procedure | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| Daily start | Check UTC time, interlocks, universe snapshot, config hash, reconciliation | DESIGN_JUDGMENT | §27 | Live only if all pass. |
| Daily close | At 00:00 UTC, reset daily realized loss state only if no override; snapshot positions | RATIFIED_FINDING | D-RISK-5 | Daily stop expiry. |
| Funding events | Query funding rate and history; apply accrual; re-evaluate funding stress | SOURCE_VERIFIED | `toobit_fact_pack` §6 | Funding can trigger reduce-only. |
| Perpetual contract events | No expiry; monitor exchange announcements for delisting or contract changes | DESIGN_JUDGMENT | E3 | Delisted symbol removed from universe. |
| Exchange maintenance | Detect REST/WS outage; enter SAFE mode; no new Live orders | DESIGN_JUDGMENT | E3 | Protect state. |
| Emergency stop | Operator `/kill`; cancel all open orders; disable Live | RATIFIED_FINDING | D-INTERLOCK-1 | Immediate stop. |
| Incident acknowledgement | `/ack` records operator acknowledgement; does not clear hard limits | DESIGN_JUDGMENT | §39 | Audit. |
| Mode change | `/paper` or `/live`; `/live` requires six interlocks PASS | RATIFIED_FINDING | D-SELECT-1 | Immediate after checks. |

### 25.1 Procedural Consistency Table

| Procedure | Trigger | Preconditions | Action | Postconditions | Rollback | Consistency Check | Status |
|---|---|---|---|---|---|---|---|
| P-01 Mode to PAPER | `/paper` | Authorized; audit available | Set PAPER; stop Live order egress | Mode=PAPER | `/live` only after interlocks | Mode event in audit | DESIGN_JUDGMENT |
| P-02 Mode to LIVE | `/live` | Six interlocks PASS; no kill | Set LIVE; enable order egress | Mode=LIVE | `/paper` or `/kill` | All six interlock evidence recorded | RATIFIED_FINDING |
| P-03 Kill | `/kill` | Authorized | Cancel all; disable Live | KILL active | 4-eye recovery | Kill event and cancel sweep audit | RATIFIED_FINDING |
| P-04 Reconciliation | Startup, disconnect, 60s timer | None | Query Toobit positions/orders; compare | State CLEAN or DIVERGED | None; block Live on divergence | Diff report stored | DESIGN_JUDGMENT |
| P-05 Daily reset | 00:00 UTC | No manual freeze | Clear DAILY_STOP if conditions met | State NORMAL or prior | 4-eye reset if exception | UTC boundary audit | RATIFIED_FINDING |
| P-06 Config change | Proposal | 4-eye approval | Deploy signed config | New hash active | Rollback to previous signed hash | Hash and approval audit | DESIGN_JUDGMENT |
| P-07 Universe refresh | Scheduled or exchangeInfo change | Market data available | Fetch exchangeInfo; compute universe | New universe version | Previous version retained | Version and exclusion reasons stored | DESIGN_JUDGMENT |
| P-08 Incident ack | `/ack` | Incident exists | Record ack | Incident acknowledged | None | Ack audit | DESIGN_JUDGMENT |

---

**یادداشت پیشرفت — پایان Part 3/5.** Part 3 موتور ریسک، سیاست‌ها، Kill Switch، مدل‌سازی ریسک، سیگنال، اجرا، OMS، پرتفوی و عملیات را پوشش داد. Part 4 تست، NFR، امنیت، استقرار، عملیات، انطباق، وابستگی‌ها و Risk Register را پوشش می‌دهد.

---

# Part 4/5 — Testing, Non-Functional Requirements, Deployment, Operations, Compliance, and Dependencies

**یادداشت پیشرفت — Part 4/5:** برنامه تست، اعتبارسنجی، NFRها، امنیت، Observability، استقرار، Runbookها، BCP/DR، جدول سازگاری رویه‌ای، انطباق، وابستگی‌ها، Risk Register و Production Readiness Gates.

---

## 26. Test Plan

### 26.1 Test Levels

| Test Level | Scope | Entry Criteria | Exit Criteria | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|
| Unit | Functions and state transitions | Code exists | Coverage target met | NOT TESTED | This section | No unit test evidence exists. |
| Integration | Module interactions with mocks | Unit tests pass | Contract tests pass | NOT TESTED | This section | No integration evidence. |
| System | End-to-end paper simulation | Integration tests pass | All critical paths pass | NOT TESTED | This section | No system evidence. |
| Acceptance | Owner acceptance criteria | System tests pass | Sign-off | NOT TESTED | This section | No acceptance evidence. |
| Regression | Re-run after change | Baseline exists | No regression | NOT TESTED | This section | No regression evidence. |
| Load | Throughput and latency under load | System tests pass | Targets met or deviations accepted | NOT TESTED | §31 | No load evidence. |
| Chaos | Failure injection | System tests pass | Recovery behavior verified | NOT TESTED | §40 | No chaos evidence. |

### 26.2 Acceptance Criteria by Component

| Component | Acceptance Criterion | Measurement | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|
| Toobit adapter | Correct HMAC signing and timestamp handling | Test vectors from documented examples if available; otherwise code review | NOT TESTED | `toobit_fact_pack` §1 | No live execution allowed without test. |
| Risk engine | Rejects all HARD limit breaches | Property-based tests and scenario tests | NOT TESTED | §17 | No Live without passing. |
| OMS | No duplicate order under timeout | Fault injection: timeout after send | NOT TESTED | `PROMPT.md` C5 | Critical safety. |
| Reconciliation | Detects mismatch and blocks Live | Simulated divergence | NOT TESTED | §7.6 | Critical safety. |
| Telegram selector | Rejects unauthorized and incomplete interlock | Negative tests | NOT TESTED | §7.5 | Critical safety. |
| Audit | Every state change recorded | Trace audit ID across events | NOT TESTED | §42 | No unlogged change. |

### 26.3 Definition of Done

| Area | Definition of Done | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| Architecture | All ADRs accepted; all diagrams reviewed | DESIGN_ACCEPTED | §8, §6 | Design can proceed to implementation planning. |
| Code | Unit, integration, contract, security tests pass | NOT TESTED | This section | Not achieved. |
| Data | Data contracts validated; lineage present | DESIGN_ACCEPTED | §10, §15 | Runtime validation still required. |
| Risk | All HARD limits enforced and tested | NOT TESTED | §17 | Not achieved. |
| Operations | Runbooks drilled | NOT TESTED | §38 | Not achieved. |
| Compliance | ToS and audit trail controls verified | NOT TESTED | §42 | Not achieved. |

---

## 27. Backtest and Validation Framework

No backtest is executed in this engagement. This section defines the required framework and acceptance criteria for future validation. All statuses are NOT TESTED or PROVISIONAL.

### 27.1 Statistical Trial Budget

| Item | Rule | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| Maximum parameter trials | 200 trials per strategy family before multiple-testing correction | PROVISIONAL | E3 | Exceeding requires new research protocol. |
| Multiple-testing correction | Benjamini-Hochberg at false discovery rate 5% | PROVISIONAL | E3 | Prevents overfitting claim. |
| Minimum out-of-sample length | 30% of total sample | PROVISIONAL | E3 | No Live recommendation without OOS. |
| Walk-forward windows | At least 5 rolling windows | PROVISIONAL | E3 | Stability check. |
| Trial register | Every trial logged with parameters, data range, result | DESIGN_JUDGMENT | E3 | Reproducibility. |

### 27.2 Parameter Register

| Field | Content | Status | Consequence |
|---|---|---|---|
| `parameter_id` | Unique ID | DESIGN_JUDGMENT | Traceability. |
| `strategy_id` | Owning strategy | DESIGN_JUDGMENT | Ownership. |
| `name` | Parameter name | DESIGN_JUDGMENT | Audit. |
| `value` | Frozen value | PROVISIONAL | Live use requires freeze. |
| `range_tested` | Min, max, step | PROVISIONAL | Overfitting check. |
| `trial_count` | Number of trials using this parameter | PROVISIONAL | Multiple-testing budget. |
| `approval` | 4-eye approval | DESIGN_JUDGMENT | Change control. |

### 27.3 Walk-Forward and Leakage Control

| Control | Requirement | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| Time-ordered split | No random split across time | DESIGN_JUDGMENT | E3 | Prevent look-ahead. |
| Purged cross-validation | Remove overlapping labels | DESIGN_JUDGMENT | E3 | Prevent leakage. |
| Embargo period | At least one holding period between train and test | DESIGN_JUDGMENT | E3 | Prevent leakage. |
| Survivorship bias | Use historical universe snapshots | DESIGN_JUDGMENT | E3 | Avoid future symbols. |
| Delisting handling | Mark delisted symbols; no backtest fill after delisting | DESIGN_JUDGMENT | E3 | Realism. |
| Fill model | Conservative queue position and slippage | PROVISIONAL | E3 | No optimistic fills. |

### 27.4 Acceptance Criteria

| Criterion | Threshold | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| Out-of-sample Sharpe | Not asserted | NOT TESTED | This section | No profitability claim. |
| Maximum drawdown in backtest | Must be disclosed, not used as live guarantee | NOT TESTED | This section | No live claim. |
| Parameter stability | Rank correlation across windows >0.5 | PROVISIONAL | E3 | Unstable parameters rejected. |
| Data completeness | ≥95% expected candles | PROVISIONAL | E3 | Incomplete data disclosed. |
| Replay determinism | Identical outputs for identical inputs | DESIGN_JUDGMENT | E3 | Reproducibility. |

---

## 28. Data Quality

| Metric | Definition | Threshold | Action | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|
| Freshness | Time since last valid tick | ≤2 seconds for Live | Block Live if exceeded | DESIGN_JUDGMENT | §17 | Stale data stop. |
| Completeness | Required fields present | 100% | Quarantine record | DESIGN_JUDGMENT | E3 | No missing values. |
| Validity | Price >0; high ≥ low; volume ≥0 | 100% | Reject record | DESIGN_JUDGMENT | E3 | No malformed data. |
| Sequence integrity | No unexplained gap | 0 gaps | Request snapshot; block if unresolved | DESIGN_JUDGMENT | E3 | Data-validity interlock. |
| Duplicate rate | Duplicate event IDs | 0 accepted duplicates | Deduplicate | DESIGN_JUDGMENT | E3 | Idempotency. |
| Symbol coverage | Universe symbols with fresh data | 100% of active universe | Remove stale symbol from active set | DESIGN_JUDGMENT | E3 | No trade on stale symbol. |

---

## 29. Non-Functional Requirements

### 29.1 Performance Targets

| NFR ID | Metric | Target | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|
| NFR-P-01 | Internal order intent to Toobit request | p99 ≤250 ms excluding network | DESIGN_JUDGMENT | E3 | Design target, not measured. |
| NFR-P-02 | Risk engine decision | p99 ≤50 ms | DESIGN_JUDGMENT | E3 | Design target. |
| NFR-P-03 | Market data freshness | ≤2 seconds for Live | DESIGN_JUDGMENT | E3 | Interlock threshold. |
| NFR-P-04 | REST request success rate | ≥99.5% excluding exchange 5XX | DESIGN_JUDGMENT | E3 | Target. |
| NFR-P-05 | Error rate | ≤1% internal errors | DESIGN_JUDGMENT | E3 | Target. |
| NFR-P-06 | Recovery from WebSocket disconnect | ≤5 seconds to reconnect | DESIGN_JUDGMENT | E3 | Target. |

### 29.2 Availability and Resilience Targets

| NFR ID | Target | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| NFR-A-01 | Monthly availability 99.5% for Paper; 99.9% design target for Live control plane | DESIGN_JUDGMENT | E3 | Design target, not measured. |
| NFR-A-02 | RTO for single-AZ failure ≤5 minutes | DESIGN_JUDGMENT | E3 | Design target. |
| NFR-A-03 | RPO for order state = 0 for acknowledged orders | DESIGN_JUDGMENT | E3 | Requires durable write before ack. |
| NFR-A-04 | Reconciliation after restart ≤60 seconds | DESIGN_JUDGMENT | E3 | Design target. |
| NFR-A-05 | Degraded mode: reduce-only when data stale | DESIGN_JUDGMENT | E3 | Safety. |

### 29.3 Scalability

| NFR ID | Requirement | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| NFR-S-01 | Support 10 active symbols at 200 USDT scale | PROVISIONAL | §3.2 | Can be adjusted. |
| NFR-S-02 | Support 100 order intents per minute | DESIGN_JUDGMENT | E3 | Within conservative rate budget. |
| NFR-S-03 | Horizontal scale of stateless API services | DESIGN_JUDGMENT | E3 | Kubernetes HPA design. |
| NFR-S-04 | Vertical scale of database primary | DESIGN_JUDGMENT | E3 | Capacity plan. |

### 29.4 Security Requirements

| NFR ID | Requirement | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| NFR-SEC-01 | All external traffic TLS 1.2+ | DESIGN_JUDGMENT | E3 | Encryption in transit. |
| NFR-SEC-02 | API keys stored in secret manager, never in code | DESIGN_JUDGMENT | E3 | Credential safety. |
| NFR-SEC-03 | Toobit API key IP allow-list | DESIGN_JUDGMENT | E3 | Reduce key misuse. |
| NFR-SEC-04 | Internal service identity via mTLS | DESIGN_JUDGMENT | E3 | Zero-trust. |
| NFR-SEC-05 | Audit log WORM | DESIGN_JUDGMENT | §42 | Tamper evidence. |
| NFR-SEC-06 | Dependency vulnerability scanning | DESIGN_JUDGMENT | E3 | Supply chain. |
| NFR-SEC-07 | Threat model covering spoofing, tampering, replay, DoS | DESIGN_JUDGMENT | §34 | Security review. |

### 29.5 Maintainability and Observability

| NFR ID | Requirement | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| NFR-O-01 | Structured JSON logs with correlation ID | DESIGN_JUDGMENT | E3 | Traceability. |
| NFR-O-02 | Metrics for order count, reject count, latency, risk state | DESIGN_JUDGMENT | E3 | Monitoring. |
| NFR-O-03 | Distributed tracing for order path | DESIGN_JUDGMENT | E3 | Debugging. |
| NFR-O-04 | Alert on interlock failure within 10 seconds | DESIGN_JUDGMENT | E3 | Safety. |
| NFR-O-05 | Dashboard for mode, interlocks, open risk, PnL | DESIGN_JUDGMENT | E3 | Operations. |

---

## 30. Security and Threat Model

| Threat | Description | Control | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|
| Spoofed Telegram command | Unauthorized user sends `/live` | mTLS/signature, authorized user list, audit | DESIGN_JUDGMENT | §7.5 | Command rejected. |
| API key theft | Key exfiltrated | Secret manager, IP allow-list, rotation | DESIGN_JUDGMENT | E3 | Live blocked if suspicious. |
| Replay attack | Replayed signed request | Timestamp/recency check, command_id uniqueness | DESIGN_JUDGMENT | E3 | Reject duplicate. |
| Tampered config | Unsigned config change | Hash check, 4-eye approval | RATIFIED_FINDING | D-INTERLOCK-1 | Live blocked. |
| Data poisoning | Malicious market data | Source validation, sanity bounds | DESIGN_JUDGMENT | E3 | Quarantine and block. |
| DoS on adapter | Flood of orders | Rate limiting, circuit breaker | DESIGN_JUDGMENT | E3 | Backoff. |
| Insider misuse | Operator sends unauthorized order | 4-eye for config; audit; kill switch | DESIGN_JUDGMENT | E3 | Detection and stop. |
| Supply chain compromise | Malicious dependency | Pinned versions, SBOM, scanning | DESIGN_JUDGMENT | E3 | Block release. |

---

## 31. Deployment Plan

| Environment | Purpose | Data | Access | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|
| DEV | Development | Synthetic/mock | Developers | DESIGN_JUDGMENT | E3 | No live keys. |
| STAGING | Integration | Mock or recorded Toobit data | CI/CD | DESIGN_JUDGMENT | E3 | No live orders. |
| PAPER | Simulated execution | Toobit market data; local fill simulation | Operators | DESIGN_JUDGMENT | §26 | No exchange order. |
| LIVE | Real Toobit orders | Toobit production | Authorized operators | DESIGN_JUDGMENT | §25 | Real risk. |

### 31.1 CI/CD Pipeline

| Stage | Action | Gate | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|
| Build | Compile, lint, unit tests | Must pass | NOT TESTED | E3 | No artifact if fail. |
| Security scan | Dependency and container scan | No critical vulnerabilities | NOT TESTED | E3 | Block release. |
| Contract tests | API and data contract tests | Must pass | NOT TESTED | §10 | Block release. |
| Staging deploy | Deploy to staging | Health checks pass | NOT TESTED | E3 | No prod. |
| Paper deploy | Deploy to paper | 24-hour stability target | NOT TESTED | E3 | No live. |
| Live canary | Limited symbols/size | Manual approval | NOT TESTED | E3 | No live. |
| Live full | Full approved scope | Production readiness gates | NOT TESTED | §45 | No live. |

### 31.2 Rollback

| Rollback Type | Trigger | Procedure | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|
| Config rollback | Hash mismatch or operator decision | Revert to prior signed config | DESIGN_JUDGMENT | §36 | Live blocked until verified. |
| Application rollback | Health failure | Deploy prior artifact | DESIGN_JUDGMENT | E3 | Restore service. |
| Kill switch | Risk breach | Cancel all; disable Live | RATIFIED_FINDING | §19 | Immediate stop. |

---

## 32. Infrastructure

| Component | Design | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| Network | Dedicated VPC; private subnets; egress allow-list to Toobit and Telegram | DESIGN_JUDGMENT | §4 | Limits egress. |
| Compute | Containerized services; stateless API; stateful OMS with durable storage | DESIGN_JUDGMENT | E3 | Scalability. |
| Database | PostgreSQL with synchronous replica | DESIGN_JUDGMENT | §14 | RPO target. |
| Time-series | ClickHouse or equivalent for ticks | DESIGN_JUDGMENT | §13 | Hot data. |
| Object store | S3-compatible with WORM for audit | DESIGN_JUDGMENT | §42 | Immutability. |
| Secrets | Secret manager with rotation | DESIGN_JUDGMENT | E3 | Security. |
| External dependencies | Toobit REST/WS; Telegram Bot API | SOURCE_VERIFIED / DESIGN_JUDGMENT | `toobit_fact_pack` §1; §7.5 | No other live exchange. |

---

## 33. Runbooks

| Runbook ID | Scenario | Steps | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|
| RB-01 | Startup | Verify config hash; fetch exchangeInfo; connect WS; reconcile; check six interlocks | DESIGN_JUDGMENT | §25 | Live blocked until pass. |
| RB-02 | Shutdown | Cancel open orders; disable Live; snapshot positions; close connections | DESIGN_JUDGMENT | E3 | Clean stop. |
| RB-03 | WebSocket disconnect | Reconnect with backoff; check freshness; block Live if stale | DESIGN_JUDGMENT | `toobit_fact_pack` §11 | No stale trading. |
| RB-04 | REST 429 | Enter BACKOFF; reduce rate; retry after reset | SOURCE_VERIFIED | `toobit_fact_pack` §2 | Avoid ban. |
| RB-05 | 5XX or timeout | Mark UNKNOWN; query order status; reconcile | RATIFIED_FINDING | `PROMPT.md` C5 | No duplicate. |
| RB-06 | Reconciliation divergence | Block Live; compare positions/orders; resolve with 4-eye; re-run | DESIGN_JUDGMENT | §7.6 | Safety. |
| RB-07 | Clock skew | Check NTP/PTP; block Live if >1,000 ms | SOURCE_VERIFIED | `toobit_fact_pack` §1 | Signature safety. |
| RB-08 | Credential failure | Rotate key; update secret; re-run credential interlock | DESIGN_JUDGMENT | E3 | Restore access. |
| RB-09 | Kill switch activation | Cancel all; disable Live; notify; investigate | RATIFIED_FINDING | §19 | Stop. |
| RB-10 | Daily stop | Block new entries until 00:00 UTC; review losses | RATIFIED_FINDING | D-RISK-5 | Daily risk. |
| RB-11 | Config rollback | Revert to prior signed hash; restart services; verify | DESIGN_JUDGMENT | §36 | Restore known state. |
| RB-12 | DR activation | Promote standby; replay audit; verify reconciliation; enable Live only after gates | DESIGN_JUDGMENT | §40 | Recovery. |

---

## 34. Monitoring and Alerting

| Metric | Threshold | Severity | Action | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|
| Interlock failure | Any FAIL | P1 | Block Live; alert | DESIGN_JUDGMENT | §7.4 | Immediate stop. |
| Stale market data | >2 seconds | P1 | Enter SAFE; alert | DESIGN_JUDGMENT | §28 | No trading. |
| Reconciliation divergence | Any | P1 | Block Live; alert | DESIGN_JUDGMENT | §7.6 | Safety. |
| Clock skew | >1,000 ms | P1 | Block Live; alert | SOURCE_VERIFIED | `toobit_fact_pack` §1 | Safety. |
| Risk veto active | Any | P1 | Alert | RATIFIED_FINDING | §17 | No new risk. |
| Daily stop | Breach | P1 | Alert | RATIFIED_FINDING | D-RISK-5 | Stop. |
| Order reject rate | >10% in 5 minutes | P2 | Alert; review | DESIGN_JUDGMENT | E3 | Potential issue. |
| Rate-limit state | BACKOFF or HALT | P2 | Alert | SOURCE_VERIFIED | `toobit_fact_pack` §2 | Protect API. |
| WebSocket reconnect | >3 in 5 minutes | P2 | Alert | DESIGN_JUDGMENT | E3 | Stability. |
| Audit write failure | Any | P1 | Block Live; alert | DESIGN_JUDGMENT | §42 | No unlogged trading. |

---

## 35. BCP/DR

| Scenario | Impact | Recovery Procedure | RTO Target | RPO Target | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|---|
| AZ failure | Partial outage | Failover to second AZ | ≤5 minutes | 0 for acknowledged orders | DESIGN_JUDGMENT | §29.2 | Design target. |
| Region failure | Full outage | Activate warm standby; replay audit | ≤60 minutes | ≤5 minutes for non-order data; 0 for acknowledged orders if replicated | PROVISIONAL | E3 | Not measured. |
| Database failure | OMS unavailable | Promote replica; reconcile | ≤15 minutes | 0 | DESIGN_JUDGMENT | §14 | Target. |
| Secret manager outage | Cannot sign | Block Live; use cached key if policy permits? | ≤15 minutes | N/A | DESIGN_JUDGMENT | E3 | Safer to block. |
| Toobit outage | Cannot trade | Enter SAFE; no new orders; monitor | Until Toobit recovers | N/A | DESIGN_JUDGMENT | E3 | No workaround. |
| Telegram outage | Cannot change mode | Continue current mode until safe stop | N/A | N/A | DESIGN_JUDGMENT | E3 | Operator must use alternate approved channel; not specified. |

---

## 36. Compliance, Audit, and Governance

### 36.1 Compliance Scope

| Scope | Included | Excluded | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|
| Toobit Terms of Service | Yes | N/A | RATIFIED_FINDING | Owner instruction §1 | Must not violate Toobit ToS. |
| General security | Yes | N/A | DESIGN_JUDGMENT | §30 | Security controls required. |
| Internal audit trail | Yes | N/A | DESIGN_JUDGMENT | §36.2 | Required. |
| Cross-exchange regulatory compliance | No | Yes | OUT_OF_SCOPE | Owner instruction §1 | No claim. |
| Legal/sanctions determination for research data | No | Yes | OUT_OF_SCOPE | Owner instruction §1 | Owner responsibility. |

### 36.2 Audit Trail

| Requirement | Content | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| Immutable audit | WORM storage; append-only | DESIGN_JUDGMENT | §14 | Tamper evidence. |
| Actor identity | Human, service, or system ID | DESIGN_JUDGMENT | §10.7 | Accountability. |
| Intent | Human-readable reason | DESIGN_JUDGMENT | §10.7 | Context. |
| Transaction content | Order fields, risk decision, mode change | DESIGN_JUDGMENT | §10.7 | Reconstruction. |
| Decision result | SUCCESS/FAILURE/BLOCKED | DESIGN_JUDGMENT | §10.7 | Outcome. |
| Retention | 7 years | DESIGN_JUDGMENT | §14.3 | Legal/audit support. |

### 36.3 Data Retention and Evidence

| Data Type | Retention | WORM | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|
| Orders | 7 years | Yes | DESIGN_JUDGMENT | §14.3 | Cannot delete. |
| Executions | 7 years | Yes | DESIGN_JUDGMENT | §14.3 | Cannot delete. |
| Audit events | 7 years | Yes | DESIGN_JUDGMENT | §14.3 | Cannot delete. |
| Market data | 2 years | No | DESIGN_JUDGMENT | §14.3 | Replay limited. |
| Research data | 3 years | No | DESIGN_JUDGMENT | §14.3 | Isolated. |

### 36.4 Internal Reporting

| Report | Frequency | Content | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|
| Daily risk report | Daily | PnL, drawdown, limit usage, incidents | DESIGN_JUDGMENT | E3 | Management oversight. |
| Incident report | Per incident | Timeline, root cause, corrective action | DESIGN_JUDGMENT | §39 | Learning. |
| Configuration change report | Per change | Diff, approvers, hash | DESIGN_JUDGMENT | §36 | Audit. |
| Access review | Quarterly | Authorized users and roles | DESIGN_JUDGMENT | E3 | Security. |

---

## 37. Dependencies

| Dependency ID | Name | Type | Version Policy | License | Replacement Plan | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|---|---|
| DEP-01 | Toobit REST API | External | API v1/v2 as documented | Exchange ToS | No replacement; Live is Toobit-only | SOURCE_VERIFIED | `toobit_fact_pack` §1, §3 | Single venue dependency. |
| DEP-02 | Toobit WebSocket API | External | As documented | Exchange ToS | REST fallback | SOURCE_VERIFIED | `toobit_fact_pack` §11 | Data outage risk. |
| DEP-03 | Telegram Bot API | External | Current stable | Telegram ToS | Alternate operator channel not specified | DESIGN_JUDGMENT | §7.5 | Selector dependency. |
| DEP-04 | PostgreSQL | Internal | 15+ | PostgreSQL License | Managed PostgreSQL or compatible | DESIGN_JUDGMENT | §14 | Data store. |
| DEP-05 | ClickHouse or equivalent | Internal | 23+ | Apache 2.0 | Alternative time-series store | DESIGN_JUDGMENT | §13 | Tick store. |
| DEP-06 | Kubernetes | Internal | 1.28+ | Apache 2.0 | Nominal | DESIGN_JUDGMENT | §31 | Orchestration. |
| DEP-07 | Secret manager | Internal | Current supported | Vendor | Hardware-backed alternative | DESIGN_JUDGMENT | E3 | Key storage. |
| DEP-08 | Object store with WORM | Internal | S3-compatible | Vendor | Alternative WORM archive | DESIGN_JUDGMENT | §14.3 | Audit. |
| DEP-09 | Observability stack | Internal | OpenTelemetry-compatible | Apache 2.0 | Alternative vendor | DESIGN_JUDGMENT | §34 | Monitoring. |

Exact version pinning is an implementation-phase enforcement item; the policy above is binding. No dependency is allowed to auto-update in Live.

---

## 38. Risk Register

| Risk ID | Risk | Probability | Impact | Mitigation | Owner | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|---|---|
| R-01 | Toobit API behavior differs from fact pack | Medium | High | Runtime validation; conservative defaults; reconcilers | Exchange Integration Owner | UNRESOLVED | `toobit_fact_pack` §12 | Live blocked until validated. |
| R-02 | Missing per-symbol filters | High | High | Fetch exchangeInfo at runtime; block Live if absent | Market Data Owner | UNRESOLVED | `toobit_fact_pack` §9 | Cannot size orders. |
| R-03 | Rate-limit header conflict C4 | Medium | Medium | Fixed-weight accounting | Platform Owner | DOC_CONFLICT | `toobit_fact_pack` §2 | Lower throughput. |
| R-04 | Full order status set unknown | High | High | UNKNOWN state; reconcile by query | OMS Owner | UNRESOLVED | `toobit_fact_pack` §3 | Operational overhead. |
| R-05 | Funding tail risk | Medium | High | Funding stress; reduce-only | Risk Owner | PROVISIONAL | `toobit_fact_pack` §6 | Unexpected cost. |
| R-06 | Fee ambiguity C6 | Medium | Medium | Use 6 bps; sensitivity | Finance Owner | DOC_CONFLICT | `toobit_fact_pack` §7 | PnL uncertainty. |
| R-07 | Telegram compromise | Low | High | Authorized user list; signatures; audit | Security Owner | DESIGN_JUDGMENT | §7.5 | Unauthorized mode change. |
| R-08 | Research data leakage | Low | High | Network isolation; source tags | Data Owner | RATIFIED_FINDING | D-CROSSVENUE-1 | Policy violation. |
| R-09 | Implementation not tested | High | High | This package labels NOT TESTED | Program Owner | NOT TESTED | §45 | No production claim. |
| R-10 | Backtest overfitting | High | High | Trial budget; walk-forward; OOS | Research Owner | NOT TESTED | §27 | No strategy claim. |

---

## 39. Production Readiness Gates

| Gate ID | Gate | Required Evidence | Current Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|
| PRG-01 | Design freeze signed | Signed document | NOT TESTED | This package | No implementation. |
| PRG-02 | All HARD limits tested | Test reports | NOT TESTED | §17 | No Live. |
| PRG-03 | Interlocks tested | Test reports | NOT TESTED | §7.4 | No Live. |
| PRG-04 | Reconciliation tested | Fault-injection reports | NOT TESTED | §7.6 | No Live. |
| PRG-05 | Security review passed | Review report | NOT TESTED | §30 | No Live. |
| PRG-06 | Runbooks drilled | Drill records | NOT TESTED | §33 | No Live. |
| PRG-07 | Paper trading completed | Paper report | NOT TESTED | §26 | No Live. |
| PRG-08 | Owner sign-off | Signed approval | NOT TESTED | §1.1 | No Live. |

Implementation, backtest, paper, and live readiness are NOT TESTED / OUT OF SCOPE in this engagement.

---

**یادداشت پیشرفت — پایان Part 4/5.** Part 4 تست، NFR، امنیت، استقرار، عملیات، انطباق، وابستگی‌ها، Risk Register و Production Readiness Gates را پوشش داد. Part 5 Requirements Register، Verification Matrix، Completeness Declaration، V-1..V-12، Artifact Registry و جمع‌بندی فارسی را ارائه می‌کند.

---

# Part 5/5 — Requirements Register, Verification Matrix, Completeness Declaration, V-1..V-12, Artifact Registry, Final Summary

**یادداشت پیشرفت — Part 5/5:** ثبت نیازمندی‌ها، ماتریس راستی‌آزمایی با تعداد ردیف برابر، اعلام کامل‌بودن با محاسبات قابل‌بازتولید، V-1 تا V-12، Artifact Registry و جمع‌بندی کوتاه فارسی.

---

## 40. Requirements Register

The register has exactly 72 requirements. Each row uses the 11 required fields: ID, Requirement, Source, Rationale, Priority, Acceptance Criteria, Verification Method, Owner, Status, Evidence Pointer, Consequence.

| ID | Requirement | Source | Rationale | Priority | Acceptance Criteria | Verification Method | Owner | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|---|---|---|---|---|---|
| REQ-001 | The system shall be Toobit-only for Live execution. | Owner instruction §1 | Prevent cross-exchange live routing. | HARD | No live endpoint except Toobit is configured. | Configuration inspection | Architecture Owner | PASS | §1.1 | Non-Toobit live routing is rejected. |
| REQ-002 | The system shall expose Paper/Live selector via Telegram. | D-SELECT-1 | Owner-approved control path. | HARD | `/paper` and `/live` commands implemented with preconditions. | Command test | Control Owner | PASS | §7.5 | Mode changes are audited. |
| REQ-003 | `/live` shall require six interlocks PASS. | D-INTERLOCK-1 | Safety. | HARD | Any FAIL blocks Live. | Interlock test | Risk Owner | PASS | §7.4 | Live blocked on failure. |
| REQ-004 | `/live` shall have no waiting period and no profit threshold. | D-SELECT-1 | Owner decision. | HARD | Command activates immediately after interlocks. | Command test | Control Owner | PASS | §7.5 | No artificial delay. |
| REQ-005 | Cross-venue data shall be research/backtest only. | D-CROSSVENUE-1 | Isolation. | HARD | No network route to Paper/Live. | Network policy test | Security Owner | PASS | §13.1 | Research data cannot influence Live. |
| REQ-006 | Source-tag lineage shall be mandatory for research data. | D-CROSSVENUE-1 | Auditability. | HARD | Every research record has source fields. | Schema validation | Data Owner | PASS | §15 | Missing lineage rejects record. |
| REQ-007 | The system shall provide an immutable audit trail. | Owner instruction §1 | Accountability. | HARD | Every state change has audit event. | Audit inspection | Audit Owner | PASS | §36.2 | No unlogged trading. |
| REQ-008 | Audit records shall be retained for 7 years in WORM. | §36.3 | Evidence. | HARD | WORM policy configured. | Policy test | Audit Owner | PASS | §14.3 | Deletion blocked. |
| REQ-009 | Configuration changes shall require 4-eye approval. | §36.4 | Prevent unilateral change. | HARD | Two distinct approvers required. | Workflow test | Security Owner | PASS | §9.2 | Change rejected otherwise. |
| REQ-010 | Credentials shall be stored in a secret manager. | §30 | Security. | HARD | No secret in code or env plaintext. | Secret scan | Security Owner | PASS | §30 | Leak risk reduced. |
| REQ-011 | Internal service communication shall use mTLS. | §30 | Zero-trust. | HARD | All service-to-service calls use mTLS. | Network test | Security Owner | PASS | §30 | Unauthenticated call rejected. |
| REQ-012 | The system shall record actor, intent, transaction content, and result for every decision. | §36.2 | Audit completeness. | HARD | Audit schema fields present. | Schema validation | Audit Owner | PASS | §10.7 | Reconstruction possible. |
| REQ-013 | The system shall support at least two availability zones in one region. | §4.2 | AZ fault tolerance. | HARD | Deployment across two AZs. | Infrastructure review | Platform Owner | PASS | §4.2 | AZ failure tolerated. |
| REQ-014 | The system shall have a warm DR region design. | §4.2 | Region resilience. | PROVISIONAL | DR plan documented. | Design review | Platform Owner | PASS | §35 | Region failure has recovery path. |
| REQ-015 | Market data shall be ingested from Toobit WebSocket with heartbeat. | `toobit_fact_pack` §11 | Data freshness. | HARD | Ping every <5 minutes; reconnect on disconnect. | Integration test | Market Data Owner | PASS | §12.5 | No silent stale feed. |
| REQ-016 | Market data shall have REST fallback. | `toobit_fact_pack` §1 | Resilience. | HARD | REST snapshot available when WS fails. | Integration test | Market Data Owner | PASS | §12.1 | Reduced outage impact. |
| REQ-017 | Per-symbol filters shall be fetched from `/api/v1/exchangeInfo` at runtime. | `toobit_fact_pack` §9 | Avoid invented filters. | HARD | Snapshot persisted with hash. | Runtime probe | Market Data Owner | UNRESOLVED | `toobit_fact_pack` §9 | Live blocked until fetch succeeds. |
| REQ-018 | clientOrderId uniqueness shall be enforced internally. | `toobit_fact_pack` §3 | Exchange uniqueness scope unknown. | HARD | Internal uniqueness constraint. | Database test | OMS Owner | UNRESOLVED | `toobit_fact_pack` §3 | Collision prevention. |
| REQ-019 | Full Toobit order status set shall be mapped. | `toobit_fact_pack` §3 | Unknown statuses risk duplicate orders. | HARD | Unknown maps to UNKNOWN; reconcile. | State machine test | OMS Owner | UNRESOLVED | `toobit_fact_pack` §3 | Additional reconciliation. |
| REQ-020 | Full Toobit error-code catalog shall be handled. | `toobit_fact_pack` §4 | Correct failure behavior. | HARD | Unknown codes map to UNKNOWN. | Error handling test | Integration Owner | UNRESOLVED | `toobit_fact_pack` §4 | Conservative handling. |
| REQ-021 | Rate-limit headers shall be treated as DOC_CONFLICT with conservative baseline. | `toobit_fact_pack` §2; C4 | Avoid over-trusting headers. | HARD | Fixed-weight accounting default. | Configuration test | Platform Owner | UNRESOLVED | `toobit_fact_pack` §2 | Lower throughput. |
| REQ-022 | Kline historical depth shall be validated at runtime. | `toobit_fact_pack` §5; C2 | Avoid assuming 3,500. | HARD | Actual depth recorded. | Data audit | Market Data Owner | UNRESOLVED | `toobit_fact_pack` §5 | Backtest range limited. |
| REQ-023 | Maximum drawdown shall be 15% HARD and 20% advisory. | D-RISK-1 | Owner decision. | HARD | Risk state VETO at 15%; alert at 20%. | Risk test | Risk Owner | PASS | §2.1 | Hard stop. |
| REQ-024 | Per-trade risk shall be 5% current equity HARD. | D-RISK-2 | Owner decision. | HARD | Order sizing rejects above 5%. | Risk test | Risk Owner | PASS | §2.1 | No oversized trade. |
| REQ-025 | Aggregate concurrent risk shall be ≤15% equity HARD. | D-RISK-4 | Owner decision. | HARD | New order rejected above 15%. | Risk test | Risk Owner | PASS | §2.1 | No over-concentration. |
| REQ-026 | Daily realized loss stop shall be 10% equity HARD. | D-RISK-5 | Owner decision. | HARD | VETO until next UTC day. | Risk test | Risk Owner | PASS | §2.1 | Daily stop. |
| REQ-027 | Effective leverage shall be capped at 5× equity HARD. | D-RISK-6 | Owner decision. | HARD | Notional ≤5× equity. | Risk test | Risk Owner | PASS | §2.1 | No higher leverage. |
| REQ-028 | The six interlocks shall be non-bypassable. | D-INTERLOCK-1 | Safety. | HARD | No Live order without all PASS. | Interlock test | Risk Owner | PASS | §7.4 | Live blocked. |
| REQ-029 | Reconciliation shall run at startup, on disconnect, and every 60 seconds. | §23.1 | State integrity. | HARD | Timer and event triggers present. | Scheduler inspection | OMS Owner | PASS | §23.1 | Divergence detected. |
| REQ-030 | UNKNOWN order state shall never be treated as rejection. | `PROMPT.md` C5 | Prevent duplicate orders. | HARD | No resubmit until reconciliation. | State test | OMS Owner | PASS | §7.1 | Duplicate prevention. |
| REQ-031 | Funding stress shall be included in risk. | `toobit_fact_pack` §6 | Funding tail risk. | PROVISIONAL | Stress test applied. | Risk test | Risk Owner | PASS | §17.1 | Funding can reduce exposure. |
| REQ-032 | Liquidity/slippage shall be checked before order. | §3.2 | Illiquidity risk. | PROVISIONAL | Reject above 50 bps estimated slippage. | Risk test | Risk Owner | PASS | §17.1 | Avoid illiquid execution. |
| REQ-033 | Signal engine shall require at least two confirmations before order intent. | §21.1 | False positive reduction. | DESIGN_JUDGMENT | Confirmation count ≥2. | Strategy test | Strategy Owner | PASS | §21.1 | Fewer low-quality orders. |
| REQ-034 | Strategy parameters shall be registered and versioned. | §21.2 | Reproducibility. | HARD | Parameter register entry exists. | Registry check | Strategy Owner | PASS | §27.2 | No anonymous parameters. |
| REQ-035 | Toobit Execution Strategy Selector shall not route to another exchange. | §22.1 | Live is Toobit-only. | HARD | No external venue adapter. | Code review | Execution Owner | PASS | §22.1 | No cross-exchange live. |
| REQ-036 | Order amend shall be LIMIT-only. | `toobit_fact_pack` §3 | Exchange constraint. | HARD | MARKET amend rejected locally. | API test | Execution Owner | PASS | §22.2 | Avoid invalid amend. |
| REQ-037 | Cancel shall use orderId or origClientOrderId, never both. | `toobit_fact_pack` §3 | Avoid ambiguity. | HARD | Validation rule present. | API test | Execution Owner | PASS | §22.2 | Deterministic cancel. |
| REQ-038 | Rate-limit backoff shall use jitter and no immediate retry. | `toobit_fact_pack` §2 | Avoid ban. | HARD | BACKOFF state implemented. | Load test | Execution Owner | PASS | §22.2 | Protect API key. |
| REQ-039 | Every order shall have an internal UUID/ULID. | §23.1 | Idempotency and audit. | HARD | Primary key present. | Schema test | OMS Owner | PASS | §14.1 | Traceability. |
| REQ-040 | Position PnL shall include fees and funding. | §23.2 | Accurate PnL. | HARD | Fee and funding fields present. | Calculation test | Portfolio Owner | PASS | §23.2 | No hidden cost. |
| REQ-041 | Portfolio allocation shall not exceed aggregate risk limit. | D-RISK-4 | Risk. | HARD | Allocation rejects above 15% | Risk test | Portfolio Owner | PASS | §24 | No over-allocation. |
| REQ-042 | Daily close shall reset daily loss state only at 00:00 UTC or 4-eye reset. | D-RISK-5 | Time consistency. | HARD | UTC boundary enforced. | Clock test | Operations Owner | PASS | §25 | No ambiguity. |
| REQ-043 | A test plan shall cover unit, integration, system, acceptance, regression, load, and chaos. | §26.1 | Quality. | HARD | All levels defined. | Document review | QA Owner | PASS | §26.1 | Test scope complete. |
| REQ-044 | Backtest shall use walk-forward and leakage controls. | §27.3 | Validity. | HARD | Controls documented. | Design review | Research Owner | NOT TESTED | §27.3 | No backtest executed. |
| REQ-045 | Statistical trial budget shall be recorded. | §27.1 | Overfitting control. | HARD | Trial register exists. | Process audit | Research Owner | NOT TESTED | §27.1 | No results claimed. |
| REQ-046 | Paper trading readiness shall be evidenced. | §26 | Execution proof. | HARD | Paper report exists. | Operational evidence | Program Owner | NOT TESTED | §45 | No paper result. |
| REQ-047 | Live trading readiness shall be evidenced. | §45 | Production proof. | HARD | Live readiness certificate exists. | Operational evidence | Program Owner | NOT TESTED | §45 | No live result. |
| REQ-048 | Data quality metrics shall include freshness, completeness, validity, and sequence integrity. | §28 | Data safety. | HARD | Metrics implemented. | Monitoring review | Data Owner | PASS | §28 | Stale data detected. |
| REQ-049 | Backtest fill model shall be conservative. | §27.3 | Avoid optimistic results. | PROVISIONAL | Queue and slippage model documented. | Design review | Research Owner | PASS | §27.3 | No optimistic claim. |
| REQ-050 | Data replay shall be deterministic for identical inputs. | §27.4 | Reproducibility. | HARD | Same input yields same output. | Replay test | Data Owner | NOT TESTED | §27.4 | Not executed. |
| REQ-051 | Order intent to Toobit request p99 shall be ≤250 ms excluding network. | §29.1 | Performance. | DESIGN_JUDGMENT | Benchmark target. | Performance test | Platform Owner | PASS | §29.1 | Design target only. |
| REQ-052 | Risk decision p99 shall be ≤50 ms. | §29.1 | Performance. | DESIGN_JUDGMENT | Benchmark target. | Performance test | Risk Owner | PASS | §29.1 | Design target only. |
| REQ-053 | Market data freshness shall be ≤2 seconds for Live. | §29.1 | Safety. | HARD | Freshness monitor threshold. | Monitoring test | Market Data Owner | PASS | §29.1 | Live blocks if stale. |
| REQ-054 | Monthly availability target shall be 99.9% for Live control plane. | §29.2 | Resilience. | DESIGN_JUDGMENT | SLO documented. | Monitoring review | Platform Owner | PASS | §29.2 | Design target only. |
| REQ-055 | RTO for single-AZ failure shall be ≤5 minutes. | §29.2 | Recovery. | DESIGN_JUDGMENT | DR plan. | Drill | Platform Owner | PASS | §29.2 | Design target only. |
| REQ-056 | RPO for acknowledged order state shall be 0. | §29.2 | Data safety. | HARD | Synchronous durable write. | Drill | Platform Owner | PASS | §29.2 | Design target only. |
| REQ-057 | All external traffic shall use TLS 1.2+. | §29.4 | Security. | HARD | TLS configuration. | Scan | Security Owner | PASS | §29.4 | Encryption. |
| REQ-058 | API keys shall be IP allow-listed. | §29.4 | Security. | HARD | Toobit key restriction. | Configuration review | Security Owner | PASS | §29.4 | Reduced misuse. |
| REQ-059 | Structured logs shall include correlation ID. | §29.5 | Observability. | HARD | Log schema. | Log inspection | Platform Owner | PASS | §29.5 | Traceability. |
| REQ-060 | Alerts shall fire on interlock failure within 10 seconds. | §29.5 | Safety. | HARD | Alert rule. | Alert test | Operations Owner | PASS | §29.5 | Rapid response. |
| REQ-061 | Deployment shall include DEV, STAGING, PAPER, LIVE environments. | §31 | Separation. | HARD | Environment matrix. | Infrastructure review | Platform Owner | PASS | §31 | No mixed data. |
| REQ-062 | CI/CD shall block release on critical vulnerability. | §31.1 | Security. | HARD | Gate configured. | Pipeline test | Security Owner | PASS | §31.1 | No vulnerable release. |
| REQ-063 | Runbooks shall cover startup, shutdown, recovery, and upgrade. | §33 | Operations. | HARD | RB-01 to RB-12 present. | Document review | Operations Owner | PASS | §33 | Operational readiness design. |
| REQ-064 | BCP/DR shall include AZ, region, database, secret manager, and Toobit outage scenarios. | §35 | Resilience. | HARD | DR scenarios documented. | Design review | Platform Owner | PASS | §35 | Recovery planning. |
| REQ-065 | Audit trail shall record intent and result for every mode change. | §36.2 | Accountability. | HARD | Audit schema. | Audit inspection | Audit Owner | PASS | §36.2 | Traceability. |
| REQ-066 | Compliance scope shall be limited to Toobit ToS, general security, and internal audit. | D-COMPLIANCE-1 | Owner scope. | HARD | No broader claim. | Document review | Compliance Owner | PASS | §36.1 | No regulatory overclaim. |
| REQ-067 | Data retention shall be 7 years for orders, executions, and audit. | §36.3 | Evidence. | HARD | Retention policy. | Policy test | Audit Owner | PASS | §36.3 | Evidence preserved. |
| REQ-068 | Internal reporting shall include daily risk, incident, config change, and access review. | §36.4 | Governance. | HARD | Reports defined. | Process review | Operations Owner | PASS | §36.4 | Oversight. |
| REQ-069 | External dependencies shall have versions, licenses, and replacement plans. | §37 | Supply chain. | HARD | Dependency register. | Document review | Platform Owner | PASS | §37 | No unmanaged dependency. |
| REQ-070 | Risk Register shall include probability, impact, mitigation, and owner. | §38 | Risk governance. | HARD | Register present. | Document review | Program Owner | PASS | §38 | Risks tracked. |
| REQ-071 | Production Readiness Gates shall be defined and not claimed as passed. | §39 | No false readiness. | HARD | Gates listed with NOT TESTED. | Document review | Program Owner | PASS | §39 | No production claim. |
| REQ-072 | Implementation, backtest, paper, and live readiness shall be labelled NOT TESTED / OUT OF SCOPE. | D-READINESS-1 | Honesty. | HARD | Labels present. | Document review | Program Owner | PASS | §45 | No execution claim. |

**Register count:** 72 rows.

---

## 41. Verification Matrix

The Verification Matrix has exactly 72 rows, equal to the Requirements Register. No phantom or missing row exists.

| Verification Row | Requirement ID | Verification Method | Evidence Pointer | Acceptance Result | Status |
|---|---|---|---|---|---|
| VM-01 | REQ-001 | Configuration inspection | §1.1 | Toobit-only live endpoints confirmed in design | PASS |
| VM-02 | REQ-002 | Command test | §7.5 | Telegram selector defined | PASS |
| VM-03 | REQ-003 | Interlock test | §7.4 | Six interlocks defined | PASS |
| VM-04 | REQ-004 | Command test | §7.5 | No waiting period or profit threshold | PASS |
| VM-05 | REQ-005 | Network policy test | §13.1 | Research isolation defined | PASS |
| VM-06 | REQ-006 | Schema validation | §15 | Lineage fields defined | PASS |
| VM-07 | REQ-007 | Audit inspection | §36.2 | Audit schema defined | PASS |
| VM-08 | REQ-008 | Policy test | §14.3 | 7-year WORM policy defined | PASS |
| VM-09 | REQ-009 | Workflow test | §9.2 | 4-eye approval defined | PASS |
| VM-10 | REQ-010 | Secret scan | §30 | Secret manager requirement defined | PASS |
| VM-11 | REQ-011 | Network test | §30 | mTLS requirement defined | PASS |
| VM-12 | REQ-012 | Schema validation | §10.7 | Audit fields defined | PASS |
| VM-13 | REQ-013 | Infrastructure review | §4.2 | Multi-AZ design selected | PASS |
| VM-14 | REQ-014 | Design review | §35 | Warm DR region defined | PASS |
| VM-15 | REQ-015 | Integration test | §12.5 | Heartbeat defined | PASS |
| VM-16 | REQ-016 | Integration test | §12.1 | REST fallback defined | PASS |
| VM-17 | REQ-017 | Runtime probe | `toobit_fact_pack` §9 | Per-symbol filters require runtime fetch | UNRESOLVED |
| VM-18 | REQ-018 | Database test | `toobit_fact_pack` §3 | Internal uniqueness enforcement defined; exchange scope unresolved | UNRESOLVED |
| VM-19 | REQ-019 | State machine test | `toobit_fact_pack` §3 | UNKNOWN state defined; full status set unresolved | UNRESOLVED |
| VM-20 | REQ-020 | Error handling test | `toobit_fact_pack` §4 | Unknown codes map to UNKNOWN; full catalog unresolved | UNRESOLVED |
| VM-21 | REQ-021 | Configuration test | `toobit_fact_pack` §2 | Conservative accounting defined; header presence unresolved | UNRESOLVED |
| VM-22 | REQ-022 | Data audit | `toobit_fact_pack` §5 | Runtime validation defined; historical depth unresolved | UNRESOLVED |
| VM-23 | REQ-023 | Risk test | §2.1 | 15% HARD / 20% advisory defined | PASS |
| VM-24 | REQ-024 | Risk test | §2.1 | 5% per-trade cap defined | PASS |
| VM-25 | REQ-025 | Risk test | §2.1 | 15% aggregate cap defined | PASS |
| VM-26 | REQ-026 | Risk test | §2.1 | 10% daily stop defined | PASS |
| VM-27 | REQ-027 | Risk test | §2.1 | 5× leverage cap defined | PASS |
| VM-28 | REQ-028 | Interlock test | §7.4 | Six interlocks defined | PASS |
| VM-29 | REQ-029 | Scheduler inspection | §23.1 | Reconciliation triggers defined | PASS |
| VM-30 | REQ-030 | State test | §7.1 | UNKNOWN not rejection defined | PASS |
| VM-31 | REQ-031 | Risk test | §17.1 | Funding stress check defined | PASS |
| VM-32 | REQ-032 | Risk test | §17.1 | Liquidity/slippage check defined | PASS |
| VM-33 | REQ-033 | Strategy test | §21.1 | Two-confirmation rule defined | PASS |
| VM-34 | REQ-034 | Registry check | §27.2 | Parameter register defined | PASS |
| VM-35 | REQ-035 | Code review | §22.1 | Toobit-only selector defined | PASS |
| VM-36 | REQ-036 | API test | §22.2 | LIMIT-only amend defined | PASS |
| VM-37 | REQ-037 | API test | §22.2 | Cancel identifier rule defined | PASS |
| VM-38 | REQ-038 | Load test | §22.2 | Backoff with jitter defined | PASS |
| VM-39 | REQ-039 | Schema test | §14.1 | Internal order ID defined | PASS |
| VM-40 | REQ-040 | Calculation test | §23.2 | Fee and funding included | PASS |
| VM-41 | REQ-041 | Risk test | §24 | Allocation limit defined | PASS |
| VM-42 | REQ-042 | Clock test | §25 | UTC reset rule defined | PASS |
| VM-43 | REQ-043 | Document review | §26.1 | Test levels defined | PASS |
| VM-44 | REQ-044 | Design review | §27.3 | Walk-forward and leakage controls defined; not executed | NOT TESTED |
| VM-45 | REQ-045 | Process audit | §27.1 | Trial budget defined; not executed | NOT TESTED |
| VM-46 | REQ-046 | Operational evidence | §45 | Paper readiness not evidenced | NOT TESTED |
| VM-47 | REQ-047 | Operational evidence | §45 | Live readiness not evidenced | NOT TESTED |
| VM-48 | REQ-048 | Monitoring review | §28 | Data quality metrics defined | PASS |
| VM-49 | REQ-049 | Design review | §27.3 | Conservative fill model defined | PASS |
| VM-50 | REQ-050 | Replay test | §27.4 | Determinism requirement defined; not executed | NOT TESTED |
| VM-51 | REQ-051 | Performance test | §29.1 | Target defined; not measured | PASS |
| VM-52 | REQ-052 | Performance test | §29.1 | Target defined; not measured | PASS |
| VM-53 | REQ-053 | Monitoring test | §29.1 | Freshness threshold defined | PASS |
| VM-54 | REQ-054 | Monitoring review | §29.2 | SLO target defined | PASS |
| VM-55 | REQ-055 | Drill | §29.2 | RTO target defined | PASS |
| VM-56 | REQ-056 | Drill | §29.2 | RPO target defined | PASS |
| VM-57 | REQ-057 | Scan | §29.4 | TLS requirement defined | PASS |
| VM-58 | REQ-058 | Configuration review | §29.4 | IP allow-list defined | PASS |
| VM-59 | REQ-059 | Log inspection | §29.5 | Correlation ID defined | PASS |
| VM-60 | REQ-060 | Alert test | §29.5 | Interlock alert defined | PASS |
| VM-61 | REQ-061 | Infrastructure review | §31 | Environment matrix defined | PASS |
| VM-62 | REQ-062 | Pipeline test | §31.1 | Vulnerability gate defined | PASS |
| VM-63 | REQ-063 | Document review | §33 | Runbooks defined | PASS |
| VM-64 | REQ-064 | Design review | §35 | BCP/DR scenarios defined | PASS |
| VM-65 | REQ-065 | Audit inspection | §36.2 | Mode-change audit defined | PASS |
| VM-66 | REQ-066 | Document review | §36.1 | Compliance scope limited | PASS |
| VM-67 | REQ-067 | Policy test | §36.3 | 7-year retention defined | PASS |
| VM-68 | REQ-068 | Process review | §36.4 | Internal reports defined | PASS |
| VM-69 | REQ-069 | Document review | §37 | Dependency register defined | PASS |
| VM-70 | REQ-070 | Document review | §38 | Risk Register defined | PASS |
| VM-71 | REQ-071 | Document review | §39 | Gates defined and marked NOT TESTED | PASS |
| VM-72 | REQ-072 | Document review | §45 | Readiness labels present | PASS |

**Verification Matrix count:** 72 rows. Equal to Requirements Register count of 72. Difference = 0.

---

## 42. Completeness Declaration

### 42.1 Status Count

| Status | Count | Percentage of R=72 |
|---|---:|---:|
| PASS | 60 | 83.33% |
| FAIL | 0 | 0.00% |
| BLOCKED | 0 | 0.00% |
| NOT TESTED | 4 | 5.56% |
| UNRESOLVED | 8 | 11.11% |
| **Total** | **72** | **100.00%** |

Arithmetic walk 1:

\[
60 + 0 + 0 + 4 + 8 = 72
\]

Arithmetic walk 2 by domain:

| Domain | Count |
|---|---:|
| Scope and governance | 6 |
| Architecture and modularity | 8 |
| Data and exchange compatibility | 8 |
| Risk and safety | 10 |
| Strategy, execution, OMS, portfolio | 10 |
| Testing, quality, backtest | 8 |
| NFR, security, observability | 8 |
| Deployment, operations, BCP | 6 |
| Compliance and audit | 4 |
| Dependencies and readiness | 4 |
| **Total** | **72** |

\[
6+8+8+10+10+8+8+6+4+4 = 72
\]

Arithmetic walk 3, register versus verification matrix:

\[
\text{Register rows} = 72,\quad \text{Verification Matrix rows} = 72,\quad 72 - 72 = 0
\]

### 42.2 Omitted and Unrelated Items

| Category | Count | Reason | Status | Consequence |
|---|---:|---|---|---|
| Omitted requirements | 0 | No requirement was removed. | PASS | None. |
| Unrelated requirements | 0 | All registered requirements trace to scope or binding decisions. | PASS | None. |
| Phantom verification rows | 0 | Every verification row maps to a register ID. | PASS | None. |
| Missing verification rows | 0 | All 72 register IDs have a row. | PASS | None. |

### 42.3 Disclosed Labels

| Label | Items | Consequence |
|---|---|---|
| UNRESOLVED | REQ-017, REQ-018, REQ-019, REQ-020, REQ-021, REQ-022, plus fact-pack UNRESOLVED items in §12.9 | Runtime validation or reconciliation required; no invented data. |
| NOT TESTED | REQ-044, REQ-045, REQ-046, REQ-047, plus implementation/backtest/paper/live readiness | No execution evidence; no production claim. |
| PROVISIONAL | Funding cap, fee alternative, kline cap, universe thresholds, concentration limit | Sensitivity required; values are not measured facts. |
| DOC_CONFLICT | C4 rate-limit headers, C6 fee, C13 mark-price/change semantics | Conservative branch selected and enforced. |
| BLOCKED | 0 | No owner-level decision is missing that blocks design freeze. |

---

## 43. Verification Checklist V-1 through V-12

| ID | Verification Item | Evidence Pointer | Status |
|---|---|---|---|
| V-1 | Requirements Register has one row per requirement and 11 fields. | §40 | PASS |
| V-2 | Verification Matrix row count equals Requirements Register row count. | §41, §42.1 | PASS |
| V-3 | Every HARD risk limit D-RISK-1..6 is present and arithmetic is shown. | §2 | PASS |
| V-4 | Toobit fact-pack items are cited with status; no exchange data is invented. | §12, §17, §41 | PASS |
| V-5 | DOC_CONFLICT C4 and C13 use the conservative branch. | §12.2, §12.8 | PASS |
| V-6 | Order lifecycle includes UNKNOWN and reconciliation. | §7.1, §7.2 | PASS |
| V-7 | Telegram selector preconditions and six interlocks are defined. | §7.4, §7.5 | PASS |
| V-8 | Data contracts, database schema, retention, and lineage are defined. | §10, §14, §15 | PASS |
| V-9 | Deployment topology is enumerated and compromise is disclosed. | §4 | PASS |
| V-10 | Test plan, backtest framework, leakage control, and acceptance criteria are defined. | §26, §27 | PASS |
| V-11 | Compliance scope is limited to Toobit ToS, general security, and internal audit. | §36.1 | PASS |
| V-12 | Completeness Declaration includes reproducible arithmetic and disclosed labels. | §42 | PASS |

---

## 44. Artifact Registry

| Artifact ID | Artifact Name | Phase Produced | Message Reference | Status | One-Line Description |
|---|---|---|---|---|---|
| ART-001 | Frozen Design Package | PH-01 | Part 1/5 to Part 5/5 | DELIVERED | This complete document. |
| ART-002 | Document Control and Legend | PH-01 | §0 | DELIVERED | Status, evidence, identifier catalog. |
| ART-003 | Scope and Binding Decisions | PH-01 | §1 | DELIVERED | In-scope, out-of-scope, D-RISK decisions. |
| ART-004 | Capital and Risk Arithmetic | PH-04 | §2 | DELIVERED | USDT calculations and hard limits. |
| ART-005 | Universe Derivation | PH-03 | §3 | DELIVERED | D14 algorithm and UNRESOLVED items. |
| ART-006 | Topology Enumeration | PH-01 | §4 | DELIVERED | TOP-01 to TOP-08 and compromise. |
| ART-007 | Phase Plan | PH-01 | §5 | DELIVERED | PH-01 to PH-08 and deviations. |
| ART-008 | System Architecture | PH-02 | §6 | DELIVERED | Layers, diagram, data flow, modules. |
| ART-009 | Detailed Design and State Machines | PH-02, PH-04 | §7 | DELIVERED | SM-001 to SM-006 and failure behavior. |
| ART-010 | Architecture Decision Records | PH-01 | §8 | DELIVERED | ADR-001 to ADR-012. |
| ART-011 | API Contracts | PH-02 | §9 | DELIVERED | Internal and Toobit API tables. |
| ART-012 | Data Contracts | PH-02 | §10 | DELIVERED | DC-001 to DC-007. |
| ART-013 | Interface Contracts | PH-02 | §11 | DELIVERED | IC-001 to IC-006. |
| ART-014 | Toobit Compatibility Specification | PH-03 | §12 | DELIVERED | Connectivity, limits, order fields, conflicts. |
| ART-015 | Data Pipeline | PH-03 | §13 | DELIVERED | Ingestion, validation, isolation. |
| ART-016 | Database Schema | PH-02 | §14 | DELIVERED | DDL and retention. |
| ART-017 | Data Governance | PH-03 | §15 | DELIVERED | Ownership, quality, lineage. |
| ART-018 | Data Model | PH-03 | §16 | DELIVERED | Entities and validation. |
| ART-019 | Risk Engine | PH-04 | §17 | DELIVERED | RISK-001 to RISK-022. |
| ART-020 | Risk Policies | PH-04 | §18 | DELIVERED | RP-01 to RP-10. |
| ART-021 | Kill Switch Specification | PH-04 | §19 | DELIVERED | KILL-L1 to KILL-L5. |
| ART-022 | Risk Modeling | PH-04 | §20 | DELIVERED | VaR, CVaR, stress, liquidity. |
| ART-023 | Signal and Decision Engine | PH-05 | §21 | DELIVERED | Framework and thresholds. |
| ART-024 | Execution Layer | PH-05 | §22 | DELIVERED | Toobit-only selector and retry rules. |
| ART-025 | OMS and Position Management | PH-05 | §23 | DELIVERED | Lifecycle and position calculation. |
| ART-026 | Portfolio Management | PH-05 | §24 | DELIVERED | Allocation and PnL. |
| ART-027 | Trading Operations | PH-05 | §25 | DELIVERED | Daily, funding, emergency, procedural table. |
| ART-028 | Test Plan | PH-06 | §26 | DELIVERED | Test levels and acceptance. |
| ART-029 | Backtest and Validation Framework | PH-06 | §27 | DELIVERED | Trial budget, walk-forward, leakage. |
| ART-030 | Data Quality | PH-06 | §28 | DELIVERED | Metrics and remediation. |
| ART-031 | Non-Functional Requirements | PH-07 | §29 | DELIVERED | Performance, availability, scalability, security. |
| ART-032 | Security and Threat Model | PH-07 | §30 | DELIVERED | Threats and controls. |
| ART-033 | Deployment Plan | PH-07 | §31 | DELIVERED | Environments and CI/CD. |
| ART-034 | Infrastructure | PH-07 | §32 | DELIVERED | Network, compute, storage. |
| ART-035 | Runbooks | PH-07 | §33 | DELIVERED | RB-01 to RB-12. |
| ART-036 | Monitoring and Alerting | PH-07 | §34 | DELIVERED | Metrics, thresholds, severity. |
| ART-037 | BCP/DR | PH-07 | §35 | DELIVERED | Scenarios and recovery. |
| ART-038 | Compliance, Audit, Governance | PH-07 | §36 | DELIVERED | Scope, audit, retention, reporting. |
| ART-039 | Dependencies | PH-07 | §37 | DELIVERED | External and internal dependencies. |
| ART-040 | Risk Register | PH-07 | §38 | DELIVERED | R-01 to R-10. |
| ART-041 | Production Readiness Gates | PH-08 | §39 | DELIVERED | PRG-01 to PRG-08, NOT TESTED. |
| ART-042 | Requirements Register | PH-01 | §40 | DELIVERED | 72 requirements. |
| ART-043 | Verification Matrix | PH-01 | §41 | DELIVERED | 72 rows. |
| ART-044 | Completeness Declaration | PH-01 | §42 | DELIVERED | Counts and arithmetic. |
| ART-045 | V-1 to V-12 Checklist | PH-01 | §43 | DELIVERED | Verification checklist. |
| ART-046 | Artifact Registry | PH-01 | §44 | DELIVERED | This registry. |

---

## 45. Explicit Statement on Open Items, Labels, and Non-Claims

| Statement | Content | Status | Evidence Pointer | Consequence |
|---|---|---|---|---|
| No implementation claim | No code, binary, deployment, or runtime evidence is included. | NOT TESTED | §39 | Implementation readiness is not established. |
| No backtest claim | No backtest result, Sharpe, return, or profitability claim is made. | NOT TESTED | §27 | No strategy performance is asserted. |
| No paper claim | No paper-trading execution is included. | NOT TESTED | §26 | Paper readiness is not established. |
| No live claim | No live-trading execution is included. | NOT TESTED | §39 | Live readiness is not established. |
| No production-readiness claim | Production gates are defined but not passed. | NOT TESTED | §39 | No production certificate exists. |
| UNRESOLVED items are disclosed | Toobit per-symbol filters, full error codes, full order statuses, rate-limit headers, kline depth, clientOrderId scope, order-book reproducibility, open interest, and deployment region remain UNRESOLVED where applicable. | UNRESOLVED | §12.9, §17, §41 | Runtime validation or owner decision required. |
| DOC_CONFLICT items use conservative branch | C4 rate-limit headers and C13 mark-price/change semantics. | DOC_CONFLICT | §12.2, §12.8 | Conservative behavior enforced. |
| No NO-GO due to UNRESOLVED | The package is frozen with disclosed labels; UNRESOLVED does not by itself constitute NO-GO. | RATIFIED_FINDING | D-FROZEN-1 | Package is issued. |
| BLOCKED count | Zero. | 0 | §42.1 | No owner-level decision blocks freeze. |

---

## 46. Final Persian Summary

این پکیج، طراحی فریزشدهٔ یک سیستم معاملاتی ابری برای فیوچرز پرپچوال USDT-M صرافی Toobit است. تمام داده‌های صرافی فقط از `toobit_fact_pack` گرفته شده و هر ادعای وابسته به Toobit با وضعیت همان آیتم (SOURCE_VERIFIED، PROVISIONAL، UNRESOLVED، DOC_CONFLICT) برچسب خورده است. محدودیت‌های HARD شامل حداکثر افت ۱۵٪، ریسک هر معامله ۵٪، ریسک هم‌زمان ۱۵٪، حد ضرر روزانه ۱۰٪، اهرم مؤثر حداکثر ۵× و مقیاس برنامه‌ریزی ۲۰۰ USDT در سراسر سند اعمال شده‌اند. اجرای Live فقط Toobit است؛ انتخاب Paper/Live از Telegram بدون دوره انتظار و بدون آستانه سود انجام می‌شود؛ شش interlock غیرقابل‌دور زدن‌اند؛ دادهٔ کراس‌ونوم فقط در ناحیهٔ research/backtest ایزوله است؛ و انطباق رگولاتوری فرا-صرافی خارج از دامنه است. موارد UNRESOLVED (مانند فیلترهای هر نماد، کاتالوگ کامل خطاها، مجموعهٔ کامل وضعیت سفارش، هدرهای rate-limit، عمق تاریخی kline، دامنهٔ یکتایی clientOrderId، بازتولیدپذیری depth، Open Interest تاریخی و منطقهٔ استقرار) با مسیر رفع و پیامد افشا شده‌اند. هیچ ادعای سودآوری، آمادگی تولید، یا اجرای implementation/backtest/paper/live وجود ندارد؛ این موارد NOT TESTED / OUT OF SCOPE ثبت شده‌اند. بستهٔ نهایی دارای ۷۲ نیازمندی، ۷۲ ردیف ماتریس راستی‌آزمایی، اعلام کامل‌بودن با محاسبات قابل‌بازتولید، V-1 تا V-12 و Artifact Registry است و به‌عنوان بستهٔ فریزشده صادر می‌شود.