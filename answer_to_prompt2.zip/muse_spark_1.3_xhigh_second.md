# Revised Design Package — Offline Forensic Reassessment and Reconstruction

## Delivery Plan and Part Map

**Closed-world profile:** Arena.ai Direct mode. No internet, no browsing, no remote calls, no account access. All Trade-Only Live facts come from the supplied `PROMPT.md` ratified findings and the embedded `TOOBIT FACT PACK` with statuses preserved.

**Revised delivery in 6 parts:**

* **Rev Part 1/6 — this message:** capability inventory, source perimeter freeze, input integrity, offline pre-review checkpoint, reassessment dependency graph, acronym definitions, incremental registry.
* **Rev Part 2/6:** single canonical Requirements Register with 11 fields, canonical risk-policy catalog for six `D-RISK` hard decisions with interaction analysis.
* **Rev Part 3/6:** clean-sheet reconstruction, candidate strategy architecture with baseline, universe derivation through `D14`, statistical methodology with trial budgets, envelope-first `D15` derivation with topology enumeration.
* **Rev Part 4/6:** integrated architecture: data and lineage firewall, independent risk authority, order management and durability, Telegram sole interface, security, Paper and Live mode semantics, operations and recovery.
* **Rev Part 5/6:** Verification Matrix with one row per requirement, design-only test specifications, three arithmetic walks with units and intermediate steps.
* **Rev Part 6/6:** forensic finding catalog, change-propagation table, `V-1` through `V-12` table, completeness declaration with arithmetic, final Artifact Registry, acceptance-status summary with seven dimensions, limitations, non-delegable next action.

**Length-check method:** no code execution facility is observed in this session. Length is controlled by manual drafting target of fewer than 32,000 characters per part. No automated counter claim is made.

> **Rev Part 1/6 scope:** this message delivers inventory, perimeter, checkpoint, and plan only. It does not select architecture, set risk values beyond restating owner decisions, implement, connect, test against exchange, or authorize trading. All monetary quantities in **USDT**. All time in **UTC**. United States Dollar Tether is abbreviated as USDT on first use here. Coordinated Universal Time is abbreviated as UTC on first use here.

---

## R1.1 Authority and role of inputs

1. **Original `PROMPT.md`:** governing requirements and precedence. The complete file as a local attachment is **not observed** in this session. What is available is the prior conversation content summarizing Sections 0 through 14, constraints `A1` through `A13`, ratified inputs `C1` through `C26`, principles `D11` through `D22`, and prior blueprint Parts 1/6 through 6/6. Reconstruction from that summary is marked as **reconstructed, not file-inspected**.
2. **Previous blueprint:** candidate to be challenged. Available as six prior assistant messages in this conversation. Inspected through conversation context.
3. **Supplemental directive with owner decisions and `TOOBIT FACT PACK`:** available as the current user message. Inspected. Extraction date stated in Fact Pack is 2026-11-02 UTC. Fact Pack is a static snapshot, not a live contract.
4. **General knowledge:** mathematical, statistical, engineering, and domain reasoning may be used. Labeled as general knowledge or explicit reasoning, not as newly verified exchange evidence.

Uniform Resource Locator is abbreviated as URL on first use here. A URL or domain in supplied materials is provenance metadata or a future evidence locator only. No URL was opened or verified in this session.

---

## R1.2 Capability honesty inventory — Direct mode

| Capability | Observed state | Consequence |
|---|---|---|
| Complete original `PROMPT.md` file read | NOT OBSERVED as file | Dependent identifier checks use reconstructed summary; marked accordingly |
| Previous blueprint messages | AVAILABLE in conversation | Full forensic inspection can proceed |
| Supplemental directive and Fact Pack text | AVAILABLE in current message | Usable as supplied evidence |
| Internet, browsing, domain resolution, Hypertext Transfer Protocol calls, WebSocket calls, Application Programming Interface calls, downloads, live data, Telegram access | NOT AVAILABLE IN THIS SESSION and PROHIBITED | External verification step is `BLOCKED`; design work continues offline |
| Local code execution, file creation, persistent volume | NOT OBSERVED | Calculations are reproducible manual derivations; test execution is `NOT TESTED` |
| Independent reviewer, second model call, remote specialist | NOT AVAILABLE IN THIS SESSION | Review passes are internal analytical passes; independence limitation disclosed |
| Multi-message delivery | AVAILABLE | Six-part delivery proceeds |
| Context and output limits | UNKNOWN | Manual 32,000-character target per part |
| User-selectable reasoning control | NOT OBSERVED | No claim about reasoning setting |

No mode change is requested. No credential is requested. No account connection is attempted.

---

## R1.3 Closed-world source perimeter freeze

Permitted project-specific evidence:

* (a) reconstructed original prompt findings with scope and limitations as summarized in session memory;
* (b) prior blueprint messages as candidate artifact;
* (c) owner decisions `D-RISK-1` through `D-RISK-6` and operating constraints in supplemental Section 1;
* (d) `TOOBIT FACT PACK` Sections 1 through 13 with stated statuses.

No outside Toobit-specific fact is added. `SOURCE_VERIFIED` retained from Fact Pack means supplied-source status inside the Fact Pack. It does not mean independent re-verification in this session.

---

## R1.4 Input integrity — missing, partial, conflicting

**Accessible:** prior blueprint, supplemental decisions, Fact Pack tables for base URLs, signing, rate limits, order lifecycle, partial error codes, klines, funding, fees, leverage example, contract multiplier examples, partial symbol list, WebSocket heartbeat.

**Genuinely incomplete or conflicting:**

* Full negative error-code catalog: partial only. Missing codes are `UNRESOLVED`.
* Per-symbol minimum quantity, step size, tick size, maximum leverage table: endpoint existence is `SOURCE_VERIFIED`; values are `UNRESOLVED`.
* Kline return bound: 2000 in one endpoint document against 1000 in another. Status is `PROVISIONAL` conflict. Conservative 1000 governs until verified.
* Rest candle cap 3,500: ratified cap, not guarantee of availability. Shorter return bound also applies per request.
* Timeframe lists: ratified 14-timeframe ceiling includes 3m and 8h. WebSocket extracted list has 11 entries and omits 3m, 4h, 8h. Precedence gives ratified ceiling; WebSocket list is a narrower transport subset. Treated as documented conflict with conservative handling.
* Rate-limit headers: documents state present; ratified finding `C4` states absent in tested environment. Status is documented conflict. Conservative fixed-weight accounting is baseline.
* Fee: 0.06 percent taker is conservative default with `SOURCE_VERIFIED` agreement; 0.05 percent is `UNRESOLVED` sensitivity.
* Funding: observed −30.0000 basis points refutes a 24 basis point universal cap; Fact Pack 2.0000 percent to 3.0000 percent range is `PROVISIONAL` per contract. Funding is tail risk, not bounded cost.
* Leverage: Bitcoin 200 times tier example is `SOURCE_VERIFIED` as an example; altcoin 50 times or 75 times is `PROVISIONAL`; 13-tier ladder is ratified finding. No universal maximum is established. Owner 5 times effective ceiling binds independently.
* Margin modes Cross and Isolated: `PROVISIONAL`, not confirmed in extracted docs.
* Symbol list of about 31 families: `PROVISIONAL` partial list, not universe.
* Order-book depth reproducibility: `NON_REPRODUCIBLE` per ratified finding.
* Mark price and klines change semantics: `CONFLICTED`.
* Historical open interest: `UNRESOLVED`.
* Client order identity uniqueness scope: `UNRESOLVED`.
* Outage tolerance 3-day value: `PROVISIONAL`; class definition undefined.
* Reference handset sustained runtime, thermal, background survival: `NOT MEASURED`.

Where a required input is unavailable, dependent verification is marked `BLOCKED` or `NOT TESTED`, the fact is marked `UNRESOLVED` or `PROVISIONAL`, safe interim behavior is fail-closed or disabled, and independent work continues.

---

## R1.5 Offline pre-review checkpoint — substitute for pre-external-research checkpoint

This checkpoint explicitly substitutes for the original pre-external-research checkpoint because new external research is prohibited. No external source was inspected.

| Check | Evidence | Disposition |
|---|---|---|
| Requirements basis sufficient to reconstruct register | `A1`–`A13` summary, `C1`–`C26` summary, six `D-RISK` decisions, Fact Pack | PROCEED to Rev Part 2/6 register |
| Evidence precedence understood | Original Section 2 precedence; ratified finding wins; documented conflict uses conservative branch | CONFIRMED |
| Prior blueprint available for hostile review | Six prior messages | PROCEED to forensic Pass D |
| Quantitative design possible offline | Formulas, weights, fees, storage unit, risk limits supplied | PROCEED with manual arithmetic |
| Exchange-dependent claims containable | `UNRESOLVED` and `PROVISIONAL` handling with disabled or fail-closed branches defined | PROCEED with containment |
| Architecture selection justified now | Not justified before register and clean-sheet baseline | DEFERRED to Rev Part 3/6 and Rev Part 4/6 |
| Implementation, backtest execution, Paper operation, Live authorization | Outside engagement | EXCLUDED; test execution `NOT TESTED` |

**Checkpoint verdict:** PROCEED with reconstruction. No architecture is selected in Rev Part 1/6. No risk limit is varied. No missing fact is invented.

Precedence applied in this reassessment:

* Ratified 14-timeframe ceiling and 3,500 cap stand within stated scope.
* WebSocket 11-interval list does not reduce the ceiling.
* Conservative 1,000-kline response bound governs pagination design.
* Conservative fixed-weight rate accounting governs; header deltas are optional enhancement only if observed.
* Conservative 0.06 percent taker governs cost acceptance.
* Funding has no guaranteed bound.
* No universal exchange leverage is inferred.
* Cross-venue data is research and historical backtest only, architecturally isolated from Paper and Live.

---

## R1.6 Reassessment dependency graph

Passes from supplemental Section 5 are ordered by dependency, not by listed letter order alone.

```
Pass A input integrity -> Pass B requirements register
Pass A -> Pass C clean-sheet baseline
Pass B -> Pass C
Pass B + Pass C -> Pass D forensic audit of prior blueprint
Pass D -> Pass E full-domain omission audit
Pass B + Pass C + Pass D + Pass E -> Pass F correction and reconstruction
Pass F -> Pass G adversarial red-team on revised design
Pass G -> Pass H regression and coherence verification
Pass H -> Verification Matrix + V-1 through V-12 + completeness + acceptance
```

No cycles. No deviation from dependency-first ordering is required. Independent inspections of supplied Fact Pack tables were interleaved where they did not depend on register completion; architecture selection was not advanced before the checkpoint.

Decision record opened in this revision:

* **DEC-R-001:** six-part revised delivery with incremental persistence. Reversible. Reason: completeness without holding findings in memory.
* **DEC-R-002:** dependency order above. Reversible only with stated dependency reason.

---

## R1.7 Acronym and term definitions for revised package

* USDT: United States Dollar Tether settlement unit. All monetary quantities use USDT.
* UTC: Coordinated Universal Time. Authoritative for computation, storage, logs, alerts, reports, scheduling, exchange communication, audit events.
* REST: Representational State Transfer. Public request and response transport.
* WS: WebSocket. Abbreviation for WebSocket streaming transport after first paired use.
* HMAC-SHA256: Hash-based Message Authentication Code with Secure Hash Algorithm 256. Exchange signing method.
* OMS: Order Management System. Local authority for order intent, identity, durability, and reconciliation.
* D-RISK: Owner-hard risk decision series in supplemental Section 1.
* D14: Universe-derivation principle from original prompt.
* D15: Envelope-first deployment principle from original prompt.
* D16: Risk-driven phase principle from original prompt.
* D19: Rigor-as-verification principle from original prompt.
* SLO: Service Level Objective. Design target, not measured result.
* RTO: Recovery Time Objective. Design target, not measured result.
* RPO: Recovery Point Objective. Design target, not measured result.
* FMEA: Failure Modes and Effects Analysis. Structured failure review method.

---

## R1.8 Incremental Artifact Registry — Rev Part 1/6 state

| Artifact Identifier | Artifact name | Phase produced | Message reference | Status | Content description |
|---|---|---|---|---|---|
| ART-R-001 | Offline inventory, perimeter, checkpoint, plan | Reassessment Pass A | Rev Part 1/6 | DELIVERED | This message: capability honesty, frozen perimeter, gap list, checkpoint verdict, dependency graph, acronyms |
| ART-R-002 | Canonical Requirements Register with 11 fields and risk catalog | Pass B | Rev Part 2/6 | DEFERRED | Single table; includes D-RISK interactions; reason: needs perimeter freeze as input |
| ART-R-003 | Clean-sheet baseline, strategy candidate, universe, statistics, envelope | Pass C | Rev Part 3/6 | DEFERRED | D14, D15, D19, C20 through C24 handling; reason: needs register |
| ART-R-004 | Integrated architecture and contracts | Pass F | Rev Part 4/6 | DEFERRED | Data, risk authority, OMS, Telegram, security, Paper and Live semantics; reason: needs universe and envelope |
| ART-R-005 | Verification Matrix, test specifications, arithmetic walks | Passes F through H | Rev Part 5/6 | DEFERRED | One matrix row per requirement; reason: needs integrated design |
| ART-R-006 | Findings, propagation, self-audits, completeness, acceptance | Passes D through H | Rev Part 6/6 | DEFERRED | V-1 through V-12, counts, limitations; reason: needs all prior artifacts |

No named artifact is claimed before it appears in its stated part.

---

## R1.9 Rev Part 1/6 completeness declaration — part scope only

Part-scope counts use the same structure as the final declaration but cover only work declared for Rev Part 1/6. Overall package completeness remains pending Rev Parts 2/6 through 6/6.

```
Inventory items declared = 9 rows in Section R1.2 = 9
Perimeter items declared = 4 permitted classes in Section R1.3 = 4
Integrity gaps declared = 16 bullets in Section R1.4 = 16
Checkpoint rows declared = 7 rows in Section R1.5 = 7
Dependency nodes declared = Pass A through Pass H = 8
Registry rows declared = 6 rows in Section R1.8 = 6
Total part-scope items = 9+4+16+7+8+6 = 50
9+4=13, 13+16=29, 29+7=36, 36+8=44, 44+6=50
```

**Rev Part 1/6 verdict:** complete for declared scope. Deferred artifacts are listed with dependency reasons. No truncation. No architecture selected. No live action performed. No profitability claim made.

---

*یادداشت فارسی مالک — پیشرفت بسته بازبینی، بخش ۱ از ۶:*
*این پیام شروع بازبینی مستقل آفلاین است. موجودی واقعی قابلیت‌ها، مرز منابع بسته، فهرست کمبودها و ایست بازبینی آفلاین ثبت شد و نقشه شش‌بخشی تحویل اعلام شد. هیچ معماری انتخاب نشد و هیچ اتصال، تست زنده، سفارش یا اقدام لایو انجام نشد. همه مبالغ با تتر و همه زمان‌ها با UTC بررسی می‌شوند. ادامه: بخش ۲ از ۶ — جدول یکتای الزامات با ۱۱ ستون و کاتالوگ شش سقف سخت ریسک.*


# Rev Part 2/6 — Canonical Requirements Register and Risk-Policy Catalog (ART-R-002)

> **Rev Part 2/6 scope:** this message delivers the single canonical Requirements Register with 11 fields and the canonical risk-policy catalog for six `D-RISK` hard decisions with interaction analysis.
> No architecture is selected. No implementation, backtest execution, Paper operation, exchange connectivity, production deployment, or Live authorization is performed. Test execution is `NOT TESTED`.
> All monetary quantities in **USDT**, United States Dollar Tether. All time in **UTC**, Coordinated Universal Time. Profit and Loss is abbreviated as **PnL** on first use here. Time In Force is abbreviated as **TIF** on first use here.

## R2.1 Single canonical Requirements Register

This table is the single normative register. It uses exactly the 11 fields required in Pass B. There is no second register. The canonical risk values live in Section R2.2. Rows in Section R2.1 restate those values without alteration and point to Section R2.2 as authoritative.

Count: **37 rows**, `RQ-001` through `RQ-037`, partitioned as 14 project invariants plus 7 risk-authority rows plus 13 exchange-contract rows plus 3 assurance rows.

| Requirement ID | Requirement / obligation | Priority | Authority / origin | Rationale / source / provenance | Verification method | Acceptance condition | Status | Evidence pointer / observed result | Failure response / safe fallback | Regression checks / dependencies / affected requirements |
|---|---|---|---|---|---|---|---|---|---|---|
| RQ-001 | System shall execute Live only on Toobit USDT-margined futures or perpetual futures and shall not route Live orders to any other venue. | HARD | Owner A1; supplement Sec 2 item 1 | Prevents venue drift and unauthorized Live routing. | SOURCE_CHECK of venue configuration plus Live-gate inspection. | LiveVenue equals Toobit-Perp; all other LiveAllowed equals False. | FROZEN | PROMPT C-summary; Fact Pack Sec 1 base URLs as supplied-source status; no Live call in session, integration NOT TESTED. | Refuse non-Toobit Live routing; halt new entries. | Affects RQ-005 RQ-022 RQ-024 RQ-027 RQ-035. |
| RQ-002 | System shall expose all routine operator control, mode selection, configuration, alerts, acknowledgements, safety refusals, monitoring, and read-only review through one Telegram bot and shall provide no second bot, dashboard, web console, desktop client, mobile application, or routine console. | HARD | Owner A2; supplement Sec 2 item 2 | Preserves sole interface and prevents shadow control paths. | Inspection of interface inventory plus demonstration. | Singleton bot; routine parallel interface count equals zero; autonomous safety logic is not counted as interface. | FROZEN | Prior blueprint interface claim inspected as candidate only; no Telegram access in session, behavior NOT TESTED. | Remove or disable parallel path; Live remains refused until singleton restored. | Affects RQ-009 RQ-010 RQ-035 RQ-036. |
| RQ-003 | System shall compute, store, log, alert, report, schedule, communicate, and audit exclusively in UTC and shall tag every timestamp with one semantic role of venue event time, bar open, bar close, availability or knowability time, monotonic elapsed time, or server-anchored wall time; elapsed deadlines shall use monotonic time. | HARD | Owner A3; supplement Sec 2 item 3 | Prevents timezone error, look-ahead use, and deadline distortion. | Inspection plus boundary-value analysis across UTC day and week boundaries. | Timezone equals UTC; null role count equals zero; daily boundary equals UTC day; weekly boundary equals ISO-8601 UTC week unless justified alternative recorded. | FROZEN | General engineering knowledge for clock discipline; no clock measurement executed, NOT TESTED. | Invalidate untagged data; trip clock interlock and refuse risk-increasing acts. | Affects RQ-010 RQ-019 RQ-029 RQ-034. |
| RQ-004 | During this design engagement the design agent shall not request or transmit secrets, connect to any account, perform authenticated calls, alter permissions, access funds, or submit, cancel, or amend orders. | HARD | Owner A4; supplement Sec 2 item 4 | Enforces design-only boundary. | Audit of engagement outputs. | Engagement authenticated-call count equals zero; order-action count equals zero. | FROZEN | Observed result in this session: zero such actions performed, PASS for engagement scope. | Stop disallowed action; record boundary violation and remove content. | Affects acceptance; blocks RQ-022 through RQ-028 runtime confirmation. |
| RQ-005 | System shall restrict every cross-venue dataset to research and historical backtest only, shall tag it at ingestion with source lineage, and shall prevent it by enforceable architectural control from entering Paper or Live data, decision, or execution paths. | HARD | Owner A5 as narrowed by supplement Sec 0.2 and Sec 2 item 5 | Prevents contaminated Live valuation and preserves owner legal boundary. | SOURCE_CHECK of lineage tags plus architectural isolation inspection plus negative-path demonstration. | No Paper path and no Live path consumes cross-venue bytes; lineage tag present on every imported bar; isolation is structural, not documentary. | FROZEN | PROMPT C17 C18 summary; research-only gate; Paper and Live isolation NOT TESTED. | Quarantine dataset; disable dependent feature until lineage passes. | Affects RQ-007 RQ-012 RQ-029 RQ-034 RQ-035. |
| RQ-006 | System shall operate with intraday intent and shall derive maximum holding-duration policy from strategy exits, market evidence, funding, costs, risk caps, and validation horizon without inventing a fixed duration to complete a table. | HARD | Owner A6; supplement Sec 2 item 6 | Preserves intent while forcing evidence-based duration limit. | Analysis of derivation record. | Intent equals intraday; duration equals derived minimum of exit, funding, risk, validation, and UTC-day bounds; no constant without derivation. | FROZEN method; quantification UNRESOLVED | PROMPT A6; Fact Pack Sec 6 funding frequency; duration value NOT TESTED. | Default to review-or-close before UTC-day boundary; refuse overnight hold without derived permission. | Affects RQ-015 RQ-030 RQ-035. |
| RQ-007 | System shall derive the usable symbol by timeframe universe through D14 evidence filters and shall not treat the ten C19 measurement symbols as recommendation or candidate list. | HARD | Owner A7; D14; supplement Sec 2 item 7 | Prevents infeasible breadth and hidden breadth reduction. | Analysis plus feasibility comparison. | Universe equals derived set; symbol-axis rationale distinct from timeframe-axis rationale; C19 set carries no selection weight. | FROZEN method; membership UNRESOLVED until runtime discovery | PROMPT C1 C2 C8 C9 C19 C25 summary; Fact Pack Sec 10 partial list PROVISIONAL; census revalidation NOT TESTED. | Contract universe to validated subset; exclude unvalidated symbols from Paper and Live. | Affects RQ-028 RQ-029 RQ-032. |
| RQ-008 | System shall apply envelope-first D15 in order of derive load envelope, then measure or bound POCO X6 capability, then match load to envelope, then record gap and compromise; shall enumerate every feasible topology before compromise; shall apply owner compromise order without letting mobile convenience predetermine architecture. | HARD | Owner A8; D15; supplement Sec 2 item 8 | Prevents phone-overload failure and silent capability loss. | Analysis plus measurement plan plus inspection for undisclosed deviation. | Steps 1 through 4b evidenced; deviation discloses what, why, effect, restoration; sustained claim requires measurement. | FROZEN process; sustained values NOT TESTED | PROMPT C14 C15 C16 snapshot; C19 1.25 GB unit; sustained runtime NOT MEASURED. | Reduce breadth then depth then capability per order; if still infeasible declare redesign. | Affects RQ-034 through RQ-036; envelope detailed in Rev Part 3/6. |
| RQ-009 | System shall assume no stable Telegram inbound from the handset; Telegram loss shall never release a risk limit, unblock an unsafe action, or present uncertain exchange state as confirmed; open-position and pending-order behavior while operator is unreachable shall be specified. | HARD | Owner A9; supplement Sec 2 item 9 | Ensures fail-closed operation under operator unreachability. | Demonstration with communications-loss injection as design walkthrough. | Loss state is safe state; limit-release-on-loss equals False; uncertain remains uncertain; parked behavior defined. | FROZEN logic; drill NOT TESTED | PROMPT A9; no Telegram test in session. | Park exposure with pre-authorized exits only; block new risk; audit gap for later review. | Affects RQ-002 RQ-010 RQ-021 RQ-035. |
| RQ-010 | System shall derive phase count and boundaries from risks and verification dependencies per D16, shall provide Telegram Paper or Live selector with no elapsed-time wait and no profitability hurdle, and shall enforce six non-bypassable interlocks of data validity, reconciliation of exchange equals ledger, all hard risk limits, credential and permission validity, configuration integrity, and clock validity. | HARD | Owner A10; D16; supplement Secs 1 and 2 item 10 | Prevents hurdle gatekeeping while preserving safety. | Demonstration of each interlock trip plus selector transaction review. | LiveAllowed equals AND of six interlocks; each refusal carries explicit reason; zero wait or profit condition present. | FROZEN logic; runtime trip NOT TESTED | PROMPT A10; six-gate list confirmed in supplement. | Refuse Live and risk-increasing act with named reason; require authenticated re-arm where latch applies. | Affects all risk rows RQ-015 through RQ-021 plus RQ-035. |
| RQ-011 | System shall keep architecture, language, framework, runtime, data store, algorithm, model class, and optimizer choices as delegated design judgments with include, transform, combine, or reject rationale and shall not ask owner to select technical solutions. | HARD | Owner A12; supplement Sec 2 item 11 | Maximizes capability without abdicating safety and reduces owner burden. | Inspection of derivation plus audit of questions asked. | Every inclusion positively derived; zero unjustified mechanisms permitted with rationale; owner technical-selection question count equals zero. | FROZEN | PROMPT A12 A13; observed result: no technical-selection question asked in Rev Part 1/6, PASS for scope. | Remove unjustified component; return decision to derivation with evidence. | Affects RQ-012 RQ-021 RQ-036. |
| RQ-012 | System shall enforce statistical validity with deflated Sharpe or equivalent multiple-testing control, minimum backtest length and minimum live track-record length separation, effective trial count with recomputed-governs rule, purge plus embargo walk-forward, and ban on exhaustive permutation grid search at timeframes at or below 12h; hard D-RISK limits are never optimizer parameters. | HARD | C20-C24; D19; supplement Sec 2 item 12 | Prevents multiple-testing, leakage, and horizon overclaim. | Statistical analysis plus trial-budget audit. | Grid at or below 12h rejected; all hypotheses pre-registered with counted trials; promotion requires deflated metric plus out-of-sample plus Paper confirmation. | FROZEN method; thresholds per hypothesis UNRESOLVED | PROMPT C20 1.5e-2 at N equals 100, C21 19.54 yr, C23 10-20 at 4h PROVISIONAL, C24 ban; no backtest executed, NOT TESTED. | Reject hypothesis; increment trial counter including rejects; block Live promotion. | Affects RQ-005 through RQ-007. |
| RQ-013 | System shall preserve evidence labels and precedence, shall not upgrade PROVISIONAL, UNRESOLVED, or DOC_CONFLICT to SOURCE_VERIFIED, shall not convert an example or partial list into universal contract, and shall not invent missing endpoints, fields, codes, filters, timeframes, tiers, or margin behavior. | HARD | PROMPT Sec 2; supplement Secs 3.2 through 3.3 | Preserves auditability and prevents false certainty. | SOURCE_CHECK plus cross-reference audit. | Every Toobit-dependent claim carries exact Fact Pack pointer with status; missing fact labeled UNRESOLVED with resolution path and safe interim. | FROZEN | Fact Pack Secs 1-13 statuses preserved; no URL opened in session. | Downgrade claim to UNRESOLVED; disable dependent Live capability. | Affects RQ-022 through RQ-034. |
| RQ-014 | System shall work in closed-world Direct mode using only supplied PROMPT summary, prior blueprint messages, owner decisions, embedded Fact Pack, and general knowledge labeled as such; shall perform no browsing, remote calls, downloads, live-data retrieval, or mode-change request; URLs are provenance metadata only. | HARD | Supplement Secs 0.3 and 3.1 | Enforces offline execution boundary. | Audit of actions and citations. | Remote-access count equals zero; every external reference marked NOT INSPECTED where relevant; calculations show manual reproducibility. | FROZEN | Observed result: zero remote calls in Rev Parts 1/6-2/6, PASS for scope. | Halt remote attempt; mark dependent verification BLOCKED and continue independent work. | Affects all verification rows. |
| RQ-015 | System shall enforce maximum peak-to-trough drawdown of 15 percent of initial equity as hard limit; 20 percent is advisory context only and shall never operate as limit, tolerated breach, optimizer target, or substitute. Authoritative definition in Section R2.2. | HARD | Owner D-RISK-1 | Caps cumulative decline on owner denominator. | Inspection of risk-policy enforcement plus boundary-value analysis. | Draw-initial equals Peak-minus-Trough divided by E0; Live halted and latched when at or beyond 0.15; 20 percent never used operatively. | FROZEN definition; live measurement NOT TESTED | Supplement Sec 1.1; equity-measure interpretation DESIGN_JUDGMENT recorded in R2.2. | Latch Live disabled; allow only risk-reducing acts with confirmed semantics; require explicit re-authorization to re-baseline. | Depends on RQ-010 RQ-021; interacts with RQ-018 RQ-019 RQ-020. |
| RQ-016 | System shall enforce maximum risk budget for any individual trade of 5 percent of current equity as ceiling, never target; shall estimate with stop distance, multiplier, quantity rounding, fees, spread, slippage, funding horizon, partial fills, gap, and protective-order failure; stop-price arithmetic alone is never a guaranteed cap. Authoritative definition in Section R2.2. | HARD | Owner D-RISK-2 | Prevents single-trade ruin and stop-as-guarantee fallacy. | Inspection of sizing formula plus stale-input injection walkthrough. | Estimated net loss at or below 0.05 times current equity before authorization; uncertain inputs fail closed. | FROZEN definition; execution NOT TESTED | Supplement Sec 1.2; contract-filter inputs UNRESOLVED per Fact Pack Sec 9. | Refuse entry; require refreshed inputs and recomputed estimate. | Depends on RQ-010 RQ-021 RQ-028 RQ-031; interacts with RQ-018. |
| RQ-017 | System shall use 200 USDT as hard capital-planning basis and shall perform sensitivity across 100 to 500 USDT; this is planning scale only, not balance statement, account-access authorization, or feasibility proof; all money in USDT with formulas, units, assumptions, and boundary cases. Authoritative basis in Section R2.2. | HARD | Owner D-RISK-3 | Prevents hard-coded single-equity assumption and currency error. | Inspection for fixed-equity constant plus arithmetic-walk review. | No embedded USDT constant outside planning parameter; sensitivity recomputed per cell; infeasible cell marked UNRESOLVED, BLOCKED, or NOT TESTED. | FROZEN | Supplement Sec 1.3; prior 200 USDT illustration superseded as hard basis. | Mark cell infeasible; do not claim filter or minimum-order feasibility. | Affects RQ-015 RQ-016 RQ-018 RQ-019 RQ-020 RQ-031. |
| RQ-018 | System shall enforce aggregate simultaneous risk across all open positions plus risk-increasing pending orders at or below 15 percent of equity as hard ceiling with atomic reservation so concurrency cannot breach it; shall not net offsetting or correlated exposure unless valid model plus conservative measure still passes. Authoritative definition in Section R2.2. | HARD | Owner D-RISK-4 | Prevents portfolio-level breach by concurrency. | Concurrency and race analysis plus reservation-logic inspection. | Sum of reserved estimated losses at or below 0.15 times applicable equity; unknown aggregate blocks new risk. | FROZEN definition; concurrency test NOT TESTED | Supplement Sec 1.4; denominator choice DESIGN_JUDGMENT in R2.2. | Block new risk-increasing intent; keep existing managed exits; reconcile pending exposure. | Depends on RQ-010 RQ-016 RQ-021 RQ-026; interacts with RQ-015 RQ-019. |
| RQ-019 | System shall enforce maximum daily realized loss of 10 percent of equity with veto on further risk-increasing activity until end of that UTC day; veto shall not block confirmed risk-reducing acts; reset occurs only at next UTC boundary with latch interaction defined. Authoritative definition in Section R2.2. | HARD | Owner D-RISK-5 | Caps single-day realized bleed while preserving exit ability. | Inspection of UTC-day accounting plus veto and reset walkthrough. | Realized day loss at or beyond threshold triggers veto until 00:00:00 UTC next day; reference equity and fee and funding inclusion verified. | FROZEN definition; live accounting NOT TESTED | Supplement Sec 1.5; denominator DESIGN_JUDGMENT in R2.2; no invented reduce-only semantics. | Veto entries and adds; permit only confirmed risk-reducing acts or park safely if route unconfirmed. | Depends on RQ-003 RQ-010; interacts with RQ-015 RQ-018. |
| RQ-020 | System shall enforce maximum effective leverage of 5 times as hard ceiling, defined on gross exposure over equity with pending orders and hedge-mode both sides included; permitted value is lesser of 5 times and symbol verified exchange constraint. Authoritative definition in Section R2.2. | HARD | Owner D-RISK-6 | Controls liquidation proximity and exposure independent of exchange setting label. | Inspection of leverage formula plus tier-uncertainty review. | Effective leverage at or below 5; no universal exchange maximum inferred; missing tier blocks increase. | FROZEN definition; margin behavior PROVISIONAL | Supplement Sec 1.6; Fact Pack Sec 8 example 200 times plus PROVISIONAL alts; margin modes PROVISIONAL. | Refuse leverage-increasing act; require deleveraging path with confirmed order semantics. | Depends on RQ-028 RQ-032 RQ-033; interacts with RQ-016 RQ-018. |
| RQ-021 | System shall vest sole risk authority in one policy catalog and evaluation order; no forecast, calibration, optimizer, allocator, or Telegram command shall override a hard veto; missing, corrupt, stale, contradictory, or unverifiable risk state shall fail closed. | HARD | Supplement Secs 1.7 and 7.3; D17 for other params | Prevents optimization or interface bypass of safety. | Inspection of authority hierarchy plus override-attempt walkthrough. | Risk veto precedes execution in all paths; override-attempt count with success equals zero; uncertain state equals refuse. | FROZEN | General control-architecture knowledge; no override test executed, NOT TESTED. | Veto act; latch and audit override attempt. | Guards RQ-015 RQ-016 RQ-018 RQ-019 RQ-020; constrains RQ-010 RQ-012 RQ-035. |
| RQ-022 | System shall use only documented REST base, WebSocket base, API-key header, HMAC-SHA256 lowercase-hex signature, millisecond timestamp, recvWindow default 5000 and maximum 60000, and 1000 ms future-skew reject within exact recorded scope without inventing canonicalization or signing detail. | HARD | Fact Pack Sec 1 | Prevents authentication and clock construction error. | SOURCE_CHECK of contract fields. | Every signed request carries documented header, signature case, timestamp unit, and recvWindow within bounds; missing detail remains UNRESOLVED. | FROZEN contract; call NOT TESTED and BLOCKED in design engagement | Fact Pack Sec 1 SOURCE_VERIFIED as supplied-source status; URL NOT INSPECTED in session. | Block submission; trip credential interlock until contract resolved. | Depends on RQ-010 RQ-013; affects RQ-023 through RQ-026. |
| RQ-023 | System shall model REQUEST_WEIGHT 3000 per minute with -1003 and ORDERS 60 per 2 seconds with -1015 separately, shall implement conservative fixed-weight accounting as safe baseline without depending on rate-limit headers, and shall treat header presence as UNRESOLVED branch. | HARD | Fact Pack Sec 2; PROMPT C4 | Prevents throttling, ban, and storm retry. | Rate-budget arithmetic plus header-absent walkthrough. | Design budget never exceeds stated limits under fixed weights; 429 maps to -1003 path; 403 WAF and -1015 paths handled distinctly. | FROZEN baseline; live header observation NOT TESTED | Fact Pack Sec 2 weights; C4 DOC_CONFLICT preserved with conservative branch (b). | Back off on monotonic deadline; shed low-priority reads; refuse burst that would breach budget. | Depends on RQ-010; affects RQ-024 RQ-026 RQ-029 RQ-034. |
| RQ-024 | System shall implement futures v2 order lifecycle exactly as listed with POST order weight 1, update weight 2 LIMIT-only by orderId or origClientOrderId, DELETE weight 1 by one identity, batch weights 2 and 3, mandatory symbol, side BUY or SELL, positionSide LONG or SHORT, type LIMIT or MARKET, newClientOrderId, timestamp, quantity or valueQuantity one non-zero, documented TIF names, and conditional fields without asserting beyond listed fields. | HARD | Fact Pack Sec 3 | Prevents invalid construction and undocumented-semantics dependence. | SOURCE_CHECK of field mapping plus contract test specification. | Order passes schema with only listed fields; amend of non-LIMIT refused locally; mutually exclusive cancel identity enforced. | FROZEN contract subset; integration NOT TESTED | Fact Pack Sec 3 as supplied-source status; beyond-listed semantics UNRESOLVED. | Refuse construction; request corrected intent. | Depends on RQ-022 RQ-023 RQ-025; affects OMS in Rev Part 4/6. |
| RQ-025 | System shall use newClientOrderId on creation and origClientOrderId on lookup or cancel, shall restrict charset to A-Za-z0-9_- binding, shall assume weakest per-account uniqueness scope and enforce local uniqueness, and shall never reuse an identifier after ambiguous outcome. | HARD | Fact Pack Sec 3; PROMPT C11 | Ensures idempotency key integrity and safe reconciliation. | SOURCE_CHECK plus invalid-charset and reuse-attempt specification. | Charset enforced pre-submit; local uniqueness holds per account; ambiguous identifier never reused. | FROZEN | C11 binding; Fact Pack examples within set; scope UNRESOLVED with conservative assumption. | Reject invalid identifier; generate fresh nonce identity for new intent. | Depends on RQ-024; guards RQ-026. |
| RQ-026 | System shall treat every 5XX, timeout, -1007 TIMEOUT, or otherwise ambiguous submission as UNKNOWN with durable record, shall perform lookup and reconciliation by client identity before any retry, and shall never blindly resubmit. | HARD | Fact Pack Secs 3-4; PROMPT C5 | Prevents duplicate exposure from retry storm. | State-machine review plus ambiguous-outcome walkthrough. | UNKNOWN outcome persists until reconciliation observes rejection, partial, full, or terminal-unresolved mismatch; resubmit without reconciliation count equals zero. | FROZEN logic; exchange test NOT TESTED and BLOCKED | -1003 SOURCE_VERIFIED; -1007 ambiguous per C5; full catalog UNRESOLVED; error-page locator NOT INSPECTED. | Hold as UNKNOWN; reserve pending exposure; reconcile; declare terminal-unresolved mismatch if equality cannot be re-established. | Depends on RQ-023 RQ-025; affects RQ-010 RQ-018 RQ-021. |
| RQ-027 | System shall keep futures and spot symbol formats distinct, shall use a canonical internal instrument identity with explicit mapping, and shall not assume BTCUSDT equals BTC-SWAP-USDT. | HARD | Fact Pack Sec 3 | Prevents wrong-instrument execution. | SOURCE_CHECK of mapping table. | Every venue symbol maps through canonical identity; unmapped symbol blocked. | FROZEN | Fact Pack futures examples BTC-SWAP-USDT and ETH-SWAP-USDT; spot BTCUSDT distinct. | Block order on unmapped symbol. | Affects RQ-024 RQ-028. |
| RQ-028 | System shall treat exchangeInfo as startup discovery source for per-symbol filters and leverage constraints; actual minQty, stepSize, tickSize, and per-symbol leverage values are UNRESOLVED in supplied evidence and no trade shall be designed around invented filters. | HARD | Fact Pack Secs 8-9 | Prevents sizing on invented minima. | SOURCE_CHECK of discovery requirement. | Discovery precedes sizing; missing filter blocks sizing for that symbol. | UNRESOLVED values; discovery design FROZEN | Fact Pack Sec 9 endpoint existence SOURCE_VERIFIED; values NOT extracted, therefore UNRESOLVED; fetch BLOCKED in session. | Disable symbol for sizing until verified filters observed. | Depends on RQ-013; guards RQ-016 RQ-020 RQ-032. |
| RQ-029 | System shall implement market-data access with GET quote klines, mark-price klines, index klines, WS kline topics, depth, and 24hr ticker within documented weights, shall paginate with conservative 1000-kline response bound, shall treat 3500 as cap not guarantee, and shall preserve ratified 14-timeframe ceiling without downgrading to narrower 11-entry WS list. | HARD | Fact Pack Sec 5; PROMPT C1 C2 | Prevents history overclaim and pagination failure. | SOURCE_CHECK plus pagination-budget arithmetic. | Pagination uses 1000 bound; 3500 never assumed available; 3d excluded; 3m and 8h availability verified per path before use. | FROZEN handling; depth history NOT TESTED | C1 RATIFIED_FINDING; C2 cap; WS 11-list SOURCE_VERIFIED for that list only; 2000 against 1000 conflict resolved to 1000 conservative. | Mark gappy range provisional; refuse validation that needs missing bars. | Depends on RQ-023; affects RQ-007 RQ-012 RQ-034. |
| RQ-030 | System shall model funding settlement every 8 hours standard with some contracts every 4 hours, shall treat PROVISIONAL 2.0000 percent to 3.0000 percent caps as tail-risk inputs not guaranteed bounds, and shall not assume funding cost bounded by observed -30.0000 basis points. | HARD | Fact Pack Sec 6; PROMPT C7 | Prevents funding-tail underestimation. | SOURCE_CHECK plus cost-inclusion review. | Every holding estimate includes horizon funding with tail add-on; no bounded-cost claim present. | PROVISIONAL caps; funding endpoint call NOT TESTED and BLOCKED | Fact Pack Sec 6 endpoints SOURCE_VERIFIED; caps PROVISIONAL; C7 refutation preserved. | Widen estimate or shorten holding; refuse if tail cannot be bounded for risk budget. | Affects RQ-006 RQ-016. |
| RQ-031 | System shall cost every decision with conservative 0.06 percent taker default, shall carry 0.05 percent as UNRESOLVED sensitivity, shall state maker and taker assumptions per path, and shall not present owner fee tier as verified. | HARD | Fact Pack Sec 7; PROMPT C6 | Prevents net-edge overstatement. | SOURCE_CHECK plus NetEdge arithmetic review. | Acceptance uses 0.06 percent legs plus spread, slippage, and funding; 0.05 percent shown only as sensitivity. | FROZEN default; tier verification NOT TESTED | Futures 0.02 percent maker and 0.06 percent taker SOURCE_VERIFIED as supplied status; 0.05 percent UNRESOLVED. | Fail NetEdge path to no-trade; require maker-evidence before maker costing. | Guards RQ-012 RQ-016. |
| RQ-032 | System shall treat BTC 200 times tier-1 example as example only, altcoin 50 times or 75 times as PROVISIONAL, riskLimits endpoint as discovery source, and 13-tier ladder as tier information not system risk limit; shall infer no universal exchange maximum. | HARD | Fact Pack Sec 8; PROMPT C3 | Prevents leverage over-assumption. | SOURCE_CHECK. | No universal maximum present; symbol maximum remains UNRESOLVED until riskLimits observed; owner 5 times ceiling still binds. | UNRESOLVED per-symbol maxima; ceiling FROZEN | BTC 200 times SOURCE_VERIFIED as example; alts PROVISIONAL; ladder RATIFIED_FINDING. | Block leverage increase until symbol tier verified. | Depends on RQ-028; guards RQ-020. |
| RQ-033 | System shall treat Cross and Isolated margin behavior as PROVISIONAL and shall define safe dependency on actual supported account and symbol configuration without assuming confirmed behavior. | SHOULD | Fact Pack Sec 9 | Prevents margin-mode failure. | SOURCE_CHECK. | Margin-dependent logic disabled or constrained until mode confirmed for account and symbol. | PROVISIONAL; confirmation NOT TESTED and BLOCKED | Fact Pack Sec 9 PROVISIONAL; not confirmed in extracted docs. | Default to most conservative supported mode or refuse margined act. | Affects RQ-020 RQ-026. |
| RQ-034 | System shall implement data lineage with availability timestamps, WS heartbeat with ping timestamp and pong response and 5-minute disconnect detection, stale-feed trip, resubscription, gap repair, duplicate handling, and provisional against final candle distinction; shall quarantine NON_REPRODUCIBLE depth, UNRESOLVED historical open interest, and CONFLICTED markPrice and klines change semantics away from sizing and critical decisions. | HARD | Fact Pack Secs 5 and 11; PROMPT C8 C13 C26 | Prevents look-ahead, stale trade, and false-signal sizing. | SOURCE_CHECK plus gap, duplicate, and quarantine walkthrough. | Heartbeat implemented; stale or gappy feed trips data interlock; depth never sizes; OI-dependent feature disabled; conflicted fields never decide. | FROZEN logic; feed behavior NOT TESTED | Heartbeat semantics as supplied status; depth NON_REPRODUCIBLE; markPrice CONFLICTED; OI UNRESOLVED; ticker weight 40 preserved. | Trip data validity; park exposure; require repair plus reconciliation before resuming. | Depends on RQ-003 RQ-010 RQ-023; affects RQ-007. |
| RQ-035 | System shall separate Paper as internal simulation from Live with isolated configuration, state, and order-sending boundary, shall make Paper-to-real submission impossible and Live consumption of cross-venue research data impossible, and shall define mode-switch transaction with pending-order, open-position, and audit behavior; Paper is not proof of Toobit testnet. | HARD | Supplement Sec 7.5; Fact Pack Sec 1 sandbox note | Prevents simulation-to-real leakage and false testnet claim. | Inspection of mode boundaries plus switch-transaction review. | Mode switch is atomic with audit event; pending and open handling explicit; cross-venue bytes unreachable from Paper and Live. | FROZEN design; switch drill NOT TESTED | No sandbox wired in CCXT as supplied wording, not overgeneralized; no Paper execution in session. | Abort switch on any isolation failure; remain in prior mode and audit. | Depends on RQ-002 RQ-005 RQ-010 RQ-021. |
| RQ-036 | System shall implement threat model with secret lifecycle, least-privilege API permissions, allowlisted Telegram principals, replay and injection and rate-limit protection, audit hash integrity, and incident response without creating a parallel operator interface for internal services. | HARD | Supplement Pass E items 10-13; Sec 2 items 2 and 4 | Controls privilege abuse and evidence tampering. | Threat-model review plus privileged-action walkthrough. | Every privileged act authenticated, authorized, validated, nonce-checked, rate-limited, and audited; token compromise halts Live until rotation and re-authentication. | FROZEN design; penetration test NOT TESTED and out of scope | No secrets handled in session; controls are general security knowledge applied to stated constraints. | Halt Live on compromise or integrity failure; preserve append-only audit. | Depends on RQ-002 RQ-004 RQ-010. |
| RQ-037 | System shall deliver traceable verification with one matrix row per requirement, reproducible arithmetic with units and intermediate steps, V-1 through V-12 enumeration, artifact registry with incremental persistence, seven-dimension acceptance reporting, and explicit limitation disclosure without claiming implementation, profitability, backtest success, Paper readiness, production readiness, or Live authorization. | HARD | Supplement Secs 9-11; original D19-D22 | Enables formal review and safe handoff as design only. | Cross-reference audit plus count reconciliation. | Matrix count equals register count; V-series individually tabled; SLO, RTO, RPO labeled as targets; no readiness claim present. | FROZEN obligation; execution evidence NOT TESTED | Prior blueprint Parts 1/6-6/6 available as candidate; V-checks in Rev Part 6/6. | Withhold completeness claim until counts reconcile; mark unexecuted evidence NOT TESTED. | Covers all RQ-001 through RQ-036. |

## R2.2 Canonical risk-policy catalog — sole authority for D-RISK values

This catalog is canonical. All other sections reference it. Sensitivity analysis varies planning equity and genuinely uncertain model inputs. It never varies the six hard limits as candidate values.

Common equity construction, conservative **DESIGN_JUDGMENT** with stated consequence:

* `E0`, initial equity in USDT, equals wallet plus unrealized net of estimated close costs at strategy-start reconciliation snapshot, fees and settled plus accrued funding inclusive. Any deposit, withdrawal, rebate correction, or late venue correction freezes new risk and requires explicit re-baselining with Telegram acknowledgement and audit event. Consequence: deposits cannot mask drawdown; withdrawals cannot create phantom headroom.
* `E_curr(t)`, current equity in USDT, equals same construction at evaluation time `t`, UTC-stamped at bar close plus post-fill plus funding-settlement updates.
* Unrealized is included. Consequence: drawdown reacts to floating loss before realization, which is stricter than realized-only accounting.
* Measurement timing is event-driven, not sampled casually: every fill, partial fill, funding settlement, correction, and bar close re-evaluates. Monotonic time orders deadlines; server-anchored wall time orders venue events.

| Limit | Owner value | Denominator and formula | Measurement, latch, reset, acknowledgement |
|---|---|---|---|
| D-RISK-1 drawdown | **15 percent of initial equity**; 20 percent advisory only, never operative. | `Draw(t) = Peak(t) minus Equity(t)` divided by `E0`; `Peak(t) = maximum Equity(s)` for `s` in start through `t`. Absolute allowance equals `0.15 times E0`. | Evaluated on every equity update. Breach at or beyond allowance latches Live disabled and blocks all risk-increasing acts. Drawdown latch does not auto-reset at UTC midnight and does not reset on daily veto reset. Re-arm requires authenticated Telegram acknowledgement plus audited re-baselining that establishes a new `E0`; prior breach remains in audit history. |
| D-RISK-2 per-trade | **5 percent of current equity**, ceiling not target. | `EstNetLoss = Q times d plus FeeOpen plus FeeClose plus SpreadEst plus SlipAllowance plus FundingHorizonEst plus RoundingUp plus PartialFillWorstCase plus GapAddOn`; all terms in USDT. Allow entry only if `EstNetLoss <= 0.05 times E_curr` at pre-trade time. Quantity uses contract multiplier and rounds up to loss-increasing side. Stop-price distance alone is an input, not a cap. | Pre-trade and pre-add evaluation with fresh inputs. Missing, stale, contradictory, or unverifiable input fails closed. Partial fills re-reserve remaining worst-case exposure before further fills accepted. Protective-order failure assumed possible; GapAddOn required. |
| D-RISK-3 planning basis | **200 USDT** basis; **100 to 500 USDT** sensitivity. | Planning equity `E_plan` in USDT; all budgets recomputed as `E_plan times rate`. Units shown in every walk. Boundary case: symbol feasibility requires verified `minQty`, `stepSize`, `tickSize`; without them the cell is `UNRESOLVED` for sizing and `BLOCKED` for Live sizing proof. | Basis fixed for design arithmetic. Sensitivity never changes D-RISK percentages. No minimum-order or fee-tier feasibility claimed without `exchangeInfo` values. |
| D-RISK-4 aggregate | **15 percent of equity**, ceiling not target. | Conservative denominator equals `minimum of E0 and E_curr`, **DESIGN_JUDGMENT**; consequence is tighter control after losses. `Agg = sum of EstNetLoss over open positions plus sum over risk-increasing pending orders`, no netting of offsetting or correlated exposure unless a validated risk model plus conservative gross measure both pass and owner limit remains satisfied. Atomic reservation: pending identity reserves its `EstNetLoss` before submission so simultaneous signals cannot overshoot. | Unknown aggregate blocks new risk. If reconciliation mismatch or UNKNOWN outcome exists, its full reserved exposure remains counted until venue truth reduces it. No time-based reset; continuous gate. |
| D-RISK-5 daily veto | **10 percent of equity**, realized loss veto until UTC-day end. | Reference `E_day_ref` equals equity at `00:00:00 UTC` start of that UTC day with same net construction; if start snapshot unavailable, use `minimum of E0 and E_curr at start`, **DESIGN_JUDGMENT**; consequence is conservative smaller allowance on first or gapped day. `RealizedDay = closed PnL plus settled funding plus fees plus commissions minus rebates plus or minus corrections plus late events bucketed by venue event time`. Trigger when `RealizedDay <= minus 0.10 times E_day_ref`. | Veto blocks entries, adds, leverage increases, and new pending risk. Veto does not block a risk-reducing act whose exchange semantics are confirmed and preconditions safe. No invented reduce-only or emergency-order semantics. If safe reduction route cannot be confirmed, disclose limitation and park safely without assuming a fill. Reset only at next `00:00:00 UTC`. Drawdown latch, reconciliation halt, clock halt, and config halt survive daily reset independently. |
| D-RISK-6 leverage | **5 times** effective, ceiling not target. | `EffLev = GrossNotional divided by E_curr_net`; `GrossNotional = sum of absolute N over open plus absolute N over risk-increasing pending`; hedge-mode LONG plus SHORT summed gross, not netted; `E_curr_net` net of estimated close costs. Allowed only if `EffLev <= 5` and `EffLev <= symbol verified maximum` where known; lesser governs. Exchange leverage-setting label is not effective leverage. | Continuous gate including pending reservation. Missing tier or margin-mode confirmation blocks increase. Isolated against Cross behavior remains PROVISIONAL; design assumes no confirmed netting benefit. |

## R2.3 Interaction analysis among six hard decisions

All six bind simultaneously. Numerical limits alone do not guarantee that realized loss cannot exceed modeled budgets. Model error, execution gaps, and venue failure are first-class constraints.

* **Per-trade against aggregate:** at full 5 percent per-trade use, three concurrent maxima exactly fill 15 percent aggregate. A fourth signal must wait even if its standalone estimate passes. Pending reservation prevents two racers from each seeing 10 percent free and jointly taking 20 percent.
* **Aggregate against drawdown:** aggregate controls modeled concurrent exposure; drawdown controls realized path including sequential losses. Repeated small realized losses can breach 15 percent of `E0` without ever breaching one 15 percent concurrent snapshot. Both gates are therefore necessary.
* **Daily realized against total drawdown with unrealized:** daily veto uses realized only; drawdown includes unrealized. A floating loss can latch drawdown before daily veto triggers. Conversely, realized churn can trigger daily veto while floating equity still looks intact. Designs that watch only one measure miss the other failure mode.
* **Leverage against notional, margin, liquidation, and stop risk:** at `E_plan = 200`, 5 times allows at most 1000 USDT gross notional. Fee round-trip at 0.06 percent per leg on full utilization is about 1.20 USDT before spread, slippage, and funding. Leverage does not change dollar PnL for fixed notional; it moves margin and liquidation proximity. A tight stop on large notional can satisfy leverage while violating per-trade and aggregate estimates once costs and gap add-ons are included.
* **Equity decline tightens current-equity limits:** per-trade, aggregate conservative denominator, and leverage all shrink in USDT terms as `E_curr` falls. Design must recompute before every act. A position size valid at 200 USDT is not automatically valid at 170 USDT.
* **Pending orders and races:** every risk-increasing pending order counts at its reserved worst case from intent durability through fill, cancel confirmation, expiry, or terminal-unresolved declaration. Cancel request alone does not release reservation; only venue-confirmed cancel or expiry does.
* **Costs and failure add-ons:** fees use 0.06 percent conservative legs; spread, slippage, funding horizon, rounding, partial-fill remainder, and gap add-ons are additive. Funding tails are unbounded by design. Inability to cancel or close preserves full reservation and trips reconciliation halt.
* **Reset, latch, re-arm, acknowledgement:** daily veto auto-resets at next UTC midnight; drawdown latch, reconciliation halt, clock halt, config halt, and credential halt do not. Re-arm of any latch requires allowlisted Telegram principal, fresh nonce, timestamp window, explicit acknowledgement command, and audit event. No forecast, optimizer, allocator, or Telegram convenience command can relax a hard percentage.

## R2.4 Capital-planning sensitivity with units and boundary cases

Formulas use USDT throughout. Rates are exact owner values. No rate is varied.

```
B_trade(E) = E times 0.05
B_agg(E) = minimum(E0,E) times 0.15
B_day(E_ref) = E_ref times 0.10
Allow_draw_abs(E0) = E0 times 0.15
MaxGross(E_curr_net) = E_curr_net times 5
FeeRoundTrip(N) = N times 0.0006 times 2
```

| Planning equity E in USDT | Per-trade max B_trade | Aggregate max B_agg using E | Daily max using same E as ref | Draw allowance if E is E0 | Max gross at 5 times |
|---|---|---|---|---|---|
| 100 | 5.00 | 15.00 | 10.00 | 15.00 | 500.00 |
| 200 | 10.00 | 30.00 | 20.00 | 30.00 | 1000.00 |
| 300 | 15.00 | 45.00 | 30.00 | 45.00 | 1500.00 |
| 500 | 25.00 | 75.00 | 50.00 | 75.00 | 2500.00 |

Worked boundary reading at basis `E = 200`: one maximum per-trade estimate of 10.00 USDT consumes one third of aggregate headroom and one half of daily headroom. Two such maxima plus costs leave almost no room for a third without breaching aggregate. Full 1000 USDT gross utilization incurs about 1.20 USDT fee round-trip alone, which is 12 percent of one maximum per-trade budget before spread, slippage, and funding. Where `minQty`, `stepSize`, `tickSize`, or symbol leverage tier is missing, the corresponding sizing cell is **UNRESOLVED** for quantity construction and **BLOCKED** for Live feasibility proof; Paper sizingproof is **NOT TESTED**. No filter value is invented to complete a cell.

## R2.5 Incremental Artifact Registry — Rev Part 2/6 state

| Artifact Identifier | Artifact name | Phase produced | Message reference | Status | Content description |
|---|---|---|---|---|---|
| ART-R-001 | Offline inventory, perimeter, checkpoint, plan | Pass A | Rev Part 1/6 | DELIVERED | Capability honesty, frozen perimeter, gaps, checkpoint, graph, acronyms. |
| ART-R-002 | Canonical Requirements Register with 11 fields and risk catalog | Pass B | Rev Part 2/6 | DELIVERED | This message: 37-row single table plus Sections R2.2 through R2.4. |
| ART-R-003 | Clean-sheet baseline, strategy candidate, universe, statistics, envelope | Pass C | Rev Part 3/6 | DEFERRED | Needs register as input; reason is dependency order. |
| ART-R-004 | Integrated architecture and contracts | Pass F | Rev Part 4/6 | DEFERRED | Needs universe and envelope; reason is dependency order. |
| ART-R-005 | Verification Matrix, test specifications, arithmetic walks | Passes F through H | Rev Part 5/6 | DEFERRED | Needs integrated design; matrix row count must equal 37. |
| ART-R-006 | Findings, propagation, self-audits, completeness, acceptance | Passes D through H | Rev Part 6/6 | DEFERRED | Needs all prior artifacts; includes V-1 through V-12. |

## R2.6 Rev Part 2/6 completeness declaration — part scope only

Part-scope reconciliation counts only work declared for Rev Part 2/6. Overall package completeness remains pending Rev Parts 3/6 through 6/6.

```
Register rows declared = 37, partitioned 14 + 7 + 13 + 3
14 + 7 = 21; 21 + 13 = 34; 34 + 3 = 37
Risk catalog limits declared = 6, matching D-RISK-1 through D-RISK-6
6 = 6, no limit varied
Interaction bullets declared = 8, covering Sec 1.7 minimum set
Sensitivity equity points declared = 4, namely 100, 200, 300, 500 USDT
Registry rows declared = 6, with 2 DELIVERED and 4 DEFERRED with reasons
Total part-scope items = 37 + 6 + 8 + 4 + 6 = 61
37 + 6 = 43; 43 + 8 = 51; 51 + 4 = 55; 55 + 6 = 61
```

**Rev Part 2/6 verdict:** complete for declared scope. No truncation. No architecture selected. No remote verification claimed. No Live action performed. No profitability claim made.

---

*یادداشت فارسی مالک — پیشرفت بسته بازبینی، بخش ۲ از ۶:*
*جدول یکتای الزامات با ۳۷ ردیف و ۱۱ ستون به‌همراه کاتالوگ شش سقف سخت ریسک تحویل شد. سقف‌ها شامل دراودان ۱۵ درصد مبنای اولیه، ریسک هر معامله ۵ درصد موجودی جاری، مبنای ۲۰۰ تتر با حساسیت ۱۰۰ تا ۵۰۰، سقف تجمیعی ۱۵ درصد، وتوی ضرر روزانه ۱۰ درصد تا پایان روز UTC و سقف لوریج مؤثر ۵ برابر است. هیچ مقداری به‌عنوان هدف یا توصیه بهینه‌سازی نشد و همه تعامل‌ها و رفتار قفل و بازگشایی ثبت شد. هیچ اتصال، تست زنده، سفارش یا اقدام لایو انجام نشد. ادامه: بخش ۳ از ۶ — بازسازی تمیز، راهبرد نامزد، یونیورس، آمار و پاکت موبایل.*


# Rev Part 3/6 — Clean-Sheet Reconstruction, Strategy Candidate, Universe, Statistics, Envelope (ART-R-003)

> **Rev Part 3/6 scope:** this message delivers ART-R-003 only.
> Inputs: ART-R-001 perimeter and checkpoint, ART-R-002 register with 37 rows and canonical risk catalog.
> Output: requirements-driven clean-sheet baseline, candidate strategy architecture with simple baseline, D14 universe derivation, statistical methodology with trial budgets, optimizer judgment, D15 envelope derivation with topology enumeration, intraday holding derivation.
> No final integrated contracts, no implementation, no backtest execution, no Paper operation, no exchange call, no Live authorization. All unexecuted tests are `NOT TESTED`. All missing exchange facts are `UNRESOLVED` with safe interim.
> All monetary quantities in **USDT**, United States Dollar Tether. All time in **UTC**, Coordinated Universal Time.
> Deflated Sharpe Ratio is abbreviated as **DSR** on first use here. Minimum Backtest Length is abbreviated as **MinBTL** on first use here. Minimum Live Track-Record Length is abbreviated as **MinTRL** on first use here. Time-Series Momentum is abbreviated as **TS-MOM** on first use here.

## R3.1 Clean-sheet reconstruction from requirements

This is a structured clean-sheet reconstruction, not a genuinely blind review, because the prior blueprint is visible in the same conversation. No component name, technology choice, assumption, data model, performance target, or diagram was copied as a premise. Every inclusion below is positively derived.

### R3.1.1 Decisions, cadence, admissible data

The system must make six decisions. Cadence is bar-close-driven, not tick-continuous, for cost, phone, and rate reasons.

1. Universe membership: daily or weekly cadence from runtime discovery.
2. Regime and no-trade gate: each execution-bar close.
3. Entry trigger: 15-minute, 1-hour, 4-hour bar close where validated.
4. Position sizing: per signal, pre-trade, with fresh inputs.
5. Exit management: protective, signal-reversal, time, funding-aware.
6. Risk veto: continuous plus pre-trade, authoritative over all six.

Admissible data for Paper and Live is Toobit perpetual direct only, with availability tagging. Any cross-venue dataset is research and historical backtest only, tagged at ingestion, structurally unreachable from Paper and Live paths per RQ-005. Consequence of violation is quarantine and feature disablement.

### R3.1.2 Minimum state and authority

Minimum owned state: canonical instrument map, validated universe, availability-tagged bars, funding schedule, ledger of positions and orders and fills, equity snapshot with net construction, risk reservations and latches, configuration version with hash, audit chain, mode flag with isolation boundary. Authoritative source for exchange truth is the venue response obtained by lookup. Authoritative source for risk permission is the independent risk authority per RQ-021. Authoritative source for operator intent is the singleton Telegram bot per RQ-002. No cache, forecast, optimizer output, or stale snapshot overrides these three.

### R3.1.3 Synchronous correctness and durability order

Synchronous correctness is required for risk reservation, client-identity durability, submission-attempt record, reconciliation equality, mode-switch atomicity, and latch transitions. Asynchronous tolerance is permitted for research calibration, historical pagination, monitoring aggregation, and read-only review exports. Durability order before any external side effect is: validate intent, reserve aggregate exposure, persist client identity with nonce, persist attempt record, then transmit. A 5XX response, timeout, or ambiguous outcome leaves a durable `UNKNOWN` local state, never an assumed rejection. Local internal states `SUBMITTING`, `UNKNOWN`, `RECONCILING` are explicitly local abstractions, not Toobit response enums, because only `NEW` and `CANCELED` are observed per Fact Pack Section 3.

### R3.1.4 True envelopes

Execution envelope: at most a handful of concurrent positions under 15 percent aggregate and 10 USDT per-trade maximum at 200 USDT basis, gross notional at most 1000 USDT at 5 times effective leverage, order rate far below 60 per 2 seconds. Rate envelope: 3000 request weight per minute, order weight 1 for new and cancel, 2 for update and batch create, 3 for batch cancel, 40 for 24-hour ticker, 8.35 for positions. Kline endpoint weight is not in the Fact Pack and is therefore `UNRESOLVED`; design paces reads conservatively and measures. Data envelope: pagination with 1000-kline conservative bound, 3500 as cap not guarantee, perpetual lineage only. Storage envelope: about 2551 bytes per stored candle from the 1.25 GB unit, derived in Section R3.6. Compute envelope: bursty validation on bar close plus funding-timestamp plus monotonic-deadline handling. Operational envelope: no stable Telegram inbound, indefinite-outage safe, kill and restart safe.

### R3.1.5 Natural boundaries and simplest credible architecture

Natural boundaries are: ingestion with lineage and quarantine, signal evaluation with counted trials, independent risk authority with veto, Order Management System with durability and reconciliation, ledger with exchange-equality check, Telegram sole interface with authentication, audit store with hash chain, offline research with promotion gate. Each boundary exists because it owns distinct state with a distinct failure policy. The simplest credible architecture satisfying hard constraints is a single-supervisor phone process with supervised tasks for the narrow universe, long-poll Telegram, and autonomous safe-park. More complex splits with an external always-on host are justified only with provisioned infrastructure and measured sustained shortfall, not assumed. Detailed selection with enumeration is in Section R3.6.

## R3.2 Candidate strategy architecture and simple baseline — D19 compliance

A defensible candidate is proposed before any statistical-rejection claim, per D19. Strategy defines when and why to hold exposure. Execution tuning defines how a valid intent is sent. Time Weighted Average Price, Volume Weighted Average Price, Percentage Of Volume, and Implementation Shortfall are execution methods, not substitutes for alpha, and are not needed at the planning size because full utilization at 200 USDT is at most 1000 USDT gross, executable as one or two listed orders without slicing benefit. This exclusion has positive reason, evidence, and consequence: inclusion would add failure modes without measurable cost saving at this size.

### R3.2.1 Baseline B0 — single-instrument 1-hour TS-MOM

**Content:** 1-hour VENUE_DIRECT klines only, availability-tagged, Bitcoin perpetual as reference instrument for comparability, not as universe recommendation. Signal `TS-MOM(24)`: return over prior 24 knowable 1-hour closes, normalized by rolling 168-hour return standard deviation. Long when normalized return exceeds plus threshold, short when below minus threshold, flat otherwise. Threshold is a research parameter with counted trial, not a Live constant. Holding exits on opposite signal, 24-hour time review, protective stop sized to D-RISK-2 estimate, or funding-avoidance exit where horizon funding would consume the budget. Sizing uses contract multiplier with round-up to the loss-increasing side and 0.06 percent conservative taker legs plus spread plus slippage plus funding horizon plus gap add-on. Status is `NOT TESTED`. No expected return and no statistical pass is claimed.

**Rationale and source:** trend persistence is the hypothesis under test for perpetual intraday drift with volatility normalization; 1-hour balances cost against sample size. **Consequence:** B0 is the permanent comparison anchor. Any richer candidate must beat B0 net of costs after deflation and trial counting or it is rejected.

### R3.2.2 Candidate C1 — filtered multi-timeframe intraday trend

**Content:** B0 logic plus three additive gates: 4-hour regime alignment, 15-minute entry refinement in the direction of the 1-hour signal, volatility-band and funding gate that forces no-trade when realized volatility is outside the validated band or horizon funding tail cannot be bounded inside the per-trade budget. Context 1-day provides calendar context only, never a holding justification. All gates use knowable bars only, with purge plus embargo in validation. Status is `NOT TESTED`.

**Inputs and semantics:** 15-minute, 1-hour, 4-hour execution bars plus 1-day context, funding rate and settlement schedule, spread estimate, symbol filters from runtime discovery, risk reservations. Signal validity requires fresh data, verified filters, discovered leverage tier, and all interlocks passing. Failure of any input fails closed to no-trade.

**Entry, exit, no-trade:** enter only on execution-bar close with full estimate at or below 5 percent of current equity and aggregate reservation available. Exit on reversal, time review, protective level, funding-bound breach, or risk veto. No-trade on stale or gappy feed, spread breach, missing tier, quarantine-field dependence, veto, latch, clock fault, or config mismatch.

**Ablation and negative controls:** remove each gate singly and measure net-edge delta with trial counted; shuffle timestamps to destroy temporal structure and require edge collapse; invert signal and require gross inversion before costs; run random entry with identical exits and sizing to isolate exit and sizing value. Lifecycle is research with pre-registration, backtest with embargo, out-of-sample confirmation, Paper confirmation, then promotion or retirement with rollback on drift. Retirement is a first-class terminal state.

## R3.3 Universe derivation through D14

The ten C19 measurement symbols carry zero selection weight. The Fact Pack partial list of about 31 families is `PROVISIONAL` and is not the universe. The prior 149-record census is a ratified snapshot, not current truth. Current truth requires runtime discovery from `GET /api/v1/exchangeInfo`, whose endpoint existence is `SOURCE_VERIFIED` as supplied status while per-symbol values are `UNRESOLVED`.

**Symbol-axis filters, which constrain symbols:** active USDT-margined perpetual status, canonical futures mapping distinct from spot per RQ-027, revalidated notional volume and bounded spread at runtime, sufficient Toobit direct history to satisfy MinBTL at the execution timeframe, NetEdge feasibility after conservative costs at planning equities, concentration cap on correlated concurrent holdings with no netting unless a validated model plus conservative gross measure both pass. Depth snapshot is `NON_REPRODUCIBLE` and never ranks or sizes. Historical open interest is `UNRESOLVED` and disables any dependent filter. New or changed listings are excluded until they pass the full chain.

**Timeframe-axis filters, which constrain timeframes:** ratified 14-timeframe ceiling preserved; 3-day excluded as unsupported; cost-per-volatility excludes consistent taker execution at 1-minute, 3-minute, and 5-minute for small equity; statistics ban exhaustive search at or below 12-hour; proxy extension is rejected at 5-minute and below; funding settlement cadence penalizes multi-settlement holds; intraday intent bars positional use of 1-day, 1-week, and 1-month as execution. The 11-entry WebSocket list is a narrower transport subset and does not reduce the ceiling. Availability of 3-minute, 4-hour, and 8-hour must be verified per path because the conflict is unresolved; a path lacking an interval cannot trade it.

**Interim derived set for envelope and design:** execution at 15-minute boundary conditional on maker evidence or taker NetEdge pass, 1-hour and 4-hour core, 30-minute and 2-hour only without new search consuming the trial budget; context 1-day and optionally 1-week and 1-month; excluded from execution are 1-minute, 3-minute, 5-minute, 6-hour, 8-hour, 12-hour, 1-day, 1-week, 1-month, 3-day. Symbol membership remains `UNRESOLVED` until runtime discovery and revalidation. Safe interim is the narrowest validated subset, contracting to single-instrument baseline on any envelope or validation breach.

## R3.4 Statistical methodology and trial budgets

Method is frozen; per-hypothesis thresholds are `UNRESOLVED` until pre-registration with counted trials.

Lineage and leakage control use venue event time, bar open, bar close, availability time, server-anchored wall time, and monotonic elapsed time. Walk-forward splits by UTC time with embargo at least maximum holding plus funding interval plus latency buffer. No shuffled cross-validation on time series. Proxy bars carry source, window, median 0.56 basis points, and correlation 0.999755 lineage and never enter Paper or Live.

Multiple testing uses pre-registered hypotheses with effective trial count equal to minimum of published and recomputed counts, with recomputed governing on greater-than-two-times discrepancy and investigation. Promotion requires a deflated metric that exceeds the null maximum given trial count, skew, and kurtosis, plus MinBTL satisfaction, plus out-of-sample confirmation, plus Paper confirmation. Reference DSR 1.5e-2 at N equal 100 illustrates how easily 100 trials generate spurious significance; it is not a pass threshold. MinTRL 19.54 years is tracked separately as the live-horizon gap; no live-significance claim is made inside this engagement. The 10-to-20 trials at 4-hour allowance is `PROVISIONAL`. Thousands nominal at 1-day collapse after correction. Full-grid search at or below 12-hour is rejected; only sparse pre-registered hypotheses are permitted there.

Calibration history bound, manual walk: assume 4.86 years listing from the 1774 daily sample. Approximate bar counts are 4.86 times 365 times 24 equals about 42574 at 1-hour, times 6 equals about 255444 at 15-minute, divided by 4 equals about 10643 at 4-hour. Independent bets are far fewer because overlapping holds and autocorrelation reduce effective sample. A 24-hour hold at 1-hour sampling yields at most about 1774 non-overlapping bets per year before dependence adjustment, which is why low-timeframe mining without pre-registration exhausts the budget immediately.

Non-stationarity uses rolling UTC windows, regime-break revalidation without auto-promotion, parameter perturbation robustness, and explicit uncertainty. Selection bias is controlled by counting every test including rejects. Limits of inference are disclosed: short perpetual history, unresolved filters, provisional caps, and unmeasured live spread and slippage prevent any profitability or readiness claim.

## R3.5 Optimization and adaptation judgment

No optimizer is needed for risk: hard limits are never tunable. No online adaptation is included: drift triggers revalidation and possible retirement, never silent self-adjustment. Offline sparse calibration of signal thresholds and volatility windows is permitted only with a pre-registered domain, explicit search budget inside Section R3.4, promotion rule requiring deflated plus out-of-sample plus Paper pass, and rollback to the last validated version on breach. Forecast calibration, strategy selection, portfolio construction, risk control, and execution tuning are separated so a calibration artifact cannot alter the risk catalog. If calibration shows no net value over B0, the design retains fixed parametric logic with rationale, which satisfies zero-mechanism acceptability.

## R3.6 Envelope-first D15 derivation

No sub-step deviation. Where measurement is absent the bound is `NOT MEASURED` with fail-closed rule.

**Step 1, derive load:** decimal-gigabyte walk with units. Storage unit 1.25 times 1.0e9 equals 1.25e9 bytes divided by 490000 candles equals about 2551 bytes per candle. Narrow 10-symbol 4-timeframe load is 10 times 4 times 3500 equals 140000 candles times 2551 equals about 357140000 bytes, about 357 MB, plus about 30 percent index equals about 464 MB. Full 134-symbol 14-timeframe load is 134 times 14 times 3500 equals 6566000 candles times 2551 equals about 16749866000 bytes, about 16.75 GB, plus indexes and outputs above 20 GB. Working set target is below 500 MB with below 2 GB safe bound. Network cadence is bar-close plus funding plus monotonic deadlines with paced pagination under 3000 weight per minute. Order load is single-digit intents per bar at weight 1, far below 60 per 2 seconds.

**Step 2, bound POCO X6:** Snapdragon 7s Gen 2 octa up to 2.4 GHz bursty only, 12 GB plus 8 GB extension where extension is swap not real-time memory, Android 16 with Termux and no service manager, Doze and App Standby apply with charging not equal exemption, 256 GB total with 56 GB free snapshot only, metered Network Address Translated intermittent network, sustained throughput and 24-hour survival `NOT MEASURED`. No sustained claim is made.

**Step 3, match:** narrow load fits the snapshot with margin. Full breadth does not fit safely and independently fails statistical breadth. Therefore breadth reduces before depth before capability.

**Step 4 and Step 4b, gap and every feasible topology:** snapshot gap is sustained behavior, Doze survival, thermal backoff, and live spread and tier freshness. Feasible topologies are E-T1 all phases on phone with no external host, E-T2 all except Live on phone with Live on an owner-provisioned always-on host, E-T3 ordered reduction retaining development and calibration on phone while reducing breadth then depth then capability to baseline, and E-T4 redesign with phone as thin terminal and all compute external. E-T2 and E-T4 require a provisioned host with sync, secret scope, relay trust, and cost that are not assumed. Compromise order is E-T1, then E-T2, then E-T3 breadth to depth to capability, then E-T4 redesign declaration. Interim synthesis target is E-T1 narrow with pre-authorized E-T3 contraction armed. Selection was not predetermined by mobile convenience because external options were enumerated and rejected only for missing provisioning and larger trust surface.

## R3.7 Intraday operational definition and holding derivation

Intraday means every position is reviewed or closed before the UTC-day boundary unless a derived permission with funding, cost, and risk evidence exists. Context timeframes never justify overnight hold. Maximum holding is derived, not invented:

```
MaxHolding = minimum of exit-quantile horizon, funding-bound horizon,
  risk-horizon bound, validation horizon, UTC-day boundary
```

No fixed hour value is adopted. If any input is missing the bound contracts to the shortest evidenced leg, defaulting to day-boundary review. Consequence is prevention of funding-tail accumulation and unvalidated multi-settlement carry.

## R3.8 Incremental Artifact Registry — Rev Part 3/6 state

| Artifact Identifier | Artifact name | Phase produced | Message reference | Status | Content description |
|---|---|---|---|---|---|
| ART-R-001 | Offline inventory, perimeter, checkpoint, plan | Pass A | Rev Part 1/6 | DELIVERED | Capability honesty, frozen perimeter, gaps, checkpoint, graph, acronyms. |
| ART-R-002 | Canonical Requirements Register with 11 fields and risk catalog | Pass B | Rev Part 2/6 | DELIVERED | 37-row single table, six D-RISK limits, interactions, sensitivity. |
| ART-R-003 | Clean-sheet baseline, strategy candidate, universe, statistics, envelope | Pass C | Rev Part 3/6 | DELIVERED | This message: Sections R3.1 through R3.7. |
| ART-R-004 | Integrated architecture and contracts | Pass F | Rev Part 4/6 | DEFERRED | Needs universe and envelope; reason is dependency order. |
| ART-R-005 | Verification Matrix, test specifications, arithmetic walks | Passes F through H | Rev Part 5/6 | DEFERRED | Needs integrated design; matrix row count must equal 37. |
| ART-R-006 | Findings, propagation, self-audits, completeness, acceptance | Passes D through H | Rev Part 6/6 | DEFERRED | Needs all prior artifacts; includes V-1 through V-12. |

## R3.9 Rev Part 3/6 completeness declaration — part scope only

```
Declared sections = 9, namely R3.1 through R3.8 plus Persian note = 9
Strategy architectures = baseline B0 + candidate C1 = 2
Universe axes separated = symbol axis + timeframe axis = 2
Statistical controls = deflated metric + MinBTL + MinTRL + trial count +
  embargo walk-forward + 12h grid ban = 6
Envelope D15 steps = derive + bound + match + gap with 4b enumeration = 4
Topologies enumerated = E-T1 + E-T2 + E-T3 + E-T4 = 4
Registry rows = 6, with 3 DELIVERED and 3 DEFERRED with reasons
Total part-scope items = 9 + 2 + 2 + 6 + 4 + 4 + 6 = 33
9 + 2 = 11; 11 + 2 = 13; 13 + 6 = 19; 19 + 4 = 23; 23 + 4 = 27; 27 + 6 = 33
```

**Rev Part 3/6 verdict:** complete for declared scope. No truncation. No architecture beyond the interim E-T1 narrow target with E-T3 contraction is selected. No remote verification claimed. No Live action performed. No profitability claim made.

---

*یادداشت فارسی مالک — پیشرفت بسته بازبینی، بخش ۳ از ۶:*
*بازسازی تمیز، راهبرد پایه و نامزد، مشتق‌سازی یونیورس، روش آماری، داوری بهینه‌ساز و پاکت اول-موبایل تحویل شد. ده‌نماد اندازه‌گیری به‌عنوان یونیورس استفاده نشد و عضویت نماد به کشف زمان اجرا و اعتبارسنجی مجدد موکول شد. راهبرد در وضعیت تست‌نشده باقی ماند و هیچ ادعای سودآوری نشد. هدف موقت باریک روی همان گوشی با مسیر کاهش از پیش مجاز ثبت شد. هیچ اتصال، تست زنده، سفارش یا اقدام لایو انجام نشد. ادامه: بخش ۴ از ۶ — معماری یکپارچه، داده، ریسک، سفارش، تلگرام، امنیت و عملیات.*


Rev Part 4/6 — Integrated Architecture and Contracts (ART-R-004)
Rev Part 4/6 scope: this message delivers ART-R-004 only.
Inputs: ART-R-001 perimeter, ART-R-002 37-row register and risk catalog, ART-R-003 baseline, universe method, statistics, envelope.
Output: integrated architecture with data and lineage firewall, independent risk authority, order durability, Telegram sole interface, Paper and Live semantics, security, operations and recovery.
No implementation, backtest execution, Paper operation, exchange call, production deployment, or Live authorization. All unexecuted tests are NOT TESTED. All missing exchange facts are UNRESOLVED with fail-closed interim.
All monetary quantities in USDT, United States Dollar Tether. All time in UTC, Coordinated Universal Time.

R4.1 System context and component boundaries
Context: one Toobit USDT-margined perpetual venue, one handset supervisor, one operator over Telegram. No second venue for Live. No second operator interface.

text

[Toobit REST https://api.toobit.com + WS wss://stream.toobit.com]
  ^ v                     | [Fact Pack Sec 1, SOURCE_VERIFIED supplied status; URLs NOT INSPECTED]
  |                     v
[ING ingestion] -> [SIG signal B0/C1] -> [RISK authority] -> [OMS] -> venue
  |                     |                 ^  veto          |  ^
  v                     v                 |                v  |
[LED ledger] <-> [AUD hash chain]    [CFG versioned]   [CLK mono+server]
  ^                                                   |
  +------------ [TG singleton bot] <-> [Operator] ----+
[RES offline research] -promotion gate-> [SIG]; no path RES->Paper/Live data
Component responsibility with state owner and failure policy:

Component	Owns	Failure policy
ING	availability-tagged bars, funding schedule, depth snapshots as non-sizing, heartbeat and gap state	Stale or gappy trips data interlock; provisional candle never promoted as final
SIG	pre-registered hypothesis version, signal validity flag, trial counter	Invalid input forces no-trade; no output bypasses RISK
RISK	reservations, latches, vetoes, equity snapshots, policy catalog values	Uncertain state refuses risk-increasing acts; veto precedes execution
OMS	intent record, client identity, attempt record, UNKNOWN persistence, reconciliation queue	Ambiguous outcome stays UNKNOWN; no blind resubmit
LED	positions, orders, fills, realized-day accounting, peak and equity series	Mismatch with venue halts new risk; managed exits only
TG	mode flag transaction, command nonce store, alerts and refusals	Loss is safe state; never releases limit
AUD	append-only hash-chained events	Integrity failure halts Live
CFG	versioned parameters with hash	Mismatch halts Live
CLK	monotonic deadlines, server offset estimate	Drift trips clock interlock
RES	cross-venue tagged bars, calibration candidates	Structurally unreachable from Paper and Live
Synchronous correctness is required for reservation plus identity durability plus attempt record before transmit, reconciliation equality, mode-switch atomicity, and latch transitions. Asynchronous tolerance is permitted for historical pagination, monitoring aggregation, and read-only export. Persistence uses local write-ahead log before external side effect, then snapshot. Bounded queues provide backpressure: on overflow low-priority reads shed first, signal evaluation second, risk and reconciliation never shed. Single supervisor owns mode flag, preventing split-brain. Crash recovery is restart plus reconciliation before any entry.

DEC-R-003: adopt single-supervisor phone process with supervised tasks for narrow universe, with pre-armed ordered reduction. Reversible on sustained measurement or provisioned host. Reason: satisfies hard constraints with smallest trust surface.

Excluded with positive reason: multi-venue Smart Order Routing because Live is single-venue per RQ-001; Time Weighted Average Price and Volume Weighted Average Price slicing because maximum 1000 USDT gross at basis needs one or two listed orders; FIX, Selective Binary Encoding, multicast, colocation, Field Programmable Gate Array, Kubernetes, microservice mesh, dashboard because no requirement or evidence justifies them and each adds failure surface; probabilistic Value at Risk as authority because hard deterministic budgets govern and a VaR model would add unvalidated assumptions.

R4.2 Data ingestion, lineage firewall, quality, retention
Contracts used, exact scope: GET /quote/v1/klines, GET /quote/v1/markPrice/klines, GET /quote/v1/index/klines, WS topics kline_$interval, markPriceKline_$interval, realtimes, trade, depth, markPrice, index, indexKline_$interval, GET /quote/v1/depth, GET /quote/v1/ticker/24hr weight 40, GET /api/v1/exchangeInfo, GET /api/v1/futures/fundingRate, GET /api/v1/futures/historyFundingRate, GET /api/v1/futures/riskLimits, heartbeat client {"ping": timestamp} with {"pong": timestamp} and 5-minute disconnect [Fact Pack Secs 5, 9, 11; SOURCE_VERIFIED supplied status; endpoint calls NOT TESTED and BLOCKED in this engagement].

Schemas, design-only:

text

Kline{symbol_canonical, venue_symbol, timeframe, open, high, low, close, volume,
 venue_event_time, bar_open, bar_close, availability_time,
 wall_server_anchored, lineage: VENUE_DIRECT | PROXY_LINEAGE(src,window),
 status: PROVISIONAL | FINAL, perpetual: true}
FundingTick{symbol_canonical, rate, settlement_time, availability_time, source}
LiquiditySnapshot{symbol_canonical, bid_notional, ask_notional, spread_bp,
 wall_time, NON_REPRODUCIBLE: true, usable_for_sizing: false}
Instrument{symbol_canonical, venue_symbol_futures e.g. BTC-SWAP-USDT,
 spot_form distinct e.g. BTCUSDT, filters: UNRESOLVED until discovery,
 leverage_tier: UNRESOLVED until riskLimits observed}
Canonical mapping per RQ-027 prevents wrong-instrument execution. Futures and spot forms are never equated.

Firewall: two logical stores with no import path from research to Paper or Live. RES_STORE holds cross-venue bytes with mandatory PROXY_LINEAGE tag. LIVE_STORE accepts VENUE_DIRECT only through an allowlisted source-identifier check enforced at ingestion function and re-checked at signal input and at mode-switch. A unit test specification in Rev Part 5/6 feeds a tagged proxy bar to Paper and Live inputs and requires rejection. Research promotion passes only a versioned parameter set through the validation gate, never bars.

Quality: pagination uses conservative 1000-kline bound; 3500 is a cap not a guarantee; 2000 against 1000 conflict resolved to 1000 [Fact Pack Sec 5, PROVISIONAL conflict; PROMPT C1 C2]. Out-of-order messages ordered by availability time. Duplicates deduplicated by venue event plus bar open. Gaps mark range provisional and refuse validation needing missing bars. Corrections create superseding records, never silent mutation. Schema evolution is versioned with migration audit. Reconstructed candles after WS disconnect are provisional until REST repair confirms final. Stale feed is age against bar interval plus funding schedule plus monotonic deadline; breach trips data interlock.

Quarantine: depth never sizes per NON_REPRODUCIBLE [C8]; historical open interest disabled per UNRESOLVED [C26]; markPrice and klines.change never decide per CONFLICTED [C13]; 5-minute and below proxy never extends history; 1-hour and 4-hour proxy carries lineage for research and backtest only [C18].

Retention: raw VENUE_DIRECT bars for validated universe plus funding ticks plus ledger plus audit retained within D15 budget. Narrow load about 464 MB derived in Rev Part 3/6. Research bars retained separately with lineage and smaller bound. Audit retained longest with hash chain. Storage pressure trips degradation before corruption: shed research retention first, then context timeframes, never ledger or audit.

R4.3 Independent risk authority
Authority hierarchy: risk catalog in Rev Part 2/6 Section R2.2 governs; RISK component enforces; no forecast, calibration, optimizer, allocator, or Telegram command overrides veto per RQ-021. Original D17 governs every other parametric input with units and sensitivity.

Evaluation order for every risk-increasing intent, in order, fail-fast with named reason:

Mode equals Live or Paper with isolation pass; config hash equals approved.
Clock offset within bound; data validity fresh with clean lineage.
Reconciliation equality holds; no UNKNOWN overhang beyond declared mismatch handling.
Equity snapshot fresh with net construction inclusive of unrealized, fees, settled plus accrued funding.
Per-trade estimate EstNetLoss <= 0.05 E_curr with up-rounding, fees at 0.06 percent legs, spread, slippage, funding horizon, partial-fill worst case, gap add-on.
Atomic aggregate reservation Agg + EstNetLoss <= 0.15 min(E0,E_curr); pending counted from durability time.
Daily veto check RealizedDay > -0.10 E_day_ref; veto blocks entries, adds, leverage increases, new pending risk.
Effective leverage GrossNotional / E_curr_net <= 5 and at or below verified symbol tier; hedge LONG plus SHORT summed gross.
Drawdown Draw / E0 < 0.15; breach latches independently of daily reset.
Holding projection within derived MaxHolding; funding tail bounded inside budget.
Continuous gates re-evaluate on every fill, partial fill, funding settlement, correction, bar close, and latch event. Missing, corrupt, stale, contradictory, or unverifiable input fails closed.

Action taxonomy so veto never blocks a needed exit and never permits an unsafe entry:

Risk-increasing: new entry, add, leverage increase, new pending risk, amend increasing quantity or adverse price exposure.
Risk-reducing with confirmed semantics: cancel pending by venue-confirmed cancel, close or reduce with opposite-side MARKET or LIMIT using listed fields, amend decreasing quantity. No invented reduce-only, stop-market guarantee, or emergency-order flag is assumed because none is listed [Fact Pack Sec 3]. If a reduction route cannot use confirmed semantics, the design parks safely and discloses the limitation.
Neutral: read-only review, alert acknowledgement without re-arm, research export.
Kill Switch: authenticated Telegram halt latches Live disabled and cancels risk-increasing pending through confirmed cancel path; open exposure managed by pre-authorized exits only. Latches:

Latch	Trigger	Reset
Drawdown 15 percent E0	Draw >= 0.15 E0	Authenticated re-baselining only; survives UTC midnight
Daily veto 10 percent	RealizedDay <= -0.10 E_day_ref	Next 00:00:00 UTC only
Reconciliation halt	exchange not equal ledger or UNKNOWN unresolvable	Equality re-established plus authenticated acknowledgement
Clock halt	skew beyond bound or monotonic fault	Fresh server-time proof plus acknowledgement
Config halt	hash mismatch	Approved version plus acknowledgement
Credential halt	permission probe or signing contract failure	Valid probe plus acknowledgement
Re-arm requires allowlisted principal, fresh nonce, timestamp window, explicit acknowledgement command, and audit event. No auto-resume into Live.

R4.4 Execution and Order Management System
Order construction, exact listed subset: POST /api/v2/futures/order weight 1 with symbol, side BUY or SELL, positionSide LONG or SHORT, type LIMIT or MARKET, newClientOrderId, timestamp, plus quantity or valueQuantity with at least one non-zero; TIF GTC default, FOK, IOC, POST_ONLY; conditional price for LIMIT, stopPrice, takeProfit, stopLoss, tpTriggerBy or slTriggerBy CONTRACT_PRICE or MARK_PRICE, tpOrderType or slOrderType MARKET or LIMIT, stopOrderType TAKE_PROFIT or STOP_LOSS, stopType FIXED_STOP or TRAILING_STOP [Fact Pack Sec 3, SOURCE_VERIFIED supplied status]. Amend is LIMIT-only by orderId or origClientOrderId weight 2. Cancel is DELETE weight 1 by one identity, mutually exclusive. Batch create weight 2, batch cancel weight 3. Beyond-listed semantics are UNRESOLVED. Charset A-Za-z0-9_- binding [C11]. Weakest per-account uniqueness assumed with local nonce uniqueness enforced; identifier never reused after ambiguous outcome [Fact Pack Sec 3, UNRESOLVED scope].

Durability order: validate intent, reserve aggregate, persist client identity with nonce in write-ahead log, persist attempt record, then transmit. Only then is send attempted.

State model: Toobit-confirmed states used are NEW and CANCELED only as observed. All other uppercase states below are local abstractions, explicitly not venue enums.

text

LOCAL: IDLE -> VALIDATED -> RISK_RESERVED -> IDENTITY_DURABLE ->
 ATTEMPT_RECORDED -> SUBMITTING -> UNKNOWN on 5XX/timeout/-1007
SUBMITTING -> NEW(exchange-observed) -> PARTIAL_LOCAL -> FILLED_LOCAL
SUBMITTING -> REJECTED_LOCAL on explicit rejection
NEW -> CANCEL_REQUESTED_LOCAL -> CANCELED(exchange-observed)
Amend: NEW -> AMEND_REQUESTED_LOCAL -> NEW on venue confirmation
UNKNOWN -> RECONCILING_LOCAL -> NEW | PARTIAL_LOCAL | FILLED_LOCAL |
 REJECTED_LOCAL | CANCELED | MISMATCH_TERMINAL_LOCAL
MISMATCH_TERMINAL_LOCAL halts new risk and preserves full reservation.
Timeout and -1007 TIMEOUT never prove rejection; no automatic resubmit until lookup and reconciliation by client identity [C5; Fact Pack Sec 4 partial catalog; full catalog UNRESOLVED with locator api-docs.toobit.com/api/usdt-m-error-codes.html, NOT INSPECTED]. Rate violation -1003 with Hypertext Transfer Protocol 429 and order burst -1015 with 429, Web Application Firewall 403, and 5XX unknown are handled on distinct paths [Fact Pack Secs 2, 4]. Fixed-weight accounting is the safe baseline; header deltas are optional enhancement only if observed [C4 conflict, conservative branch].

Reconciliation compares venue positions, orders, fills by client identity against LED on startup, periodically, pre-entry, post-fill, and after every UNKNOWN. Equality uses venue truth for exchange state and preserves reservation until venue-confirmed reduction. Position accounting uses contract multiplier examples 0.001 for BTC-SWAP-USDT and 0.01 for ETH-SWAP-USDT as examples only [Fact Pack Sec 9, SOURCE_VERIFIED as examples]; per-symbol minima remain UNRESOLVED from exchangeInfo discovery and block sizing until observed.

R4.5 Telegram sole interface and Paper and Live semantics
Singleton bot only. Internal health tasks emit through the bot; they are not a second interface.

Command catalog with preconditions:

Command	Precondition	Effect
`/mode paper	live`	Allowlisted chat, nonce, window, isolation checks pass
/status /positions /ledger /config_show	Authenticated read	Read-only export with UTC roles
/config_set	Authenticated plus explicit /ack plus hash re-approval	Versioned change; mismatch halts Live
/halt	Authenticated	Kill Switch latches Live disabled
/resume	Authenticated plus all latches cleared by rule	Re-arm only where reset rule permits
/ack	Fresh nonce	Confirms named refusal or latch event
/help	Authenticated	Lists commands and refusal meanings
Privileged acts require allowlisted identifier, timestamp window, single-use nonce, explicit confirmation, charset and range validation, token-bucket rate limit, and idempotent handling. Push covers fills, refusals with reason, interlock trips, reconciliation mismatch, clock drift, funding anomaly, outage entry and exit. Long-poll is selected; webhook with relay is feasible only with a provisioned always-on host and is not assumed. Loss semantics per RQ-009: no new risk while unreachable, pre-authorized exits only, pending reconciled on next valid window, uncertain never marked confirmed, gap audited for later review.

Paper and Live separation: isolated configuration, isolated state and ledger, isolated data path with cross-venue bytes unreachable from both, separate order-sending boundary where Paper path has no transmit capability by construction. Mode switch is atomic: freeze intent, confirm no in-flight UNKNOWN unless handled as terminal, carry or flatten open handling explicitly per switch record, re-run all six interlocks for Live entry, emit audit event. Switch aborts to prior mode on any isolation failure. Paper is internal simulation only and is not proof of a Toobit testnet; the no-sandbox-wired-in-CCXT wording is not overgeneralized [Fact Pack Sec 1].

Six interlocks gate Live entry and each risk-increasing act to the extent of its safety purpose: data validity, exchange equals ledger, all hard risk limits, credential and permission validity, configuration integrity, clock validity. Each refusal names the gate. No wait and no profit hurdle exists.

R4.6 Security and supply chain
Threats addressed: forged Telegram command, replay, injection, flood, token compromise, secret disclosure, permission excess, dependency tampering, audit tampering, backup disclosure, malicious config change, stale-cache trade, degraded-subsystem bypass. Controls: allowlisted principals, nonce plus window anti-replay, validated fields, rate limits, parameterized handling, least-privilege API permissions for the future system, Hash-based Message Authentication Code signing with millisecond timestamp and recvWindow within 5000 default and 60000 maximum and 1000 ms future-skew reject [Fact Pack Sec 1], encrypted secret store at rest with in-memory minimization for the future implementation, privilege separation between ingestion, risk, OMS, and interface tasks, append-only hash-chained audit, confidential backup with separate key, incident response of halt plus rotate plus re-authenticate plus reconcile before resuming. Token compromise procedure halts Live until rotation out-of-band and re-authentication. Dependency inventory is maintained as a pinned list; full Software Bill of Materials is produced only if the eventual stack justifies the overhead, with positive record at handoff. Penetration testing is out of scope and NOT TESTED.

R4.7 Reliability, operations, deployment, phases
Design targets, explicitly not measured results: bar-close processing target below one half bar interval as DESIGN_JUDGMENT NOT TESTED; Recovery Time Objective target of safe-park within one execution-bar close after fault detection; Recovery Point Objective of zero committed order attempts lost because of write-ahead durability, with at most one provisional bar under repair. Monitoring is local health plus Telegram alerts only. Circuit breakers exist on rate budget, stale feed, reconciliation mismatch, and consecutive UNKNOWN outcomes. Degradation order sheds research retention, then context timeframes, then breadth to baseline, never ledger or audit. Restart behavior is reconcile-first. Backup is encrypted ledger plus config plus audit snapshot. Disaster recovery is re-provision from backup plus discovery plus reconciliation, with Live remaining refused until all interlocks pass.

Deployment follows Rev Part 3/6 enumeration: interim E-T1 narrow on POCO X6 Termux with E-T3 breadth to depth to capability contraction armed; E-T2 and E-T4 only with owner-provisioned host. D16 phases derived from risk and verification: P0 frozen design, P1 offline validation with counted trials, P2 Paper simulation with isolation proof, P3 gated Live with continuous interlocks. No phase boundary uses elapsed wait or profit threshold.

R4.8 Traceability to register
RQ-001 venue bound; RQ-002 singleton; RQ-003 UTC roles; RQ-005 firewall structural; RQ-006 day-boundary default; RQ-008 E-T1 plus E-T3; RQ-009 loss safe; RQ-010 six gates plus selector; RQ-011 derivation with exclusions; RQ-013 pointers with statuses; RQ-015 through RQ-021 risk order and latches; RQ-022 through RQ-034 contracts with conservative branches; RQ-035 Paper and Live isolation; RQ-036 privilege controls. RQ-004, RQ-012, RQ-014, RQ-037 govern engagement, statistics, offline boundary, and verification and are preserved.

R4.9 Incremental Artifact Registry — Rev Part 4/6 state
Artifact Identifier	Artifact name	Phase produced	Message reference	Status	Content description
ART-R-001	Offline inventory, perimeter, checkpoint, plan	Pass A	Rev Part 1/6	DELIVERED	Capability honesty, perimeter, gaps, checkpoint, graph, acronyms.
ART-R-002	Canonical Requirements Register with 11 fields and risk catalog	Pass B	Rev Part 2/6	DELIVERED	37-row table, six D-RISK limits, interactions, sensitivity.
ART-R-003	Clean-sheet baseline, strategy candidate, universe, statistics, envelope	Pass C	Rev Part 3/6	DELIVERED	B0 and C1, D14, D19, D15, trial budgets.
ART-R-004	Integrated architecture and contracts	Pass F	Rev Part 4/6	DELIVERED	This message: Sections R4.1 through R4.8.
ART-R-005	Verification Matrix, test specifications, arithmetic walks	Passes F through H	Rev Part 5/6	DEFERRED	Needs integrated design; matrix rows must equal 37.
ART-R-006	Findings, propagation, self-audits, completeness, acceptance	Passes D through H	Rev Part 6/6	DEFERRED	Needs all prior artifacts; V-1 through V-12.
R4.10 Rev Part 4/6 completeness declaration — part scope only
text

Declared sections = 10, namely R4.1 through R4.9 plus Persian note = 10
Components with owner and failure policy = 10
Order lifecycle states modeled = 14 with local against exchange distinction
Interlocks enforced = 6 with named refusals
Telegram commands specified = 7 families
Latches specified = 6 with reset rules
Registry rows = 6, with 4 DELIVERED and 2 DEFERRED with reasons
Total part-scope items = 10 + 10 + 14 + 6 + 7 + 6 + 6 = 59
10 + 10 = 20; 20 + 14 = 34; 34 + 6 = 40; 40 + 7 = 47; 47 + 6 = 53; 53 + 6 = 59
Rev Part 4/6 verdict: complete for declared scope. No truncation. No remote verification claimed. No Live action performed. No profitability claim made.

یادداشت فارسی مالک — پیشرفت بسته بازبینی، بخش ۴ از ۶:
معماری یکپارچه با مرز داده تحقیقاتی و لایو، مرجع مستقل ریسک، ماشین سفارش با حالت نامشخص پایدار و بدون ارسال مجدد کور، ربات واحد تلگرام با رفتار امن هنگام قطعی، جدایی ساختاری شبیه‌سازی و لایو، امنیت و عملیات بازیابی تحویل شد. همه رفتارهای حساس به صراحت fail-closed طراحی شدند و هیچ قابلیت صرافی خارج از بسته شواهد فرض نشد. هیچ اتصال، تست زنده، سفارش یا اقدام لایو انجام نشد. ادامه: بخش ۵ از ۶ — ماتریس راستی‌آزمایی، طرح تست‌ها و محاسبات بازتولیدشده.


بسته ۵ از ۶ — ماتریس راستی‌آزمایی و محاسبات.# Rev Part 5/6 — Verification Matrix, Test Specifications, Arithmetic Walks (ART-R-005)

> **Rev Part 5/6 scope:** this message delivers **ART-R-005 only**.
> Inputs: ART-R-001 perimeter, ART-R-002 37-row register and risk catalog, ART-R-003 baseline and envelope, ART-R-004 integrated contracts.
> Output: normative Verification Matrix with one row per requirement, design-only test specifications, three reproduced arithmetic walks, design-only Definition of Done.
> No implementation, backtest execution, Paper operation, exchange call, production deployment, or Live authorization. All unexecuted tests are `NOT TESTED`. All endpoint calls are `BLOCKED` in this design engagement.
> All monetary quantities in United States Dollar Tether (**USDT**). All time in Coordinated Universal Time (**UTC**).

## R5.1 Method and status semantics

`SOURCE_CHECK` means inspection of a source already supplied in conversation or message. It never means opening a Uniform Resource Locator or retrieving a new source. Contract review, schema review, state-machine review, arithmetic review, and test-plan specification are completed on supplied data. Actual endpoint invocation, live-data retrieval, and integration execution are prohibited and remain `BLOCKED` and `NOT TESTED`.

Acceptance labels:

* `PASS`: observed design content satisfies declared criterion.
* `FAIL`: observed content violates criterion.
* `BLOCKED`: required remote source, access, resource, or authorization is outside permitted environment.
* `NOT TESTED`: test or measurement has not been executed.
* `UNRESOLVED`: underlying fact or decision is not established or is conflicting.
* `PROVISIONAL`: working value with stated resolution path.
* `DESIGN_JUDGMENT`: reasoned choice under incomplete evidence with stated consequence.
* `SOURCE_VERIFIED`: supplied-source status inside the Fact Pack. It does not mean independent re-verification in this session.

Source status and execution status are reported separately in every matrix row. Deflated Sharpe Ratio (**DSR**), Minimum Backtest Length (**MinBTL**), Minimum Live Track-Record Length (**MinTRL**) are defined here on first use in this part.

## R5.2 Normative Verification Matrix — 37 rows equal to register

One row per `RQ-001` through `RQ-037`. No missing row. No phantom row. Multiple procedures may appear inside one row.

| Req | Checks | Criterion | Evidence and status | Verdict |
|---|---|---|---|---|
| RQ-001 | Config inspection plus Live-gate review [T-R-02] | LiveVenue equals Toobit-Perp; other LiveAllowed equals False | Fact Pack Sec 1 base URLs supplied SOURCE_VERIFIED; URLs NOT INSPECTED; call BLOCKED | PASS design; NOT TESTED exec; BLOCKED verification step |
| RQ-002 | Interface inventory inspection plus demonstration [T-R-03] | Singleton bot; routine parallel count equals zero | No Telegram access in session; behavior NOT TESTED | PASS design; NOT TESTED exec |
| RQ-003 | Inspection plus UTC day and week boundary analysis [T-R-04] | Timezone UTC; null role count zero; monotonic for deadlines | General clock knowledge; measurement NOT TESTED | PASS design; NOT TESTED exec |
| RQ-004 | Engagement-output audit [T-R-01] | Authenticated-call count zero; order-action count zero | Observed zero in Rev Parts 1 through 5; PASS for scope | PASS |
| RQ-005 | Lineage-tag inspection plus structural isolation review plus negative-path walkthrough [T-R-05] | No Paper path and no Live path consumes cross-venue bytes; every import tagged | PROMPT C17 C18 summary; isolation drill NOT TESTED | PASS design; NOT TESTED exec |
| RQ-006 | Derivation-record analysis [T-R-06] | Intent intraday; MaxHolding equals derived minimum; no fixed constant | Fact Pack Sec 6 frequency supplied SOURCE_VERIFIED; value UNRESOLVED | PASS method; UNRESOLVED value; NOT TESTED exec |
| RQ-007 | Feasibility-comparison analysis [T-R-07] | Universe derived; symbol rationale distinct from timeframe rationale; C19 weight zero | Fact Pack Sec 10 partial list PROVISIONAL; discovery NOT TESTED and BLOCKED | PASS method; UNRESOLVED membership; NOT TESTED exec |
| RQ-008 | Envelope analysis plus measurement-plan inspection [T-R-08] | Steps 1 through 4b evidenced; deviation discloses four items | C14 C15 C16 snapshot; sustained NOT MEASURED; C19 unit used | PASS process; NOT TESTED sustained |
| RQ-009 | Loss-injection walkthrough [T-R-03] | Loss is safe state; limit release on loss False; uncertain stays uncertain | PROMPT A9; drill NOT TESTED | PASS logic; NOT TESTED drill |
| RQ-010 | Six-gate trip walkthrough plus selector-transaction review [T-R-09] | LiveAllowed equals AND of six; each refusal named; zero wait or profit hurdle | Six-gate list confirmed in supplement; runtime trip NOT TESTED | PASS logic; NOT TESTED exec |
| RQ-011 | Derivation inspection plus question audit [T-R-01] | Every inclusion positively derived; owner technical-selection count zero | Observed zero in this revision; PASS for scope | PASS |
| RQ-012 | Statistical analysis plus trial-budget audit [T-R-11] | 12h grid rejected; pre-registration with counted trials; deflated plus out-of-sample plus Paper required | C20 C21 C22 C23 C24 preserved; backtest NOT TESTED | PASS method; UNRESOLVED per-hypothesis thresholds |
| RQ-013 | Cross-reference and provenance audit [T-R-12] | Every Toobit claim carries exact pointer with status; missing labeled UNRESOLVED | Fact Pack Secs 1 through 13 statuses preserved; no URL opened | PASS |
| RQ-014 | Action and citation audit [T-R-01] | Remote-access count zero; external locator marked NOT INSPECTED | Observed zero remote calls in Rev Parts 1 through 5; PASS for scope | PASS |
| RQ-015 | Policy-enforcement inspection plus boundary analysis [T-R-10] | Draw divided by E0 at or beyond 0.15 latches; 20 percent never operative | Supplement Sec 1.1 canonical; live measurement NOT TESTED | PASS definition; NOT TESTED exec |
| RQ-016 | Sizing-formula inspection plus stale-input walkthrough [T-R-10] | EstNetLoss at or below 0.05 current equity; uncertain fails closed | Contract filters UNRESOLVED per Fact Pack Sec 9; sizing proof BLOCKED | PASS definition; UNRESOLVED inputs; NOT TESTED exec |
| RQ-017 | Fixed-constant inspection plus walk review [W1 in R5.4] | No embedded USDT constant; sensitivity 100 to 500 recomputed per cell | Basis 200 fixed for planning; feasibility without filters UNRESOLVED | PASS |
| RQ-018 | Reservation-logic inspection plus race analysis [T-R-10] | Reserved sum at or below 0.15 minimum of E0 and current; unknown blocks new risk | Supplement Sec 1.4; concurrency test NOT TESTED | PASS definition; NOT TESTED exec |
| RQ-019 | UTC-day accounting inspection plus veto and reset walkthrough [T-R-10] | Realized day at or below minus 0.10 reference vetoes until 00:00:00 UTC next day | Denominator DESIGN_JUDGMENT; no invented reduce semantics; accounting NOT TESTED | PASS definition; NOT TESTED exec |
| RQ-020 | Leverage-formula inspection plus tier review [T-R-10] | Gross divided by net at or below 5 and at or below verified tier; lesser governs | Fact Pack Sec 8 example 200 times plus PROVISIONAL alts; margin PROVISIONAL | PASS definition; UNRESOLVED tier; NOT TESTED exec |
| RQ-021 | Hierarchy inspection plus override-attempt walkthrough [T-R-10] | Veto precedes execution; override success count zero; uncertain equals refuse | Control-architecture reasoning; override test NOT TESTED | PASS design; NOT TESTED exec |
| RQ-022 | Contract-field SOURCE_CHECK [T-R-13] | Header plus HMAC-SHA256 lowercase hex plus millisecond plus recvWindow within 5000 default and 60000 max plus 1000 ms skew bound | Fact Pack Sec 1 supplied SOURCE_VERIFIED; signing detail beyond listed UNRESOLVED; call BLOCKED | PASS contract subset; UNRESOLVED remainder; BLOCKED call |
| RQ-023 | Rate-budget arithmetic plus header-absent walkthrough [W2 in R5.4] | Budget never exceeds 3000 per minute and 60 per 2 seconds under fixed weights | Fact Pack Sec 2 weights supplied SOURCE_VERIFIED; C4 conflict conservative branch; live headers NOT TESTED | PASS baseline; NOT TESTED live |
| RQ-024 | Field-mapping SOURCE_CHECK plus schema review [T-R-13] | Only listed v2 fields used; amend LIMIT-only; cancel identity exclusive | Fact Pack Sec 3 supplied SOURCE_VERIFIED; beyond-listed UNRESOLVED; integration BLOCKED | PASS subset; BLOCKED integration |
| RQ-025 | Charset and uniqueness review [T-R-13] | Charset A-Za-z0-9_- enforced; per-account uniqueness; no reuse after ambiguous | C11 binding; Fact Pack examples within set; scope UNRESOLVED conservative | PASS |
| RQ-026 | State-machine review plus ambiguous-outcome walkthrough [T-R-13] | UNKNOWN persists until lookup; resubmit-without-reconciliation count zero | -1003 supplied SOURCE_VERIFIED; -1007 ambiguous per C5; full catalog UNRESOLVED; error page NOT INSPECTED | PASS logic; UNRESOLVED catalog; BLOCKED exchange test |
| RQ-027 | Mapping-table SOURCE_CHECK [T-R-07] | Every venue symbol through canonical identity; unmapped blocked | Futures BTC-SWAP-USDT and ETH-SWAP-USDT distinct from spot BTCUSDT | PASS |
| RQ-028 | Discovery-requirement SOURCE_CHECK [T-R-07] | Discovery precedes sizing; missing filter blocks that symbol | Fact Pack Sec 9 endpoint existence supplied SOURCE_VERIFIED; values NOT extracted therefore UNRESOLVED; fetch BLOCKED | PASS containment; UNRESOLVED values; BLOCKED fetch |
| RQ-029 | Pagination-budget arithmetic plus SOURCE_CHECK [W2 in R5.4] | Pagination bound 1000; 3500 cap not guarantee; 14 ceiling kept; 3d excluded | C1 RATIFIED_FINDING; C2 cap; WS 11-list for that list only; 2000 against 1000 resolved to 1000 | PASS handling; NOT TESTED depth |
| RQ-030 | Cost-inclusion review plus SOURCE_CHECK [T-R-14] | Horizon funding with tail add-on in every estimate; no bounded-cost claim | Fact Pack Sec 6 endpoints supplied SOURCE_VERIFIED; caps 2.0000 to 3.0000 percent PROVISIONAL; C7 refutation preserved | PASS with PROVISIONAL caps; NOT TESTED call |
| RQ-031 | NetEdge arithmetic review plus SOURCE_CHECK [W1 in R5.4] | Acceptance uses 0.06 percent legs plus spread plus slippage plus funding; 0.05 shown only as sensitivity | Futures 0.02 maker and 0.06 taker supplied SOURCE_VERIFIED; 0.05 UNRESOLVED; tier NOT TESTED | PASS default; NOT TESTED tier |
| RQ-032 | Tier SOURCE_CHECK [T-R-07] | No universal maximum; symbol maximum UNRESOLVED until riskLimits observed; 5 times still binds | BTC 200 times example; alts PROVISIONAL; ladder RATIFIED_FINDING; call BLOCKED | PASS containment; UNRESOLVED maxima |
| RQ-033 | Margin-dependence SOURCE_CHECK [T-R-14] | Margin-dependent logic disabled or constrained until mode confirmed | Fact Pack Sec 9 Cross and Isolated PROVISIONAL; confirmation BLOCKED | PROVISIONAL; BLOCKED confirmation; PASS containment |
| RQ-034 | Heartbeat plus gap plus quarantine walkthrough [T-R-14] | Ping with pong and 5-minute disconnect; stale trips data gate; depth never sizes; OI disabled; conflicted never decides | Heartbeat supplied status; depth NON_REPRODUCIBLE; markPrice CONFLICTED; OI UNRESOLVED; feed NOT TESTED | PASS logic; NOT TESTED feed |
| RQ-035 | Boundary inspection plus switch-transaction review [T-R-02] | Atomic switch with audit; Paper cannot transmit; Live cannot consume cross-venue | No-sandbox-wired wording not overgeneralized; drill NOT TESTED | PASS design; NOT TESTED drill |
| RQ-036 | Threat-model review plus privileged-action walkthrough [T-R-15] | Every privileged act authenticated plus authorized plus validated plus nonce-checked plus rate-limited plus audited | No secrets handled; controls from general security knowledge; penetration test out of scope | PASS design; NOT TESTED penetration |
| RQ-037 | Cross-reference audit plus count reconciliation [T-R-16 and W3 in R5.4] | Matrix count equals register count; V-1 through V-12 tabled; targets labeled; no readiness claim | Prior blueprint available as candidate; V-checks in Rev Part 6/6 | PASS obligation; execution evidence NOT TESTED |

Count check: register rows 37 partitioned 14 plus 7 plus 13 plus 3. 14 plus 7 equals 21. 21 plus 13 equals 34. 34 plus 3 equals 37. Matrix rows counted RQ-001 through RQ-037 inclusive equals 37. Equality 37 equals 37 holds.

## R5.3 Design-only test specifications

Each specification is a plan only. Execution status is `NOT TESTED`. Remote-dependent confirmation is `BLOCKED`. No test has been run.

**T-R-01 Engagement and offline boundary.** Objective: prove zero disallowed acts and zero technical-selection questions. Setup: all Rev Part messages with hashes. Steps: search outputs for secrets, authenticated calls, order directives, remote-fetch claims, owner technical-selection questions. Expected: zero findings. Maps to RQ-004, RQ-011, RQ-014. Status NOT TESTED as formal run; observed scope PASS in draft.

**T-R-02 Venue and mode isolation.** Objective: prove Toobit-only Live and Paper non-transmission. Setup: venue config plus mode flag plus isolated stores. Steps: attempt non-Toobit Live route; attempt Paper transmit; attempt cross-venue byte into Paper and Live inputs. Expected: all three refused with audit. Maps to RQ-001, RQ-035. Status NOT TESTED.

**T-R-03 Singleton interface and loss.** Objective: prove one bot and safe loss. Setup: interface inventory plus single open position plus one pending order plus 1-hour inbound drop. Steps: count routine interfaces; drop inbound; attempt limit release by loss; replay privileged mode command; flood. Expected: count zero parallel; no release; no unsafe unblock; uncertain stays uncertain; replay and flood rejected. Maps to RQ-002, RQ-009. Status NOT TESTED.

**T-R-04 UTC roles and monotonic deadlines.** Objective: prove tagging and deadline discipline. Setup: synthetic bars across daylight boundary and UTC day and ISO-8601 week boundary with six role fields. Steps: inject 500 ms server offset; inject 5 s pause; deliver out-of-order poll. Expected: ordering uses availability time; deadlines use monotonic; offset breach trips clock gate. Maps to RQ-003. Status NOT TESTED.

**T-R-05 Research firewall and lineage.** Objective: prove structural separation. Setup: tagged proxy bar with source, window, 0.56 basis points, 0.999755 correlation. Steps: feed proxy to research input, Paper input, Live input; attempt promotion as bars. Expected: research accepts with tag; Paper and Live reject; promotion passes only versioned parameters through validation gate. Maps to RQ-005. Status NOT TESTED.

**T-R-06 Duration derivation.** Objective: prove no fixed constant. Setup: exit-quantile, funding-bound, risk-horizon, validation-horizon, UTC-day inputs. Steps: remove one input; attempt overnight hold on context-timeframe justification. Expected: bound contracts to shortest evidenced leg; context justification refused. Maps to RQ-006. Status NOT TESTED.

**T-R-07 Universe, mapping, discovery, tiers.** Objective: prove validated-only trading. Setup: census snapshot, candidate symbols, canonical map, missing-filter symbol, missing-tier symbol. Steps: filter to active perpetual; map futures against spot; attempt sizing without `minQty` or `stepSize` or `tickSize`; attempt leverage increase without tier. Expected: unvalidated blocked; unmapped blocked; BTCUSDT never equated to BTC-SWAP-USDT. Maps to RQ-007, RQ-027, RQ-028, RQ-032. Status NOT TESTED and BLOCKED for fetch.

**T-R-08 Envelope and reduction.** Objective: prove snapshot fit and ordered contraction. Setup: narrow load about 464 MB, snapshot 56 GB free, sustained NOT MEASURED. Steps: measure bursty bar-close central processing unit and working set; inject storage pressure and Doze kill. Expected: narrow fits snapshot; breach triggers breadth then depth then capability contraction with gap log. Maps to RQ-008. Status NOT TESTED.

**T-R-09 Interlocks and selector.** Objective: prove six gates with no hurdle. Setup: six independent fault injections. Steps: trip data, reconciliation, risk, credential, config, clock singly; attempt Live with stale pass; attempt Paper or Live switch with pending UNKNOWN. Expected: six distinct named refusals; LiveAllowed False; zero time or profit condition. Maps to RQ-010. Status NOT TESTED.

**T-R-10 Risk authority and five money gates.** Objective: prove veto precedence and arithmetic. Setup: symbolic equity and full estimate terms in Section R5.4 Walk W1. Steps: sweep planning equities 100, 200, 300, 500; inject concurrent racers; inject stale input; attempt optimizer relaxation; attempt Telegram override. Expected: entry refused on any breach or uncertain input; pending reserves atomically; override success zero. Maps to RQ-015, RQ-016, RQ-017, RQ-018, RQ-019, RQ-020, RQ-021. Status NOT TESTED.

**T-R-11 Statistical validity.** Objective: prove multiple-testing control. Setup: pre-registered set with declared effective trials, walk-forward UTC splits with embargo. Steps: attempt 12h grid; attempt 5-minute proxy validation; compute deflated metric with skew and kurtosis; check MinBTL against MinTRL gap. Expected: grid rejected; proxy rejected; non-deflated promotion rejected; trial counter increments on rejects. Maps to RQ-012. Status NOT TESTED.

**T-R-12 Provenance honesty.** Objective: prove no upgrade and no invention. Setup: every Toobit claim with pointer and status. Steps: audit for invented endpoint, field, code, filter, timeframe, tier, margin behavior; verify conflict branches conservative. Expected: zero upgrades; missing labeled UNRESOLVED with path. Maps to RQ-013. Status PASS for draft scope by inspection.

**T-R-13 Exchange contracts and durability.** Objective: prove exact construction and no blind resubmit. Setup: single-flight nonce identity, documented v2 fields, weight budgets. Steps: submit invalid construction; amend non-LIMIT; cancel with both identities; inject 429, 403, 5XX, timeout, -1007; kill before acknowledgement; duplicate submit. Expected: invalid refused locally; ambiguous stays UNKNOWN; lookup before retry; no double submit; mismatch halts new risk. Maps to RQ-022, RQ-023, RQ-024, RQ-025, RQ-026. Status NOT TESTED and BLOCKED for calls.

**T-R-14 Data, funding, cost, feed, margin.** Objective: prove pagination, tail funding, conservative costing, heartbeat, quarantine. Setup: 1000-bound pagination, 8-hour and 4-hour settlement cadence, 0.06 percent legs, heartbeat 5-minute limit, depth snapshot, open-interest feature, conflicted fields. Steps: paginate full cap; estimate multi-settlement hold; cost with 0.05 sensitivity; drop heartbeat; attempt depth sizing and open-interest filter and mark-price decision. Expected: cap never assumed; tail add-on required; depth never sizes; dependent features disabled. Maps to RQ-029, RQ-030, RQ-031, RQ-033, RQ-034. Status NOT TESTED.

**T-R-15 Telegram privilege and security.** Objective: prove authenticated control and compromise handling. Setup: allowlisted principal, nonce store, rate bucket, audit chain. Steps: attempt non-allowlisted command, expired timestamp, reused nonce, oversized message, invalid charset, token compromise. Expected: all rejected and audited; compromise halts Live until rotation and re-authentication. Maps to RQ-036 and RQ-002. Status NOT TESTED.

**T-R-16 Traceability and completeness.** Objective: prove counts reconcile. Setup: register, matrix, artifact registry, V-series table. Steps: count rows, verify 37 equals 37, verify identifiers used after definition, verify formulas with units. Expected: equality holds; no orphan; no duplicate definition. Maps to RQ-037. Status PASS for draft scope by inspection.

## R5.4 Three reproduced arithmetic walks with units and steps

### Walk W1 — Risk budgets and one estimated trade in USDT

Inputs: `E0` equals 200.00 USDT. `E_curr` equals 200.00 USDT. `E_day_ref` equals 200.00 USDT. Owner rates 0.05, 0.15, 0.10, 0.15, leverage 5. Trade illustration notional `N` equals 300.00 USDT. Adverse stop fraction 0.02. Fee rate 0.0006 per leg. Spread illustration 0.0002 per side as DESIGN_JUDGMENT, not verified. Slippage allowance 0.20 USDT. Funding-horizon estimate 0.10 USDT. Rounding up 0.05 USDT. Partial remainder 0.00 USDT. Gap add-on 1.00 USDT.

Formulas:

```
B_trade equals E_curr times 0.05
B_agg equals minimum(E0,E_curr) times 0.15
B_day equals E_day_ref times 0.10
Allow_draw equals E0 times 0.15
MaxGross equals E_curr_net times 5
FeeRoundTrip equals N times 0.0006 times 2
GrossAtStop equals N times stop_fraction
SpreadEst equals N times 0.0002 times 2
EstNetLoss equals GrossAtStop plus FeeRoundTrip plus SpreadEst plus Slip plus Funding plus Rounding plus Gap
```

Steps:

```
B_trade equals 200.00 times 0.05 equals 10.00 USDT
B_agg equals 200.00 times 0.15 equals 30.00 USDT
B_day equals 200.00 times 0.10 equals 20.00 USDT
Allow_draw equals 200.00 times 0.15 equals 30.00 USDT
MaxGross equals 200.00 times 5 equals 1000.00 USDT
GrossAtStop equals 300.00 times 0.02 equals 6.00 USDT
FeeRoundTrip equals 300.00 times 0.0006 times 2 equals 0.36 USDT
SpreadEst equals 300.00 times 0.0002 times 2 equals 0.12 USDT
EstNetLoss equals 6.00 plus 0.36 plus 0.12 plus 0.20 plus 0.10 plus 0.05 plus 1.00 equals 7.83 USDT
Check per-trade: 7.83 at or below 10.00 therefore passes standalone
Three concurrent: 7.83 times 3 equals 23.49 at or below 30.00 therefore passes aggregate
Four concurrent: 7.83 times 4 equals 31.32 above 30.00 therefore fourth refused
Realized two losses: 7.83 times 2 equals 15.66 below 20.00 therefore no veto; third realized loss would total 23.49 above 20.00 therefore veto
Gross check: 900.00 divided by 200.00 equals 4.50 at or below 5 therefore passes leverage
Declined equity: at E_curr 170.00, B_trade equals 8.50; same 7.83 still passes but headroom falls to 0.67 USDT
```

Result: one 300.00 USDT illustration with stated add-ons consumes 7.83 USDT of 10.00 USDT per-trade budget, one third of aggregate headroom in a three-position portfolio, and triggers daily veto on the third sequential realized loss. No rate varied. No feasibility claimed without verified filters.

### Walk W2 — Storage, pagination, and rate-limit budgets

Inputs: storage unit 1.25e9 bytes for 490000 candles. Narrow load 10 symbols times 4 timeframes times 3500 equals 140000 candles. Full load 134 times 14 times 3500 equals 6566000 candles. Index allowance 30 percent. Rate limits 3000 weight per 1 minute and 60 order requests per 2 seconds. Weights: ticker 40, positions 8.35, new order 1, cancel 1, update 2, batch create 2, batch cancel 3. Conservative kline response bound 1000 against 3500 cap. Heartbeat limit 5 minutes equals 300 s.

Steps:

```
Bytes per candle equals 1.25e9 divided by 490000 equals 2551.02, rounded 2551 bytes
Narrow raw equals 140000 times 2551 equals 357140000 bytes equals 357.14 MB decimal
Narrow with index equals 357.14 times 1.30 equals 464.28 MB
Full raw equals 6566000 times 2551 equals 16749866000 bytes equals 16.75 GB decimal
Full with index and outputs therefore above 20 GB, excluded for phone narrow target
Pagination per full-cap symbol-timeframe equals ceiling(3500 divided by 1000) equals 4 requests
Narrow pagination equals 40 combos times 4 equals 160 requests, paced under 3000 per minute
Read cycle example: 40 position reads times 8.35 equals 334.00 weight; 10 tickers times 40 equals 400.00 weight; sum 734.00 below 3000 therefore passes minute budget
Order burst example: 3 intents times weight 1 equals 3.00 below 60 per 2 s therefore passes order budget
Heartbeat example: ping every 60 s leaves 240 s margin below 300 s disconnect therefore passes design target
Kline endpoint weight is UNRESOLVED in Fact Pack; design paces reads and treats weight as unknown therefore conservative
```

Result: narrow universe fits snapshot storage with margin; full breadth does not fit phone target and independently fails statistical breadth; read and order examples use less than one quarter of minute budget and less than one twentieth of order burst budget under stated weights.

### Walk W3 — Sample size, trial budget, and completeness count

Inputs: listing proxy 4.86 years from 1774 daily sample. Days 1773.90. Bars per day: 24 at 1-hour, 96 at 15-minute, 6 at 4-hour. Reference DSR 1.5e-2 at N equals 100. MinTRL 19.54 years. PROVISIONAL 10 to 20 trials at 4-hour. Register partition 14 plus 7 plus 13 plus 3.

Steps:

```
Days equals 4.86 times 365 equals 1773.90 days
1h bars equals 1773.90 times 24 equals 42573.60, rounded 42574 bars
15m bars equals 1773.90 times 96 equals 170294.40, rounded 170294 bars
4h bars equals 1773.90 times 6 equals 10643.40, rounded 10643 bars
Non-overlapping 24h holds per span equals 1773 before dependence adjustment; autocorrelation and overlap reduce effective sample further
DSR reference means 100 uncorrected trials readily produce about 0.015 Sharpe under null; therefore 100-trial mining without deflation is rejected
10 to 20 PROVISIONAL trials at 4-hour are the only sparse budget; full grid at or below 12h rejected; 1-day thousands collapse after correction
MinTRL 19.54 years against 4.86 years available leaves gap 14.68 years; therefore live-significance claim BLOCKED in this engagement
Register total equals 14 plus 7 plus 13 plus 3 equals 37; 14 plus 7 equals 21; 21 plus 13 equals 34; 34 plus 3 equals 37
Matrix total RQ-001 through RQ-037 equals 37; 37 equals 37 therefore coverage holds
```

Result: sample supports sparse pre-registered hypotheses with embargo and deflation; breadth mining is statistically inadmissible; completeness equality holds with no orphan row.

## R5.5 Definition of Done — design-only

Done means every requirement has design disposition, every Toobit claim has exact pointer with status, every UNRESOLVED fact has resolution path plus safe interim plus consequence, every arithmetic walk shows units and intermediate steps, matrix count equals register count, V-1 through V-12 are tabled in Rev Part 6/6, and no claim of implementation, profitability, backtest success, Paper readiness, production readiness, or Live authorization is present. Service Level Objective, Recovery Time Objective, and Recovery Point Objective values are targets with `NOT TESTED` status. All 16 test plans are specified with execution `NOT TESTED` and remote confirmation `BLOCKED` where applicable.

## R5.6 Incremental Artifact Registry — Rev Part 5/6 state

| Artifact Identifier | Artifact name | Phase produced | Message reference | Status | Content description |
|---|---|---|---|---|---|
| ART-R-001 | Offline inventory, perimeter, checkpoint, plan | Pass A | Rev Part 1/6 | DELIVERED | Capability honesty, perimeter, gaps, checkpoint, graph, acronyms. |
| ART-R-002 | Canonical Requirements Register with 11 fields and risk catalog | Pass B | Rev Part 2/6 | DELIVERED | 37-row table, six D-RISK limits, interactions, sensitivity. |
| ART-R-003 | Clean-sheet baseline, strategy candidate, universe, statistics, envelope | Pass C | Rev Part 3/6 | DELIVERED | B0 and C1, D14, D19, D15, trial budgets. |
| ART-R-004 | Integrated architecture and contracts | Pass F | Rev Part 4/6 | DELIVERED | Data, risk, OMS, Telegram, security, Paper and Live. |
| ART-R-005 | Verification Matrix, test specifications, arithmetic walks | Passes F through H | Rev Part 5/6 | DELIVERED | This message: Sections R5.1 through R5.5. |
| ART-R-006 | Findings, propagation, self-audits, completeness, acceptance | Passes D through H | Rev Part 6/6 | DEFERRED | Needs all prior artifacts; V-1 through V-12 and final counts. |

## R5.7 Rev Part 5/6 completeness declaration — part scope only

```
Declared sections = 7, namely R5.1 through R5.6 plus Persian note = 7
Matrix rows = 37, equal to register rows 37
Test specifications = 16, namely T-R-01 through T-R-16 = 16
Arithmetic walks = 3, namely W1 risk plus W2 capacity and rate plus W3 stats and completeness = 3
Registry rows = 6, with 5 DELIVERED and 1 DEFERRED with reason = 6
Total part-scope items = 7 + 37 + 16 + 3 + 6 = 69
7 + 37 = 44; 44 + 16 = 60; 60 + 3 = 63; 63 + 6 = 69
```

**Rev Part 5/6 verdict:** complete for declared scope. No truncation. No remote verification claimed. No Live action performed. No profitability claim made.

---

*یادداشت فارسی مالک — پیشرفت بسته بازبینی، بخش ۵ از ۶:*
*ماتریس راستی‌آزمایی ۳۷به۳۷ برابر جدول الزامات، ۱۶ طرح تست طراحی-فقط، سه محاسبه بازتولیدشده ریسک و ظرفیت و آمار، و تعریف اتمام طراحی تحویل شد. همه تست‌های اجرایی تست‌نشده و همه فراخوانی‌های صرافی مسدود اعلام شدند و هیچ ادعای سودآوری یا آمادگی لایو نشد. ادامه: بخش ۶ از ۶ — کاتالوگ یافته‌ها، جدول انتشار تغییر، خودممیزی، اعلام تکمیل، پذیرش و اقدام بعدی.*


# Rev Part 6/6 — Findings, Propagation, Red-Team, Regression, Self-Audits, Completeness, Acceptance (ART-R-006)

> **Rev Part 6/6 scope:** this message delivers **ART-R-006 only** and closes the six-part revised package.
> Inputs: ART-R-001 perimeter, ART-R-002 37-row register and risk catalog, ART-R-003 baseline and envelope, ART-R-004 integrated contracts, ART-R-005 matrix and walks.
> No implementation, backtest execution, Paper operation, exchange call, production deployment, or Live authorization. All unexecuted tests are `NOT TESTED`. All remote confirmations are `BLOCKED` in this design engagement.
> All monetary quantities in United States Dollar Tether (**USDT**). All time in Coordinated Universal Time (**UTC**).

## R6.1 Severity classes — defined before use

* `CRITICAL`: violates a hard owner constraint, an essential safety invariant, or could permit uncontrolled risk or incorrect exchange state.
* `MAJOR`: breaks a material capability, correctness property, essential interface, or implementation handoff.
* `MODERATE`: creates meaningful degradation, missing control, ambiguity, or avoidable operational burden with a bounded safe fallback.
* `MINOR`: localized noncritical defect in clarity, consistency, or maintainability.

Severity is not dramatized. A finding marked fixed points to corrected content and a check that verifies the correction.

## R6.2 Forensic finding catalog — Pass D plus Pass E omissions

Previous blueprint means the six prior-design messages in this conversation. Each finding carries disposition `FIXED`, `REDESIGNED`, `REMOVED`, `RETAINED_WITH_JUSTIFICATION`, `UNRESOLVED`, `BLOCKED`, or `NOT_TESTED`.

**F-R-001 Pending risk boundary carried as parametric [MAJOR, REDESIGNED].** Prev: prior Parts 2/6 through 6/6 left drawdown, per-trade, aggregate, daily, leverage pending. Basis: RQ-015 through RQ-020 plus owner D-RISK-1 through D-RISK-6. Rationale: later hard decisions supersede pending values and refine planning scale. Destination: Rev Part 2/6 Section R2.2 canonical catalog as sole authority. Pointer: supplement Section 1. Consequence: Live remains refused until runtime gates pass; no parametric Live. Regression: R6.5 checks RQ-015 through RQ-021 hierarchy.

**F-R-002 Drawdown denominator used conventional peak ratio [CRITICAL, REDESIGNED].** Prev: prior education used peak-to-trough divided by prior peak. Basis: RQ-015 plus D-RISK-1 initial-equity denominator. Rationale: owner denominator is initial equity; substitution understates allowance drift and masks deposit effects. Destination: Rev Part 2/6 drawdown formula with `E0`, peak tracking, unrealized inclusive, deposit and withdrawal re-baselining freeze. Pointer: supplement Section 1.1. Consequence: prior arithmetic walks recomputed in Walk W1. Regression: V-4 plus T-R-10 boundary check.

**F-R-003 Per-trade estimate reduced to stop distance [CRITICAL, REDESIGNED].** Prev: prior sizing discussion centered nominal stop without full add-ons. Basis: RQ-016 plus D-RISK-2. Rationale: stop price alone is not a guaranteed cap; fees, spread, slippage, funding horizon, rounding, partial fills, gap, protective failure are additive. Destination: Rev Part 2/6 estimate plus Rev Part 4/6 evaluation order step 5. Pointer: supplement Section 1.2 plus Fact Pack Sections 6 through 7. Consequence: small-equity feasibility tightens; maker claim requires evidence. Regression: Walk W1 plus T-R-10 stale-input injection.

**F-R-004 Aggregate lacked atomic reservation and used loose denominator [CRITICAL, REDESIGNED].** Prev: prior aggregate as sum without reservation timing and without pending-order race control. Basis: RQ-018 plus D-RISK-4. Rationale: concurrent signals can jointly overshoot between check and submission; netting without validated model hides exposure. Destination: Rev Part 2/6 aggregate with `minimum(E0,E_curr)`, no netting default, atomic reservation from durability time, UNKNOWN exposure retained. Pointer: supplement Section 1.4. Consequence: fourth concurrent maximum refused in Walk W1. Regression: race analysis in T-R-10.

**F-R-005 Daily veto missing with reset confusion [CRITICAL, REDESIGNED].** Prev: prior had daily-loss concept without UTC-day reference equity, realized-only construction, veto scope, and latch interaction. Basis: RQ-019 plus D-RISK-5. Rationale: without reference definition and reset rule, veto either never triggers or blocks needed exits. Destination: Rev Part 2/6 daily catalog with `E_day_ref`, realized construction, veto until 00:00:00 UTC next day, risk-reducing acts preserved on confirmed semantics, latch survival table. Pointer: supplement Section 1.5. Consequence: third sequential realized loss triggers veto in Walk W1. Regression: T-R-10 plus R6.5 latch check.

**F-R-006 Effective leverage undefined against exchange label [MAJOR, REDESIGNED].** Prev: prior discussed leverage without gross formula and without pending inclusion and hedge gross rule. Basis: RQ-020 plus D-RISK-6. Rationale: exchange leverage setting is not portfolio exposure; pending and both hedge sides contribute. Destination: Rev Part 2/6 `GrossNotional divided by E_curr_net` with lesser-of rule. Pointer: supplement Section 1.6 plus Fact Pack Section 8. Consequence: 1000 USDT maximum gross at 200 USDT basis; tier unknown blocks increase. Regression: T-R-10 leverage check.

**F-R-007 Ten-symbol measurement set used as interim universe [MAJOR, REMOVED].** Prev: prior Part 3/6 carried ten C19 symbols as seed candidate. Basis: RQ-007 plus supplement Section 2 item 7. Rationale: ten symbols are a measurement set with zero selection weight; carrying them biases derivation. Destination: removed; Rev Part 3/6 derives through D14 filters with membership `UNRESOLVED` until runtime discovery. Pointer: Fact Pack Section 10 `PROVISIONAL` plus PROMPT C19. Consequence: narrow envelope uses abstract validated subset, not a named list. Regression: T-R-07 discovery gate.

**F-R-008 Cross-venue proxy permitted toward Paper calibration [CRITICAL, REDESIGNED].** Prev: prior allowed 1-hour and 4-hour proxy with lineage for calibration and Paper. Basis: RQ-005 as narrowed by supplement Sections 0.2 and 2 item 5. Rationale: current directive restricts cross-venue to research and historical backtest with structural isolation from Paper and Live. Destination: Rev Part 4/6 dual-store firewall with allowlisted source check at ingestion, signal input, and mode switch plus negative-path test. Pointer: PROMPT C17 C18 plus RQ-005. Consequence: any Paper use refused; promotion passes parameters only. Regression: T-R-05 proxy rejection drill.

**F-R-009 Funding clamp treated as bounded cost [MAJOR, FIXED].** Prev: prior carried observed minus 30.0000 basis points as governing bound. Basis: RQ-030 plus Fact Pack Section 6. Rationale: observed clamp plus `PROVISIONAL` 2.0000 percent to 3.0000 percent caps are tail inputs, not guaranteed bounds. Destination: Rev Part 3/6 and Rev Part 4/6 tail add-on with funding-bound holding leg. Pointer: Fact Pack Section 6 plus PROMPT C7. Consequence: multi-settlement holds require wider estimate or shorter hold. Regression: T-R-14 funding review.

**F-R-010 No testable strategy candidate before statistical rejection [MAJOR, REDESIGNED].** Prev: prior rejected low timeframes and grid without proposing an alpha hypothesis. Basis: RQ-012 plus D19 plus supplement Section 7.2. Rationale: rigor-as-verification requires a candidate before a budget-restrictive conclusion; execution slicing is not alpha. Destination: Rev Part 3/6 baseline B0 single-instrument 1-hour Time-Series Momentum and candidate C1 filtered multi-timeframe with ablation and negative controls, both `NOT TESTED`. Pointer: general quantitative knowledge labeled as such. Consequence: comparison anchor exists; richer candidate must beat B0 net of costs. Regression: T-R-11 promotion rule.

**F-R-011 Order contract incomplete for v2 lifecycle [CRITICAL, REDESIGNED].** Prev: prior state machine lacked exact endpoint, weights, mandatory fields, Time In Force names, conditional fields, amend LIMIT-only rule, cancel identity exclusivity, batch weights, observed `NEW` and `CANCELED` scope. Basis: RQ-024 plus Fact Pack Section 3. Rationale: implementation handoff cannot invent fields or semantics. Destination: Rev Part 4/6 Section R4.4 with exact listed subset and local-against-exchange state distinction. Pointer: Fact Pack Section 3 supplied status. Consequence: beyond-listed semantics remain `UNRESOLVED`. Regression: T-R-13 contract review.

**F-R-012 Order-rate limit and header branch missing [MAJOR, FIXED].** Prev: prior modeled request weight only. Basis: RQ-023 plus Fact Pack Section 2 plus PROMPT C4. Rationale: `ORDERS` 60 per 2 seconds with `-1015` is a separate burst gate; header presence is a documented conflict. Destination: Rev Part 4/6 dual-budget limiter with conservative fixed-weight baseline and optional header-delta enhancement only if observed. Pointer: Fact Pack Section 2 plus C4 conservative branch. Consequence: burst sizing and backoff paths corrected; Walk W2 verifies budgets. Regression: T-R-13 plus Walk W2.

**F-R-013 Futures against spot symbol conflation risk [MAJOR, FIXED].** Prev: prior lacked canonical mapping. Basis: RQ-027 plus Fact Pack Section 3. Rationale: `BTC-SWAP-USDT` form against `BTCUSDT` form confusion causes wrong-instrument execution. Destination: Rev Part 4/6 canonical instrument schema with explicit mapping and unmapped block. Pointer: Fact Pack Section 3 examples. Consequence: single-format assumption blocked. Regression: T-R-07 mapping check.

**F-R-014 Pagination assumed 3500 availability; timeframe conflict unresolved [MODERATE, FIXED].** Prev: prior used 3500 cap without conservative response bound and without 14 against 11 handling. Basis: RQ-029 plus Fact Pack Section 5 plus PROMPT C1 C2. Rationale: 2000 against 1000 conflict requires 1000 bound; WebSocket 11-list is a transport subset, not a ceiling reduction. Destination: Rev Part 4/6 pagination with ceiling function plus per-path interval verification. Pointer: Fact Pack Section 5 `PROVISIONAL` conflict plus C1 `RATIFIED_FINDING`. Consequence: narrow pagination 160 requests derived in Walk W2. Regression: T-R-14 pagination review.

**F-R-015 Heartbeat and candle finality unspecified [MODERATE, FIXED].** Prev: prior lacked ping and pong with 5-minute disconnect plus provisional-against-final handling. Basis: RQ-034 plus Fact Pack Section 11. Rationale: silent disconnect plus premature finality causes stale trade and false signals. Destination: Rev Part 4/6 heartbeat with 60-second ping target, stale trip, resubscription, gap repair, duplicate handling. Pointer: Fact Pack Section 11 supplied status. Consequence: reconstructed candles stay provisional until REST repair. Regression: T-R-14 feed walkthrough.

**F-R-016 Per-symbol filters treated as knowable [CRITICAL, FIXED].** Prev: prior sizing arithmetic implied usable minima. Basis: RQ-028 plus Fact Pack Section 9. Rationale: minimum quantity, step size, tick size, per-symbol leverage values are not extracted; sizing on invented filters is unsafe. Destination: Rev Part 4/6 discovery gating where missing filter blocks sizing. Pointer: Fact Pack Section 9 endpoint existence supplied status with values `UNRESOLVED`. Consequence: sizing cells without filters are `UNRESOLVED` with Live proof `BLOCKED`. Regression: T-R-07 discovery test.

**F-R-017 Risk authority lacked order, taxonomy, latches [MAJOR, REDESIGNED].** Prev: prior stated veto precedence without ten-step evaluation order, action taxonomy, Kill Switch semantics, six-latch table, re-arm rule. Basis: RQ-021 plus RQ-010 plus supplement Sections 1.7 and 7.3. Rationale: without order and taxonomy a veto can block a needed exit or permit an unsafe amend. Destination: Rev Part 4/6 Sections R4.3 through R4.5 with fail-fast order and three action classes. Pointer: general control knowledge plus supplement latch list. Consequence: no optimizer, forecast, allocator, or Telegram path bypasses veto. Regression: T-R-09 plus T-R-10 override attempt.

**F-R-018 Register schema and identifier migration [MAJOR, REDESIGNED].** Prev: prior 28-row register with prior 11-field list. Basis: RQ-037 plus supplement Pass B 11-field mandate. Rationale: supplemental schema resolves the original count mismatch and adds failure response plus regression columns; risk hard decisions add rows. Destination: Rev Part 2/6 37-row single table `RQ-001` through `RQ-037`; prior `REQ` identifiers superseded with trace in this catalog. Pointer: supplement Section 5 Pass B. Consequence: matrix equality moves from 28 equals 28 to 37 equals 37. Regression: Walk W3 plus R6.5 count check.

**F-R-019 Telegram and Paper and Live isolation underspecified [MAJOR, REDESIGNED].** Prev: prior listed commands without preconditions, nonce and window, idempotency, switch transaction, structural Paper non-transmission proof. Basis: RQ-002 RQ-010 RQ-035 RQ-036. Rationale: convenience commands plus ambiguous switch can leak simulation into real submission. Destination: Rev Part 4/6 Section R4.5 with seven command families, allowlisted principal, single-use nonce, atomic switch, abort-to-prior-mode rule. Pointer: supplement Sections 7.5 and 2 items 2 and 10 plus Fact Pack Section 1 sandbox note. Consequence: Paper path has no transmit capability by construction. Regression: T-R-02 plus T-R-03 plus T-R-15.

Prior-design strengths retained with justification: UTC role tagging, singleton-interface intent, six-interlock structure, conservative 0.06 percent taker default, quarantine of depth and mark-price and open interest, envelope-first ordering, and no-grid at or below 12-hour. Each is preserved in RQ-003, RQ-002, RQ-010, RQ-031, RQ-034, RQ-008, RQ-012 with tightened handling above.

## R6.3 Change-propagation table — correction presence

| Finding | Changed artifact and exact location | New content | Verification present |
|---|---|---|---|
| F-R-001 | ART-R-002 Rev Part 2/6 Section R2.2 | Canonical six-limit catalog with formulas, latches, resets | T-R-10 plus V-4 |
| F-R-002 | ART-R-002 Section R2.2 drawdown row; ART-R-005 Walk W1 | Initial-equity denominator with re-baselining freeze | Walk W1 plus T-R-10 |
| F-R-003 | ART-R-002 RQ-016; ART-R-004 Section R4.3 step 5 | Full additive estimate with up-rounding and gap add-on | T-R-10 |
| F-R-004 | ART-R-002 RQ-018; ART-R-004 Sections R4.3 R4.4 | Atomic reservation with conservative denominator | T-R-10 race check |
| F-R-005 | ART-R-002 RQ-019; ART-R-004 latch table | UTC-day veto with reset and latch survival | T-R-10 veto walk |
| F-R-006 | ART-R-002 RQ-020; ART-R-004 Section R4.3 step 8 | Gross exposure formula with lesser-of tier rule | T-R-10 leverage check |
| F-R-007 | ART-R-003 Rev Part 3/6 Section R3.3 | D14 filters with zero weight to measurement set | T-R-07 |
| F-R-008 | ART-R-004 Section R4.2 firewall | Dual-store structural isolation with triple check | T-R-05 |
| F-R-009 | ART-R-003 Section R3.7; ART-R-004 Section R4.3 | Funding tail add-on plus holding-bound leg | T-R-14 |
| F-R-010 | ART-R-003 Section R3.2 | B0 and C1 with ablation, negative controls, lifecycle | T-R-11 |
| F-R-011 | ART-R-004 Section R4.4 | Exact v2 subset with local-against-exchange states | T-R-13 |
| F-R-012 | ART-R-004 Section R4.4; ART-R-005 Walk W2 | Dual rate budgets with fixed-weight baseline | Walk W2 plus T-R-13 |
| F-R-013 | ART-R-004 Section R4.2 schemas | Canonical instrument map with block on unmapped | T-R-07 |
| F-R-014 | ART-R-004 Section R4.2; Walk W2 | 1000-bound pagination with per-path verification | Walk W2 plus T-R-14 |
| F-R-015 | ART-R-004 Section R4.2 | Heartbeat plus provisional-final distinction | T-R-14 |
| F-R-016 | ART-R-004 Section R4.4; ART-R-002 RQ-028 | Discovery-before-sizing gate | T-R-07 |
| F-R-017 | ART-R-004 Section R4.3 | Ten-step order plus taxonomy plus six latches | T-R-09 plus T-R-10 |
| F-R-018 | ART-R-002 Rev Part 2/6 Section R2.1 | 37-row 11-field single register | Walk W3 plus T-R-16 |
| F-R-019 | ART-R-004 Section R4.5 | Command preconditions plus atomic switch | T-R-02 plus T-R-03 plus T-R-15 |

## R6.4 Adversarial red-team on revised design — Pass G

Internal analytical passes, not independent external review. Paper analysis is not an operational drill.

Analyzed with fault-tree, threat-tree, Failure Modes and Effects Analysis, boundary-value, and race reasoning: venue drift; shadow interface; timezone look-ahead; proxy leakage into Paper and Live; cost understatement with 0.05 percent substitution; notional against margin against budget confusion; concurrent race overshoot; daily against drawdown blind spot; equity-decline headroom shrinkage; leverage with tight stop passing leverage while failing budget; `-1007` double submission; 429 and 403 storm; cancel and amend race; partial-fill remainder; UNKNOWN overhang counted in aggregate; reconciliation mismatch; clock skew beyond 1000 ms; config hash mismatch; credential failure; Telegram loss with open exposure; replay and flood and token compromise; Doze kill before acknowledgement; storage pressure; corrupted audit; research promotion as bars; optimizer relaxation attempt; funding multi-settlement tail; gap beyond protective level; inability to cancel or close.

Result: no analyzed path achieves Live entry, limit release, uncertain confirmation, blind resubmit, cross-venue consumption, or override success without tripping a named interlock, latch, halt, or audit event. Residual risks are unmeasured live spread and slippage, undiscovered tiers and filters, sustained phone behavior, and same-model independence limitation. Not analyzed by execution: live order submission, live reconciliation timing, Telegram delivery timing, thermal endurance, penetration testing, disaster-recovery rehearsal. Each is `NOT TESTED` with safe interim in Sections R4.6 through R4.7.

## R6.5 Regression and coherence verification — Pass H

Checked on the full revised package as one system: no orphan component because every Section R4.1 owner maps to a failure policy; no unjustified dependency because excluded routing, slicing, FIX, colocation, Field Programmable Gate Array, Kubernetes, dashboard carry positive reasons; no module without state owner; no identifier used before definition with `RQ`, `ART-R`, `T-R`, `W`, `F-R`, `DEC-R` catalogs singular; no duplicate parameter values because Section R2.2 is sole risk authority; no contract mismatch because v2 subset, durability order, UNKNOWN handling, and reconciliation use the same identities and weights; no topology mismatch because E-T1 narrow plus E-T3 contraction matches envelope and phase model; no research path reachable from Paper or Live by triple check; no forecast, optimizer, Telegram, cache, or degraded-subsystem bypass because veto precedes execution; no unsupported venue behavior presented as confirmed because missing facts are `UNRESOLVED` with `BLOCKED` confirmation; no silent numeric threshold because per-hypothesis values remain `UNRESOLVED`; arithmetic reconciled in Walks W1 through W3 with units and intermediate steps.

## R6.6 Self-audits V-1 through V-12

| ID | Check | Result | Evidence pointer | Corrective action |
|---|---|---|---|---|
| V-1 | Evidence-first with closed-world perimeter and no invented venue fact | PASS | Rev Part 1/6 Sections R1.3 R1.4; Fact Pack Sections 1 through 13 statuses preserved; zero URLs opened | None; F-R-011 through F-R-016 enforce containment |
| V-2 | Dependency-first ordering without cycles | PASS | Rev Part 1/6 Section R1.6 graph; register before baseline before synthesis before verification | None; DEC-R-002 holds |
| V-3 | Delivery integrity across six revised parts without truncation | PASS | Six registry rows in Section R6.8 all `DELIVERED`; part-scope counts in Rev Parts 1 through 5 | None |
| V-4 | No variation of six hard limits; no anchor substitution | PASS | Section R2.2 canonical values; Walk W1 varies equity only | None; F-R-001 through F-R-006 closed the prior gap |
| V-5 | Independent options with baseline compared on pre-stated criteria | PASS | Rev Part 3/6 B0 against C1; Rev Part 3/6 E-T1 through E-T4 enumeration | None; F-R-010 added the missing candidate |
| V-6 | Statistical validity with deflation, MinBTL against MinTRL, trial budget, embargo, grid ban | PASS method | Rev Part 3/6 Section R3.4; Walk W3 gap 14.68 years | None; thresholds stay `UNRESOLVED` per hypothesis |
| V-7 | Fail-closed safety across interlocks, loss, outage, ambiguity, optimizer bound | PASS logic | Rev Part 4/6 Sections R4.3 through R4.5; latch table | None; execution remains `NOT TESTED` |
| V-8 | Verification coverage with matrix rows equal to register rows | PASS | Section R5.2 count 37 equals 37 in Walk W3 | None; F-R-018 migrated 28 to 37 |
| V-9 | Adversarial review with dispositions and independence limitation | PASS with limitation | Sections R6.2 through R6.4; 19 findings with regression checks | Future independent review remains recommended; limitation disclosed |
| V-10 | Artifact registry integrity with stable identifiers and persistence | PASS | Section R6.8; six artifacts present in stated parts | None; no file facility observed, messages are persistence |
| V-11 | Engagement boundary with zero secrets, calls, orders, mode-change requests | PASS for scope | Observed zero in Rev Parts 1 through 6; T-R-01 | None |
| V-12 | Pending clarity with no silent default and explicit acceptance | PASS | Sections R6.7 R6.9 R6.10; Live refused with reasons | None; all PENDING carry path and interim |

No audit failed. No audit waived.

## R6.7 Overall completeness declaration

Design delivery is complete for delegated scope. Complete means every material item has defined content, rationale, source or evidence label, status, pointer, consequence, and safe handling. Complete does not mean implemented, profitable, validated on data, Paper-tested, production-ready, or authorized for Live.

Requirements counted exactly once in one partition:

* Project invariants `RQ-001` through `RQ-014` equals 14.
* Risk authority `RQ-015` through `RQ-021` equals 7.
* Exchange contracts `RQ-022` through `RQ-034` equals 13.
* Assurance `RQ-035` through `RQ-037` equals 3.

```
14 + 7 + 13 + 3 = 37
14 + 7 = 21; 21 + 13 = 34; 34 + 3 = 37
Register rows = 37; Matrix rows RQ-001 through RQ-037 = 37
37 = 37, equality holds, no orphan, no phantom
```

Auxiliary reconciliations, not double-counted as requirements:

```
Artifacts ART-R-001 through ART-R-006 = 6, all DELIVERED
6 = 6
Self-audits V-1 through V-12 = 12, all tabled with pointer and action
12 = 12
Test specifications T-R-01 through T-R-16 = 16, all NOT TESTED for execution
16 = 16
Arithmetic walks W1 risk plus W2 capacity and rate plus W3 statistics and counts = 3
3 = 3
Findings F-R-001 through F-R-019 = 19, each with disposition and regression
19 = 19
```

Acceptance-test truth: zero `FAIL` in design content; zero `PASS` claimed for live behavior, Paper behavior, implementation correctness, or operational readiness by execution; remote confirmations `BLOCKED`; unexecuted measurements `NOT TESTED`; missing venue facts `UNRESOLVED`; working values `PROVISIONAL` or `DESIGN_JUDGMENT` where labeled. No item is intentionally excluded without a positive reason in Sections R4.1, R3.5, and R6.2.

**DEC-R-004:** declare revised six-part delivery complete with Live refused while Section R6.9 PENDING gates persist. Reversible only by re-derivation or owner-supplied evidence with audit. Reason: close the gated workflow without resolving non-delegable evidence by default.

## R6.8 Final Artifact Registry

| Artifact ID | Artifact name | Phase produced | Message reference | Status | Content description |
|---|---|---|---|---|---|
| ART-R-001 | Offline inventory, perimeter, checkpoint, plan | Pass A | Rev Part 1/6 | DELIVERED | Capability honesty, frozen perimeter, gaps, checkpoint, graph, acronyms. |
| ART-R-002 | Canonical Requirements Register with 11 fields and risk catalog | Pass B | Rev Part 2/6 | DELIVERED | 37-row single table, six hard limits, interactions, sensitivity. |
| ART-R-003 | Clean-sheet baseline, strategy candidate, universe, statistics, envelope | Pass C | Rev Part 3/6 | DELIVERED | B0 and C1, D14 filters, trial budgets, E-T1 through E-T4. |
| ART-R-004 | Integrated architecture and contracts | Pass F | Rev Part 4/6 | DELIVERED | Data firewall, risk authority, order durability, Telegram, security, Paper and Live. |
| ART-R-005 | Verification Matrix, test specifications, arithmetic walks | Passes F through H | Rev Part 5/6 | DELIVERED | 37-row matrix, 16 plans, Walks W1 through W3, design-only Done. |
| ART-R-006 | Findings, propagation, red-team, audits, completeness, acceptance | Passes D through H | Rev Part 6/6 | DELIVERED | This message: Sections R6.1 through R6.11. |

## R6.9 Acceptance-status summary with seven dimensions

1. **Design completeness:** `PASS` as frozen design with all dispositions, pointers, interims, and consequences present.
2. **Source and evidence review:** `PASS` for supplied-source handling with exact Fact Pack pointers; remote verification `BLOCKED`; no URL inspected.
3. **Research and backtest evidence:** `NOT TESTED`; method frozen with deflation, MinBTL, embargo, trial counting; no profitability or validation claim.
4. **Implementation correctness:** `NOT TESTED` and out of scope; handoff boundary is frozen contracts, schemas, state models, and 16 test plans.
5. **Paper behavior:** `NOT TESTED`; isolation design frozen with non-transmission by construction; switch drill `NOT TESTED`.
6. **Operational readiness:** `NOT TESTED`; Service Level Objective, Recovery Time Objective, and Recovery Point Objective are targets; sustained phone, Doze survival, thermal behavior not measured.
7. **Live authorization:** `REFUSED` with reasons: undiscovered filters and tiers, unvalidated universe membership, unmeasured sustained envelope, unexecuted interlock drills, outstanding independent review, plus any active latch. No wait and no profit hurdle applies; six interlocks remain mandatory.

Conservative branches accepted until sourced resolution: 0.06 percent taker with 0.05 percent sensitivity; 1000-kline pagination bound; fixed-weight rate baseline; funding as unbounded tail; per-account identity uniqueness; `NEW` and `CANCELED` as only observed exchange states. `PROVISIONAL` values accepted only as provisional: 2.0000 percent to 3.0000 percent funding range, altcoin leverage examples, Cross against Isolated behavior, partial symbol list, 10-to-20 trials at 4-hour, 3-day outage value.

## R6.10 Limitations and residual risks

Same-model review without independent reviewer; no code execution observed so walks are manual; all venue facts are static to 2026-11-02 UTC snapshot; sustained phone behavior not measured; live spread, slippage, tiers, filters, permission state unknown by design boundary; proxy valid for research and backtest only; provisional values must not become constants; storage projection derives from 1.25 GB unit and is not a full-breadth measurement; no persistent volume observed so delivered messages are persistence; penetration testing and recovery rehearsal out of scope.

## R6.11 Next action — non-delegable owner-supplied evidence only

No architecture, language, framework, algorithm, model-class, parameter, or optimizer question is returned. If the owner proceeds toward future engineering outside this engagement, the only needed acts are owner-supplied evidence and provisioning: dated `exchangeInfo` and `riskLimits` exports with secrets removed for filter and tier resolution; confirmed fee-tier notice for cost finalization; account and symbol margin-mode confirmation for RQ-033; sustained phone measurement authorization record if E-T1 is to be confirmed; provisioned-host decision if E-T2 or E-T4 is ever invoked; independent-review authorization. Silence leaves all `UNRESOLVED` contained and Live refused. No Live authorization is requested by this design.

**Final delivery statement:** Rev Parts 1/6 through 6/6 deliver the strongest defensible revised design obtainable from the governing prompt summary, binding D-RISK decisions, and supplied Fact Pack through offline reasoning. Counts reconcile at 37 equals 37. V-1 through V-12 are tabled. Nineteen findings are dispositioned with propagation. No live action was performed. No readiness or profitability claim is made.

*یادداشت فارسی مالک — بخش ۶ از ۶ و پایان بسته بازبینی:*
*این پیام پایانی هر شش بخش بازبینی را کامل کرد. نوزده یافته با شدت و اصلاح ثبت شد، جدول انتشار تغییر، بازبینی تهاجمی، راستی‌آزمایی برگشتی، جدول V-1 تا V-12، معادله تکمیل ۳۷ برابر ۳۷، ثبت نهایی شش مصنوعی، پذیرش در هفت بعد، محدودیت‌ها و اقدام بعدی تحویل شد. اجازه لایو به‌صورت صریح رد شد و هیچ اتصال، تست زنده، سفارش یا اقدام لایو انجام نشد. اقدام بعدی فقط شواهد و تأمین مالک است و هیچ انتخاب فنی از مالک خواسته نشد.*