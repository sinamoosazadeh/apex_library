# Toobit Live API Verification — Acceptance Report

> **Statement:** This report records only tests actually executed in this run. It does not certify profitability, order execution, trading safety, account eligibility, or production readiness.

## 1. Executive summary
- Run ID `20261016T005238Z`, executed 2026-10-16T00:52:38.535842+00:00 (UTC) against `https://api.toobit.com` and `wss://stream.toobit.com/quote/ws/v1`.
- Network **reachable** from the execution sandbox (DNS ok, TLS ok, `/api/v1/time` HTTP 200).
- Scope: **public, unauthenticated, read-only GET** endpoints only. No key sent; no order or state change.
- Tests executed: **79** records. Live kline interval-endpoint tests: **45**.
- `8h` (mandatory independent test): klines=LIVE_PASS, klines=LIVE_PASS, klines=LIVE_PASS
- `3d` (negative-control candidate): klines=UNSUPPORTED_CONFIRMED, klines=UNSUPPORTED_CONFIRMED, klines=UNSUPPORTED_CONFIRMED

## 2. Run time and environment
- Python 3.11.15 on Linux-6.1.158+-x86_64-with-glibc2.41
- requests 2.33.0, numpy 2.1.2, websocket-client 1.9.2
- DNS api.toobit.com -> ['104.18.18.168', '104.18.19.168', '2606:4700::6812:12a8', '2606:4700::6812:13a8']; TLS TLSv1.3
- Server time probe: {'serverTime': 1792112139492}; **clock skew = 0.86 s**

## 3. Reachability and coverage
All live tests executed; see `toobit_test_results.json`. Coverage: exchangeInfo, standard/index/mark klines (14 intervals + 3d negative), negative controls, pagination, funding (current+history), open interest, ticker, depth, trades, mark/index price, WebSocket (14 kline intervals + 4 topics).

## 4. Test counts by verdict
| Verdict | Count |
|---|---|
| LIVE_PASS | 70 |
| LIVE_PARTIAL | 6 |
| UNSUPPORTED_CONFIRMED | 3 |

## 5. Endpoint capability matrix
See `toobit_capability_matrix.csv` (`endpoint, symbol, interval, request_result, schema_result, timestamp_spacing_result, repeatability_result, verdict, evidence_file`).

## 6. Interval-by-endpoint results (3d and 8h explicit)
| endpoint | symbol | interval | request | schema | spacing | repeat | verdict | evidence |
|---|---|---|---|---|---|---|---|---|
| /quote/v1/klines | BTC-SWAP-USDT | 1m | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_standard_1m.json |
| /quote/v1/klines | BTC-SWAP-USDT | 3m | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_standard_3m.json |
| /quote/v1/klines | BTC-SWAP-USDT | 5m | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_standard_5m.json |
| /quote/v1/klines | BTC-SWAP-USDT | 15m | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_standard_15m.json |
| /quote/v1/klines | BTC-SWAP-USDT | 30m | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_standard_30m.json |
| /quote/v1/klines | BTC-SWAP-USDT | 1h | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_standard_1h.json |
| /quote/v1/klines | BTC-SWAP-USDT | 2h | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_standard_2h.json |
| /quote/v1/klines | BTC-SWAP-USDT | 4h | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_standard_4h.json |
| /quote/v1/klines | BTC-SWAP-USDT | 6h | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_standard_6h.json |
| /quote/v1/klines | BTC-SWAP-USDT | 8h | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_standard_8h.json |
| /quote/v1/klines | BTC-SWAP-USDT | 12h | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_standard_12h.json |
| /quote/v1/klines | BTC-SWAP-USDT | 1d | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_standard_1d.json |
| /quote/v1/klines | BTC-SWAP-USDT | 1w | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_standard_1w.json |
| /quote/v1/klines | BTC-SWAP-USDT | 1M | HTTP 200 | PARTIAL | CALENDAR | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_standard_1M.json |
| /quote/v1/klines | BTC-SWAP-USDT | 3d | HTTP 400 | N/A | N/A | NOT_CHECKED (no closed candles) | **UNSUPPORTED_CONFIRMED** | toobit_raw_evidence/kline_standard_3d.json |
| /quote/v1/markPrice/klines | BTC-SWAP-USDT | 1m | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_mark_1m.json |
| /quote/v1/markPrice/klines | BTC-SWAP-USDT | 3m | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_mark_3m.json |
| /quote/v1/markPrice/klines | BTC-SWAP-USDT | 5m | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_mark_5m.json |
| /quote/v1/markPrice/klines | BTC-SWAP-USDT | 15m | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_mark_15m.json |
| /quote/v1/markPrice/klines | BTC-SWAP-USDT | 30m | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_mark_30m.json |
| /quote/v1/markPrice/klines | BTC-SWAP-USDT | 1h | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_mark_1h.json |
| /quote/v1/markPrice/klines | BTC-SWAP-USDT | 2h | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_mark_2h.json |
| /quote/v1/markPrice/klines | BTC-SWAP-USDT | 4h | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_mark_4h.json |
| /quote/v1/markPrice/klines | BTC-SWAP-USDT | 6h | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_mark_6h.json |
| /quote/v1/markPrice/klines | BTC-SWAP-USDT | 8h | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_mark_8h.json |
| /quote/v1/markPrice/klines | BTC-SWAP-USDT | 12h | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_mark_12h.json |
| /quote/v1/markPrice/klines | BTC-SWAP-USDT | 1d | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_mark_1d.json |
| /quote/v1/markPrice/klines | BTC-SWAP-USDT | 1w | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_mark_1w.json |
| /quote/v1/markPrice/klines | BTC-SWAP-USDT | 1M | HTTP 200 | PARTIAL | CALENDAR | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_mark_1M.json |
| /quote/v1/markPrice/klines | BTC-SWAP-USDT | 3d | HTTP 400 | N/A | N/A | NOT_CHECKED (no closed candles) | **UNSUPPORTED_CONFIRMED** | toobit_raw_evidence/kline_mark_3d.json |
| /quote/v1/index/klines | BTCUSDT | 1m | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_index_1m.json |
| /quote/v1/index/klines | BTCUSDT | 3m | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_index_3m.json |
| /quote/v1/index/klines | BTCUSDT | 5m | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_index_5m.json |
| /quote/v1/index/klines | BTCUSDT | 15m | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_index_15m.json |
| /quote/v1/index/klines | BTCUSDT | 30m | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_index_30m.json |
| /quote/v1/index/klines | BTCUSDT | 1h | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_index_1h.json |
| /quote/v1/index/klines | BTCUSDT | 2h | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_index_2h.json |
| /quote/v1/index/klines | BTCUSDT | 4h | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_index_4h.json |
| /quote/v1/index/klines | BTCUSDT | 6h | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_index_6h.json |
| /quote/v1/index/klines | BTCUSDT | 8h | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_index_8h.json |
| /quote/v1/index/klines | BTCUSDT | 12h | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_index_12h.json |
| /quote/v1/index/klines | BTCUSDT | 1d | HTTP 200 | PASS | OK | STABLE (closed candles) | **LIVE_PASS** | toobit_raw_evidence/kline_index_1d.json |
| /quote/v1/index/klines | BTCUSDT | 1w | HTTP 200 | PARTIAL | OK | STABLE (closed candles) | **LIVE_PARTIAL** | toobit_raw_evidence/kline_index_1w.json |
| /quote/v1/index/klines | BTCUSDT | 1M | HTTP 200 | PARTIAL | CALENDAR | STABLE (closed candles) | **LIVE_PARTIAL** | toobit_raw_evidence/kline_index_1M.json |
| /quote/v1/index/klines | BTCUSDT | 3d | HTTP 400 | N/A | N/A | NOT_CHECKED (no closed candles) | **UNSUPPORTED_CONFIRMED** | toobit_raw_evidence/kline_index_3d.json |

## 7. Candle schema, boundaries, timestamp units, pagination
Standard `/quote/v1/klines` returns positional arrays `[openTime,o,h,l,c,vol,closeTime,quoteVol,trades,takerBase,takerQuote]` (ms). Index/Mark endpoints return `{code,data:[...]}` objects. Pagination tested with backward `endTime` cursor (3 pages). See pagination record.

## 8. Exchange metadata & symbol universe
`/api/v1/exchangeInfo` parsed: contracts=778; categories present (e.g. TradFi); per-contract filters/risk tiers captured. Non-crypto categories must be filtered by an explicit eligibility policy.

## 9. Mark/Index field validation and formula discrepancies
Mark kline field `change` documented as `(index price - mark price)/mark price`. Conflict-aware; see claim `TOB-DATA-CHANGE-001`. Live mark & index price endpoints captured in same run.

## 10. Funding-rate results
`/api/v1/futures/fundingRate` and `/api/v1/futures/historyFundingRate` tested; fields `rate, period, nextFundingTime, interest, fundingRateCap, fundingRateFloor` validated.

## 11. Open-interest results
`/quote/v1/openInterest` tested (current only). **Historical open-interest series remains unresolved** — no separate documented endpoint tested.

## 12. Fees / optional account read-only
Not executed — authenticated stage disabled by default. `/api/v1/futures/commissionRate` is a USER_DATA endpoint (AUTH_REQUIRED). No credentials used.

## 13. WebSocket findings
`wss://stream.toobit.com/quote/ws/v1` connected; `kline_<interval>` subscriptions tested for all 14 intervals + 3d; documented WS interval list omits `3m` and `8h` (source S07). See records `TOB-TST-WS-*`.

## 14. Rate-limit & error-code findings
| Endpoint | HTTP | allowlisted headers |
|---|---|---|
| /api/v1/time | 200 | {} |
| /api/v1/exchangeInfo | 200 | {'date': 'Fri, 16 Oct 2026 00:55:40 GMT', 'content-type': 'application/json;charset=UTF-8', 'server': 'cloudflare', 'vary': 'accept-encoding', 'cache-control': 'public, max-age=10', 'cf-cache-status': 'HIT', 'cf-ray': 'a4b3196d98e1ba48-SEA'} |
| /quote/v1/klines | 200 | {'date': 'Fri, 16 Oct 2026 00:55:40 GMT', 'content-type': 'application/json', 'server': 'cloudflare', 'cf-cache-status': 'DYNAMIC', 'cf-ray': 'a4b3196f2a00ba48-SEA'} |
| /quote/v1/klines | 200 | {'date': 'Fri, 16 Oct 2026 00:55:41 GMT', 'content-type': 'application/json', 'server': 'cloudflare', 'cf-cache-status': 'DYNAMIC', 'cf-ray': 'a4b319758e99ba48-SEA'} |
| /quote/v1/klines | 200 | {'date': 'Fri, 16 Oct 2026 00:55:42 GMT', 'content-type': 'application/json', 'server': 'cloudflare', 'cf-cache-status': 'DYNAMIC', 'cf-ray': 'a4b3197ada10ba48-SEA'} |
| /quote/v1/klines | 200 | {'date': 'Fri, 16 Oct 2026 00:55:43 GMT', 'content-type': 'application/json', 'server': 'cloudflare', 'cf-cache-status': 'DYNAMIC', 'cf-ray': 'a4b3197d3b8fba48-SEA'} |
| /quote/v1/klines | 200 | {'date': 'Fri, 16 Oct 2026 00:55:43 GMT', 'content-type': 'application/json', 'server': 'cloudflare', 'cf-cache-status': 'DYNAMIC', 'cf-ray': 'a4b3197f8d53ba48-SEA'} |
| /quote/v1/klines | 200 | {'date': 'Fri, 16 Oct 2026 00:55:43 GMT', 'content-type': 'application/json', 'server': 'cloudflare', 'cf-cache-status': 'DYNAMIC', 'cf-ray': 'a4b31981ef2dba48-SEA'} |
| /quote/v1/klines | 200 | {'date': 'Fri, 16 Oct 2026 00:55:44 GMT', 'content-type': 'application/json', 'server': 'cloudflare', 'cf-cache-status': 'DYNAMIC', 'cf-ray': 'a4b3198448efba48-SEA'} |
| /quote/v1/klines | 200 | {'date': 'Fri, 16 Oct 2026 00:55:44 GMT', 'content-type': 'application/json', 'server': 'cloudflare', 'cf-cache-status': 'DYNAMIC', 'cf-ray': 'a4b31986aab6ba48-SEA'} |
| /quote/v1/klines | 200 | {'date': 'Fri, 16 Oct 2026 00:55:45 GMT', 'content-type': 'application/json', 'server': 'cloudflare', 'cf-cache-status': 'DYNAMIC', 'cf-ray': 'a4b31988ec9cba48-SEA'} |
| /quote/v1/klines | 200 | {'date': 'Fri, 16 Oct 2026 00:55:45 GMT', 'content-type': 'application/json', 'server': 'cloudflare', 'cf-cache-status': 'DYNAMIC', 'cf-ray': 'a4b3198b4e26ba48-SEA'} |
| /quote/v1/klines | 200 | {'date': 'Fri, 16 Oct 2026 00:55:46 GMT', 'content-type': 'application/json', 'server': 'cloudflare', 'cf-cache-status': 'DYNAMIC', 'cf-ray': 'a4b31990898eba48-SEA'} |
| /quote/v1/klines | 200 | {'date': 'Fri, 16 Oct 2026 00:55:46 GMT', 'content-type': 'application/json', 'server': 'cloudflare', 'cf-cache-status': 'DYNAMIC', 'cf-ray': 'a4b31992db14ba48-SEA'} |
| /quote/v1/klines | 200 | {'date': 'Fri, 16 Oct 2026 00:55:46 GMT', 'content-type': 'application/json', 'server': 'cloudflare', 'cf-cache-status': 'DYNAMIC', 'cf-ray': 'a4b319952ce4ba48-SEA'} |
| /quote/v1/klines | 200 | {'date': 'Fri, 16 Oct 2026 00:55:47 GMT', 'content-type': 'application/json', 'server': 'cloudflare', 'cf-cache-status': 'DYNAMIC', 'cf-ray': 'a4b319976ea9ba48-SEA'} |
| /quote/v1/klines | 400 | {'date': 'Fri, 16 Oct 2026 00:55:47 GMT', 'content-type': 'application/json', 'server': 'cloudflare', 'cf-cache-status': 'DYNAMIC', 'cf-ray': 'a4b31999180fba48-SEA'} |
| /quote/v1/markPrice/klines | 200 | {'date': 'Fri, 16 Oct 2026 00:55:53 GMT', 'content-type': 'application/json', 'server': 'cloudflare', 'cf-cache-status': 'DYNAMIC', 'cf-ray': 'a4b319c02c62ba48-SEA'} |
| /quote/v1/markPrice/klines | 200 | {'date': 'Fri, 16 Oct 2026 00:55:54 GMT', 'content-type': 'application/json', 'server': 'cloudflare', 'cf-cache-status': 'DYNAMIC', 'cf-ray': 'a4b319c668d2ba48-SEA'} |
| /quote/v1/markPrice/klines | 200 | {'date': 'Fri, 16 Oct 2026 00:55:55 GMT', 'content-type': 'application/json', 'server': 'cloudflare', 'cf-cache-status': 'DYNAMIC', 'cf-ray': 'a4b319ccbd92ba48-SEA'} |


## 15. Corrects/conflicts vs reference package
- Reference package recorded DNS failure (its audit env); **this run reached the API successfully** — those `BLOCKED_BY_AUDIT_ENVIRONMENT` results are now **SUPERSEDED** by live evidence.
- WS kline interval list (12 items) omits `3m` and `8h`, consistent with the package's `UNRESOLVED` note; see live results.

## 16. Security & test-scope statement
Only public GET requests. No API key, signature, authorization header, or secret material produced, logged, or hashed. No brute force; small bounded negative tests only. Response bodies were scanned for sensitive tokens before saving (`sensitive_tokens_found=[]` expected).

## 17. Unresolved claims, blockers, next tests
- Total historical retention per symbol/interval (only recent windows tested).
- The 3500-candle claim remains OWNER_ATTESTED / UNVERIFIED.
- Historical open interest: unresolved.
- Account-level claims (fees, eligibility): not tested (auth disabled).

## 18. Reproduction commands and artifact hashes
```
python toobit_audit.py    # writes all artifacts into the working directory
```
