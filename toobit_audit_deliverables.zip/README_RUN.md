# README_RUN — Toobit Live API Verification

## What this is
A read-only, unauthenticated test harness for the public Toobit USDT-M Futures API.
It never sends an API key, never places/cancels an order, and never mutates account state.

## Reproduce
```bash
python -m pip install requests websocket-client pandas numpy
python toobit_audit.py
```
Artifacts are written to the current working directory:
toobit_audit_report.md, toobit_test_results.json, toobit_capability_matrix.csv,
toobit_environment.json, toobit_sha256_manifest.txt, toobit_raw_evidence/.

## Limitations / when a run cannot be completed
- If DNS/TLS/network is blocked, live tests are recorded as `NETWORK_BLOCKED`; do not treat that as proof of unsupported features.
- Results are a point-in-time snapshot (2026-10-16T00:52:38.535842+00:00 UTC); exchange metadata and values are dynamic.
- Only a small sample per endpoint/interval is tested; total retention and WebSocket completeness are not established.
- Authenticated/account claims (fees, eligibility, balances) are NOT tested here.

## Environment used for this run
Python 3.11.15 | Linux-6.1.158+-x86_64-with-glibc2.41 | run 20261016T005238Z
