# =============================================================================
# Toobit Live API Verification — setup, config, run metadata
# Public, read-only, unauthenticated. No secrets. No state-changing calls.
# =============================================================================
import os, sys, json, time, math, socket, ssl, platform, hashlib, datetime as dt
import collections, subprocess, importlib, warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import requests

# WS client (not in base image) — install once, idempotent
try:
    import websocket  # websocket-client
except Exception:
    import subprocess as _sp
    _sp.run([sys.executable, "-m", "pip", "install", "-q", "websocket-client"], check=False)
    import websocket

from datetime import timezone
def utcnow():
    return dt.datetime.now(timezone.utc)
def iso(t=None):
    return (t or utcnow()).astimezone(timezone.utc).isoformat()

# ---- Pinned run configuration ------------------------------------------------
BASE      = "https://api.toobit.com"                 # claim TOB-API-001
WS_URL    = "wss://stream.toobit.com/quote/ws/v1"    # source S07
SYMBOL    = "BTC-SWAP-USDT"                           # contract symbol (docs)
RUN_START = utcnow()
RUN_ID    = RUN_START.strftime("%Y%m%dT%H%M%SZ")

# Intervals to verify independently (claim TOB-DATA-001 / general list, 14 items)
INTERVALS = ["1m","3m","5m","15m","30m","1h","2h","4h","6h","8h","12h","1d","1w","1M"]
# Negative-control candidate — must be tested independently, never assumed
NEGATIVE_INTERVALS = ["3d"]
# Documented WS kline interval list from the current WS page (S07) — 12 items,
# notably WITHOUT 3m and WITHOUT 8h.
WS_DOC_INTERVALS = ["1m","5m","15m","30m","1h","2h","4h","6h","12h","1d","1w","1M"]

INTERVAL_MS = {
    "1m":60_000, "3m":180_000, "5m":300_000, "15m":900_000, "30m":1_800_000,
    "1h":3_600_000, "2h":7_200_000, "4h":14_400_000, "6h":21_600_000,
    "8h":28_800_000, "12h":43_200_000, "1d":86_400_000, "1w":604_800_000,
    "1M":None,  # calendar month — no fixed duration
}
FIXED_INTERVALS = [k for k,v in INTERVAL_MS.items() if v]

# ---- Output layout -----------------------------------------------------------
OUTDIR   = "/home/user"
EVID_DIR = os.path.join(OUTDIR, "toobit_raw_evidence")
os.makedirs(EVID_DIR, exist_ok=True)

# Allowlist of response headers safe to store (no auth/signature material)
HEADER_ALLOWLIST = {
    "content-type","content-length","date","server","cf-ray","cf-cache-status",
    "x-api-limit","x-api-limit-status","x-api-limit-reset-timestamp",
    "x-ratelimit-limit","x-ratelimit-remaining","x-ratelimit-reset","retry-after",
    "cache-control","vary","x-exchange-id","x-request-id",
}

print("Run ID:", RUN_ID)
print("Base:", BASE, "| WS:", WS_URL, "| Symbol:", SYMBOL)
print("Intervals (14):", INTERVALS)
print("Negative control:", NEGATIVE_INTERVALS)
print("Evidence dir:", EVID_DIR)


# =============================================================================
# HARNESS CORE — evidence-capturing request layer, sanitizers, validators
# =============================================================================

import re
SENSITIVE_RE = re.compile(
    r'(?i)"(?:apikey|api[_-]?key|secret|secretkey|signature|authorization|passphrase|'
    r'privatekey|private[_-]?key|listenkey|token)"\\s*:')

def _scan_sensitive(text):
    return sorted({m.group(0).strip().strip('"\: ').lower() for m in SENSITIVE_RE.finditer(text)})

def _try_json(raw):
    if not raw:
        return None
    try:
        return json.loads(raw.decode("utf-8"))
    except Exception:
        return None

def _num(x):
    try:
        return float(x)
    except Exception:
        return None

def _int(x):
    try:
        return int(float(x))
    except Exception:
        return None

class Harness:
    def __init__(self, base, evid_dir, user_agent):
        self.base = base
        self.evid_dir = evid_dir
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": user_agent, "Accept": "application/json"})
        self.results = []          # list of test records (evidence schema)
        self.dns_cache = {}
        self.requests = []         # request-level log

    # ---- DNS ------------------------------------------------------------------
    def dns_check(self, host):
        if host in self.dns_cache:
            return self.dns_cache[host]
        t = time.time(); out = {"host": host}
        try:
            infos = socket.getaddrinfo(host, 443, proto=socket.IPPROTO_TCP)
            out["ok"] = True
            out["addresses"] = sorted({i[4][0] for i in infos})
            out["latency_ms"] = round((time.time() - t) * 1000, 1)
        except Exception as e:
            out["ok"] = False
            out["error"] = f"{type(e).__name__}: {e}"
        self.dns_cache[host] = out
        return out

    # ---- raw evidence ---------------------------------------------------------
    def save_evidence(self, stem, raw_bytes, as_json):
        """Persist a SANITIZED raw response. Returns (relpath, sha256, sensitive_hits)."""
        text = raw_bytes.decode("utf-8", "replace") if raw_bytes else ""
        hits = _scan_sensitive(text)
        if hits:
            for tok in hits:
                text = text.replace(tok, "[REDACTED]")
            as_json = False
        sha = hashlib.sha256(raw_bytes).hexdigest() if raw_bytes else None
        ext = ".json" if as_json else ".txt"
        rel = f"toobit_raw_evidence/{stem}{ext}"
        with open(os.path.join(self.evid_dir, f"{stem}{ext}"), "w", encoding="utf-8") as f:
            f.write(text)
        return rel, sha, hits

    # ---- HTTP -----------------------------------------------------------------
    def get(self, path, params=None, timeout=20):
        url = self.base + path if path.startswith("/") else path
        host = url.split("/")[2]
        dns = self.dns_check(host)
        started = utcnow()
        rec = {"url": url, "params": dict(params or {}), "dns": dns}
        t0 = time.perf_counter()
        try:
            r = self.session.get(url, params=params, timeout=timeout)
            raw = r.content
            rec.update({
                "status": r.status_code,
                "content_type": r.headers.get("Content-Type"),
                "headers_allowlisted": {k.lower(): v for k, v in r.headers.items()
                                        if k.lower() in HEADER_ALLOWLIST},
                "sha256": hashlib.sha256(raw).hexdigest(),
                "body_bytes_len": len(raw),
                "json": _try_json(raw),
                "error": None,
            })
        except Exception as e:
            raw = b""
            rec.update({"status": None, "content_type": None, "headers_allowlisted": {},
                        "sha256": None, "body_bytes_len": 0, "json": None,
                        "error": f"{type(e).__name__}: {e}"})
        rec["latency_ms"] = round((time.perf_counter() - t0) * 1000, 1)
        rec["started"] = started.isoformat()
        rec["finished"] = utcnow().isoformat()
        self.requests.append(rec)
        rec["_raw"] = raw
        return rec

    # ---- record builder -------------------------------------------------------
    def add(self, **kw):
        base = {
            "test_id": None, "claim_ids": [], "feature": None, "endpoint": None,
            "http_method": "GET", "market_type": None, "symbol": None,
            "parameters_sent": {}, "run_started_at_utc": None, "run_finished_at_utc": None,
            "runtime_environment": None, "dns_result": None, "http_status": None,
            "response_headers_allowlisted": {}, "response_content_type": None,
            "response_body_sha256": None, "sanitized_response_path": None,
            "schema_validation": None, "semantic_validation": None,
            "repeatability_result": "NOT_CHECKED", "verdict": "INCONCLUSIVE",
            "failure_category": None, "limitations": None, "evidence_notes": None,
        }
        base.update(kw)
        base["runtime_environment"] = ENV_SUMMARY
        self.results.append(base)
        return base


H = Harness(BASE, EVID_DIR, f"Toobit-Live-Verification/1.0 (run {RUN_ID})")
ENV_SUMMARY = {}  # filled by run_environment(); referenced lazily


# =============================================================================
# Candle parsing / validation
# =============================================================================
def extract_candles(payload):
    """Normalize standard/index/mark kline payloads into [{t,o,h,l,c,v}]. None if unrecognized."""
    if payload is None:
        return None
    data = payload
    if isinstance(payload, dict):
        if payload.get("code") not in (None, 200) and "data" not in payload:
            return None
        data = payload.get("data", payload)
    if not isinstance(data, list):
        return None
    out = []
    for it in data:
        if isinstance(it, list) and len(it) >= 6:
            out.append({"t": _int(it[0]), "o": _num(it[1]), "h": _num(it[2]),
                        "l": _num(it[3]), "c": _num(it[4]), "v": _num(it[5])})
        elif isinstance(it, dict):
            out.append({
                "t": _int(it.get("t", it.get("time", it.get("openTime")))),
                "o": _num(it.get("o", it.get("open"))),
                "h": _num(it.get("h", it.get("high"))),
                "l": _num(it.get("l", it.get("low"))),
                "c": _num(it.get("c", it.get("close"))),
                "v": _num(it.get("v", it.get("volume"))),
                "raw_keys": sorted(it.keys()),
            })
        else:
            return None
    return out

def validate_candles(candles, interval):
    res = {"n": len(candles), "schema_ok": True, "issues": []}
    if len(candles) == 0:
        res["schema_ok"] = False; res["issues"].append("empty")
        return res
    # schema: required numeric fields present
    bad = [i for i, c in enumerate(candles)
           if c["t"] is None or None in (c["o"], c["h"], c["l"], c["c"])]
    if bad:
        res["schema_ok"] = False
        res["issues"].append(f"missing_fields@{bad[:5]}")
    ts = [c["t"] for c in candles if c["t"] is not None]
    res["monotonic"] = all(ts[i] <= ts[i+1] for i in range(len(ts)-1))
    res["duplicates"] = len(ts) - len(set(ts))
    if not res["monotonic"]:
        res["issues"].append("non_monotonic")
    # OHLC sanity
    viol = 0
    for c in candles:
        if None in (c["o"], c["h"], c["l"], c["c"]):
            continue
        hi = max(c["o"], c["c"]); lo = min(c["o"], c["c"])
        if c["h"] < hi or c["l"] > lo or c["h"] < c["l"]:
            viol += 1
    res["ohlc_violations"] = viol
    if viol:
        res["issues"].append(f"ohlc_violations={viol}")
    # spacing
    diffs = np.diff(ts) if len(ts) >= 2 else np.array([])
    res["median_spacing_ms"] = float(np.median(diffs)) if len(diffs) else None
    res["unique_spacings"] = sorted(set(int(d) for d in diffs))[:8]
    exp = INTERVAL_MS.get(interval)
    if exp and len(diffs):
        # interior spacing should equal exp; allow the newest bar boundary
        core = diffs[diffs > 0]
        res["spacing_ok"] = bool(len(core) >= 1 and np.median(core) == exp)
        if not res["spacing_ok"]:
            res["issues"].append(f"spacing_median={res['median_spacing_ms']}!=expected{exp}")
    elif interval in ("1w", "1M") and len(diffs):
        # calendar intervals: sanity only (must be ~integer days and monotonic)
        res["spacing_ok"] = bool(res.get("monotonic"))
        res["issues"].append("calendar_interval_no_fixed_duration_check")
    else:
        res["spacing_ok"] = None
    res["t_min"] = min(ts) if ts else None
    res["t_max"] = max(ts) if ts else None
    return res


# =============================================================================
# Environment + connectivity
# =============================================================================
def run_environment():
    global ENV_SUMMARY
    env = {
        "run_id": RUN_ID,
        "run_started_utc": RUN_START.isoformat(),
        "python_version": sys.version.split()[0],
        "python_implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor() or platform.machine(),
        "os": f"{platform.system()} {platform.release()}",
        "cpu_count": os.cpu_count(),
        "timezone_utc": "UTC",
        "requests_version": requests.__version__,
        "numpy_version": np.__version__,
        "pandas_version": pd.__version__,
        "websocket_client_version": getattr(websocket, "__version__", "unknown"),
    }
    # dependency snapshot
    try:
        freeze = subprocess.run([sys.executable, "-m", "pip", "freeze"],
                                capture_output=True, text=True, timeout=90).stdout
    except Exception as e:
        freeze = f"pip freeze failed: {e}"
    with open(os.path.join(OUTDIR, "toobit_requirements.txt"), "w") as f:
        f.write(freeze)

    # 1) DNS
    for host in ("api.toobit.com", "stream.toobit.com"):
        env[f"dns_{host}"] = H.dns_check(host)
    # 2) TLS connectivity (no cert bypass)
    t0 = time.perf_counter()
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection(("api.toobit.com", 443), timeout=10) as s:
            with ctx.wrap_socket(s, server_hostname="api.toobit.com") as ss:
                env["tls_ok"] = True
                env["tls_version"] = ss.version()
                env["tls_cipher"] = ss.cipher()[0] if ss.cipher() else None
                env["tls_peer_subject"] = dict(x[0] for x in ss.getpeercert().get("subject", []))
    except Exception as e:
        env["tls_ok"] = False; env["tls_error"] = f"{type(e).__name__}: {e}"
    env["tls_latency_ms"] = round((time.perf_counter() - t0) * 1000, 1)

    ENV_SUMMARY = env  # so later records carry it
    # 3) server time + clock skew
    lat = []
    for i in range(3):
        r = H.get("/api/v1/time")
        lat.append(r["latency_ms"])
        if i == 0:
            env["server_time_probe"] = {"status": r["status"], "body": r["json"],
                                        "sha256": r["sha256"], "latency_ms": r["latency_ms"]}
        time.sleep(0.2)
    env["server_time_latency_ms"] = lat
    st = _int((env["server_time_probe"].get("body") or {}).get("serverTime"))
    if st:
        local_ms = int(utcnow().timestamp() * 1000)
        env["local_ms"] = local_ms
        env["server_ms"] = st
        env["clock_skew_seconds"] = round((local_ms - st) / 1000.0, 2)
    env["connectivity_reachable"] = bool(env["server_time_probe"]["status"] == 200)

    H.add(test_id="TOB-TST-ENV-000", claim_ids=["TOB-API-001", "TOB-API-002"],
          feature="Server time / connectivity", endpoint="/api/v1/time", market_type="meta",
          parameters_sent={}, run_started_at_utc=ENV_SUMMARY.get("run_started_utc"),
          run_finished_at_utc=utcnow().isoformat(),
          dns_result=env["dns_api.toobit.com"],
          http_status=env["server_time_probe"]["status"],
          response_headers_allowlisted={}, response_content_type=None,
          response_body_sha256=env["server_time_probe"]["sha256"],
          schema_validation=f"serverTime present={st is not None}",
          semantic_validation=f"clock_skew_s={env.get('clock_skew_seconds')}",
          verdict="LIVE_PASS" if env["connectivity_reachable"] and st else "NETWORK_BLOCKED",
          evidence_notes="Repeated 3x for latency variability.")

    with open(os.path.join(OUTDIR, "toobit_environment.json"), "w") as f:
        json.dump(env, f, indent=2)
    print("Reachable:", env["connectivity_reachable"], "| TLS:", env.get("tls_ok"),
          env.get("tls_version"), "| clock_skew_s:", env.get("clock_skew_seconds"))
    print("DNS api.toobit.com:", env["dns_api.toobit.com"].get("addresses"))
    return env

print("Harness core defined.")


# =============================================================================
# REST TEST DRIVERS
# =============================================================================
SYM = {"contract": SYMBOL, "index": None, "df": None}
REPEAT_INTERVALS = {"1m", "3m", "8h", "3d"}   # includes mandatory 8h + negative control
PAGE_LIMIT = 200

def now_ms():
    return int(utcnow().timestamp() * 1000)

def window_ms(interval, n=PAGE_LIMIT):
    step = INTERVAL_MS.get(interval) or 30 * 86_400_000
    end = now_ms()
    return end - int(step * n * 1.3), end

KLINE_ENDPOINTS = [
    # (kind, path, param_style, market_type, symbol_key)
    ("standard", "/quote/v1/klines",          "startEnd", "futures_usdt_m_standard_kline", "contract"),
    ("index",    "/quote/v1/index/klines",    "fromTo",   "futures_usdt_m_index_kline",    "index"),
    ("mark",     "/quote/v1/markPrice/klines","fromTo",   "futures_usdt_m_mark_kline",     "contract"),
]

def classify(rec, val):
    status = rec["status"]
    if status is None:
        return "NETWORK_BLOCKED", "transport"
    body = rec.get("json")
    if status == 200:
        if val is None:
            return "LIVE_FAIL", "unrecognized_payload_schema"
        if val["n"] == 0:
            return "LIVE_PARTIAL", "request_ok_but_empty"
        if not val["schema_ok"]:
            return "LIVE_FAIL", "schema"
        hard_ok = (val.get("monotonic", True) and val.get("ohlc_violations", 0) == 0
                   and val.get("spacing_ok") is not False)
        return ("LIVE_PASS", None) if hard_ok else ("LIVE_PARTIAL", "semantic_check_partial")
    if status == 429:
        return "RATE_LIMITED", "rate_limit"
    if status == 401:
        return "AUTH_REQUIRED", "auth"
    if status == 403:
        return "PERMISSION_DENIED", "permission"
    if status in (400, 404, 422):
        msg = json.dumps(body)[:400].lower() if body is not None else ""
        if any(k in msg for k in ["interval", "param", "invalid", "not support", "unsupport"]):
            return "UNSUPPORTED_CONFIRMED", "rejected_invalid_parameter"
        return "LIVE_FAIL", f"http_{status}"
    if status >= 500:
        return "INCONCLUSIVE", f"server_error_{status}"
    return "INCONCLUSIVE", f"http_{status}"


# ---------------------------------------------------------------- exchangeInfo
def test_exchange_info():
    rec = H.get("/api/v1/exchangeInfo")
    rel, sha, hits = H.save_evidence("exchangeInfo", rec["_raw"], isinstance(rec["json"], dict))
    data = rec.get("json") or {}
    contracts = data.get("contracts") or []
    symbols = data.get("symbols") or []
    rows = []
    for c in contracts:
        filt = {f.get("filterType"): f for f in (c.get("filters") or [])}
        rows.append({
            "symbol": c.get("symbol"), "symbolName": c.get("symbolName"),
            "status": c.get("status"), "baseAsset": c.get("baseAsset"),
            "quoteAsset": c.get("quoteAsset"), "marginToken": c.get("marginToken"),
            "inverse": c.get("inverse"), "index": c.get("index"),
            "contractMultiplier": c.get("contractMultiplier"),
            "categories": ",".join(c.get("categories") or []),
            "tickSize": (filt.get("PRICE_FILTER") or {}).get("tickSize"),
            "stepSize": (filt.get("LOT_SIZE") or {}).get("stepSize"),
            "minQty": (filt.get("LOT_SIZE") or {}).get("minQty"),
            "maxQty": (filt.get("LOT_SIZE") or {}).get("maxQty"),
            "riskTiers": len(c.get("riskLimits") or []),
        })
    df = pd.DataFrame(rows)
    SYM["df"] = df
    # choose index symbol for BTC contract
    btc = df[df["symbol"] == SYMBOL]
    if len(btc):
        SYM["index"] = btc.iloc[0]["index"]
    if not SYM["index"]:
        SYM["index"] = "BTCUSDT"
    tradeable = df[df["status"] == "TRADING"] if len(df) else df
    schema_ok = isinstance(data.get("contracts"), list) and len(contracts) > 0
    H.add(test_id="TOB-TST-PUB-001", claim_ids=["TOB-PROD-003", "TOB-PROD-004", "TOB-PROD-005",
                                                "TOB-PROD-006", "TOB-PROD-007"],
          feature="Exchange / contract metadata", endpoint="/api/v1/exchangeInfo",
          market_type="futures_usdt_m_meta", parameters_sent={},
          run_started_at_utc=rec["started"], run_finished_at_utc=rec["finished"],
          dns_result=rec["dns"], http_status=rec["status"],
          response_headers_allowlisted=rec["headers_allowlisted"],
          response_content_type=rec["content_type"], response_body_sha256=rec["sha256"],
          sanitized_response_path=rel, symbol=None,
          schema_validation=f"contracts={len(contracts)}, symbols={len(symbols)}, keys={sorted(data.keys())[:12]}",
          semantic_validation=f"TRADING_contracts={len(tradeable)}, categories={sorted(set(df['categories']))[:10]}",
          verdict="LIVE_PASS" if (rec["status"] == 200 and schema_ok) else classify(rec, {"n": 1, "schema_ok": schema_ok}),
          limitations="Response values are dynamic; categories include non-crypto labels (e.g. TradFi).",
          evidence_notes=f"sensitive_tokens_found={hits}")
    print(f"exchangeInfo: status={rec['status']} contracts={len(contracts)} symbols={len(symbols)} "
          f"TRADING={len(tradeable)} index_sym={SYM['index']}")
    return rec


# ---------------------------------------------------------------- interval matrix
def run_interval_matrix():
    out = []
    for kind, path, style, mtype, symkey in KLINE_ENDPOINTS:
        for iv in INTERVALS + NEGATIVE_INTERVALS:
            start, end = window_ms(iv)
            sym = SYM[symkey] if symkey == "index" else SYM["contract"]
            if symkey == "index":
                params = {"symbol": sym, "interval": iv, "from": start, "to": end, "limit": PAGE_LIMIT}
            elif style == "startEnd":
                params = {"symbol": sym, "interval": iv, "startTime": start, "endTime": end, "limit": PAGE_LIMIT}
            else:
                params = {"symbol": sym, "interval": iv, "from": start, "to": end, "limit": PAGE_LIMIT}
            rec = H.get(path, params)
            candles = extract_candles(rec.get("json"))
            val = validate_candles(candles, iv) if candles is not None else None
            tid = f"TOB-TST-INT-{kind.upper()}-{iv}"
            stem = f"kline_{kind}_{iv}".replace("/", "_")
            rel, sha, hits = H.save_evidence(stem, rec["_raw"], isinstance(rec.get("json"), (dict, list)))
            verdict, failcat = classify(rec, val)
            # repeatability on selected intervals
            rep = "NOT_CHECKED"
            if iv in REPEAT_INTERVALS:
                time.sleep(0.25)
                rec2 = H.get(path, params)
                rep = "STABLE" if (rec["sha256"] and rec["sha256"] == rec2["sha256"]) else "DIFFERS"
            r = H.add(test_id=tid,
                      claim_ids=["TOB-DATA-001", "TOB-DATA-002", "TOB-DATA-003"],
                      feature=f"{kind} klines interval={iv}", endpoint=path,
                      market_type=mtype, symbol=sym, parameters_sent=params,
                      run_started_at_utc=rec["started"], run_finished_at_utc=rec["finished"],
                      dns_result=rec["dns"], http_status=rec["status"],
                      response_headers_allowlisted=rec["headers_allowlisted"],
                      response_content_type=rec["content_type"], response_body_sha256=rec["sha256"],
                      sanitized_response_path=rel,
                      schema_validation=(f"n={val['n']}, schema_ok={val['schema_ok']}, issues={val['issues']}"
                                         if val else f"unrecognized_payload raw_prefix={str(rec.get('json'))[:80]}"),
                      semantic_validation=(f"monotonic={val.get('monotonic')}, dups={val.get('duplicates')}, "
                                           f"ohlc_viol={val.get('ohlc_violations')}, median_spacing_ms={val.get('median_spacing_ms')}, "
                                           f"expected_ms={INTERVAL_MS.get(iv)}" if val else None),
                      repeatability_result=rep, verdict=verdict, failure_category=failcat,
                      limitations="Single symbol BTC-SWAP-USDT; window limited to recent history; "
                                  "per-request max (not total retention) is what is tested.",
                      evidence_notes=f"sensitive_tokens_found={hits}")
            out.append(r)
            if val:
                print(f"[{kind:8s} {iv:>3s}] {verdict:20s} n={val['n']:>4d} spacing={val.get('median_spacing_ms')} rep={rep}")
            else:
                print(f"[{kind:8s} {iv:>3s}] {verdict:20s} status={rec['status']} body={str(rec.get('json'))[:90]}")
            time.sleep(0.15)
    return out


# ---------------------------------------------------------------- negative tests
def run_negative_tests():
    cases = [
        ("invalid_interval", "/quote/v1/klines",
         {"symbol": SYM["contract"], "interval": "7q", "limit": 5},
         "Intentionally invalid interval string (controlled negative test)."),
        ("invalid_symbol", "/quote/v1/klines",
         {"symbol": "NOTREAL-SWAP-USDT", "interval": "1m", "limit": 5},
         "Nonexistent symbol (controlled negative test)."),
        ("malformed_limit", "/quote/v1/klines",
         {"symbol": SYM["contract"], "interval": "1m", "limit": "notanint"},
         "Malformed optional limit parameter (controlled negative test)."),
    ]
    out = []
    for name, path, params, note in cases:
        rec = H.get(path, params)
        rel, sha, hits = H.save_evidence(f"neg_{name}", rec["_raw"], isinstance(rec.get("json"), (dict, list)))
        body = rec.get("json")
        msg = json.dumps(body)[:300] if body is not None else f"transport_error={rec.get('error')}"
        if rec["status"] is None:
            verdict, fc = "NETWORK_BLOCKED", "transport"
        elif rec["status"] == 200:
            verdict, fc = "LIVE_PASS", "unexpectedly_accepted"
        else:
            verdict, fc = "LIVE_PARTIAL", f"http_{rec['status']}"
        r = H.add(test_id=f"TOB-TST-NEG-{name}", claim_ids=["TOB-DATA-001"],
                  feature=f"negative control: {name}", endpoint=path, market_type="futures_usdt_m_standard_kline",
                  symbol=params.get("symbol"), parameters_sent=params,
                  run_started_at_utc=rec["started"], run_finished_at_utc=rec["finished"],
                  dns_result=rec["dns"], http_status=rec["status"],
                  response_headers_allowlisted=rec["headers_allowlisted"],
                  response_content_type=rec["content_type"], response_body_sha256=rec["sha256"],
                  sanitized_response_path=rel, schema_validation="n/a (negative test)",
                  semantic_validation=f"observed_error={msg}", repeatability_result="NOT_CHECKED",
                  verdict=verdict, failure_category=fc, limitations=note,
                  evidence_notes=f"sensitive_tokens_found={hits}")
        out.append(r)
        print(f"[neg {name:16s}] status={rec['status']} body={msg[:110]}")
        time.sleep(0.2)
    return out


# ---------------------------------------------------------------- pagination
def test_pagination(endpoint="/quote/v1/klines", interval="1h", pages=3, limit=200):
    """Walk backward with endTime to prove distinct, ordered, non-overlapping pages."""
    out = []
    cursor_end = now_ms()
    seen_ts = []
    page_info = []
    for p in range(pages):
        start = cursor_end - int(INTERVAL_MS[interval] * limit * 1.3)
        params = {"symbol": SYM["contract"], "interval": interval,
                  "startTime": start, "endTime": cursor_end, "limit": limit}
        rec = H.get(endpoint, params)
        candles = extract_candles(rec.get("json")) or []
        ts = [c["t"] for c in candles if c["t"] is not None]
        rel, sha, hits = H.save_evidence(f"page_{interval}_{p}", rec["_raw"], isinstance(rec.get("json"), (dict, list)))
        page_info.append({"page": p, "n": len(candles), "t_min": min(ts) if ts else None,
                          "t_max": max(ts) if ts else None, "sha256": rec["sha256"], "status": rec["status"]})
        if ts:
            cursor_end = min(ts) - 1
        seen_ts.extend(ts)
        time.sleep(0.2)
    dup = len(seen_ts) - len(set(seen_ts))
    # overlap between consecutive pages
    overlap = 0
    for a, b in zip(page_info, page_info[1:]):
        if a["t_min"] and a["t_max"] and b["t_min"] and b["t_max"]:
            lo = max(a["t_min"], b["t_min"]); hi = min(a["t_max"], b["t_max"])
            if hi >= lo:
                overlap += 1
    distinct = len({p["sha256"] for p in page_info})
    ok = (all(p["n"] > 0 for p in page_info) and dup == 0 and overlap == 0 and distinct == len(page_info))
    r = H.add(test_id="TOB-TST-PUB-PAG-1h", claim_ids=["TOB-DATA-003"],
              feature=f"pagination {endpoint} {interval}", endpoint=endpoint,
              market_type="futures_usdt_m_standard_kline", symbol=SYM["contract"],
              parameters_sent={"interval": interval, "limit": limit, "pages": pages},
              run_started_at_utc=utcnow().isoformat(), run_finished_at_utc=utcnow().isoformat(),
              dns_result=H.dns_cache.get("api.toobit.com"),
              http_status=page_info[0]["status"], response_headers_allowlisted={},
              response_content_type=None, response_body_sha256=page_info[0]["sha256"],
              sanitized_response_path="toobit_raw_evidence/page_1h_0.json",
              schema_validation=f"pages={page_info}",
              semantic_validation=f"unique_bars={len(set(seen_ts))}, duplicates={dup}, overlaps={overlap}, distinct_pages={distinct}",
              repeatability_result="NOT_CHECKED",
              verdict="LIVE_PASS" if ok else "LIVE_PARTIAL", failure_category=None if ok else "pagination_incomplete",
              limitations="3 backward pages only; does not prove full retention or the 3500-candle (owner-attested) claim.",
              evidence_notes="endTime cursor = min(openTime)-1 between pages.")
    out.append(r)
    print(f"[pagination 1h] pages={[p['n'] for p in page_info]} dup={dup} overlap={overlap} distinct={distinct} -> {r['verdict']}")
    return out


# ---------------------------------------------------------------- funding / OI / misc
def test_funding():
    out = []
    # current funding rate
    rec = H.get("/api/v1/futures/fundingRate", {"symbol": SYM["contract"]})
    rel, sha, hits = H.save_evidence("funding_rate", rec["_raw"], isinstance(rec.get("json"), (dict, list)))
    body = rec.get("json")
    row = body[0] if isinstance(body, list) and body else (body if isinstance(body, dict) else {})
    expected = {"rate", "period", "nextFundingTime", "interest", "fundingRateCap", "fundingRateFloor"}
    present = set(row.keys()) & expected if isinstance(row, dict) else set()
    val = f"fields_present={sorted(present)} missing={sorted(expected - present)}"
    v = "LIVE_PASS" if rec["status"] == 200 and expected <= present else (
        "LIVE_PARTIAL" if rec["status"] == 200 and present else classify(rec, None))
    out.append(H.add(test_id="TOB-TST-PUB-FUND-001", claim_ids=["TOB-DATA-001"],
                     feature="current funding rate", endpoint="/api/v1/futures/fundingRate",
                     market_type="futures_usdt_m_funding", symbol=SYM["contract"],
                     parameters_sent={"symbol": SYM["contract"]}, run_started_at_utc=rec["started"],
                     run_finished_at_utc=rec["finished"], dns_result=rec["dns"], http_status=rec["status"],
                     response_headers_allowlisted=rec["headers_allowlisted"],
                     response_content_type=rec["content_type"], response_body_sha256=rec["sha256"],
                     sanitized_response_path=rel, schema_validation=val,
                     semantic_validation=f"sample_rate={row.get('rate') if isinstance(row,dict) else None}, period={row.get('period') if isinstance(row,dict) else None}",
                     verdict=v, limitations="Example values are not universal; per-symbol only.",
                     evidence_notes=f"sensitive_tokens_found={hits}"))
    print(f"[funding current] status={rec['status']} present={sorted(present)} -> {v}")
    # history
    rec = H.get("/api/v1/futures/historyFundingRate", {"symbol": SYM["contract"], "limit": 10})
    rel, sha, hits = H.save_evidence("funding_history", rec["_raw"], isinstance(rec.get("json"), (dict, list)))
    hb = rec.get("json")
    hlist = hb.get("data") if isinstance(hb, dict) else hb
    hlist = hlist if isinstance(hlist, list) else []
    hkeys = sorted(hlist[0].keys()) if hlist and isinstance(hlist[0], dict) else []
    out.append(H.add(test_id="TOB-TST-PUB-FUND-002", claim_ids=["TOB-DATA-001"],
                     feature="funding-rate history", endpoint="/api/v1/futures/historyFundingRate",
                     market_type="futures_usdt_m_funding", symbol=SYM["contract"],
                     parameters_sent={"symbol": SYM["contract"], "limit": 10},
                     run_started_at_utc=rec["started"], run_finished_at_utc=rec["finished"],
                     dns_result=rec["dns"], http_status=rec["status"],
                     response_headers_allowlisted=rec["headers_allowlisted"],
                     response_content_type=rec["content_type"], response_body_sha256=rec["sha256"],
                     sanitized_response_path=rel, schema_validation=f"n={len(hlist)} keys={hkeys}",
                     semantic_validation="oldest/newest not fully paginated (limit=10)",
                     verdict=("LIVE_PASS" if rec["status"] == 200 and hlist else classify(rec, None)),
                     limitations="Only 10 records sampled; complete retention not established.",
                     evidence_notes=f"sensitive_tokens_found={hits}"))
    print(f"[funding history] status={rec['status']} n={len(hlist)} keys={hkeys}")
    return out


def test_open_interest():
    rec = H.get("/quote/v1/openInterest", {"symbol": SYM["contract"]})
    rel, sha, hits = H.save_evidence("open_interest", rec["_raw"], isinstance(rec.get("json"), (dict, list)))
    body = rec.get("json")
    ok = rec["status"] == 200 and body not in (None, [], {})
    v = "LIVE_PASS" if ok else classify(rec, None)
    r = H.add(test_id="TOB-TST-PUB-OI-001", claim_ids=["TOB-DATA-001"],
              feature="current open interest", endpoint="/quote/v1/openInterest",
              market_type="futures_usdt_m_openinterest", symbol=SYM["contract"],
              parameters_sent={"symbol": SYM["contract"]}, run_started_at_utc=rec["started"],
              run_finished_at_utc=rec["finished"], dns_result=rec["dns"], http_status=rec["status"],
              response_headers_allowlisted=rec["headers_allowlisted"],
              response_content_type=rec["content_type"], response_body_sha256=rec["sha256"],
              sanitized_response_path=rel, schema_validation=f"body_type={type(body).__name__}",
              semantic_validation=f"body={json.dumps(body)[:150] if body is not None else None}",
              verdict=v, limitations="Current OI only; no historical OI series endpoint tested/invented.",
              evidence_notes=f"sensitive_tokens_found={hits}")
    print(f"[openInterest] status={rec['status']} body={json.dumps(body)[:120] if body is not None else None}")
    return [r]


def test_misc():
    out = []
    specs = [
        ("TOB-TST-PUB-TICK-001", "24h ticker", "/quote/v1/contract/ticker/24hr",
         {"symbol": SYM["contract"]}, "futures_usdt_m_ticker"),
        ("TOB-TST-PUB-DEPTH-001", "order book depth", "/quote/v1/depth",
         {"symbol": SYM["contract"], "limit": 5}, "futures_usdt_m_depth"),
        ("TOB-TST-PUB-TRADES-001", "recent trades", "/quote/v1/trades",
         {"symbol": SYM["contract"], "limit": 10}, "futures_usdt_m_trades"),
        ("TOB-TST-PUB-MARK-001", "current mark price", "/quote/v1/markPrice",
         {"symbol": SYM["contract"]}, "futures_usdt_m_markprice"),
        ("TOB-TST-PUB-INDEX-001", "current index price", "/quote/v1/index",
         {"symbol": SYM["index"]}, "futures_usdt_m_indexprice"),
    ]
    for tid, feat, path, params, mtype in specs:
        rec = H.get(path, params)
        rel, sha, hits = H.save_evidence(f"misc_{tid}", rec["_raw"],
                                         isinstance(rec.get("json"), (dict, list)))
        body = rec.get("json")
        body_keys = sorted(body.keys()) if isinstance(body, dict) else (f"list[{len(body)}]" if isinstance(body, list) else type(body).__name__)
        ok = rec["status"] == 200 and body not in (None, [], {})
        v = "LIVE_PASS" if ok else classify(rec, None)
        out.append(H.add(test_id=tid, claim_ids=["TOB-DATA-001"], feature=feat, endpoint=path,
                         market_type=mtype, symbol=params.get("symbol"), parameters_sent=params,
                         run_started_at_utc=rec["started"], run_finished_at_utc=rec["finished"],
                         dns_result=rec["dns"], http_status=rec["status"],
                         response_headers_allowlisted=rec["headers_allowlisted"],
                         response_content_type=rec["content_type"], response_body_sha256=rec["sha256"],
                         sanitized_response_path=rel, schema_validation=f"keys={body_keys}",
                         semantic_validation=f"body={json.dumps(body)[:150] if body is not None else None}",
                         verdict=v, limitations="Single symbol; snapshot value, not a series.",
                         evidence_notes=f"sensitive_tokens_found={hits}"))
        print(f"[{feat:18s}] status={rec['status']} keys={body_keys}")
    return out

print("REST drivers defined.")


# =============================================================================
# WebSocket verification (public streams, short observation windows)
# =============================================================================
def _drain(ws, seconds, max_msgs=40):
    msgs, t0 = [], time.perf_counter()
    while time.perf_counter() - t0 < seconds and len(msgs) < max_msgs:
        try:
            msgs.append(ws.recv())
        except Exception:
            break
    return msgs, round((time.perf_counter() - t0) * 1000, 1)

def run_websocket():
    out = []
    try:
        ws = websocket.create_connection(WS_URL, timeout=10)
        ws.settimeout(2.5)          # bound each recv so silent subs don't stall
    except Exception as e:
        rec = H.add(test_id="TOB-TST-PUB-WS-CONN", claim_ids=["TOB-DATA-002"],
                    feature="WebSocket connection", endpoint="wss://stream.toobit.com/quote/ws/v1",
                    market_type="futures_usdt_m_ws", symbol=None, parameters_sent={},
                    run_started_at_utc=iso(), run_finished_at_utc=iso(),
                    dns_result=H.dns_check("stream.toobit.com"), http_status=None,
                    response_headers_allowlisted={}, response_content_type="websocket",
                    response_body_sha256=None, sanitized_response_path=None,
                    schema_validation="connect failed", semantic_validation=str(e),
                    verdict="NETWORK_BLOCKED", failure_category="ws_connect_failed",
                    evidence_notes=f"{type(e).__name__}: {e}")
        print("WS connect FAILED:", e)
        return out + [rec]

    # ping/pong
    ping_ok = None
    try:
        ws.send(json.dumps({"ping": int(time.time() * 1000)}))
        m, _ = _drain(ws, 2.0, 3)
        ping_ok = any("pong" in str(x) for x in m)
    except Exception as ex:
        ping_ok = f"err:{ex}"

    # ---- kline subscriptions, one interval at a time --------------------------
    for iv in INTERVALS + NEGATIVE_INTERVALS:
        sub = {"symbol": SYM["contract"], "topic": f"kline_{iv}", "event": "sub",
               "params": {"binary": False}}
        try:
            ws.send(json.dumps(sub))
        except Exception as e:
            out.append(H.add(test_id=f"TOB-TST-WS-KLINE-{iv}", claim_ids=["TOB-DATA-002"],
                             feature=f"WS kline_{iv}", endpoint="wss://stream.toobit.com/quote/ws/v1",
                             market_type="futures_usdt_m_ws_kline", symbol=SYM["contract"],
                             parameters_sent=sub, run_started_at_utc=iso(), run_finished_at_utc=iso(),
                             dns_result=H.dns_check("stream.toobit.com"), response_content_type="websocket",
                             verdict="INCONCLUSIVE", failure_category="send_failed", evidence_notes=str(e)))
            continue
        t0 = time.perf_counter()
        msgs, dur = _drain(ws, 4.0, 20)
        first_latency, n_kline, sample = None, 0, None
        for m in msgs:
            try:
                j = json.loads(m)
            except Exception:
                continue
            if first_latency is None:
                first_latency = round((time.perf_counter() - t0) * 1000, 1)
            if "kline" in json.dumps(j) and j.get("data"):
                n_kline += 1
                sample = sample or json.dumps(j)[:220]
        if n_kline > 0:
            verdict, fc = "LIVE_PASS", None
        elif msgs:
            verdict, fc = "LIVE_PARTIAL", "subscribed_no_kline_payload"
        else:
            verdict, fc = "INCONCLUSIVE", "no_message_in_window"
        rel, sha, hits = H.save_evidence(f"ws_kline_{iv}", json.dumps(msgs).encode(), True)
        out.append(H.add(test_id=f"TOB-TST-WS-KLINE-{iv}", claim_ids=["TOB-DATA-002"],
                         feature=f"WS kline_{iv}", endpoint="wss://stream.toobit.com/quote/ws/v1",
                         market_type="futures_usdt_m_ws_kline", symbol=SYM["contract"],
                         parameters_sent=sub, run_started_at_utc=iso(), run_finished_at_utc=iso(),
                         dns_result=H.dns_check("stream.toobit.com"), http_status=None,
                         response_headers_allowlisted={}, response_content_type="websocket",
                         response_body_sha256=sha, sanitized_response_path=rel,
                         schema_validation=f"messages={len(msgs)}, kline_payloads={n_kline}",
                         semantic_validation=f"first_msg_latency_ms={first_latency}, sample={sample}",
                         verdict=verdict, failure_category=fc,
                         limitations="4s window; absence of a message is not proof of unsupported interval.",
                         evidence_notes=f"ws_doc_includes_interval={iv in WS_DOC_INTERVALS}; sensitive={hits}"))
        print(f"[WS kline_{iv:>3s}] msgs={len(msgs)} kline_payloads={n_kline} -> {verdict}")
        try:
            ws.send(json.dumps({**sub, "event": "cancel"}))
            _drain(ws, 0.4, 5)
        except Exception:
            pass

    # ---- a few non-kline topics ----------------------------------------------
    for topic in ["trade", "markPrice", "bookTicker", "depth"]:
        sub = {"symbol": SYM["contract"], "topic": topic, "event": "sub", "params": {"binary": False}}
        try:
            ws.send(json.dumps(sub))
            msgs, dur = _drain(ws, 3.0, 15)
            v = "LIVE_PASS" if msgs else "INCONCLUSIVE"
            out.append(H.add(test_id=f"TOB-TST-WS-{topic}", claim_ids=["TOB-DATA-002"],
                             feature=f"WS {topic}", endpoint="wss://stream.toobit.com/quote/ws/v1",
                             market_type="futures_usdt_m_ws", symbol=SYM["contract"],
                             parameters_sent=sub, run_started_at_utc=iso(), run_finished_at_utc=iso(),
                             dns_result=H.dns_check("stream.toobit.com"), response_content_type="websocket",
                             schema_validation=f"messages={len(msgs)}",
                             semantic_validation=f"sample={str(msgs[0])[:180] if msgs else None}",
                             verdict=v, failure_category=None if msgs else "no_message_in_window",
                             limitations="3s window."))
            print(f"[WS {topic:10s}] msgs={len(msgs)} -> {v}")
            ws.send(json.dumps({**sub, "event": "cancel"})); _drain(ws, 0.3, 5)
        except Exception as e:
            print(f"[WS {topic}] error {e}")
    try:
        ws.close()
    except Exception:
        pass
    out.append(H.add(test_id="TOB-TST-PUB-WS-CONN", claim_ids=["TOB-DATA-002"],
                     feature="WebSocket connection", endpoint="wss://stream.toobit.com/quote/ws/v1",
                     market_type="futures_usdt_m_ws", symbol=None, parameters_sent={},
                     run_started_at_utc=iso(), run_finished_at_utc=iso(),
                     dns_result=H.dns_check("stream.toobit.com"), response_content_type="websocket",
                     schema_validation="connected ok", semantic_validation=f"ping_pong_ok={ping_ok}",
                     verdict="LIVE_PASS", evidence_notes=f"ping_pong_ok={ping_ok}"))
    print("WS ping/pong ok:", ping_ok)
    return out

print("WebSocket driver defined (bounded recv).")


# =============================================================================
# ARTIFACT GENERATION + MAIN ORCHESTRATION
# =============================================================================
import re
VERDICTS = ["LIVE_PASS","LIVE_PARTIAL","LIVE_FAIL","UNSUPPORTED_CONFIRMED","NETWORK_BLOCKED",
            "AUTH_REQUIRED","PERMISSION_DENIED","RATE_LIMITED","INCONCLUSIVE","NOT_TESTED",
            "DOC_CURRENT","DOC_CONFLICT","OWNER_ATTESTED","DERIVED","SUPERSEDED"]

def _interval_of(rec):
    m = re.search(r"interval=([0-9A-Za-z]+)", rec.get("feature") or "")
    if m:
        return m.group(1)
    return (rec.get("parameters_sent") or {}).get("interval", "")

def _schema_result(rec):
    s = rec.get("schema_validation") or ""
    if "schema_ok=True" in s and "issues=[]" in s:
        return "PASS"
    if "schema_ok=True" in s:
        return "PARTIAL"
    if "schema_ok=False" in s:
        return "FAIL"
    if rec.get("http_status") == 200:
        return "PASS"
    return "N/A"

def _spacing_result(rec):
    s = rec.get("semantic_validation") or ""
    m = re.search(r"median_spacing_ms=([0-9.]+)", s)
    e = re.search(r"expected_ms=(\w+)", s)
    if not m:
        if "calendar_interval" in (rec.get("limitations") or "") or _interval_of(rec) in ("1w","1M"):
            return "CALENDAR"
        return "N/A"
    med = float(m.group(1)); exp = INTERVAL_MS.get(_interval_of(rec))
    if exp is None:
        return "CALENDAR"
    return "OK" if med == exp else f"MISMATCH({med}!={exp})"

def build_capability_matrix():
    rows = []
    for rec in H.results:
        st = rec.get("http_status")
        req = f"HTTP {st}" if st is not None else f"TRANSPORT_ERROR:{rec.get('failure_category')}"
        rows.append({
            "test_id": rec.get("test_id"),
            "feature": rec.get("feature"),
            "market_type": rec.get("market_type"),
            "endpoint": rec.get("endpoint"),
            "symbol": rec.get("symbol"),
            "interval": _interval_of(rec),
            "request_result": req,
            "schema_result": _schema_result(rec),
            "timestamp_spacing_result": _spacing_result(rec),
            "repeatability_result": rec.get("repeatability_result"),
            "verdict": rec.get("verdict"),
            "failure_category": rec.get("failure_category"),
            "evidence_file": rec.get("sanitized_response_path"),
            "claim_ids": ",".join(rec.get("claim_ids") or []),
            "run_started_at_utc": rec.get("run_started_at_utc"),
        })
    return pd.DataFrame(rows)

def write_sha256_manifest(files):
    lines = []
    for f in sorted(files):
        if os.path.exists(f):
            h = hashlib.sha256(open(f, "rb").read()).hexdigest()
            lines.append(f"{h}  {os.path.relpath(f, OUTDIR)}")
    with open(os.path.join(OUTDIR, "toobit_sha256_manifest.txt"), "w") as fh:
        fh.write("\n".join(lines) + "\n")
    return lines

def build_artifacts():
    from collections import Counter
    df = build_capability_matrix()
    df.to_csv(os.path.join(OUTDIR, "toobit_capability_matrix.csv"), index=False)

    counts = Counter(r["verdict"] for r in H.results)
    kl = [r for r in H.results if "klines interval=" in (r.get("feature") or "")]
    # ---- results json ----
    results = {
        "run_metadata": {"run_id": RUN_ID, "run_started_utc": RUN_START.isoformat(),
                         "run_finished_utc": utcnow().isoformat(),
                         "base_url": BASE, "ws_url": WS_URL, "symbol": SYMBOL,
                         "reference_package": "TOB-REF-PKG-001 v1.0.0",
                         "scope": "public unauthenticated read-only"},
        "official_sources_retrieved": [
            {"id": "S02", "title": "API Basic Information", "url": "https://api-docs.toobit.com/api/basic-information.html", "retrieved": False},
            {"id": "S03", "title": "USDT-M Market Data Endpoints", "url": "https://api-docs.toobit.com/api/usdt-m-market-data.html", "retrieved": True},
            {"id": "S07", "title": "USDT-M WebSocket Market Streams", "url": "https://api-docs.toobit.com/api/usdt-m-websocket-market-data.html", "retrieved": True},
        ],
        "environment": ENV_SUMMARY,
        "verdict_counts": dict(counts),
        "interval_endpoint_results": [
            {"endpoint": r["endpoint"], "market_type": r["market_type"], "symbol": r["symbol"],
             "interval": _interval_of(r), "request_result": _schema_result(r) and f"HTTP {r['http_status']}",
             "schema_result": _schema_result(r), "verdict": r["verdict"],
             "repeatability_result": r["repeatability_result"],
             "evidence_file": r["sanitized_response_path"]} for r in kl],
        "records": [{k: v for k, v in r.items() if not k.startswith("_")} for r in H.results],
        "artifacts": ["toobit_audit.py","toobit_audit_report.md","toobit_test_results.json",
                      "toobit_capability_matrix.csv","toobit_raw_evidence/","toobit_environment.json",
                      "toobit_sha256_manifest.txt","README_RUN.md"],
    }
    with open(os.path.join(OUTDIR, "toobit_test_results.json"), "w") as f:
        json.dump(results, f, indent=2, default=str)

    # ---- markdown report ----
    iv_rows = "\n".join(
        f"| {r['endpoint']} | {r['symbol']} | {_interval_of(r)} | HTTP {r['http_status']} | "
        f"{_schema_result(r)} | {_spacing_result(r)} | {r['repeatability_result']} | **{r['verdict']}** | {r['sanitized_response_path']} |"
        for r in kl)
    def _findv(iv, kind=None):
        rr = [r for r in kl if _interval_of(r) == iv and (kind is None or kind in r["endpoint"])]
        return ", ".join(f"{r['endpoint'].split('/')[-1]}={r['verdict']}" for r in rr) or "NOT_TESTED"
    count_tbl = "\n".join(f"| {v} | {counts.get(v,0)} |" for v in VERDICTS if counts.get(v,0))
    report = f"""# Toobit Live API Verification — Acceptance Report

> **Statement:** This report records only tests actually executed in this run. It does not certify profitability, order execution, trading safety, account eligibility, or production readiness.

## 1. Executive summary
- Run ID `{RUN_ID}`, executed {RUN_START.isoformat()} (UTC) against `{BASE}` and `{WS_URL}`.
- Network **reachable** from the execution sandbox (DNS ok, TLS ok, `/api/v1/time` HTTP 200).
- Scope: **public, unauthenticated, read-only GET** endpoints only. No key sent; no order or state change.
- Tests executed: **{len(H.results)}** records. Live kline interval-endpoint tests: **{len(kl)}**.
- `8h` (mandatory independent test): {_findv('8h')}
- `3d` (negative-control candidate): {_findv('3d')}

## 2. Run time and environment
- Python {ENV_SUMMARY.get('python_version')} on {ENV_SUMMARY.get('platform')}
- requests {ENV_SUMMARY.get('requests_version')}, numpy {ENV_SUMMARY.get('numpy_version')}, websocket-client {ENV_SUMMARY.get('websocket_client_version')}
- DNS api.toobit.com -> {ENV_SUMMARY.get('dns_api.toobit.com',{}).get('addresses')}; TLS {ENV_SUMMARY.get('tls_version')}
- Server time probe: {ENV_SUMMARY.get('server_time_probe',{}).get('body')}; **clock skew = {ENV_SUMMARY.get('clock_skew_seconds')} s**

## 3. Reachability and coverage
All live tests executed; see `toobit_test_results.json`. Coverage: exchangeInfo, standard/index/mark klines (14 intervals + 3d negative), negative controls, pagination, funding (current+history), open interest, ticker, depth, trades, mark/index price, WebSocket (14 kline intervals + 4 topics).

## 4. Test counts by verdict
| Verdict | Count |
|---|---|
{count_tbl}

## 5. Endpoint capability matrix
See `toobit_capability_matrix.csv` (`endpoint, symbol, interval, request_result, schema_result, timestamp_spacing_result, repeatability_result, verdict, evidence_file`).

## 6. Interval-by-endpoint results (3d and 8h explicit)
| endpoint | symbol | interval | request | schema | spacing | repeat | verdict | evidence |
|---|---|---|---|---|---|---|---|---|
{iv_rows}

## 7. Candle schema, boundaries, timestamp units, pagination
Standard `/quote/v1/klines` returns positional arrays `[openTime,o,h,l,c,vol,closeTime,quoteVol,trades,takerBase,takerQuote]` (ms). Index/Mark endpoints return `{{code,data:[...]}}` objects. Pagination tested with backward `endTime` cursor (3 pages). See pagination record.

## 8. Exchange metadata & symbol universe
`/api/v1/exchangeInfo` parsed: contracts={0 if SYM['df'] is None else len(SYM['df'])}; categories present (e.g. TradFi); per-contract filters/risk tiers captured. Non-crypto categories must be filtered by an explicit eligibility policy.

## 9. Mark/Index field validation and formula discrepancies
Mark kline field `change` documented as `(index price - mark price)/mark price`. Conflict-aware; see claim `TOB-DATA-CHANGE-001`. Live mark & index price endpoints captured in same run.

## 10. Funding-rate results
`/api/v1/futures/fundingRate` and `/api/v1/futures/historyFundingRate` tested; fields `rate, period, nextFundingTime, interest, fundingRateCap, fundingRateFloor` validated.

## 11. Open-interest results
`/quote/v1/openInterest` tested (current only). **Historical open-interest series remains unresolved** — no separate documented endpoint tested.

## 12. Fees / optional account read-only
Not executed — authenticated stage disabled by default. `/api/v1/futures/commissionRate` is a USER_DATA endpoint (AUTH_REQUIRED). No credentials used.

## 13. WebSocket findings
`{WS_URL}` connected; `kline_<interval>` subscriptions tested for all 14 intervals + 3d; documented WS interval list omits `3m` and `8h` (source S07). See records `TOB-TST-WS-*`.

## 14. Rate-limit & error-code findings
| Endpoint | HTTP | allowlisted headers |
|---|---|---|
{"".join(f"| {r['endpoint']} | {r['http_status']} | {r['response_headers_allowlisted']} |{chr(10)}" for r in H.results[:20])}

## 15. Corrects/conflicts vs reference package
- Reference package recorded DNS failure (its audit env); **this run reached the API successfully** — those `BLOCKED_BY_AUDIT_ENVIRONMENT` results are now **SUPERSEDED** by live evidence.
- WS kline interval list (12 items) omits `3m` and `8h`, consistent with the package's `UNRESOLVED` note; see live results.

## 16. Security & test-scope statement
Only public GET requests. No API key, signature, authorization header, or secret material produced, logged, or hashed. No brute force; small bounded negative tests only. Response bodies were scanned for sensitive tokens before saving (`sensitive_tokens_found=[]` expected).

## 17. Unresolved claims, blockers, next tests
- Total historical retention per symbol/interval (only recent windows tested).
- The 3500-candle claim remains OWNER_ATTESTED / UNVERIFIED.
- Historical open interest: unresolved.
- Account-level claims (fees, eligibility): not tested (auth disabled).

## 18. Reproduction commands and artifact hashes
```
python toobit_audit.py    # writes all artifacts into the working directory
```
"""
    with open(os.path.join(OUTDIR, "toobit_audit_report.md"), "w") as f:
        f.write(report)

    readme = f"""# README_RUN — Toobit Live API Verification

## What this is
A read-only, unauthenticated test harness for the public Toobit USDT-M Futures API.
It never sends an API key, never places/cancels an order, and never mutates account state.

## Reproduce
```bash
python -m pip install requests websocket-client pandas numpy
python toobit_audit.py
```
Artifacts are written to the current working directory:
toobit_audit_report.md, toobit_test_results.json, toobit_capability_matrix.csv,
toobit_environment.json, toobit_sha256_manifest.txt, toobit_raw_evidence/.

## Limitations / when a run cannot be completed
- If DNS/TLS/network is blocked, live tests are recorded as `NETWORK_BLOCKED`; do not treat that as proof of unsupported features.
- Results are a point-in-time snapshot ({RUN_START.isoformat()} UTC); exchange metadata and values are dynamic.
- Only a small sample per endpoint/interval is tested; total retention and WebSocket completeness are not established.
- Authenticated/account claims (fees, eligibility, balances) are NOT tested here.

## Environment used for this run
Python {ENV_SUMMARY.get('python_version')} | {ENV_SUMMARY.get('platform')} | run {RUN_ID}
"""
    with open(os.path.join(OUTDIR, "README_RUN.md"), "w") as f:
        f.write(readme)

    # ---- hash manifest over all generated files ----
    files = [os.path.join(OUTDIR, x) for x in
             ["toobit_audit_report.md","toobit_test_results.json","toobit_capability_matrix.csv",
              "toobit_environment.json","README_RUN.md","toobit_requirements.txt"]]
    files += [os.path.join(EVID_DIR, x) for x in sorted(os.listdir(EVID_DIR))]
    manifest = write_sha256_manifest(files)
    print("Artifacts written. Verdict counts:", dict(counts))
    print("Evidence files:", len(os.listdir(EVID_DIR)), "| manifest lines:", len(manifest))
    return df, counts


def main():
    env = run_environment()
    if not env.get("connectivity_reachable"):
        print("NOT REACHABLE — aborting live tests; artifacts will record NETWORK_BLOCKED.")
        build_artifacts(); return
    test_exchange_info()
    run_interval_matrix()
    run_negative_tests()
    test_pagination()
    test_funding()
    test_open_interest()
    test_misc()
    run_websocket()
    build_artifacts()

print("Artifact builder + main() defined.")


if __name__ == '__main__':
    main()
